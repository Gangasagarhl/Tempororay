"""One item of the rules library added to an analysis from page 3 ("Use it in this analysis", owner 2026-11-15: "where is the whole
thing? ... you can add level by level"), and a group added inside a level of the library.

  GET  /api/agents/runs/<rid>/items     every item of the library with its state in this analysis, can_add, why_not
  POST /api/agents/runs/<rid>/items     {section, level, id, admin} -> {ok, how, steps} or 400/409 {error}

One flow on the sample S17 with the stand-in (no model, no server), the way tests/test_command_rules_flow.py runs it. Five rule families of
the NVMe command level are added at five moments of the flow:

  before the plan card exists      "A read could not be recovered"            ticked on the card when the card is made
  a  the plan card is open          "A command never completed"                ticked on the card, nothing else changes
  b  the plan is approved, the flow waits on another card
                                    "The command was aborted because the host asked"   its steps go after the other items' steps,
                                                                               before the errors card and the report; nothing else changes
  b  the errors card is open        "The host sent an Abort"                   its steps go before the errors card, which is asked again
  c  the flow has finished          "A block range beyond the end of the namespace"    the analysis is opened again at the rules with
                                                                               it ticked beside the items it used; those keep their results
  d  the refusals, each one plain sentence.

The fixture writes down what the application answers at each point; the tests read what was written down. Also here: the routes that add
and delete a group inside a level (no flow). Everything is written under temporary folders.
"""
import json
import os
import shutil
import sys
import tempfile
import time

import pytest

os.environ.setdefault("F2T_WORKERS", "1")
APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for _p in (APP, os.path.join(APP, "app"), os.path.join(APP, "tests")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from agentic import core, family1, family3, pipeline, procedures as PR      # noqa: E402
from agentic import rule_hierarchy as RH      # noqa: E402
from nvme_hier import coded_findings as CF, command_error_rules as CE      # noqa: E402
from test_command_rules_flow import S17, TIMEOUT, ITEM, ask_routes, drive, findings_of, key_like, keys_of, step_of, view_of      # noqa: E402

pytestmark = pytest.mark.skipif(not os.path.isdir(S17), reason="the S17 sample recording is not on this machine (the code-only zip carries no samples)")

PRE, A, B, B2, C = ITEM("status_01"), ITEM("behaviour_01"), ITEM("status_13"), ITEM("behaviour_03"), ITEM("protocol_11")
NAME = {PRE: "A read could not be recovered", A: "A command never completed", B: "The command was aborted because the host asked",
        B2: "The host sent an Abort", C: "A block range beyond the end of the namespace"}
ORDER = ["write", "research", "req", "code", "run", "test", "export", "result", "errors"]       # an item's own steps, in the flow's order


def parts(key):
    sec, lvl, rid = key.split("/")
    return {"section": sec, "level": lvl, "id": rid}


def add(c, rid, key, admin="Sagar"):
    r = c.post("/api/agents/runs/%d/items" % rid, json=dict(parts(key), admin=admin))
    return r.status_code, r.get_json()


def items(c, rid):
    r = c.get("/api/agents/runs/%d/items" % rid)
    assert r.status_code == 200, r.get_json()
    j = r.get_json()
    return dict(j, by_key={"%s/%s/%s" % (i["section"], i["level"], i["id"]): i for i in j["items"]})


def steps_now(eng, rid):
    return eng.store.all("SELECT id, idx, key, state, output, started, attempts FROM step WHERE run=? ORDER BY idx", (rid,))


def ticks(rv):
    return sorted(i["key"] for i in rv["data"]["items"] if i.get("selected"))


@pytest.fixture(scope="module")
def w():
    import fuzz_app as F
    from api import config_api, hier_api
    root = tempfile.mkdtemp(prefix="add_item_%d_" % os.getpid())
    kept = (core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK)
    uploads, hook, standin, tree_of = PR._UPLOADS[0], PR.MODEL_CONNECTED, dict(PR.STANDIN_CODE), pipeline.tree_of
    w = {"root": root}
    try:
        app, c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kept[0]
        family3._SECTIONS_SEEN[0] = None
        c.get("/api/agents/state")
        eng = app.config["services"].agentic_engine
        w["eng"] = eng
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "added items", "folder": S17}).get_json()["id"]
        rid = c.post("/api/agents/projects/%d/flow" % pid, json={"admin": "t"}).get_json()["run"]
        w["rid"] = rid

        # ---- before the plan card exists: the first card of the flow (stage 1)
        rv, st, v = drive(c, rid, lambda s: True, [])
        w["pre"] = {"card": st["key"], "items": items(c, rid), "add": add(c, rid, PRE), "after": items(c, rid),
                    "no_admin": add(c, rid, A, admin="   ")}

        # ---- a: the plan card is open
        rv, st, v = drive(c, rid, lambda s: s["key"] == "f3_plan", [])
        w["a"] = {"ticks_before": ticks(rv), "items": items(c, rid), "add": add(c, rid, A)}
        v = view_of(c, rid)
        rv2 = next(q for q in v["reviews"] if q["state"] == "open")
        w["a"].update(ticks_after=ticks(rv2), same_review=rv2["id"] == rv["id"], after=items(c, rid), again=add(c, rid, A),
                      steps=[s["key"] for s in v["steps"]])
        # the admin unticks what they do not want and approves the card as it is (the page sends its ticks)
        chosen = [k for k in ticks(rv2) if k in (TIMEOUT, PRE, A)]
        w["a"]["chosen"] = chosen
        assert c.post("/api/agents/reviews/%d/decide" % rv2["id"], json={"decision": "approve", "admin": "t", "edits": {"selected": chosen}}).status_code == 200
        w["a"]["plan_input"] = json.loads(eng.store.one("SELECT input FROM step WHERE run=? AND key='f3_plan'", (rid,))["input"])

        # ---- b: the plan is approved and the flow waits on the result card of the built-in check
        rv, st, v = drive(c, rid, lambda s: s["key"] == "f3:%s:result" % TIMEOUT, chosen)
        before = steps_now(eng, rid)
        got = add(c, rid, B)
        w["b"] = {"before": before, "add": got, "after": steps_now(eng, rid), "items": items(c, rid), "card": rv["id"],
                  "params": json.loads(eng.store.one("SELECT params FROM run WHERE id=?", (rid,))["params"])}

        # ---- d: the refusals (the flow waits on the same card)
        d = {"already": add(c, rid, TIMEOUT), "no_such": add(c, rid, "errors/nvme_command/no_such_rule"), "no_admin": add(c, rid, ITEM("behaviour_02"), admin=""),
             "bad_level": add(c, rid, "errors/no_such_level/x"), "items_404": c.get("/api/agents/runs/999999/items").status_code}
        family3.delete_item("errors", "nvme_command", CE.item_id("behaviour_02"), "t", "the test deletes it")
        try:
            d["deleted"] = add(c, rid, ITEM("behaviour_02"))
        finally:
            family3.restore_item("errors", "nvme_command", CE.item_id("behaviour_02"), "t")
        other = family3.add_item("analytics", "other", "Rows of the bench log", "count the rows of bench_log.csv", "t")
        d["other"] = add(c, rid, "analytics/other/%s" % other["id"])
        d["other_state"] = items(c, rid)["by_key"]["analytics/other/%s" % other["id"]]
        family3.delete_item("analytics", "other", other["id"], "t", "only for the test")
        pipeline.tree_of = lambda *a, **k: None          # as if the admin had gone on without stage 2: a rule that reads the tree cannot be used
        try:
            d["no_tree"] = add(c, rid, ITEM("behaviour_02"))
        finally:
            pipeline.tree_of = tree_of
        oid = eng.store.exec("INSERT INTO run (project, kind, target, params, state, created, updated, heartbeat) VALUES (?,?,?,?,?,?,?,?)",
                             (pid, "rule_run", "", "{}", "finished", time.time(), time.time(), time.time()))
        d["other_kind"] = add(c, rid=oid, key=ITEM("behaviour_02"))
        d["other_kind_get"] = c.get("/api/agents/runs/%d/items" % oid).status_code
        eng.store.exec("DELETE FROM run WHERE id=?", (oid,))
        d["unchanged"] = [(s["id"], s["idx"], s["key"]) for s in steps_now(eng, rid)] == [(s["id"], s["idx"], s["key"]) for s in w["b"]["after"]]
        w["d"] = d

        # ---- the added family runs to its result card: before the approval its errors are not listed and the page of one refuses
        up = step_of(v, "f3:%s:run" % TIMEOUT)["output"]["upload_id"]
        db = PR.source_paths(up)[PR.TREE]
        w["up"], w["db"] = up, db
        cards = []
        rv, st, v = drive(c, rid, lambda s: s["key"] == "f3:%s:result" % B, chosen, on_card=lambda s, r, vv: cards.append(s["key"]))
        run_out = step_of(v, "f3:%s:run" % B)["output"]
        filed = CF.file_findings(db, "errors", "nvme_command", CE.item_id("status_13"), run_out["procedure_version"], NAME[B], run_out["output_csv"])
        fid = findings_of(db, key_like(B))[0][0]
        w["b_wait"] = {"cards": list(cards), "waiting": pipeline.waiting_patterns(v["steps"]), "errors_step": keys_of(v, B)["errors"],
                       "routes": ask_routes(c, up, fid), "filed": filed, "findings_before": None}
        assert CF.remove(db, "errors", "nvme_command", CE.item_id("status_13")) == filed["total"]
        w["b_wait"]["findings_before"] = findings_of(db, key_like(B))

        # ---- b again: the errors card is open
        rv, st, v = drive(c, rid, lambda s: s["key"] == "errors_done", chosen)
        errs = keys_of(v, B)["errors"]["output"]["errors"]
        w["b_done"] = {"errors": errs, "findings": findings_of(db, key_like(B)), "routes": ask_routes(c, up, errs[0]["finding"]) if errs else {},
                       "gate_review": rv["id"], "keys": keys_of(v, B)}
        before = steps_now(eng, rid)
        got = add(c, rid, B2)
        w["b2"] = {"before": before, "add": got, "after": steps_now(eng, rid),
                   "gate_review": eng.store.one("SELECT state, comment FROM review WHERE id=?", (rv["id"],))}
        rv, st, v = drive(c, rid, lambda s: s["key"] == "errors_done", chosen)
        w["b2"]["gate_again"] = {"review": rv["id"], "b2_result": keys_of(v, B2)["result"]["state"], "b2_errors": keys_of(v, B2)["errors"]}
        _rv, _st, v = drive(c, rid, lambda s: False, chosen)
        w["end"] = {"state": v["run"]["state"], "steps": steps_now(eng, rid), "items": items(c, rid)}

        # ---- c: the flow has finished
        got = add(c, rid, C)
        w["c"] = {"add": got, "run": eng.store.one("SELECT state FROM run WHERE id=?", (rid,))["state"]}
        rv, st, v = drive(c, rid, lambda s: s["key"] == "f3_plan", [])
        w["c"].update(ticks=ticks(rv), items=items(c, rid), again=add(c, rid, C))
        chosen_c = ticks(rv)
        assert c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t", "edits": {"selected": chosen_c}}).status_code == 200
        w["c"]["plan_out"] = json.loads(eng.store.one("SELECT output FROM step WHERE run=? AND key='f3_plan'", (rid,))["output"])
        w["c"]["plan_input"] = json.loads(eng.store.one("SELECT input FROM step WHERE run=? AND key='f3_plan'", (rid,))["input"])
        _rv, _st, v = drive(c, rid, lambda s: False, chosen_c)
        w["c"].update(state=v["run"]["state"], steps=steps_now(eng, rid), view=v, items_end=items(c, rid))
        yield w
    finally:
        pipeline.tree_of = tree_of
        core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK = kept
        PR.use_uploads_folder(uploads)
        PR.MODEL_CONNECTED = hook
        PR.STANDIN_CODE.clear()
        PR.STANDIN_CODE.update(standin)
        family3._SECTIONS_SEEN[0] = None
        shutil.rmtree(root, ignore_errors=True)


# ============================================================================================== GET: the whole library with its states
def test_get_lists_all_43_items_of_the_library_with_their_states(w):
    got = w["a"]["items"]
    lib = [(s["section"], l["level"], it["id"]) for s in family3.tree() for l in s["levels"] for it in l["items"]]
    assert len(got["items"]) == 43 and sorted((i["section"], i["level"], i["id"]) for i in got["items"]) == sorted(lib)
    assert all(set(i) == {"section", "level", "id", "state", "words"} for i in got["items"])
    assert got["can_add"] is True and got["why_not"] == ""
    by = got["by_key"]
    # on the open plan card: the items the card ticks, and the one added before the card was made, are "chosen, plan not approved yet"
    ticked = {k for k, i in by.items() if i["state"] == pipeline.ITEM_TICKED}
    assert ticked == set(w["a"]["ticks_before"]) and PRE in ticked
    assert by[PRE]["words"] == "It is ticked on the card that asks which rules to use: it runs when you approve that card."
    assert {i["state"] for k, i in by.items() if k not in ticked} == {pipeline.ITEM_OUT}
    assert by[A]["words"] == "It is not in this analysis: “Use it in this analysis” adds it."


def test_get_after_the_items_ran_says_in_the_analysis_for_each_of_them(w):
    by = w["end"]["items"]["by_key"]
    assert {k for k, i in by.items() if i["state"] == pipeline.ITEM_IN} == {TIMEOUT, PRE, A, B, B2}
    assert by[B]["words"] == "It is in this analysis: its steps are on page 3."
    assert w["c"]["items_end"]["by_key"][C]["state"] == pipeline.ITEM_IN and len(w["c"]["items_end"]["items"]) == 43


# ============================================================================================== before the plan card exists
def test_an_item_added_before_the_plan_card_is_ticked_on_it_when_it_is_made(w):
    p = w["pre"]
    assert p["card"] != "f3_plan" and p["items"]["by_key"][PRE]["state"] == pipeline.ITEM_OUT
    assert p["add"] == (200, {"ok": True, "steps": [], "how": "“A read could not be recovered” will be ticked on the card that asks which rules to use, when the analysis reaches that card."})
    assert p["after"]["by_key"][PRE] == dict(parts(PRE), state=pipeline.ITEM_TICKED,
                                             words="It will be ticked on the card that asks which rules to use, when the analysis reaches that card.")
    assert PRE in w["a"]["ticks_before"]
    # the 38 families stay unticked except the one the admin added: nothing is chosen for the admin
    fams = [k for k in w["a"]["ticks_before"] if k.split("/")[2].startswith(CE.ITEM_PREFIX)]
    assert fams == [PRE]


# ============================================================================================== a: the plan card is open
def test_a_while_the_plan_card_is_open_the_item_is_ticked_on_it_and_nothing_else_changes(w):
    a = w["a"]
    assert a["add"] == (200, {"ok": True, "steps": [], "how": "“A command never completed” is now ticked on the card that asks which rules to use: approve that card to run it with the others."})
    assert a["ticks_after"] == sorted(a["ticks_before"] + [A]) and a["same_review"]
    assert a["after"]["by_key"][A]["state"] == pipeline.ITEM_TICKED
    assert a["again"] == (409, {"error": "“A command never completed” is already ticked on the card that asks which rules to use: approve that card to run it."})
    assert not any(k.startswith("f3:%s:" % A) for k in a["steps"])          # no step before the card is approved
    assert "add_items" not in a["plan_input"] and "keep_chosen" not in a["plan_input"]   # the approval decided them


# ============================================================================================== b: the plan is approved, the flow waits
def test_b_the_items_steps_go_after_the_other_items_and_before_the_errors_card_and_the_report(w):
    b = w["b"]
    code, ans = b["add"]
    assert code == 200 and ans["ok"] is True
    n = sum(1 for k in ans["steps"] if k.startswith("f3:"))
    assert ans["how"] == ("“The command was aborted because the host asked” was added to this analysis: its %d steps are on page 3 after the other rules, "
                          "and they run when the analysis reaches them; its result card comes to you like the others." % n)
    after = b["after"]
    keys = [s["key"] for s in after]
    new = [k for k in keys if k.startswith("f3:%s:" % B)]
    assert new == ans["steps"] and [k.rsplit(":", 1)[1] for k in new] == [x for x in ORDER if "f3:%s:%s" % (B, x) in new]
    assert [k.rsplit(":", 1)[1] for k in new][-3:] == ["export", "result", "errors"] and "run" in [k.rsplit(":", 1)[1] for k in new]
    first, last = keys.index(new[0]), keys.index(new[-1])
    others_f3 = [i for i, k in enumerate(keys) if k.startswith("f3:") and not k.startswith("f3:%s:" % B)]
    assert max(others_f3) < first and last < keys.index("errors_done") < keys.index("report")
    # no other step changed: the same steps, in the same order, with the same state and output
    old = [(s["id"], s["key"], s["state"], s["output"], s["started"], s["attempts"]) for s in b["before"]]
    assert [(s["id"], s["key"], s["state"], s["output"], s["started"], s["attempts"]) for s in after if not s["key"].startswith("f3:%s:" % B)] == old
    assert b["items"]["by_key"][B]["state"] == pipeline.ITEM_IN
    added = b["params"]["added_items"]
    assert [(x["item"], x["by"], x["steps"]) for x in added] == [(B, "Sagar", len(ans["steps"]))]


def test_b_the_added_family_runs_in_order_to_its_result_card_and_its_errors_wait_for_the_approval(w):
    wb = w["b_wait"]
    order = [k for k in wb["cards"] if k.startswith("f3:")]
    assert "f3:%s:result" % B not in order                       # the stop was at its result card: it came after the others' cards
    waits = {x["item"]: x for x in wb["waiting"]}
    assert waits[B]["state"] == "waits" and waits[B]["sentence"] == "The result of '%s' waits for your decision on page 3: its errors are listed here after you approve it." % NAME[B]
    assert wb["errors_step"]["state"] == "waiting" and not wb["errors_step"].get("output")
    want = ("The result of '%s' waits for your decision on page 3 of the analysis “added items”: this error can be opened and worked on "
            "(stage 1, stage 2 and its test) after you approve that result." % NAME[B])
    assert wb["filed"]["total"] == 1 and len(wb["routes"]) == 9
    for route, (code, err) in wb["routes"].items():
        assert (code, err) == (409, want), (route, code, err)
    assert wb["findings_before"] == []


def test_b_after_its_result_is_approved_its_errors_are_listed_and_the_page_of_one_opens(w):
    d = w["b_done"]
    assert [e["row"] for e in d["errors"]] == [144] and len(d["findings"]) == 1
    assert d["keys"]["result"]["state"] == "approved" and d["keys"]["errors"]["state"] == "done"
    code, err = d["routes"]["GET /"]
    assert code == 200 and err is None


def test_b_with_the_errors_card_open_the_card_is_closed_and_asked_again_after_the_new_item(w):
    b = w["b2"]
    code, ans = b["add"]
    n = sum(1 for k in ans["steps"] if k.startswith("f3:"))
    assert code == 200 and ans["how"] == (
        "“The host sent an Abort” was added to this analysis: its %d steps are on page 3 after the other rules, and they run when the analysis reaches them; "
        "its result card comes to you like the others. The card of the errors was closed: it is asked again after the result of “The host sent an Abort”, "
        "with its errors listed." % n)
    assert b["gate_review"]["state"] == "rejected" and "was added to the analysis by Sagar" in b["gate_review"]["comment"]
    keys = [s["key"] for s in b["after"]]
    assert keys.index(ans["steps"][-1]) < keys.index("errors_done") < keys.index("report")
    gate = next(s for s in b["after"] if s["key"] == "errors_done")
    assert gate["state"] == "waiting"
    old = {s["id"]: s for s in b["before"]}
    for s in b["after"]:
        if s["key"].startswith("f3:%s:" % B2) or s["key"] == "errors_done":
            continue
        o = old[s["id"]]
        assert (s["key"], s["state"], s["output"], s["started"], s["attempts"]) == (o["key"], o["state"], o["output"], o["started"], o["attempts"])
    g = b["gate_again"]
    assert g["review"] != w["b_done"]["gate_review"] and g["b2_result"] == "approved" and g["b2_errors"]["state"] == "done"
    assert sorted(e["row"] for e in g["b2_errors"]["output"]["errors"]) == [145, 216, 358, 501, 570]


# ============================================================================================== c: the flow has finished
def test_c_a_finished_flow_is_opened_again_with_the_item_ticked_beside_the_ones_it_used(w):
    c = w["c"]
    assert w["end"]["state"] == "finished"
    assert c["add"] == (200, {"ok": True, "steps": [], "how": (
        "This analysis had finished, so it was opened again at the rules: the card that asks which rules to use comes again with “%s” ticked beside the 5 rules "
        "it already used. Approve it as it is: “%s” runs, and the others keep their results while their rule, their code and the data are the same." % (NAME[C], NAME[C]))})
    assert c["run"] == "running"
    assert c["ticks"] == sorted([TIMEOUT, PRE, A, B, B2, C])          # exactly these: nothing else is ticked for the admin
    assert c["items"]["by_key"][C]["state"] == pipeline.ITEM_TICKED and c["again"][0] == 409
    assert sorted(c["plan_out"]["kept"]) == sorted([TIMEOUT, PRE, A, B, B2]) and c["plan_out"]["chosen"]
    assert "add_items" not in c["plan_input"] and "keep_chosen" not in c["plan_input"]
    assert c["state"] == "finished"


def test_c_the_items_already_done_keep_their_results_and_no_step_ran_twice(w):
    end, after = w["end"]["steps"], w["c"]["steps"]
    by_id = {s["id"]: s for s in after}
    for s in end:
        if s["key"] in ("f3_plan", "errors_done", "report"):
            continue                    # the decisions and the report are asked and written again, as opening again at the rules promises
        a = by_id[s["id"]]
        assert (a["key"], a["state"], a["output"], a["started"], a["attempts"]) == (s["key"], s["state"], s["output"], s["started"], s["attempts"]), s["key"]
    keys = [s["key"] for s in after]
    assert not any("#2" in k for k in keys)                            # no item got a second round
    mine = [k for k in keys if k.startswith("f3:%s:" % C)]
    assert mine and all(by["state"] in ("done", "approved", "skipped") for by in after if by["key"] in mine)
    assert keys.index(mine[-1]) < keys.index("errors_done") < keys.index("report")


# ============================================================================================== d: refusals
def test_d_every_refusal_is_one_plain_sentence(w):
    d = w["d"]
    assert d["already"] == (409, {"error": "“NVMe command timeout” is already in this analysis: its steps are on page 3."})
    assert d["no_such"] == (400, {"error": "The rules library has no such item."})
    assert d["bad_level"] == (400, {"error": "The rules library has no such item."})
    assert d["no_admin"] == (400, {"error": "Say who adds the item: the decisions that follow are stored with that name."})
    assert w["pre"]["no_admin"] == d["no_admin"]
    assert d["deleted"] == (400, {"error": "“%s” is in Deleted items: restore it in the rules library first, then add it." % CE.BY_ID["behaviour_02"]["name"]})
    assert d["other"] == (400, {"error": "“Rows of the bench log” cannot be used in this analysis: it reads a CSV file of the folder that is not one of the analyzer's exports, and this analysis has none."})
    assert d["other_state"]["state"] == pipeline.ITEM_OUT and "cannot be used here" in d["other_state"]["words"]
    assert d["no_tree"] == (400, {"error": "“%s” cannot be used in this analysis: it %s." % (CE.BY_ID["behaviour_02"]["name"], pipeline.NO_TREE_ITEM)})
    assert d["other_kind"] == (400, {"error": "Only an analysis made by the flow can take an item of the rules library: this run is of another kind."})
    assert d["other_kind_get"] == 400 and d["items_404"] == 404
    assert d["unchanged"]                                              # no refusal changed a step


def test_while_the_report_is_written_an_item_cannot_be_added(w):
    """The flow's own order: once the errors card is approved, an item would come after the report; refused until the flow has finished."""
    f = {"plan": {"state": "approved", "idx": 1}, "run": {"state": "running"}, "by_key": {"errors_done": {"state": "approved", "idx": 5}, "report": {"state": "waiting", "idx": 6}}}
    assert pipeline._when_not(f) == pipeline.REPORT_UNDER_WAY
    f["by_key"]["errors_done"]["state"] = "running"
    assert pipeline._when_not(f) == pipeline.ERRORS_CARD_BEING_MADE
    f["plan"]["state"] = "running"
    assert pipeline._when_not(f) == pipeline.PLAN_BEING_MADE
    f["plan"], f["run"]["state"] = {"state": "approved", "idx": 1}, "finished"
    f["by_key"]["errors_done"]["state"] = "approved"
    assert pipeline._when_not(f) == ""                                 # finished: case c opens it again


def test_tick_added_items_never_ticks_a_blocked_item_and_keeps_the_cards_own_ticks_otherwise():
    items = [{"key": "x", "selected": True, "blocked": ""}, {"key": "y", "selected": False, "blocked": ""}, {"key": "z", "selected": False, "blocked": "reads the tree"}]
    got = pipeline.tick_added_items([dict(i) for i in items], {"add_items": ["y", "z"]})
    assert [i["selected"] for i in got] == [True, True, False]
    got = pipeline.tick_added_items([dict(i) for i in items], {"add_items": ["y"], "keep_chosen": []})
    assert [i["selected"] for i in got] == [False, True, False]
    assert pipeline.tick_added_items([dict(i) for i in items], {}) == items


# ============================================================================================== groups inside a level
@pytest.fixture()
def gworld(tmp_path, monkeypatch):
    from test_rule_hierarchy import World
    know = str(tmp_path / "knowledge")
    os.makedirs(know)
    monkeypatch.setattr(family1, "knowledge_dir", lambda: know)
    family3._SECTIONS_SEEN[0] = None
    family3.tree()
    uploads = PR._UPLOADS[0]
    try:
        yield World(tmp_path / "app", know, monkeypatch)
    finally:
        PR.use_uploads_folder(uploads)
        family3._SECTIONS_SEEN[0] = None


def level_of(h, section, lid):
    s = next(x for x in h["sections"] if x["section"] == section)
    return next(l for k in s["kinds"] for l in k["levels"] if l["id"] == lid)


def test_a_group_is_added_inside_a_level_shown_after_the_stated_ones_and_takes_an_item(gworld):
    c = gworld.c
    r = c.post("/api/agents/rule-hierarchy/levels/nvme_command/groups", json={"name": "Queue depth checks", "about": "rules on how deep a queue got", "admin": "Sagar"})
    assert r.status_code == 200, r.get_json()
    g = r.get_json()["group"]
    assert (g["name"], g["level"], g["section"], g["about"]) == ("Queue depth checks", "nvme_command", "", "rules on how deep a queue got")
    lvl = level_of(gworld.hier(), "errors", "nvme_command")
    assert [x["name"] for x in lvl["groups"]] == [n for n, _a in CE.GROUPS] + ["Queue depth checks"]
    mine = lvl["groups"][-1]
    assert mine["added"] is True and mine["id"] == g["id"] and mine["stated"] is False and mine["items"] == [] and mine["about"] == "rules on how deep a queue got"
    assert not any(x["added"] for x in lvl["groups"][:-1])
    assert [x["name"] for x in level_of(gworld.hier(), "analytics", "nvme_command")["groups"]] == ["Queue depth checks"]     # every section
    # an item is put in it, as in a stated group
    r = c.post("/api/agents/rule-hierarchy/items", json={"section": "errors", "level": "nvme_command", "group": "queue depth  checks", "name": "Queue full",
                                                         "description": "a submission queue held more commands than its size", "admin": "Sagar"})
    assert r.status_code == 200, r.get_json()
    assert r.get_json()["rule"]["group"] == "Queue depth checks"
    lvl = level_of(gworld.hier(), "errors", "nvme_command")
    assert [i["name"] for i in lvl["groups"][-1]["items"]] == ["Queue full"] and lvl["groups"][-1]["items"][0]["in_group"] == "Queue depth checks"
    # it cannot be deleted while it holds that item; empty, it can
    r = c.delete("/api/agents/rule-hierarchy/levels/nvme_command/groups/%s" % g["id"], json={"admin": "Sagar"})
    assert r.status_code == 400 and r.get_json()["error"] == ("'Queue depth checks' still holds 1 item (Queue full): delete it first (Deleted items can restore an item "
                                                             "later), then the group")
    family3.delete_item("errors", "nvme_command", r_id(gworld, "Queue full"), "Sagar")
    r = c.delete("/api/agents/rule-hierarchy/levels/nvme_command/groups/%s" % g["id"], json={"admin": "Sagar"})
    assert r.status_code == 200 and r.get_json()["deleted"] == "Queue depth checks"
    assert [x["name"] for x in level_of(r.get_json()["hierarchy"], "errors", "nvme_command")["groups"]] == [n for n, _a in CE.GROUPS]
    with open(RH.kinds_file(), encoding="utf-8") as fh:
        assert json.load(fh)["groups"] == []


def r_id(gworld, name):
    lvl = level_of(gworld.hier(), "errors", "nvme_command")
    return next(i["id"] for i in RH.items_of(lvl) if i["name"] == name)


def test_a_group_name_that_exists_or_is_empty_is_refused_and_so_is_a_level_without_groups(gworld):
    c = gworld.c
    post = lambda lid, body: c.post("/api/agents/rule-hierarchy/levels/%s/groups" % lid, json=dict(body, admin="Sagar"))       # noqa: E731
    stated = CE.GROUPS[0][0]
    r = post("nvme_command", {"name": " %s " % stated.upper()})
    assert r.status_code == 400 and r.get_json()["error"] == "'NVMe command level errors' has a group named '%s' already" % stated.upper()
    assert post("split", {"name": "Long splits", "section": "analytics"}).status_code == 200
    r = post("split", {"name": "long  SPLITS"})
    assert r.status_code == 400 and "has a group named" in r.get_json()["error"]
    assert post("split", {"name": "Long splits", "section": "errors"}).status_code == 200        # the other section has none of that name
    for bad, word in (("", "give a group a name"), ("   ", "give a group a name"), (None, "must be text"), ("x" * 200, "under 80 characters")):
        r = post("link", {"name": bad})
        assert r.status_code == 400 and word in r.get_json()["error"], (bad, r.get_json())
    r = post("other", {"name": "Mine"})
    assert r.status_code == 400 and r.get_json()["error"] == ("a group can be added inside one of the analyzer's five levels only: the items of this level are listed "
                                                             "directly under it")
    assert post("no_such_level", {"name": "Mine"}).status_code == 404
    assert post("link", {"name": "Mine", "section": "no_such_section"}).status_code == 400
    # a stated group is the application's: it cannot be deleted; a group that is not there: 404
    r = c.delete("/api/agents/rule-hierarchy/levels/nvme_command/groups/%s" % stated, json={"admin": "Sagar"})
    assert r.status_code == 400 and r.get_json()["error"] == "this group is part of the application: it cannot be deleted"
    assert c.delete("/api/agents/rule-hierarchy/levels/nvme_command/groups/grp_no_such", json={"admin": "Sagar"}).status_code == 404
    # the kinds and levels the admin added are kept beside the groups in the same file
    kind = gworld.add_kind("Bench logs")
    with open(RH.kinds_file(), encoding="utf-8") as fh:
        stored = json.load(fh)
    assert [k["label"] for k in stored["kinds"]] == ["Bench logs"] and sorted(g["name"] for g in stored["groups"]) == ["Long splits", "Long splits"]
    assert kind["id"]
