"""The three NVMe command errors the owner kept (2026-11-15): NVMe command timeout, Read failed, and the command aborted because the
host asked. Two faults an independent check found on a recording with planted cases, kept fixed here:

  A. "never completed" was decided from an empty status cell in the command's row alone, although the tree held the command's
     completion entry: the timeout rule then listed a completed command as "never completed".
  B. a status written the way the NVMe specification writes hexadecimal values ("81h", "1Bh") was read as decimal (81 = 51h),
     so an Unrecovered Read Error (2h/81h) was named "an error status (2h/51h)".
"""
import json
import os
import shutil
import sqlite3
import sys

import pytest

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (APP, os.path.join(APP, "app")):
    if p not in sys.path:
        sys.path.insert(0, p)
os.environ.setdefault("F2T_WORKERS", "1")

from nvme_hier import builder as B, command_error_rules as CE, loader as L, parse as P, rules as RL, tree_api as T   # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}


def test_a_value_written_with_h_is_read_as_hexadecimal():
    assert [P.int_value(x) for x in ("81h", "1Bh", "07h", "0x81", "129", "81", " 7 ", "12 us")] == [129, 27, 7, 129, 129, 81, 7, 12]
    assert P.int_value("") is None and P.int_value(None) is None
    assert P.int_value("81h", hex_default=True) == 129


def _tree(tmp_path):
    if not os.path.isdir(S17):
        pytest.skip("the sample S17 is not on this machine")
    db = str(tmp_path / "hier.sqlite")
    L.load_upload(db, {k: os.path.join(S17, v) for k, v in NAMES.items() if os.path.exists(os.path.join(S17, v))})
    B.build(db)
    return db


def _findings(db, rule):
    con = sqlite3.connect(db)
    try:
        return {r: json.loads(d or "{}") for r, d in con.execute("SELECT rowid, detail FROM finding WHERE rule = ? ORDER BY rowid", (rule,))}
    finally:
        con.close()


def test_the_three_rules_on_s17_find_exactly_the_rows_an_independent_reading_finds(tmp_path):
    db = _tree(tmp_path)
    RL.apply(db)
    t = _findings(db, "cmd.timeout")
    assert {r: d.get("kind") for r, d in t.items()} == {144: "aborted by the host", 155: "never completed", 216: "never completed",
                                                         295: "never completed", 358: "never completed", 443: "never completed", 509: "never completed"}
    assert _findings(db, "cmd.read_failure") == {}
    tree = T.Tree(db)
    try:
        assert [x["row"] for x in CE.find("status_13", tree, {})] == [144]
    finally:
        tree.close()


def test_a_completed_command_with_an_empty_status_cell_is_not_never_completed(tmp_path):
    db = _tree(tmp_path)
    con = sqlite3.connect(db)
    # row 55 of S17 is a command the tree has a completion entry for; its status cells are emptied, as an export may leave them
    has_end = con.execute("SELECT COUNT(*) FROM ntx WHERE parent_level = 'nvme_command' AND parent = 55 AND type LIKE '%Completion Queue Entry%'").fetchone()[0]
    assert has_end >= 1
    con.execute("UPDATE cmd SET sct = NULL, sc = NULL WHERE rowid_file = 55")
    con.commit()
    con.close()
    RL.apply(db)
    t = _findings(db, "cmd.timeout")
    assert 55 not in t or t[55].get("kind") != "never completed", t.get(55)
    assert {155, 216, 295, 358, 443, 509} <= {r for r, d in t.items() if d.get("kind") == "never completed"}


def test_an_unrecovered_read_error_written_81h_keeps_its_meaning(tmp_path):
    if not os.path.isdir(S17):
        pytest.skip("the sample S17 is not on this machine")
    src = tmp_path / "s17"
    shutil.copytree(S17, src)
    path = src / "nvme_command.csv"
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    import csv
    import io
    rows = list(csv.reader(io.StringIO("".join(lines))))
    head = rows[0]
    sct_i = next(i for i, h in enumerate(head) if h in ("ST.SCT", "SCT"))
    sc_i = next(i for i, h in enumerate(head) if h in ("ST.SC", "SC"))
    opc_i = next(i for i, h in enumerate(head) if h == "OPC")
    sq_i = next(i for i, h in enumerate(head) if h == "SQID")
    # the first Read on an I/O queue that completed with success: its status becomes 2h/81h, written the specification's way
    k = next(i for i, r in enumerate(rows[1:], 1) if len(r) > max(sct_i, sc_i, opc_i, sq_i) and r[sq_i] not in ("", "0")
             and P.int_value(r[opc_i], hex_default=True) == 2 and r[sct_i] in ("0", "0h") and r[sc_i] in ("0", "0h", "00h"))
    rows[k][sct_i], rows[k][sc_i] = "2h", "81h"
    out = io.StringIO()
    csv.writer(out, lineterminator="\n").writerows(rows)
    path.write_text(out.getvalue(), encoding="utf-8")
    db = str(tmp_path / "hier.sqlite")
    L.load_upload(db, {kk: str(src / v) for kk, v in NAMES.items() if (src / v).exists()})
    B.build(db)
    con = sqlite3.connect(db)
    assert con.execute("SELECT sct, sc FROM cmd WHERE rowid_file = ?", (k,)).fetchone() == (2, 0x81)
    con.close()
    RL.apply(db)
    rf = _findings(db, "cmd.read_failure")
    assert k in rf and (rf[k].get("SCT"), rf[k].get("SC")) == (2, 0x81), rf
