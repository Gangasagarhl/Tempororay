"""The whole flow of the rule families of the NVMe command level (owner, 2026-11-15: "rules and all present should be at the third one ...
after the error analysis is done ... isolation of the defect should happen, and then later other things ... fix the flow. Test the flow.").

One application on a throw-away root, sample samples/clean_five_files/S17_io_timeout_abort_reset, the stand-in (no model, no server), two
flows one after the other:

  FLOW 1, no model connected. Chosen on the plan card: the built-in check "NVMe command timed out" and five rule families of the application's
  rule set: "A command never completed", "The host sent an Abort", "The command was aborted because the host asked", "A read could not be
  recovered" (finds nothing on S17) and "A block range beyond the end of the namespace" (cannot be checked on S17). Their code is the
  application's reference implementation. Checked in the order of the flow: nothing is an error before its result is approved; after the
  approval the rows are findings of the tree with their numbers, with the reason of each row and the sentence of its episode; the same command
  found by two rules is said on both; one error of a family goes through stage 1, the name from the fixed dictionary, cause, solution, test;
  the families that list nothing say why; a second run doubles nothing; a deleted item's errors leave the tree.

  FLOW 2, a model said to be connected (procedures.MODEL_CONNECTED gives True) while every call is answered by the stand-in, and the stand-in
  Coder hands out code written by hand for this test, as a model would write it from the rule's text (it reads the tree itself and never
  the reference implementation). Family 4's path is walked: research, requirements card, code card, run, the Tester's comparison with the
  reference implementation. One of the planted programs is wrong on purpose (it loses one row): the comparison says which row.

The fixture writes down what the application answers at each point; the tests read what was written down, so their order does not matter.
Also here: the checks that keep a Coder's code away from the reference implementation, whose rule a finding is said to be, the job that
ends at 100 per cent, and the constructed case for a command identifier used again. Everything is written under temporary folders.
"""
import csv
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

import pytest

os.environ.setdefault("F2T_WORKERS", "1")
APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for _p in (APP, os.path.join(APP, "app"), os.path.join(APP, "tests")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from agentic import core, family1, family3, pipeline, procedures as PR      # noqa: E402
from nvme_hier import builder as B, coded_findings as CF, command_error_rules as CE, loader as L, rules as RL, terms, tree_api as T   # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NODE = "/home/raghavendra/.nvm/versions/node/v22.23.2/bin/node"
LOWER = ["nvme_transaction", "split", "link", "packets"]
ITEM = lambda fid: "errors/nvme_command/" + CE.item_id(fid)      # noqa: E731
TIMEOUT = "errors/nvme_command/cmd_timeout"
NEVER, ABORT, ABORTED, NOTHING, CANNOT = ITEM("behaviour_01"), ITEM("behaviour_03"), ITEM("status_13"), ITEM("status_01"), ITEM("protocol_11")
FAMILIES_1 = [NEVER, ABORT, ABORTED, NOTHING, CANNOT]
NAME = {NEVER: "A command never completed", ABORT: "The host sent an Abort", ABORTED: "The command was aborted because the host asked",
        NOTHING: "A read could not be recovered", CANNOT: "A block range beyond the end of the namespace", TIMEOUT: "NVMe command timeout"}
# what S17 holds, read from the file itself by slow() below and from the detector's own findings: nothing here is taken from the code under test
ROWS = {NEVER: [155, 216, 295, 358, 443, 509], ABORT: [145, 216, 358, 501, 570], ABORTED: [144], NOTHING: [], CANNOT: []}
TIMEOUT_ROWS = [144, 155, 216, 295, 358, 443, 509]
RULE_SET = "the application's rule set for NVMe command level errors"
pytestmark = pytest.mark.skipif(not os.path.isdir(S17), reason="the S17 sample recording is not on this machine (the code-only zip carries no samples)")


class Yes:
    def random(self):
        return 0.0

    def choice(self, seq):
        return seq[0]

    def sample(self, seq, k):
        return list(seq)[:k]

    def randint(self, _a, b):
        return b


def slow():
    """The slow recomputation from the file itself: the rows of nvme_command.csv (row 1 = first under the header) that are an Abort command
    (admin queue, command code 08h), that completed with status type 0 and status code 07h / 08h / 1Bh, and that carry no status at all."""
    with open(os.path.join(S17, "nvme_command.csv"), newline="", encoding="utf-8-sig") as fh:
        rd = csv.reader(fh)
        head = next(rd)
        opc, sq, a, b = head.index("OPC"), head.index("SQID"), head.index("ST.SCT"), head.index("ST.SC")
        out = {"abort": [], "aborted": [], "no_status": [], "unrecovered": []}
        for n, row in enumerate(rd, 1):
            code = int(row[opc].split()[0], 16) if row[opc].strip() else None
            if row[sq].strip() == "0" and code == 8:
                out["abort"].append(n)
            if not row[a].strip() and not row[b].strip():
                out["no_status"].append(n)
            elif int(row[a]) == 0 and int(row[b]) in (7, 8, 0x1B):
                out["aborted"].append(n)
            elif int(row[a]) == 2 and int(row[b]) == 0x81:
                out["unrecovered"].append(n)
        return out


# ---------------------------------------------------------------------------------------------- the code a model would write, by hand
# Each program reads the tree itself (tree.rows, tree.findings) and writes the 13 output columns of the item's procedure. None of them
# imports or names the application's reference implementation: procedures.check_code refuses that.
PLANTED_HEAD = '''import csv
from nvme_hier import names

COLUMNS = %(columns)r
RULE = %(name)r


def num(cell):
    t = str(cell or "").strip()
    if not t:
        return None
    first = t.split()[0]
    try:
        return int(first, 16) if first.lower().startswith("0x") else int(first)
    except ValueError:
        return None


def line(row, reason, fault):
    opc, sqid = num(row.get("OPC")), num(row.get("SQID"))
    return [RULE, "nvme_command.csv", row.row, reason, fault, row.number, row.time_ps, "", row.row,
            names.opcode_name(opc, sqid) if opc is not None else "", sqid, num(row.get("CID")), ""]

'''
PLANTED_BODY = {
    # step by step as the procedure of "A command never completed" says: no status on the row, and the detector's rule judged the time
    "behaviour_01": '''
def run(tree, out_csv):
    never = set()
    for f in tree.findings(rule="cmd.timeout", level="nvme_command"):
        if " never completed" in str(f["name"]):
            never.add(f["row"])
    read = written = 0
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(COLUMNS)
        for row in tree.rows("nvme_command"):
            read += 1
            if num(row.get("ST.SCT")) is None and num(row.get("ST.SC")) is None and row.row in never:
                w.writerow(line(row, "The command has no completion in the recording.", "it cannot be told from this rule alone"))
                written += 1
    return {"rows_read": read, "rows_written": written, "total": None}
''',
    "status_13": '''
def run(tree, out_csv):
    read = written = 0
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(COLUMNS)
        for row in tree.rows("nvme_command"):
            read += 1
            if num(row.get("ST.SCT")) == 0 and num(row.get("ST.SC")) in (0x07, 0x08, 0x1B):
                w.writerow(line(row, "The command completed as aborted because the host asked.", "the trigger is the host's"))
                written += 1
    return {"rows_read": read, "rows_written": written, "total": None}
''',
    "status_01": '''
def run(tree, out_csv):
    read = written = 0
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(COLUMNS)
        for row in tree.rows("nvme_command"):
            read += 1
            if num(row.get("ST.SCT")) == 2 and num(row.get("ST.SC")) == 0x81:
                w.writerow(line(row, "The read could not be recovered.", "the controller"))
                written += 1
    return {"rows_read": read, "rows_written": written, "total": None}
''',
    # WRONG ON PURPOSE: the last Abort it finds is held back and never written (a program that writes each row one step late and forgets the end)
    "behaviour_03": '''
def run(tree, out_csv):
    read = written = 0
    held = None
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(COLUMNS)
        for row in tree.rows("nvme_command"):
            read += 1
            if num(row.get("SQID")) == 0 and num(row.get("OPC")) == 0x08:
                if held is not None:
                    w.writerow(held)
                    written += 1
                held = line(row, "The host sent an Abort.", "the host sent it")
    return {"rows_read": read, "rows_written": written, "total": None}
''',
}


def planted(fid):
    return PLANTED_HEAD % {"columns": [c for c, _m in CE.OUTPUT_COLUMNS], "name": CE.BY_ID[fid]["name"]} + PLANTED_BODY[fid]


FAMILIES_2 = [NEVER, ABORTED, NOTHING, ABORT]            # the second flow: three right programs and the wrong one


# ---------------------------------------------------------------------------------------------- helpers
def view_of(c, rid):
    return c.get("/api/agents/runs/%d" % rid).get_json()


def drive(c, rid, stop, chosen, on_card=None, limit=1500):
    """Approve the flow's cards the plain way until stop(step) is true -> (review, step, view). on_card(step, review, view) is called for
    every card before it is decided. Never goes on "with open points"."""
    import fuzz_deep as FD
    t0 = time.time()
    while time.time() - t0 < limit:
        v = view_of(c, rid)
        failed = [(s["key"], (s.get("error") or "")[-800:]) for s in v["steps"] if s["state"] == "failed"]
        assert not failed, failed
        if v["run"]["state"] != "running":
            return None, None, v
        rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
        if rv is None:
            time.sleep(0.2)
            continue
        st = next(s for s in v["steps"] if s["id"] == rv["step"])
        if stop(st):
            return rv, st, v
        if on_card:
            on_card(st, rv, v)
        if st["key"] == "f3_plan":
            edits = {"selected": list(chosen)}
        elif st["key"].endswith(":result"):
            edits = None
        else:
            edits = FD.edits_for(st["key"], rv.get("data") or {}, Yes())
        assert not (edits or {}).get("go_on_with_open_points")
        r = c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t", "edits": edits})
        if r.status_code != 200 and os.environ.get("F2T_DEBUG_DIR"):
            with open(os.path.join(os.environ["F2T_DEBUG_DIR"], "refused_card.json"), "w", encoding="utf-8") as fh:
                json.dump({"key": st["key"], "answer": r.get_json(), "review": rv, "edits": edits}, fh, indent=1, default=str)
        assert r.status_code == 200, (st["key"], r.get_json())
    raise AssertionError("the flow did not reach the point in %d s" % limit)


ROUTES = [("GET", ""), ("GET", "/window"), ("POST", "/chat"), ("POST", "/isolate"), ("POST", "/testcase"), ("POST", "/testcase/approve"),
          ("POST", "/signal"), ("POST", "/reorder"), ("POST", "/summary")]


def ask_routes(c, up, fid):
    out = {}
    for method, tail in ROUTES:
        r = c.open("/api/isolate/%s/%d%s" % (up, fid, tail), method=method, json=({} if method == "POST" else None))
        j = r.get_json(silent=True) or {}
        out["%s %s" % (method, tail or "/")] = (r.status_code, j.get("error") if isinstance(j, dict) else None)
    return out


def findings_of(db, like="admin.%"):
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        return con.execute("SELECT id, rule, level, rowid, row_n, cmd_rowid, name, detail, severity FROM finding WHERE rule LIKE ? ORDER BY id", (like,)).fetchall()
    finally:
        con.close()


def key_like(item):
    return "admin.%s.v%%" % item.replace("/", ".")


def page_of(view, tmp):
    """What the errors page's own script (app/static/js/agents.js) makes of a view, run by node: the lists, the "not listed yet" card, the card
    of the rules that listed nothing, the commands listed under more than one rule, and the notes under each error."""
    if not os.path.exists(NODE):
        return None
    with open(os.path.join(APP, "app", "static", "js", "agents.js"), encoding="utf-8") as fh:
        text = fh.read()
    part = text[text.index("function errorLists(v) {"):text.index("async function loadErrStatus(v) {")]
    part += "\nconst errHref = (pid, up, fid) => `/isolate?upload=${up}&finding=${fid}`;\n" + text[text.index("function sameCommand(ls) {"):text.index("function errCounts(st) {")]
    d = tempfile.mkdtemp(prefix="page_", dir=tmp)
    with open(os.path.join(d, "view.json"), "w", encoding="utf-8") as fh:
        json.dump(view, fh)
    with open(os.path.join(d, "h.cjs"), "w", encoding="utf-8") as fh:
        fh.write("const esc = s => String(s ?? '');\nconst plainDefects = (cols, head) => (head || []).map(x => ({ no: x[0], what: x[3], where: '', when: '', sev: x[4], level: x[1], row: x[8] }));\n"
                 + part + "\nconst v = JSON.parse(require('fs').readFileSync(process.argv[2], 'utf8'));\nconst ls = errorLists(v), same = sameCommand(ls);\n"
                 "console.log('RESULT ' + JSON.stringify({ lists: ls.map(s => ({ key: s.key, n: s.output.errors.length, findings: s.output.errors.map(e => e.finding),\n"
                 "  notes: s.output.errors.map(e => errNotes(e, s, same, 7)) })), waiting: errorsWaiting(v), nothing: errorsNothing(v),\n"
                 "  same: Object.fromEntries(Object.entries(same).map(([k, xs]) => [k, xs.map(x => x.pattern)])) }));\n")
    p = subprocess.run([NODE, os.path.join(d, "h.cjs"), os.path.join(d, "view.json")], capture_output=True, text=True, encoding="utf-8", timeout=60)
    line = next((ln for ln in p.stdout.splitlines() if ln.startswith("RESULT ")), None)
    assert line, (p.stdout[-500:], p.stderr[-1500:])
    return json.loads(line[7:])


class FakeStore:
    def __init__(self, state):
        self.state = state

    def one(self, sql, args=()):
        return {"state": self.state, "decided_by": "t"}


class FakeIc:
    """The errors step of one item, called by hand with a result (the step's context made by hand)."""

    def __init__(self, run_out, project, item, state="approved"):
        self.item, self.prefix, self.run, self.project = item, "f3:%s:" % item, {"id": 1}, project
        self.params = {"section": "errors", "level": "nvme_command", "id": item.split("/")[2].split("#")[0]}
        self.engine = type("E", (), {"store": FakeStore(state)})()
        self._out = run_out

    def output_of(self, key):
        return self._out if key == "run" else {}

    def progress(self, text):
        pass


def keys_of(view, item):
    return {s["key"].rsplit(":", 1)[1]: s for s in view["steps"] if s["key"].startswith("f3:%s:" % item)}


def step_of(view, key):
    return next(s for s in view["steps"] if s["key"] == key)


@pytest.fixture(scope="module")
def world():
    import fuzz_app as F
    from api import config_api, hier_api
    root = tempfile.mkdtemp(prefix="cmd_rules_flow_%d_" % os.getpid())
    kept = (core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK)
    uploads, hook, standin = PR._UPLOADS[0], PR.MODEL_CONNECTED, dict(PR.STANDIN_CODE)
    w = {"root": root}
    try:
        app, c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kept[0]
        family3._SECTIONS_SEEN[0] = None
        c.get("/api/agents/state")                              # the engine is made here: it sets the hook from its own runner (the stand-in: no model)
        w["hook_without_a_model"] = (callable(PR.MODEL_CONNECTED), PR.MODEL_CONNECTED() if callable(PR.MODEL_CONNECTED) else None)
        runner = app.config["services"].agentic_engine.runner
        calls, real = [], runner.ask
        runner.ask = lambda *a, **k: (calls.append(str(a[1] if len(a) > 1 else k.get("agent"))), real(*a, **k))[1]
        w["route_families"] = c.get("/api/hier/nvme_command_rules").get_json()

        # =========================================================================================== FLOW 1: no model connected
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "command rules", "folder": S17}).get_json()["id"]
        rid = c.post("/api/agents/projects/%d/flow" % pid, json={"admin": "t"}).get_json()["run"]
        chosen = [TIMEOUT] + FAMILIES_1
        # ---- the plan card, as the admin sees it
        rv, st, v = drive(c, rid, lambda s: s["key"] == "f3_plan", chosen)
        w["plan"] = {"body": rv["body"], "items": {i["key"]: i for i in rv["data"]["items"]}}
        # ---- point 1: the result of the built-in check waits
        rv, st, v = drive(c, rid, lambda s: s["key"] == "f3:%s:result" % TIMEOUT, chosen)
        up = step_of(v, "f3:%s:run" % TIMEOUT)["output"]["upload_id"]
        db = PR.source_paths(up)[PR.TREE]
        t_fid = step_of(v, "f3:%s:run" % TIMEOUT)["output"]["head"][0][0]
        w.update(upload=up, db=db, t_fid=t_fid)
        w["p1"] = {"view": v, "routes": ask_routes(c, up, t_fid), "page": page_of(v, root), "findings": findings_of(db), "all": len(findings_of(db, "%"))}
        assert c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t"}).status_code == 200

        # ---- point 2: every family's result card, each written down BEFORE it is approved
        project = {"upload_id": up, "admin": "t", "folder": S17}
        before, cards1 = {}, []

        def on_card(st, rv, v):
            cards1.append(st["key"])
            if not st["key"].endswith(":result"):
                return
            item = st["key"][3:-len(":result")]
            if item not in FAMILIES_1:
                return
            run_out = step_of(v, "f3:%s:run" % item)["output"]
            snap = {"view": v, "card": rv, "findings": findings_of(db, key_like(item)), "waiting": pipeline.waiting_patterns(v["steps"]), "page": page_of(v, root),
                    "errors_step": keys_of(v, item)["errors"], "run": run_out, "test": step_of(v, "f3:%s:test" % item)["output"]}
            early = pipeline._errors(FakeIc(run_out, project, item, state="needs_review"))        # the errors step called too early
            snap["early"] = {"output": early.output, "findings": findings_of(db, key_like(item))}
            if item == NEVER:
                # the page of one error of this rule while its result waits: such an error can only be there from an earlier analysis of this
                # recording, so one is filed by hand for the question and taken out again
                got = CF.file_findings(db, "errors", "nvme_command", CE.item_id("behaviour_01"), run_out["procedure_version"], NAME[NEVER], run_out["output_csv"])
                early_fid = findings_of(db, key_like(item))[0][0]
                snap["routes_while_waiting"] = ask_routes(c, up, early_fid)
                snap["filed_by_hand"] = got
                assert CF.remove(db, "errors", "nvme_command", CE.item_id("behaviour_01")) == got["total"]
            before[item] = snap
        rv, st, v = drive(c, rid, lambda s: s["key"] == "errors_done", chosen, on_card=on_card)
        w["before"], w["cards1"] = before, list(cards1)

        # ---- point 3: the errors gate: everything is listed
        w["p3"] = {"view": v, "gate": rv, "page": page_of(v, root), "findings": findings_of(db), "all": len(findings_of(db, "%")),
                   "errors": {i: keys_of(v, i)["errors"] for i in chosen}, "same": pipeline.same_command(v["steps"]), "calls": list(calls)}
        never = w["p3"]["errors"][NEVER]["output"]["errors"]
        fid = next(e["finding"] for e in never if e["row"] == 155)
        base = "/api/isolate/%s/%d" % (up, fid)
        p = w["p3"]
        p["fid"], p["routes"], p["header"] = fid, ask_routes(c, up, fid), c.get(base).get_json()
        iso = c.post(base + "/isolate", json={"n": 15, "m": 15, "levels": LOWER, "history": True, "anyway": True, "isolation": True, "name": "t", "standin": True}).get_json()
        p["iso"] = iso
        i = iso["isolation"]
        status = lambda: c.get("/api/dg/status?upload=%s&findings=%d" % (up, fid)).get_json()["status"][str(fid)]     # noqa: E731
        p["status_new"] = status()
        d = c.post("/api/dg/defects", json={"name": i["term"]["name"], "term_key": i["term"]["key"], "rule": i["rule"], "level": i["level"], "what": i["what"], "admin": "t"}).get_json()
        c.post("/api/dg/occurrences", json={"defect_id": d["id"], "cause_id": None, "upload_id": up, "finding_id": fid, "device": i.get("device"), "admin": "t"})
        p["defect"], p["status_isolated"] = c.get("/api/dg/defects/%d" % d["id"]).get_json(), status()
        cz = c.post("/api/dg/causes", json={"defect_id": d["id"], "keyword": "firmware_stall", "admin": "t"}).get_json()
        c.post("/api/dg/occurrences", json={"defect_id": d["id"], "cause_id": cz["id"], "upload_id": up, "finding_id": fid, "admin": "t"})
        p["cause"], p["status_cause"] = cz, status()
        sol = c.post("/api/dg/solutions", json={"cause_id": cz["id"], "error_seq": iso["sequence"], "optimized": ["update the drive's firmware and send the Write again"],
                                                "admin": "t", "upload_id": up, "finding_id": fid}).get_json()
        p["solution"], p["status_solved"] = sol, status()
        ex = c.post(base + "/testcase", json={"sequence": iso["sequence"], "expected_after": 3, "name": "t", "standin": True}).get_json()
        f = c.post(base + "/testcase", json={"sequence": ex["sequence"], "expected_outcomes": [dict(x, verified=True) for x in ex.get("expected_outcomes") or []],
                                             "verified": True, "name": "t", "standin": True}).get_json()
        p["expected"], p["testfile"] = ex, f
        p["test_exists"] = bool(f.get("path")) and os.path.exists(f["path"])
        if f.get("path"):
            p["approved"] = c.post(base + "/testcase/approve", json={"path": f["path"], "name": "t", "revision_id": sol.get("revision_id")}).get_json()
        p["status_tested"] = status()

        # ---- run again: the errors step of the same item with the same result
        run_out = step_of(v, "f3:%s:run" % NEVER)["output"]
        again = pipeline._errors(FakeIc(run_out, project, NEVER))
        w["again"] = {"output": again.output, "findings": findings_of(db), "all": len(findings_of(db, "%"))}

        # ---- the item is deleted: its errors leave the tree at the next sweep; the others stay
        w["before_delete"] = findings_of(db)
        family3.delete_item("errors", "nvme_command", CE.item_id("behaviour_01"), "t", "the test deletes it")
        w["swept"] = pipeline.remove_deleted_items_errors(db)
        w["after_delete"] = findings_of(db)
        w["route_after_delete"] = c.get(base).status_code
        family3.restore_item("errors", "nvme_command", CE.item_id("behaviour_01"), "t")

        # ---- the end of flow 1
        assert c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t"}).status_code == 200
        _rv, _st, v = drive(c, rid, lambda s: False, chosen)
        w["end1"] = {"state": v["run"]["state"], "view": v, "calls": list(calls)}

        # =========================================================================================== FLOW 2: a model said to be connected
        PR.MODEL_CONNECTED = lambda: True
        for item in FAMILIES_2:
            fam = item.split("/")[2][len(CE.ITEM_PREFIX):]
            PR.STANDIN_CODE[CE.item_id(fam)] = planted(fam)             # what the stand-in Coder hands out: the test's own programs
        del calls[:]
        pid2 = c.post("/api/agents/projects", json={"admin": "t", "name": "command rules, coded", "folder": S17}).get_json()["id"]
        rid2 = c.post("/api/agents/projects/%d/flow" % pid2, json={"admin": "t"}).get_json()["run"]
        cards, before2 = [], {}

        def on_card2(st, rv, v):
            cards.append(st["key"])
            if st["key"].endswith(":result") and st["key"][3:-len(":result")] in FAMILIES_2:
                item = st["key"][3:-len(":result")]
                before2[item] = {"card": rv, "run": step_of(v, "f3:%s:run" % item)["output"], "test": step_of(v, "f3:%s:test" % item)["output"],
                                 "code_state": PR.code_state(family3.load_rule(*item.split("/"))), "steps": keys_of(v, item)}
        rv, st, v = drive(c, rid2, lambda s: s["key"] == "errors_done", FAMILIES_2, on_card=on_card2)
        up2 = step_of(v, "f3:%s:run" % NEVER)["output"]["upload_id"]
        db2 = PR.source_paths(up2)[PR.TREE]
        w["f2"] = {"view": v, "gate": rv, "cards": list(cards), "before": before2, "calls": list(calls), "upload": up2, "db": db2,
                   "findings": findings_of(db2), "errors": {i: keys_of(v, i)["errors"] for i in FAMILIES_2}, "plan_items": None}
        with open(before2[NEVER]["run"]["code_file"], encoding="utf-8") as fh:
            w["f2"]["code"] = fh.read()
        assert c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t"}).status_code == 200
        _rv, _st, v = drive(c, rid2, lambda s: False, FAMILIES_2)
        w["end2"] = {"state": v["run"]["state"], "view": v}
        yield w
    finally:
        core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK = kept
        PR.use_uploads_folder(uploads)
        PR.MODEL_CONNECTED = hook
        PR.STANDIN_CODE.clear()
        PR.STANDIN_CODE.update(standin)
        family3._SECTIONS_SEEN[0] = None
        shutil.rmtree(root, ignore_errors=True)


def detail_of(f):
    return json.loads(f[7])


def sentence_rows(sentence):
    """(first row, last row) of "Episode n of the recording (command rows a to b): ..."."""
    part = sentence.split("(command rows ", 1)[1].split(")", 1)[0]
    a, b = part.split(" to ")
    return int(a), int(b)


# ============================================================================================== FLOW 1: no model connected
def test_the_sample_holds_these_rows_counted_from_the_file_itself():
    got = slow()
    assert got["abort"] == ROWS[ABORT] and got["aborted"] == ROWS[ABORTED] and got["unrecovered"] == ROWS[NOTHING] == []
    assert set(ROWS[NEVER]) <= set(got["no_status"]) and ROWS[CANNOT] == []


def test_the_engine_sets_the_hook_and_without_a_model_it_says_no(world):
    assert world["hook_without_a_model"] == (True, False)          # set where the engine is made; the stand-in is no model


def test_the_route_of_the_rules_page_sends_the_families(world):
    from nvme_hier import nvme_command_rules as NR
    got = world["route_families"]
    assert got["families"] == json.loads(json.dumps(NR.families())) and len(got["families"]["families"]) == len(CE.FAMILIES)
    assert [g["name"] for g in got["families"]["groups"]] == [CE.STATUS, CE.BEHAVIOUR, CE.PROTOCOL] and got["rules"] and got["groups"]
    js = open(os.path.join(APP, "app", "static", "js", "nvme_command_rules.js"), encoding="utf-8").read()
    assert "loadFamilies(state.cat.families)" in js and "/static/nvme_command_families.json" in js        # the route first, the file only when the route sends none


def test_nothing_is_chosen_in_advance_and_the_cost_is_said_where_the_rules_are_chosen(world):
    from agentic import rule_hierarchy as RH
    items = world["plan"]["items"]
    mine = [i for k, i in items.items() if k.split("/")[2].startswith(CE.ITEM_PREFIX)]
    assert len(mine) == len(CE.items()) == 38 and not any(i["selected"] for i in mine)
    assert sorted(k for k, i in items.items() if i["selected"] and i["section"] == "errors") == sorted([TIMEOUT, "errors/nvme_command/cmd_read_failure"])
    body = world["plan"]["body"]
    assert "**The 38 rules of the NVMe command level** (Errors, NVMe commands; none is chosen in advance). No model is connected now: each of them you tick runs the " \
           "application's reference implementation, with no call to a model. " + CE.COST_WORDS in body
    # the rules library shows a group's meaning when the group is open: the sentence is in that data, after the group's own first sentence
    stated = RH.stated_groups("errors", "nvme_command")
    assert [n for n, _a in stated] == [CE.STATUS, CE.BEHAVIOUR, CE.PROTOCOL]
    for (name, text), (_n, base) in zip(stated, CE.GROUP_MEANINGS):
        first, rest = RH._sentences(text)
        assert text == base + " " + CE.COST_WORDS and first == RH._sentences(base)[0] and CE.COST_WORDS in rest
    assert "adds 8 steps to page 3" in CE.COST_WORDS and "you decide 1 card (the result)" in CE.COST_WORDS and "at least 10 calls to the model" in CE.COST_WORDS \
        and "3 cards for you to decide (the requirements, the code, the result)" in CE.COST_WORDS


def test_before_the_result_of_the_builtin_check_is_approved_its_error_page_refuses(world):
    p = world["p1"]
    assert p["findings"] == []
    for route, (code, err) in p["routes"].items():
        assert code == 409 and err.startswith("The result of 'NVMe command timeout' waits for your decision on page 3 of the analysis") and err.endswith("after you approve that result."), (route, code, err)
    if p["page"] is not None:
        assert p["page"]["lists"] == [] and "waits for your decision on page 3: its errors are listed here after you approve it." in p["page"]["waiting"]


@pytest.mark.parametrize("item", FAMILIES_1)
def test_before_a_familys_result_is_approved_nothing_of_it_is_an_error(world, item):
    b = world["before"][item]
    assert b["findings"] == []                                   # nothing in the tree's finding table yet
    assert b["errors_step"]["state"] == "waiting" and not b["errors_step"].get("output")
    waits = {x["item"]: x for x in b["waiting"]}
    assert waits[item]["state"] == "waits" and waits[item]["sentence"] == "The result of '%s' waits for your decision on page 3: its errors are listed here after you approve it." % NAME[item]
    # the errors step itself, called too early, files nothing and says the same
    assert b["early"]["output"]["errors"] == [] and b["early"]["findings"] == []
    assert b["early"]["output"]["refused"] == "The result of the rule '%s' waits for your decision on page 3: its errors are listed here after you approve it." % NAME[item]
    if b["page"] is not None:
        assert "f3:%s:errors" % item not in [x["key"] for x in b["page"]["lists"]]
        assert "The result of %s waits for your decision on page 3: its errors are listed here after you approve it." % NAME[item] in b["page"]["waiting"]
    # a family later in the plan has not reached its result: it is said so, and it is not listed either
    later = FAMILIES_1[FAMILIES_1.index(item) + 1:]
    assert [waits[x]["state"] for x in later] == ["not yet"] * len(later)


def test_the_page_of_one_error_of_a_family_refuses_while_the_familys_result_waits(world):
    b = world["before"][NEVER]
    assert b["filed_by_hand"]["total"] == 6
    want = ("The result of 'A command never completed' waits for your decision on page 3 of the analysis “command rules”: this error can be opened and worked on "
            "(stage 1, stage 2 and its test) after you approve that result.")
    assert len(b["routes_while_waiting"]) == 9
    for route, (code, err) in b["routes_while_waiting"].items():
        assert (code, err) == (409, want), (route, code, err)


def test_the_result_card_of_a_family_says_whose_rule_it_is_and_what_approval_does(world):
    body = world["before"][NEVER]["card"]["body"]
    assert "**Tester:** all checks passed" in body
    assert "Approve to accept it and file the 6 rows it found as errors of this recording (nvme_command.csv)" in body and "Nothing is listed before you approve." in body
    assert ("the part \"matched the rule 'A command never completed'\" comes from the rule *A command never completed* of the application's rule set for NVMe command "
            "level errors, which you chose for this recording") in body and "No model names it." in body
    assert "your own rule" not in body and "the admin's rule" not in body                     # it is not a rule the admin wrote, and the card does not say so
    assert "The code of this item is part of the application (nvme_hier/command_error_rules.py): no model was asked and no Coder wrote it." in body
    # the Tester's line on the reference implementation says what it shows here: the same code ran twice
    assert "the same 6 rows (the application's own code ran both times: this shows the result file is whole, not that a second program agrees)" in body
    assert body.count("the rows found are the rows the application's reference implementation of this rule finds on the whole recording") == 1
    assert world["before"][NEVER]["test"]["passed"] is True


def test_the_result_card_says_which_rows_another_rule_already_lists(world):
    b = world["before"]
    assert ("**The same command, found twice:** 6 of these rows are a command that this analysis already lists as an error under 'NVMe command timeout' "
            "(rows 155, 216, 295, 358, 443, 509 of nvme_command.csv).") in b[NEVER]["card"]["body"]
    assert ("**The same command, found twice:** 2 of these rows are a command that this analysis already lists as an error under 'NVMe command timeout' and "
            "'A command never completed' (rows 216, 358 of nvme_command.csv).") in b[ABORT]["card"]["body"]
    assert ("**The same command, found twice:** 1 of these rows is a command that this analysis already lists as an error under 'NVMe command timeout' "
            "(row 144 of nvme_command.csv).") in b[ABORTED]["card"]["body"]
    for item in (NEVER, ABORT, ABORTED):
        assert "the errors page says on each of the two that it is the same command and links the other, so that you do not isolate it twice without knowing." in b[item]["card"]["body"]
    assert "found twice" not in b[NOTHING]["card"]["body"] and "found twice" not in b[CANNOT]["card"]["body"]


@pytest.mark.parametrize("item", [NEVER, ABORT, ABORTED])
def test_after_the_approval_the_rows_are_findings_of_the_tree_with_their_numbers(world, item):
    p = world["p3"]
    rid = item.split("/")[2]
    mine = [f for f in p["findings"] if f[1] == "admin.errors.nvme_command.%s.v1" % rid]
    assert [f[3] for f in mine] == ROWS[item]                                   # exactly the rows of the sample, one finding each
    assert CF.item_of(mine[0][1]) == ("errors", "nvme_command", rid, 1)
    detector_top = world["p1"]["all"]
    for fid, rule, level, rowid, row_n, cmd_rowid, name, detail, severity in mine:
        assert fid > detector_top and (level, cmd_rowid, severity) == ("nvme_command", rowid, "error")
        assert name == "%s (found by a rule of the application's rule set for NVMe command level errors)" % NAME[item]
        d = json.loads(detail)
        assert d["kind"] == "matched the rule '%s'" % NAME[item]
        a = d["admin_rule"]
        assert a["origin"] == "application" and a["kind_comes_from"] == RULE_SET and a["approved_by"] == "t" and a["item"] == item and a["procedure_version"] == 1
        assert a["words"] == ("Found by the rule '%s' of the application's rule set for NVMe command level errors (version 1 of its procedure; the rows were found by "
                              "the application's reference implementation of the rule, no model wrote its code)." % NAME[item])
        assert a["short"] == "the rule “%s” of the application's rule set for NVMe command level errors" % NAME[item] and "your own rule" not in a["kind_from"]
        assert d["reason"] and d["linked"].startswith("Episode ")
    eo = p["errors"][item]
    o = eo["output"]
    assert eo["state"] == "done" and o["kind"] == pipeline.CODED_KIND and o["found_by"] == "application" and o["total"] == len(ROWS[item]) and not o.get("refused")
    assert o["rule"] == mine[0][1] and o["filed"] == {"kept": 0, "added": len(ROWS[item]), "removed": 0, "without_a_command": 0}
    assert [(e["finding"], e["level"], e["row"], e["serious"]) for e in o["errors"]] == [(f[0], "nvme_command", f[3], "error") for f in mine]
    for e, f in zip(o["errors"], mine):
        assert e["where"].startswith("row %d of nvme_command.csv" % f[3]) and e["what"] == json.loads(f[7])["reason"] and e["rule_words"] == f[6]
    assert o["kind_words"] == "matched the rule '%s'" % NAME[item] and "application's rule set" in o["kind_from"] and "your own rule" not in o["kind_from"]
    if p["page"] is not None:
        assert next(x for x in p["page"]["lists"] if x["key"] == "f3:%s:errors" % item)["findings"] == [f[0] for f in mine]


def test_the_gate_and_the_page_list_every_pattern_that_found_errors(world):
    p = world["p3"]
    assert p["gate"]["data"]["errors_overview"] and "4 patterns found 19 errors in this recording" in p["gate"]["body"] and "Not listed yet" not in p["gate"]["body"]
    assert [e["row"] for e in p["errors"][TIMEOUT]["output"]["errors"]] == TIMEOUT_ROWS and "kind" not in p["errors"][TIMEOUT]["output"]      # the detector's list, as before
    assert len(p["findings"]) == 12 and p["all"] == world["p1"]["all"] + 12
    if p["page"] is not None:
        assert sorted(x["key"] for x in p["page"]["lists"]) == sorted("f3:%s:errors" % i for i in (TIMEOUT, NEVER, ABORT, ABORTED)) and p["page"]["waiting"] == ""
    for route, (code, _err) in p["routes"].items():
        assert code != 409, (route, code)


def test_every_error_carries_the_sentence_of_its_episode(world):
    p = world["p3"]
    by_sentence = {}
    for item in (NEVER, ABORT, ABORTED):
        for e in p["errors"][item]["output"]["errors"]:
            assert e["linked"].startswith("Episode ") and " of the recording (command rows " in e["linked"], e
            a, b = sentence_rows(e["linked"])
            assert a <= e["row"] <= b, (e["row"], e["linked"])                      # the error's own row lies in the stretch its sentence names
            by_sentence.setdefault(e["linked"], set()).add(e["row"])
    assert len(by_sentence) == 3                                                    # three episodes on S17
    assert sorted(len(v) for v in by_sentence.values()) == [2, 4, 4] and sum(len(v) for v in by_sentence.values()) == 10      # 12 errors on 10 different rows
    two = next(s for s, rows in by_sentence.items() if 155 in rows)
    assert by_sentence[two] == {144, 145, 155, 216} and "2 commands never completed (rows 155, 216 of the NVMe command file)" in two \
        and "the host sent 2 Abort commands (rows 145, 216)" in two and "1 command was completed as aborted (row 144)" in two
    assert all("linked" not in e for e in p["errors"][TIMEOUT]["output"]["errors"])          # the detector's own list says none
    if p["page"] is not None:                                                        # the page shows it under "what was found" of each of these errors
        for item in (NEVER, ABORT, ABORTED):
            lst = next(x for x in p["page"]["lists"] if x["key"] == "f3:%s:errors" % item)
            for e, note in zip(p["errors"][item]["output"]["errors"], lst["notes"]):
                assert "<b>Belongs together:</b> " + e["linked"] in note


def test_the_same_command_under_two_rules_is_said_on_both_and_linked_by_its_row(world):
    p = world["p3"]
    same = {g["row"]: g for g in p["same"]}
    assert sorted(same) == TIMEOUT_ROWS and all(g["level"] == "nvme_command" for g in p["same"])
    assert [x["pattern"] for x in same[144]["listed"]] == [NAME[TIMEOUT], NAME[ABORTED]]
    assert [x["pattern"] for x in same[155]["listed"]] == [NAME[TIMEOUT], NAME[NEVER]]
    assert [x["pattern"] for x in same[216]["listed"]] == [NAME[TIMEOUT], NAME[NEVER], NAME[ABORT]] == [x["pattern"] for x in same[358]["listed"]]
    for g in p["same"]:                 # the two (or three) errors of one row are different findings: each keeps its own number and its own page
        ids = [x["finding"] for x in g["listed"]]
        assert len(set(ids)) == len(ids) and g["where"] == "row %d of nvme_command.csv" % g["row"]
    body = p["gate"]["body"]
    assert "**The same command under more than one rule:** 7 rows are listed as an error by more than one of the rules you chose." in body
    assert "- row 144 of nvme_command.csv: 'NVMe command timeout' and 'The command was aborted because the host asked'" in body
    assert "- row 216 of nvme_command.csv: 'NVMe command timeout', 'A command never completed' and 'The host sent an Abort'" in body
    assert p["gate"]["data"]["same_command"] == p["same"]
    if p["page"] is None:
        return
    assert sorted(p["page"]["same"]) == sorted("nvme_command|%d" % r for r in TIMEOUT_ROWS)
    lists = {x["key"][3:-len(":errors")]: x for x in p["page"]["lists"]}
    fid = {(item, e["row"]): e["finding"] for item in (TIMEOUT, NEVER, ABORT, ABORTED) for e in p["errors"][item]["output"]["errors"]}
    for item in (TIMEOUT, NEVER, ABORT, ABORTED):
        for e, note in zip(p["errors"][item]["output"]["errors"], lists[item]["notes"]):
            others = [x for x in (same.get(e["row"]) or {"listed": []})["listed"] if x["item"] != item]
            if not others:
                assert "The same command is also listed under" not in note, (item, e["row"])      # rows 145, 501 and 570: one rule only
                continue
            assert "<b>The same command is also listed under</b>" in note and "one command, found by more than one rule" in note
            for x in others:            # both directions: the built-in check's error names the family's, and the family's names the built-in check's
                assert "finding=%d\">%s</a>" % (fid[(x["item"], e["row"])], x["pattern"]) in note, (item, e["row"], note)
    assert {e["row"] for e in p["errors"][ABORT]["output"]["errors"]} - set(same) == {145, 501, 570}


def test_an_error_of_a_family_goes_through_stage_1_and_the_fixed_dictionary_names_it(world):
    p = world["p3"]
    h = p["header"]["finding"]
    assert h["level"] == "nvme_command" and h["command"]["rowid"] == 155 and h["rule"] == "admin.errors.nvme_command.%s.v1" % CE.item_id("behaviour_01")
    a = h["admin_rule"]                 # the page's header says whose rule it is, in the words kept with the finding
    assert a["kind_words"] == "matched the rule 'A command never completed'" and a["whose"] == RULE_SET and a["origin"] == "application"
    assert "your own rule" not in a["kind_from"] and "of the application's rule set for NVMe command level errors, which you chose for this recording" in a["kind_from"]
    assert a["short"] == "the rule “A command never completed” of the application's rule set for NVMe command level errors"
    assert a["words"].startswith("Found by the rule 'A command never completed' of the application's rule set for NVMe command level errors")
    iso = p["iso"]
    i = iso["isolation"]
    assert set("what why when where who which how".split()) <= set(i) and iso["window"]["n"] == 15 and iso["sequence"]
    assert str(i.get("producer") or "").startswith("stand-in")
    term = i["term"]
    want = terms.defect_term(dict(h, detail={"kind": "matched the rule 'A command never completed'"}))
    assert term["key"] == want["key"] and term["name"] == want["name"] == "Write matched the rule 'A command never completed'"
    assert term["key"] == "admin.errors.nvme_command.cmd_family_behaviour_01.v1|io.write|matched_the_rule_a_command_never_completed"
    assert term["slots"]["what"] == "matched the rule 'A command never completed'"
    assert p["status_new"]["state"] == "new" and p["status_isolated"]["state"] == "isolated" and p["defect"]["name"] == term["name"]


def test_then_cause_solution_and_test_and_the_status_follows(world):
    p = world["p3"]
    assert p["cause"]["id"] and p["status_cause"]["state"] == "cause" and p["status_cause"]["cause"] == "the drive's firmware stopped making progress"
    assert p["solution"]["solution"]["judged_words"] == "not yet judged" and p["status_solved"]["state"] == "solved"
    assert p["expected"]["sequence"] and p["test_exists"], p["testfile"]
    assert "simulated" in json.dumps(p["testfile"])              # the written file was tried on the simulated drive, and the answer says so
    assert p["approved"]["ok"] and p["status_tested"]["state"] == "tested"
    assert [p[k]["state"] for k in ("status_new", "status_isolated", "status_cause", "status_solved", "status_tested")] == ["new", "isolated", "cause", "solved", "tested"]


def test_a_family_that_finds_nothing_or_cannot_be_checked_says_so_in_a_sentence(world):
    p, b = world["p3"], world["before"]
    nothing = ("The rule 'A read could not be recovered' found no row in this recording (608 rows read): there is no error to list and nothing to isolate. "
               "An empty list is a result, not a failure.")
    cannot = ("The rule 'A block range beyond the end of the namespace' cannot be checked on this recording: no Identify command of the recording carries the size "
              "of a namespace (column NSZE). No error is listed for it; that is what this recording allows, not a failure of the rule.")
    for item, words in ((NOTHING, nothing), (CANNOT, cannot)):
        assert b[item]["test"]["passed"] is True, [c for c in b[item]["test"]["checks"] if not c["ok"]]          # an empty list is a result, never a failure
        assert b[item]["run"]["rows"] == 0 and ("Approve to accept it. " + words) in b[item]["card"]["body"]
        eo = p["errors"][item]
        assert eo["state"] == "skipped" and eo["output"]["errors"] == [] and eo["output"]["total"] == 0 and eo["output"]["nothing"] == words and not eo["output"].get("refused")
        assert ("- " + words) in p["gate"]["body"]
        if p["page"] is not None:
            assert words in p["page"]["nothing"] and "<h2>Rules that listed no error</h2>" in p["page"]["nothing"]
    assert "**Rules that listed no error:**" in p["gate"]["body"] and p["gate"]["data"]["listed_nothing"] == [nothing, cannot]
    assert "In plain words:** The rule 'A block range beyond the end of the namespace' cannot be checked on this recording: no Identify command" in b[CANNOT]["card"]["body"]
    assert [f for f in p["findings"] if "status_01" in f[1] or "protocol_11" in f[1]] == []


def test_running_a_family_again_does_not_double_its_errors(world):
    before, again = world["p3"]["findings"], world["again"]
    assert again["findings"] == before and again["all"] == world["p3"]["all"]
    assert again["output"]["filed"] == {"kept": 6, "added": 0, "removed": 0, "without_a_command": 0} and again["output"]["total"] == 6
    assert [x["finding"] for x in again["output"]["errors"]] == [f[0] for f in before if "behaviour_01" in f[1]]


def test_a_deleted_familys_errors_leave_the_tree_and_the_others_stay(world):
    assert len(world["before_delete"]) == 12 and world["swept"] == 6
    assert sorted(f[3] for f in world["after_delete"]) == sorted(ROWS[ABORT] + ROWS[ABORTED]) and not [f for f in world["after_delete"] if "behaviour_01" in f[1]]
    assert world["route_after_delete"] == 404                      # the error is gone: its page says "no such finding"


def test_flow_1_finishes_and_no_model_and_no_stand_in_agent_was_asked_for_a_family(world):
    v = world["end1"]["view"]
    assert world["end1"]["state"] == "finished"
    sentence = "this item runs code that is part of the application (nvme_hier/command_error_rules.py): there is nothing to research, to ask or to code"
    for item in FAMILIES_1:
        st = keys_of(v, item)
        assert list(st) == ["research", "req", "code", "run", "test", "export", "result", "errors"] and len(st) == CE.STEPS_PER_RULE
        for sub in ("research", "req", "code"):
            assert st[sub]["state"] == "skipped" and (st[sub].get("note") or "").startswith(sentence), (item, sub, st[sub]["state"], st[sub].get("note"))
        assert [k for k in world["cards1"] if k.startswith("f3:%s:" % item)] == ["f3:%s:result" % item]            # one card for the admin: the result
    assert CE.CARDS_WITHOUT_A_MODEL == 1 and not [a for a in world["end1"]["calls"] if CE.ITEM_PREFIX in a]


# ============================================================================================== FLOW 2: a model said to be connected
def calls_per_family(calls):
    """The calls of flow 2 by family: a call that names the family's item, and the questions to Family 1's Managers (named by the file) that
    follow its requirements call. -> {item id: {"research", "requirements", "family 1", "coder", "second", "tester", "all"}}."""
    out, cur = {}, None
    for a in calls:
        fam = next((CE.item_id(i.split("/")[2][len(CE.ITEM_PREFIX):]) for i in FAMILIES_2 if a.endswith(i.split("/")[2]) or (i.split("/")[2] + "_") in a), None)
        if fam:
            cur = fam
        if cur is None:
            continue
        kind = ("research" if a.startswith("f4_research_") else "requirements" if a.startswith("f4_requirements_") else "family 1" if a.startswith("f4_asks_") else
                "coder" if a.startswith("f4_coder_") else "second" if a.startswith("f4_second_") else "tester" if a.startswith("f4_tester_") else "other")
        d = out.setdefault(cur, {})
        d[kind] = d.get(kind, 0) + 1
        d["all"] = d.get("all", 0) + 1
    return out


@pytest.mark.parametrize("item", FAMILIES_2)
def test_with_a_model_family_4_researches_asks_and_codes_and_the_admin_decides_three_cards(world, item):
    f2 = world["f2"]
    b = f2["before"][item]
    st = b["steps"]
    assert list(st) == ["research", "req", "code", "run", "test", "export", "result", "errors"]
    assert (st["research"]["state"], st["req"]["state"], st["code"]["state"], st["run"]["state"]) == ("done", "approved", "approved", "done")
    assert [k.rsplit(":", 1)[1] for k in f2["cards"] if k.startswith("f3:%s:" % item)] == ["req", "code", "result"]
    cs = b["code_state"]
    assert cs["kind"] == "python" and cs["verified"] is True and cs["verified_by"] == "t" and not cs.get("application") and b["run"]["code_file"] == cs["path"]
    assert st["code"]["output"]["kind"] == "python" and b["run"]["kind"] == "python"
    assert world["f2"]["upload"] == world["upload"]


def test_the_code_the_coder_handed_in_never_reaches_the_reference_implementation(world):
    code = world["f2"]["code"]
    assert code == planted("behaviour_01") and "command_error_rules" not in code and PR.check_code(code, tree=True) == []
    for fid in PLANTED_BODY:
        assert PR.check_code(planted(fid), tree=True) == [], fid


@pytest.mark.parametrize("item,same", [(NEVER, "the same 6 rows"), (ABORTED, "the same 1 row"), (NOTHING, "the same 0 rows")])
def test_the_tester_compares_the_coders_rows_with_the_reference_and_they_agree(world, item, same):
    b = world["f2"]["before"][item]
    lines = [c for c in b["test"]["checks"] if "reference implementation" in c["check"]]
    assert len(lines) == 1 and lines[0]["ok"] is True and lines[0]["detail"] == same            # a real comparison: two programs, one answer
    assert lines[0]["check"] == "the rows found are the rows the application's reference implementation of this rule finds on the whole recording"
    assert b["test"]["passed"] is True, [c for c in b["test"]["checks"] if not c["ok"]]
    assert "- ✔ the rows found are the rows the application's reference implementation of this rule finds on the whole recording: " + same in b["card"]["body"]
    assert b["run"]["rows"] == len(ROWS[item])
    with_rows = [c for c in b["test"]["checks"] if c["check"].startswith("the code wrote rows")]
    if item == NOTHING:                 # a model's code that finds nothing: an empty list is a result for a rule that finds errors
        assert with_rows[0]["ok"] is True and with_rows[0]["check"] == "the code wrote rows, or found none (an empty list is a result for a rule that finds errors)"
        assert with_rows[0]["detail"].startswith("0 rows: this rule found no row in this recording. For a rule that finds errors an empty list is a result, not a failure")
        assert ("Approve to accept it. The rule 'A read could not be recovered' found no row in this recording: there is no error to list and nothing to isolate. "
                "An empty list is a result, not a failure.") in b["card"]["body"]
    else:
        assert with_rows[0]["ok"] is True and with_rows[0]["check"] == "the code wrote rows"


def test_a_wrong_program_is_caught_by_the_comparison_in_words(world):
    b = world["f2"]["before"][ABORT]
    lines = [c for c in b["test"]["checks"] if "reference implementation" in c["check"]]
    assert len(lines) == 1 and lines[0]["ok"] is False and lines[0]["detail"] == "only the reference implementation found row 570"
    assert b["test"]["passed"] is False and b["run"]["rows"] == 4
    body = b["card"]["body"]
    assert "**Tester:** SOME CHECKS FAILED" in body
    assert "- ✘ the rows found are the rows the application's reference implementation of this rule finds on the whole recording: only the reference implementation found row 570" in body
    assert ("**The code and the application's reference implementation of this rule do not find the same rows:** only the reference implementation found row 570. "
            "Approving files the rows of the code as they are. To have the code corrected first, choose Change and say which rows are missing or too many.") in body


def test_the_errors_of_a_coded_family_are_filed_the_same_way_and_say_family_4_wrote_the_code(world):
    f2 = world["f2"]
    o = f2["errors"][NEVER]["output"]
    assert f2["errors"][NEVER]["state"] == "done" and o["total"] == 6 and [e["row"] for e in o["errors"]] == ROWS[NEVER] and o["found_by"] == "application"
    assert o["filed"] == {"kept": 0, "added": 6, "removed": 0, "without_a_command": 0}          # flow 1's were taken out with the deleted item
    mine = [f for f in f2["findings"] if "behaviour_01" in f[1]]
    assert [f[3] for f in mine] == ROWS[NEVER]
    for f in mine:
        d = json.loads(f[7])
        assert d["kind"] == "matched the rule 'A command never completed'" and d["admin_rule"]["origin"] == "application"
        assert d["admin_rule"]["words"] == ("Found by the rule 'A command never completed' of the application's rule set for NVMe command level errors (version 1 of its "
                                            "procedure; the rows were found by code that Family 4 wrote from the rule's text and the admin approved).")
        assert d["reason"] == "The command has no completion in the recording." and "linked" not in d       # what this program wrote for the row, and it wrote no episode
    # the same error of flow 1 is found again by another program: it keeps its number (nothing is doubled across two analyses of one recording)
    one = f2["errors"][ABORTED]["output"]
    assert one["filed"] == {"kept": 1, "added": 0, "removed": 0, "without_a_command": 0}
    assert [e["finding"] for e in one["errors"]] == [f[0] for f in world["after_delete"] if "status_13" in f[1]]
    # the wrong program's result was approved as it was: the row it lost is no longer listed (the card said so before the approval)
    lost = f2["errors"][ABORT]["output"]
    assert lost["filed"] == {"kept": 4, "added": 0, "removed": 1, "without_a_command": 0} and [e["row"] for e in lost["errors"]] == [145, 216, 358, 501]
    assert f2["errors"][NOTHING]["state"] == "skipped" and f2["errors"][NOTHING]["output"]["nothing"].startswith("The rule 'A read could not be recovered' found no row in this recording:")
    assert world["end2"]["state"] == "finished"


def test_what_one_chosen_family_costs_is_what_the_screen_says(world):
    per = calls_per_family(world["f2"]["calls"])
    print("\ncalls to the model (answered by the stand-in) for one chosen family, flow 2 on S17: %s" % json.dumps(per, sort_keys=True))
    assert set(per) == {CE.item_id(i.split("/")[2][len(CE.ITEM_PREFIX):]) for i in FAMILIES_2}
    for fam, d in per.items():
        assert (d["requirements"], d["family 1"], d["coder"], d["second"], d["tester"]) == (1, 5, 1, 1, 1) and d["research"] in (1, 2) and "other" not in d, (fam, d)
        assert d["all"] == d["research"] + 9
    assert min(d["all"] for d in per.values()) == CE.CALLS_WITH_A_MODEL == 10 and max(d["all"] for d in per.values()) == 11
    assert CE.CARDS_WITH_A_MODEL == 3 and CE.STEPS_PER_RULE == 8
    assert not [a for a in world["f2"]["calls"] if not a.startswith("f4_")]      # every call of this flow's rules is Family 4's


# ============================================================================================== the Coder's code and the reference implementation
REF = "it calls or reads the application's reference implementation of the NVMe command level rules (nvme_hier/command_error_rules.py)"
WAYS_ROUND = {
    "import": "import nvme_hier.command_error_rules as X\n\ndef run(tree, out_csv):\n    return X.run_on_tree(tree, out_csv, 'behaviour_01')\n",
    "from-import": "from nvme_hier import command_error_rules\n\ndef run(tree, out_csv):\n    return command_error_rules.run_on_tree(tree, out_csv, 'behaviour_01')\n",
    "from-import of a name": "from nvme_hier.command_error_rules import run_on_tree\n\ndef run(tree, out_csv):\n    return run_on_tree(tree, out_csv, 'behaviour_01')\n",
    "the package's attribute": "import nvme_hier\n\ndef run(tree, out_csv):\n    return nvme_hier.command_error_rules.run_on_tree(tree, out_csv, 'behaviour_01')\n",
    "importlib": "import importlib\n\ndef run(tree, out_csv):\n    return importlib.import_module('nvme_hier.command_error_rules').run_on_tree(tree, out_csv, 'behaviour_01')\n",
    "__import__": "def run(tree, out_csv):\n    return __import__('nvme_hier.command_error_rules', fromlist=['x']).run_on_tree(tree, out_csv, 'behaviour_01')\n",
    "getattr on a module object": "import nvme_hier\n\ndef run(tree, out_csv):\n    return getattr(nvme_hier, 'command_error_rules').run_on_tree(tree, out_csv, 'behaviour_01')\n",
    "attrgetter on a module object": "import operator, nvme_hier\n\ndef run(tree, out_csv):\n    return operator.attrgetter('command_error_rules')(nvme_hier).run_on_tree(tree, out_csv, 'x')\n",
    "reading the module's file and exec": "def run(tree, out_csv):\n    src = open('/app/nvme_hier/command_error_rules.py').read()\n    exec(src)\n",
    "through another module": "from nvme_hier import near_limit\n\ndef run(tree, out_csv):\n    return near_limit.RL.apply(tree.db)\n",
}


@pytest.mark.parametrize("way", sorted(WAYS_ROUND))
def test_a_coders_code_that_reaches_the_reference_or_the_detector_is_refused_in_a_plain_sentence(way):
    for on_tree in (True, False):
        probs = PR.check_code(WAYS_ROUND[way], tree=on_tree)
        assert probs, way
        if way == "through another module":             # the detector's code, reached through the module of another built-in item
            assert any(p.startswith("it calls or reads the detector's code (nvme_hier/rules.py)") for p in probs) and any("reaches the module nvme_hier.rules through another module" in p for p in probs)
        else:
            assert [p for p in probs if p.startswith(REF)] == [PR.REFERENCE_REFUSAL], (way, probs)
            assert "a comparison of the reference with itself shows nothing" in PR.REFERENCE_REFUSAL
    # what was refused before is refused as before, beside the new sentence
    assert "calls getattr()" in PR.check_code(WAYS_ROUND["getattr on a module object"], tree=True)
    assert "calls exec()" in PR.check_code(WAYS_ROUND["reading the module's file and exec"], tree=True)
    assert any(p.startswith("imports importlib") for p in PR.check_code(WAYS_ROUND["importlib"], tree=True))


def test_only_the_applications_own_code_text_may_call_the_reference_and_the_stand_in_holds_none():
    for f in CE.FAMILIES:
        if not f["checkable"]:
            continue
        text = CE.code_for(f["id"])
        assert PR.check_code(text, tree=True, application=True) == [] and PR.check_code(text, tree=True) == [PR.REFERENCE_REFUSAL]
        # the stand-in Coder never hands the reference implementation out as its code (while this file's flow runs it holds the test's own programs)
        assert "command_error_rules" not in (PR.STANDIN_CODE.get(CE.item_id(f["id"])) or "")
    assert "no model answered, and the stand-in writes no code for a rule of the application's rule set for NVMe command level errors" in PR.NO_STANDIN_FOR_FAMILY
    # nothing that was allowed for other code is refused now
    from nvme_hier import near_limit as NL
    assert PR.check_code(NL.code_for(), tree=True) == [] and PR.check_code(PR.STANDIN_CODE["read_pattern"]) == [] and PR.check_code(PR.STANDIN_CODE["command_type_share"]) == []
    ok = "import csv\nfrom nvme_hier import names\n\ndef run(tree, out_csv):\n    return {'rows_read': 0, 'rows_written': 0, 'total': names.opcode_name(2, 1)}\n"
    assert PR.check_code(ok, tree=True) == []
    assert any("reaches the module os through another module" in p for p in PR.check_code("from nvme_hier import near_limit\n\ndef run(tree, out_csv):\n    return near_limit.os.getcwd()\n", tree=True))


@pytest.fixture(scope="module")
def built():
    d = tempfile.mkdtemp(prefix="cmd_rules_tree_")
    db = os.path.join(d, "hier.sqlite")
    names = {"nvme_command": "nvme_command.csv", "nvme_transaction": "NVME_Transactions.csv", "split": "split.csv", "link": "link.csv", "packets": "packets.csv"}
    L.load_upload(db, {k: os.path.join(S17, n) for k, n in names.items()})
    B.build(db)
    RL.apply(db)
    yield db
    shutil.rmtree(d, ignore_errors=True)


def tree_copy(built, tmp_path):
    p = str(tmp_path / "hier.sqlite")
    a, b = sqlite3.connect(built), sqlite3.connect(p)
    a.backup(b)
    b.close()
    a.close()
    return p


def test_when_the_code_runs_the_reference_cannot_be_imported_by_a_coders_code(built, tmp_path):
    """The second line, at run time: whatever passed the check of the text, the process a Coder's code runs in cannot import the reference."""
    sneaky = tmp_path / "sneaky.py"
    sneaky.write_text("import csv\n\n\ndef run(tree, out_csv):\n    mod = 'nvme_hier.' + 'command_' + 'error_rules'\n    X = __import__(mod, fromlist=['x'])\n"
                      "    return X.run_on_tree(tree, out_csv, 'behaviour_01')\n", encoding="utf-8")
    res = PR.run_code(str(sneaky), {PR.TREE: built}, str(tmp_path / "o1.csv"), str(tmp_path / "box1"), timeout=120)
    assert res["ok"] is False and "command_error_rules" in res["error"] and "ImportError" in res["error"] or "ModuleNotFoundError" in res["error"], res
    # the application's own code text of the item runs, and finds the sample's rows
    own = tmp_path / "own.py"
    own.write_text(CE.code_for("behaviour_01"), encoding="utf-8")
    res = PR.run_code(str(own), {PR.TREE: built}, str(tmp_path / "o2.csv"), str(tmp_path / "box2"), timeout=120, application=True)
    assert res["ok"] is True and res["summary"]["rows_written"] == 6, res
    # the same text handed in as a Coder's code does not run
    res = PR.run_code(str(own), {PR.TREE: built}, str(tmp_path / "o3.csv"), str(tmp_path / "box3"), timeout=120)
    assert res["ok"] is False and "command_error_rules" in res["error"], res


# ============================================================================================== whose rule a finding is said to be
@pytest.fixture
def library(tmp_path):
    kept = family1.knowledge_dir
    family1.knowledge_dir = lambda: str(tmp_path / "knowledge")
    family3._SECTIONS_SEEN[0] = None
    try:
        family3.seed()
        yield family3
    finally:
        family1.knowledge_dir = kept
        family3._SECTIONS_SEEN[0] = None


def test_whose_rule_it_is_is_decided_from_stored_facts_of_the_item(library):
    seeded = family3.load_rule("errors", "nvme_command", CE.item_id("status_13"))
    o = family3.rule_origin(seeded, by_application=True)
    assert o["is"] == "application" and o["kind"] == "matched the rule 'The command was aborted because the host asked'" and o["kind_comes_from"] == RULE_SET
    assert "no model wrote its code" in o["words"] and "Family 4" not in o["words"]
    assert "code that Family 4 wrote from the rule's text and the admin approved" in family3.rule_origin(seeded, by_application=False)["words"]
    # renamed by the admin: still the application's rule (its procedure is the seeded one), and the name's part keeps the rule set's own name
    renamed = dict(seeded, name="My name for it")
    assert family3.rule_origin(renamed)["kind"] == o["kind"]
    # its procedure changed by the admin: procedures.store() makes it a rule of its own (kind "python", edited_by the admin): the admin's version
    proc = PR.procedure_of(seeded)
    changed, did = PR.store(json.loads(json.dumps(seeded)), dict({k: proc[k] for k in ("source_data", "steps", "output", "open_questions")},
                                                                  steps=proc["steps"] + ["One more step of the admin's own."]), "admin t")
    assert did and changed["kind"] == "python" and changed["procedure"]["edited_by"] == "admin t"
    v = family3.rule_origin(changed)
    assert v["is"] == "admins_version" and v["kind"] == "matched the admin's version of the rule 'The command was aborted because the host asked'"
    assert "changed by admin t" in v["words"] and v["short"] == "your own version of the rule “The command was aborted because the host asked”"
    assert family3.errors_of_the_tree(seeded) and family3.errors_of_the_tree(changed)
    # a rule the admin wrote, the detector's items and the other built-in item are none of these
    own = {"id": "aborted_commands", "section": "errors", "level": "nvme_command", "name": "aborted commands", "kind": None}
    assert family3.rule_origin(own) is None and family3.errors_of_the_tree(own)
    assert family3.rule_origin(family3.load_rule("errors", "nvme_command", "cmd_timeout")) is None and not family3.errors_of_the_tree(family3.load_rule("errors", "nvme_command", "cmd_timeout"))
    near = family3.load_rule("analytics", "nvme_command", "near_limit")
    assert family3.rule_origin(near) is None and not family3.errors_of_the_tree(near)
    # an item that only carries the prefix, or a family that is not in the rule set, is the admin's own
    assert family3.rule_origin(dict(own, id=CE.ITEM_PREFIX + "mine", plan={"family": "no_such_family"})) is None


def test_the_item_list_carries_the_group_and_the_plan_is_said_in_words(library):
    tree = family3.tree()
    errs = next(lv for s in tree if s["section"] == "errors" for lv in s["levels"] if lv["level"] == "nvme_command")
    mine = {i["id"]: i for i in errs["items"] if i["id"].startswith(CE.ITEM_PREFIX)}
    assert len(mine) == 38 and {i["group"] for i in mine.values()} == {CE.STATUS, CE.BEHAVIOUR, CE.PROTOCOL}
    for f in CE.FAMILIES:
        if f["checkable"]:
            assert mine[CE.item_id(f["id"])]["group"] == f["group"]
    assert all(i.get("group") is None for i in errs["items"] if not i["id"].startswith(CE.ITEM_PREFIX))      # the detector's two items are in no group
    r = family3.load_rule("errors", "nvme_command", CE.item_id("behaviour_03"))
    words = family3.describe(r)
    assert words.startswith("List every row of the NVMe command file that matches the rule 'The host sent an Abort' (behaviour over time): ")
    assert "After you approve the result, every found row is an error of the recording and goes on to stage 1" in words and "No plan yet" not in words
    assert family3.describe(dict(r, plan={"family": "gone"})).startswith("A rule of the NVMe command level whose rule family is not in the application's rule set any more")


def test_the_bridge_files_a_rule_of_the_rule_set_in_its_own_words_and_keeps_what_each_row_says(built, tmp_path):
    db = tree_copy(built, tmp_path)
    out = str(tmp_path / "r.csv")
    with open(out, "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows([[CF.ROW_COLUMN, CF.REASON_COLUMN, CF.LINKED_COLUMN], [144, "the reason of row 144", "Episode 2 of the recording"], [10, "the reason of row 10", ""]])
    origin = {"is": "application", "kind": "matched the rule 'X'", "found_by": "found by a rule of the rule set", "kind_comes_from": "the rule set", "words": "Found by X.",
              "sentence": "the part comes from the rule *X*", "short": "the rule “X”"}
    got = CF.file_findings(db, "errors", "nvme_command", "cmd_family_x", 1, "X", out, approved_by="t", origin=origin)
    assert (got["total"], got["added"], got["kept"]) == (2, 2, 0)
    rows = {f[3]: f for f in findings_of(db)}
    assert rows[144][6] == "X (found by a rule of the rule set)"
    d = detail_of(rows[144])
    assert d["kind"] == "matched the rule 'X'" and d["reason"] == "the reason of row 144" and d["linked"] == "Episode 2 of the recording"
    assert d["admin_rule"]["origin"] == "application" and d["admin_rule"]["kind_from"] == "the part comes from the rule X" and d["admin_rule"]["short"] == "the rule “X”"
    assert "linked" not in detail_of(rows[10]) and detail_of(rows[10])["reason"] == "the reason of row 10"
    assert CF.facts_of(db, [rows[144][0], rows[10][0]])[rows[144][0]]["linked"] == "Episode 2 of the recording"
    # the same rows again with other words: the findings keep their numbers and take the new words
    with open(out, "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows([[CF.ROW_COLUMN, CF.REASON_COLUMN, CF.LINKED_COLUMN], [144, "another reason", "Episode 9"], [10, "the reason of row 10", ""]])
    got = CF.file_findings(db, "errors", "nvme_command", "cmd_family_x", 1, "X", out, origin=origin)
    again = {f[3]: f for f in findings_of(db)}
    assert (got["kept"], got["added"]) == (2, 0) and again[144][0] == rows[144][0] and detail_of(again[144])["reason"] == "another reason" and detail_of(again[144])["linked"] == "Episode 9"
    # without an origin the words are the admin's own rule's, as before, and a result without the two columns files as before
    plain = str(tmp_path / "p.csv")
    with open(plain, "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows([[CF.ROW_COLUMN, "note"], [7, "x"]])
    CF.file_findings(db, "errors", "nvme_command", "my_rule", 2, "my rule", plain)
    mine = [f for f in findings_of(db) if f[1].endswith("my_rule.v2")][0]
    assert mine[6] == "my rule (found by the admin's own rule)"
    assert detail_of(mine) == {"kind": "matched the admin's rule 'my rule'", "admin_rule": {"item": "errors/nvme_command/my_rule", "procedure_version": 2, "name": "my rule", "approved_by": "",
                                                                                           "kind_comes_from": "the admin's rule", "origin": "admin",
                                                                                           "words": "Found by the admin's own rule 'my rule' (version 2 of its procedure, coded by Family 4)."}}


def test_the_sentence_for_a_rule_that_listed_nothing():
    r = {"name": "R"}
    said = pipeline.nothing_found_words
    assert said(r, {"summary": {"is_an_error_rule": True, "can_be_checked": True, "rows_read": 608}}) == (
        "The rule 'R' found no row in this recording (608 rows read): there is no error to list and nothing to isolate. An empty list is a result, not a failure.")
    assert said(r, {"summary": {"can_be_checked": False, "why_not": "cannot be checked on this recording: the NVMe transactions file is not loaded"}}) == (
        "The rule 'R' cannot be checked on this recording: the NVMe transactions file is not loaded. No error is listed for it; that is what this recording allows, not a failure of the rule.")
    # code a model wrote says nothing of it: the Tester's comparison with the reference implementation does
    test = {"checks": [{"check": "the rows found are ...", "ok": True, "detail": "the reference says: cannot be checked on this recording: no row carries a value in PRP1; the code's result has 0 rows"}]}
    assert said(r, {"summary": {"rows_read": 5, "rows_written": 0}}, test) == (
        "The rule 'R' cannot be checked on this recording: no row carries a value in PRP1. No error is listed for it; that is what this recording allows, not a failure of the rule.")
    assert said(r, {"summary": {"rows_read": 5}}) == "The rule 'R' found no row in this recording: there is no error to list and nothing to isolate. An empty list is a result, not a failure."
    assert said(r, {}) == said(r, {"summary": "text"})
    # code that listed nothing while the reference implementation finds rows is never said as "the rule found nothing"
    wrong = {"checks": [{"check": "the rows found are the rows the application's reference implementation of this rule finds on the whole recording", "ok": False,
                         "detail": "only the reference implementation found rows 5, 9"}]}
    assert said(r, {"summary": {"rows_read": 5, "rows_written": 0}}, wrong) == (
        "The code of the rule 'R' listed no row in this recording, and the application's reference implementation of the rule does not agree: only the reference "
        "implementation found rows 5, 9. No error is listed for it; the code needs to be corrected first (choose Change on its result card).")


def test_the_same_command_is_matched_by_level_and_row_and_only_the_latest_round_counts():
    def errs(item, pattern, rows, state="done", **more):
        return {"key": "f3:%s:errors" % item, "state": state, "output": dict({"pattern": pattern, "errors": [
            {"finding": 100 * n + i, "level": lv, "row": row, "where": "row %s of %s.csv (NVMe Cmd 9)" % (row, lv)} for i, (lv, row) in enumerate(rows)]}, **more)}
    n = 1
    steps = [errs("errors/nvme_command/a", "A", [("nvme_command", 5), ("nvme_command", 7)]),
             errs("errors/nvme_command/b", "B", [("nvme_command", 7), ("nvme_transaction", 5)]),              # row 5 of another level is another row
             errs("errors/nvme_command/c", "C", [("nvme_command", 5)], state="waiting"),                        # not finished: not listed
             errs("errors/nvme_command/d", "D", [("nvme_command", 5)]),
             errs("errors/nvme_command/d#2", "D", [("nvme_command", 9)]),                                      # round 2 replaces round 1
             errs("errors/other/e", "E", [("nvme_command", 7)], kind="other_csv"),                             # a CSV file that is not part of the tree
             {"key": "f3:errors/nvme_command/a:result", "state": "approved", "output": {}}]
    got = pipeline.same_command(steps)
    assert [(g["level"], g["row"], [x["pattern"] for x in g["listed"]]) for g in got] == [("nvme_command", 7, ["A", "B"])]
    assert got[0]["where"] == "row 7 of nvme_command.csv"
    assert pipeline.same_command_lines([]) == [] and pipeline.same_command_lines(got)[1].startswith("**The same command under more than one rule:** 1 row is listed")
    assert pipeline.same_command_lines(got)[2] == "- row 7 of nvme_command.csv: 'A' and 'B'"
    assert sorted(pipeline.latest_error_lists(steps)) == ["errors/nvme_command/a", "errors/nvme_command/b", "errors/nvme_command/d"]


def test_an_empty_table_is_still_a_failed_check_for_a_rule_that_gives_a_table(tmp_path):
    """The check "the code wrote rows" itself is unchanged: family3._test turns it into "an empty list is a result" only for a rule of a
    section that finds defects. A share, a count or a pattern with no line at all still fails."""
    empty = str(tmp_path / "e.csv")
    with open(empty, "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerow(["OPC", "count", "percent"])
    checks = PR.output_checks_file({"output": {"columns": ["OPC", "count", "percent"]}}, empty, None)
    assert [c for c in checks if c["check"] == "the code wrote rows"][0]["ok"] is False
    kept = family1.knowledge_dir
    family1.knowledge_dir = lambda: str(tmp_path / "knowledge")         # the sections are read from a folder of this test, never the application's own
    family3._SECTIONS_SEEN[0] = None
    try:
        assert family3.goes_to_stages("errors") and not family3.goes_to_stages("analytics")
    finally:
        family1.knowledge_dir = kept
        family3._SECTIONS_SEEN[0] = None
    src = open(os.path.join(APP, "agentic", "family3.py"), encoding="utf-8").read()
    assert "if goes_to_stages(r.get(\"section\")):" in src and "an empty list is a result for a rule that finds errors" in src


# ============================================================================================== the job that ends at 100 per cent
def test_a_job_is_never_seen_finished_at_less_than_100_per_cent(tmp_path):
    """The cause of "done with 90 per cent" (tests/test_nvme_command_rules.py, under load): the state was written first and the 100 in a second
    write. Every write is looked at here as a reader would see it right after it: no reader may see "done" below 100."""
    from jobs import JobManager
    seen = []

    class Watched(JobManager):
        def _update(self, jid, **fields):
            JobManager._update(self, jid, **fields)
            j = self.get(jid)
            seen.append((j["status"], (j.get("progress") or {}).get("pct")))
    mgr = Watched(str(tmp_path / "jobs.sqlite"))

    def work(jid, params, m):
        m.progress(jid, "checking the NVMe commands", "the errors are numbered by time", 90, stats={"rows": 5})
        return {"ok": True}
    jid = mgr.submit("nvme_command_rules", {}, work)
    mgr.threads[jid].join(30)
    j = mgr.get(jid)
    assert j["status"] == "done" and j["progress"]["pct"] == 100 and j["progress"]["step"] == "done" and j["progress"]["stats"] == {"rows": 5} and j["result"] == {"ok": True}
    assert ("running", 90) in seen and [s for s in seen if s[0] == "done"] and all(pct == 100 for state, pct in seen if state == "done"), seen
    # a job that fails keeps the percentage it had reached, and says failed
    bad = mgr.submit("x", {}, lambda jid, p, m: (m.progress(jid, "s", "", 40), 1 / 0))
    mgr.threads[bad].join(30)
    assert mgr.get(bad)["status"] == "failed" and mgr.get(bad)["progress"]["pct"] == 40


def test_the_check_again_route_does_not_count_the_families_before_its_job(built):
    from nvme_hier import nvme_command_rules as NR
    quick = NR.status(built, with_families=False)
    assert quick["families"] is None and quick["command_file_loaded"] is True and quick["commands"] == 608
    assert NR.status(built)["families"]["counts"]
    src = open(os.path.join(APP, "app", "api", "nvme_errors_api.py"), encoding="utf-8").read()
    assert "st = NR.status(db, with_families=False)" in src and '"families": NR.families()' in src


# ============================================================================================== a command identifier used again while its command was open
def test_a_reused_command_identifier_cannot_be_seen_in_the_tree_and_the_rule_says_so(tmp_path):
    """The constructed case. In S17, command row 43 (I/O queue 1, identifier 1) is open from 412,479,130,750 ps to its completion at
    412,503,227,750 ps, and command row 44 (I/O queue 1, identifier 2) is sent in between, at 412,480,073,750 ps. Row 44 and its NVMe
    transactions are given the identifier 1: two commands of one queue with the same identifier, open at once."""
    def rewrite(name, rows):
        changed = 0
        with open(os.path.join(S17, name), newline="", encoding="utf-8-sig") as fi, open(str(tmp_path / name), "w", newline="", encoding="utf-8") as fo:
            rd, w = csv.reader(fi), csv.writer(fo)
            head = next(rd)
            w.writerow(head)
            idx = [i for i, h in enumerate(head) if h.strip() == "CID"]
            for n, row in enumerate(rd, 1):
                if n in rows:
                    for i in idx:
                        if i < len(row) and row[i].strip() == "2":
                            row[i], changed = "1", changed + 1
                w.writerow(row)
        return changed
    # which NVMe transactions belong to command row 44, by identity: the tree of the unchanged files
    db0 = str(tmp_path / "before.sqlite")
    L.load_upload(db0, {"nvme_command": os.path.join(S17, "nvme_command.csv"), "nvme_transaction": os.path.join(S17, "NVME_Transactions.csv")})
    B.build(db0)
    con = sqlite3.connect("file:%s?mode=ro" % db0, uri=True)
    a, b = con.execute("SELECT sqid, cid, t_ps FROM cmd WHERE rowid_file = 43").fetchone(), con.execute("SELECT sqid, cid, t_ps FROM cmd WHERE rowid_file = 44").fetchone()
    done_a = con.execute("SELECT MIN(t_ps) FROM ntx WHERE parent_level='nvme_command' AND parent=43 AND type LIKE '%Completion Queue Entry%'").fetchone()[0]
    kids = {r[0] for r in con.execute("SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=44")}
    con.close()
    assert (a[0], a[1], b[0], b[1]) == (1, 1, 1, 2) and a[2] < b[2] < done_a          # row 44 is sent while row 43 is open: the case is real
    assert rewrite("nvme_command.csv", {44}) == 1 and rewrite("NVME_Transactions.csv", kids) >= 3
    db = str(tmp_path / "hier.sqlite")
    L.load_upload(db, {"nvme_command": str(tmp_path / "nvme_command.csv"), "nvme_transaction": str(tmp_path / "NVME_Transactions.csv")})
    B.build(db)
    RL.apply(db)
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    assert con.execute("SELECT sqid, cid FROM cmd WHERE rowid_file IN (43, 44) ORDER BY rowid_file").fetchall() == [(1, 1), (1, 1)]
    # what the tree made of it: every completion with this queue and identifier went to the newer command or to none; the earlier command has none
    cqe = con.execute("SELECT parent FROM ntx WHERE sqid = 1 AND cid = 1 AND type LIKE '%Completion Queue Entry%' AND t_ps BETWEEN ? AND ? ORDER BY rowid_file", (a[2], done_a + 10 ** 7)).fetchall()
    assert [p[0] for p in cqe] == [44, None]
    assert con.execute("SELECT COUNT(*) FROM ntx WHERE parent_level='nvme_command' AND parent=43 AND type LIKE '%Completion Queue Entry%'").fetchone()[0] == 0
    assert ("cmd.incomplete",) in con.execute("SELECT rule FROM finding WHERE level='nvme_command' AND rowid=43").fetchall()       # it shows as a command that never completed
    con.close()
    t = T.Tree(db)
    try:
        info = {}
        assert [x["row"] for x in CE.find("protocol_01", t, info)] == []           # the rule cannot see it ...
        assert info["can_be_checked"] is True and info["notes"] == [CE.CID_LIMIT_SAYS]
        res = CE.run_on_tree(t, str(tmp_path / "o.csv"), "protocol_01")
    finally:
        t.close()
    # ... and it says so with every result, in its text and on the page: it is never silent about it
    assert res["rows_written"] == 0 and res["words"].endswith(CE.CID_LIMIT_SAYS) and "found no row in this recording" in res["words"]
    assert "cannot be seen at the command level" in CE.CID_LIMIT_SAYS and "the earlier command shows as one that never completed" in CE.CID_LIMIT_SAYS
    f = CE.BY_ID["protocol_01"]
    assert (CE.CID_LIMIT, CE.CID_LIMIT_SRC) in f["how"] and any(CE.CID_LIMIT in s for s in CE.procedure(f)["steps"])
    assert pipeline.nothing_found_words({"name": f["name"]}, {"summary": res}).startswith("The rule '%s' found no row in this recording" % f["name"])


def test_the_identifier_ffffh_is_still_found_and_said_with_the_limit(built, tmp_path):
    """What the rule does find: the identifier FFFFh, as advice. One command of S17 is given it in a copy of the tree's command table."""
    db = tree_copy(built, tmp_path)
    con = sqlite3.connect(db)
    raw = json.loads(con.execute("SELECT raw FROM cmd WHERE rowid_file = 50").fetchone()[0])
    raw["CID"] = "65535"
    con.execute("UPDATE cmd SET raw = ?, cid = 65535 WHERE rowid_file = 50", (json.dumps(raw),))
    con.commit()
    con.close()
    t = T.Tree(db)
    try:
        res = CE.run_on_tree(t, str(tmp_path / "o.csv"), "protocol_01")
    finally:
        t.close()
    assert res["rows_written"] == 1 and "found 1 row of the NVMe command file" in res["words"] and res["words"].endswith(CE.CID_LIMIT_SAYS)
    with open(str(tmp_path / "o.csv"), newline="", encoding="utf-8") as fh:
        rows = list(csv.reader(fh))
    assert rows[1][rows[0].index(CE.ROW_COLUMN)] == "50" and "FFFFh" in rows[1][rows[0].index("what was found")]


# ============================================================================================== the page scripts
def test_the_page_scripts_compile():
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    d = tempfile.mkdtemp(prefix="cmd_rules_js_")
    try:
        for name in ("agents.js", "nvme_command_rules.js"):
            shutil.copy(os.path.join(APP, "app", "static", "js", name), os.path.join(d, name[:-3] + ".cjs"))
            p = subprocess.run([NODE, "--check", os.path.join(d, name[:-3] + ".cjs")], capture_output=True, text=True, timeout=60)
            assert p.returncode == 0, (name, p.stderr[-800:])
        text = open(os.path.join(APP, "app", "static", "js", "agents.js"), encoding="utf-8").read()
        assert "errNotes(e, st, same, pid)" in text and "h += errorsNothing(v);" in text and "const same = sameCommand(ls);" in text
    finally:
        shutil.rmtree(d, ignore_errors=True)


# ============================================================================================== one tree, many readers, one writer
def test_filing_errors_waits_for_the_code_runs_that_read_the_tree(tmp_path):
    """Two analyses of one recording share its tree. A code run reads the tree's file as one that cannot change; the errors step writes into
    it. procedures.TreeLock: runs read together, a write waits until none reads, no reader starts while a write waits or works, and the
    write-ahead log is folded only when nobody reads."""
    import threading
    lock = PR.TreeLock()
    events, folds = [], []
    assert lock.read_begin(lambda: folds.append("first") or True) is True           # the first reader may fold the log
    assert lock.read_begin(lambda: folds.append("second") or True) is None          # a second reader beside it may not: the first reads the file now
    assert folds == ["first"]
    told = []

    def writer():
        lock.write_begin(waiting=lambda: told.append(1))
        events.append("write starts")
        time.sleep(0.2)
        events.append("write ends")
        lock.write_end()

    def late_reader():
        lock.read_begin()
        events.append("late reader starts")
        lock.read_end()
    w = threading.Thread(target=writer)
    w.start()
    time.sleep(0.3)
    assert events == [] and told                                # the writer waits for the two readers, and says so
    r = threading.Thread(target=late_reader)
    r.start()
    time.sleep(0.3)
    assert events == []                                         # a reader that comes while a write waits does not start before it
    lock.read_end()
    time.sleep(0.2)
    assert events == []                                         # one reader is still there
    events.append("last reader ends")
    lock.read_end()
    w.join(10)
    r.join(10)
    assert events == ["last reader ends", "write starts", "write ends", "late reader starts"]
    # the same lock for the same file, whatever way its path is written; write_tree folds after the work and gives the work's answer
    db = str(tmp_path / "t.sqlite")
    con = sqlite3.connect(db)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("CREATE TABLE x (a)")
    con.commit()
    con.close()
    assert PR.tree_lock(db) is PR.tree_lock(os.path.join(str(tmp_path), ".", "t.sqlite")) and PR.tree_lock(db) is not PR.tree_lock(db + "2")

    def work():
        c2 = sqlite3.connect(db)
        c2.execute("INSERT INTO x VALUES (1)")
        c2.commit()
        c2.close()
        return "done"
    assert PR.write_tree(db, work) == "done"
    assert not os.path.exists(db + "-wal") or os.path.getsize(db + "-wal") == 0
    with pytest.raises(ValueError):                             # a failure of the work leaves the lock free
        PR.write_tree(db, lambda: (_ for _ in ()).throw(ValueError("x")))
    assert PR.write_tree(db, lambda: 7) == 7
    src = open(os.path.join(APP, "agentic", "pipeline.py"), encoding="utf-8").read()
    assert "PR.write_tree(db, lambda: CF.file_findings(" in src and "CF.remove(db, sec, lvl, rid))" in src


# ============================================================================================== a decision that arrives while the run's loop is ending
def test_a_decision_that_arrives_while_the_runs_loop_is_on_its_way_out_is_not_lost():
    """Found by the four flows at once of tests/test_application_code_items.py (twice on 2026-11-15): a run stayed "running" with no step
    running, its result card approved and its next step waiting. The loop had read "this step waits for the admin"; the decision was stored
    and kick() found the loop still alive, so it did nothing; the loop ended. Here the decision arrives exactly in that moment."""
    import threading

    class Store:
        def __init__(self):
            self.step = {"id": 1, "key": "result", "state": "needs_review", "idx": 1}
            self.run = {"id": 7, "state": "running", "kind": "k"}

        def one(self, sql, args=()):
            if "FROM run" in sql:
                return dict(self.run)
            return dict(self.step) if self.step["state"] not in ("done", "approved", "skipped") else None

        def all(self, sql, args=()):
            return []

        def exec(self, sql, args=()):
            return None
    eng = core.Engine(Store(), {"k": object()}, runner=None)
    ran, decided = [], threading.Event()
    kick = core.Engine.kick if getattr(core.Engine.kick, "__name__", "") == "kick" else None
    if kick is None:                            # another test's set-up holds the engine's start back (fuzz_app.setup): the real one is kept there
        import fuzz_app as F
        kick = F.REAL_KICK

    def start_ahead(run):                       # the moment between "the step waits for the admin" being read and the loop's end
        if not decided.is_set():
            decided.set()
            eng.store.step = {"id": 2, "key": "errors", "state": "waiting", "idx": 2}      # the admin approved: the next step is to run
            kick(eng, 7)                        # ... and the engine is told, while this loop is still alive
    eng._start_ahead = start_ahead
    eng._run_step = lambda run, step: (ran.append(step["key"]), eng.store.step.update(state="done"))
    eng._finish = lambda rid, state: eng.store.run.update(state=state)
    kick(eng, 7)
    for _ in range(100):
        if eng.store.run["state"] == "finished":
            break
        time.sleep(0.05)
    assert ran == ["errors"] and eng.store.run["state"] == "finished"       # the step after the decision ran: nothing was lost
    th = eng.threads.get(7)
    th.join(5)
    assert not th.is_alive() and 7 not in eng.again and 7 in eng.leaving          # the loop left; the next kick starts a new one
    eng.store.run["state"], eng.store.step = "running", {"id": 3, "key": "report", "state": "waiting", "idx": 3}
    kick(eng, 7)
    for _ in range(100):
        if eng.store.run["state"] == "finished":
            break
        time.sleep(0.05)
    assert ran == ["errors", "report"] and eng.threads[7] is not th
