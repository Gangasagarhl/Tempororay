"""The error numbers of a recording are given anew when its rules run again; everything an analysis keeps must follow (found 2026-11-15
by a tester in a browser: after "Check this recording again" on /nvme-rules the stores had followed, the analysis's errors page had not:
it linked the old number, which was another error by then, and showed "not isolated yet" for an error that was finished).

One application on a throw-away root, sample samples/clean_five_files/S17_io_timeout_abort_reset, the stand-in (no model, no server).
Two analyses on the same recording: the first with the built-in check "NVMe command timed out" and the rule family "A command never
completed" chosen and approved (the same six commands are listed under both), the second with the built-in check alone. One error of the
family is taken to "isolated". Then, one after the other, written down by the fixture at each point:

  1. the check the button of /nvme-rules starts (the job), which moves numbers;
  2. the same check a second time: nothing moves;
  3. a timing limit applied again on the recording's page 3;
  4. the check with a higher host limit: three listed timeouts are no longer found;
  5. the half-done case: the link limit is put back, the numbers move (the stores follow) and the analyses' records do NOT: the page's
     links open other errors, until the errors page asks the server to check the numbers (POST /api/agents/runs/<run>/error-numbers);
  6. every rule run anew (the settings page's "save the limits"): the errors the rule family had filed are gone until it runs again.

After each, every link the errors page builds (the page's own functions, run by node) must open the SAME error as before, told by what
the error is: its rule, its level and its row in the level's file (never by a time stamp); the finished error must still show where it
stands; "The same command is also listed under" must still point at the right error; both analyses must be followed.

Everything is written under temporary folders; what the fixture changes in the application's modules is put back.
"""
import copy
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

import pytest

os.environ.setdefault("F2T_WORKERS", "1")
APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for _p in (APP, os.path.join(APP, "app"), os.path.join(APP, "tests")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from agentic import core, family1, family3, pipeline, procedures as PR      # noqa: E402
from nvme_hier import coded_findings as CF, command_error_rules as CE, rules as RL      # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NODE = "/home/raghavendra/.nvm/versions/node/v22.23.2/bin/node"
LOWER = ["nvme_transaction", "split", "link", "packets"]
TIMEOUT = "errors/nvme_command/cmd_timeout"
NEVER = "errors/nvme_command/" + CE.item_id("behaviour_01")
TIMEOUT_ROWS = [144, 155, 216, 295, 358, 443, 509]          # what S17 holds (tests/test_command_rules_flow.py counts them from the file itself)
NEVER_ROWS = [155, 216, 295, 358, 443, 509]
S = 10 ** 12                                                # picoseconds in a second
pytestmark = pytest.mark.skipif(not os.path.isdir(S17) or not os.path.exists(NODE),
                                reason="the S17 sample recording or node is not on this machine (the code-only zip carries no samples)")


class Yes:
    def random(self):
        return 0.0

    def choice(self, seq):
        return seq[0]

    def sample(self, seq, k):
        return list(seq)[:k]

    def randint(self, _a, b):
        return b


# ---------------------------------------------------------------------------------------------- helpers
def view_of(c, rid):
    return c.get("/api/agents/runs/%d" % rid).get_json()


def drive(c, rid, stop, chosen, limit=1500):
    """Approve the flow's cards the plain way until stop(step) is true -> (review, step, view)."""
    import fuzz_deep as FD
    t0 = time.time()
    while time.time() - t0 < limit:
        v = view_of(c, rid)
        failed = [(s["key"], (s.get("error") or "")[-800:]) for s in v["steps"] if s["state"] == "failed"]
        assert not failed, failed
        if v["run"]["state"] != "running":
            return None, None, v
        rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
        if rv is None:
            time.sleep(0.2)
            continue
        st = next(s for s in v["steps"] if s["id"] == rv["step"])
        if stop(st):
            return rv, st, v
        if st["key"] == "f3_plan":
            edits = {"selected": list(chosen)}
        elif st["key"].endswith(":result"):
            edits = None
        else:
            edits = FD.edits_for(st["key"], rv.get("data") or {}, Yes())
        r = c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t", "edits": edits})
        assert r.status_code == 200, (st["key"], r.get_json())
    raise AssertionError("the flow did not reach the point in %d s" % limit)


def page_of(view, tmp, note=""):
    """What the errors page's own script (app/static/js/agents.js) makes of a view, run by node: of every list its errors with the link
    the page builds for each (the page's own errHref), the notes under each error ("The same command is also listed under" with its
    links), and the cards "No longer found after the recording was checked again" and "The error numbers were checked"."""
    with open(os.path.join(APP, "app", "static", "js", "agents.js"), encoding="utf-8") as fh:
        text = fh.read()
    part = text[text.index("function errorLists(v) {"):text.index("async function loadErrStatus(v) {")]
    href = next(ln for ln in text.splitlines() if ln.startswith("const errHref = "))
    part += "\n" + href + "\n" + text[text.index("function sameCommand(ls) {"):text.index("function errCounts(st) {")]
    d = tempfile.mkdtemp(prefix="page_", dir=tmp)
    with open(os.path.join(d, "view.json"), "w", encoding="utf-8") as fh:
        json.dump(view, fh)
    with open(os.path.join(d, "h.cjs"), "w", encoding="utf-8") as fh:
        fh.write("const esc = s => String(s ?? '');\nconst S = { errNumbers: {} };\nconst api = async () => ({});\n"
                 "const plainDefects = (cols, head) => (head || []).map(x => ({ no: x[0], what: x[3], where: '', when: '', sev: x[4], level: x[1], row: x[8] }));\n"
                 + part + "\nconst v = JSON.parse(require('fs').readFileSync(process.argv[2], 'utf8'));\nconst ls = errorLists(v), same = sameCommand(ls);\n"
                 "S.errNumbers[v.run.id] = process.argv[3] || '';\n"
                 "console.log('RESULT ' + JSON.stringify({ lists: ls.map(s => ({ key: s.key, upload: s.output.upload_id, errors: s.output.errors.map(e => ({ finding: e.finding, level: e.level, row: e.row,\n"
                 "  link: errHref(7, s.output.upload_id, e.finding), notes: errNotes(e, s, same, 7) })) })), gone: errorsNoLongerFound(v), checked: errNumbersNote(v) }));\n")
    p = subprocess.run([NODE, os.path.join(d, "h.cjs"), os.path.join(d, "view.json"), note], capture_output=True, text=True, encoding="utf-8", timeout=60)
    line = next((ln for ln in p.stdout.splitlines() if ln.startswith("RESULT ")), None)
    assert line, (p.stdout[-500:], p.stderr[-1500:])
    return json.loads(line[7:])


def tree(db):
    """{error number: (rule, level, row of the level's file)} of the whole tree, and the same the other way round for the rules whose
    errors stand one on a row."""
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        return {fid: (rule, level, row) for fid, rule, level, row in con.execute("SELECT id, rule, level, rowid FROM finding")}
    finally:
        con.close()


def facts(db, like):
    """What the tree keeps of the errors of some rules, apart from their numbers: {(rule, row): (level, name, detail, command row, severity)}."""
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        return {(r[0], r[1]): tuple(r[2:]) for r in con.execute("SELECT rule, rowid, level, name, detail, cmd_rowid, severity FROM finding WHERE rule LIKE ?", (like,))}
    finally:
        con.close()


def mark_of(db):
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        r = con.execute("SELECT v FROM meta WHERE k = ?", (CF.LAST_ID_KEY,)).fetchone()
        return (json.loads(r[0]) if r else None), con.execute("SELECT COALESCE(MAX(id), 0) FROM finding").fetchone()[0]
    finally:
        con.close()


def being_numbered(db, since=False):
    """Does the tree say that its findings are being filed anew? since: a time to write the word by hand (None takes it away)."""
    con = sqlite3.connect(db)
    try:
        if since is not False:
            if since is None:
                RL.numbering_ends(con)
            else:
                con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES (?, ?)", (RL.NUMBERING_KEY, json.dumps(since)))
                con.commit()
        return RL.numbering_since(con)
    finally:
        con.close()


def link_number(link):
    m = re.search(r"[?&]finding=(\d+)", link)
    return int(m.group(1))


def opened(page, who):
    """What each link of the page opens, told by what the error is: {list key: [(rule, level, row) per listed error, in the list's order]}."""
    out = {}
    for ls in page["lists"]:
        out[ls["key"]] = [who.get(link_number(e["link"])) for e in ls["errors"]]
    return out


def also_listed(page, who):
    """{(list key, row): [what the links under "The same command is also listed under" open]}."""
    out = {}
    for ls in page["lists"]:
        for e in ls["errors"]:
            if "The same command is also listed under" in e["notes"]:
                out[(ls["key"], e["row"])] = [who.get(int(n)) for n in re.findall(r'href="[^"]*[?&]finding=(\d+)', e["notes"])]
    return out


def numbers_kept(view):
    """Every error number an analysis keeps, by where it is kept (for "a second check changes nothing")."""
    out = {}
    for s_ in view["steps"]:
        o = s_.get("output") or {}
        if s_["key"].endswith(":errors"):
            out[s_["key"]] = [e["finding"] for e in o.get("errors") or []]
        if s_["key"].endswith(":run") and o.get("kind") == "detector":
            out[s_["key"]] = [x[0] for x in o.get("head") or []]
    for r in view["reviews"]:
        d = r.get("data") or {}
        if d.get("same_command") is not None:
            out["gate"] = [[x["finding"] for x in g["listed"]] for g in d["same_command"]]
        if isinstance(d.get("head"), list) and (d.get("columns") or [])[:1] == ["defect"]:
            out["card %d" % r["id"]] = [x[0] for x in d["head"]]
    return out


def check_job(c, up):
    """The button "Check this recording again" of /nvme-rules: the job, waited for -> its result."""
    r = c.post("/api/hier/nvme_command_rules/%s/check" % up, json={})
    assert r.status_code == 200, r.get_json()
    jid = r.get_json()["job"]
    t0 = time.time()
    while time.time() - t0 < 300:
        j = c.get("/api/jobs/%s" % jid).get_json()
        if j.get("status") in ("done", "failed", "cancelled"):
            assert j["status"] == "done", j
            return j["result"]
        time.sleep(0.2)
    raise AssertionError("the check did not finish")


def set_host_limit(d, ps):
    """The host's time limit for an NVMe command in the recording's own settings (what the check reads), or back to the default."""
    path = os.path.join(d, "meta.json")
    with open(path, encoding="utf-8") as fh:
        meta = json.load(fh)
    th = dict(meta.get("thresholds") or {})
    if ps is None:
        th.pop("nvme_command", None)
    else:
        th["nvme_command"] = {"value": ps / S, "unit": "s", "ps": ps, "source": "set by the test"}
    meta["thresholds"] = th
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(meta, fh)


def point(c, w, name, **more):
    """Write down what the application holds now."""
    db, up = w["db"], w["upload"]
    va, vb = view_of(c, w["run_a"]), view_of(c, w["run_b"])
    who = tree(db)
    fid = next((e["finding"] for e in next(s for s in va["steps"] if s["key"] == "f3:%s:errors" % NEVER)["output"]["errors"] if e["row"] == 155), None)
    w[name] = dict({"a": va, "b": vb, "page_a": page_of(va, w["root"]), "page_b": page_of(vb, w["root"]), "who": who, "fid": fid, "mark": mark_of(db),
                    "status": c.get("/api/dg/status?upload=%s&findings=%d" % (up, fid)).get_json()["status"][str(fid)] if fid is not None else None,
                    "coded": facts(db, "admin.%"), "gate": next(r for r in va["reviews"] if (r.get("data") or {}).get("errors_overview")),
                    "being_numbered": being_numbered(db)}, **more)
    return w[name]


@pytest.fixture(scope="module")
def world():
    import fuzz_app as F
    from api import config_api, hier_api
    root = tempfile.mkdtemp(prefix="renumber_flows_%d_" % os.getpid())
    kept = (core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK)
    uploads, hook, standin = PR._UPLOADS[0], PR.MODEL_CONNECTED, dict(PR.STANDIN_CODE)
    w = {"root": root}
    try:
        app, c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kept[0]
        family3._SECTIONS_SEEN[0] = None
        c.get("/api/agents/state")
        s = app.config["services"]

        # ---- the first analysis: the built-in check and the rule family, both approved; the second: the built-in check alone
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "numbers one", "folder": S17}).get_json()["id"]
        rid = c.post("/api/agents/projects/%d/flow" % pid, json={"admin": "t"}).get_json()["run"]
        _rv, _st, v = drive(c, rid, lambda s_: s_["key"] == "errors_done", [TIMEOUT, NEVER])
        up = next(s_ for s_ in v["steps"] if s_["key"] == "f3:%s:run" % TIMEOUT)["output"]["upload_id"]
        db = PR.source_paths(up)[PR.TREE]
        pid2 = c.post("/api/agents/projects", json={"admin": "t", "name": "numbers two", "folder": S17}).get_json()["id"]
        rid2 = c.post("/api/agents/projects/%d/flow" % pid2, json={"admin": "t"}).get_json()["run"]
        _rv, _st, v2 = drive(c, rid2, lambda s_: s_["key"] == "errors_done", [TIMEOUT])
        w.update(upload=up, db=db, run_a=rid, run_b=rid2, dir=os.path.dirname(db), services=s,
                 upload_b=next(s_ for s_ in v2["steps"] if s_["key"] == "f3:%s:run" % TIMEOUT)["output"]["upload_id"])

        # ---- one error of the family (the command of row 155) is taken to "isolated": the defect named, this occurrence stored
        fid = next(e["finding"] for e in next(s_ for s_ in v["steps"] if s_["key"] == "f3:%s:errors" % NEVER)["output"]["errors"] if e["row"] == 155)
        base = "/api/isolate/%s/%d" % (up, fid)
        iso = c.post(base + "/isolate", json={"n": 15, "m": 15, "levels": LOWER, "history": True, "anyway": True, "isolation": True, "name": "t", "standin": True}).get_json()
        i = iso["isolation"]
        d = c.post("/api/dg/defects", json={"name": i["term"]["name"], "term_key": i["term"]["key"], "rule": i["rule"], "level": i["level"], "what": i["what"], "admin": "t"}).get_json()
        c.post("/api/dg/occurrences", json={"defect_id": d["id"], "cause_id": None, "upload_id": up, "finding_id": fid, "device": i.get("device"), "admin": "t"})
        p0 = point(c, w, "p0")
        shutil.copy(os.path.join(root, "db", "agentic.sqlite"), os.path.join(root, "records_before.sqlite"))       # the records as they were, for the tests on a copy

        # ---- 1. the button of /nvme-rules: the check that moves numbers
        point(c, w, "p1", job=check_job(c, up))
        # ---- 2. the same check again: nothing moves
        point(c, w, "p2", job=check_job(c, up))
        # ---- 3. a timing limit of page 3 applied again (the link transactions' limit raised: fewer of their errors, so the numbers move)
        r = c.put("/api/hier/uploads/%s/timing_limits" % up, json={"link": {"value": 60, "unit": "us", "source": "the test"}})
        assert r.status_code == 200, r.get_json()
        point(c, w, "p3", answer=r.get_json())
        # ---- 4. the check with a higher host limit (100 s): some listed timeouts are no longer found
        set_host_limit(w["dir"], 100 * S)
        point(c, w, "p4", job=check_job(c, up))

        # ---- 5. the half-done case: the link limit back to the specification's, the stores followed, the analyses' records NOT followed
        with open(os.path.join(w["dir"], "meta.json"), encoding="utf-8") as fh:
            meta = json.load(fh)
        meta["thresholds"].pop("link", None)
        with open(os.path.join(w["dir"], "meta.json"), "w", encoding="utf-8") as fh:
            json.dump(meta, fh)
        out = {}
        RL.apply_link_limit(db, meta["thresholds"], out=out)
        hier_api.follow_in_stores(s, up, out.get("renumbered") or {})
        con = sqlite3.connect(db)
        hier_api.ensure_indexes(con)
        con.close()
        half = point(c, w, "half", moved=dict(out.get("renumbered") or {}), gone=list(out.get("no_longer_found") or []))
        half["look"] = pipeline.follow_renumbering(s, up, None, db=db, dry=True)                    # what a look alone says: nothing is written
        half["after_look"] = numbers_kept(view_of(c, rid))
        ans = c.post("/api/agents/runs/%d/error-numbers" % rid, json={})
        p5 = point(c, w, "p5", answer=ans.get_json(), code=ans.status_code)
        p5["page_a"] = page_of(p5["a"], root, note=p5["answer"].get("sentence") or "")
        p5["again"] = c.post("/api/agents/runs/%d/error-numbers" % rid, json={}).get_json()
        p5["other"] = c.post("/api/agents/runs/%d/error-numbers" % rid2, json={}).get_json()
        p5["no_such"] = c.post("/api/agents/runs/987654/error-numbers", json={}).status_code

        # ---- while a check of the recording is under way (the tree says so itself) nothing is compared and nothing is changed
        being_numbered(db, since=time.time() - 90)
        w["busy"] = {"answer": c.post("/api/agents/runs/%d/error-numbers" % rid, json={}).get_json(), "kept": numbers_kept(view_of(c, rid)),
                     "follow": hier_api.follow_in_analyses(s, up, {1: 2, 2: 1}, [], db), "kept_after_follow": numbers_kept(view_of(c, rid))}
        being_numbered(db, since=None)

        # ---- a number is never handed to two errors: a new error filed by a rule after all this gets a number above every number in use
        before = mark_of(db)
        csv_path = os.path.join(root, "by_hand.csv")
        with open(csv_path, "w", encoding="utf-8", newline="") as fh:
            fh.write("%s\n145\n" % CF.ROW_COLUMN)
        got = CF.file_findings(db, "errors", "nvme_command", "by_hand_for_the_mark", 1, "by hand", csv_path)
        w["mark"] = {"before": before, "after": mark_of(db), "got": got, "numbers": sorted(n for n, x in tree(db).items() if x[0] == got["rule"])}
        assert CF.remove(db, "errors", "nvme_command", "by_hand_for_the_mark") == 1

        # ---- 6. every rule run anew (the settings page saves the limits): the family's filed errors are gone until the rule runs again
        r = c.put("/api/hier/uploads/%s/thresholds" % up, json={})
        assert r.status_code == 200, r.get_json()
        point(c, w, "p6", answer=r.get_json())
        _ = p0
        yield w
    finally:
        core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK = kept
        PR.use_uploads_folder(uploads)
        PR.MODEL_CONNECTED = hook
        PR.STANDIN_CODE.clear()
        PR.STANDIN_CODE.update(standin)
        family3._SECTIONS_SEEN[0] = None
        shutil.rmtree(root, ignore_errors=True)


KEY_T, KEY_N = "f3:%s:errors" % TIMEOUT, "f3:%s:errors" % NEVER


def rows_of(page, key):
    return [e["row"] for e in next(ls for ls in page["lists"] if ls["key"] == key)["errors"]]


def same_errors_as_before(w, name, base="p0"):
    """Every link of both analyses' errors pages opens the error it opened at `base`, told by rule, level and row."""
    now, was = w[name], w[base]
    assert opened(now["page_a"], now["who"]) == opened(was["page_a"], was["who"]), name
    assert opened(now["page_b"], now["who"]) == opened(was["page_b"], was["who"]), name
    assert also_listed(now["page_a"], now["who"]) == also_listed(was["page_a"], was["who"]), name


# ============================================================================================== the start
def test_at_the_start_both_analyses_list_the_errors_of_the_same_recording_and_one_is_isolated(world):
    p = world["p0"]
    assert world["upload_b"] == world["upload"]                       # two analyses, one recording, one tree
    assert rows_of(p["page_a"], KEY_T) == TIMEOUT_ROWS and rows_of(p["page_a"], KEY_N) == NEVER_ROWS and rows_of(p["page_b"], KEY_T) == TIMEOUT_ROWS
    got = opened(p["page_a"], p["who"])
    assert got[KEY_T] == [("cmd.timeout", "nvme_command", r) for r in TIMEOUT_ROWS]
    assert [x[1:] for x in got[KEY_N]] == [("nvme_command", r) for r in NEVER_ROWS] and all(CF.is_coded(x[0]) for x in got[KEY_N])
    assert p["status"]["state"] == "isolated" and p["status"]["words"].startswith("isolated: the defect")
    # "The same command is also listed under": on each of the six commands, under each of the two rules, the link opens the other rule's error of that row
    also = also_listed(p["page_a"], p["who"])
    assert sorted(also) == sorted([(KEY_T, r) for r in NEVER_ROWS] + [(KEY_N, r) for r in NEVER_ROWS])
    for (key, row), xs in also.items():
        assert len(xs) == 1 and xs[0][1:] == ("nvme_command", row) and CF.is_coded(xs[0][0]) == (key == KEY_T), (key, row, xs)


def test_each_listed_error_keeps_what_it_is_beside_its_number(world):
    p = world["p0"]
    for key in (KEY_T, KEY_N):
        for e in next(s for s in p["a"]["steps"] if s["key"] == key)["output"]["errors"]:
            rule, level, row = p["who"][e["finding"]]
            assert e["identity"] == {"rule": rule, "level": level, "row": row, "nth": 0} and e["row"] == row and e["level"] == level


# ============================================================================================== 1. the check of /nvme-rules moves numbers
def test_the_check_moved_numbers_and_the_fault_would_have_shown(world):
    p0, p1 = world["p0"], world["p1"]
    assert p1["job"]["error_numbers_that_moved"] > 0
    # the family's error of row 155 has another number now, and its old number is another error (what the tester saw)
    assert p1["fid"] != p0["fid"] and p1["who"][p1["fid"]] == p0["who"][p0["fid"]] and p1["who"].get(p0["fid"]) != p0["who"][p0["fid"]]
    old_links = opened(p0["page_a"], p1["who"])                       # the links the page drew BEFORE, opened in the tree as it is NOW
    assert old_links != opened(p0["page_a"], p0["who"])               # they open other errors: the records had to follow


def test_after_the_check_every_link_opens_the_same_error(world):
    same_errors_as_before(world, "p1")
    p1 = world["p1"]
    assert rows_of(p1["page_a"], KEY_T) == TIMEOUT_ROWS and rows_of(p1["page_a"], KEY_N) == NEVER_ROWS and rows_of(p1["page_b"], KEY_T) == TIMEOUT_ROWS
    assert p1["page_a"]["gone"] == "" and p1["page_a"]["checked"] == ""             # nothing vanished, nothing had to be corrected


def test_after_the_check_the_finished_error_still_shows_where_it_stands(world):
    p0, p1 = world["p0"], world["p1"]
    assert p1["status"] == p0["status"] and p1["status"]["state"] == "isolated"


def test_after_the_check_every_other_number_the_analysis_keeps_followed_too(world):
    p1 = world["p1"]
    for name in ("a", "b"):
        kept = numbers_kept(p1[name])
        run_key = "f3:%s:run" % TIMEOUT
        assert [p1["who"][n] for n in kept[run_key]] == [("cmd.timeout", "nvme_command", r) for r in TIMEOUT_ROWS], name     # the result lines of the built-in check
        cards = [v for k, v in kept.items() if k.startswith("card ")]
        assert cards and all([p1["who"][n] for n in x] == [("cmd.timeout", "nvme_command", r) for r in TIMEOUT_ROWS] for x in cards), name
    gate = numbers_kept(p1["a"])["gate"]                              # the errors gate's own note of the commands listed twice
    assert len(gate) == 6
    for pair, row in zip(gate, NEVER_ROWS):
        assert [p1["who"][n][1:] for n in pair] == [("nvme_command", row)] * 2 and [CF.is_coded(p1["who"][n][0]) for n in pair] == [False, True]


def test_the_errors_a_rule_of_the_rule_set_filed_are_kept_through_the_check_with_everything_but_their_number(world):
    p0, p1 = world["p0"], world["p1"]
    assert p1["coded"] == p0["coded"] and len(p1["coded"]) == 6       # the rule key, the level, the name, the detail, the command, the severity: all as before
    for (rule, row), (level, _name, detail, cmd, sev) in p1["coded"].items():
        d = json.loads(detail)
        assert CF.item_of(rule)[:3] == ("errors", "nvme_command", CE.item_id("behaviour_01")) and level == "nvme_command" and cmd == row and sev == "error"
        assert d["admin_rule"]["name"] == "A command never completed" and d.get("reason") and d.get("linked")


def test_the_status_sentence_of_the_check_says_that_the_analyses_were_followed_with_real_counts(world):
    job, p0, p1 = world["p1"]["job"], world["p0"], world["p1"]
    a = job["analyses"]
    k0, k1 = numbers_kept(p0["a"]), numbers_kept(p1["a"])
    moved = sum(x != y for key in (KEY_T, KEY_N) for x, y in zip(k0[key], k1[key])) + sum(x != y for x, y in zip(numbers_kept(p0["b"])[KEY_T], numbers_kept(p1["b"])[KEY_T]))
    assert (a["analyses"], a["lists"], a["entries"], a["no_longer_found"], a["not_certain"]) == (2, 3, 20, 0, 0) and a["moved"] == moved > 0
    assert job["analyses_words"] == "the error lists of 2 analyses of this recording were followed too: %d of their 20 entries got a new number" % moved
    assert "analyses_not_followed" not in job
    # the whole end of the status sentence of /nvme-rules is made by the server from these counts (the page only puts it after "of the rules of this page; ")
    n = job["error_numbers_that_moved"]
    assert job["stores_followed"] is True and job["follow_words"] == "%s error numbers moved and were followed in the stores; %s" % ("{:,}".format(n), job["analyses_words"])
    assert world["p2"]["job"]["follow_words"] == world["p2"]["job"]["analyses_words"]              # nothing moved: nothing is said of the stores


# ============================================================================================== 2. a second check changes nothing
def test_a_second_check_changes_nothing(world):
    p1, p2 = world["p1"], world["p2"]
    assert p2["job"]["error_numbers_that_moved"] == 0 and p2["job"]["analyses"]["moved"] == 0 and p2["job"]["analyses"]["elsewhere"] == 0
    assert p2["job"]["analyses_words"] == "the error lists of 2 analyses of this recording were followed too: 0 of their 20 entries got a new number"
    assert p2["who"] == p1["who"] and numbers_kept(p2["a"]) == numbers_kept(p1["a"]) and numbers_kept(p2["b"]) == numbers_kept(p1["b"])
    assert p2["status"] == p1["status"] and p2["mark"] == p1["mark"]
    same_errors_as_before(world, "p2")


# ============================================================================================== 3. a timing limit applied again
def test_a_timing_limit_applied_again_moves_numbers_and_every_link_still_opens_the_same_error(world):
    p2, p3 = world["p2"], world["p3"]
    assert p3["answer"]["changed"] == ["link"] and p3["answer"]["counts"]["link"]["after"] < p3["answer"]["counts"]["link"]["before"]
    assert numbers_kept(p3["a"]) != numbers_kept(p2["a"])                           # the numbers did move
    same_errors_as_before(world, "p3")
    assert p3["status"] == world["p0"]["status"]                                    # the procedural graph is followed on this path too (it was not)
    f = p3["answer"]["analyses"]["link"]
    assert f["analyses"]["analyses"] == 2 and f["analyses"]["moved"] > 0 and f["analyses"]["no_longer_found"] == 0 and p3["answer"]["analyses_not_followed"] == []
    assert p3["coded"] == world["p0"]["coded"]


def test_the_map_of_a_timing_limit_names_each_error_by_what_it_is(tmp_path):
    """The rule's own errors are taken out and filed again under passing numbers: their earlier numbers are found by rule, level and row."""
    import fuzz_app as F
    from nvme_hier import builder as B, loader as L
    db = str(tmp_path / "hier.sqlite")
    L.load_upload(db, {k: os.path.join(S17, n) for k, n in F.NAMES.items()})
    B.build(db)
    RL.apply(db)
    was, out = tree(db), {}
    RL.apply_link_limit(db, {"link": {"ps": 60 * 10 ** 6, "source": "the test"}}, out=out)
    now = tree(db)
    assert out["renumbered"] and "_count" not in out["renumbered"] and out["no_longer_found"]
    for old, what in was.items():
        if old in out["no_longer_found"]:
            assert what[0] == "lnk.response_over_limit" and what not in now.values()
        else:
            assert now[out["renumbered"].get(old, old)] == what
    assert set(out["renumbered"]) | set(out["no_longer_found"]) <= set(was) and len(now) == len(was) - len(out["no_longer_found"])
    # every rule run anew gives the same kind of map (nothing changed in between: nothing moves, nothing is lost)
    out2 = {}
    RL.apply(db, {"link": {"ps": 60 * 10 ** 6, "source": "the test"}}, out=out2)
    assert out2 == {"renumbered": {}, "no_longer_found": []} and tree(db) == now


# ============================================================================================== 4. an error that is no longer found
def test_an_error_that_is_no_longer_found_is_taken_out_and_said(world):
    p3, p4 = world["p3"], world["p4"]
    left = rows_of(p4["page_a"], KEY_T)
    lost = [r for r in TIMEOUT_ROWS if r not in left]
    assert lost and left and set(left) < set(TIMEOUT_ROWS)
    assert all(("cmd.timeout", "nvme_command", r) not in p4["who"].values() for r in lost)              # the tree no longer holds them
    n = len(lost)
    sentence = "After the recording was checked again, %d error%s of the rule 'NVMe command timeout' %s no longer found in it and %s taken out of this list." % (
        n, "" if n == 1 else "s", "is" if n == 1 else "are", "was" if n == 1 else "were")
    for name in ("a", "b"):
        o = next(s for s in p4[name]["steps"] if s["key"] == KEY_T)["output"]
        assert o["no_longer_found"]["count"] == n and o["no_longer_found"]["sentence"] == sentence and o["total"] == len(left) == len(o["errors"])
    assert "<h2>No longer found after the recording was checked again</h2>" in p4["page_a"]["gone"] and sentence in p4["page_a"]["gone"] and sentence in p4["page_b"]["gone"]
    # the errors gate, open while the check ran, says it too; and a command that is now listed under one rule only is not "listed twice" any more
    assert p4["gate"]["state"] == "open" and p4["gate"]["body"].rstrip().endswith("**No longer found after the recording was checked again:**\n- " + sentence)
    assert sorted(g["row"] for g in p4["gate"]["data"]["same_command"]) == sorted(r for r in NEVER_ROWS if r in left)
    assert sorted(r for (key, r) in also_listed(p4["page_a"], p4["who"]) if key == KEY_N) == sorted(r for r in NEVER_ROWS if r in left)
    # the job says how many, of which rule, in which analysis
    a = p4["job"]["analyses"]
    assert a["no_longer_found"] == 2 * n and sorted((x["analysis"], x["rule"], x["errors"]) for x in a["by_rule"]) == [("numbers one", "NVMe command timeout", n), ("numbers two", "NVMe command timeout", n)]
    assert p4["job"]["analyses_words"].endswith("; %d listed errors are no longer found and were taken out of their lists" % (2 * n))
    # the errors that stayed are the same errors, and the family's six are untouched
    assert opened(p4["page_a"], p4["who"])[KEY_T] == [("cmd.timeout", "nvme_command", r) for r in left]
    assert opened(p4["page_a"], p4["who"])[KEY_N] == opened(p3["page_a"], p3["who"])[KEY_N] and p4["status"] == world["p0"]["status"]


def test_the_gate_says_what_left_the_lists_when_it_is_written_later(world):
    """The errors gate written after the check (not only the open card that was amended) carries the same sentences, as its last block."""
    v = world["p4"]["a"]
    steps = copy.deepcopy(v["steps"])

    class E:
        store = None

        def view(self, rid):
            return {"steps": steps}
    ctx = type("C", (), {"engine": E(), "run": {"id": v["run"]["id"]}, "project": {"admin": "t"}})()
    body = pipeline._errors_done(ctx).review["body"]
    want = next(s for s in steps if s["key"] == KEY_T)["output"]["no_longer_found"]["sentence"]
    assert body.endswith("\n\n" + pipeline.NO_LONGER_FOUND + "\n- " + want)


# ============================================================================================== 5. the half-done case
def test_half_done_the_page_would_link_other_errors(world):
    half, p4 = world["half"], world["p4"]
    assert half["moved"] and numbers_kept(half["a"]) == numbers_kept(p4["a"])       # the tree's numbers moved; the analysis's records did not
    assert opened(half["page_a"], half["who"]) != opened(p4["page_a"], p4["who"])   # so its links open other errors now
    assert half["status"]["state"] == "new"                                         # and the finished error's stale number shows "not isolated yet"
    # a look alone says how many numbers are wrong and writes nothing
    assert half["look"]["moved"] > 0 and half["after_look"] == numbers_kept(half["a"])


def test_half_done_the_errors_page_check_corrects_every_number_and_says_so(world):
    p4, p5 = world["p4"], world["p5"]
    ans = p5["answer"]
    assert p5["code"] == 200 and ans["corrected"] == world["half"]["look"]["moved"] > 0 and ans["no_longer_found"] == 0 and ans["not_certain"] == 0
    n = ans["corrected"]
    assert ans["sentence"] == ("The errors of this recording were numbered anew after these lists were made, and the lists had not followed. Now %d error numbers of these "
                               "lists were corrected: each listed error was found again by its rule, its file and its row, and its link opens that error." % n)
    same_errors_as_before(world, "p5", base="p4")
    assert p5["status"] == world["p0"]["status"]                                    # the finished error shows where it stands again
    assert "<h2>The error numbers were checked against the recording</h2>" in p5["page_a"]["checked"] and ans["sentence"] in p5["page_a"]["checked"]
    # asked again, and asked for the other analysis of the same recording (corrected by the same transaction): nothing is wrong, nothing is said
    for again in (p5["again"], p5["other"]):
        assert (again["corrected"], again["no_longer_found"], again["sentence"]) == (0, 0, "") and again["checked"] > 0
    assert p5["no_such"] == 404
    assert rows_of(p5["page_a"], KEY_T) == rows_of(p4["page_a"], KEY_T) and rows_of(p5["page_a"], KEY_N) == NEVER_ROWS


def test_the_page_script_asks_the_server_before_it_draws_a_link():
    js = open(os.path.join(APP, "app", "static", "js", "agents.js"), encoding="utf-8").read()
    page = js[js.index("async function renderErrorsPage("):]
    assert page.index("await errNumbersChecked(v0)") < page.index("await loadErrStatus(v)") < page.index("errHref(pid, o.upload_id, e.finding)")
    assert "/error-numbers`" in js and "errorsNoLongerFound(v)" in page and "errNumbersNote(v)" in page
    # a page left open while the recording is checked again in another tab draws itself again: the listed numbers are part of what the watcher compares
    sig = js[js.index("function sigOf(v) {"):js.index("async function watch() {")]
    assert '+ "|" + errNumbersSig(v);' in sig and "s.output.errors.map(e => e.finding)" in sig


# ============================================================================================== one transaction, with or without the engine
def records(path):
    con = sqlite3.connect("file:%s?mode=ro" % path, uri=True)
    try:
        return con.execute("SELECT id, key, input, output FROM step ORDER BY id").fetchall(), con.execute("SELECT id, title, body, data FROM review ORDER BY id").fetchall()
    finally:
        con.close()


def a_swap(world):
    """Two errors of the timeout list change places: a map made by hand, for the tests on a copy of the records."""
    errs = next(s for s in world["p0"]["a"]["steps"] if s["key"] == KEY_T)["output"]["errors"]
    a, b = errs[0]["finding"], errs[1]["finding"]
    return a, b, {a: b, b: a}


def test_the_records_follow_without_the_engine_and_from_a_path_a_store_or_the_services(world, tmp_path):
    a, b, swap = a_swap(world)
    for k, make in enumerate((lambda p: p, lambda p: core.Store(p), lambda p: type("Services", (), {"root": os.path.dirname(os.path.dirname(p))})())):
        d = tmp_path / ("root%d" % k) / "db"
        d.mkdir(parents=True)
        path = str(d / "agentic.sqlite")
        shutil.copy(os.path.join(world["root"], "records_before.sqlite"), path)
        got = pipeline.follow_renumbering(make(path), world["upload"], swap)           # no tree given: the map alone
        assert (got["analyses"], got["lists"], got["entries"], got["moved"], got["no_longer_found"]) == (2, 3, 20, 4, 0), got
        steps, _reviews = records(path)
        for _id, key, _i, o in steps:
            if key == KEY_T:
                assert [e["finding"] for e in json.loads(o)["errors"]][:2] == [b, a]
            if key == "f3:%s:run" % TIMEOUT:
                assert [x[0] for x in json.loads(o)["head"]][:2] == [b, a]
    # no records file at all (no analysis was ever started): nothing to follow, said as such, no file is made
    empty = tmp_path / "nothing"
    got = pipeline.follow_renumbering(type("Services", (), {"root": str(empty)})(), world["upload"], swap)
    assert got["lists"] == 0 and got["words"] == "no analysis lists an error of this recording, so no error list had to follow" and not empty.exists()


def test_all_records_follow_or_none_and_the_failure_is_said_in_words(world, tmp_path, monkeypatch):
    from api import hier_api
    a, b, swap = a_swap(world)
    path = str(tmp_path / "agentic.sqlite")
    shutil.copy(os.path.join(world["root"], "records_before.sqlite"), path)
    before = records(path)
    real, calls = pipeline._Follow.run, []

    def fails_on_the_second(self, con, run):
        calls.append(run["id"])
        if len(calls) == 2:
            raise OSError("the disk is full")
        return real(self, con, run)
    monkeypatch.setattr(pipeline._Follow, "run", fails_on_the_second)
    with pytest.raises(pipeline.NumbersNotFollowed) as e:
        pipeline.follow_renumbering(path, world["upload"], swap)
    assert len(calls) == 2 and records(path) == before                 # the first analysis's records were changed inside the transaction and put back
    assert str(e.value).startswith("The error lists of the analyses of this recording were not followed (OSError: the disk is full). Nothing was changed in them")
    # the caller of every check puts the failure into its answer in words: it is never swallowed
    calls.clear()
    got = hier_api.follow_in_analyses(path, world["upload"], swap, [], None)
    assert got["analyses_not_followed"] == str(e.value) and got["analyses_words"].startswith("the error lists of the analyses of this recording could NOT be followed")
    assert records(path) == before
    # a map that is not a map of whole numbers changes nothing either
    monkeypatch.setattr(pipeline._Follow, "run", real)
    with pytest.raises(pipeline.NumbersNotFollowed):
        pipeline.follow_renumbering(path, world["upload"], {"x": "y"})
    assert records(path) == before


def test_an_error_named_as_gone_is_taken_out_of_every_record_that_names_it(world, tmp_path):
    """The map alone (no tree): the lists, the result lines, and the gate's note of the commands listed twice."""
    path = str(tmp_path / "agentic.sqlite")
    shutil.copy(os.path.join(world["root"], "records_before.sqlite"), path)
    errs = next(s for s in world["p0"]["a"]["steps"] if s["key"] == KEY_T)["output"]["errors"]
    gone = next(e["finding"] for e in errs if e["row"] == 155)
    got = pipeline.follow_renumbering(path, world["upload"], {}, gone=[gone])
    assert got["no_longer_found"] == 2 and got["moved"] == 0 and got["entries"] == 18
    steps, reviews = records(path)
    seen = 0
    for _id, key, _i, o in steps:
        o = json.loads(o) if o else {}
        if key == KEY_T:
            seen += 1
            assert gone not in [e["finding"] for e in o["errors"]] and len(o["errors"]) == 6 and o["total"] == 6
            assert o["no_longer_found"]["sentence"] == ("After the recording was checked again, 1 error of the rule 'NVMe command timeout' is no longer found in it "
                                                        "and was taken out of this list.")
        if key == "f3:%s:run" % TIMEOUT:
            assert gone not in [x[0] for x in o["head"]]
    assert seen == 2
    gate = next(json.loads(d) for _id, _t, _b, d in reviews if d and json.loads(d).get("errors_overview"))
    assert sorted(g["row"] for g in gate["same_command"]) == [216, 295, 358, 443, 509]       # row 155 is listed under one rule only now
    # a second time with the same word: the error is not in the lists any more, nothing is counted twice
    again = pipeline.follow_renumbering(path, world["upload"], {}, gone=[gone])
    assert again["no_longer_found"] == 0 and again["records_changed"] == 0


def test_a_list_made_before_the_identity_was_kept_is_followed_by_its_rule_its_level_and_its_row(world, tmp_path):
    """The records as they were at the start, with what each error is taken away again (a list of an analysis made before 2026-11-15), against
    the tree as it is at the end (numbered anew several times, no map at hand): an error of the built-in check is found again by its list's
    rule, its level and its row and keeps its identity from then on; an error that cannot be found that way is NOT guessed: its number is
    marked as not certain and counted."""
    path = str(tmp_path / "agentic.sqlite")
    shutil.copy(os.path.join(world["root"], "records_before.sqlite"), path)
    con = sqlite3.connect(path)
    for sid, o in con.execute("SELECT id, output FROM step WHERE key LIKE 'f3:%:errors'").fetchall():
        o = json.loads(o)
        for e in o["errors"]:
            assert e.pop("identity")
            if e["finding"] < 1300:
                e["finding"] += 3               # and the numbers of the built-in check's errors are stale ones: each names another error of the tree now
        con.execute("UPDATE step SET output = ? WHERE id = ?", (json.dumps(o), sid))
    con.commit()
    con.close()
    who = world["p6"]["who"]                                           # the tree now: the family's filed errors are not in it
    got = pipeline.follow_renumbering(path, world["upload"], None, db=world["db"])
    assert (got["analyses"], got["lists"], got["moved"], got["no_longer_found"], got["not_certain"]) == (2, 3, 14, 0, 6) and got["words"].endswith(
        "; for 6 entries the number could not be checked against the recording")
    steps, _reviews = records(path)
    seen = 0
    for _id, key, _i, o in steps:
        o = json.loads(o) if o else {}
        if key == KEY_T:
            seen += 1
            assert [who[e["finding"]] for e in o["errors"]] == [("cmd.timeout", "nvme_command", r) for r in TIMEOUT_ROWS]
            assert all(e["identity"] == {"rule": "cmd.timeout", "level": "nvme_command", "row": e["row"], "nth": 0} and "number_not_certain" not in e for e in o["errors"])
        if key == KEY_N:
            seen += 1
            assert len(o["errors"]) == 6 and all(e["number_not_certain"] is True and "identity" not in e for e in o["errors"])
    assert seen == 3


def test_what_the_page_does_with_the_servers_answer_about_the_numbers(tmp_path):
    """errNumbersChecked of the page script, run by node against a stand-in for the server: a correction makes it read the analysis again and
    keep the server's sentence; a server that fails is said; a server from before this check (no such address) is left in peace."""
    with open(os.path.join(APP, "app", "static", "js", "agents.js"), encoding="utf-8") as fh:
        text = fh.read()
    part = text[text.index("function errorLists(v) {"):text.index("async function loadErrStatus(v) {")]
    part += text[text.index("async function errNumbersChecked(v) {"):text.index("function errCounts(st) {")]
    (tmp_path / "h.cjs").write_text(
        "const esc = s => String(s ?? '');\nconst S = {};\nconst plainDefects = () => [];\nlet mode = 'corrected';\nconst asked = [];\n"
        "async function api(method, url) { asked.push(method + ' ' + url);\n"
        "  if (method === 'GET') return { run: { id: 5 }, steps: [], reviews: [], read_again: true };\n"
        "  if (mode === 'corrected') return { corrected: 2, no_longer_found: 0, found_again: 0, sentence: 'Two numbers were corrected.' };\n"
        "  if (mode === 'right') return { corrected: 0, no_longer_found: 0, found_again: 0, sentence: '' };\n"
        "  const e = new Error(mode === 'old server' ? 'HTTP 404' : 'the records file is locked'); e.status = mode === 'old server' ? 404 : 500; throw e; }\n"
        + part + "\nconst v = { run: { id: 5 }, reviews: [], steps: [{ key: 'f3:errors/nvme_command/x:errors', state: 'done', title: 'x', output: { upload_id: 'u', errors: [{ finding: 3 }] } }] };\n"
        "(async () => { const out = {};\n"
        "  for (const m of ['corrected', 'right', 'old server', 'fails']) { mode = m; S.errNumbers = {}; asked.length = 0; const got = await errNumbersChecked(v);\n"
        "    out[m] = { read_again: !!got.read_again, asked: [...asked], note: errNumbersNote(v) }; }\n"
        "  out.no_list = (await errNumbersChecked({ run: { id: 6 }, steps: [], reviews: [] })).run.id; out.asked_for_no_list = asked.length;\n"
        "  console.log('RESULT ' + JSON.stringify(out)); })();\n", encoding="utf-8")
    p = subprocess.run([NODE, str(tmp_path / "h.cjs")], capture_output=True, text=True, encoding="utf-8", timeout=60)
    line = next((ln for ln in p.stdout.splitlines() if ln.startswith("RESULT ")), None)
    assert line, (p.stdout[-500:], p.stderr[-1500:])
    out = json.loads(line[7:])
    assert out["corrected"]["read_again"] and out["corrected"]["asked"] == ["POST /api/agents/runs/5/error-numbers", "GET /api/agents/runs/5"]
    assert "<h2>The error numbers were checked against the recording</h2>" in out["corrected"]["note"] and "Two numbers were corrected." in out["corrected"]["note"]
    assert out["right"] == {"read_again": False, "asked": ["POST /api/agents/runs/5/error-numbers"], "note": ""}
    assert out["old server"] == {"read_again": False, "asked": ["POST /api/agents/runs/5/error-numbers"], "note": ""}
    assert not out["fails"]["read_again"] and "The numbers of the errors listed here could not be checked against the recording (the records file is locked)." in out["fails"]["note"]
    assert out["no_list"] == 6 and out["asked_for_no_list"] == 1          # an analysis that lists no error asks nothing (the 1 is the question before it)


# ============================================================================================== the mark of the last number given
def test_no_number_is_handed_to_two_errors_after_the_numbers_moved(world):
    m = world["mark"]
    (mark_before, top_before), (mark_after, top_after) = m["before"], m["after"]
    assert m["got"]["added"] == 1 and len(m["numbers"]) == 1
    n = m["numbers"][0]
    assert n > top_before and n > mark_before and n == mark_after == top_after        # above every number in use and every number a rule's error ever had
    marks = [world[p]["mark"][0] for p in ("p0", "p1", "p2", "p3", "p4", "p5")]
    assert marks == sorted(marks) and all(x is not None for x in marks)              # the mark never goes down through the checks
    for p in ("p1", "p2", "p3", "p4", "p5"):                                          # and the rule's errors keep one number each: none is shared, none is lost
        coded = [n_ for n_, x in world[p]["who"].items() if CF.is_coded(x[0])]
        assert len(coded) == len(set(coded)) == 6 and len({world[p]["who"][n_] for n_ in coded}) == 6


# ============================================================================================== 6. every rule run anew
def test_every_rule_run_anew_takes_the_filed_errors_of_a_rule_out_and_the_analysis_says_to_run_it_again(world):
    p6 = world["p6"]
    assert not any(CF.is_coded(x[0]) for x in p6["who"].values()) and p6["coded"] == {}            # the family's six filed errors are gone from the tree
    a = p6["answer"]["analyses"]
    assert a["no_longer_found"] == 6 and [(x["analysis"], x["rule"], x["errors"]) for x in a["by_rule"]] == [("numbers one", "A command never completed", 6)]
    o = next(s for s in p6["a"]["steps"] if s["key"] == KEY_N)["output"]
    sentence = ("After the recording was checked again, 6 errors of the rule 'A command never completed' are no longer found in it and were taken out of this list."
                " The rows this rule finds are errors of the recording only while they are filed for it: if the rule should still find them, run it again in this analysis "
                "(open the analysis again at stage 3 and choose the rule).")
    assert o["errors"] == [] and o["no_longer_found"]["sentence"] == sentence and sentence in p6["page_a"]["gone"]
    assert KEY_N not in [ls["key"] for ls in p6["page_a"]["lists"]]                              # no link is left to an error that is not there
    assert p6["fid"] is None and p6["gate"]["data"]["same_command"] == []
    assert "analyses_not_followed" not in p6["answer"]


def test_an_error_that_is_found_again_is_put_back_where_it_stood(world):
    """Step 6 also took the host limit back to the specification's: the three timeouts that had left the lists at step 4 are in the recording
    again. Each is put back where it stood, under the number it has now; the sentence that said they were gone is gone."""
    p0, p5, p6 = world["p0"], world["p5"], world["p6"]
    assert len(rows_of(p5["page_a"], KEY_T)) == 4 and rows_of(p6["page_a"], KEY_T) == TIMEOUT_ROWS and rows_of(p6["page_b"], KEY_T) == TIMEOUT_ROWS
    assert opened(p6["page_a"], p6["who"])[KEY_T] == opened(p0["page_a"], p0["who"])[KEY_T] == [("cmd.timeout", "nvme_command", r) for r in TIMEOUT_ROWS]
    assert opened(p6["page_b"], p6["who"]) == opened(p0["page_b"], p0["who"])
    for name in ("a", "b"):
        o = next(s for s in p6[name]["steps"] if s["key"] == KEY_T)["output"]
        assert "no_longer_found" not in o and o["total"] == 7
    assert "NVMe command timeout" not in p6["page_a"]["gone"] and p6["page_b"]["gone"] == ""
    a = p6["answer"]["analyses"]
    assert a["found_again"] == 6 and p6["answer"]["analyses_words"].endswith("; 6 errors that had been taken out are found again and are back in their lists")
    assert pipeline.NO_LONGER_FOUND in p6["gate"]["body"] and "NVMe command timeout' are no longer found" not in p6["gate"]["body"]


def test_while_the_recording_is_being_checked_nothing_is_compared_and_it_is_said(world):
    b, p5 = world["busy"], world["p5"]          # (the word was written by hand right after step 5 and taken away again)
    assert b["answer"]["waits"] == b["answer"]["sentence"] and (b["answer"]["corrected"], b["answer"]["no_longer_found"], b["answer"]["checked"]) == (0, 0, 0)
    assert b["answer"]["sentence"].startswith("The errors of this recording are being numbered anew right now (a check of the recording started at 20")
    assert b["answer"]["sentence"].endswith("If no check is running, check the recording again on the page of the NVMe command rules.")
    assert b["follow"]["analyses_not_followed"] == b["answer"]["sentence"] and "analyses" not in b["follow"]
    assert b["kept"] == b["kept_after_follow"] == numbers_kept(p5["a"])               # nothing was changed, by the page's question or by a map handed in meanwhile
    # every real run takes its word away when it has finished
    assert [world[p]["being_numbered"] for p in ("p0", "p1", "p2", "p3", "p4", "half", "p5", "p6")] == [None] * 8
