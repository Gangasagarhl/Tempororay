"""Windows ADK ETL + XML analytics (adk_etl): discovery by content, the XML reader, phases, the xperf parsers, the verdict,
the benchmark and the comparison. Runs without xperf (the parsers are fed xperf's own text); the last test decodes the real
traces on this computer when xperf and the Desktop data are there, and is skipped otherwise.

    python -m pytest -q tests/test_adk_etl.py
"""
import csv
import io
import json
import os
import sys

import pytest

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, APP)

from adk_etl import analyze, compare, config, discover, histogram, phases, store, summary, xmlread, xperf   # noqa: E402

TIMING_XML = """<?xml version="1.0" encoding="utf-8"?>
<AssessmentResult Name="Fast Startup" Iteration="{n}">
  <Metrics>
    <MetricValue Value="{boot}"><ProgrammaticName>FastStartup-Resume-PoweredOnToKernelResumeComplete</ProgrammaticName><Unit>ms</Unit></MetricValue>
    <MetricValue Value="900"><ProgrammaticName>FastStartup-Phase-kernel_to_smss</ProgrammaticName></MetricValue>
  </Metrics>
  <ComponentTimings><ComponentTiming ComponentName="System!Ntfs.sys" Kind="kernel module" TotalCPU="10" TotalDisk="0" DiskOps="0"/>
  <ComponentTiming ComponentName="svchost.exe" Kind="process" TotalCPU="0" TotalDisk="60" DiskOps="49"/></ComponentTimings>
</AssessmentResult>"""


def etl(n=200, fill=1):
    """Bytes that begin like an ETW trace (buffer size 64 KB, the system trace header marker 0x02 0xC0 at 0x4A)."""
    h = bytearray([fill]) * max(n, 0x50)
    h[0:4] = (0x10000).to_bytes(4, "little")
    h[0x4A], h[0x4B] = 0x02, 0xC0
    return bytes(h)


def write(path, text, binary=False):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb" if binary else "w", encoding=None if binary else "utf-8") as f:
        f.write(text)


# ------------------------------------------------------------------------------------------------ names and roles
@pytest.mark.parametrize("name,n", [
    ("FastStartup_Timing_7.xml", 7), ("FastStartup_Timing_10.etl", 10), ("boot 3.etl", 3), ("run(4).etl", 4),
    ("fast_07_boot_7.83s.etl", 7), ("FastStartup_Analysis_1.analysis.xml", 1), ("DESKTOP-3CI491M.FastStartup_1.etl", 1),
    ("FastStartup_Timing_2.events.csv", 2), ("nothing.etl", None)])
def test_number_in_name(name, n):
    assert discover.number_in_name(name) == n


def test_etl_role_from_words_only():
    assert discover.etl_role(r"C:\r\FastStartup_IO_1.etl") == "io"
    assert discover.etl_role(r"C:\r\FastStartup_Analysis_1.etl") == "analysis"
    assert discover.etl_role(r"C:\r\Verbose\host.FastStartup_1.etl") == "verbose"
    assert discover.etl_role(r"C:\r\AxeLog-001.etl") == "infrastructure"
    assert discover.etl_role(r"C:\r\my boot trace 3.etl") == "trace"
    assert discover.etl_role(r"C:\r\radio_3.etl") == "trace"            # "io" inside a word is not the I/O trace


# ------------------------------------------------------------------------------------------------ XML
def test_timing_xml_and_verdict_metric(tmp_path):
    p = str(tmp_path / "whatever.xml")
    write(p, TIMING_XML.format(n=3, boot=12114))
    assert xmlread.sniff(p) == ("timing", {"iteration": 3, "root": "assessmentresult", "problem": None})
    rows, notes = xmlread.read_timing_xml(p)
    assert xmlread.boot_of(rows) == (12114.0, "FastStartup-Resume-PoweredOnToKernelResumeComplete")
    assert {"kind": "phase", "name": "kernel_to_smss", "measure": "duration", "value": 900.0} in rows
    assert {"kind": "module", "name": "Ntfs.sys", "measure": "cpu", "value": 10.0} in rows
    assert any("fallback" in n for n in notes)


def test_overall_metric_wins_over_fallback():
    name, v, how = xmlread.pick_boot_metric({"FastStartup-Resume-PoweredOnToKernelResumeComplete": 5, "FastStartup-Resume-Overall-Time": 9})
    assert (name, v, how) == ("FastStartup-Resume-Overall-Time", 9.0, "exact")
    assert xmlread.pick_boot_metric({"Fast Startup overall time ms": 7})[2] == "keyword"
    assert xmlread.pick_boot_metric({"nothing": 1}) == (None, None, "missing")


def test_other_xml_layouts(tmp_path):
    a = str(tmp_path / "a.xml")
    write(a, '<AssessmentJobResults><Iteration number="2"><Metric name="Boot to desktop" unit="ms" value="14948.0"/>'
             '<Metric name="Phase mainpath" value="9598"/><Activity kind="DriverInit" component="dut.sys" duration_ms="11800"/></Iteration></AssessmentJobResults>')
    rows, _n = xmlread.read_timing_xml(a)
    assert xmlread.boot_of(rows)[0] == 14948.0
    assert {"kind": "driver", "name": "dut.sys", "measure": "duration", "value": 11800.0} in rows
    assert {"kind": "phase", "name": "mainpath", "measure": "duration", "value": 9598.0} in rows
    io_ = str(tmp_path / "b.xml")
    write(io_, '<StartupIO><ProcessIO Name="System" DiskTimeMs="27416" DiskOps="25263"/></StartupIO>')
    assert xmlread.sniff(io_)[0] == "io"
    assert xmlread.read_io_xml(io_)[0] == {"kind": "process", "name": "System", "measure": "disk", "value": 27416.0}
    bad = str(tmp_path / "c.xml")
    write(bad, "Boot action failed: not XML")
    assert xmlread.sniff(bad)[0] == "unreadable"
    assert xmlread.read_timing_xml(bad)[0] == []


# ------------------------------------------------------------------------------------------------ discovery
def test_discovery_by_content_any_layout(tmp_path):
    root = tmp_path / "given"
    job = root / "deep" / "JobResults_PC_1" / "000_Fast-Startup" / "results"
    for n in (1, 2, 3):
        write(str(job / ("FastStartup_Timing_%d.etl" % n)), etl(100), binary=True)
        write(str(job / "001_Fast-Startup" / ("FastStartup_Timing_%d.xml" % n)), TIMING_XML.format(n=n, boot=10000 + n))
    write(str(job / "FastStartup_IO_1.etl"), etl(50), binary=True)
    write(str(job / "AxeLog-000.etl"), etl(50), binary=True)
    write(str(root / "deep" / "JobResults_PC_1" / "backup" / "FastStartup_Timing_2.xml"), TIMING_XML.format(n=2, boot=1))
    # a second run with renamed files, no JobResults folder, the iteration only inside the XML, an empty trace
    other = root / "my failing run"
    write(str(other / "trace 1.etl"), etl(100, 2), binary=True)
    write(str(other / "trace 2.etl"), b"", binary=True)
    write(str(other / "result-a.xml"), TIMING_XML.format(n=1, boot=20000))
    write(str(other / "result-b.xml"), TIMING_XML.format(n=2, boot=21000))
    write(str(other / "notes.txt"), "x")
    inv = discover.discover(str(root))
    assert not inv["errors"]
    runs = {r["label"]: r for r in inv["runs"]}
    assert set(runs) == {"JobResults_PC_1", "my failing run"}
    a = runs["JobResults_PC_1"]
    assert [i["n"] for i in a["iterations"]] == [1, 2, 3]
    assert all(i["etl"] and i["xml"] for i in a["iterations"])
    assert "001_Fast-Startup" in a["iterations"][1]["xml"]                     # the expected place wins over backup\
    assert any("duplicate XML" in x for x in a["ignored"])
    assert a["iterations"][0]["extra_etls"][0]["role"] == "io"
    assert a["infrastructure_etls"] and a["infrastructure_etls"][0].endswith("AxeLog-000.etl")
    b = runs["my failing run"]
    assert [i["n"] for i in b["iterations"]] == [1, 2]
    assert b["iterations"][0]["etl"].endswith("trace 1.etl") and b["iterations"][0]["xml"].endswith("result-a.xml")
    assert b["iterations"][1]["etl"] is None and any("empty file" in p for p in b["problems"])
    assert inv["other_files"] == {".txt": 1}


def test_same_jobresults_name_in_two_folders_gets_two_labels(tmp_path):
    for case in ("case_a", "case_b"):
        write(str(tmp_path / case / "JobResults_X" / "FastStartup_Timing_1.xml"), TIMING_XML.format(n=1, boot=1))
    labels = sorted(r["label"] for r in discover.discover(str(tmp_path))["runs"])
    assert labels == [os.path.join("case_a", "JobResults_X"), os.path.join("case_b", "JobResults_X")]


def test_no_adk_material(tmp_path):
    write(str(tmp_path / "a.csv"), "x,y\n1,2\n")
    write(str(tmp_path / "fake_1.etl"), b"\x00" * 500, binary=True)              # named .etl, but no ETW trace
    inv = discover.discover(str(tmp_path))
    assert inv["errors"] and not discover.looks_like_adk(inv) and inv["csv_files"] == 1
    assert inv["not_traces"] and "not ETW traces" in inv["problems"][0]
    assert discover.is_etl(str(tmp_path / "fake_1.etl")) is False


# ------------------------------------------------------------------------------------------------ phases
def test_timeline_categories():
    procs = [{"name": "System", "start_us": None}, {"name": "smss.exe", "start_us": 2_000_000}, {"name": "smss.exe", "start_us": 3_000_000},
             {"name": "wininit.exe", "start_us": 4_000_000}, {"name": "winlogon.exe", "start_us": 4_100_000},
             {"name": "LogonUI.exe", "start_us": 5_000_000}, {"name": "userinit.exe", "start_us": 9_000_000},
             {"name": "explorer.exe", "start_us": 9_500_000}]
    tl = phases.Timeline(procs, 20_000_000)
    assert tl.boot_ms() == 5000.0
    assert [s["phase"] for s in tl.segments] == ["kernel_to_smss", "smss_to_wininit", "wininit_to_winlogon", "winlogon_to_logonui",
                                                 "logonui_to_userinit", "userinit_to_explorer", "explorer_to_end"]
    assert tl.phase_at(1) == ("kernel_to_smss", "pre_logon")
    assert tl.phase_at(6_000_000) == ("logonui_to_userinit", "logon")
    assert tl.phase_at(19_000_000) == ("explorer_to_end", "post_logon")
    assert tl.category_ms() == {"pre_logon": 5000.0, "logon": 4000.0, "post_logon": 11000.0}
    nolog = phases.Timeline([p for p in procs if p["name"] not in ("userinit.exe", "explorer.exe")], 8_000_000)
    assert nolog.category_at(7_000_000) == "logon"


# ------------------------------------------------------------------------------------------------ xperf text parsers
PROC_TXT = """Start Time,   End Time, Process,            DataPtr,     Process Name ( PID),  ParentPID,  SessionID,          UniqueKey, Command Line
       MIN,        MAX, Process, 0X1,           System (   4),          0,         -1, 0x1, <Unknown>
   1000000,        MAX, Process, 0X2,         smss.exe ( 356),          4,         -1, 0x2, \\SystemRoot\\System32\\smss.exe
   3000000,        MAX, Process, 0X3,      svchost.exe ( 432),        616,          0, 0x3, C:\\Windows\\system32\\svchost.exe -k NetSvcs -p
   4000000,    6000000, Process, 0X4,      LogonUI.exe ( 956),        608,          1, 0x4, "LogonUI.exe" /flags:0x2, more
"""
DISK_TXT = """QD/I - Number of outstanding IOs at IO start time.

   IO Type, Start Time,   End Time,    IO Time,  Disk SrvT,    IO Size,  Byte Offset,  Pri, QD/I, QD/C, IBCB, IBCA, IACB,     Process Name ( PID), Disk, Filename
  DiskRead,     500000,     500245,        245,        245, 0x00000200, 0x0000000000,    3,    0,    0,    0,    0,    0,           System (   4),    0, Unknown (0x0)
  DiskRead,    3500000,    3530000,      30000,      29000, 0x00002000, 0x000c900000,    0,    0,    0,    0,    0,    0,      svchost.exe ( 432),    0, C:\\Windows\\a, b.dll
 DiskFlush,    5000000,    5000600,        600,        590, 0x00000000, 0x0000000000,    0,    0,    0,    0,    0,    0,      LogonUI.exe ( 956),    0, \\Device\\HarddiskVolume3\\$LogFile
"""
DUMP_TXT = """BeginHeader
               DiskRead,  TimeStamp,     Process Name ( PID),   ThreadID, CPU,             IrpPtr,   ByteOffset,     IOSize, ElapsedTime,  DiskNum, IrpFlags, DiskSvcTime, I/O Pri,  VolSnap,         FileObject, FileName
             FileIoRead,  TimeStamp,     Process Name ( PID),   ThreadID, LoggingProcessName ( PID), LoggingThreadID, CPU,             IrpPtr,         FileObject,   ByteOffset,       Size,      Flags, ExtraFlags, Priority, FileName, ParsedFlags
            FileIoOpEnd,  TimeStamp,     Process Name ( PID),   ThreadID, LoggingProcessName ( PID), LoggingThreadID, CPU,             IrpPtr,         FileObject, ElapsedTime,     Status,          ExtraInfo, Type, FileName
   UnknownEvent/Classic,  TimeStamp,     Process Name ( PID),   ThreadID, CPU,                              EventGuid, Type, Level, Version, MofLength
         FileNameCreate,  TimeStamp,         FileObject, FileName, NT FileName
EndHeader
               DiskRead,    500245,           System (   4),          8,   0, 0xa, 0x0, 0x200, 245, 0, 0x0, 245, 3, Original, 0x0, "x"
             FileIoRead,   3600000,      svchost.exe ( 432),  12, svchost.exe ( 432), 12, 0, 0xffff01, 0xf1, 0x0, 0x1000, 0x0, 0x0, 2, "C:\\Windows\\a, b.dll", none
            FileIoOpEnd,   3600500,      svchost.exe ( 432),  12, svchost.exe ( 432), 12, 0, 0xffff01, 0xf1, 500, 0x0, 0x0, 0x0, "C:\\Windows\\a, b.dll"
   UnknownEvent/Classic,   4500000,      LogonUI.exe ( 956),  9, 0, {7687a439-f752-45b8-b741-321aec0f8df9}, 0x0c, 0x00, 0x0002, 48
         FileNameCreate,   4600000,    0xf1, "C:\\x", "\\Device\\x"
"""


def test_xperf_text_parsers(tmp_path):
    pp = str(tmp_path / "p.txt")
    write(pp, PROC_TXT)
    procs = xperf.parse_processes(pp)
    by = {p["name"]: p for p in procs}
    assert by["System"]["start_us"] is None and by["smss.exe"]["start_us"] == 1000000
    assert by["svchost.exe"]["key"] == "svchost.exe (netsvcs)"
    assert by["LogonUI.exe"]["end_us"] == 6000000 and by["LogonUI.exe"]["cmdline"].endswith("more")
    pi = xperf.ProcessIndex(procs)
    dp = str(tmp_path / "d.txt")
    write(dp, DISK_TXT)
    rows = list(xperf.parse_diskio(dp, pi))
    assert [r["command"] for r in rows] == ["DiskRead", "DiskRead", "DiskFlush"]
    assert rows[1]["process"] == "svchost.exe (netsvcs)" and rows[1]["io_time_us"] == 30000 and rows[1]["service_us"] == 29000
    assert rows[1]["file"] == "C:\\Windows\\a, b.dll" and rows[1]["size_bytes"] == 0x2000
    assert xperf.norm_file(rows[2]["file"]) == "\\$logfile" and xperf.norm_file("C:\\$LogFile") == "\\$logfile"
    assert xperf.norm_file("C:\\Users\\Bob\\x.db") == "\\users\\<user>\\x.db"
    tl = phases.Timeline(procs, 7_000_000)
    d = xperf.Dumper(tl, pi, True, True, 10_000)
    d.feed(io.StringIO(DUMP_TXT))
    assert d.file_ops == [{"command": "FileIoRead", "process": "svchost.exe (netsvcs)", "pid": 432, "start_us": 3600000, "end_us": 3600500,
                           "duration_us": 500, "size_bytes": 0x1000, "status": "0x0", "file": "C:\\Windows\\a, b.dll",
                           "phase": tl.phase_at(3600000)[0], "category": "pre_logon"}]
    ev = {(k[0], k[1]): v for k, v in d.census.items()}
    assert ev[("DiskRead", "System")] == 1 and ev[("FileIoOpEnd", "svchost.exe (netsvcs)")] == 1
    assert ev[("Unknown {7687a439-f752-45b8-b741-321aec0f8df9} type 0x0c", "LogonUI.exe")] == 1
    assert ev[("FileNameCreate", "(no process)")] == 1
    assert d.last_ts == 4600000


# ------------------------------------------------------------------------------------------------ verdict, benchmark, comparison
def _fake_decode(tmp_path, spec):
    """spec: {etl path: {"logonui_us", "disk": [(process, command, start_us, io_us, file)]}} -> a decode() that writes the CSVs."""
    def decode(etl, cache_root, cfg=None, progress=None):
        s = spec[etl]
        out = os.path.join(str(tmp_path), "cache", os.path.basename(os.path.dirname(etl)) + "_" + os.path.basename(etl))
        os.makedirs(out, exist_ok=True)
        procs = [{"key": "smss.exe", "name": "smss.exe", "pid": 1, "start_us": 1000, "end_us": None},
                 {"key": "LogonUI.exe", "name": "LogonUI.exe", "pid": 2, "start_us": s["logonui_us"], "end_us": None},
                 {"key": "userinit.exe", "name": "userinit.exe", "pid": 3, "start_us": s["logonui_us"] + 1000, "end_us": None}]
        procs += [{"key": p, "name": p, "pid": 10 + i, "start_us": 2000, "end_us": None} for i, p in enumerate(sorted({d[0] for d in s["disk"]}))]
        tl = phases.Timeline(procs, s["logonui_us"] + 10_000_000)
        for p in procs:
            p["phase"], p["category"] = tl.phase_at(p["start_us"])
            p["lifetime_ms"] = None
        disk = []
        for proc, cmd, st, us, f in s["disk"]:
            ph, cat = tl.phase_at(st)
            disk.append({"command": cmd, "process": proc, "pid": 0, "start_us": st, "end_us": st + us, "io_time_us": us, "service_us": us,
                         "size_bytes": 4096, "file": f, "phase": ph, "category": cat})
        files = {k: os.path.join(out, k + ".csv") for k in ("processes", "disk_commands", "file_commands", "census", "phases")}
        xperf._write_csv(files["processes"], procs, xperf.PROC_FIELDS)
        xperf._write_csv(files["disk_commands"], disk, xperf.DISK_FIELDS)
        xperf._write_csv(files["file_commands"], [], xperf.FILE_FIELDS)
        xperf._write_csv(files["census"], [{"event": "DiskRead", "process": d["process"], "phase": d["phase"], "category": d["category"], "count": 1} for d in disk], xperf.CENSUS_FIELDS)
        xperf._write_csv(files["phases"], tl.segments, xperf.PHASE_FIELDS)
        return {"etl": etl, "dir": out, "files": files, "timeline": tl.as_dict(), "counts": {"disk_commands": len(disk)}, "notes": [], "cached": False}
    return decode


def _make_run(root, name, boots, etl_spec, spec, disk_of):
    for n, boot in enumerate(boots, 1):
        path = os.path.join(root, name, "trace_%d.etl" % n)
        write(path, etl(10), binary=True)
        if boot is not None:
            write(os.path.join(root, name, "timing_%d.xml" % n), TIMING_XML.format(n=n, boot=boot))
        spec[path] = {"logonui_us": etl_spec, "disk": disk_of(n)}


def test_verdict_benchmark_and_comparison(tmp_path, monkeypatch):
    root = str(tmp_path / "in")
    spec = {}
    ok_disk = lambda n: [("svchost.exe", "DiskRead", 2_000_000, 1000, "C:\\a.dll"), ("System", "DiskWrite", 2_500_000, 500, "C:\\$LogFile")]   # noqa: E731
    bad_disk = lambda n: ok_disk(n) + [("svchost.exe", "DiskRead", 2_100_000, 90_000, "C:\\Windows\\slow.dll"),                             # noqa: E731
                                       ("newproc.exe", "DiskFlush", 9_000_000 + 2000, 5000, "C:\\x")]
    _make_run(root, "pass_a", [12000, 13000], 5_000_000, spec, ok_disk)
    _make_run(root, "pass_b", [14000, 14000], 5_000_000, spec, ok_disk)          # exactly the limit is PASS
    _make_run(root, "fail", [16000, 15000], 8_000_000, spec, bad_disk)
    _make_run(root, "trace_only", [None], 4_000_000, spec, ok_disk)              # no XML: the time comes from the trace
    monkeypatch.setattr(xperf, "decode", _fake_decode(tmp_path, spec))
    st = store.Store(str(tmp_path / "db" / "adk.sqlite"))
    res = analyze.analyze_folder(root, 7, st, None, str(tmp_path / "cache"))
    assert not res["errors"]
    runs = {r["label"]: r for r in st.runs(7)}
    assert {k: (v["verdict"], v["boot_mean_ms"]) for k, v in runs.items()} == {
        "pass_a": ("PASS", 12500.0), "pass_b": ("PASS", 14000.0), "fail": ("FAIL", 15500.0), "trace_only": ("PASS", 4000.0)}
    assert runs["trace_only"]["boot_source"] == "trace: start of LogonUI.exe"
    # analysing again replaces, never duplicates
    analyze.analyze_folder(root, 7, st, None, str(tmp_path / "cache"), only_runs=[discover.run_id_of(os.path.join(root, "fail"))])
    assert len(st.runs(7)) == 4
    fail_id = next(r["id"] for r in st.runs(7) if r["label"] == "fail")
    b = compare.benchmark(st, 7, exclude=fail_id)
    assert b["n_runs"] == 3 and round(b["boot_mean_ms"], 1) == round((12500 + 14000 + 4000) / 3, 1)
    res = compare.compare(st, fail_id, 7)
    assert res["boot"]["delta_ms"] == round(15500 - (12500 + 14000 + 4000) / 3, 1)
    top = res["by_category"]["pre_logon"][0]
    assert top["process"] == "svchost.exe" and top["delta_disk_us"] == 90000.0
    cmd = top["commands"][0]
    assert (cmd["command"], cmd["run_count"], cmd["bench_count"], cmd["delta_us"]) == ("DiskRead", 2.0, 1.0, 90000.0)
    assert cmd["files"][0]["file"] == "\\windows\\slow.dll" and cmd["files"][0]["bench_us"] == 0.0
    post = res["by_category"]["post_logon"]
    assert post[0]["process"] == "newproc.exe" and post[0]["new"] is True
    assert any(p["process"] == "newproc.exe" for p in res["new_processes"])
    assert next(p for p in res["phases"] if p["phase"] == "winlogon_to_logonui" or p["phase"] == "smss_to_logonui")["delta_ms"] > 0
    text = summary.written(res)
    assert "FAIL" in text and "svchost.exe" in text and "DiskRead" in text
    rows = compare.flat_rows(res, "file")
    assert any(r["file"] == "\\windows\\slow.dll" and r["category"] == "pre_logon" for r in rows)
    # latency (increment 2): the slow 90 ms read lands in the doubling bucket [80, 160) ms of the run only
    lat = {x["command"]: x for x in res["latency"]["pre_logon"]}
    assert lat["DiskRead"]["run"]["count"] == 2.0 and lat["DiskRead"]["bench"]["count"] == 1.0
    assert lat["DiskRead"]["above_10ms_pct"] == {"run": 50.0, "bench": 0.0}
    bench_ids = [b["id"] for b in res["benchmark"]["runs"]]
    h = histogram.compare_hist(st, fail_id, bench_ids, "pre_logon", "svchost.exe", "DiskRead", "disk")
    assert [(b["lo_us"], b["run"], b["bench"]) for b in h["buckets"]] == [(1000, 1.0, 1.0), (80000, 1.0, 0.0)]
    assert h["buckets_that_grew"][0]["lo_us"] == 80000
    assert "Latency of DiskRead" in summary.written(res)
    # stored before increment 2 / another bucket width: rebuilt from the decoded CSVs
    st.exec("DELETE FROM histogram WHERE run=?", (fail_id,))
    st.exec("DELETE FROM hist_meta WHERE run=?", (fail_id,))
    assert histogram.ensure(st, fail_id) == 2 and histogram.ensure(st, fail_id) == 0
    assert histogram.ensure(st, fail_id, {"adk_etl": {"hist_bucket_us": 1000}}) == 2
    assert {(r["lo_us"], r["hi_us"]) for r in st.all("SELECT lo_us, hi_us FROM histogram WHERE run=? AND command='DiskRead'", (fail_id,))} == {(1000, 2000), (80000, 160000)}
    histogram.ensure(st, fail_id)
    # a PASS run taken out of the benchmark is not pooled
    pa = next(r["id"] for r in st.runs(7) if r["label"] == "pass_a")
    st.exec("UPDATE run SET in_benchmark=0 WHERE id=?", (pa,))
    assert compare.benchmark(st, 7, exclude=fail_id)["n_runs"] == 2
    st.exec("UPDATE run SET in_benchmark=0")
    assert "no PASS run" in compare.compare(st, fail_id, 7)["error"]


def test_model_summary_numbers_are_checked():
    res = {"run": {"label": "r", "verdict": "FAIL", "boot_mean_ms": 20000.0, "iterations": 2, "traced": 2, "boot_values": [20000.0]},
           "benchmark": {"n_runs": 1, "scope": "this analysis", "boot_mean_ms": 12000.0}, "limit_ms": 14000.0,
           "boot": {"run_ms": 20000.0, "bench_ms": 12000.0, "delta_ms": 8000.0, "delta_pct": 66.7}, "categories": [], "phases": [],
           "by_category": {"all": []}, "events": [], "new_processes": []}

    class FakeLLM:
        name = "fake"

        def generate_json(self, prompt, schema, max_tokens=None):
            return {"summary": "The run took 20000 ms against 12000 ms. It lost 5555 ms in smss.", "findings": [], "likely_causes": ["x"]}, False
    out = summary.summarise(res, FakeLLM())
    assert out["model_text"] == "The run took 20000 ms against 12000 ms."
    assert out["unchecked"] == ["It lost 5555 ms in smss."]
    assert summary.summarise(res, None)["by"] == "the program"


# ------------------------------------------------------------------------------------------------ I/O latency histograms (increment 2)
def test_buckets_are_5us_then_doubling():
    assert histogram.bucket(0) == (0, 5) and histogram.bucket(4.9) == (0, 5) and histogram.bucket(5) == (5, 10)
    assert histogram.bucket(237) == (235, 240) and histogram.bucket(9999) == (9995, 10000)
    assert histogram.bucket(10000) == (10000, 20000) and histogram.bucket(25000) == (20000, 40000)
    assert histogram.bucket(1_893_541) == (1_280_000, 2_560_000)
    assert histogram.bucket(25000, 5, 0) == (25000, 25005)                     # fine_max 0: 5 µs everywhere
    assert histogram.bucket(237, 10, 10000) == (230, 240)
    s = histogram.settings({"adk_etl": {"hist_bucket_us": 0, "hist_measure": "nonsense"}})        # 0 / unknown: the defaults
    assert s == {"width": 5, "fine_max": 10000, "measure": "io_time_us"}
    assert histogram.settings({"adk_etl": {"hist_bucket_us": 2, "hist_fine_max_us": 0}})["fine_max"] == 0


def test_histogram_build_and_stats():
    disk = [{"process": "a.exe", "command": "DiskRead", "category": "pre_logon", "io_time_us": v, "service_us": v / 2}
            for v in (101, 102, 104, 106, 250, 12000)]
    files = [{"process": "a.exe", "command": "FileIoRead", "category": "logon", "duration_us": 7}]
    rows = {(r["source"], r["command"], r["lo_us"], r["hi_us"]): r["count"] for r in histogram.build(disk, files)}
    assert rows == {("disk", "DiskRead", 100, 105): 3, ("disk", "DiskRead", 105, 110): 1, ("disk", "DiskRead", 250, 255): 1,
                    ("disk", "DiskRead", 10000, 20000): 1, ("file", "FileIoRead", 5, 10): 1}
    svc = histogram.build(disk, [], {"adk_etl": {"hist_measure": "service_us"}})
    assert sorted((r["lo_us"], r["count"]) for r in svc) == [(50, 4), (125, 1), (6000, 1)]
    h = {(100, 105): 3, (105, 110): 1, (250, 255): 1, (10000, 20000): 1}
    st = histogram.stats(h)
    assert st["count"] == 6 and st["p50_us"] == 105.0 and st["max_bucket_us"] == [10000, 20000]     # 3 of 6 fill [100, 105)
    assert 250 <= st["p90_us"] <= 20000 and st["p99_us"] > 10000
    assert histogram.share_above(h, 1000) == round(100 / 6, 2)
    assert histogram.stats({})["p50_us"] is None


def test_flushes_come_from_the_events():
    procs = [{"name": "System", "pid": 4, "start_us": None, "end_us": None, "key": "System"},
             {"name": "app.exe", "pid": 77, "start_us": 100, "end_us": None, "key": "app.exe"}]
    head = ("BeginHeader\n DiskFlush,  TimeStamp,     Process Name ( PID),   ThreadID, CPU,             IrpPtr,                           ElapsedTime,  DiskNum, IrpFlags, DiskSvcTime, I/O Pri\n"
            " DiskFlushInit,  TimeStamp,     Process Name ( PID),   ThreadID, CPU,             IrpPtr, Current Process Name ( PID), Current ThreadID\nEndHeader\n")
    data = (" DiskFlushInit, 5000, app.exe (  77), 9, 0, 0xaa, app.exe (  77), 9\n"
            " DiskFlush, 5900, System (   4), 8, 0, 0xaa, 900, 0, 0x0, 880, 0\n"
            " DiskFlush, 8000, System (   4), 8, 0, 0xbb, 300, 0, 0x0, 290, 0\n")
    tl = phases.Timeline(procs, 10000)
    d = xperf.Dumper(tl, xperf.ProcessIndex(procs), False, False, 1000)
    d.feed(io.StringIO(head + data))
    assert [(f["process"], f["start_us"], f["io_time_us"], f["service_us"], f["issuer"]) for f in d.flushes] == [
        ("app.exe", 5000, 900, 880, "DiskFlushInit"), ("System", 7700, 300, 290, "completion")]
    assert d.flush_init_seen


# ------------------------------------------------------------------------------------------------ every command under every process
ALL_DUMP = """BeginHeader
                CSwitch,  TimeStamp, New Process Name ( PID),    New TID, NPri, NQnt, TmSinceLast, WaitTime, Old Process Name ( PID),    Old TID, OPri, OQnt,        OldState,      Wait Reason, Swapable, InSwitchTime, CPU, IdealProc
         SampledProfile,  TimeStamp,     Process Name ( PID),   ThreadID,           PrgrmCtr, CPU, ThreadStartImage!Function,            Image!Function, Count, SampledProfile type
              HardFault,  TimeStamp,     Process Name ( PID),   ThreadID,        VirtualAddr,   ByteOffset,     IOSize, ElapsedTime,         FileObject, FileName, Hardfaulted Address Information
                    DPC,  TimeStamp, ElapsedTime, CPU,        ServiceAddr,            Image!Function
                P-Start,  TimeStamp,     Process Name ( PID),  ParentPID,  SessionID,          UniqueKey, DirectoryTableBase, Flags, UserSid, Command Line, Package Full Name, Package Relative Application Id
                  P-End,  TimeStamp,     Process Name ( PID),  ParentPID,  SessionID,          UniqueKey,     Status, DirectoryTableBase, Flags, UserSid, Command Line, Package Full Name, Package Relative Application Id
                T-Start,  TimeStamp,     Process Name ( PID),   ThreadID,          StackBase,         StackLimit,         UsrStkBase,          UsrStkLmt,            TebBase, SubProcessTag, BasePri, PagePri, IoPri, Flags,            Image!Function
                  T-End,  TimeStamp,     Process Name ( PID),   ThreadID,          StackBase,         StackLimit,         UsrStkBase,          UsrStkLmt,            TebBase, SubProcessTag, BasePri, PagePri, IoPri, Flags,            Image!Function
                I-Start,  TimeStamp,     Process Name ( PID),           BaseAddr,            EndAddr,   Checksum, TimeDateStamp,        DefaultBase, FileName, Relocated, NT FileName
              I-DCStart,  TimeStamp,     Process Name ( PID),           BaseAddr,            EndAddr,   Checksum, TimeDateStamp,        DefaultBase, FileName, Relocated, NT FileName
Microsoft-Windows-Kernel-PnP/DriverInit/win:Start,  TimeStamp,     Process Name ( PID),   ThreadID, CPU, etw:ActivityId, etw:Related ActivityId, etw:UserSid, etw:SessionId, DriverNameLength, DriverName
Microsoft-Windows-Kernel-PnP/DriverInit/win:Stop,  TimeStamp,     Process Name ( PID),   ThreadID, CPU, etw:ActivityId, etw:Related ActivityId, etw:UserSid, etw:SessionId, DriverNameLength, DriverName, Status
Microsoft-Windows-CodeIntegrity/ValidateImageHeader/win:Start,  TimeStamp,     Process Name ( PID),   ThreadID, CPU, etw:ActivityId, etw:Related ActivityId, etw:UserSid, etw:SessionId, FileNameLength, FileNameBuffer, SecureRequired
Microsoft-Windows-CodeIntegrity/ValidateImageHeader/win:Stop,  TimeStamp,     Process Name ( PID),   ThreadID, CPU, etw:ActivityId, etw:Related ActivityId, etw:UserSid, etw:SessionId, Status
Microsoft-Windows-Kernel-Prefetch/ScenarioDecision/win:Info,  TimeStamp,     Process Name ( PID),   ThreadID, CPU, etw:ActivityId, etw:Related ActivityId, etw:UserSid, etw:SessionId, NameLength, Name, Decision
             GroupMasks,  TimeStamp, Index, Mask
EndHeader
                CSwitch,   1000, app.exe ( 77), 9, 8, -1, 0, 0, Idle (   0), 0, 0, -1, Running, Executive, NonSwap, 0, 0, 0
                CSwitch,   1600, System (   4), 8, 8, -1, 0, 0, app.exe ( 77), 9, 0, -1, Waiting, PageIn, NonSwap, 0, 0, 0
                CSwitch,   1700, app.exe ( 77), 9, 8, -1, 0, 0, System (   4), 8, 0, -1, Waiting, Executive, NonSwap, 0, 0, 0
                CSwitch,   2000, Idle (   0), 0, 8, -1, 0, 0, app.exe ( 77), 9, 0, -1, Ready, Unknown, NonSwap, 0, 0, 0
         SampledProfile,   1100, app.exe ( 77), 9, 0x1, 0, ntdll.dll!0x7ff, Ntfs.sys!0xfff, 2, Unbatched
         SampledProfile,   1200, app.exe ( 77), 9, 0x1, 0, ntdll.dll!0x7ff, ntoskrnl.exe!0xfff, 1, Unbatched
              HardFault,   1300, app.exe ( 77), 9, 0x0, 0x0, 0x1000, 250, 0xf1, "C:\\Windows\\a, b.dll", N/A
                    DPC,   1400, 55, 0, 0xfff, storport.sys!0xfffff806
                P-Start,   3000, child.exe ( 88), 77, 1, 0x1, 0x1, 0, S-1, child.exe -x, y, ,
                  P-End,   7000, child.exe ( 88), 77, 1, 0x1, 0, 0x1, 0, S-1, child.exe -x, y, ,
                T-Start,   3100, app.exe ( 77), 12, 0, 0, 0, 0, 0, 0, 8, 5, 2, 0, ntdll.dll!0x00007ffbe5676830
                  T-End,   4100, app.exe ( 77), 12, 0, 0, 0, 0, 0, 0, 8, 5, 2, 0, ntdll.dll!0x00007ffbe5676830
                I-Start,   3200, app.exe ( 77), 0x1, 0x2, 0, 0, 0, \\Device\\HarddiskVolume3\\Windows\\x.dll, 0, \\x
              I-DCStart,   3200, app.exe ( 77), 0x1, 0x2, 0, 0, 0, \\Device\\HarddiskVolume3\\Windows\\y.dll, 0, \\y
Microsoft-Windows-Kernel-PnP/DriverInit/win:Start,   5000, System (   4), 8, 0, , , , , 53, "\\REGISTRY\\MACHINE\\SYSTEM\\Services\\cdrom"
Microsoft-Windows-Kernel-PnP/DriverInit/win:Stop,   5900, System (   4), 8, 0, , , , , 53, "\\REGISTRY\\MACHINE\\SYSTEM\\Services\\cdrom", 0
Microsoft-Windows-CodeIntegrity/ValidateImageHeader/win:Start,   6000, System (   4), 8, 0, {aa}, , , , 38, "\\windows\\System32\\drivers\\x.sys", 1
Microsoft-Windows-CodeIntegrity/ValidateImageHeader/win:Stop,   6400, System (   4), 99, 0, {aa}, , , , 0x0
Microsoft-Windows-Kernel-Prefetch/ScenarioDecision/win:Info,   6500, System (   4), 8, 0, , , , , 12, "WEVTUTIL.EXE", 0
             GroupMasks,   6600, 1, 0x0
"""


def test_every_command_under_every_process():
    from adk_etl import commands
    procs = [{"name": "System", "pid": 4, "start_us": None, "end_us": None, "key": "System"},
             {"name": "Idle", "pid": 0, "start_us": None, "end_us": None, "key": "Idle"},
             {"name": "app.exe", "pid": 77, "start_us": 500, "end_us": None, "key": "app.exe"},
             {"name": "child.exe", "pid": 88, "start_us": 3000, "end_us": 7000, "key": "child.exe"}]
    pi = xperf.ProcessIndex(procs)
    tl = phases.Timeline(procs, 10000)
    d = xperf.Dumper(tl, pi, True, False, 10000)
    d.cmds = commands.AllCommands(pi, d.resolve, tl.category_at)
    d.feed(io.StringIO(ALL_DUMP))
    d.cmds.add_timed("app.exe", "DiskRead", "pre_logon", 300.0, "\\x.dll", "disk")
    rows = {(r["process"], r["command"]): r for r in d.cmds.rows()}
    objs = {(o["process"], o["command"], o["object"]): o for o in d.cmds.object_rows()}
    # CPU run time from context switches: app.exe ran 1000->1600 and 1700->2000 on CPU 0; System 1600->1700
    assert rows[("app.exe", "CPU (run time)")]["total_us"] == 900.0 and rows[("app.exe", "CPU (run time)")]["count"] == 2
    assert rows[("System", "CPU (run time)")]["total_us"] == 100.0
    assert objs[("app.exe", "Wait (switched out)", "PageIn")]["count"] == 1 and objs[("System", "Wait (switched out)", "Executive")]["count"] == 1
    # sampled CPU per module (Count = 2 samples for Ntfs.sys)
    assert rows[("app.exe", "CPU (sampled)")]["count"] == 3 and rows[("app.exe", "CPU (sampled)")]["total_us"] == 3000.0
    assert objs[("app.exe", "CPU (sampled)", "Ntfs.sys")]["total_us"] == 2000.0
    # an event with its own ElapsedTime, its file with a comma
    assert rows[("app.exe", "HardFault")]["total_us"] == 250.0 and ("app.exe", "HardFault", "C:\\Windows\\a, b.dll") in objs
    # DPCs have no process: counted under the drivers, by module
    assert objs[(commands.NO_PROC_DRIVERS, "DPC", "storport.sys")]["total_us"] == 55.0
    # a child process the .exe started (its command line, its lifetime) and a thread (its start module, its lifetime)
    sp = rows[("app.exe", "Start process")]
    assert sp["count"] == 1 and sp["total_us"] == 4000.0 and "lifetime" in sp["basis"]
    assert any(k[0] == "app.exe" and k[1] == "Start process" and k[2].startswith("child.exe child.exe -x, y") for k in objs)
    assert rows[("app.exe", "Create thread")]["total_us"] == 1000.0 and ("app.exe", "Create thread", "ntdll.dll") in objs
    # images: a load counts, a rundown snapshot does not; metadata is no command
    assert rows[("app.exe", "Load image (I-Start)")]["count"] == 1
    assert not any(c in ("I-DCStart", "GroupMasks") for _p, c in rows)
    # begin -> end pairs: on process + thread, or on the activity id (the Stop comes from another thread)
    di = rows[("System", "Microsoft-Windows-Kernel-PnP/DriverInit")]
    assert (di["count"], di["timed"], di["total_us"]) == (1, 1, 900.0)
    assert ("System", "Microsoft-Windows-Kernel-PnP/DriverInit", "\\REGISTRY\\MACHINE\\SYSTEM\\Services\\cdrom") in objs
    ci = rows[("System", "Microsoft-Windows-CodeIntegrity/ValidateImageHeader")]
    assert (ci["timed"], ci["total_us"]) == (1, 400.0) and ("System", "Microsoft-Windows-CodeIntegrity/ValidateImageHeader", "\\windows\\System32\\drivers\\x.sys") in objs
    # a provider's single event: counted, its first quoted value is its object
    assert ("System", "Microsoft-Windows-Kernel-Prefetch/ScenarioDecision/win:Info", "WEVTUTIL.EXE") in objs
    assert rows[("app.exe", "DiskRead")]["basis"].startswith("IO time")
    # 5 µs buckets of the timed commands that are not disk / file I/O
    b = {(r["process"], r["command"], r["lo_us"]) for r in d.cmds.bucket_rows()}
    assert ("System", "Microsoft-Windows-Kernel-PnP/DriverInit", 900) in b and ("app.exe", "HardFault", 250) in b
    assert not any(c == "DiskRead" for _p, c, _l in b)


def test_every_command_comparison(tmp_path):
    st = store.Store(str(tmp_path / "a.sqlite"))
    ids = []
    for label, rows in (("pass", [("System", "DiskRead", 100, 2000, "IO time"), ("app.exe", "Create thread", 2, 500000, "thread lifetime")]),
                        ("fail", [("System", "DiskRead", 300, 9000, "IO time"), ("System", "Microsoft-Windows-X/Stall", 1, 128000000, "begin -> end"),
                                  ("app.exe", "Create thread", 2, 9000000, "thread lifetime"), ("Idle", "CPU (run time)", 9, 9e9, "CPU run time"),
                                  ("app.exe", "DiskRead", 10, 500, "IO time")])):
        rid = st.new_run(1, label, label, "f", "d/" + label, 14000)
        st.finish_run(rid, status="done", verdict="PASS" if label == "pass" else "FAIL", boot_mean_ms=1.0)
        st.exec("INSERT INTO phase (run, n, phase, category, start_ms, duration_ms) VALUES (?,?,?,?,?,?)", (rid, 1, "kernel_to_smss", "pre_logon", 0, 1))
        st.many("INSERT INTO command_all (run, n, process, command, category, count, timed, total_us, max_us, basis) VALUES (?,?,?,?,?,?,?,?,?,?)",
                [(rid, 1, p, c, "pre_logon", n, n, t, t / n, b) for p, c, n, t, b in rows])
        st.exec("INSERT INTO command_all_object (run, n, process, command, category, object, count, total_us, max_us) VALUES (?,?,?,?,?,?,?,?,?)",
                (rid, 1, "System", "DiskRead", "pre_logon", "\\$mft", 50, rows[0][3] / 2, 9))
        ids.append(rid)
    ra, ba = compare.all_commands_of(st, ids[1]), compare.all_commands_bench(st, [ids[0]])
    t = compare.all_commands_table(ra, ba, "pre_logon")
    assert [p["process"] for p in t] == ["System", "app.exe"]                  # Idle is not a process; measured differences first
    sysc = {c["command"]: c for c in t[0]["commands"]}
    assert t[0]["top_command"] == "DiskRead" and t[0]["top_delta_us"] == 7000.0
    assert sysc["Microsoft-Windows-X/Stall"]["recorded_in_bench"] is False
    assert t[0]["top_run_command"] == "Microsoft-Windows-X/Stall"
    app = t[1]["commands"]
    assert app[0]["command"] == "DiskRead" and app[-1]["command"] == "Create thread" and app[-1]["lifetime"]
    assert compare.all_commands_table(ra, ba, "pre_logon", sort="longest")[0]["process"] == "System"
    assert any(p["process"] == "Idle" for p in compare.all_commands_table(ra, ba, "pre_logon", process="Idle"))
    objs = compare.command_objects(st, ids[1], [ids[0]], "pre_logon", "System", "DiskRead")
    assert objs[0]["object"] == "\\$mft" and objs[0]["delta_us"] == 3500.0


def test_config_defaults():
    s = config.settings({"adk_etl": {"limit_ms": 9000}})
    assert s["limit_ms"] == 9000 and config.settings(None)["limit_ms"] == 14000


# ------------------------------------------------------------------------------------------------ the real traces (this computer)
REAL = r"C:\Users\User\Desktop\etl files\adk_trace_data\path"


@pytest.mark.skipif(not (os.path.isdir(REAL) and config.find_xperf()), reason="needs xperf and the ADK traces on the Desktop")
def test_real_adk_traces(tmp_path):
    st = store.Store(str(tmp_path / "adk.sqlite"))
    analyze.analyze_folder(REAL, 1, st, None, str(tmp_path / "cache"))
    runs = {r["verdict"]: r for r in st.runs(1)}
    assert runs["PASS"]["boot_mean_ms"] == 12114.0 and runs["FAIL"]["boot_mean_ms"] == 141263.0
    res = compare.compare(st, runs["FAIL"]["id"], 1)
    worst = max(res["phases"], key=lambda p: p["delta_ms"])
    assert worst["phase"] == "smss_to_wininit" and worst["delta_ms"] > 100_000
    assert res["by_category"]["pre_logon"][0]["commands"][0]["command"].startswith("Disk")
    # every command under every process: the 128 s volume-snapshot wait and Ntfs.sys CPU under System, before the logon screen
    sysp = next(p for p in res["all_commands_longest"]["pre_logon"] if p["process"] == "System")
    names = {c["command"] for c in compare.all_commands_table(compare.all_commands_of(st, runs["FAIL"]["id"], "System"),
                                                             compare.all_commands_bench(st, [runs["PASS"]["id"]], "System"), "pre_logon", "System")[0]["commands"]}
    assert "Microsoft-Windows-VolumeSnapshot-Driver/vs:VolumeSafe" in names and "CPU (sampled)" in names and sysp["top_run_us"] > 100e6
    cpu = compare.command_objects(st, runs["FAIL"]["id"], [runs["PASS"]["id"]], "pre_logon", "System", "CPU (sampled)")
    assert cpu[0]["object"] == "Ntfs.sys" and cpu[0]["run_us"] > 100e6
