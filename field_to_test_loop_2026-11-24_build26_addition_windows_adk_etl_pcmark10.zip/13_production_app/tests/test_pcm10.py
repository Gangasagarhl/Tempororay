"""PCMark 10 Storage results (pcm10): UL's names, the reader in every layout, discovery by content, the baseline, the comparison,
and the routes. The inputs are synthetic (pcm10/synth.py): no real PCMark 10 result file was available.

    python -m pytest -q tests/test_pcm10.py
"""
import os
import sys
import zipfile

import pytest

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, APP)
from pcm10 import analyze, catalog, compare, discover, reader, store, summary, synth   # noqa: E402


@pytest.mark.parametrize("name,parts", [
    ("rw_bw", ("rw", "bw")), ("read_s_rnd_at9999", ("read_s_rnd", "at9999")), ("write_l_aat", ("write_l", "aat")),
    ("READ_SEQ_AT99", ("read_seq", "at99")), ("flush_count", ("flush", "count")), ("all_notbusy", ("all", "notbusy")),
    ("foo_bw", ("foo", "bw")), ("bytes_read", (None, None)), ("busy", (None, None))])
def test_metric_names(name, parts):
    assert catalog.split_metric(name) == parts


def test_better_direction():
    assert catalog.better("bw") == "higher" and catalog.better("at99") == "lower" and catalog.better("count") is None
    assert compare.worse_pct("bw", 80.0, 100.0) == 20.0 and compare.worse_pct("aat", 120.0, 100.0) == 20.0
    assert compare.worse_pct("bw", 120.0, 100.0) == -20.0 and compare.worse_pct("count", 1, 2) is None


def test_decode_and_separators():
    assert reader.decode("type,trace\n".encode("utf-16"))[0].startswith("type")
    assert reader.decode(b"\xef\xbb\xbftype;trace\n") == ("type;trace\n", "utf-8-sig")
    t = reader.parse_csv("type;trace;rw_bw\naggregated;all_traces;1.234,5\ntrace;boo;987,25\n")
    assert t["separator"] == ";" and t["decimal_comma"] is True
    assert reader.num("1.234,5", True) == 1234.5 and reader.num("1,234.5") == 1234.5 and reader.num("n/a") is None


def test_layouts_wide_long_transposed():
    wide = "type,trace,pass,drive,rw_bw,rw_aat,read_at99\naggregated,all_traces,1,C,1000,100,900\ntrace,boo,1,C,2000,50,400\n"
    o = reader.read_csv_text(wide, "m.csv")
    assert (o["role"], o["layout"]) == ("metrics", "wide") and o["not_understood"] == ["drive"]
    assert {"type": "trace", "trace": "boo", "pass": "1", "metric": "rw_aat", "filter": "rw", "ending": "aat", "value": 50.0} in o["metrics"]
    long_ = "trace\tpass\tmetric\tvalue\nall_traces\t2\trw_bw\t1500\nboo\t2\twrite_s_rnd_at50\t33\n"
    o = reader.read_csv_text(long_, "m.tsv")
    assert (o["role"], o["layout"]) == ("metrics", "long")
    assert {(m["type"], m["trace"], m["metric"]) for m in o["metrics"]} == {("aggregated", "all_traces", "rw_bw"), ("trace", "boo", "write_s_rnd_at50")}
    assert any("no 'type' column" in n for n in o["notes"])
    tr = "metric,boo,exc,all_traces\nrw_bw,1,2,3\nrw_aat,4,5,6\n"
    o = reader.read_csv_text(tr)
    assert (o["role"], o["layout"]) == ("metrics", "transposed") and len(o["metrics"]) == 6
    st = "statistic;boo;exc\nbytes_read;10;20\nbusy;5;6\n"
    o = reader.read_csv_text(st)
    assert (o["role"], o["layout"]) == ("statistics", "transposed") and {"trace": "exc", "name": "busy", "value": 6.0} in o["statistics"]
    assert reader.read_csv_text("a,b\n1,2\n")["role"] is None


def test_xml_headline():
    named = reader.read_xml_text('<r><secondary><rw_bw>1600000000.5</rw_bw><rw_aat unit="us">120.25</rw_aat></secondary>'
                                 '<score name="PCMark 10 Storage score">2950</score></r>')
    h = reader.headline_from_xml(named)
    assert h["rw_bw"] == 1600000000.5 and h["rw_aat"] == 120.25 and h["score"] == 2950.0


def _folder(tmp_path):
    d = tmp_path / "in"
    synth.write_result(str(d / "good_1.pcmark10-result"), seed=1)
    synth.write_result(str(d / "good_2.pcmark10-result"), seed=2)
    synth.write_result(str(d / "sub" / "slow drive.zip"), seed=3, slow=1.8, slow_traces=("psh", "cp1"), layout="long", sep=";",
                       decimal_comma=True, stats_layout="transposed", with_xml=False)
    synth.write_result(str(d / "loose"), seed=4, layout="transposed", archive=False, metrics_name="metrics.csv")
    with zipfile.ZipFile(str(d / "photos.zip"), "w") as z:                 # an archive that is not PCMark 10
        z.writestr("a.csv", "x,y\n1,2\n")
    (d / "notes.csv").write_text("name,age\nbob,3\n", encoding="utf-8")       # a table that is not PCMark 10
    return str(d)


def test_discovery_by_content(tmp_path):
    inv = discover.discover(_folder(tmp_path))
    by = {r["label"]: r for r in inv["results"]}
    assert set(by) == {"good_1", "good_2", "slow drive", "loose"}
    assert by["slow drive"]["kind"] == "archive" and not by["slow drive"]["named_as_result"]
    assert {(f["name"], f["role"], f["layout"]) for f in by["slow drive"]["files"]} == {
        ("pcmark_storage_trace_metrics.csv", "metrics", "long"), ("pcmark_storage_trace_statistics.csv", "statistics", "transposed")}
    assert {f["name"] for f in by["loose"]["files"]} == {"metrics.csv", "pcmark_storage_trace_statistics.csv", "Ariel.xml"}
    assert any("photos.zip" in x for x in inv["ignored"])
    assert discover.discover(str(tmp_path / "nothing"))["errors"]


def test_analysis_baseline_and_comparison(tmp_path):
    st = store.Store(str(tmp_path / "db" / "p.sqlite"))
    out = analyze.analyze_folder(_folder(tmp_path), 5, st, None)
    assert len(out["results"]) == 4
    res = {r["label"]: r for r in st.results(5)}
    assert all(r["status"] == "done" and r["verdict"] == "NOT JUDGED" and r["in_benchmark"] == 0 for r in res.values())
    assert res["good_1"]["headline_from"] == "XML: Ariel.xml"
    assert res["slow drive"]["headline_from"].startswith("metrics: aggregated")
    assert res["slow drive"]["rw_bw"] < res["good_1"]["rw_bw"] and res["slow drive"]["rw_aat"] > res["good_1"]["rw_aat"]
    slow = res["slow drive"]["id"]
    assert "no baseline" in compare.compare(st, slow, 5)["error"]
    for k in ("good_1", "good_2"):
        st.exec("UPDATE result SET in_benchmark=1 WHERE id=?", (res[k]["id"],))
    c = compare.compare(st, slow, 5)
    hl = {h["metric"]: h for h in c["headline"]}
    assert 40 < hl["rw_bw"]["worse_pct"] < 50 and 75 < hl["rw_aat"]["worse_pct"] < 90
    worst_traces = [t["trace"] for t in c["traces"][:3]]
    assert set(worst_traces) == {"psh", "cp1", "all_traces"}
    boo = next(t for t in c["traces"] if t["trace"] == "boo")
    assert boo["n_worse"] == 0
    # the synthetic slow drive slows the 99 % and 99.99 % access times of writes by the same factor: either may rank first
    assert c["worst_metrics"][0]["ending"] in ("at99", "at9999") and c["metrics_worse"] > 0
    rw = {p["p"]: p for p in c["percentiles"]["all_traces"]["rw"]}
    assert set(rw) == set(catalog.PERCENTILES) and rw["at9999"]["worse_pct"] > rw["at50"]["worse_pct"]
    assert c["passes"] and all(len(p["values"]) == 3 for p in c["passes"])
    text = summary.written(c)
    assert "MB/s" in text and "psh" in text and "99.99%" in text
    assert compare.flat_rows(c, "trace")[0]["trace"] in ("psh", "cp1", "all_traces")
    assert compare.flat_rows(c, "percentile")
    # reading again keeps the baseline choice and does not duplicate
    analyze.analyze_folder(str(tmp_path / "in"), 5, st, None)
    again = {r["label"]: r for r in st.results(5)}
    assert len(again) == 4 and again["good_1"]["in_benchmark"] == 1


def test_limits_judge_and_fill_the_baseline(tmp_path):
    st = store.Store(str(tmp_path / "p.sqlite"))
    cfg = {"pcm10": {"min_rw_bw_mbps": 1200, "max_rw_aat_us": 150}}
    analyze.analyze_folder(_folder(tmp_path), 1, st, cfg)
    res = {r["label"]: r for r in st.results(1)}
    assert res["good_1"]["verdict"] == "PASS" and res["good_1"]["in_benchmark"] == 1
    assert res["slow drive"]["verdict"] == "FAIL" and res["slow drive"]["in_benchmark"] == 0
    assert analyze.verdict(None, 100, {"pcm10": {"min_rw_bw_mbps": 1}})[0] == "UNKNOWN"


def test_statistics_that_differ_are_said(tmp_path):
    st = store.Store(str(tmp_path / "p.sqlite"))
    d = tmp_path / "in"
    synth.write_result(str(d / "a.pcmark10-result"), seed=1)
    synth.write_result(str(d / "b.pcmark10-result"), seed=2)
    analyze.analyze_folder(str(d), 1, st, None)
    a, b = sorted(st.results(1), key=lambda r: r["label"])
    st.exec("UPDATE result SET in_benchmark=1 WHERE id=?", (a["id"],))
    st.exec("UPDATE statistic SET value=value*2 WHERE result=? AND name='reads'", (b["id"],))
    c = compare.compare(st, b["id"], 1)
    assert c["statistics_differ"] and "may not use the same traces" in c["note"]


def test_model_summary_is_checked(tmp_path):
    st = store.Store(str(tmp_path / "p.sqlite"))
    analyze.analyze_folder(_folder(tmp_path), 1, st, None)
    res = {r["label"]: r for r in st.results(1)}
    st.exec("UPDATE result SET in_benchmark=1 WHERE id=?", (res["good_1"]["id"],))
    c = compare.compare(st, res["slow drive"]["id"], 1)
    bw = next(h for h in c["headline"] if h["metric"] == "rw_aat")

    class Fake:
        name = "fake"

        def generate_json(self, prompt, schema, max_tokens=None):
            return {"summary": "Average access is %.1f µs against %.1f µs. The drive lost 333333333333 MB/s." % (bw["run"], bw["bench"]),
                    "likely_causes": ["thermal throttling"]}, False
    out = summary.summarise(c, Fake())
    assert out["model_text"].startswith("Average access") and out["unchecked"] == ["The drive lost 333333333333 MB/s."]


# ------------------------------------------------------------------------------------------------ the routes and the start page
flask = pytest.importorskip("flask")


@pytest.fixture()
def client(tmp_path):
    sys.path.insert(0, os.path.join(APP, "app"))
    from server import create_app, load_config
    cfg = load_config(os.path.join(APP, "config", "app_config.json"))
    cfg["llm"]["backend"] = "standin"
    return create_app(cfg, str(tmp_path / "root")).test_client()


def test_routes_and_category(client, tmp_path):
    only = tmp_path / "only_pcmark"
    synth.write_result(str(only / "g1.pcmark10-result"), seed=1)
    synth.write_result(str(only / "g2.pcmark10-result"), seed=2)
    synth.write_result(str(only / "bad.pcmark10-result"), seed=3, slow=2.0)
    r = client.get("/api/agents/inventory", query_string={"folder": str(only)}).get_json()
    assert r["pcmark"] and r["no_table"] is None
    p = client.post("/api/agents/projects", json={"admin": "t", "name": "pcm", "folder": str(only), "category": "auto"}).get_json()
    assert p["source_tool"] == "pcmark10_storage" and p["source_tool_name"] == "PCMark 10 Storage"
    assert client.post("/api/agents/projects/%d/flow" % p["id"], json={"admin": "t"}).status_code == 409
    other = tmp_path / "plain"
    other.mkdir()
    (other / "t.csv").write_text("a,b\n1,2\n", encoding="utf-8")
    bad = client.post("/api/agents/projects", json={"admin": "t", "name": "x", "folder": str(other), "category": "pcmark10"})
    assert bad.status_code == 400 and "Another tool" in bad.get_json()["error"]
    out = client.post("/api/pcm10/analyze", json={"project": p["id"]}).get_json()
    assert len(out["results"]) == 3
    rs = client.get("/api/pcm10/results?project=%d" % p["id"]).get_json()
    ids = {r["label"]: r["id"] for r in rs}
    d = client.get("/api/pcm10/results/%d" % ids["bad"]).get_json()
    assert d["files"] and d["traces"] and d["counts"]["metrics"] > 0
    for k in ("g1", "g2"):
        assert client.put("/api/pcm10/results/%d" % ids[k], json={"in_benchmark": True}).get_json()["in_benchmark"] == 1
    b = client.get("/api/pcm10/benchmark?project=%d" % p["id"]).get_json()
    assert b["n"] == 2
    c = client.post("/api/pcm10/results/%d/compare" % ids["bad"], json={}).get_json()
    assert c["summary"]["by"] == "the program" and c["metrics_worse"] > 0 and c["unverified"]
    for level in ("metric", "trace", "percentile"):
        resp = client.get("/api/pcm10/results/%d/compare.csv?level=%s" % (ids["bad"], level))
        assert resp.status_code == 200 and len(resp.data.splitlines()) > 2
    assert client.get("/api/pcm10/results/%d/compare" % ids["bad"]).get_json()["id"] == c["id"]
    assert client.get("/api/pcm10/catalog").get_json()["traces"]["boo"] == "Booting Windows 10"
    assert client.delete("/api/pcm10/results/%d" % ids["g2"]).get_json()["ok"]
