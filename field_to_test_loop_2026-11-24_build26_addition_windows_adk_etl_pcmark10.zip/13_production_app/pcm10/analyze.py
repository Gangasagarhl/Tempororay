"""Read every PCMark 10 Storage result of a folder and store it.

    out = analyze_folder(folder, project, store, cfg)

Headline numbers of a result (the two secondary metrics of the PCMark 10 Storage score, UL):
    rw_bw   bandwidth of read and write operations, B/s     rw_aat   their average access time, µs
taken from Ariel.xml / an XML export when present, else from the metrics table (type aggregated, trace all_traces, mean over
the passes), else the mean over the traces. A score is shown only when an XML holds one (UL does not publish the constants
of its score formula, so it is never computed here).

Verdict: config pcm10.min_rw_bw_mbps and / or pcm10.max_rw_aat_us when set (PASS when every limit given is met; a PASS
result joins the baseline); with no limit the verdict is "not judged" and the admin chooses the baseline results.
"""
import statistics

from . import catalog, discover, reader

DEFAULTS = {"min_rw_bw_mbps": None, "max_rw_aat_us": None, "worse_pct": 10.0}


def settings(cfg=None):
    s = dict(DEFAULTS)
    mine = (cfg or {}).get("pcm10") if isinstance(cfg, dict) else None
    if isinstance(mine, dict):
        s.update({k: v for k, v in mine.items() if not str(k).startswith("_")})
    return s


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return statistics.fmean(xs) if xs else None


def verdict(rw_bw, rw_aat, cfg=None):
    s = settings(cfg)
    lo_bw, hi_aat = s.get("min_rw_bw_mbps"), s.get("max_rw_aat_us")
    if lo_bw is None and hi_aat is None:
        return "NOT JUDGED", "no limit is set (config pcm10.min_rw_bw_mbps / pcm10.max_rw_aat_us): choose the baseline results yourself"
    why, ok = [], True
    if lo_bw is not None:
        if rw_bw is None:
            return "UNKNOWN", "no read/write bandwidth in this result"
        good = rw_bw / 1e6 >= float(lo_bw)
        ok &= good
        why.append("bandwidth %.1f MB/s %s %s MB/s" % (rw_bw / 1e6, ">=" if good else "<", lo_bw))
    if hi_aat is not None:
        if rw_aat is None:
            return "UNKNOWN", "no average access time in this result"
        good = rw_aat <= float(hi_aat)
        ok &= good
        why.append("average access %.1f µs %s %s µs" % (rw_aat, "<=" if good else ">", hi_aat))
    return ("PASS" if ok else "FAIL"), "; ".join(why)


def analyze_folder(folder, project, store, cfg=None, only=None):
    inv = discover.discover(folder)
    out = {"folder": inv["folder"], "errors": list(inv["errors"]), "results": [], "discovery": discover.brief(inv),
           "problems": inv["problems"], "ignored": inv["ignored"]}
    for r in inv["results"]:
        if only and r["id"] not in only:
            continue
        out["results"].append(analyze_result(r, project, store, cfg))
    return out


def analyze_result(res, project, store, cfg=None):
    rid, kept = store.new_result(project, res["id"], res["label"], res["path"], res["kind"])
    notes, headline, src = [], {}, None
    try:
        for f in res["files"]:
            raw = discover.read_member(res, f["name"])
            text, enc = reader.decode(raw)
            if f["role"] in ("metrics", "statistics"):
                o = reader.read_csv_text(text, f["name"])
                store.many("INSERT INTO metric (result, type, trace, pass, metric, filter, ending, value) VALUES (?,?,?,?,?,?,?,?)",
                           [(rid, m["type"], m["trace"], m["pass"], m["metric"], m["filter"], m["ending"], m["value"]) for m in o["metrics"]])
                store.many("INSERT INTO statistic (result, trace, name, value) VALUES (?,?,?,?)",
                           [(rid, s["trace"], s["name"], s["value"]) for s in o["statistics"]])
                store.exec("INSERT INTO file (result, name, role, layout, separator, decimal_comma, rows, values_read, not_understood, notes) "
                           "VALUES (?,?,?,?,?,?,?,?,?,?)", (rid, f["name"], o["role"], o["layout"], o["separator"], int(o["decimal_comma"]),
                                                            o["rows_in_file"], len(o["metrics"]) + len(o["statistics"]),
                                                            "|".join(o["not_understood"]), "|".join(o["notes"])))
                if o["not_understood"]:
                    notes.append("%s: columns not understood (kept out): %s" % (f["name"], ", ".join(o["not_understood"][:12])))
                notes += ["%s: %s" % (f["name"], n) for n in o["notes"]]
            elif f["role"] == "xml":
                named = reader.read_xml_text(text)
                store.many("INSERT INTO xml_value (result, file, name, value) VALUES (?,?,?,?)", [(rid, f["name"], x["name"], x["value"]) for x in named])
                store.exec("INSERT INTO file (result, name, role, layout, separator, decimal_comma, rows, values_read, not_understood, notes) "
                           "VALUES (?,?,?,?,?,?,?,?,?,?)", (rid, f["name"], "xml", None, None, 0, 0, len(named), "", ""))
                h = reader.headline_from_xml(named)
                for k, v in h.items():
                    if k not in headline:
                        headline[k] = v
                        src = src or ("XML: %s" % f["name"])
        if headline.get("rw_bw") is None or headline.get("rw_aat") is None:
            for ending in ("bw", "aat"):
                k = "rw_" + ending
                if headline.get(k) is not None:
                    continue
                agg = [r["value"] for r in store.all("SELECT value FROM metric WHERE result=? AND filter='rw' AND ending=? AND trace='all_traces'", (rid, ending))]
                if agg:
                    headline[k], src = _mean(agg), src or "metrics: aggregated all_traces (mean over the passes)"
                else:
                    per = [r["v"] for r in store.all("SELECT AVG(value) v FROM metric WHERE result=? AND filter='rw' AND ending=? AND type='trace' GROUP BY trace", (rid, ending))]
                    if per:
                        headline[k], src = _mean(per), src or "metrics: mean over the traces"
        v, why = verdict(headline.get("rw_bw"), headline.get("rw_aat"), cfg)
        notes.insert(0, "verdict: %s" % why)
        n_metrics = store.one("SELECT COUNT(*) c FROM metric WHERE result=?", (rid,))["c"]
        if not n_metrics:
            notes.append("no metric value was read from this result")
        in_bench = kept if kept is not None else (1 if v == "PASS" else 0)
        store.finish(rid, status="done", verdict=v, rw_bw=headline.get("rw_bw"), rw_aat=headline.get("rw_aat"), score=headline.get("score"),
                     score_name=headline.get("score_name"), headline_from=src, in_benchmark=in_bench, notes=notes)
    except Exception as exc:                            # noqa: BLE001 - one bad result never stops the others
        store.finish(rid, status="failed", error=str(exc)[:800], notes=notes)
    return rid


def profile(store, rid):
    """One result averaged over its passes: {(type, trace, filter, ending): value}, plus statistics and XML numbers."""
    m = {}
    for r in store.all("SELECT type, trace, filter, ending, AVG(value) v, COUNT(*) n FROM metric WHERE result=? GROUP BY type, trace, filter, ending", (rid,)):
        m[(r["type"], r["trace"], r["filter"], r["ending"])] = r["v"]
    passes = store.all("SELECT trace, pass, filter, ending, value FROM metric WHERE result=? AND type='trace' AND filter='rw' AND ending IN ('bw','aat') ORDER BY trace, pass", (rid,))
    st = {(r["trace"], r["name"]): r["v"] for r in store.all("SELECT trace, name, AVG(value) v FROM statistic WHERE result=? GROUP BY trace, name", (rid,))}
    xv = {r["name"]: r["v"] for r in store.all("SELECT name, AVG(value) v FROM xml_value WHERE result=? GROUP BY name", (rid,))}
    return {"metrics": m, "passes": passes, "statistics": st, "xml": xv, "known_traces": sorted({k[1] for k in m if k[1] in catalog.TRACES})}
