"""Read PCMark 10 Storage CSV / XML content, whatever its layout (UL documents the names, not the layout).

    text, enc = decode(raw_bytes)
    t = parse_csv(text)                    {"header", "rows", "separator", "decimal_comma"}
    c = classify(t)                        {"role": metrics | statistics | None, "layout": wide | long | transposed, ...}
    out = read_csv_text(text, name)        the rows in one long form + what was not understood
    named = read_xml_text(text)            every named number of an XML file (Ariel.xml: rw_bw, rw_aat; an export: scores)

Long form of the metrics: {"type": trace | aggregated, "trace", "pass", "metric", "filter", "ending", "value"}
Long form of the statistics: {"trace", "name", "value"}

Layouts recognised (each decided from the file, never assumed):
  wide         one column per metric (rw_bw, read_at99, ...) or statistic (bytes_read, busy, ...); a row per trace / pass;
               the other columns are read as type / trace / pass when their names say so, else listed as not understood
  long         one column holds metric (or statistic) names, another the value
  transposed   the first column holds the metric (or statistic) names, every other column is a trace (its header)
"""
import csv
import io
import re
import xml.etree.ElementTree as ET

from . import catalog

ID_TYPE = ("type", "metric_type", "kind")
ID_TRACE = ("trace", "trace_name", "tracename", "workload", "test")
ID_PASS = ("pass", "pass_index", "passindex", "pass_number", "iteration", "run", "playback", "round", "index")
NAME_COLS = ("metric", "name", "metric_name", "variable", "key", "statistic", "measure", "field")
VALUE_COLS = ("value", "val", "result", "number", "score")


def decode(raw):
    """(text, encoding) of a file's bytes: UTF-8 (with or without BOM), UTF-16 (BOM, or every other byte 0), else cp1252."""
    if raw.startswith(b"\xef\xbb\xbf"):
        return raw[3:].decode("utf-8", errors="replace"), "utf-8-sig"
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        return raw.decode("utf-16", errors="replace").lstrip("\ufeff"), "utf-16"
    head = raw[:400]
    if head and head.count(b"\x00") > len(head) // 3:
        enc = "utf-16-le" if head[1:2] == b"\x00" else "utf-16-be"
        return raw.decode(enc, errors="replace"), enc
    try:
        return raw.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace"), "cp1252"


def _separator(lines):
    best, score = ",", -1
    for sep in (",", ";", "\t", "|"):
        counts = [len(next(csv.reader([ln], delimiter=sep))) for ln in lines[:20] if ln.strip()]
        if not counts or max(counts) < 2:
            continue
        same = sum(1 for c in counts if c == counts[0])
        s = same * 100 + counts[0]
        if s > score:
            best, score = sep, s
    return best


_DEC_COMMA = re.compile(r"^-?\d{1,3}(\.\d{3})*,\d+$|^-?\d+,\d+$")
_DEC_DOT = re.compile(r"^-?\d+\.\d+$|^-?\d{1,3}(,\d{3})+\.\d+$")


def parse_csv(text, max_rows=None):
    lines = text.splitlines()
    while lines and not lines[0].strip():
        lines.pop(0)
    sep = _separator(lines)
    rdr = csv.reader(io.StringIO("\n".join(lines)), delimiter=sep)
    rows = []
    for i, r in enumerate(rdr):
        if max_rows is not None and i > max_rows:
            break
        if any(c.strip() for c in r):
            rows.append([c.strip() for c in r])
    header = rows[0] if rows else []
    body = rows[1:]
    sample = [c for r in body[:200] for c in r if c]
    commas = sum(1 for c in sample if _DEC_COMMA.match(c))
    dots = sum(1 for c in sample if _DEC_DOT.match(c))
    dec_comma = sep != "," and commas >= 1 and commas > dots       # "1.234,5" / "987,25" against "987.25"
    return {"header": header, "rows": body, "separator": sep, "decimal_comma": dec_comma}


def num(s, decimal_comma=False):
    s = (s or "").strip().strip('"').replace("\u00a0", "").replace(" ", "")
    if not s or s.lower() in ("-", "n/a", "na", "nan", "null", "none"):
        return None
    if decimal_comma:
        s = s.replace(".", "").replace(",", ".")
    else:
        s = s.replace(",", "") if re.match(r"^-?\d{1,3}(,\d{3})+(\.\d+)?$", s) else s
    try:
        v = float(s)
    except ValueError:
        return None
    return v if v == v else None


def _col(header, names):
    hn = [catalog.norm(h) for h in header]
    for want in names:
        if want in hn:
            return hn.index(want)
    return None


def _kind_of_name(n):
    if catalog.is_metric(n):
        return "metric"
    if catalog.is_statistic(n):
        return "statistic"
    f, e = catalog.split_metric(n)
    return "metric?" if e else None


def classify(t):
    """What a parsed table is: role (metrics | statistics | None) and its layout, from its own header and cells."""
    header, rows = t["header"], t["rows"]
    if not header:
        return {"role": None, "layout": None}
    kinds = [_kind_of_name(h) for h in header]
    n_metric = sum(1 for k in kinds if k == "metric")
    n_stat = sum(1 for k in kinds if k == "statistic")
    if n_metric >= 2 or (n_metric >= 1 and n_metric >= n_stat):
        return {"role": "metrics", "layout": "wide"}
    if n_stat >= 2:
        return {"role": "statistics", "layout": "wide"}
    # long: one column of names
    best = None
    for j in range(len(header)):
        vals = [r[j] for r in rows[:300] if j < len(r) and r[j]]
        if not vals:
            continue
        m = sum(1 for v in vals if _kind_of_name(v) == "metric")
        s = sum(1 for v in vals if _kind_of_name(v) == "statistic")
        share_m, share_s = m / float(len(vals)), s / float(len(vals))
        for role, share in (("metrics", share_m), ("statistics", share_s)):
            if share >= 0.5 and (best is None or share > best[2]):
                best = (role, j, share)
    if best:
        role, j, _s = best
        layout = "transposed" if j == 0 and _col(header, VALUE_COLS) is None and len(header) >= 2 and \
            not any(catalog.norm(h) in ID_TRACE + ID_TYPE + ID_PASS for h in header[1:]) else "long"
        return {"role": role, "layout": layout, "name_col": j}
    return {"role": None, "layout": None}


def read_csv_text(text, name=""):
    """Every value of a PCMark 10 CSV in the long form, with what was not understood. Never raises for bad content."""
    t = parse_csv(text)
    c = classify(t)
    out = {"name": name, "role": c["role"], "layout": c["layout"], "separator": t["separator"], "decimal_comma": t["decimal_comma"],
           "header": t["header"][:60], "rows_in_file": len(t["rows"]), "metrics": [], "statistics": [], "not_understood": [],
           "unknown_filters": [], "notes": []}
    if not c["role"]:
        out["notes"].append("not a PCMark 10 storage table: no documented metric or statistic name in its header or cells")
        return out
    header, rows, dc = t["header"], t["rows"], t["decimal_comma"]
    ty, tr, ps = _col(header, ID_TYPE), _col(header, ID_TRACE), _col(header, ID_PASS)
    unknown_f = set()

    def add_metric(typ, trace, pas, name_, raw):
        v = num(raw, dc)
        if v is None:
            return
        f, e = catalog.split_metric(name_)
        if f not in catalog.FILTERS:
            unknown_f.add(f)
        trace = (trace or "").strip() or "all_traces"
        typ = catalog.norm(typ) if typ else ("aggregated" if trace == "all_traces" else "trace")
        out["metrics"].append({"type": typ, "trace": trace, "pass": (pas or "").strip(), "metric": catalog.norm(name_),
                               "filter": f, "ending": e, "value": v})

    def add_stat(trace, name_, raw):
        v = num(raw, dc)
        if v is not None:
            out["statistics"].append({"trace": (trace or "").strip() or "all_traces", "name": catalog.norm(name_), "value": v})

    get = lambda r, j: r[j] if j is not None and j < len(r) else ""        # noqa: E731
    if c["layout"] == "wide":
        want = "metric" if c["role"] == "metrics" else "statistic"
        cols = [j for j, h in enumerate(header) if _kind_of_name(h) in (want, "metric?" if want == "metric" else want)]
        ids = {ty, tr, ps} - {None}
        out["not_understood"] = [h for j, h in enumerate(header) if j not in cols and j not in ids]
        for r in rows:
            for j in cols:
                if c["role"] == "metrics":
                    add_metric(get(r, ty), get(r, tr), get(r, ps), header[j], get(r, j))
                else:
                    add_stat(get(r, tr), header[j], get(r, j))
    elif c["layout"] == "long":
        nc = c["name_col"]
        vc = _col(header, VALUE_COLS)
        if vc is None:                                  # the value is the one numeric column that is not an id
            for j in range(len(header)):
                if j in (nc, ty, tr, ps):
                    continue
                vals = [num(get(r, j), dc) for r in rows[:50]]
                if vals and sum(1 for v in vals if v is not None) >= len(vals) * 0.8:
                    vc = j
                    break
        if vc is None:
            out["notes"].append("a column of %s names was found but no column of values" % c["role"])
            return out
        out["not_understood"] = [h for j, h in enumerate(header) if j not in {nc, vc, ty, tr, ps}]
        for r in rows:
            n_ = get(r, nc)
            if c["role"] == "metrics":
                if _kind_of_name(n_) in ("metric", "metric?"):
                    add_metric(get(r, ty), get(r, tr), get(r, ps), n_, get(r, vc))
            elif catalog.is_statistic(n_):
                add_stat(get(r, tr), n_, get(r, vc))
    else:                                               # transposed: names in column 0, one column per trace
        for r in rows:
            n_ = get(r, 0)
            for j in range(1, len(header)):
                trace = header[j]
                if c["role"] == "metrics" and _kind_of_name(n_) in ("metric", "metric?"):
                    add_metric(None, trace, "", n_, get(r, j))
                elif c["role"] == "statistics" and catalog.is_statistic(n_):
                    add_stat(trace, n_, get(r, j))
    out["unknown_filters"] = sorted(x for x in unknown_f if x)
    if out["unknown_filters"]:
        out["notes"].append("metric prefixes that UL does not document: %s (kept as they are)" % ", ".join(out["unknown_filters"][:10]))
    if c["role"] == "metrics" and ty is None and c["layout"] != "transposed":
        out["notes"].append("no 'type' column: rows of trace all_traces are taken as aggregated, the others as trace")
    if c["role"] == "metrics" and tr is None and c["layout"] != "transposed":
        out["notes"].append("no 'trace' column: every row is taken as all_traces")
    return out


def _local(tag):
    return str(tag).split("}")[-1]


def read_xml_text(text):
    """[{"name", "value", "path"}] of every named number of an XML file: an element whose text is a number (named by its tag,
    or by a name / id / type attribute), and every numeric attribute. Ariel.xml holds rw_bw and rw_aat (UL); an XML export
    holds the scores."""
    try:
        root = ET.fromstring(text.encode("utf-8") if isinstance(text, str) else text)
    except ET.ParseError:
        return []
    out = []

    def walk(el, path):
        tag = _local(el.tag)
        a = {k.split("}")[-1].lower(): v for k, v in el.attrib.items()}
        label = a.get("name") or a.get("id") or a.get("type") or tag
        p = path + "/" + tag
        txt = (el.text or "").strip()
        v = num(txt)
        if v is not None and len(el) == 0:
            out.append({"name": catalog.norm(label), "value": v, "path": p})
        for k, val in a.items():
            if k in ("name", "id", "type"):
                continue
            vv = num(val)
            if vv is not None:
                out.append({"name": catalog.norm(k if label == tag else "%s_%s" % (label, k)), "value": vv, "path": p + "@" + k})
        for ch in el:
            walk(ch, p)
    walk(root, "")
    return out


def headline_from_xml(named):
    """rw_bw / rw_aat / score(s) from the named numbers of an XML file."""
    h = {}
    for x in named:
        n = x["name"]
        if n.endswith("rw_bw") and "rw_bw" not in h:
            h["rw_bw"] = x["value"]
        elif n.endswith("rw_aat") and "rw_aat" not in h:
            h["rw_aat"] = x["value"]
        elif "score" in n and "score" not in h:
            h["score"] = x["value"]
            h["score_name"] = n
    return h
