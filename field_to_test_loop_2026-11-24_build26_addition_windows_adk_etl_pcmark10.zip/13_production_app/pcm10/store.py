"""Every PCMark 10 Storage result read is kept: <application root>/db/pcmark10.sqlite.

    result      one row per result (an archive or a folder of tables): headline numbers, verdict, baseline or not
    metric      per result: type (trace | aggregated), trace, pass, metric = filter_ending, value
    statistic   per result: trace, statistic name, value
    xml_value   per result: every named number of its XML files (Ariel.xml: rw_bw, rw_aat; an export: scores)
    file        per result: each file read, its role, layout, separator and what was not understood
    comparison  every comparison made (JSON)
"""
import json
import os
import sqlite3
import threading
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS result (id INTEGER PRIMARY KEY AUTOINCREMENT, project INTEGER, result_key TEXT, label TEXT, path TEXT,
  kind TEXT, status TEXT, verdict TEXT, rw_bw REAL, rw_aat REAL, score REAL, score_name TEXT, headline_from TEXT,
  in_benchmark INTEGER DEFAULT 0, created REAL, updated REAL, notes TEXT, error TEXT);
CREATE TABLE IF NOT EXISTS metric (result INTEGER, type TEXT, trace TEXT, pass TEXT, metric TEXT, filter TEXT, ending TEXT, value REAL);
CREATE TABLE IF NOT EXISTS statistic (result INTEGER, trace TEXT, name TEXT, value REAL);
CREATE TABLE IF NOT EXISTS xml_value (result INTEGER, file TEXT, name TEXT, value REAL);
CREATE TABLE IF NOT EXISTS file (result INTEGER, name TEXT, role TEXT, layout TEXT, separator TEXT, decimal_comma INTEGER,
  rows INTEGER, values_read INTEGER, not_understood TEXT, notes TEXT);
CREATE TABLE IF NOT EXISTS comparison (id INTEGER PRIMARY KEY AUTOINCREMENT, result INTEGER, scope TEXT, created REAL, json TEXT);
CREATE INDEX IF NOT EXISTS ix_pm_metric ON metric(result, type, trace);
CREATE INDEX IF NOT EXISTS ix_pm_stat ON statistic(result);
CREATE INDEX IF NOT EXISTS ix_pm_xml ON xml_value(result);
CREATE INDEX IF NOT EXISTS ix_pm_file ON file(result);
CREATE INDEX IF NOT EXISTS ix_pm_cmp ON comparison(result);
"""
CHILD = ("metric", "statistic", "xml_value", "file", "comparison")


def jload(s, default):
    try:
        return json.loads(s) if s else default
    except (TypeError, ValueError):
        return default


class Store:
    def __init__(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.path = path
        self.lock = threading.RLock()
        with self._c() as c:
            c.executescript(SCHEMA)

    def _c(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        return c

    def all(self, sql, args=()):
        with self.lock, self._c() as c:
            return [dict(r) for r in c.execute(sql, args).fetchall()]

    def one(self, sql, args=()):
        r = self.all(sql, args)
        return r[0] if r else None

    def exec(self, sql, args=()):
        with self.lock, self._c() as c:
            return c.execute(sql, args).lastrowid

    def many(self, sql, rows):
        rows = list(rows)
        if rows:
            with self.lock, self._c() as c:
                c.executemany(sql, rows)

    def new_result(self, project, key, label, path, kind):
        """A result read again (same analysis, same file) replaces the earlier one; its baseline choice is kept."""
        with self.lock:
            old = self.all("SELECT id, in_benchmark FROM result WHERE project IS ? AND result_key=?", (project, key))
            keep = old[0]["in_benchmark"] if old else None
            for o in old:
                self.delete(o["id"])
            t = time.time()
            rid = self.exec("INSERT INTO result (project, result_key, label, path, kind, status, in_benchmark, created, updated) "
                            "VALUES (?,?,?,?,?,?,?,?,?)", (project, key, label, path, kind, "reading", keep or 0, t, t))
            return rid, keep

    def finish(self, rid, **kw):
        kw["updated"] = time.time()
        if "notes" in kw and not isinstance(kw["notes"], str):
            kw["notes"] = json.dumps(kw["notes"])
        self.exec("UPDATE result SET %s WHERE id=?" % ", ".join("%s=?" % k for k in kw), tuple(kw.values()) + (rid,))

    def delete(self, rid):
        with self.lock, self._c() as c:
            for t in CHILD:
                c.execute("DELETE FROM %s WHERE result=?" % t, (rid,))
            c.execute("DELETE FROM result WHERE id=?", (rid,))

    def results(self, project=None):
        rows = self.all("SELECT * FROM result" + (" WHERE project=?" if project is not None else "") + " ORDER BY id DESC",
                        (project,) if project is not None else ())
        for r in rows:
            r["notes"] = jload(r.get("notes"), [])
        return rows

    def result(self, rid):
        r = self.one("SELECT * FROM result WHERE id=?", (rid,))
        if r:
            r["notes"] = jload(r.get("notes"), [])
        return r
