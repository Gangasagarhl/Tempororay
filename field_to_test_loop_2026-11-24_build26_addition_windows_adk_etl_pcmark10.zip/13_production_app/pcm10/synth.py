"""Synthetic PCMark 10 Storage results, for tests and a demonstration only (NOT real data: no real file was available).

They use UL's documented file names, metric and statistic names and trace labels, in the layouts the reader accepts, so the
whole chain (discovery, reading, storing, baseline, comparison, pages) can be exercised. Every file says SYNTHETIC in it.

    write_result(path, seed=1, slow=1.0, layout="wide", sep=",", decimal_comma=False, archive=True)
"""
import io
import math
import os
import random
import zipfile

from . import catalog

TRACES = ["boo", "sacr", "exc", "psh", "cp1", "cps3"]
FILTERS = ["rw", "read", "write", "read_s_rnd", "write_s_rnd", "read_seq", "write_seq", "flush"]
ENDS = ["count", "bytes", "busy", "bw", "aat", "at50", "at90", "at95", "at99", "at9999"]


def _metrics(rng, slow, slow_traces):
    rows = []
    for p in (1, 2, 3):
        for t in TRACES + ["all_traces"]:
            k = slow if (t in slow_traces or t == "all_traces" or not slow_traces) else 1.0
            for f in FILTERS:
                base_aat = {"flush": 900.0, "write_s_rnd": 60.0, "read_s_rnd": 80.0}.get(f, 120.0)
                aat = base_aat * k * (1 + rng.uniform(-0.03, 0.03))
                bw = 1.6e9 / k * (1 + rng.uniform(-0.03, 0.03))
                cnt = 20000 + TRACES.index(t) * 1000 if t != "all_traces" else 150000
                vals = {"count": cnt, "bytes": cnt * 32768, "busy": cnt * aat * 0.6, "bw": bw, "aat": aat,
                        "at50": aat * 0.6, "at90": aat * 1.8, "at95": aat * 2.6, "at99": aat * 6.0 * (k if f.startswith("write") else 1.0),
                        "at9999": aat * 40.0 * k}
                for e in ENDS:
                    rows.append(("aggregated" if t == "all_traces" else "trace", t, str(p), "%s_%s" % (f, e), vals[e]))
    return rows


def _fmt(v, dc):
    s = ("%.3f" % v) if not float(v).is_integer() else str(int(v))
    return s.replace(".", ",") if dc else s


def metrics_csv(rows, layout="wide", sep=",", dc=False):
    buf = io.StringIO()
    buf.write("")
    if layout == "wide":
        names = sorted({r[3] for r in rows})
        keys = sorted({(r[0], r[1], r[2]) for r in rows}, key=lambda k: (k[2], k[1]))
        val = {(r[0], r[1], r[2], r[3]): r[4] for r in rows}
        buf.write(sep.join(["type", "trace", "pass"] + names) + "\n")
        for k in keys:
            buf.write(sep.join(list(k) + [_fmt(val[k + (n,)], dc) for n in names]) + "\n")
    elif layout == "long":
        buf.write(sep.join(["type", "trace", "pass", "metric", "value"]) + "\n")
        for r in rows:
            buf.write(sep.join([r[0], r[1], r[2], r[3], _fmt(r[4], dc)]) + "\n")
    else:                                               # transposed: one column per trace (pass 1 only)
        traces = TRACES + ["all_traces"]
        names = sorted({r[3] for r in rows})
        val = {(r[1], r[3]): r[4] for r in rows if r[2] == "1"}
        buf.write(sep.join(["metric"] + traces) + "\n")
        for n in names:
            buf.write(sep.join([n] + [_fmt(val[(t, n)], dc) for t in traces]) + "\n")
    return buf.getvalue()


def statistics_csv(layout="wide", sep=","):
    names = ["bytes_read", "bytes_write", "reads", "writes", "flushes", "busy", "idle", "bandwidth", "average_access", "max_queue_depth"]
    vals = {t: {n: 1000 * (i + 1) * (j + 1) for j, n in enumerate(names)} for i, t in enumerate(TRACES)}
    if layout == "transposed":
        out = sep.join(["statistic"] + TRACES) + "\n"
        for n in names:
            out += sep.join([n] + [str(vals[t][n]) for t in TRACES]) + "\n"
        return out
    out = sep.join(["trace"] + names) + "\n"
    for t in TRACES:
        out += sep.join([t] + [str(vals[t][n]) for n in names]) + "\n"
    return out


def ariel_xml(rows):
    agg = [r[4] for r in rows if r[1] == "all_traces" and r[3] in ("rw_bw",)]
    aat = [r[4] for r in rows if r[1] == "all_traces" and r[3] in ("rw_aat",)]
    bw = math.exp(sum(math.log(x) for x in agg) / len(agg))
    return ('<?xml version="1.0" encoding="utf-8"?>\n<!-- SYNTHETIC: made by pcm10/synth.py, not by PCMark 10 -->\n'
            '<results><result><secondary_metrics><rw_bw>%.1f</rw_bw><rw_aat>%.2f</rw_aat></secondary_metrics></result></results>\n'
            % (bw, sum(aat) / len(aat)))


def write_result(path, seed=1, slow=1.0, slow_traces=(), layout="wide", sep=",", decimal_comma=False, archive=True,
                 stats_layout="wide", with_xml=True, metrics_name=catalog.METRICS_FILE):
    rng = random.Random(seed)
    rows = _metrics(rng, slow, list(slow_traces))
    files = {metrics_name: metrics_csv(rows, layout, sep, decimal_comma),
             catalog.STATISTICS_FILE: statistics_csv(stats_layout, sep)}
    if with_xml:
        files[catalog.SECONDARY_FILE] = ariel_xml(rows)
    files["SYNTHETIC_README.txt"] = "SYNTHETIC PCMark 10 result made by pcm10/synth.py for tests; not produced by PCMark 10.\n"
    if archive:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for n, t in files.items():
                z.writestr(n, t)
    else:
        os.makedirs(path, exist_ok=True)
        for n, t in files.items():
            with open(os.path.join(path, n), "w", encoding="utf-8", newline="") as fh:
                fh.write(t)
    return path
