"""The baseline (good PCMark 10 Storage results, chosen by the admin or PASS by the configured limits) and one result against it.

    b = benchmark(store, project, exclude)     each baseline result averaged over its passes, then the mean over the results
    res = compare(store, rid, project, cfg)    worst first

"Worse" follows the meaning of each metric (catalog.ENDINGS): a lower bandwidth (_bw) is worse; a higher busy time, average
access time or access-time percentile (_busy, _aat, _at50 ... _at9999) is worse; counts, bytes, not-busy time and duty cycle
describe the workload and are shown but never ranked. worse_pct = how much worse in % of the baseline (negative = better).
"""
import math
import statistics

from . import analyze, catalog

PCT_FILTERS = ["rw", "read", "write", "read_s_rnd", "write_s_rnd", "read_seq", "write_seq", "read_s", "write_s", "read_m",
               "write_m", "read_l", "write_l", "flush", "create", "close", "all"]


def baseline_results(store, project=None, exclude=None):
    sql = "SELECT * FROM result WHERE status='done' AND in_benchmark=1"
    args = ()
    if project is not None:
        sql += " AND project=?"
        args = (project,)
    return [r for r in store.all(sql + " ORDER BY id", args) if r["id"] != exclude]


def _pool(dicts):
    keys = set()
    for d in dicts:
        keys |= set(d)
    out = {}
    for k in keys:
        vals = [d[k] for d in dicts if d.get(k) is not None]
        if vals:
            out[k] = {"mean": statistics.fmean(vals), "std": statistics.stdev(vals) if len(vals) > 1 else 0.0, "n": len(vals)}
    return out


def benchmark(store, project=None, exclude=None):
    rows = baseline_results(store, project, exclude)
    profs = [analyze.profile(store, r["id"]) for r in rows]
    b = {"results": [{"id": r["id"], "label": r["label"], "rw_bw": r["rw_bw"], "rw_aat": r["rw_aat"], "score": r["score"]} for r in rows],
         "n": len(rows), "scope": "this analysis" if project is not None else "every analysis"}
    b["metrics"] = _pool([p["metrics"] for p in profs])
    b["statistics"] = _pool([p["statistics"] for p in profs])
    b["xml"] = _pool([p["xml"] for p in profs])
    for k in ("rw_bw", "rw_aat", "score"):
        vals = [r[k] for r in rows if r[k] is not None]
        b[k] = statistics.fmean(vals) if vals else None
    return b


def worse_pct(ending, run, bench):
    d = better_dir = catalog.better(ending)
    if better_dir is None or run is None or not bench:
        return None
    d = (bench - run) / bench if better_dir == "higher" else (run - bench) / bench
    return round(100.0 * d, 1)


def _r(x, nd=1):
    return round(x, nd) if isinstance(x, (int, float)) and not (isinstance(x, float) and math.isnan(x)) else None


def compare(store, rid, project=None, cfg=None):
    r = store.result(rid)
    if not r:
        return {"error": "no such result"}
    s = analyze.settings(cfg)
    flag = float(s.get("worse_pct") or 10.0)
    b = benchmark(store, project, exclude=rid)
    prof = analyze.profile(store, rid)
    res = {"result": {"id": rid, "label": r["label"], "verdict": r["verdict"], "rw_bw": r["rw_bw"], "rw_aat": r["rw_aat"],
                      "score": r["score"], "score_name": r["score_name"], "headline_from": r["headline_from"]},
           "baseline": {"n": b["n"], "results": b["results"], "scope": b["scope"], "rw_bw": b["rw_bw"], "rw_aat": b["rw_aat"], "score": b["score"]},
           "flag_pct": flag}
    if not b["n"]:
        res["error"] = ("no baseline result yet: tick \"baseline\" for the good results (or set the limits pcm10.min_rw_bw_mbps / "
                        "pcm10.max_rw_aat_us so that PASS results join it), then compare again")
        return res
    hl = []
    for k, ending, words in (("rw_bw", "bw", "read/write bandwidth (B/s)"), ("rw_aat", "aat", "read/write average access time (µs)"),
                             ("score", None, r["score_name"] or "score")):
        rv, bv = r[k], b[k]
        if rv is None and bv is None:
            continue
        wp = worse_pct(ending, rv, bv) if ending else (round(100.0 * (bv - rv) / bv, 1) if rv is not None and bv else None)
        hl.append({"metric": k, "words": words, "run": _r(rv, 3), "bench": _r(bv, 3), "worse_pct": wp})
    res["headline"] = hl
    rows = []
    for key in set(prof["metrics"]) | set(b["metrics"]):
        typ, trace, f, e = key
        rv = prof["metrics"].get(key)
        bm = b["metrics"].get(key)
        if rv is None or not bm:
            continue
        wp = worse_pct(e, rv, bm["mean"])
        z = (rv - bm["mean"]) / bm["std"] if bm["std"] else None
        rows.append({"type": typ, "trace": trace, "trace_words": catalog.TRACES.get(trace, ""), "filter": f, "ending": e,
                     "metric": "%s_%s" % (f, e), "unit": catalog.unit(e), "run": _r(rv, 3), "bench": _r(bm["mean"], 3),
                     "bench_std": _r(bm["std"], 3), "bench_n": bm["n"], "worse_pct": wp, "z": _r(z, 2),
                     "better": catalog.better(e)})
    ranked = sorted([x for x in rows if x["worse_pct"] is not None], key=lambda x: -x["worse_pct"])
    res["worst_metrics"] = ranked[:60]
    res["metrics_compared"] = len(rows)
    res["metrics_worse"] = sum(1 for x in ranked if x["worse_pct"] >= flag)
    res["metrics_missing_in_run"] = sorted({"%s_%s" % (k[2], k[3]) for k in b["metrics"] if k not in prof["metrics"]})[:40]
    # per trace: its read/write bandwidth and access time, and its worst metric
    traces = {}
    for x in rows:
        if x["type"] != "trace" and x["trace"] != "all_traces":
            continue
        t = traces.setdefault(x["trace"], {"trace": x["trace"], "words": x["trace_words"], "worst": None, "n_worse": 0, "rw_bw": None, "rw_aat": None})
        if x["filter"] == "rw" and x["ending"] in ("bw", "aat"):
            t["rw_" + x["ending"]] = {"run": x["run"], "bench": x["bench"], "worse_pct": x["worse_pct"]}
        if x["worse_pct"] is not None:
            if x["worse_pct"] >= flag:
                t["n_worse"] += 1
            if t["worst"] is None or x["worse_pct"] > t["worst"]["worse_pct"]:
                t["worst"] = {"metric": x["metric"], "run": x["run"], "bench": x["bench"], "worse_pct": x["worse_pct"], "unit": x["unit"]}
    res["traces"] = sorted(traces.values(), key=lambda t: -((t["worst"] or {}).get("worse_pct") or -1e9))
    # access-time percentiles (the latency profile) per filter, aggregated over all traces, and per trace for rw / read / write
    res["percentiles"] = {}
    for trace in ["all_traces"] + sorted({k[1] for k in prof["metrics"] if k[1] != "all_traces"}):
        per = {}
        for f in PCT_FILTERS if trace == "all_traces" else ("rw", "read", "write"):
            pts = []
            for e in catalog.PERCENTILES:
                key = next((k for k in (("aggregated", trace, f, e), ("trace", trace, f, e)) if k in prof["metrics"] or k in b["metrics"]), None)
                if not key:
                    continue
                rv = prof["metrics"].get(key)
                bm = (b["metrics"].get(key) or {}).get("mean")
                pts.append({"p": e, "words": catalog.PERCENTILE_WORDS[e], "run": _r(rv), "bench": _r(bm), "worse_pct": worse_pct(e, rv, bm)})
            if pts:
                per[f] = pts
        if per:
            res["percentiles"][trace] = per
    # pass to pass: the spread of each trace's bandwidth over the passes (consistency)
    spread = {}
    for p in prof["passes"]:
        if p["ending"] == "bw":
            spread.setdefault(p["trace"], []).append(p["value"])
    res["passes"] = [{"trace": t, "values": [_r(v, 1) for v in vs], "spread_pct": _r(100.0 * (max(vs) - min(vs)) / max(vs), 1) if len(vs) > 1 and max(vs) else None}
                     for t, vs in sorted(spread.items())]
    # statistics should not change between runs with the same settings: a difference says the trace selection differs
    sd = []
    for key, v in prof["statistics"].items():
        bm = b["statistics"].get(key)
        if bm and bm["mean"] and abs(v - bm["mean"]) > 1e-9 * max(1.0, abs(bm["mean"])):
            sd.append({"trace": key[0], "name": key[1], "run": _r(v, 3), "bench": _r(bm["mean"], 3)})
    res["statistics_differ"] = sd[:40]
    if sd:
        res["note"] = ("%d trace statistic(s) differ from the baseline: UL says they do not change from run to run with the same "
                       "settings, so this result and the baseline may not use the same traces or settings" % len(sd))
    return res


def flat_rows(res, level="metric"):
    if level == "trace":
        return [{"trace": t["trace"], "words": t["words"], "metrics_worse": t["n_worse"],
                 "worst_metric": (t["worst"] or {}).get("metric"), "worst_run": (t["worst"] or {}).get("run"),
                 "worst_bench": (t["worst"] or {}).get("bench"), "worst_pct": (t["worst"] or {}).get("worse_pct"),
                 "rw_bw_run": (t["rw_bw"] or {}).get("run"), "rw_bw_bench": (t["rw_bw"] or {}).get("bench"),
                 "rw_aat_run": (t["rw_aat"] or {}).get("run"), "rw_aat_bench": (t["rw_aat"] or {}).get("bench")} for t in res.get("traces", [])]
    if level == "percentile":
        out = []
        for trace, per in (res.get("percentiles") or {}).items():
            for f, pts in per.items():
                for p in pts:
                    out.append({"trace": trace, "filter": f, "percentile": p["words"], "run_us": p["run"], "bench_us": p["bench"], "worse_pct": p["worse_pct"]})
        return out
    return list(res.get("worst_metrics") or [])
