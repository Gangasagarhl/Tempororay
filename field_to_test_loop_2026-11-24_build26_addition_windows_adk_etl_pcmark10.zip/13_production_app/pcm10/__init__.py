"""PCMark 10 Storage benchmark results (UL Benchmarks): read, store, pool good results into a benchmark, compare.

Built from UL's documentation only (support.benchmarks.ul.com, articles 44002171518 "Result data in detail" and
44002171465 "Full System Drive Benchmark", read 2026-11-24): NO real PCMark 10 result file was available. What UL documents
is used as written (file names, metric and statistic names, units, trace labels, type = trace | aggregated); what UL does
NOT document (the header row, whether a metric is a column or a row, the separator) is detected from each file, and every
column the reader did not understand is reported, so the first real file shows at once what has to be adjusted.

    discover.discover(folder)        -> results: every .pcmark10-result (a ZIP, whatever its name) and loose CSV / XML files
    reader.read_result(result)       -> metric rows (type, trace, pass, filter, ending, value), statistics, notes
    analyze.analyze_folder(...)      -> every result read and stored (store.Store, db/pcmark10.sqlite)
    compare.benchmark / compare.compare  -> the baseline results pooled; one result against them, worst first
"""
CATEGORY = "pcmark10_storage"
CATEGORY_NAME = "PCMark 10 Storage"
UNVERIFIED = ("Built from UL's documentation: no real PCMark 10 result file has been seen yet. The layout of the CSV files is "
              "detected from each file; columns that were not understood are listed with every result.")
