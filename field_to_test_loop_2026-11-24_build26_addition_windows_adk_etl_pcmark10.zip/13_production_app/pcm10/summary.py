"""A PCMark 10 comparison in words: written by the program; with a model connected, the model's summary is added and every
number in it is checked against the comparison (adk_etl.summary.grounded), sentences with other numbers are left out."""
import json
import re

from adk_etl.summary import _n, _numbers, grounded

SCHEMA = {"type": "object", "properties": {"summary": {"type": "string"},
                                           "likely_causes": {"type": "array", "items": {"type": "string"}}}, "required": ["summary"]}


def _mbps(bps):
    return None if bps is None else round(bps / 1e6, 1)


def written(res):
    if res.get("error") and "headline" not in res:
        return res["error"]
    r, b = res["result"], res["baseline"]
    lines = ["%s: verdict %s. Compared with %d baseline result(s) (%s)." % (r["label"], r["verdict"], b["n"], b["scope"])]
    if res.get("error"):
        lines.append(res["error"])
        return "\n".join(lines)
    for h in res.get("headline", []):
        if h["metric"] == "rw_bw":
            lines.append("Read/write bandwidth %s MB/s vs %s MB/s (%s%% worse)." % (_n(_mbps(h["run"])), _n(_mbps(h["bench"])), _n(h["worse_pct"])))
        elif h["metric"] == "rw_aat":
            lines.append("Read/write average access time %s µs vs %s µs (%s%% worse)." % (_n(h["run"]), _n(h["bench"]), _n(h["worse_pct"])))
        else:
            lines.append("%s %s vs %s." % (h["words"], _n(h["run"]), _n(h["bench"])))
    lines.append("%d of %d metrics compared are %s%% or more worse than the baseline." % (res["metrics_worse"], res["metrics_compared"], _n(res["flag_pct"])))
    bad = [t for t in res.get("traces", []) if t["worst"] and t["worst"]["worse_pct"] >= res["flag_pct"]][:5]
    for t in bad:
        w = t["worst"]
        lines.append("Trace %s (%s): worst %s %s vs %s %s (%s%% worse); %d metrics worse." % (
            t["trace"], t["words"] or "-", w["metric"], _n(w["run"]), _n(w["bench"]), w["unit"], _n(w["worse_pct"]), t["n_worse"]))
    pc = ((res.get("percentiles") or {}).get("all_traces") or {})
    for f in ("rw", "read", "write"):
        pts = {p["p"]: p for p in pc.get(f, [])}
        if "at99" in pts or "at9999" in pts:
            p99, p9999 = pts.get("at99", {}), pts.get("at9999", {})
            lines.append("Access-time percentiles, %s, all traces: 99%% %s µs vs %s; 99.99%% %s µs vs %s." % (
                f, _n(p99.get("run")), _n(p99.get("bench")), _n(p9999.get("run")), _n(p9999.get("bench"))))
    if res.get("note"):
        lines.append(res["note"])
    return "\n".join(lines)


def summarise(res, llm=None):
    out = {"by": "the program", "text": written(res), "likely_causes": [], "unchecked": []}
    if res.get("error") or llm is None or str(getattr(llm, "name", "")).startswith("stand"):
        return out
    facts = {k: res.get(k) for k in ("result", "baseline", "headline", "metrics_worse", "metrics_compared", "flag_pct", "note")}
    facts["traces"] = res.get("traces", [])[:8]
    facts["worst_metrics"] = res.get("worst_metrics", [])[:15]
    facts["percentiles_all_traces"] = (res.get("percentiles") or {}).get("all_traces")
    prompt = ("You are a storage performance engineer. A PCMark 10 Storage result is compared with baseline results (B/s = bytes per "
              "second, µs = microseconds; worse_pct = how much worse than the baseline in %%; traces are UL's recorded workloads).\n\n"
              "DATA:\n%s\n\nWrite 'summary' (at most 150 words: how much worse, in which traces, which kind of operations - read / write, "
              "small / large, random / sequential - and which latency percentiles) and 'likely_causes' (up to 4 short hypotheses). "
              "Use ONLY numbers that are in DATA. Answer as JSON." % json.dumps(facts, ensure_ascii=False, default=str))
    try:
        ans, _c = llm.generate_json(prompt, SCHEMA, max_tokens=1200)
    except Exception as exc:                            # noqa: BLE001
        out["model_error"] = str(exc)[:300]
        return out
    if not isinstance(ans, dict) or "_error" in ans or not ans.get("summary"):
        out["model_error"] = "no usable answer"
        return out
    known = _numbers(facts, set())
    keep, drop = [], []
    for sent in re.split(r"(?<=[.!?])\s+", ans["summary"].strip()):
        (keep if grounded(sent, known) else drop).append(sent)
    out.update({"by": "model %s (every number checked against the comparison)" % getattr(llm, "name", "?"), "model_text": " ".join(keep),
                "likely_causes": [c for c in ans.get("likely_causes") or [] if isinstance(c, str) and grounded(c, known)], "unchecked": drop})
    return out
