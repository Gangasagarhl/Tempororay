"""From ONE folder to the PCMark 10 Storage results in it, by CONTENT, whatever the files are called.

    inv = discover(folder)     never raises for bad input

  - a ZIP archive (its first bytes are PK\\x03\\x04, whatever its name or ending: .pcmark10-result, .zip, renamed) is one
    result when a CSV inside it is a PCMark 10 metrics or statistics table, or it holds an XML with rw_bw / rw_aat;
  - CSV / TXT / TSV files outside archives are read by their header and cells (reader.classify); the PCMark 10 tables of
    one folder are one result;
  - XML files outside archives count when they hold rw_bw / rw_aat or a score (Ariel.xml, an XML export).
Each result gets an id from its path. Several results in one folder are normal (one per run of the benchmark).
"""
import hashlib
import os
import time
import zipfile

from . import reader

SKIP_DIRS = {"__pycache__", ".git", ".venv", "node_modules", "adk_cache"}
MAX_MEMBER = 200 * 1024 * 1024
HEAD = 256 * 1024
XML_WHOLE = 20 * 1024 * 1024
TABLE_ENDINGS = (".csv", ".txt", ".tsv", ".tab", "")


def result_id(path):
    return hashlib.sha1(os.path.normcase(os.path.abspath(path)).encode("utf-8")).hexdigest()[:12]


def is_zip(path):
    try:
        with open(path, "rb") as fh:
            return fh.read(4) == b"PK\x03\x04"
    except OSError:
        return False


def classify_bytes(name, raw):
    """{"name", "role": metrics | statistics | xml | None, "layout"} of one file's first bytes."""
    ext = os.path.splitext(name)[1].lower()
    text, enc = reader.decode(raw)
    if ext == ".xml" or text.lstrip().startswith("<"):
        named = reader.read_xml_text(text)
        h = reader.headline_from_xml(named)
        return {"name": name, "role": "xml" if h else None, "layout": None, "encoding": enc, "headline": h}
    if ext in TABLE_ENDINGS:
        c = reader.classify(reader.parse_csv(text, max_rows=400))
        return {"name": name, "role": c["role"], "layout": c["layout"], "encoding": enc}
    return {"name": name, "role": None, "layout": None, "encoding": enc}


def _zip_members(path):
    out, problem = [], None
    try:
        with zipfile.ZipFile(path) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                n = info.filename
                ext = os.path.splitext(n)[1].lower()
                if ext not in TABLE_ENDINGS + (".xml",) or info.file_size > MAX_MEMBER:
                    out.append({"name": n, "role": None, "size": info.file_size})
                    continue
                with z.open(info) as fh:                # an XML is read whole: a cut one does not parse
                    head = fh.read(XML_WHOLE if ext == ".xml" else HEAD)
                c = classify_bytes(n, head)
                c["size"] = info.file_size
                out.append(c)
    except (zipfile.BadZipFile, OSError, RuntimeError) as exc:
        problem = "the archive cannot be opened: %s" % exc
    return out, problem


def discover(folder, max_depth=10):
    t0 = time.perf_counter()
    folder = os.path.abspath(os.path.expandvars(os.path.expanduser(str(folder or "").strip().strip('"'))))
    inv = {"folder": folder, "results": [], "errors": [], "problems": [], "ignored": [], "seconds": 0.0}
    if not os.path.isdir(folder):
        inv["errors"].append("folder not found: %s" % folder)
        return inv
    base = folder.rstrip("\\/").count(os.sep)
    loose = {}
    for dirpath, dirnames, files in os.walk(folder):
        dirnames[:] = sorted(d for d in dirnames if d.lower() not in SKIP_DIRS and not d.startswith("."))
        if dirpath.count(os.sep) - base >= max_depth:
            dirnames[:] = []
        for f in sorted(files, key=str.lower):
            full = os.path.join(dirpath, f)
            ext = os.path.splitext(f)[1].lower()
            if is_zip(full):
                members, problem = _zip_members(full)
                used = [m for m in members if m.get("role")]
                if problem:
                    inv["problems"].append("%s: %s" % (f, problem))
                elif used:
                    inv["results"].append({"id": result_id(full), "label": os.path.splitext(f)[0], "kind": "archive", "path": full,
                                           "files": used, "other_members": len(members) - len(used),
                                           "named_as_result": f.lower().endswith(".pcmark10-result")})
                else:
                    inv["ignored"].append("%s: an archive without a PCMark 10 table or result XML" % f)
                continue
            if ext in TABLE_ENDINGS + (".xml",):
                try:
                    with open(full, "rb") as fh:
                        head = fh.read(XML_WHOLE if ext == ".xml" else HEAD)
                except OSError:
                    continue
                c = classify_bytes(f, head)
                if c.get("role"):
                    c["path"] = full
                    loose.setdefault(dirpath, []).append(c)
    for d in sorted(loose, key=str.lower):
        files = loose[d]
        if not any(x["role"] in ("metrics", "statistics") for x in files) and not any(x["role"] == "xml" for x in files):
            continue
        rel = os.path.relpath(d, folder)
        inv["results"].append({"id": result_id(d), "label": os.path.basename(folder) if rel == "." else rel, "kind": "folder",
                               "path": d, "files": files, "other_members": 0, "named_as_result": False})
    if not inv["results"]:
        inv["errors"].append("no PCMark 10 Storage result under %s: no .pcmark10-result archive and no CSV with UL's metric or "
                             "statistic names" % folder)
    inv["seconds"] = round(time.perf_counter() - t0, 3)
    return inv


def read_member(result, name):
    """The full bytes of one file of a result (a member of its archive, or a loose file)."""
    if result["kind"] == "archive":
        with zipfile.ZipFile(result["path"]) as z:
            return z.read(name)
    f = next(x for x in result["files"] if x["name"] == name)
    with open(f["path"], "rb") as fh:
        return fh.read()


def looks_like_pcmark(inv):
    return bool(inv.get("results"))


def brief(inv):
    return [{"id": r["id"], "label": r["label"], "kind": r["kind"], "path": r["path"],
             "files": [{"name": f["name"], "role": f["role"], "layout": f.get("layout")} for f in r["files"]],
             "named_as_result": r["named_as_result"]} for r in inv.get("results", [])]


__all__ = ["discover", "read_member", "brief", "looks_like_pcmark", "classify_bytes", "is_zip"]
