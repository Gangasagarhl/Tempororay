"""What UL documents about PCMark 10 Storage result data, as data (source: support.benchmarks.ul.com/support/solutions/articles/
44002171518-result-data-in-detail and 44002171465-full-system-drive-benchmark, read 2026-11-24).

    split_metric("read_s_rnd_at99") -> ("read_s_rnd", "at99")       a metric = <filter>_<ending>
    better("at99") -> "lower"; better("bw") -> "higher"; better("count") -> None (neither: a property of the workload)
"""
STATISTICS_FILE = "pcmark_storage_trace_statistics.csv"
METRICS_FILE = "pcmark_storage_trace_metrics.csv"
METRICS_FILE_SHORT = "metrics.csv"          # the name another UL page uses for the same file
SECONDARY_FILE = "Ariel.xml"                # holds the multi-pass metrics rw_bw and rw_aat
RESULT_EXTENSION = ".pcmark10-result"       # a ZIP archive

# trace statistics (constant from run to run with the same settings): name -> (unit, UL's words)
STATISTICS = {
    "bytes_read": ("bytes", "Number of bytes read"),
    "bytes_write": ("bytes", "Number of bytes written"),
    "bytes_read_aligned": ("bytes", "Number of bytes read after alignment to the target drive"),
    "bytes_write_aligned": ("bytes", "Number of bytes written after alignment to the target drive"),
    "reads": ("", "Number of read operations"),
    "writes": ("", "Number of write operations"),
    "createfiles": ("", "Number of CreateFile operations (in the file system level)"),
    "closefiles": ("", "Number of CloseFile operations (in the file system level)"),
    "flushes": ("", "Number of flushes"),
    "idle_periods": ("", "Number of idle periods"),
    "idle": ("µs", "The sum of all idle times"),
    "idle_compressed": ("µs", "The sum of idle times after the idle time compression"),
    "busy": ("µs", "The sum of all busy times"),
    "access": ("µs", "The sum of all access times"),
    "compressed_playback_time": ("ms", "The playback time with idle times compressed (= busy + idle_compressed)"),
    "bandwidth": ("B/s", "The bandwidth (= bytes moved / busy)"),
    "average_access": ("µs", "The average access time (= access / the number of I/Os)"),
    "max_read_size": ("B", "The largest read operation"),
    "max_write_size": ("B", "The largest write operation"),
    "max_read_location": ("", "The largest read location"),
    "max_write_location": ("", "The largest write location"),
    "max_queue_depth": ("", "The largest queue depth"),
}

# metric endings: ending -> (unit, UL's words, which way is better)
ENDINGS = {
    "count": ("", "The number of operations executed", None),
    "bytes": ("B", "The number of bytes transferred", None),
    "busy": ("µs", "The total busy time during the playback", "lower"),
    "notbusy": ("µs", "The total time being not busy during the playback", None),
    "dc": ("1/1000", "The duty cycle: busy against not busy, in permilles", None),
    "bw": ("B/s", "The bandwidth (= bytes moved / busy)", "higher"),
    "aat": ("µs", "The average access time (= total access / the number of I/Os)", "lower"),
    "at50": ("µs", "The 50% percentile of access times", "lower"),
    "at90": ("µs", "The 90% percentile of access times", "lower"),
    "at95": ("µs", "The 95% percentile of access times (UL's table prints its name as at90 a second time)", "lower"),
    "at99": ("µs", "The 99% percentile of access times", "lower"),
    "at9999": ("µs", "The 99.99% percentile of access times", "lower"),
}
PERCENTILES = ["at50", "at90", "at95", "at99", "at9999"]
PERCENTILE_WORDS = {"at50": "50%", "at90": "90%", "at95": "95%", "at99": "99%", "at9999": "99.99%"}

# metric filters (the <mf> prefix): filter -> UL's words
FILTERS = {
    "all": "All operations",
    "rw": "Read and write operations",
    "read": "Read operations",
    "write": "Write operations",
    "read_s": "Small read operations (up to 16 KB inclusive)",
    "write_s": "Small write operations (up to 16 KB inclusive)",
    "read_m": "Medium read operations (over 16 KB, up to 128 KB inclusive)",
    "write_m": "Medium write operations (over 16 KB, up to 128 KB inclusive)",
    "read_l": "Large read operations (over 128 KB)",
    "write_l": "Large write operations (over 128 KB; UL's table prints write_m beside it)",
    "read_s_rnd": "Small random read operations",
    "write_s_rnd": "Small random write operations",
    "read_seq": "Sequential read operations",
    "write_seq": "Sequential write operations",
    "create": "Create file operations",
    "close": "Close file operations",
    "flush": "Flush operations",
}
HEADLINE = [("rw", "bw"), ("rw", "aat")]          # the two secondary metrics of the score

# the 23 traces of the Full System Drive Benchmark: label -> UL's words
TRACES = {
    "boo": "Booting Windows 10",
    "sacr": "Adobe Acrobat - starting the application until usable",
    "saft": "Adobe After Effects - starting the application until usable",
    "sill": "Adobe Illustrator - starting the application until usable",
    "spre": "Adobe Premiere Pro - starting the application until usable",
    "slig": "Adobe Lightroom - starting the application until usable",
    "sps": "Adobe Photoshop - starting the application until usable",
    "bf": "Battlefield V - starting the game until the main menu",
    "cod": "Call of Duty Black Ops 4 - starting the game until the main menu",
    "ow": "Overwatch - starting the game until main menu",
    "aft": "Using Adobe After Effects",
    "exc": "Using Microsoft Excel",
    "ill": "Using Adobe Illustrator",
    "ind": "Using Adobe InDesign",
    "pow": "Using Microsoft PowerPoint",
    "psh": "Using Adobe Photoshop (heavy use)",
    "psl": "Using Adobe Photoshop (light use)",
    "cp1": "Copying 4 ISO image files, 20 GB in total, from a secondary drive to the target drive (write test)",
    "cp2": "Making a copy of the ISO files (read-write test)",
    "cp3": "Copying the ISO to a secondary drive (read test)",
    "cps1": "Copying 339 JPEG files, 2.37 GB in total, to the target drive (write test)",
    "cps2": "Making a copy of the JPEG files (read-write test)",
    "cps3": "Copying the JPEG files to another drive (read test)",
    "all_traces": "Average over all the trace results in the pass",
}

_ENDINGS_BY_LENGTH = sorted(ENDINGS, key=len, reverse=True)
_FILTERS_BY_LENGTH = sorted(FILTERS, key=len, reverse=True)


def norm(name):
    return str(name or "").strip().strip('"').strip().lower().replace(" ", "_").replace("-", "_")


def split_metric(name):
    """(filter, ending) of a metric name, or (None, None) when it is not <a documented filter>_<a documented ending>.
    A name with a documented ending but another prefix gives (prefix, ending)."""
    n = norm(name)
    for e in _ENDINGS_BY_LENGTH:
        if n.endswith("_" + e):
            f = n[: -len(e) - 1]
            if f:
                return f, e
    return None, None


def is_metric(name):
    f, e = split_metric(name)
    return f is not None and (f in FILTERS)


def is_statistic(name):
    return norm(name) in STATISTICS


def better(ending):
    return (ENDINGS.get(ending) or (None, None, None))[2]


def unit(ending):
    return (ENDINGS.get(ending) or ("",))[0]


def describe(filter_, ending):
    return "%s - %s" % (FILTERS.get(filter_, filter_), (ENDINGS.get(ending) or ("", ending))[1])
