"""Schema-tolerant reader of the XML files of a Windows ADK assessment (ported from etl_stage1_isolation/implementations/common
xmlread.py + schema.pick_boot_metric, extended to the other XML files of a run).

    role, info = sniff(path)               what an XML file is, from its CONTENT (never from its name):
                                           timing | io | analysis | machine | job | errors | other | unreadable
    rows, notes = read_timing_xml(path)    [{"kind", "name", "measure", "value"}]; the verdict metric has kind "boot"
    rows = read_io_xml(path)               per-process disk time / operations of a FastStartup_IO XML
    name, value, how = pick_boot_metric({name: value}, cfg)

Namespaces and letter case are ignored. Known sections of a timing XML:
    Metrics/MetricValue        ProgrammaticName (attribute or child) + Value (attribute or child)
                               <prefix>-Phase-<phase> -> kind phase; anything else -> kind metric (ms)
    ComponentTimings/ComponentTiming  ComponentName, Kind, TotalCPU, TotalDisk, DiskOps -> kind process or module
    services/<any>             Name + TotalTime -> kind service;  pnp/<any>  Name + InitTime -> kind driver
    <Metric name= value=>, <Measure Name= Value=>, <Activity component= duration_ms=> (other layouts)
Anything else: every element with a name-like attribute and a numeric time-like attribute becomes kind "other".
"""
import math
import os
import re
import xml.etree.ElementTree as ET

from . import config

MAX_XML_BYTES = 200 * 1024 * 1024
_PHASE_METRIC = re.compile(r"^(?:.*?-)?Phase-(.+)$", re.I)
_NAME_ATTRS = ("programmaticname", "componentname", "name", "component", "id")
_TIME_ATTRS = re.compile(r"(time|cpu|disk|duration|ms|init|total|value)", re.I)
_ITER_ATTRS = ("iteration", "number", "index", "run", "iter", "n")


def num(v):
    if v is None or v == "":
        return None
    try:
        f = float(str(v).strip().replace(",", ""))
        return None if math.isnan(f) or math.isinf(f) else f
    except ValueError:
        return None


def _local(tag):
    return str(tag).split("}")[-1].lower()


def _attrs(el):
    return {k.split("}")[-1].lower(): v for k, v in el.attrib.items()}


def _child_text(el, name):
    for ch in el:
        if _local(ch.tag) == name:
            return (ch.text or "").strip()
    return None


def parse(path):
    """(root element, problem): never raises."""
    try:
        if os.path.getsize(path) > MAX_XML_BYTES:
            return None, "XML larger than %d MB: not read" % (MAX_XML_BYTES // 1024 // 1024)
        return ET.parse(path).getroot(), None
    except (ET.ParseError, OSError, ValueError) as exc:
        return None, ("XML does not parse (%s: %s)" % (type(exc).__name__, exc))[:240]


# ------------------------------------------------------------------------------------------------ what an XML file is
def sniff(path):
    """(role, info) from the file's content. info: {"iteration": n or None, "root": tag, "problem": text or None}."""
    root, problem = parse(path)
    if root is None:
        return "unreadable", {"iteration": None, "root": None, "problem": problem}
    tags = {}
    for el in root.iter():
        t = _local(el.tag)
        tags[t] = tags.get(t, 0) + 1
    rt = _local(root.tag)
    it = None
    for el in [root] + list(root)[:5]:
        a = _attrs(el)
        for k in _ITER_ATTRS:
            v = num(a.get(k))
            if v is not None and v == int(v) and 0 <= v < 100000:
                it = int(v)
                break
        if it is not None:
            break
    if tags.get("metricvalue") or tags.get("componenttiming") or (
            (tags.get("metric") or tags.get("measure")) and ("assessment" in rt or "iteration" in tags or it is not None)):
        role = "timing"
    elif tags.get("processio") or rt in ("startupio", "io"):
        role = "io"
    elif tags.get("issue"):
        role = "analysis"
    elif "machineconfiguration" in rt or (tags.get("property") and "machine" in rt):
        role = "machine"
    elif "errorsandwarnings" in rt or rt in ("errors", "warnings"):
        role = "errors"
    elif "jobresult" in rt:
        role = "job"
    else:
        rows, _n = _generic_rows(root)
        name, _v, _how = pick_boot_metric({r["name"]: r["value"] for r in rows})
        role = "timing" if name else "other"
    return role, {"iteration": it, "root": rt, "problem": None}


# ------------------------------------------------------------------------------------------------ the verdict metric
def _norm(name):
    return "".join(ch for ch in str(name or "").lower() if ch not in "-_ \t\r\n")


def pick_boot_metric(names_values, cfg=None):
    """(name, value, how) of the metric that decides PASS / FAIL: how = exact | keyword | fallback | missing."""
    s = config.settings(cfg)
    items, seen = [], set()
    for name, value in (names_values or {}).items():
        v = num(value)
        if not name or v is None or name in seen:
            continue
        seen.add(name)
        items.append((str(name), v))
    by_norm = {}
    for name, v in items:
        by_norm.setdefault(_norm(name), (name, v))
    for cand in s["boot_metric_candidates"]:
        hit = by_norm.get(_norm(cand))
        if hit:
            return hit[0], hit[1], "exact"
    best = None
    for group in s["boot_metric_keywords"]:
        words = [_norm(w) for w in group if _norm(w)]
        for name, v in items:
            n = _norm(name)
            if words and all(w in n for w in words) and (best is None or len(n) < len(_norm(best[0]))):
                best = (name, v)
        if best:
            return best[0], best[1], "keyword"
    for fb in s["boot_metric_fallbacks"]:
        hit = by_norm.get(_norm(fb))
        if hit:
            return hit[0], hit[1], "fallback"
    return None, None, "missing"


# ------------------------------------------------------------------------------------------------ timing XML
def _generic_rows(root):
    rows, n = [], 0
    for el in root.iter():
        a = _attrs(el)
        tag = _local(el.tag)
        name = next((a[k] for k in _NAME_ATTRS if a.get(k)), None)
        if not name:
            continue
        for k, val in a.items():
            if k in _NAME_ATTRS or not _TIME_ATTRS.search(k):
                continue
            v = num(val)
            if v is not None:
                kind = "metric" if tag in ("metric", "measure") and k == "value" else "other"
                rows.append({"kind": kind, "name": name, "measure": "duration" if kind == "metric" else k, "value": v})
                n += 1
    return rows, n


def read_timing_xml(path, cfg=None):
    """(rows, notes). Never raises: an unreadable file gives [] and a note."""
    root, problem = parse(path)
    if root is None:
        return [], [problem]
    rows, notes = [], []
    found = {"metrics": 0, "components": 0, "services": 0, "pnp": 0, "activities": 0}
    for el in root.iter():
        tag = _local(el.tag)
        a = _attrs(el)
        if tag == "metricvalue":
            name = a.get("programmaticname") or _child_text(el, "programmaticname") or a.get("name") or ""
            raw = a.get("value") if a.get("value") is not None else _child_text(el, "value")
            v = num(raw)
            if not name or v is None:
                continue
            m = _PHASE_METRIC.match(name)
            rows.append({"kind": "phase" if m else "metric", "name": m.group(1) if m else name, "measure": "duration", "value": v})
            found["metrics"] += 1
        elif tag in ("metric", "measure") and (a.get("name") or a.get("programmaticname")):
            name = a.get("name") or a.get("programmaticname")
            v = num(a.get("value"))
            if v is None:
                continue
            m = _PHASE_METRIC.match(name) or re.match(r"^phase\s+(.+)$", name, re.I)
            rows.append({"kind": "phase" if m else "metric", "name": m.group(1) if m else name, "measure": "duration", "value": v})
            found["metrics"] += 1
        elif tag == "componenttiming":
            name = a.get("componentname") or a.get("name") or ""
            if not name:
                continue
            kind_txt = (a.get("kind") or "").lower()
            if "module" in kind_txt or "!" in name:
                kind, name = "module", name.split("!", 1)[-1]
            else:
                kind = "process"
            for attr, measure in (("totalcpu", "cpu"), ("totaldisk", "disk"), ("diskops", "diskops")):
                v = num(a.get(attr))
                if v is not None:
                    rows.append({"kind": kind, "name": name, "measure": measure, "value": v})
            found["components"] += 1
        elif tag == "activity" and (a.get("component") or a.get("name")):
            v = next((num(a[k]) for k in ("duration_ms", "duration", "time", "totaltime") if num(a.get(k)) is not None), None)
            if v is not None:
                kind = {"driverinit": "driver", "servicestart": "service"}.get((a.get("kind") or "").lower(), "activity")
                rows.append({"kind": kind, "name": a.get("component") or a.get("name"), "measure": "duration", "value": v})
                found["activities"] += 1
    for container, kind, attr, measure in (("services", "service", "totaltime", "total"), ("pnp", "driver", "inittime", "init")):
        for cont in root.iter():
            if _local(cont.tag) != container:
                continue
            for ch in cont:
                a = _attrs(ch)
                name = a.get("name") or _local(ch.tag)
                v = num(a.get(attr))
                if v is None:
                    v = next((num(val) for k, val in a.items() if k != "name" and _TIME_ATTRS.search(k) and num(val) is not None), None)
                if v is not None:
                    rows.append({"kind": kind, "name": name, "measure": measure, "value": v})
                    found[container] += 1
    if not any(found.values()):
        notes.append("no known section (Metrics / ComponentTimings / services / pnp): every named number was read")
        rows, _n = _generic_rows(root)
    boot_name, _v, how = pick_boot_metric({r["name"]: r["value"] for r in rows if r["kind"] in ("metric", "other")}, cfg)
    if boot_name is None:
        notes.append("no Fast Startup time in this XML")
    else:
        for r in rows:
            if r["kind"] in ("metric", "other") and r["name"] == boot_name:
                r["kind"], r["measure"] = "boot", "duration"
                break
        notes.append("Fast Startup time: %s (%s)" % (boot_name, how))
    return rows, notes


def boot_of(rows):
    """(value ms, metric name) of the row with kind boot, or (None, None)."""
    for r in rows or ():
        if r.get("kind") == "boot":
            return r["value"], r["name"]
    return None, None


def read_io_xml(path):
    """[{"kind": "process", "name", "measure": disk|diskops, "value"}] of a FastStartup_IO XML (<ProcessIO Name DiskTimeMs DiskOps/>)."""
    root, _p = parse(path)
    if root is None:
        return []
    rows = []
    for el in root.iter():
        if _local(el.tag) != "processio":
            continue
        a = _attrs(el)
        name = a.get("name") or a.get("process")
        if not name:
            continue
        for attr, measure in (("disktimems", "disk"), ("diskops", "diskops")):
            v = num(a.get(attr))
            if v is not None:
                rows.append({"kind": "process", "name": name, "measure": measure, "value": v})
    return rows


def read_analysis_xml(path):
    """[{"title", "message", "component", "duration_ms"}] of an assessment's analysis XML (<Issue> elements)."""
    root, _p = parse(path)
    if root is None:
        return []
    out = []
    for el in root.iter():
        if _local(el.tag) != "issue":
            continue
        out.append({"title": _child_text(el, "issuetitle") or _attrs(el).get("title") or "",
                    "message": (_child_text(el, "issuemessage") or "")[:400],
                    "component": _child_text(el, "component") or "",
                    "duration_ms": num(_child_text(el, "durationms"))})
    return out
