"""Benchmark and comparison.

    prof = run_profile(store, run_id)               one run, averaged over its iterations (per boot)
    bench = benchmark(store, scope_project, exclude) the PASS runs that are in the benchmark, pooled: the mean of their profiles
    res = compare(store, run_id, scope_project)     the run against the benchmark, ranked

Averaging. A run's value of an I/O total or a count is the mean over its traced iterations, an iteration where a process
did no I/O counting 0 (I/O per boot). A duration (phase, process lifetime) is the mean over the iterations where it exists.
The benchmark is the mean of the PASS runs' values (a run without the item counts 0 for I/O and counts, and is left out for
durations), with the standard deviation over the runs and how many runs hold the item.

Ranking (what took more time than in the PASS runs): phases by delta; per category (all, pre_logon, logon, post_logon)
the processes by delta of their disk I/O time; inside each process its commands (DiskRead / DiskWrite / DiskFlush and the
file I/O operations) by delta of their total time, each with its count, mean and max and the files that grew most.
"""
import statistics

from . import histogram
from .phases import CATEGORIES

CATS = ("all",) + CATEGORIES


def _mean(xs):
    return statistics.fmean(xs) if xs else 0.0


def run_profile(store, rid):
    run = store.run(rid)
    if not run:
        return None
    its = store.all("SELECT n, boot_ms, etl FROM iteration WHERE run=? ORDER BY n", (rid,))
    traced = [i["n"] for i in its if i["etl"]] or []
    nt = len(set(r["n"] for r in store.all("SELECT DISTINCT n FROM phase WHERE run=?", (rid,)))) or 0
    div = float(nt or 1)
    prof = {"run": rid, "label": run["label"], "verdict": run["verdict"], "boot_mean_ms": run["boot_mean_ms"], "iterations": len(its),
            "traced": nt, "boot_values": [i["boot_ms"] for i in its if i["boot_ms"] is not None]}
    # phases: mean over the iterations where present
    ph = {}
    for r in store.all("SELECT phase, category, duration_ms FROM phase WHERE run=?", (rid,)):
        ph.setdefault((r["phase"], r["category"]), []).append(r["duration_ms"])
    prof["phases"] = {k: _mean(v) for k, v in ph.items()}
    cat = {c: 0.0 for c in CATEGORIES}
    for (p, c), v in prof["phases"].items():
        cat[c] = cat.get(c, 0.0) + v
    prof["category_ms"] = cat
    # commands per (process, source, command, category): per boot
    cmd = {}
    for r in store.all("SELECT source, process, command, category, SUM(count) c, SUM(total_us) t, SUM(service_us) s, MAX(max_us) m, "
                       "SUM(bytes) b FROM command WHERE run=? GROUP BY source, process, command, category", (rid,)):
        cmd[(r["process"], r["source"], r["command"], r["category"])] = {"count": r["c"] / div, "total_us": r["t"] / div,
                                                                         "service_us": (r["s"] or 0) / div, "max_us": r["m"], "bytes": (r["b"] or 0) / div}
    prof["commands"] = cmd
    files = {}
    for r in store.all("SELECT process, command, category, file, SUM(count) c, SUM(total_us) t, MAX(max_us) m FROM command_file "
                       "WHERE run=? GROUP BY process, command, category, file", (rid,)):
        files[(r["process"], r["command"], r["category"], r["file"])] = {"count": r["c"] / div, "total_us": r["t"] / div, "max_us": r["m"]}
    prof["files"] = files
    cen = {}
    for r in store.all("SELECT process, event, category, SUM(count) c FROM census WHERE run=? GROUP BY process, event, category", (rid,)):
        cen[(r["process"], r["event"], r["category"])] = r["c"] / div
    prof["census"] = cen
    life = {}
    for r in store.all("SELECT process, lifetime_ms, first_start_ms, category FROM process WHERE run=?", (rid,)):
        d = life.setdefault(r["process"], {"lifetime": [], "start": [], "category": r["category"], "seen": 0})
        d["seen"] += 1
        if r["lifetime_ms"] is not None:
            d["lifetime"].append(r["lifetime_ms"])
        if r["first_start_ms"] is not None:
            d["start"].append(r["first_start_ms"])
    prof["processes"] = {k: {"lifetime_ms": _mean(v["lifetime"]) if v["lifetime"] else None,
                             "first_start_ms": _mean(v["start"]) if v["start"] else None, "category": v["category"], "seen": v["seen"]}
                         for k, v in life.items()}
    xml = {}
    for r in store.all("SELECT kind, name, measure, value FROM xml_item WHERE run=?", (rid,)):
        xml.setdefault((r["kind"], r["name"], r["measure"]), []).append(r["value"])
    prof["xml"] = {k: _mean(v) for k, v in xml.items()}
    return prof


def benchmark_runs(store, scope_project=None, exclude=None):
    sql = "SELECT * FROM run WHERE status='done' AND verdict='PASS' AND in_benchmark=1"
    args = []
    if scope_project is not None:
        sql += " AND project=?"
        args.append(scope_project)
    rows = store.all(sql + " ORDER BY id", tuple(args))
    return [r for r in rows if r["id"] != exclude]


def _pool(profiles, field, zero_missing=True, sub=None):
    keys = set()
    for p in profiles:
        keys |= set(p[field].keys())
    out = {}
    for k in keys:
        vals, present = [], 0
        for p in profiles:
            v = p[field].get(k)
            if v is not None and sub:
                v = v.get(sub)
            if v is None:
                if zero_missing:
                    vals.append(0.0)
                continue
            present += 1
            vals.append(float(v))
        if not vals:
            continue
        out[k] = {"mean": _mean(vals), "std": statistics.stdev(vals) if len(vals) > 1 else 0.0, "runs": present}
    return out


def benchmark(store, scope_project=None, exclude=None):
    runs = benchmark_runs(store, scope_project, exclude)
    profs = [run_profile(store, r["id"]) for r in runs]
    profs = [p for p in profs if p]
    b = {"runs": [{"id": p["run"], "label": p["label"], "boot_mean_ms": p["boot_mean_ms"], "traced": p["traced"]} for p in profs],
         "n_runs": len(profs), "scope": "this analysis" if scope_project is not None else "every analysis"}
    if not profs:
        return b
    boots = [p["boot_mean_ms"] for p in profs if p["boot_mean_ms"] is not None]
    b["boot_mean_ms"] = _mean(boots) if boots else None
    b["boot_std_ms"] = statistics.stdev(boots) if len(boots) > 1 else 0.0
    traced = [p for p in profs if p["traced"]]
    b["traced_runs"] = len(traced)
    b["phases"] = _pool(traced, "phases", zero_missing=False)
    b["category_ms"] = _pool(traced, "category_ms", zero_missing=False)
    b["commands"] = {k: v for k, v in _pool(traced, "commands", True, "total_us").items()}
    b["command_counts"] = _pool(traced, "commands", True, "count")
    b["command_max"] = _pool(traced, "commands", False, "max_us")
    b["files"] = _pool(traced, "files", True, "total_us")
    b["census"] = _pool(traced, "census", True)
    b["present"] = _pool(traced, "processes", False, "seen")
    b["lifetimes"] = _pool(traced, "processes", False, "lifetime_ms")
    b["starts"] = _pool(traced, "processes", False, "first_start_ms")
    b["xml"] = _pool(profs, "xml", False)
    return b


def _pct(d, base):
    return round(100.0 * d / base, 1) if base else None


def _bm(b, field, key):
    x = (b.get(field) or {}).get(key)
    return (x["mean"], x["std"], x["runs"]) if x else (0.0, 0.0, 0)


def compare(store, rid, scope_project=None, top_processes=30, top_commands=12, top_files=6, cfg=None):
    res = _compare(store, rid, scope_project, top_processes, top_commands, top_files)
    if res.get("error") and "phases" not in res:
        return res
    # I/O latency (5 µs buckets): per category and command, all processes together; the buckets themselves are read per selection
    bench_ids = [r["id"] for r in res["benchmark"]["runs"] if r.get("traced")]
    for x in [rid] + bench_ids:
        histogram.ensure(store, x, cfg)
    cmds = {c: set() for c in CATS}
    for p in res["by_category"].get("all", []):
        for cm in p["commands"]:
            cmds["all"].add((cm["source"], cm["command"]))
    for row in store.all("SELECT DISTINCT source, command, category FROM histogram WHERE source IN ('disk','file') AND run IN (%s)"
                         % ",".join("?" * (1 + len(bench_ids))), tuple([rid] + bench_ids)):
        cmds["all"].add((row["source"], row["command"]))
        if row["category"] in cmds:
            cmds[row["category"]].add((row["source"], row["command"]))
    res["latency"] = histogram.latency_overview(store, rid, bench_ids, CATS, {k: sorted(v) for k, v in cmds.items()})
    res["histogram_settings"] = histogram.settings(cfg)
    # every command under every process (adk_etl.commands): per category, the processes whose commands grew most
    ra, ba = all_commands_of(store, rid), all_commands_bench(store, bench_ids)
    if not ra["rows"]:
        res["all_commands_note"] = ("this run was analysed before every command was extracted (or its traces were not decoded): "
                                    "press Analyse again on page 1 to get every command under every process")
    res["all_commands"] = {c: all_commands_table(ra, ba, c, top_processes=40, top_commands=12) for c in CATS}
    res["all_commands_longest"] = {c: all_commands_table(ra, ba, c, top_processes=25, top_commands=8, sort="longest") for c in CATS}
    res["all_commands_bench_runs"] = len(bench_ids)
    return res


# ------------------------------------------------------------------------------------------------ every command under every process
def _traced_n(store, rid):
    return len({r["n"] for r in store.all("SELECT DISTINCT n FROM phase WHERE run=?", (rid,))}) or 0


def all_commands_of(store, rid, process=None):
    """{(process, command, category): {count, timed, total_us, max_us}} per boot (summed over the iterations, divided by the traced
    iterations), and the basis of each command."""
    div = float(_traced_n(store, rid) or 1)
    sql = ("SELECT process, command, category, SUM(count) c, SUM(timed) t, SUM(total_us) s, MAX(max_us) m, MAX(basis) b FROM command_all "
           "WHERE run=?" + (" AND process=?" if process else "") + " GROUP BY process, command, category")
    rows, basis = {}, {}
    for r in store.all(sql, (rid, process) if process else (rid,)):
        rows[(r["process"], r["command"], r["category"])] = {"count": r["c"] / div, "timed": r["t"] / div, "total_us": r["s"] / div, "max_us": r["m"]}
        basis[r["command"]] = r["b"]
    return {"rows": rows, "basis": basis}


def all_commands_bench(store, bench_ids, process=None):
    """The mean over the benchmark runs of all_commands_of (a run without the command counts 0; max is the mean of the runs' max)."""
    profs = [all_commands_of(store, b, process) for b in bench_ids]
    keys, basis = set(), {}
    for p in profs:
        keys |= set(p["rows"])
        basis.update(p["basis"])
    n = float(len(profs) or 1)
    out = {}
    for k in keys:
        vals = [p["rows"].get(k) for p in profs]
        present = [v for v in vals if v]
        out[k] = {"count": sum(v["count"] for v in present) / n, "timed": sum(v["timed"] for v in present) / n,
                  "total_us": sum(v["total_us"] for v in present) / n,
                  "max_us": statistics.fmean([v["max_us"] for v in present]) if present else 0.0, "runs": len(present)}
    return {"rows": out, "basis": basis, "n": len(profs)}


def all_commands_table(ra, ba, cat="all", process=None, top_processes=40, top_commands=12, sort="added"):
    """Per process its commands, the run against the benchmark, ranked by the time added (commands without a time: by the count added).
    sort = added: a process is ranked by its command that added most time against the benchmark (commands the benchmark's traces
    recorded first); sort = longest: by its longest command in this run alone."""
    want = (lambda c: True) if cat in (None, "", "all") else (lambda c: c == cat)
    run, bench = {}, {}
    for src, dst in ((ra["rows"], run), (ba["rows"], bench)):
        for (p, cmd, c), v in src.items():
            if not want(c) or (process and p != process):
                continue
            x = dst.setdefault((p, cmd), {"count": 0.0, "timed": 0.0, "total_us": 0.0, "max_us": 0.0, "runs": 0})
            x["count"] += v["count"]
            x["timed"] += v["timed"]
            x["total_us"] += v["total_us"]
            x["max_us"] = max(x["max_us"], v["max_us"] or 0)
            x["runs"] = max(x["runs"], v.get("runs", 0))
    basis = dict(ba["basis"])
    basis.update(ra["basis"])
    recorded = {cmd for (_p, cmd) in bench}                 # the kinds of command the benchmark's traces recorded at all
    procs = {}
    for k in set(run) | set(bench):
        p, cmd = k
        if p in NOT_A_PROCESS and not process:
            continue
        r = run.get(k, {"count": 0.0, "timed": 0.0, "total_us": 0.0, "max_us": 0.0})
        b = bench.get(k, {"count": 0.0, "timed": 0.0, "total_us": 0.0, "max_us": 0.0, "runs": 0})
        timed = (r["timed"] or b["timed"]) > 0
        e = procs.setdefault(p, {"process": p, "commands": [], "new": True, "n_commands": 0, "added_ms": 0.0, "top_delta_us": None})
        if b.get("runs"):
            e["new"] = False
        e["n_commands"] += 1
        d = r["total_us"] - b["total_us"]
        e["commands"].append({"command": cmd, "basis": basis.get(cmd, ""), "timed": timed, "recorded_in_bench": cmd in recorded,
                              "lifetime": "lifetime" in (basis.get(cmd) or ""),
                              "run_count": _r(r["count"]), "bench_count": _r(b["count"]), "delta_count": _r(r["count"] - b["count"]),
                              "run_us": _r(r["total_us"]), "bench_us": _r(b["total_us"]), "delta_us": _r(d) if timed else None,
                              "delta_pct": _pct(d, b["total_us"]) if timed else _pct(r["count"] - b["count"], b["count"]),
                              "run_mean_us": _r(r["total_us"] / r["timed"]) if r["timed"] else None,
                              "bench_mean_us": _r(b["total_us"] / b["timed"]) if b["timed"] else None,
                              "run_max_us": _r(r["max_us"]), "bench_max_us": _r(b["max_us"]), "new": not b.get("runs")})
    out = []
    for e in procs.values():
        # costs first (a time the command itself took), ranked by the time added; lifetimes (overlapping wall-clock spans) after them;
        # commands without a time last, by the count added
        e["commands"].sort(key=lambda x: (x["lifetime"], x["delta_us"] is None,
                                          -(x["delta_us"] if x["delta_us"] is not None else 0), -(x["delta_count"] or 0)))
        costs = [x for x in e["commands"] if x["delta_us"] is not None and not x["lifetime"]]
        compared = [x for x in costs if x["recorded_in_bench"]]
        best = max(compared or costs, key=lambda x: x["delta_us"]) if costs else None
        e["top_delta_us"] = best["delta_us"] if best else None
        e["top_command"] = best["command"] if best else (e["commands"][0]["command"] if e["commands"] else None)
        e["top_recorded_in_bench"] = bool(best and best["recorded_in_bench"])
        longest = max(costs, key=lambda x: x["run_us"] or 0) if costs else None   # this run alone: its longest command
        e["top_run_us"] = longest["run_us"] if longest else None
        e["top_run_command"] = longest["command"] if longest else None
        e["top_run_recorded_in_bench"] = bool(longest and longest["recorded_in_bench"])
        if top_commands:
            e["commands"] = e["commands"][:top_commands]
        out.append(e)
    if sort == "longest":
        out.sort(key=lambda e: -(e["top_run_us"] or 0))
    else:
        out.sort(key=lambda e: (not e["top_recorded_in_bench"], -(e["top_delta_us"] if e["top_delta_us"] is not None else -1e18)))
    return out[:top_processes] if top_processes else out


NOT_A_PROCESS = {"Idle", "(no process)", "(unknown)"}       # left out of the ranking (Idle = the processors' idle time)


def command_objects(store, rid, bench_ids, cat, process, command, top=40):
    """The objects of one command of one process (files, DLLs, drivers, services, modules, child command lines, wait reasons):
    the run against the benchmark, per boot."""
    def one(r_id):
        div = float(_traced_n(store, r_id) or 1)
        sql = "SELECT object, SUM(count) c, SUM(total_us) s, MAX(max_us) m FROM command_all_object WHERE run=? AND process=? AND command=?"
        args = [r_id, process, command]
        if cat not in (None, "", "all"):
            sql += " AND category=?"
            args.append(cat)
        return {r["object"]: {"count": r["c"] / div, "total_us": r["s"] / div, "max_us": r["m"]} for r in store.all(sql + " GROUP BY object", tuple(args))}
    run = one(rid)
    bench = {}
    for b in bench_ids:
        for k, v in one(b).items():
            x = bench.setdefault(k, {"count": 0.0, "total_us": 0.0, "max_us": 0.0})
            x["count"] += v["count"] / len(bench_ids)
            x["total_us"] += v["total_us"] / len(bench_ids)
            x["max_us"] = max(x["max_us"], v["max_us"] or 0)
    rows = []
    for k in set(run) | set(bench):
        r, b = run.get(k, {"count": 0.0, "total_us": 0.0, "max_us": 0.0}), bench.get(k, {"count": 0.0, "total_us": 0.0, "max_us": 0.0})
        rows.append({"object": k, "run_count": _r(r["count"]), "bench_count": _r(b["count"]), "run_us": _r(r["total_us"]), "bench_us": _r(b["total_us"]),
                     "delta_us": _r(r["total_us"] - b["total_us"]), "delta_count": _r(r["count"] - b["count"]), "run_max_us": _r(r["max_us"])})
    rows.sort(key=lambda x: (-(x["delta_us"] or 0), -(x["delta_count"] or 0)))
    return rows[:top]


def _compare(store, rid, scope_project=None, top_processes=30, top_commands=12, top_files=6):
    prof = run_profile(store, rid)
    if not prof:
        return {"error": "no such run"}
    b = benchmark(store, scope_project, exclude=rid)
    res = {"run": {"id": rid, "label": prof["label"], "verdict": prof["verdict"], "boot_mean_ms": prof["boot_mean_ms"],
                   "boot_values": prof["boot_values"], "iterations": prof["iterations"], "traced": prof["traced"]},
           "benchmark": {"n_runs": b["n_runs"], "traced_runs": b.get("traced_runs", 0), "runs": b["runs"], "scope": b["scope"],
                         "boot_mean_ms": b.get("boot_mean_ms"), "boot_std_ms": b.get("boot_std_ms")},
           "limit_ms": (store.run(rid) or {}).get("limit_ms")}
    if not b["n_runs"]:
        res["error"] = ("no PASS run is in the benchmark yet: analyse at least one run whose mean Fast Startup time is within the limit "
                        "(and keep it in the benchmark), then compare again")
        return res
    if b.get("boot_mean_ms") is not None and prof["boot_mean_ms"] is not None:
        d = prof["boot_mean_ms"] - b["boot_mean_ms"]
        res["boot"] = {"run_ms": prof["boot_mean_ms"], "bench_ms": round(b["boot_mean_ms"], 1), "delta_ms": round(d, 1),
                       "delta_pct": _pct(d, b["boot_mean_ms"])}
    if not prof["traced"] or not b.get("traced_runs"):
        res["note"] = ("per-command comparison needs traces: %s" % ("this run has no decoded trace" if not prof["traced"]
                                                                     else "no PASS run of the benchmark has a decoded trace"))
    # phases
    phases = []
    for k in set(prof["phases"]) | set((b.get("phases") or {}).keys()):
        rv = prof["phases"].get(k)
        bm, bs, bn = _bm(b, "phases", k)
        if rv is None and not bn:
            continue
        d = (rv or 0.0) - bm
        phases.append({"phase": k[0], "category": k[1], "run_ms": round(rv, 1) if rv is not None else None, "bench_ms": round(bm, 1),
                       "bench_std_ms": round(bs, 1), "delta_ms": round(d, 1), "delta_pct": _pct(d, bm), "bench_runs": bn})
    order = {c: i for i, c in enumerate(CATEGORIES)}
    phases.sort(key=lambda x: (order.get(x["category"], 9), -(x["delta_ms"] or 0)))
    res["phases"] = phases
    res["categories"] = []
    for c in CATEGORIES:
        rv = prof["category_ms"].get(c, 0.0)
        bm, bs, _bn = _bm(b, "category_ms", c)
        io_r = sum(v["total_us"] for k, v in prof["commands"].items() if k[3] == c and k[1] == "disk")
        io_b = sum(v["mean"] for k, v in (b.get("commands") or {}).items() if k[3] == c and k[1] == "disk")
        res["categories"].append({"category": c, "run_ms": round(rv, 1), "bench_ms": round(bm, 1), "delta_ms": round(rv - bm, 1),
                                  "run_disk_io_ms": round(io_r / 1000.0, 1), "bench_disk_io_ms": round(io_b / 1000.0, 1),
                                  "delta_disk_io_ms": round((io_r - io_b) / 1000.0, 1)})
    # processes > commands > files, per category
    res["by_category"] = {}
    for c in CATS:
        res["by_category"][c] = _processes(prof, b, c, top_processes, top_commands, top_files)
    # events (census): count per boot
    ev = []
    for k in set(prof["census"]) | set((b.get("census") or {}).keys()):
        rv = prof["census"].get(k, 0.0)
        bm, bs, bn = _bm(b, "census", k)
        d = rv - bm
        if abs(d) < 1:
            continue
        ev.append({"process": k[0], "event": k[1], "category": k[2], "run": round(rv, 1), "bench": round(bm, 1), "delta": round(d, 1),
                   "delta_pct": _pct(d, bm), "new": bn == 0})
    ev.sort(key=lambda x: -abs(x["delta"]))
    res["events"] = ev[:60]
    # processes that are new / gone, and lifetimes
    new, gone, life = [], [], []
    bl = b.get("lifetimes") or {}
    present = b.get("present") or {}
    for p, v in prof["processes"].items():
        if p not in present:
            new.append({"process": p, "category": v["category"], "first_start_ms": _r(v["first_start_ms"]), "lifetime_ms": _r(v["lifetime_ms"])})
        elif v["lifetime_ms"] is not None and p in bl:
            d = v["lifetime_ms"] - bl[p]["mean"]
            life.append({"process": p, "category": v["category"], "run_ms": _r(v["lifetime_ms"]), "bench_ms": _r(bl[p]["mean"]), "delta_ms": _r(d)})
    half = max(1, (b.get("traced_runs") or 0) // 2 + ((b.get("traced_runs") or 0) % 2))
    for p in set(present) - set(prof["processes"]):
        if present[p]["runs"] >= half:
            gone.append({"process": p, "bench_runs": present[p]["runs"]})
    life.sort(key=lambda x: -(x["delta_ms"] or 0))
    res["new_processes"] = sorted(new, key=lambda x: x["first_start_ms"] or 0)[:50]
    res["missing_processes"] = gone[:50]
    res["lifetimes"] = life[:30]
    # assessment XML numbers
    xd = []
    for k in set(prof["xml"]) | set((b.get("xml") or {}).keys()):
        if k[0] in ("boot",):
            continue
        rv = prof["xml"].get(k)
        bm, _bs, bn = _bm(b, "xml", k)
        if rv is None or not bn:
            continue
        d = rv - bm
        xd.append({"kind": k[0], "name": k[1], "measure": k[2], "run": _r(rv), "bench": _r(bm), "delta": _r(d), "delta_pct": _pct(d, bm)})
    xd.sort(key=lambda x: -(x["delta"] or 0))
    res["xml"] = xd[:40]
    return res


def _r(x, nd=1):
    return round(x, nd) if isinstance(x, (int, float)) else None


def _processes(prof, b, cat, top_processes, top_commands, top_files):
    bc = b.get("commands") or {}
    bcn = b.get("command_counts") or {}
    bmx = b.get("command_max") or {}
    bf = b.get("files") or {}
    want = (lambda c: True) if cat == "all" else (lambda c: c == cat)
    # commands summed over categories when cat == all
    run_cmd, bench_cmd = {}, {}
    for (p, src, cmd, c), v in prof["commands"].items():
        if want(c):
            x = run_cmd.setdefault((p, src, cmd), {"total_us": 0.0, "count": 0.0, "max_us": 0.0, "service_us": 0.0})
            x["total_us"] += v["total_us"]
            x["count"] += v["count"]
            x["service_us"] += v["service_us"]
            x["max_us"] = max(x["max_us"], v["max_us"] or 0)
    for (p, src, cmd, c), v in bc.items():
        if want(c):
            x = bench_cmd.setdefault((p, src, cmd), {"total_us": 0.0, "count": 0.0, "max_us": 0.0, "runs": 0})
            x["total_us"] += v["mean"]
            x["count"] += (bcn.get((p, src, cmd, c)) or {}).get("mean", 0.0)
            x["max_us"] = max(x["max_us"], (bmx.get((p, src, cmd, c)) or {}).get("mean", 0.0))
            x["runs"] = max(x["runs"], v["runs"])
    procs = {}
    for k in set(run_cmd) | set(bench_cmd):
        p, src, cmd = k
        r = run_cmd.get(k, {"total_us": 0.0, "count": 0.0, "max_us": 0.0, "service_us": 0.0})
        bb = bench_cmd.get(k, {"total_us": 0.0, "count": 0.0, "max_us": 0.0, "runs": 0})
        d = r["total_us"] - bb["total_us"]
        e = procs.setdefault(p, {"process": p, "run_disk_us": 0.0, "bench_disk_us": 0.0, "run_file_us": 0.0, "bench_file_us": 0.0,
                                 "run_count": 0.0, "bench_count": 0.0, "commands": [], "new": True})
        if bb["runs"]:
            e["new"] = False
        if src == "disk":
            e["run_disk_us"] += r["total_us"]
            e["bench_disk_us"] += bb["total_us"]
            e["run_count"] += r["count"]
            e["bench_count"] += bb["count"]
        else:
            e["run_file_us"] += r["total_us"]
            e["bench_file_us"] += bb["total_us"]
        e["commands"].append({"source": src, "command": cmd, "run_us": round(r["total_us"], 1), "bench_us": round(bb["total_us"], 1),
                              "delta_us": round(d, 1), "delta_pct": _pct(d, bb["total_us"]), "run_count": round(r["count"], 1),
                              "bench_count": round(bb["count"], 1),
                              "run_mean_us": round(r["total_us"] / r["count"], 1) if r["count"] else None,
                              "bench_mean_us": round(bb["total_us"] / bb["count"], 1) if bb["count"] else None,
                              "run_max_us": r["max_us"], "bench_max_us": round(bb["max_us"], 1), "files": []})
    out = []
    for e in procs.values():
        e["delta_disk_us"] = round(e["run_disk_us"] - e["bench_disk_us"], 1)
        e["delta_file_us"] = round(e["run_file_us"] - e["bench_file_us"], 1)
        e["delta_pct"] = _pct(e["delta_disk_us"], e["bench_disk_us"])
        for f in ("run_disk_us", "bench_disk_us", "run_file_us", "bench_file_us", "run_count", "bench_count"):
            e[f] = round(e[f], 1)
        e["commands"].sort(key=lambda x: -x["delta_us"])
        e["commands"] = e["commands"][:top_commands]
        for cm in e["commands"]:
            cm["files"] = _files(prof, bf, e["process"], cm["command"], want, top_files)
        out.append(e)
    out.sort(key=lambda x: -(x["delta_disk_us"] + x["delta_file_us"]))
    return out[:top_processes]


def _files(prof, bf, proc, cmd, want, top):
    run_f, bench_f = {}, {}
    for (p, c, cat, f), v in prof["files"].items():
        if p == proc and c == cmd and want(cat):
            x = run_f.setdefault(f, [0.0, 0.0])
            x[0] += v["total_us"]
            x[1] += v["count"]
    for (p, c, cat, f), v in bf.items():
        if p == proc and c == cmd and want(cat):
            bench_f[f] = bench_f.get(f, 0.0) + v["mean"]
    rows = []
    for f in set(run_f) | set(bench_f):
        r = run_f.get(f, [0.0, 0.0])
        bm = bench_f.get(f, 0.0)
        rows.append({"file": f, "run_us": round(r[0], 1), "bench_us": round(bm, 1), "delta_us": round(r[0] - bm, 1), "run_count": round(r[1], 1)})
    rows.sort(key=lambda x: -x["delta_us"])
    return rows[:top]


def flat_rows(res, level="command"):
    """Rows for a CSV export of a comparison: level = process | command | file | phase | event."""
    out = []
    if level == "phase":
        return list(res.get("phases") or [])
    if level == "event":
        return list(res.get("events") or [])
    if level == "all_commands":
        for cat, procs in (res.get("all_commands") or {}).items():
            for i, p in enumerate(procs, 1):
                for j, c in enumerate(p["commands"], 1):
                    out.append(dict({"category": cat, "process_rank": i, "process": p["process"], "process_new": p["new"], "command_rank": j},
                                    **{k: v for k, v in c.items()}))
        return out
    for cat, procs in (res.get("by_category") or {}).items():
        for i, p in enumerate(procs, 1):
            base = {"category": cat, "process_rank": i, "process": p["process"], "process_run_disk_us": p["run_disk_us"],
                    "process_bench_disk_us": p["bench_disk_us"], "process_delta_disk_us": p["delta_disk_us"], "process_new": p["new"]}
            if level == "process":
                out.append(dict(base, run_file_us=p["run_file_us"], bench_file_us=p["bench_file_us"], delta_file_us=p["delta_file_us"],
                                run_count=p["run_count"], bench_count=p["bench_count"]))
                continue
            for j, c in enumerate(p["commands"], 1):
                row = dict(base, command_rank=j, source=c["source"], command=c["command"], run_us=c["run_us"], bench_us=c["bench_us"],
                           delta_us=c["delta_us"], delta_pct=c["delta_pct"], run_count=c["run_count"], bench_count=c["bench_count"],
                           run_mean_us=c["run_mean_us"], bench_mean_us=c["bench_mean_us"], run_max_us=c["run_max_us"], bench_max_us=c["bench_max_us"])
                if level == "command":
                    out.append(row)
                else:
                    for f in c["files"]:
                        out.append(dict(row, file=f["file"], file_run_us=f["run_us"], file_bench_us=f["bench_us"], file_delta_us=f["delta_us"]))
    return out
