"""The phases of one boot / Fast Startup trace and where any timestamp falls.

Milestones are the FIRST start inside the trace of these processes (a process already running when the trace starts - shown
by xperf as MIN - is no milestone):
    smss.exe -> wininit.exe -> winlogon.exe -> LogonUI.exe -> userinit.exe -> explorer.exe
Back-to-back segments, from the trace start to its end, with the milestones that exist and come in time order:
    kernel_to_smss, smss_to_wininit, wininit_to_winlogon, winlogon_to_logonui     category pre_logon   (to the logon screen)
    logonui_to_userinit                                                           category logon       (the logon screen)
    userinit_to_explorer, explorer_to_end                                         category post_logon  (the user's session)
Without userinit.exe (no one logged on during the trace) everything after LogonUI.exe is "logon"; without LogonUI.exe the
logon boundary is winlogon.exe. The Fast Startup time measured from a trace (when no XML gives it) is the start of
LogonUI.exe: boot to the logon screen.
"""
import bisect

MILESTONES = [("smss", "smss.exe"), ("wininit", "wininit.exe"), ("winlogon", "winlogon.exe"), ("logonui", "logonui.exe"),
              ("userinit", "userinit.exe"), ("explorer", "explorer.exe")]
CATEGORIES = ("pre_logon", "logon", "post_logon")
CATEGORY_WORDS = {"pre_logon": "Pre-logon (boot to the logon screen)", "logon": "Logon (logon screen until the user session)",
                  "post_logon": "Post-logon (user session, desktop)"}


class Timeline:
    def __init__(self, processes, end_us):
        """processes: [{"name", "start_us" (None = before the trace)}]; end_us: the trace's last timestamp."""
        first = {}
        for p in processes or []:
            st = p.get("start_us")
            if st is None:
                continue
            k = (p.get("name") or "").lower()
            if k not in first or st < first[k]:
                first[k] = st
        self.milestones = {}
        last = 0
        for key, image in MILESTONES:
            t = first.get(image)
            if t is not None and t >= last:
                self.milestones[key] = t
                last = t
        self.end_us = max(int(end_us or 0), last)
        self.logon_us = self.milestones.get("logonui", self.milestones.get("winlogon"))
        self.session_us = self.milestones.get("userinit")
        self.segments = []
        prev_name, prev_t = "kernel", 0
        for key, _image in MILESTONES:
            if key in self.milestones:
                t = self.milestones[key]
                self.segments.append(self._seg(prev_name, key, prev_t, t))
                prev_name, prev_t = key, t
        self.segments.append(self._seg(prev_name, "end", prev_t, self.end_us))
        self._starts = [s["start_us"] for s in self.segments]

    def _seg(self, a, b, t0, t1):
        return {"phase": "%s_to_%s" % (a, b), "category": self.category_at(t0), "start_us": t0, "end_us": max(t0, t1),
                "duration_ms": round((max(t0, t1) - t0) / 1000.0, 3)}

    def category_at(self, t):
        if self.logon_us is None or t < self.logon_us:
            return "pre_logon"
        if self.session_us is None or t < self.session_us:
            return "logon"
        return "post_logon"

    def phase_at(self, t):
        """(phase, category) of a timestamp in µs from the trace start (None = before the trace: the first phase)."""
        if t is None:
            s = self.segments[0]
        else:
            i = bisect.bisect_right(self._starts, t) - 1
            s = self.segments[max(0, i)]
        return s["phase"], s["category"]

    def boot_ms(self):
        """Fast Startup time from the trace: boot to the logon screen (LogonUI.exe start), None when not in the trace."""
        t = self.milestones.get("logonui")
        return round(t / 1000.0, 3) if t is not None else None

    def category_ms(self):
        out = {c: 0.0 for c in CATEGORIES}
        for s in self.segments:
            out[s["category"]] += s["duration_ms"]
        return {k: round(v, 3) for k, v in out.items()}

    def as_dict(self):
        return {"milestones_ms": {k: round(v / 1000.0, 3) for k, v in self.milestones.items()},
                "end_ms": round(self.end_us / 1000.0, 3), "boot_ms": self.boot_ms(), "segments": self.segments,
                "category_ms": self.category_ms()}
