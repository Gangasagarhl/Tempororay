"""Windows ADK ETL + XML analytics (Fast Startup).

Input: any folder that holds Windows ADK assessment results (JobResults_* folders, renamed folders or a flat folder) with
ETL traces and/or the assessment's XML files. No CSV is needed: every ETL is decoded with xperf (Windows Performance
Toolkit) into CSV tables that are kept in a cache.

    discover.discover(folder)            -> runs, iterations, every file and why it was used or left out (by content, not by name)
    xmlread.read_timing_xml(path)        -> item rows of one ADK XML (schema tolerant) + the verdict ("boot") metric
    xperf.decode(etl, cache_root, cfg)   -> processes / disk commands / file commands / event census of one trace, as CSV
    phases.Timeline(processes, end_us)   -> pre-logon / logon / post-logon phases of one boot and where a timestamp falls
    analyze.analyze_folder(...)          -> every run of a folder decoded, aggregated and stored (store.Store)
    compare.benchmark(...) / compare.compare(...)
                                         -> the PASS runs pooled into a benchmark; a run compared with it, phase > process > command
    summary.summarise(...)               -> the comparison in words (the configured model, every number checked; else written by code)

Verdict (owner, 2026-11-24): the mean Fast Startup time of a run's iterations <= 14 s is PASS, above is FAIL
(config adk_etl.limit_ms).
"""
CATEGORY = "windows_adk_etl"          # project.source_tool of an analysis of Windows ADK ETL / XML files
CATEGORY_NAME = "Windows ADK (ETL + XML)"
