"""Every command under every process of a trace (owner, 2026-11-24: "all types of commands under each .exe, all those under an
ETL"), from the one streamed pass of `xperf -a dumper` (xperf.Dumper calls feed() for each event).

A "command" is a kind of event a process caused. Its time, when the trace gives one:
    ElapsedTime     an event that carries its own duration (µs, as xperf prints it): HardFault (page read from disk),
                    DPC / DPCTmr / Interrupt (driver code; no process: counted under "(DPC / ISR - drivers)" with the driver),
                    any other event type with an ElapsedTime field
    begin -> end    events a Windows component logs in pairs (<provider>/<task>/win:Start ... win:Stop): Code Integrity checks,
                    PnP driver init / device start, service start (ServiceMain), Prefetch, Shell ...; matched on the activity id
                    when there is one, else on process and thread; the command is <provider>/<task>
    lifetime        "Start process" (a child process the .exe started, with its command line) and "Create thread" (with its
                    start routine): from start to end when both are in the trace
    CPU             "CPU (run time)": exact, from context switches (each core's time from switch-in to switch-out);
                    "CPU (sampled)": sampled profile, samples x adk_etl.profile_interval_us (1 ms), per module
    count only      "Wait (switched out)" by wait reason (PageIn, Executive, WrQueue ...), "Load image" (DLLs), and every other
                    event type of the trace
Disk commands (DiskRead / DiskWrite / DiskFlush, issuing process from xperf -a diskio) and file I/O operations (FileIo*, their
duration from FileIoOpEnd) are added by xperf.decode with add_timed(). Rundown / snapshot events (…DCStart, …DCEnd, …Rundown)
and trace metadata are not commands and are left out (they stay in the event census).

Per (process, command, category): count, timed (how many had a time), total / max µs; per object (file, DLL, driver, service,
module, child command line, wait reason): count, total, max - the top adk_etl.top_objects of each command; and 5 µs buckets
(adk_etl.histogram) of the timed commands that are not disk or file I/O.
"""
from . import histogram

META = {"GroupMasks", "GroupMasksEnd", "EtwInternalVersion", "FirstReliableEventTimeStamp", "FirstReliableCSwitchEventTimeStamp",
        "ImageId", "FileVersion", "ThreadName", "FileNameCreate", "FileNameDelete", "FileNameRundown", "SystemPaths", "UnknownVolume",
        "VolumeMapping", "BuildInfo", "EventTrace", "SessionRundownDCStart", "SessionRundownDCEnd", "DiskReadInit", "DiskWriteInit",
        "DiskFlushInit", "FileIoOpEnd"}
OBJ_FIELDS = ["FileName", "NT FileName", "FileNameBuffer", "DriverName", "ServiceName", "OrigFileName", "KeyName", "Command Line",
              "Image!Function"]
NO_PROC_DRIVERS = "(DPC / ISR - drivers)"
BASIS = {"elapsed": "the event's own ElapsedTime (µs)", "pair": "begin -> end (win:Start -> win:Stop)",
         "child": "child process lifetime (wall clock; lifetimes overlap)", "thread": "thread lifetime (wall clock; lifetimes overlap)",
         "run": "CPU run time from context switches", "sample": "CPU samples x %d µs",
         "count": "count only", "disk": "IO time, issue -> completion (xperf -a diskio)", "file": "file operation duration (FileIoOpEnd)"}


class Plan:
    __slots__ = ("kind", "full", "nf", "pp", "et", "tid", "act", "obj", "objmod", "cpu", "newp", "oldp", "state", "reason",
                 "ppid", "cmdl", "count", "base", "quoted")

    def __init__(self):
        for s in self.__slots__:
            setattr(self, s, None)
        self.full = False


def _idx(fields, *names):
    for n in names:
        if n in fields:
            return fields.index(n) + 1                  # + 1: parts[0] is the event's name
    return None


def plan_of(name, fields):
    """How one event type is turned into commands (from its header); None = not a command."""
    if (name in META or name.startswith(("DbgId", "EventTrace", "UnknownEvent", "BeginHeader")) or "DCStart" in name or "DCEnd" in name
            or "Rundown" in name or name.startswith("FileIo") or name in ("DiskRead", "DiskWrite", "DiskFlush")):
        return None
    p = Plan()
    p.nf = len(fields)
    p.pp = next((i + 1 for i, h in enumerate(fields) if h == "Process Name ( PID)"), None)
    if name in ("CSwitch",):
        p.kind, p.full = "cswitch", True
        p.newp, p.oldp = _idx(fields, "New Process Name ( PID)"), _idx(fields, "Old Process Name ( PID)")
        p.cpu, p.state, p.reason = _idx(fields, "CPU"), _idx(fields, "OldState"), _idx(fields, "Wait Reason")
        return p if p.newp and p.oldp and p.cpu else None
    if name == "CSwitchCached":
        p.kind, p.full = "wait", True
        p.oldp, p.state, p.reason = _idx(fields, "Old Process Name ( PID)"), _idx(fields, "OldState"), _idx(fields, "Wait Reason")
        return p if p.oldp else None
    if name.startswith("SampledProfile"):
        p.kind, p.full = "sample", True
        p.objmod, p.count = _idx(fields, "Image!Function"), _idx(fields, "Count")
        return p if p.pp else None
    if name in ("P-Start", "P-End"):
        p.kind, p.full = ("pstart" if name == "P-Start" else "pend"), True
        p.ppid, p.cmdl = _idx(fields, "ParentPID"), _idx(fields, "Command Line")
        return p if p.pp else None
    if name in ("T-Start", "T-End"):
        p.kind, p.full = ("tstart" if name == "T-Start" else "tend"), True
        p.tid, p.objmod = _idx(fields, "ThreadID"), _idx(fields, "Image!Function")
        return p if p.pp and p.tid else None
    for suf in ("/win:Start", "/win:Stop"):
        if name.endswith(suf):
            p.kind, p.full = ("start" if suf == "/win:Start" else "stop"), True
            p.base = name[: -len(suf)]
            p.tid, p.act = _idx(fields, "ThreadID"), _idx(fields, "etw:ActivityId")
            p.obj = _idx(fields, *OBJ_FIELDS[:-1])
            p.quoted = p.obj is None
            return p
    p.obj = _idx(fields, *OBJ_FIELDS[:-1])
    p.objmod = _idx(fields, "Image!Function") if p.obj is None else None
    p.et = _idx(fields, "ElapsedTime")
    p.kind = "elapsed" if p.et else "count"
    p.quoted = "/" in name and p.obj is None and p.objmod is None    # a provider's event: its first quoted value names the object
    p.full = bool(p.et or p.obj or p.objmod or p.quoted)
    return p


def _span(parts, i, nf):
    """The value of field i, which may hold commas: everything up to the fields that follow it in the header."""
    if i is None or i >= len(parts):
        return ""
    trailing = nf - i
    if len(parts) > nf + 1 and trailing >= 0:
        v = ",".join(parts[i: len(parts) - trailing])
    else:
        v = parts[i]
    return v.strip().strip('"').strip()


def _module(parts, i):
    """The module of an Image!Function field ('ntdll.dll!0x00007ffb...' -> 'ntdll.dll'): addresses change with every boot (ASLR),
    so only the module can be compared between traces."""
    if i is None or i >= len(parts):
        return ""
    return parts[i].strip().strip('"').split("!")[0].strip()


FRIENDLY = {"I-Start": "Load image (I-Start)", "I-End": "Unload image (I-End)", "P-Zombie": "Process zombie (P-Zombie)"}


def _first_quoted(parts):
    for x in parts[2:]:
        x = x.strip()
        if x.startswith('"') and len(x) > 2:
            return x.strip('"')[:160]
    return ""


def _num(s):
    s = (s or "").strip()
    try:
        return int(s, 16) if s.lower().startswith("0x") else float(s)
    except ValueError:
        return None


class AllCommands:
    def __init__(self, pindex, resolve, cat_at, cfg=None, top_objects=15, profile_interval_us=1000):
        self.pi, self.resolve, self.cat_at = pindex, resolve, cat_at
        hs = histogram.settings(cfg)
        self.bw, self.fine = hs["width"], hs["fine_max"]
        self.top_objects, self.interval = top_objects, profile_interval_us
        self.agg, self.objs, self.buckets, self.basis = {}, {}, {}, {}
        self.plans = {}
        self.pairs, self.child, self.threads, self.oncpu = {}, {}, {}, {}

    def set_header(self, fields):
        for name, f in fields.items():
            self.plans[name] = plan_of(name, f)

    def plan(self, name):
        return self.plans.get(name)

    # ---------------------------------------------------------------- accumulation
    def _add(self, proc, cmd, cat, basis, dur=None, obj="", count=1, bucket=True):
        k = (proc, cmd, cat)
        a = self.agg.get(k)
        if a is None:
            a = self.agg[k] = [0, 0, 0.0, 0.0]
            self.basis.setdefault(cmd, basis)
        a[0] += count
        if dur is not None:
            a[1] += 1
            a[2] += dur
            if dur > a[3]:
                a[3] = dur
            if bucket:
                lo, hi = histogram.bucket(dur, self.bw, self.fine)
                bk = (proc, cmd, cat, lo, hi)
                self.buckets[bk] = self.buckets.get(bk, 0) + 1
        if obj:
            ok = (proc, cmd, cat, obj[:200])
            o = self.objs.get(ok)
            if o is None:
                o = self.objs[ok] = [0, 0.0, 0.0]
            o[0] += count
            if dur is not None:
                o[1] += dur
                if dur > o[2]:
                    o[2] = dur

    def _time_only(self, proc, cmd, cat, dur, obj):
        """A duration that ends a command already counted at its start (no second count)."""
        a = self.agg.get((proc, cmd, cat))
        if a is None:
            self._add(proc, cmd, cat, BASIS["pair"], dur, obj)
            return
        a[1] += 1
        a[2] += dur
        if dur > a[3]:
            a[3] = dur
        lo, hi = histogram.bucket(dur, self.bw, self.fine)
        bk = (proc, cmd, cat, lo, hi)
        self.buckets[bk] = self.buckets.get(bk, 0) + 1
        if obj:
            o = self.objs.setdefault((proc, cmd, cat, obj[:200]), [0, 0.0, 0.0])
            o[1] += dur
            o[2] = max(o[2], dur)

    def add_timed(self, proc, cmd, cat, dur, obj, kind):
        """Disk commands and file operations, from xperf.decode (their histograms come from their own tables)."""
        self._add(proc, cmd, cat, BASIS[kind], dur, obj, bucket=False)

    # ---------------------------------------------------------------- one event
    def feed(self, name, p, parts, ts, proc, pid, cat):
        k = p.kind
        if k == "count" or k == "elapsed":
            obj = _span(parts, p.obj, p.nf) if p.obj else (_module(parts, p.objmod) if p.objmod else
                                                             (_first_quoted(parts) if p.quoted else ""))
            if p.pp is None and k == "elapsed":
                proc = NO_PROC_DRIVERS
            dur = _num(parts[p.et]) if k == "elapsed" and p.et < len(parts) else None
            self._add(proc, FRIENDLY.get(name, name), cat, BASIS["elapsed" if dur is not None else "count"], dur, obj)
        elif k == "start" or k == "stop":
            act = parts[p.act].strip() if p.act and p.act < len(parts) else ""
            tid = parts[p.tid].strip() if p.tid and p.tid < len(parts) else ""
            key = (p.base, act) if act and not act.startswith("{00000000") else (p.base, pid, tid)
            obj = _span(parts, p.obj, p.nf) if p.obj else (_first_quoted(parts) if p.quoted else "")
            if k == "start":
                self.pairs.setdefault(key, []).append((ts, proc, cat, obj))
                self._add(proc, p.base, cat, BASIS["pair"], None, obj)
            else:
                st = self.pairs.get(key)
                if st:
                    t0, pr, c0, o0 = st.pop()
                    self._time_only(pr, p.base, c0, max(0.0, ts - t0), o0 or obj)
        elif k == "cswitch":
            cpu = parts[p.cpu].strip() if p.cpu < len(parts) else ""
            old = self.resolve(parts[p.oldp], ts) if p.oldp < len(parts) else "(unknown)"
            last = self.oncpu.get(cpu)
            if last is not None:
                t0, c0 = last
                self._add(old, "CPU (run time)", c0, BASIS["run"], max(0.0, ts - t0), "", bucket=False)
            self.oncpu[cpu] = (ts, cat)
            if p.state and p.state < len(parts) and parts[p.state].strip() == "Waiting":
                self._add(old, "Wait (switched out)", cat, BASIS["count"], None, parts[p.reason].strip() if p.reason and p.reason < len(parts) else "")
        elif k == "wait":
            if p.state and p.state < len(parts) and parts[p.state].strip() == "Waiting":
                old = self.resolve(parts[p.oldp], ts) if p.oldp < len(parts) else "(unknown)"
                self._add(old, "Wait (switched out)", cat, BASIS["count"], None, parts[p.reason].strip() if p.reason and p.reason < len(parts) else "")
        elif k == "sample":
            n = _num(parts[p.count]) if p.count and p.count < len(parts) else None
            n = int(n) if n and n > 0 else 1
            mod = _module(parts, p.objmod)
            self._add(proc, "CPU (sampled)", cat, BASIS["sample"] % self.interval, None, mod, count=n)
            a = self.agg[(proc, "CPU (sampled)", cat)]
            a[1] += n
            a[2] += n * self.interval
            a[3] = max(a[3], float(self.interval))
            o = self.objs.get((proc, "CPU (sampled)", cat, mod[:200]))
            if o is not None:
                o[1] += n * self.interval
        elif k == "pstart":
            ppid = _num(parts[p.ppid]) if p.ppid and p.ppid < len(parts) else None
            parent = self.pi.key(None, int(ppid), ts) if ppid is not None else "(unknown)"
            if isinstance(parent, type(None)) or parent in (None, ""):
                parent = "(pid %s)" % (int(ppid) if ppid is not None else "?")
            cmdl = _span(parts, p.cmdl, p.nf) if p.cmdl else ""
            obj = (proc + (" " + cmdl if cmdl and cmdl != "<Unknown>" else ""))[:200]
            self.child[pid] = (parent, ts, cat, obj)
            self._add(parent, "Start process", cat, BASIS["child"], None, obj)
        elif k == "pend":
            st = self.child.pop(pid, None)
            if st:
                parent, t0, c0, obj = st
                self._time_only(parent, "Start process", c0, max(0.0, ts - t0), obj)
        elif k == "tstart":
            tid = parts[p.tid].strip() if p.tid < len(parts) else ""
            fn = _module(parts, p.objmod)
            self.threads[(pid, tid)] = (proc, ts, cat, fn)
            self._add(proc, "Create thread", cat, BASIS["thread"], None, fn)
        elif k == "tend":
            tid = parts[p.tid].strip() if p.tid < len(parts) else ""
            st = self.threads.pop((pid, tid), None)
            if st:
                pr, t0, c0, fn = st
                self._time_only(pr, "Create thread", c0, max(0.0, ts - t0), fn)

    # ---------------------------------------------------------------- results
    def rows(self):
        return [{"process": k[0], "command": k[1], "category": k[2], "count": v[0], "timed": v[1], "total_us": round(v[2], 1),
                 "max_us": round(v[3], 1), "basis": self.basis.get(k[1], "")} for k, v in self.agg.items()]

    def object_rows(self):
        by = {}
        for k, v in self.objs.items():
            by.setdefault(k[:3], []).append((k[3], v))
        out = []
        for k, lst in by.items():
            lst.sort(key=lambda x: (-x[1][1], -x[1][0]))
            for obj, v in lst[: self.top_objects]:
                out.append({"process": k[0], "command": k[1], "category": k[2], "object": obj, "count": v[0], "total_us": round(v[1], 1),
                            "max_us": round(v[2], 1)})
        return out

    def bucket_rows(self):
        return [{"process": k[0], "command": k[1], "category": k[2], "lo_us": k[3], "hi_us": k[4], "count": c} for k, c in self.buckets.items()]


ALL_FIELDS = ["process", "command", "category", "count", "timed", "total_us", "max_us", "basis"]
OBJ_FIELDS_CSV = ["process", "command", "category", "object", "count", "total_us", "max_us"]
BUCKET_FIELDS = ["process", "command", "category", "lo_us", "hi_us", "count"]
