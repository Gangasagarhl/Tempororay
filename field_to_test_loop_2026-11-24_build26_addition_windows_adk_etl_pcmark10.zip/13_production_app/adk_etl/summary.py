"""A comparison in words.

    out = summarise(res, llm=None)    {"by": "model <name>" | "the program", "text", "findings": [...], "unchecked": [...]}

The written summary (by the program) is always made: it states the verdict, the gap to the benchmark, the phase and the
processes / commands that grew most, with the numbers of the comparison. When a model is connected (the application's
model settings), it is given ONLY the comparison's numbers and asked for a summary and likely causes; every number in its
answer must be one of the numbers it was given (within 1 %), otherwise that sentence is dropped and listed as unchecked.
"""
import json
import re

CAT_WORDS = {"pre_logon": "pre-logon", "logon": "logon screen", "post_logon": "post-logon", "all": "whole trace"}
SCHEMA = {"type": "object", "properties": {
    "summary": {"type": "string"},
    "findings": {"type": "array", "items": {"type": "object", "properties": {
        "title": {"type": "string"}, "detail": {"type": "string"}, "category": {"type": "string"}}}},
    "likely_causes": {"type": "array", "items": {"type": "string"}}}, "required": ["summary"]}


def _ms(us):
    return round((us or 0) / 1000.0, 1)


def _n(x):
    """A number for a sentence: '-' for nothing, whole numbers without '.0', else one decimal."""
    if x is None:
        return "-"
    if isinstance(x, float) and x.is_integer():
        return "{:,}".format(int(x))
    if isinstance(x, int):
        return "{:,}".format(x)
    return "{:,.1f}".format(x)


def facts(res, top=8):
    """The comparison reduced to what a reader (or the model) needs; every number in it is in the comparison."""
    f = {"run": res.get("run", {}).get("label"), "verdict": res.get("run", {}).get("verdict"), "limit_ms": res.get("limit_ms"),
         "fast_startup_mean_ms": res.get("run", {}).get("boot_mean_ms"), "benchmark_runs": res.get("benchmark", {}).get("n_runs"),
         "benchmark_fast_startup_mean_ms": _round(res.get("benchmark", {}).get("boot_mean_ms")), "boot": res.get("boot"),
         "categories": res.get("categories"),
         "phases_that_grew": [p for p in res.get("phases", []) if (p.get("delta_ms") or 0) > 0][:top]}
    tops = {}
    for cat, procs in (res.get("by_category") or {}).items():
        lst = []
        for p in procs[:top]:
            if p["delta_disk_us"] + p["delta_file_us"] <= 0:
                continue
            lst.append({"process": p["process"], "new_process": p["new"], "disk_io_ms_run": _ms(p["run_disk_us"]),
                        "disk_io_ms_benchmark": _ms(p["bench_disk_us"]), "disk_io_ms_delta": _ms(p["delta_disk_us"]),
                        "commands": [{"command": c["command"], "ms_run": _ms(c["run_us"]), "ms_benchmark": _ms(c["bench_us"]),
                                      "ms_delta": _ms(c["delta_us"]), "count_run": c["run_count"], "count_benchmark": c["bench_count"],
                                      "mean_us_run": c["run_mean_us"], "mean_us_benchmark": c["bench_mean_us"],
                                      "top_file": (c["files"][0]["file"] if c["files"] else None)}
                                     for c in p["commands"][:4] if c["delta_us"] > 0]})
        tops[cat] = lst
    f["processes_that_grew"] = tops
    f["new_processes"] = [p["process"] for p in res.get("new_processes", [])[:15]]
    f["every_command_that_grew"] = [{"category": cat, "process": p["process"], "command": c["command"], "ms_run": _ms(c["run_us"]),
                                     "ms_benchmark": _ms(c["bench_us"]), "ms_delta": _ms(c["delta_us"]), "count_run": c["run_count"],
                                     "count_benchmark": c["bench_count"], "what_the_time_is": c["basis"],
                                     "recorded_in_benchmark_traces": c.get("recorded_in_bench", True)}
                                    for cat in ("pre_logon", "logon", "post_logon") for p in (res.get("all_commands") or {}).get(cat, [])[:6]
                                    for c in p["commands"][:3] if c["delta_us"] and c["delta_us"] > 0 and not c.get("lifetime")]
    f["io_latency_us_all_processes"] = [{"command": x["command"], "run": x["run"], "benchmark": x["bench"],
                                         "share_above_10ms_pct": x.get("above_10ms_pct")}
                                        for x in (res.get("latency") or {}).get("all", []) if x["run"].get("count")]
    f["events_that_grew"] = [e for e in res.get("events", []) if e["delta"] > 0][:top]
    return f


def _round(x):
    return round(x, 1) if isinstance(x, (int, float)) else x


def written(res):
    """The summary written by the program from the comparison."""
    if res.get("error"):
        return res["error"]
    r, b = res.get("run", {}), res.get("benchmark", {})
    lines = []
    lim = res.get("limit_ms")
    lines.append("%s: %s. Mean Fast Startup time %s ms over %s iteration(s) (limit %s ms)." % (
        r.get("label"), r.get("verdict"), _n(r.get("boot_mean_ms")), r.get("iterations"), _n(lim)))
    bo = res.get("boot")
    if bo:
        lines.append("The benchmark (%d PASS run(s), %s) averages %s ms: this run is %s%s ms (%s%%) from it." % (
            b.get("n_runs", 0), b.get("scope"), _n(bo["bench_ms"]), "+" if bo["delta_ms"] >= 0 else "", _n(bo["delta_ms"]), _n(bo["delta_pct"])))
    for c in res.get("categories", []):
        if abs(c["delta_ms"]) >= 1 or abs(c["delta_disk_io_ms"]) >= 1:
            lines.append("%s: %s ms vs %s ms in the benchmark (%s%s ms); disk I/O time %s ms vs %s ms (%s%s ms)." % (
                CAT_WORDS.get(c["category"], c["category"]).capitalize(), _n(c["run_ms"]), _n(c["bench_ms"]), "+" if c["delta_ms"] >= 0 else "",
                _n(c["delta_ms"]), _n(c["run_disk_io_ms"]), _n(c["bench_disk_io_ms"]), "+" if c["delta_disk_io_ms"] >= 0 else "", _n(c["delta_disk_io_ms"])))
    grew = [p for p in res.get("phases", []) if (p.get("delta_ms") or 0) > 0]
    if grew:
        g = max(grew, key=lambda p: p["delta_ms"])
        lines.append("The phase that grew most: %s (%s), %s ms vs %s ms (+%s ms)." % (
            g["phase"], CAT_WORDS.get(g["category"], g["category"]), _n(g["run_ms"] or 0), _n(g["bench_ms"]), _n(g["delta_ms"])))
        cpu = [e for e in res.get("events", []) if e["event"] == "SampledProfile" and e["category"] == g["category"] and e["delta"] > 0][:3]
        if cpu:
            lines.append("CPU in that category (sampled CPU, about one sample per millisecond): %s." % "; ".join(
                "%s %s samples vs %s" % (e["process"], _n(e["run"]), _n(e["bench"])) for e in cpu))
    for cat in ("pre_logon", "logon", "post_logon"):
        procs = [p for p in (res.get("by_category") or {}).get(cat, []) if p["delta_disk_us"] > 0][:3]
        for p in procs:
            cm = next((c for c in p["commands"] if c["delta_us"] > 0), None)
            s = "%s, %s: disk I/O %s ms vs %s ms (+%s ms)%s." % (
                CAT_WORDS[cat].capitalize(), p["process"], _n(_ms(p["run_disk_us"])), _n(_ms(p["bench_disk_us"])), _n(_ms(p["delta_disk_us"])),
                " - a process not seen in the PASS runs" if p["new"] else "")
            if cm:
                s += " Most of it: %s, %s ms vs %s ms, %s commands vs %s, mean %s µs vs %s µs%s." % (
                    cm["command"], _n(_ms(cm["run_us"])), _n(_ms(cm["bench_us"])), _n(cm["run_count"]), _n(cm["bench_count"]), _n(cm["run_mean_us"]),
                    _n(cm["bench_mean_us"]), (", mostly on %s" % cm["files"][0]["file"]) if cm["files"] and cm["files"][0]["delta_us"] > 0 else "")
            lines.append(s)
    for cat, take in (("pre_logon", 4), ("logon", 3), ("post_logon", 2)):
        allc = []
        for p in (res.get("all_commands") or {}).get(cat, []):
            for c in p["commands"]:
                if c["delta_us"] is not None and c["delta_us"] > 0 and not c.get("lifetime"):
                    allc.append((c["delta_us"], p["process"], c))
        allc.sort(key=lambda x: -x[0])
        if allc:
            lines.append("%s, every command under every process - the ones that added most time: %s." % (CAT_WORDS[cat].capitalize(), "; ".join(
                "%s: %s %s ms vs %s ms (+%s ms, %s times vs %s)%s" % (
                    proc, c["command"], _n(_ms(c["run_us"])), _n(_ms(c["bench_us"])), _n(_ms(c["delta_us"])), _n(c["run_count"]), _n(c["bench_count"]),
                    "" if c.get("recorded_in_bench", True) else " - not recorded at all in the PASS traces, so not a measured difference")
                for _d, proc, c in allc[:take])))
    if res.get("all_commands_note"):
        lines.append(res["all_commands_note"])
    hs = res.get("histogram_settings") or {}
    for x in (res.get("latency") or {}).get("all", []):
        r, b = x["run"], x["bench"]
        if not r.get("count"):
            continue
        g = x["buckets_that_grew"][0] if x.get("buckets_that_grew") else None
        lines.append("Latency of %s (%s, %s µs buckets): %s commands per boot vs %s; p50 %s µs vs %s, p90 %s vs %s, p99 %s vs %s; "
                     "above 10 ms %s%% vs %s%%%s." % (
                         x["command"], x["source"], hs.get("width", 5), _n(r["count"]), _n(b.get("count")), _n(r["p50_us"]), _n(b.get("p50_us")),
                         _n(r["p90_us"]), _n(b.get("p90_us")), _n(r["p99_us"]), _n(b.get("p99_us")),
                         _n((x.get("above_10ms_pct") or {}).get("run")), _n((x.get("above_10ms_pct") or {}).get("bench")),
                         ("; the bucket that grew most: %s-%s µs, %s commands vs %s" % (_n(g["lo_us"]), _n(g["hi_us"]), _n(g["run"]), _n(g["bench"])))
                         if g else ""))
    if res.get("new_processes"):
        lines.append("Processes not seen in the PASS runs: %s." % ", ".join(p["process"] for p in res["new_processes"][:10]))
    if res.get("note"):
        lines.append(res["note"])
    return "\n".join(lines)


_NUM = re.compile(r"(?<![\w.])[-+]?\d[\d,]*(?:\.\d+)?")


def _numbers(obj, out):
    if isinstance(obj, dict):
        for v in obj.values():
            _numbers(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _numbers(v, out)
    elif isinstance(obj, bool):
        return
    elif isinstance(obj, (int, float)):
        out.add(float(obj))
        out.add(round(float(obj) / 1000.0, 1))          # µs <-> ms, ms <-> s
        out.add(round(float(obj) * 1000.0, 1))
    return out


def grounded(sentence, known):
    for m in _NUM.findall(sentence):
        try:
            v = float(m.replace(",", ""))
        except ValueError:
            continue
        if abs(v) < 10:                                 # small counts / ordinals are not checked
            continue
        if not any(abs(v - k) <= max(0.011 * abs(k), 0.15) for k in known):
            return False
    return True


def summarise(res, llm=None):
    out = {"by": "the program", "text": written(res), "findings": [], "likely_causes": [], "unchecked": []}
    if res.get("error") or llm is None or str(getattr(llm, "name", "")).startswith("stand"):
        return out
    fx = facts(res)
    prompt = ("You are a Windows boot-performance engineer. A Windows ADK Fast Startup run is compared with a benchmark made of "
              "the PASS runs (mean Fast Startup time <= %s ms). Below are the measured differences, in JSON (ms = milliseconds, "
              "us = microseconds; 'delta' = this run minus the benchmark; categories: pre_logon = boot to the logon screen, logon = "
              "the logon screen, post_logon = the user's session).\n\nDATA:\n%s\n\nWrite: 'summary' (at most 180 words: verdict, "
              "where the extra time is - which category, which phase, which processes and inside them which commands), "
              "'findings' (up to 6: title, detail, category) and 'likely_causes' (up to 4 short hypotheses). Use ONLY numbers that "
              "are in DATA, copied exactly; name only processes, commands and files that are in DATA. Answer as JSON."
              % (res.get("limit_ms"), json.dumps(fx, ensure_ascii=False)))
    try:
        ans, _cached = llm.generate_json(prompt, SCHEMA, max_tokens=1500)
    except Exception as exc:                            # noqa: BLE001 - the written summary stands
        out["model_error"] = str(exc)[:300]
        return out
    if not isinstance(ans, dict) or "_error" in ans or not ans.get("summary"):
        out["model_error"] = str((ans or {}).get("_error") if isinstance(ans, dict) else "no answer")[:300]
        return out
    known = _numbers(fx, set())
    keep, drop = [], []
    for sent in re.split(r"(?<=[.!?])\s+", ans["summary"].strip()):
        (keep if grounded(sent, known) else drop).append(sent)
    findings = []
    for f in ans.get("findings") or []:
        if not isinstance(f, dict):
            continue
        txt = "%s %s" % (f.get("title", ""), f.get("detail", ""))
        (findings if grounded(txt, known) else drop).append(f if grounded(txt, known) else txt)
    causes = [c for c in ans.get("likely_causes") or [] if isinstance(c, str) and grounded(c, known)]
    out.update({"by": "model %s (every number checked against the comparison)" % getattr(llm, "name", "?"),
                "model_text": " ".join(keep), "findings": findings, "likely_causes": causes, "unchecked": drop})
    return out
