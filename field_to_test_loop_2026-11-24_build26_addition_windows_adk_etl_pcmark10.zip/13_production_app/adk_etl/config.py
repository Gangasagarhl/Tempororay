"""Settings of the Windows ADK ETL analytics: config/app_config.json "adk_etl" overrides DEFAULTS key by key."""
import os
import shutil

DEFAULTS = {
    # PASS when the mean Fast Startup time of a run's iterations is at most this (owner, 2026-11-24: 14 seconds)
    "limit_ms": 14000,
    # which XML metric is the Fast Startup time (first match wins): exact names (case, '-', '_' and spaces ignored), then
    # a name holding all words of one keyword group, then the fallbacks in order
    "boot_metric_candidates": ["FastStartup-Resume-Overall-Time", "FastStartup-Resume-OverallTime",
                               "FastStartup-ResumeOverallTime", "FastStartup-OverallTime", "BootTime", "Boot to desktop"],
    "boot_metric_keywords": [["resume", "overall"], ["fast", "startup", "overall"], ["boot", "total"]],
    "boot_metric_fallbacks": ["FastStartup-Resume-PoweredOnToKernelResumeComplete", "FastStartup-BootToLogonUI"],
    # xperf.exe: empty = PATH, then the Windows Performance Toolkit folders below
    "xperf": "",
    "timeout_s": 1800,                 # one xperf action on one trace
    "census": True,                    # count every event type of every trace per process (xperf -a dumper)
    "census_max_lines": 40_000_000,    # a census stops (and says so) after this many lines of one trace
    "file_io": True,                   # file I/O operations with their duration, when the trace recorded them
    "flushes": True,                   # disk flushes from the events (xperf -a diskio -detail does not list them)
    "all_commands": True,              # every command under every process (adk_etl.commands): times, counts, objects
    "top_objects": 15,                 # objects (files, DLLs, drivers, services, modules ...) kept per process and command
    "profile_interval_us": 1000,       # one CPU sample stands for this much CPU time (the default sampling rate is 1 kHz)
    "top_files": 40,                   # files kept per (process, command) in the database; every command stays in the CSV
    "max_depth": 10,                   # how deep a folder is searched
    # I/O latency histograms (adk_etl.histogram): buckets of hist_bucket_us up to hist_fine_max_us, doubling buckets above
    # (0 = hist_bucket_us everywhere); hist_measure: io_time_us (issue to completion) or service_us (the device's own time)
    "hist_bucket_us": 5,
    "hist_fine_max_us": 10000,
    "hist_measure": "io_time_us",
}

XPERF_PLACES = [
    r"C:\Program Files (x86)\Windows Kits\10\Windows Performance Toolkit\xperf.exe",
    r"C:\Program Files\Windows Kits\10\Windows Performance Toolkit\xperf.exe",
    r"C:\Program Files (x86)\Windows Kits\11\Windows Performance Toolkit\xperf.exe",
]


def settings(cfg=None):
    out = dict(DEFAULTS)
    mine = (cfg or {}).get("adk_etl") if isinstance(cfg, dict) else None
    if isinstance(mine, dict):
        out.update({k: v for k, v in mine.items() if not str(k).startswith("_")})
    return out


def find_xperf(cfg=None):
    """Path of xperf.exe, or None when the Windows Performance Toolkit is not installed."""
    s = settings(cfg)
    if s.get("xperf") and os.path.isfile(s["xperf"]):
        return s["xperf"]
    w = shutil.which("xperf") or shutil.which("xperf.exe")
    if w:
        return w
    for p in XPERF_PLACES:
        if os.path.isfile(p):
            return p
    return None
