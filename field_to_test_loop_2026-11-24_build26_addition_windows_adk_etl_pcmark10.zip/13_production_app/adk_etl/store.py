"""The back end of the Windows ADK ETL analytics: every run analysed is kept (PASS and FAIL), with each iteration's phases,
processes, per-command times and event census, so that the PASS runs can be pooled into a benchmark and any run compared
with it later. One SQLite file: <application root>/db/adk_etl.sqlite.

Tables (run = one ADK run folder, n = iteration):
    run          one row per analysed run: verdict, mean Fast Startup time, limit, whether it is in the benchmark
    iteration    per iteration: its XML / trace, Fast Startup time and where it came from, the decoded CSV folder
    phase        per iteration: phase, category (pre_logon / logon / post_logon), duration
    process      per iteration and process: instances, first start, lifetime, phase and category of the start
    command      per iteration, process, command and category: count, total / service / max / p95 time (µs), bytes
                 source: disk (DiskRead / DiskWrite / DiskFlush) or file (FileIoRead / FileIoWrite / ...)
    command_file per iteration, process, command, category and file: count, total, max (the top files of each command)
    census       per iteration, process, event type and category: how many events (every event type of the trace)
    xml_item     per iteration: every number of the assessment's XML (kind, name, measure, value)
    command_all  per iteration, process, command (every kind of event a process caused, adk_etl.commands) and category: count,
                 how many had a time, total / max µs, and what the time is (basis)
    command_all_object  the top objects of each (files, DLLs, drivers, services, modules, child command lines, wait reasons)
    histogram    per iteration, source, process, command, category and latency bucket [lo_us, hi_us): how many commands
                 (5 µs buckets; adk_etl.histogram) - hist_meta: the bucket settings they were built with
    job          the background analyses (state, note, percentage)
    comparison   every comparison made (its result as JSON)
"""
import json
import os
import sqlite3
import threading
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS run (id INTEGER PRIMARY KEY AUTOINCREMENT, project INTEGER, run_key TEXT, label TEXT, folder TEXT,
  run_dir TEXT, status TEXT, verdict TEXT, boot_mean_ms REAL, limit_ms REAL, boot_source TEXT, iterations INTEGER, traced INTEGER,
  in_benchmark INTEGER DEFAULT 1, created REAL, updated REAL, notes TEXT, error TEXT, info TEXT);
CREATE TABLE IF NOT EXISTS iteration (run INTEGER, n INTEGER, xml TEXT, etl TEXT, etl_bytes INTEGER, boot_ms REAL, boot_source TEXT,
  xml_boot_ms REAL, etl_boot_ms REAL, cache_dir TEXT, counts TEXT, notes TEXT, timeline TEXT);
CREATE TABLE IF NOT EXISTS phase (run INTEGER, n INTEGER, phase TEXT, category TEXT, start_ms REAL, duration_ms REAL);
CREATE TABLE IF NOT EXISTS process (run INTEGER, n INTEGER, process TEXT, instances INTEGER, first_start_ms REAL, lifetime_ms REAL,
  phase TEXT, category TEXT);
CREATE TABLE IF NOT EXISTS command (run INTEGER, n INTEGER, source TEXT, process TEXT, command TEXT, category TEXT, count INTEGER,
  total_us REAL, service_us REAL, max_us REAL, p95_us REAL, bytes REAL);
CREATE TABLE IF NOT EXISTS command_file (run INTEGER, n INTEGER, process TEXT, command TEXT, category TEXT, file TEXT, count INTEGER,
  total_us REAL, max_us REAL);
CREATE TABLE IF NOT EXISTS census (run INTEGER, n INTEGER, process TEXT, event TEXT, category TEXT, count INTEGER);
CREATE TABLE IF NOT EXISTS xml_item (run INTEGER, n INTEGER, kind TEXT, name TEXT, measure TEXT, value REAL);
CREATE TABLE IF NOT EXISTS job (id TEXT PRIMARY KEY, project INTEGER, folder TEXT, state TEXT, note TEXT, pct REAL, created REAL,
  updated REAL, result TEXT, error TEXT);
CREATE TABLE IF NOT EXISTS comparison (id INTEGER PRIMARY KEY AUTOINCREMENT, run INTEGER, scope TEXT, created REAL, result TEXT);
CREATE TABLE IF NOT EXISTS histogram (run INTEGER, n INTEGER, source TEXT, process TEXT, command TEXT, category TEXT, lo_us INTEGER,
  hi_us INTEGER, count INTEGER);
CREATE TABLE IF NOT EXISTS hist_meta (run INTEGER, meta TEXT);
CREATE TABLE IF NOT EXISTS command_all (run INTEGER, n INTEGER, process TEXT, command TEXT, category TEXT, count INTEGER, timed INTEGER,
  total_us REAL, max_us REAL, basis TEXT);
CREATE TABLE IF NOT EXISTS command_all_object (run INTEGER, n INTEGER, process TEXT, command TEXT, category TEXT, object TEXT,
  count INTEGER, total_us REAL, max_us REAL);
CREATE INDEX IF NOT EXISTS ix_cmdall_run ON command_all(run, process);
CREATE INDEX IF NOT EXISTS ix_cmdallo_run ON command_all_object(run, process, command);
CREATE INDEX IF NOT EXISTS ix_hist_run ON histogram(run, category, command);
CREATE INDEX IF NOT EXISTS ix_run_project ON run(project);
CREATE INDEX IF NOT EXISTS ix_it_run ON iteration(run);
CREATE INDEX IF NOT EXISTS ix_phase_run ON phase(run);
CREATE INDEX IF NOT EXISTS ix_proc_run ON process(run);
CREATE INDEX IF NOT EXISTS ix_cmd_run ON command(run);
CREATE INDEX IF NOT EXISTS ix_cmdf_run ON command_file(run);
CREATE INDEX IF NOT EXISTS ix_census_run ON census(run);
CREATE INDEX IF NOT EXISTS ix_xml_run ON xml_item(run);
CREATE INDEX IF NOT EXISTS ix_cmp_run ON comparison(run);
"""
CHILD_TABLES = ("iteration", "phase", "process", "command", "command_file", "census", "xml_item", "comparison", "histogram", "hist_meta",
                "command_all", "command_all_object")


class Store:
    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.lock = threading.RLock()
        with self._conn() as c:
            c.executescript(SCHEMA)

    def _conn(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        return c

    def all(self, sql, args=()):
        with self.lock, self._conn() as c:
            return [dict(r) for r in c.execute(sql, args).fetchall()]

    def one(self, sql, args=()):
        rows = self.all(sql, args)
        return rows[0] if rows else None

    def exec(self, sql, args=()):
        with self.lock, self._conn() as c:
            cur = c.execute(sql, args)
            return cur.lastrowid

    def many(self, sql, rows):
        rows = list(rows)
        if not rows:
            return
        with self.lock, self._conn() as c:
            c.executemany(sql, rows)

    # ---------------------------------------------------------------- runs
    def new_run(self, project, run_key, label, folder, run_dir, limit_ms):
        """A run analysed again (same analysis, same run folder) replaces the earlier result."""
        with self.lock:
            old = self.all("SELECT id, in_benchmark FROM run WHERE project IS ? AND run_key=?", (project, run_key))
            keep = old[0]["in_benchmark"] if old else 1
            for o in old:
                self.delete_run(o["id"])
            t = time.time()
            return self.exec("INSERT INTO run (project, run_key, label, folder, run_dir, status, limit_ms, in_benchmark, created, updated) "
                             "VALUES (?,?,?,?,?,?,?,?,?,?)", (project, run_key, label, folder, run_dir, "analysing", limit_ms, keep, t, t))

    def finish_run(self, rid, **kw):
        kw["updated"] = time.time()
        for k in ("notes", "info"):
            if k in kw and not isinstance(kw[k], str):
                kw[k] = json.dumps(kw[k])
        cols = ", ".join("%s=?" % k for k in kw)
        self.exec("UPDATE run SET %s WHERE id=?" % cols, tuple(kw.values()) + (rid,))

    def delete_run(self, rid):
        with self.lock, self._conn() as c:
            for t in CHILD_TABLES:
                c.execute("DELETE FROM %s WHERE run=?" % t, (rid,))
            c.execute("DELETE FROM run WHERE id=?", (rid,))

    def runs(self, project=None):
        sql = "SELECT * FROM run" + (" WHERE project=?" if project is not None else "") + " ORDER BY id DESC"
        out = self.all(sql, (project,) if project is not None else ())
        for r in out:
            r["notes"] = jload(r.get("notes"), [])
            r["info"] = jload(r.get("info"), {})
        return out

    def run(self, rid):
        r = self.one("SELECT * FROM run WHERE id=?", (rid,))
        if r:
            r["notes"] = jload(r.get("notes"), [])
            r["info"] = jload(r.get("info"), {})
        return r

    # ---------------------------------------------------------------- jobs
    def job_set(self, jid, **kw):
        kw["updated"] = time.time()
        if "result" in kw and not isinstance(kw["result"], str):
            kw["result"] = json.dumps(kw["result"])
        with self.lock:
            if not self.one("SELECT id FROM job WHERE id=?", (jid,)):
                self.exec("INSERT INTO job (id, created, updated, state) VALUES (?,?,?,?)", (jid, time.time(), time.time(), "queued"))
            cols = ", ".join("%s=?" % k for k in kw)
            self.exec("UPDATE job SET %s WHERE id=?" % cols, tuple(kw.values()) + (jid,))

    def job(self, jid):
        j = self.one("SELECT * FROM job WHERE id=?", (jid,))
        if j:
            j["result"] = jload(j.get("result"), None)
        return j


def jload(s, default):
    if s is None or s == "":
        return default
    try:
        return json.loads(s)
    except (TypeError, ValueError):
        return default
