"""One ETL trace -> CSV tables, with xperf (Windows Performance Toolkit). Nothing here needs a CSV as input.

    res = decode(etl_path, cache_root, cfg, progress=None)
    res = {"dir": cache folder, "files": {"processes", "disk_commands", "file_commands", "census", "phases"}: csv paths,
           "timeline": phases.Timeline(...).as_dict(), "counts": {...}, "notes": [...], "cached": bool}

xperf actions (all times are µs from the trace start: -tle -tti):
    -a process -withcmdline    every process: start, end, parent, command line            -> processes.csv, phases
    -a diskio -detail          every disk command (DiskRead / DiskWrite / DiskFlush) with the process that issued it,
                               start, end, IO time (queue + device), disk service time, size, offset, priority, file
                                                                                           -> disk_commands.csv
    -a dumper                  every event of the trace, streamed (never written whole to disk):
                                 - census: how many events of each type each process logged, per phase -> census.csv
                                 - file I/O operations (FileIoCreate / Read / Write / ... completed by FileIoOpEnd, whose
                                   ElapsedTime is the operation's duration) when the trace recorded them  -> file_commands.csv
                                 - disk flushes (DiskFlush: ElapsedTime, DiskSvcTime; the issuing process from DiskFlushInit
                                   when recorded), which -a diskio -detail leaves out                    -> disk_commands.csv
A decoded trace is kept under cache_root/<hash of path, size, time, decoder version>/ and never decoded twice.
xperf is called with its output redirected to a file (its -o option fails when started from PowerShell on some machines).
"""
import csv
import hashlib
import json
import os
import re
import subprocess
import time

from . import commands, config
from .phases import Timeline

DECODER_VERSION = "adk-etl-7"
_PROC = re.compile(r"^(.*?)\s*\(\s*(\d+)\s*\)\s*$")
_K_GROUP = re.compile(r"\s-k\s+(\S+)", re.I)
CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0


class XperfMissing(RuntimeError):
    pass


def split_proc(text):
    """'svchost.exe ( 432)' -> ('svchost.exe', 432); 'Unknown' -> ('Unknown', None)."""
    m = _PROC.match((text or "").strip())
    if not m:
        return (text or "").strip() or "Unknown", None
    return m.group(1).strip() or "Unknown", int(m.group(2))


def _num(s):
    s = (s or "").strip()
    if not s or s in ("MIN", "MAX"):
        return None
    try:
        return int(s, 16) if s.lower().startswith("0x") else int(float(s))
    except ValueError:
        return None


def cache_key(etl):
    """From the trace's CONTENT (size + its first and last 4 MB), not its path: a copy of a trace under another name or in
    another folder is decoded once."""
    size = os.path.getsize(etl)
    h = hashlib.sha1(("%d|%s|" % (size, DECODER_VERSION)).encode("utf-8"))
    block = 4 * 1024 * 1024
    with open(etl, "rb") as fh:
        h.update(fh.read(block))
        if size > 2 * block:
            fh.seek(size - block)
            h.update(fh.read(block))
    return h.hexdigest()[:20]


def _run(xperf, etl, args, out_path, timeout):
    cmd = [xperf, "-i", etl, "-tle", "-tti", "-quiet"] + args
    with open(out_path, "w", encoding="utf-8", errors="replace", newline="") as fh:
        p = subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT, timeout=timeout, creationflags=CREATE_NO_WINDOW)
    return p.returncode


# --------------------------------------------------------------------------------------------- processes
class ProcessIndex:
    """pid -> the process instance alive at a timestamp (a pid may be used again during a boot)."""

    def __init__(self, procs):
        self.by_pid = {}
        for p in procs:
            if p["pid"] is not None:
                self.by_pid.setdefault(p["pid"], []).append(p)
        for v in self.by_pid.values():
            v.sort(key=lambda p: (p["start_us"] if p["start_us"] is not None else -1))

    def key(self, name, pid, t):
        cands = self.by_pid.get(pid)
        if not cands:
            return name
        best = cands[0]
        for p in cands:
            st = p["start_us"] if p["start_us"] is not None else -1
            if t is None or st <= t:
                best = p
        return best["key"] if best["name"].lower() == (name or "").lower() or name in ("Unknown", "", None) else name


def process_key(name, cmdline):
    """The name a process is compared by: its image name; svchost.exe also by its service group (-k netsvcs)."""
    if (name or "").lower() == "svchost.exe":
        m = _K_GROUP.search(cmdline or "")
        if m:
            return "svchost.exe (%s)" % m.group(1).lower()
    return name


_VOL = re.compile(r"^(?:\\Device\\HarddiskVolume\d+|\\\\\?\\[A-Za-z]:|[A-Za-z]:)(?=\\)", re.I)
_USER = re.compile(r"^\\Users\\[^\\]+\\", re.I)


def norm_file(path):
    """A file as it is compared between traces (and computers): without its volume (C:, \\Device\\HarddiskVolume3) and with the
    user's folder name replaced, in lower case. 'Unknown (0x...)' -> 'unknown'."""
    p = (path or "").strip().strip('"')
    if not p or p.lower().startswith("unknown"):
        return "unknown"
    p = _VOL.sub("", p)
    p = _USER.sub(r"\\Users\\<user>\\", p)
    return p.lower()


def parse_processes(path):
    procs = []
    header = None
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if header is None:
                if line.lstrip().startswith("Start Time"):
                    header = [h.strip() for h in line.split(",")]
                continue
            parts = line.rstrip("\r\n").split(",", len(header) - 1)
            if len(parts) < len(header) - 1:
                continue
            row = dict(zip(header, [x.strip() for x in parts]))
            name, pid = split_proc(row.get("Process Name ( PID)", ""))
            if name in ("Idle",):
                continue
            cmdline = row.get("Command Line", "")
            procs.append({"name": name, "pid": pid, "parent": _num(row.get("ParentPID")), "start_us": _num(row.get("Start Time")),
                          "end_us": _num(row.get("End Time")), "cmdline": "" if cmdline == "<Unknown>" else cmdline,
                          "key": process_key(name, cmdline)})
    return procs


# --------------------------------------------------------------------------------------------- disk commands
def parse_diskio(path, pindex):
    """Yields one dict per disk command of `xperf -a diskio -detail`."""
    header = None
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if header is None:
                if line.lstrip().startswith("IO Type"):
                    header = [h.strip() for h in line.split(",")]
                    ix = {h: i for i, h in enumerate(header)}
                continue
            parts = line.rstrip("\r\n").split(",", len(header) - 1)
            if len(parts) < len(header):
                continue
            g = lambda h: parts[ix[h]].strip() if h in ix else ""          # noqa: E731
            start, end = _num(g("Start Time")), _num(g("End Time"))
            if start is None:
                continue
            name, pid = split_proc(g("Process Name ( PID)"))
            yield {"command": g("IO Type"), "process": pindex.key(name, pid, start), "pid": pid, "start_us": start, "end_us": end,
                   "io_time_us": _num(g("IO Time")), "service_us": _num(g("Disk SrvT")), "size_bytes": _num(g("IO Size")),
                   "offset": g("Byte Offset"), "priority": g("Pri"), "disk": g("Disk"), "file": g("Filename").strip('"')}


# --------------------------------------------------------------------------------------------- the whole trace, streamed
class Dumper:
    """Streams `xperf -a dumper` and keeps: the census of event types per (process, phase) and the file I/O operations."""

    def __init__(self, timeline, pindex, want_census, want_fileio, max_lines, cmds=None):
        self.tl, self.pi = timeline, pindex
        self.want_census, self.want_fileio, self.max_lines = want_census, want_fileio, max_lines
        self.cmds = cmds                                # commands.AllCommands: every command under every process, or None
        self._pc = {}
        self.fields = {}
        self.census = {}
        self.file_ops = []
        self.pending = {}
        self.flushes = []                               # DiskFlush commands (xperf -a diskio -detail does not list them)
        self.flush_init = {}                            # IrpPtr -> (issuing process, pid, timestamp) from DiskFlushInit
        self.flush_init_seen = False
        self.lines = 0
        self.truncated = False
        self.last_ts = 0

    def _event_name(self, name, parts, f):
        if name.startswith("UnknownEvent/Classic") and "EventGuid" in f:
            i, j = f.index("EventGuid"), f.index("Type")
            return "Unknown %s type %s" % (parts[i + 1].strip() if i + 1 < len(parts) else "?", parts[j + 1].strip() if j + 1 < len(parts) else "?")
        if name.startswith("UnknownEvent/Crimson") and "ProviderId" in f:
            i, j = f.index("ProviderId"), f.index("Id")
            return "Unknown %s id %s" % (parts[i + 1].strip() if i + 1 < len(parts) else "?", parts[j + 1].strip() if j + 1 < len(parts) else "?")
        return name

    def resolve(self, raw, ts):
        """'svchost.exe ( 432)' at a timestamp -> the process's key (commands.AllCommands uses it for context switches)."""
        got = self._pc.get(raw)
        if got is None:
            got = self._pc[raw] = split_proc(raw)
        return self.pi.key(got[0], got[1], ts) if got[1] is not None else got[0]

    def feed(self, stream):
        """Fast path: a line is split only up to its process column (its position per event type comes from the header);
        the whole line only for the events that need it (file I/O, unknown events, flushes, and the commands that carry a
        time or an object - commands.plan_of)."""
        in_header = False
        proc_pos = {}                                   # event name -> index of its process column in the split line, or None
        proc_cache = {}                                 # raw process text -> (name, pid)
        census = self.census
        starts = self.tl._starts
        segs = [(s["phase"], s["category"]) for s in self.tl.segments]
        cmds = self.cmds
        plans = {}
        import bisect
        for raw in stream:
            if in_header or raw.startswith(("BeginHeader", "EndHeader")):
                line = raw.rstrip("\r\n")
                if line == "BeginHeader":
                    in_header = True
                elif line == "EndHeader":
                    in_header = False
                    for nm, f in self.fields.items():
                        proc_pos[nm] = next((i + 1 for i, h in enumerate(f) if h.endswith("Process Name ( PID)")), None)
                    if cmds is not None:
                        cmds.set_header(self.fields)
                        plans = cmds.plans
                elif in_header and line:
                    parts = line.split(",")
                    self.fields[parts[0].strip()] = [x.strip() for x in parts[1:]]
                continue
            self.lines += 1
            if self.lines > self.max_lines:
                self.truncated = True
                break
            c1 = raw.find(",")
            if c1 < 0:
                continue
            name = raw[:c1].strip()
            if name not in proc_pos:
                continue
            pp = proc_pos[name]
            plan = plans.get(name)
            full = name.startswith(("FileIo", "UnknownEvent", "DiskFlush")) or (plan is not None and plan.full)
            parts = raw.rstrip("\r\n").split(",") if full else raw.split(",", (pp or 1) + 1)
            ts = _num(parts[1]) if len(parts) > 1 else None
            if ts is None:
                continue
            if ts > self.last_ts:
                self.last_ts = ts
            if pp is not None and pp < len(parts):
                rp = parts[pp]
                got = proc_cache.get(rp)
                if got is None:
                    got = proc_cache[rp] = split_proc(rp)
                pname, pid = got
            else:
                pname, pid = "(no process)", None
            proc = self.pi.key(pname, pid, ts) if pid is not None else pname
            i = bisect.bisect_right(starts, ts) - 1
            phase, cat = segs[i if i >= 0 else 0]
            if self.want_census:
                ev = self._event_name(name, parts, self.fields[name]) if name.startswith("UnknownEvent") else name
                k = (ev, proc, phase, cat)
                census[k] = census.get(k, 0) + 1
            if self.want_fileio and name.startswith("FileIo"):
                self._file_io(name, parts, self.fields[name], ts, proc, pid)
            elif name.startswith("DiskFlush"):
                self._flush(name, parts, self.fields[name], ts, proc, pid)
            if plan is not None:
                cmds.feed(name, plan, parts, ts, proc, pid, cat)

    def _flush(self, name, parts, f, ts, proc, pid):
        def get(h):
            i = f.index(h) + 1 if h in f else None
            return parts[i].strip() if i is not None and i < len(parts) else ""
        irp = get("IrpPtr")
        if name == "DiskFlushInit":
            self.flush_init_seen = True
            if irp:
                self.flush_init[irp] = (proc, pid, ts)
            return
        if name != "DiskFlush":
            return
        elapsed = _num(get("ElapsedTime"))
        init = self.flush_init.pop(irp, None) if irp else None
        if init:
            p, pd, t0 = init
        else:
            p, pd, t0 = proc, pid, ts - (elapsed or 0)
        phase, cat = self.tl.phase_at(t0)
        self.flushes.append({"command": "DiskFlush", "process": p, "pid": pd, "start_us": t0, "end_us": ts,
                             "io_time_us": elapsed if elapsed is not None else ts - t0, "service_us": _num(get("DiskSvcTime")),
                             "size_bytes": 0, "offset": "", "priority": get("I/O Pri"), "disk": get("DiskNum"), "file": "",
                             "phase": phase, "category": cat, "issuer": "DiskFlushInit" if init else "completion"})

    def _file_io(self, name, parts, f, ts, proc, pid):
        def get(h):
            if h not in f:
                return ""
            i = f.index(h) + 1
            if i >= len(parts):
                return ""
            if h == "FileName":                 # quoted, may hold commas, and is not always the last field
                tok = parts[i].strip()
                if tok.startswith('"'):
                    j = i
                    while not parts[j].rstrip().endswith('"') or (j == i and len(parts[j].strip()) == 1):
                        if j + 1 >= len(parts):
                            break
                        j += 1
                    tok = ",".join(parts[i:j + 1]).strip()
                return tok.strip('"')
            return parts[i].strip()
        irp = get("IrpPtr")
        if name != "FileIoOpEnd":
            if irp:
                self.pending[irp] = (name, ts, proc, pid, get("FileName"), _num(get("Size")))
            return
        start = self.pending.pop(irp, None)
        elapsed = _num(get("ElapsedTime"))
        if start is None:
            op, t0, p, pd, fn, size = ("FileIo" + (get("Type") or "Op").strip(), ts - (elapsed or 0), proc, pid, get("FileName"), None)
        else:
            op, t0, p, pd, fn, size = start
        phase, cat = self.tl.phase_at(t0)
        self.file_ops.append({"command": op, "process": p, "pid": pd, "start_us": t0, "end_us": ts,
                              "duration_us": elapsed if elapsed is not None else ts - t0, "size_bytes": size,
                              "status": get("Status"), "file": fn, "phase": phase, "category": cat})


def _write_csv(path, rows, fields):
    with open(path, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


PROC_FIELDS = ["key", "name", "pid", "parent", "start_us", "end_us", "lifetime_ms", "phase", "category", "cmdline"]
DISK_FIELDS = ["command", "process", "pid", "start_us", "end_us", "io_time_us", "service_us", "size_bytes", "offset", "priority",
               "disk", "file", "phase", "category"]
FILE_FIELDS = ["command", "process", "pid", "start_us", "end_us", "duration_us", "size_bytes", "status", "file", "phase", "category"]
CENSUS_FIELDS = ["event", "process", "phase", "category", "count"]
PHASE_FIELDS = ["phase", "category", "start_us", "end_us", "duration_ms"]


def decode(etl, cache_root, cfg=None, progress=None):
    """Decode one trace (or take it from the cache). Raises XperfMissing when xperf is not installed."""
    s = config.settings(cfg)
    say = progress or (lambda _t: None)
    out_dir = os.path.join(cache_root, cache_key(etl))
    meta_path = os.path.join(out_dir, "meta.json")
    if os.path.isfile(meta_path):
        with open(meta_path, encoding="utf-8") as fh:
            meta = json.load(fh)
        meta["cached"] = True
        return meta
    xperf = config.find_xperf(cfg)
    if not xperf:
        raise XperfMissing("xperf.exe (Windows Performance Toolkit, part of the Windows ADK) is not installed on this computer: "
                           "install the Windows Performance Toolkit or set adk_etl.xperf in the configuration")
    os.makedirs(out_dir, exist_ok=True)
    tmo = int(s.get("timeout_s") or 1800)
    notes = []
    t0 = time.time()
    say("processes of %s" % os.path.basename(etl))
    raw_proc = os.path.join(out_dir, "xperf_process.txt")
    rc = _run(xperf, etl, ["-a", "process", "-withcmdline"], raw_proc, tmo)
    procs = parse_processes(raw_proc)
    if not procs:
        with open(raw_proc, encoding="utf-8", errors="replace") as fh:
            why = fh.read(600).strip()
        raise RuntimeError("xperf could not read the processes of %s (exit %s): %s" % (etl, rc, why or "no output"))
    pindex = ProcessIndex(procs)
    end_guess = max([p["start_us"] or 0 for p in procs] + [p["end_us"] or 0 for p in procs])
    tl = Timeline(procs, end_guess)

    say("disk commands of %s" % os.path.basename(etl))
    raw_disk = os.path.join(out_dir, "xperf_diskio_detail.txt")
    _run(xperf, etl, ["-a", "diskio", "-detail"], raw_disk, tmo)
    disk = []
    for r in parse_diskio(raw_disk, pindex):
        r["phase"], r["category"] = tl.phase_at(r["start_us"])
        disk.append(r)
    if not disk:
        notes.append("no disk command in this trace (the DiskIo events were not recorded): per-command disk times are not available")
    try:
        os.remove(raw_disk)                                  # its content is in disk_commands.csv
    except OSError:
        pass

    dump = None
    cmds = None
    if s.get("census") or s.get("file_io") or s.get("flushes", True) or s.get("all_commands", True):
        say("every event of %s (all commands, census)" % os.path.basename(etl))
        dump = Dumper(tl, pindex, bool(s.get("census")), bool(s.get("file_io")), int(s.get("census_max_lines") or 40_000_000))
        if s.get("all_commands", True):
            cmds = commands.AllCommands(pindex, dump.resolve, tl.category_at, cfg, int(s.get("top_objects") or 15),
                                        int(s.get("profile_interval_us") or 1000))
            dump.cmds = cmds
        cmd = [xperf, "-i", etl, "-tle", "-tti", "-quiet", "-a", "dumper"]
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=CREATE_NO_WINDOW,
                             text=True, encoding="utf-8", errors="replace", bufsize=1 << 20)
        try:
            dump.feed(p.stdout)
        finally:
            if dump.truncated:
                p.kill()
            try:
                p.wait(timeout=tmo)
            except subprocess.TimeoutExpired:
                p.kill()
        if dump.truncated:
            notes.append("the event census and every-command extraction stopped after %d lines (adk_etl.census_max_lines; disk commands "
                         "are complete): their counts cover the trace up to %.1f s" % (dump.max_lines, dump.last_ts / 1e6))
        if s.get("file_io") and not dump.file_ops:
            notes.append("no file I/O operation in this trace (FileIo events were not recorded): only disk commands have durations")
        if dump.flushes and not any(r["command"] == "DiskFlush" for r in disk):
            disk.extend(dump.flushes)                    # xperf -a diskio -detail leaves flushes out; the events hold them
            disk.sort(key=lambda r: r["start_us"])
            if not dump.flush_init_seen:
                notes.append("%d disk flushes: the trace has no DiskFlushInit events, so a flush is counted under the process whose "
                             "context completed it (often System), not necessarily the one that asked for it" % len(dump.flushes))

    end_us = max([end_guess] + [r["end_us"] or 0 for r in disk[-2000:]] + [dump.last_ts if dump else 0])
    tl = Timeline(procs, end_us)
    for p in procs:
        p["phase"], p["category"] = tl.phase_at(p["start_us"])
        p["lifetime_ms"] = round((p["end_us"] - p["start_us"]) / 1000.0, 3) if p["start_us"] is not None and p["end_us"] is not None else None

    if cmds is not None:                                 # disk commands (issuing process) and file operations join every other command
        for r in disk:
            if r.get("io_time_us") is not None:
                cmds.add_timed(r["process"], r["command"], r["category"], float(r["io_time_us"]), norm_file(r.get("file")), "disk")
        for r in (dump.file_ops if dump else []):
            if r.get("duration_us") is not None:
                cmds.add_timed(r["process"], r["command"], r["category"], float(r["duration_us"]), norm_file(r.get("file")), "file")

    files = {k: os.path.join(out_dir, k + ".csv") for k in ("processes", "disk_commands", "file_commands", "census", "phases",
                                                            "commands_all", "command_objects", "event_buckets")}
    _write_csv(files["processes"], procs, PROC_FIELDS)
    _write_csv(files["disk_commands"], disk, DISK_FIELDS)
    _write_csv(files["file_commands"], dump.file_ops if dump else [], FILE_FIELDS)
    _write_csv(files["census"], ({"event": k[0], "process": k[1], "phase": k[2], "category": k[3], "count": v}
                                 for k, v in sorted((dump.census if dump else {}).items(), key=lambda kv: -kv[1])), CENSUS_FIELDS)
    _write_csv(files["phases"], tl.segments, PHASE_FIELDS)
    _write_csv(files["commands_all"], sorted(cmds.rows() if cmds else [], key=lambda r: (r["process"], -r["total_us"], -r["count"])), commands.ALL_FIELDS)
    _write_csv(files["command_objects"], cmds.object_rows() if cmds else [], commands.OBJ_FIELDS_CSV)
    _write_csv(files["event_buckets"], cmds.bucket_rows() if cmds else [], commands.BUCKET_FIELDS)
    meta = {"etl": etl, "dir": out_dir, "files": files, "timeline": tl.as_dict(), "decoder": DECODER_VERSION,
            "counts": {"processes": len(procs), "disk_commands": len(disk), "file_commands": len(dump.file_ops) if dump else 0,
                       "census_lines": dump.lines if dump else 0, "event_types": len({k[0] for k in dump.census}) if dump else 0,
                       "command_types": len({k[1] for k in cmds.agg}) if cmds else 0,
                       "process_commands": len(cmds.agg) if cmds else 0},
            "notes": notes, "seconds": round(time.time() - t0, 2), "xperf": xperf, "cached": False}
    with open(meta_path, "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=1)
    return meta


def read_csv(path):
    if not path or not os.path.isfile(path):
        return []
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))
