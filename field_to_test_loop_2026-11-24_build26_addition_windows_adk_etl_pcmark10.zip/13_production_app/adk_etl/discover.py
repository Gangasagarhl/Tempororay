"""From ONE folder to the runs and iterations of Windows ADK assessments, by CONTENT, whatever the files are called.

    inv = discover(folder, cfg)       never raises for a bad input: read inv["errors"] / inv["problems"]

Rules
  1. Every file below the folder (cache folders skipped) is looked at:
       *.etl   a trace. Its role comes from words in its name when there are any (io, analysis, verbose, axelog), else it is
               the iteration's trace. AxeLog traces are the assessment engine's own log: listed, never analysed.
       *.xml   read and classified by what it holds (xmlread.sniff): timing (metrics / component timings), io (per-process
               disk), analysis (issues), machine, job, errors, other. The NAME of an XML never decides what it is.
       other   counted by ending (a CSV is not needed: the traces are decoded with xperf).
  2. Runs: a JobResults_* folder is one run. Files outside such folders belong to the folder that holds them, where the
     assessment's own sub-folders (results, 001_*, Verbose, ...) count as their parent. Several runs in one folder are
     normal (ten successful runs, one failing run, ...): each is analysed and stored by itself, never mixed.
  3. Iteration number: the XML's own Iteration / Number attribute; else the number at the end of the file name
     (FastStartup_Timing_7.xml, boot 7.etl, run(7).etl), else the first short number in it (fast_07_boot_9.1s.etl); else
     files are numbered in name order. XML and trace of the same number are one iteration.
  4. Duplicates: the XML under an 001_* folder and the trace under "results" first, then the shallower path; the others are
     listed as ignored, with the file that was used.
  5. A trace that is empty or cannot be opened is not used (said in problems). An iteration without an XML still counts:
     its Fast Startup time is then taken from the trace (start of LogonUI.exe).
"""
import hashlib
import os
import re
import time

from . import config, xmlread

SKIP_DIRS = {"__pycache__", ".git", ".venv", "_work", "_var", "_decode_cache", "adk_cache", "node_modules", "_etl_stage1_out"}
_JOB = re.compile(r"^JobResults_", re.I)
_ADK_SUB = re.compile(r"^(results|verbose|sysevtx|powerconfig|screenon|pa|inband_dumps|before|after|\d{3}_.+)$", re.I)
_SECOND_EXT = re.compile(r"\.(analysis|hiberdiag|events|boot|proc|timing)$", re.I)
_END_NUM = re.compile(r"(?:^|[_\-\s.(#])(\d{1,4})\)?$")
_ANY_NUM = re.compile(r"(?:^|[_\-\s(#])(\d{1,4})(?=[_\-\s.)]|$)")
ROLE_ORDER = {"trace": 0, "io": 1, "analysis": 2, "verbose": 3}


def number_in_name(name):
    stem = os.path.splitext(os.path.basename(name))[0]
    while True:
        s2 = _SECOND_EXT.sub("", stem)
        if s2 == stem:
            break
        stem = s2
    m = _END_NUM.search(stem)
    if m:
        return int(m.group(1))
    m = _ANY_NUM.search(stem)
    return int(m.group(1)) if m else None


def etl_role(path):
    n = os.path.basename(path).lower()
    parent = os.path.basename(os.path.dirname(path)).lower()
    if "axelog" in n:
        return "infrastructure"
    if re.search(r"(^|[_\-. ])io([_\-. ]|\d|$)", n):
        return "io"
    if "analysis" in n:
        return "analysis"
    if parent == "verbose" or "verbose" in n:
        return "verbose"
    return "trace"


def _walk(root, max_depth):
    root = os.path.abspath(root)
    base = root.rstrip("\\/").count(os.sep)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d.lower() not in SKIP_DIRS and not d.startswith("."))
        if dirpath.count(os.sep) - base >= max_depth:
            dirnames[:] = []
        yield dirpath, sorted(filenames, key=str.lower)


def _run_dir_of(path, root):
    """The run a file belongs to: the nearest JobResults_* folder above it (inside root), else its folder with the assessment's
    own sub-folders counted as their parent."""
    d = os.path.dirname(path)
    root = os.path.abspath(root)
    probe = d
    while True:
        if _JOB.match(os.path.basename(probe)):
            return probe
        if os.path.normcase(probe) == os.path.normcase(root) or len(probe) <= len(root):
            break
        probe = os.path.dirname(probe)
    while os.path.normcase(d) != os.path.normcase(root) and _ADK_SUB.match(os.path.basename(d)):
        d = os.path.dirname(d)
    return d


def _prefer(kind, paths, run_dir):
    def score(p):
        parts = [x.lower() for x in os.path.relpath(p, run_dir).replace("/", "\\").split("\\")[:-1]]
        expected = (kind == "xml" and any(x.startswith("001_") for x in parts)) or (kind == "etl" and "results" in parts)
        return (0 if expected else 1, len(parts), p.lower())
    return sorted(paths, key=score)


def run_id_of(run_dir):
    return hashlib.sha1(os.path.normcase(os.path.abspath(run_dir)).encode("utf-8")).hexdigest()[:12]


def is_etl(path):
    """Is this file an ETW trace? Its CONTENT says it: the first buffer's header (WMI_BUFFER_HEADER, 0x48 bytes: BufferSize a
    multiple of 1 KB) followed by the trace's system header, whose marker bytes at 0x4A..0x4B are 0x02 0xC0 (or 0x01 0xC0).
    A file merely named .etl is not taken as a trace."""
    try:
        with open(path, "rb") as fh:
            h = fh.read(0x50)
    except OSError:
        return False
    if len(h) < 0x4C:
        return False
    size = int.from_bytes(h[0:4], "little")
    return size > 0 and size % 1024 == 0 and h[0x4B] == 0xC0 and h[0x4A] in (0x01, 0x02)


def _etl_ok(path):
    try:
        size = os.path.getsize(path)
        with open(path, "rb") as fh:
            fh.read(64)
        return (size, None) if size > 0 else (0, "empty file")
    except OSError as exc:
        return None, str(exc)


def discover(folder, cfg=None):
    t0 = time.perf_counter()
    s = config.settings(cfg)
    folder = os.path.abspath(os.path.expandvars(os.path.expanduser(str(folder or "").strip().strip('"'))))
    inv = {"folder": folder, "runs": [], "other_files": {}, "csv_files": 0, "problems": [], "errors": [], "seconds": 0.0,
           "etl_files": 0, "xml_files": 0, "not_traces": []}
    if not os.path.isdir(folder):
        inv["errors"].append("folder not found: %s" % folder)
        return inv
    groups = {}                                         # run_dir -> {"etl": [(path, role, n)], "xml": [(path, role, n, info)]}
    for dirpath, files in _walk(folder, int(s.get("max_depth") or 10)):
        for f in files:
            full = os.path.join(dirpath, f)
            ext = os.path.splitext(f)[1].lower()
            if ext == ".etl":
                try:
                    empty = os.path.getsize(full) == 0
                except OSError:
                    empty = True
                if not empty and not is_etl(full):      # named .etl, but its content is no ETW trace
                    inv["not_traces"].append(full)
                    continue
                inv["etl_files"] += 1
                g = groups.setdefault(_run_dir_of(full, folder), {"etl": [], "xml": []})
                g["etl"].append((full, etl_role(full), number_in_name(f)))
            elif ext == ".xml":
                inv["xml_files"] += 1
                role, info = xmlread.sniff(full)
                g = groups.setdefault(_run_dir_of(full, folder), {"etl": [], "xml": []})
                n = info.get("iteration")
                if n is None:
                    n = number_in_name(f)
                g["xml"].append((full, role, n, info))
            else:
                if ext == ".csv":
                    inv["csv_files"] += 1
                inv["other_files"][ext or "(no ending)"] = inv["other_files"].get(ext or "(no ending)", 0) + 1
    for run_dir in sorted(groups, key=str.lower):
        run = _build_run(run_dir, groups[run_dir], folder, s)
        if run is not None:
            inv["runs"].append(run)
    labels = {}
    for r in inv["runs"]:
        labels.setdefault(r["label"].lower(), []).append(r)
    for same in labels.values():                        # the same JobResults name in several folders: the path says which
        if len(same) > 1:
            for r in same:
                r["label"] = os.path.relpath(r["run_dir"], folder)
    if inv["not_traces"]:
        inv["problems"].append("%d file(s) named .etl are not ETW traces (their first bytes are no trace header) and were left out: %s"
                               % (len(inv["not_traces"]), ", ".join(os.path.basename(p) for p in inv["not_traces"][:5])))
    if not inv["runs"]:
        inv["errors"].append("no Windows ADK run found under %s: no trace (.etl) and no assessment timing XML" % folder)
    inv["seconds"] = round(time.perf_counter() - t0, 3)
    return inv


def _build_run(run_dir, g, folder, s):
    traces = [(p, r, n) for p, r, n in g["etl"] if r != "infrastructure"]
    timing = [(p, n, info) for p, r, n, info in g["xml"] if r == "timing"]
    if not traces and not timing:
        return None
    job = run_dir if _JOB.match(os.path.basename(run_dir)) else None
    rel = os.path.relpath(run_dir, folder)
    run = {"id": run_id_of(run_dir), "run_dir": run_dir, "job_name": os.path.basename(job) if job else None,
           "label": os.path.basename(job) if job else (os.path.basename(folder) if rel == "." else rel),
           "iterations": [], "machine_config": None, "analysis_xml": [], "io_xml": [], "infrastructure_etls": [],
           "unreadable_xml": [], "problems": [], "ignored": []}
    for p, r, n, info in g["xml"]:
        if r == "machine" and run["machine_config"] is None:
            run["machine_config"] = p
        elif r == "analysis":
            run["analysis_xml"].append(p)
        elif r == "io":
            run["io_xml"].append({"path": p, "n": n})
        elif r == "unreadable":
            run["unreadable_xml"].append(p)
            run["problems"].append("%s: %s" % (os.path.basename(p), info.get("problem")))
    run["infrastructure_etls"] = [p for p, r, n in g["etl"] if r == "infrastructure"]

    # number the files without a number, in name order, after the highest number seen
    used = [n for _p, _r, n in traces if n is not None] + [n for _p, n, _i in timing if n is not None]
    nxt = (max(used) if used else 0) + 1
    unnumbered_x = sorted([p for p, n, _i in timing if n is None], key=str.lower)
    unnumbered_t = sorted([p for p, r, n in traces if n is None and r == "trace"], key=str.lower)
    fixed = {}
    if len(unnumbered_x) == 1 and len(unnumbered_t) == 1 and not used:
        fixed[unnumbered_x[0]] = fixed[unnumbered_t[0]] = 1
    else:
        for p in unnumbered_x + unnumbered_t:
            fixed[p] = nxt
            nxt += 1
        if unnumbered_x or unnumbered_t:
            run["problems"].append("%d file(s) carry no iteration number: numbered in name order (%s)"
                                   % (len(unnumbered_x) + len(unnumbered_t), ", ".join(os.path.basename(p) for p in (unnumbered_x + unnumbered_t)[:6])))
    by_n = {}
    for p, n, _i in timing:
        by_n.setdefault(n if n is not None else fixed[p], {"xml": [], "etl": {}})["xml"].append(p)
    for p, r, n in traces:
        if n is None:
            n = fixed.get(p)
            if n is None:                                # an unnumbered io / analysis / verbose trace: belongs to the first iteration
                n = min(by_n) if by_n else 1
        by_n.setdefault(n, {"xml": [], "etl": {}})["etl"].setdefault(r, []).append(p)
    for n in sorted(by_n):
        d = by_n[n]
        it = {"n": n, "xml": None, "etl": None, "etl_role": None, "etl_bytes": None, "extra_etls": [], "io_xml": None, "notes": []}
        xs = _prefer("xml", d["xml"], run_dir)
        if xs:
            it["xml"] = xs[0]
            run["ignored"] += ["iteration %d: duplicate XML %s (used %s)" % (n, p, xs[0]) for p in xs[1:]]
        for role in sorted(d["etl"], key=lambda r: ROLE_ORDER.get(r, 9)):
            ps = _prefer("etl", d["etl"][role], run_dir)
            usable = []
            for p in ps:
                size, why = _etl_ok(p)
                if why:
                    run["problems"].append("iteration %d: trace not used (%s): %s" % (n, why, p))
                else:
                    usable.append((p, size))
            if not usable:
                continue
            first, size = usable[0]
            if it["etl"] is None:
                it["etl"], it["etl_role"], it["etl_bytes"] = first, role, size
            else:
                it["extra_etls"].append({"path": first, "role": role, "bytes": size})
            run["ignored"] += ["iteration %d: duplicate %s trace %s (used %s)" % (n, role, p, first) for p, _s in usable[1:]]
        io = next((x["path"] for x in run["io_xml"] if x["n"] == n), None)
        it["io_xml"] = io
        if not it["xml"]:
            it["notes"].append("no timing XML: the Fast Startup time is taken from the trace")
        if not it["etl"]:
            it["notes"].append("no trace: only the XML is used (no per-command data)")
        elif it["etl_role"] != "trace":
            it["notes"].append("the %s trace is used as this iteration's trace" % it["etl_role"])
        run["iterations"].append(it)
    ns = [it["n"] for it in run["iterations"]]
    if ns and ns != list(range(ns[0], ns[-1] + 1)):
        run["problems"].append("iteration numbers are not contiguous: missing %s" % sorted(set(range(ns[0], ns[-1] + 1)) - set(ns)))
    return run


def looks_like_adk(inv):
    """True when the folder holds Windows ADK material (a trace or an assessment timing XML)."""
    return bool(inv.get("runs"))


def brief(inv):
    """A short JSON-ready view for a screen: per run its label, iterations, traces and XMLs."""
    out = []
    for r in inv.get("runs", []):
        its = r["iterations"]
        out.append({"id": r["id"], "label": r["label"], "run_dir": r["run_dir"], "iterations": len(its),
                    "with_trace": sum(1 for i in its if i["etl"]), "with_xml": sum(1 for i in its if i["xml"]),
                    "extra_traces": sum(len(i["extra_etls"]) for i in its), "problems": r["problems"], "ignored": len(r["ignored"])})
    return out
