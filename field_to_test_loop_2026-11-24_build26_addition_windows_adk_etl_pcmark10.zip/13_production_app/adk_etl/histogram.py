"""I/O latency histograms: how many commands completed in each 5 µs of time (owner, 2026-11-24: "segregate for each and every
five microseconds how many number of command count that are coming, especially when it comes to I/O").

Buckets (config adk_etl): hist_bucket_us wide (5 µs) from 0 up to hist_fine_max_us (10 000 µs = 10 ms, about 98 % of the
disk commands of the traces seen); above it, buckets that double ([10, 20) ms, [20, 40) ms, ...) so that a 2-second command
does not need 400 000 empty buckets. hist_fine_max_us = 0: 5 µs buckets everywhere. Only buckets holding a command are stored.
Measure: a disk command's IO time (issue to completion: queue + device, xperf's "IO Time"; config hist_measure = service_us
for the device's own service time); a file I/O operation's duration.

    rows = build(disk_rows, file_rows, cfg)                  per (source, process, command, category, lo_us, hi_us): count
    ensure(store, rid, cfg)                                  a run's histograms exist and match the settings (rebuilt from the
                                                             decoded CSV cache when they do not: runs stored before, or a new width)
    h = run_hist(store, rid, category, process, command, source)    {(lo, hi): commands per boot}
    res = compare_hist(store, rid, bench_runs, ...)          run vs the benchmark, bucket by bucket, with percentiles
    stats(h)                                                 count, mean, p50 / p90 / p99 / max (from the buckets)
"""
import json
import os

from . import config, xperf


def settings(cfg=None):
    s = config.settings(cfg)
    return {"width": max(1, int(s.get("hist_bucket_us") or 5)), "fine_max": max(0, int(s.get("hist_fine_max_us") if s.get("hist_fine_max_us") is not None else 10000)),
            "measure": s.get("hist_measure") if s.get("hist_measure") in ("io_time_us", "service_us") else "io_time_us"}


def bucket(us, width=5, fine_max=10000):
    """(lo, hi) in µs of the bucket a duration falls in."""
    us = max(0.0, float(us))
    if fine_max <= 0 or us < fine_max:
        lo = int(us // width) * width
        return lo, lo + width
    lo = fine_max
    while us >= lo * 2:
        lo *= 2
    return lo, lo * 2


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def build(disk_rows, file_rows, cfg=None):
    hs = settings(cfg)
    counts = {}
    for rows, source, field in ((disk_rows, "disk", hs["measure"]), (file_rows, "file", "duration_us")):
        for r in rows or ():
            v = _f(r.get(field))
            if v is None:
                continue
            lo, hi = bucket(v, hs["width"], hs["fine_max"])
            k = (source, r["process"], r["command"], r["category"], lo, hi)
            counts[k] = counts.get(k, 0) + 1
    return [{"source": k[0], "process": k[1], "command": k[2], "category": k[3], "lo_us": k[4], "hi_us": k[5], "count": c}
            for k, c in counts.items()]


def _meta(hs):
    return json.dumps(hs, sort_keys=True)


def rebin_events(event_rows, cfg=None):
    """The buckets of every other timed command (adk_etl.commands wrote them while decoding, from each command's own time), in the
    current bucket settings: a bucket is moved by its lower edge (exact when the new width is a multiple of the old one)."""
    hs = settings(cfg)
    counts = {}
    for r in event_rows or ():
        try:
            lo0, c = float(r["lo_us"]), int(r["count"])
        except (KeyError, TypeError, ValueError):
            continue
        lo, hi = bucket(lo0, hs["width"], hs["fine_max"])
        k = ("event", r["process"], r["command"], r["category"], lo, hi)
        counts[k] = counts.get(k, 0) + c
    return [{"source": k[0], "process": k[1], "command": k[2], "category": k[3], "lo_us": k[4], "hi_us": k[5], "count": c} for k, c in counts.items()]


def store_iteration(store, rid, n, disk_rows, file_rows, cfg=None, event_rows=None):
    rows = build(disk_rows, file_rows, cfg) + rebin_events(event_rows, cfg)
    store.many("INSERT INTO histogram (run, n, source, process, command, category, lo_us, hi_us, count) VALUES (?,?,?,?,?,?,?,?,?)",
               [(rid, n, r["source"], r["process"], r["command"], r["category"], r["lo_us"], r["hi_us"], r["count"]) for r in rows])
    return len(rows)


def ensure(store, rid, cfg=None):
    """The run's histograms exist for the current settings; else they are (re)built from each iteration's decoded CSV files.
    Returns the number of iterations rebuilt (0 when nothing had to be done)."""
    hs = settings(cfg)
    want = _meta(hs)
    have = store.one("SELECT meta FROM hist_meta WHERE run=?", (rid,))
    if have and have["meta"] == want:
        return 0
    its = store.all("SELECT n, cache_dir FROM iteration WHERE run=? AND cache_dir IS NOT NULL", (rid,))
    store.exec("DELETE FROM histogram WHERE run=?", (rid,))
    done = 0
    for it in its:
        d = it["cache_dir"]
        disk = xperf.read_csv(os.path.join(d, "disk_commands.csv"))
        files = xperf.read_csv(os.path.join(d, "file_commands.csv"))
        events = xperf.read_csv(os.path.join(d, "event_buckets.csv"))
        if disk or files or events:
            store_iteration(store, rid, it["n"], disk, files, cfg, events)
            done += 1
    store.exec("DELETE FROM hist_meta WHERE run=?", (rid,))
    store.exec("INSERT INTO hist_meta (run, meta) VALUES (?,?)", (rid, want))
    return done


def mark_built(store, rid, cfg=None):
    store.exec("DELETE FROM hist_meta WHERE run=?", (rid,))
    store.exec("INSERT INTO hist_meta (run, meta) VALUES (?,?)", (rid, _meta(settings(cfg))))


def _traced(store, rid):
    return len({r["n"] for r in store.all("SELECT DISTINCT n FROM phase WHERE run=?", (rid,))}) or 0


def run_hist(store, rid, category="all", process=None, command=None, source=None):
    """{(lo, hi): commands per boot} of one run (counts summed over the selection, divided by the traced iterations)."""
    sql = "SELECT lo_us, hi_us, SUM(count) c FROM histogram WHERE run=?"
    args = [rid]
    for col, v in (("category", None if category in (None, "", "all") else category), ("process", process),
                   ("command", command), ("source", source)):
        if v not in (None, ""):
            sql += " AND %s=?" % col
            args.append(v)
    rows = store.all(sql + " GROUP BY lo_us, hi_us", tuple(args))
    div = float(_traced(store, rid) or 1)
    return {(r["lo_us"], r["hi_us"]): r["c"] / div for r in rows}


def stats(h):
    """count, mean and percentiles (µs) of a histogram {(lo, hi): count}; a percentile is interpolated inside its bucket."""
    items = sorted(h.items())
    total = sum(c for _k, c in items)
    out = {"count": round(total, 1), "mean_us": None, "p50_us": None, "p90_us": None, "p99_us": None, "max_bucket_us": None}
    if total <= 0:
        return out
    out["mean_us"] = round(sum((lo + hi) / 2.0 * c for (lo, hi), c in items) / total, 1)
    out["max_bucket_us"] = [items[-1][0][0], items[-1][0][1]]
    for p in (50, 90, 99):
        target = total * p / 100.0
        cum = 0.0
        for (lo, hi), c in items:
            if c <= 0:
                continue
            if cum + c >= target:
                out["p%d_us" % p] = round(lo + (hi - lo) * (target - cum) / c, 1)
                break
            cum += c
    return out


def share_above(h, us):
    total = sum(h.values())
    return round(100.0 * sum(c for (lo, _hi), c in h.items() if lo >= us) / total, 2) if total else None


def compare_hist(store, rid, bench_ids, category="all", process=None, command=None, source=None):
    """The run's histogram against the benchmark (the mean over the benchmark runs of their per-boot histograms; a run without
    commands in a bucket counts 0 there)."""
    run = run_hist(store, rid, category, process, command, source)
    bench = {}
    for b in bench_ids:
        for k, v in run_hist(store, b, category, process, command, source).items():
            bench[k] = bench.get(k, 0.0) + v
    nb = float(len(bench_ids) or 1)
    bench = {k: v / nb for k, v in bench.items()}
    buckets = []
    for k in sorted(set(run) | set(bench)):
        r, b = run.get(k, 0.0), bench.get(k, 0.0)
        buckets.append({"lo_us": k[0], "hi_us": k[1], "run": round(r, 2), "bench": round(b, 2), "delta": round(r - b, 2)})
    sr, sb = stats(run), stats(bench)
    grew = sorted([x for x in buckets if x["delta"] > 0], key=lambda x: -x["delta"])[:15]
    return {"category": category or "all", "process": process, "command": command, "source": source, "buckets": buckets,
            "run_stats": sr, "bench_stats": sb, "bench_runs": len(bench_ids),
            "above_1ms_pct": {"run": share_above(run, 1000), "bench": share_above(bench, 1000)},
            "above_10ms_pct": {"run": share_above(run, 10000), "bench": share_above(bench, 10000)},
            "buckets_that_grew": grew}


def latency_overview(store, rid, bench_ids, categories, commands_of):
    """Per category and per command (all processes together): the run's and the benchmark's count, mean and percentiles.
    commands_of: {category: [(source, command)]}. Small enough to keep with a comparison."""
    out = {}
    for cat in categories:
        lst = []
        for source, cmd in commands_of.get(cat, []):
            c = compare_hist(store, rid, bench_ids, cat, None, cmd, source)
            lst.append({"source": source, "command": cmd, "run": c["run_stats"], "bench": c["bench_stats"],
                        "above_1ms_pct": c["above_1ms_pct"], "above_10ms_pct": c["above_10ms_pct"],
                        "buckets_that_grew": c["buckets_that_grew"][:5]})
        out[cat] = lst
    return out
