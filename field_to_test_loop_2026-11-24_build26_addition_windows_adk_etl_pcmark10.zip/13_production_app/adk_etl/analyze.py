"""Analyse every run of a folder and keep the result in the store (PASS and FAIL alike).

    result = analyze_folder(folder, project, store, cfg, cache_root, progress=None, only_runs=None)

Per run:
  1. each iteration: its timing XML read (every number kept, the Fast Startup time picked), its trace decoded with xperf
     (xperf.decode: processes, disk commands, file I/O operations, event census, phases), aggregated per
     (process, command, category) and stored;
  2. the Fast Startup time of an iteration: the XML's metric when there is one, else the trace's (start of LogonUI.exe);
  3. verdict: mean of the iterations' Fast Startup times <= limit (14 000 ms) -> PASS, above -> FAIL; none -> UNKNOWN.
"""
import os
import statistics
import time

from . import config, discover, histogram, xmlread, xperf

PROGRESS_NONE = lambda *_a, **_k: None          # noqa: E731


def _p95(values):
    if not values:
        return None
    v = sorted(values)
    return v[min(len(v) - 1, int(round(0.95 * (len(v) - 1))))]


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def aggregate_commands(rows, time_field, source, top_files):
    """rows: dicts of disk_commands.csv / file_commands.csv -> (command rows, command_file rows)."""
    groups, files = {}, {}
    for r in rows:
        t = _f(r.get(time_field))
        if t is None:
            continue
        k = (r["process"], r["command"], r["category"])
        g = groups.get(k)
        if g is None:
            g = groups[k] = {"count": 0, "total": 0.0, "service": 0.0, "max": 0.0, "bytes": 0.0, "values": []}
        g["count"] += 1
        g["total"] += t
        g["service"] += _f(r.get("service_us")) or 0.0
        g["max"] = max(g["max"], t)
        g["bytes"] += _f(r.get("size_bytes")) or 0.0
        g["values"].append(t)
        fk = k + (xperf.norm_file(r.get("file")),)
        fg = files.get(fk)
        if fg is None:
            fg = files[fk] = [0, 0.0, 0.0]
        fg[0] += 1
        fg[1] += t
        fg[2] = max(fg[2], t)
    cmd_rows = [{"source": source, "process": k[0], "command": k[1], "category": k[2], "count": g["count"], "total_us": round(g["total"], 1),
                 "service_us": round(g["service"], 1), "max_us": g["max"], "p95_us": _p95(g["values"]), "bytes": g["bytes"]}
                for k, g in groups.items()]
    by_cmd = {}
    for fk, (c, tot, mx) in files.items():
        by_cmd.setdefault(fk[:3], []).append({"process": fk[0], "command": fk[1], "category": fk[2], "file": fk[3], "count": c,
                                              "total_us": round(tot, 1), "max_us": mx})
    file_rows = []
    for lst in by_cmd.values():
        lst.sort(key=lambda x: -x["total_us"])
        file_rows += lst[:top_files]
    return cmd_rows, file_rows


def aggregate_processes(procs):
    out = {}
    for p in procs:
        k = p["key"]
        st = _f(p.get("start_us"))
        life = _f(p.get("lifetime_ms"))
        o = out.get(k)
        if o is None:
            o = out[k] = {"process": k, "instances": 0, "first_start_ms": None, "lifetime_ms": None, "phase": p.get("phase"),
                          "category": p.get("category")}
        o["instances"] += 1
        if st is not None and (o["first_start_ms"] is None or st / 1000.0 < o["first_start_ms"]):
            o["first_start_ms"] = round(st / 1000.0, 3)
            o["phase"], o["category"] = p.get("phase"), p.get("category")
        if life is not None:
            o["lifetime_ms"] = max(o["lifetime_ms"] or 0.0, life)
    return list(out.values())


def analyze_folder(folder, project, store, cfg, cache_root, progress=None, only_runs=None):
    say = progress or PROGRESS_NONE
    inv = discover.discover(folder, cfg)
    out = {"folder": inv["folder"], "errors": list(inv["errors"]), "runs": [], "discovery": discover.brief(inv)}
    if inv["errors"]:
        return out
    runs = [r for r in inv["runs"] if not only_runs or r["id"] in only_runs]
    total_its = sum(len(r["iterations"]) for r in runs) or 1
    done = [0]
    for run in runs:
        def step(note, run=run):
            say(note, 100.0 * done[0] / total_its)
        rid = analyze_run(run, inv["folder"], project, store, cfg, cache_root, step, done)
        out["runs"].append(rid)
    return out


def analyze_run(run, folder, project, store, cfg, cache_root, say=PROGRESS_NONE, done=None):
    s = config.settings(cfg)
    limit = float(s["limit_ms"])
    rid = store.new_run(project, run["id"], run["label"], folder, run["run_dir"], limit)
    notes = list(run["problems"])
    boots, sources, traced = [], set(), 0
    timelines = []
    try:
        for it in run["iterations"]:
            n = it["n"]
            say("run %s, iteration %d: reading" % (run["label"], n))
            rows, xnotes = xmlread.read_timing_xml(it["xml"], cfg) if it["xml"] else ([], [])
            if it.get("io_xml"):
                rows += [dict(r, kind="io_process") for r in xmlread.read_io_xml(it["io_xml"])]
            xml_boot, metric = xmlread.boot_of(rows)
            store.many("INSERT INTO xml_item (run, n, kind, name, measure, value) VALUES (?,?,?,?,?,?)",
                       [(rid, n, r["kind"], r["name"], r["measure"], r["value"]) for r in rows])
            meta, etl_boot, inotes = None, None, list(it["notes"]) + [x for x in xnotes if not x.startswith("Fast Startup time:")]
            if it["etl"]:
                say("run %s, iteration %d: decoding the trace with xperf" % (run["label"], n))
                try:
                    meta = xperf.decode(it["etl"], cache_root, cfg, progress=lambda t, n=n: say("run %s, iteration %d: %s" % (run["label"], n, t)))
                except xperf.XperfMissing:
                    raise
                except Exception as exc:                # noqa: BLE001 - one bad trace never stops the run
                    inotes.append("the trace could not be decoded: %s" % str(exc)[:300])
                    notes.append("iteration %d: the trace could not be decoded: %s" % (n, str(exc)[:200]))
            if meta:
                traced += 1
                etl_boot = meta["timeline"].get("boot_ms")
                inotes += meta.get("notes", [])
                timelines.append(meta["timeline"])
                _store_trace(store, rid, n, meta, int(s.get("top_files") or 40), cfg)
            boot = xml_boot if xml_boot is not None else etl_boot
            src = ("XML: %s" % metric) if xml_boot is not None else ("trace: start of LogonUI.exe" if etl_boot is not None else None)
            if boot is not None:
                boots.append(boot)
                sources.add(src)
            store.exec("INSERT INTO iteration (run, n, xml, etl, etl_bytes, boot_ms, boot_source, xml_boot_ms, etl_boot_ms, cache_dir, counts, notes, timeline) "
                       "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                       (rid, n, it["xml"], it["etl"], it["etl_bytes"], boot, src, xml_boot, etl_boot, meta["dir"] if meta else None,
                        _js(meta["counts"]) if meta else None, _js(inotes), _js(meta["timeline"]) if meta else None))
            if done is not None:
                done[0] += 1
        mean = round(statistics.fmean(boots), 1) if boots else None
        verdict = "UNKNOWN" if mean is None else ("PASS" if mean <= limit else "FAIL")
        if len(sources) > 1:
            notes.append("the iterations do not all take the Fast Startup time from the same place: %s" % "; ".join(sorted(sources)))
        info = {"boot_values": boots, "boot_std_ms": round(statistics.stdev(boots), 1) if len(boots) > 1 else 0.0,
                "machine_config": run.get("machine_config"), "analysis_xml": run.get("analysis_xml"),
                "extra_traces": [x for it in run["iterations"] for x in it["extra_etls"]], "ignored": run.get("ignored", [])}
        analysis = []
        for p in run.get("analysis_xml") or []:
            analysis += xmlread.read_analysis_xml(p)
        info["assessment_issues"] = analysis[:50]
        histogram.mark_built(store, rid, cfg)
        store.finish_run(rid, status="done", verdict=verdict, boot_mean_ms=mean, boot_source="; ".join(sorted(sources)),
                         iterations=len(run["iterations"]), traced=traced, notes=notes, info=info)
    except Exception as exc:                            # noqa: BLE001
        store.finish_run(rid, status="failed", error=str(exc)[:1000], notes=notes)
        raise
    return rid


def _store_trace(store, rid, n, meta, top_files, cfg=None):
    f = meta["files"]
    store.many("INSERT INTO phase (run, n, phase, category, start_ms, duration_ms) VALUES (?,?,?,?,?,?)",
               [(rid, n, sg["phase"], sg["category"], round(sg["start_us"] / 1000.0, 3), sg["duration_ms"]) for sg in meta["timeline"]["segments"]])
    procs = xperf.read_csv(f["processes"])
    store.many("INSERT INTO process (run, n, process, instances, first_start_ms, lifetime_ms, phase, category) VALUES (?,?,?,?,?,?,?,?)",
               [(rid, n, p["process"], p["instances"], p["first_start_ms"], p["lifetime_ms"], p["phase"], p["category"])
                for p in aggregate_processes(procs)])
    loaded = {}
    for path, tf, source in ((f["disk_commands"], "io_time_us", "disk"), (f["file_commands"], "duration_us", "file")):
        loaded[source] = xperf.read_csv(path)
        cmds, files = aggregate_commands(loaded[source], tf, source, top_files)
        store.many("INSERT INTO command (run, n, source, process, command, category, count, total_us, service_us, max_us, p95_us, bytes) "
                   "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                   [(rid, n, c["source"], c["process"], c["command"], c["category"], c["count"], c["total_us"], c["service_us"], c["max_us"],
                     c["p95_us"], c["bytes"]) for c in cmds])
        store.many("INSERT INTO command_file (run, n, process, command, category, file, count, total_us, max_us) VALUES (?,?,?,?,?,?,?,?,?)",
                   [(rid, n, x["process"], x["command"], x["category"], x["file"], x["count"], x["total_us"], x["max_us"]) for x in files])
    histogram.store_iteration(store, rid, n, loaded["disk"], loaded["file"], cfg, xperf.read_csv(f.get("event_buckets")))
    store.many("INSERT INTO command_all (run, n, process, command, category, count, timed, total_us, max_us, basis) VALUES (?,?,?,?,?,?,?,?,?,?)",
               [(rid, n, r["process"], r["command"], r["category"], int(r["count"]), int(r["timed"]), float(r["total_us"]), float(r["max_us"]),
                 r["basis"]) for r in xperf.read_csv(f.get("commands_all"))])
    store.many("INSERT INTO command_all_object (run, n, process, command, category, object, count, total_us, max_us) VALUES (?,?,?,?,?,?,?,?,?)",
               [(rid, n, r["process"], r["command"], r["category"], r["object"], int(r["count"]), float(r["total_us"]), float(r["max_us"]))
                for r in xperf.read_csv(f.get("command_objects"))])
    census = {}
    for r in xperf.read_csv(f["census"]):
        k = (r["process"], r["event"], r["category"])
        census[k] = census.get(k, 0) + int(r["count"] or 0)
    store.many("INSERT INTO census (run, n, process, event, category, count) VALUES (?,?,?,?,?,?)",
               [(rid, n, k[0], k[1], k[2], v) for k, v in census.items()])


def _js(x):
    import json
    return json.dumps(x)


def cache_root_of(app_root):
    d = os.path.join(app_root, "adk_cache")
    os.makedirs(d, exist_ok=True)
    return d


def now():
    return time.time()
