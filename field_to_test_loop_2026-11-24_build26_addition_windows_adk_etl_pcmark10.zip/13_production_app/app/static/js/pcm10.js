// The pages of an analysis of category PCMark 10 Storage (owner, 2026-11-24). Loaded after agents.js and uses its helpers
// ($, esc, api, IC, toast, crumb, setProject, route, S). Built from UL's documentation: no real PCMark 10 result file was seen.
//   1 Understand the data  the results found (.pcmark10-result archives whatever their names, or loose CSV / XML), how each file was
//                          read (layout, separator, columns not understood); "Read every result" stores them
//   2 One tree             not needed
//   3 PCMark 10 storage analytics   the baseline (good results) and per result "Compare": bandwidth and access time, the traces
//                          and metrics that are worse, the access-time percentiles (50 % ... 99.99 %) against the baseline
//   4 Report
"use strict";
(function () {
  const CAT = "pcmark10_storage";
  const ST = [
    { id: "data", n: 1, short: "Understand the data", who: "PCMark 10 Storage", title: "Understand the data",
      text: "Every PCMark 10 Storage result in the folder, found by what the files hold: a .pcmark10-result archive (a ZIP, whatever it is called) or the CSV / XML files taken out of one. Each CSV is read with UL's documented names (pcmark_storage_trace_metrics.csv: <filter>_<metric> per trace and pass; pcmark_storage_trace_statistics.csv; Ariel.xml: rw_bw, rw_aat). Its layout, separator and decimal sign are detected from the file, and every column that was not understood is listed." },
    { id: "tree", n: 2, short: "One tree", who: "Not needed for PCMark 10", title: "One tree", text: "Not needed for PCMark 10: each result is read by itself." },
    { id: "rules", n: 3, short: "Rules, defects, test cases", who: "PCMark 10 storage analytics", title: "PCMark 10 storage analytics",
      text: "The baseline is the good results (tick them, or set limits on bandwidth and access time in the configuration so that PASS results join it). Compare puts one result against the baseline: read/write bandwidth and average access time, the traces that are worse and in them the metrics (read / write, small / medium / large, random / sequential, flush ...), and the access-time percentiles 50 % to 99.99 %. A lower bandwidth is worse; a higher time is worse; counts and bytes describe the workload and are not ranked." },
    { id: "report", n: 4, short: "Report", who: "PCMark 10 Storage", title: "Report", text: "Every result with its numbers, and the summary of each comparison, with the CSV exports." },
  ];
  const P = { pid: null, inv: null, invFolder: null, results: [], status: null, bench: null, scope: "project", cmp: {}, sel: null, open: {},
              detail: {}, busy: "", pt: "all_traces", pf: "rw", scale: "log" };
  const n1 = x => x === null || x === undefined || x === "" ? "-" : Number(x).toLocaleString(undefined, { maximumFractionDigits: 1 });
  const mbps = b => b === null || b === undefined ? "-" : (b / 1e6).toLocaleString(undefined, { maximumFractionDigits: 1 }) + " MB/s";
  const val = (v, unit) => unit === "B/s" ? mbps(v) : unit === "B" ? (v === null || v === undefined ? "-" : (v / 1e6).toLocaleString(undefined, { maximumFractionDigits: 1 }) + " MB") : `${n1(v)}${unit ? " " + unit : ""}`;
  const wcls = w => w === null || w === undefined ? "" : w >= ((P.status || {}).flag_pct || 10) ? "err" : w < 0 ? "ok-t" : "";
  const wtxt = w => w === null || w === undefined ? "-" : `${w > 0 ? "+" : ""}${n1(w)}%`;
  const verdictPill = v => v === "PASS" ? `<span class="pill ok">PASS</span>` : v === "FAIL" ? `<span class="pill bad">FAIL</span>` : `<span class="pill">${esc(v || "-")}</span>`;
  const banner = () => `<div class="banner"><span>${esc((P.status || {}).unverified || "Built from UL's documentation: no real PCMark 10 result file has been seen yet.")}</span></div>`;

  async function load(p, force) {
    if (P.pid !== p.id) Object.assign(P, { pid: p.id, inv: null, invFolder: null, cmp: {}, sel: null, detail: {}, bench: null, open: {} });
    const jobs = [api("GET", "/api/pcm10/results?project=" + p.id).then(r => P.results = r)];
    if (!P.status || force) jobs.push(api("GET", "/api/pcm10/status").then(r => P.status = r));
    if (!P.inv || P.invFolder !== p.folder || force) jobs.push(api("GET", "/api/pcm10/inventory?folder=" + encodeURIComponent(p.folder)).then(r => { P.inv = r; P.invFolder = p.folder; }));
    await Promise.all(jobs);
    if (!P.bench || force) P.bench = await api("GET", `/api/pcm10/benchmark?project=${p.id}&scope=${P.scope}`);
    for (const r of P.results) {
      if (P.cmp[r.id] !== undefined) continue;
      try { P.cmp[r.id] = await api("GET", `/api/pcm10/results/${r.id}/compare`); } catch (e) { P.cmp[r.id] = null; }
    }
    if (!P.sel) { const c = P.results.find(r => P.cmp[r.id]); P.sel = c ? c.id : null; }
  }
  function states() {
    const read = P.results.filter(r => r.status === "done").length, compared = P.results.some(r => P.cmp[r.id]);
    return { data: read ? "done" : "waiting", tree: read ? "done" : "waiting", rules: read ? (compared ? "done" : "active") : "waiting", report: read ? "active" : "waiting" };
  }
  function stepper(pid, cur) {
    const s = states();
    return `<nav class="stepper" aria-label="the stages">` + ST.map(st => {
      const x = s[st.id], reached = st.id === "data" || x !== "waiting";
      const sub = st.id === "tree" ? "not needed" : { done: "done", active: "ready", waiting: "not yet" }[x];
      return `<button class="stg ${x} ${st.id === cur ? "cur" : ""}" data-act="stage" data-pid="${pid}" data-stage="${st.id}" ${reached ? "" : "disabled"}><span class="num">${x === "done" ? IC.check : st.n}</span><span class="txt"><div class="t">${st.n} · ${esc(st.short)}</div><div class="s">${esc(sub)}</div></span></button>`;
    }).join("") + `</nav>`;
  }
  function invView() {
    const v = P.inv || {};
    if ((v.errors || []).length) return `<p class="err">${esc(v.errors.join("; "))}</p>`;
    return `<div class="tbl"><table><tr><th>Result</th><th>Kind</th><th>Files read (role · layout)</th></tr>${(v.results || []).map(r => `<tr><td><b>${esc(r.label)}</b><div class="tiny muted">${esc(r.path)}</div></td>
      <td>${r.kind === "archive" ? (r.named_as_result ? ".pcmark10-result archive" : "archive (ZIP) under another name") : "folder of files"}</td>
      <td class="small">${r.files.map(f => `${esc(f.name)} <span class="muted">· ${esc(f.role)}${f.layout ? " · " + esc(f.layout) : ""}</span>`).join("<br>")}</td></tr>`).join("")}</table></div>
      ${(v.problems || []).length ? `<p class="small err">${v.problems.map(esc).join("<br>")}</p>` : ""}${(v.ignored || []).length ? `<p class="small muted">${v.ignored.map(esc).join("<br>")}</p>` : ""}`;
  }
  function resultsTable(actions) {
    if (!P.results.length) return `<div class="empty">No result read yet.</div>`;
    return `<div class="tbl"><table><tr><th>Result</th><th>Verdict</th><th>Read/write bandwidth</th><th>Average access</th><th>Score</th><th>Numbers from</th><th>Baseline</th>${actions ? "<th></th>" : ""}</tr>` +
      P.results.map(r => `<tr><td><b>${esc(r.label)}</b>${r.status !== "done" ? ` <span class="pill bad">${esc(r.status)}</span>` : ""}${r.error ? `<div class="err">${esc(r.error)}</div>` : ""}</td>
        <td>${verdictPill(r.verdict)}</td><td>${mbps(r.rw_bw)}</td><td>${r.rw_aat === null ? "-" : n1(r.rw_aat) + " µs"}</td><td>${r.score === null ? "-" : n1(r.score)}</td>
        <td class="small">${esc(r.headline_from || "-")}</td>
        <td><label class="small"><input type="checkbox" data-pcm="bench" data-rid="${r.id}" ${r.in_benchmark ? "checked" : ""}> ${r.in_benchmark ? "yes" : "no"}</label></td>
        ${actions ? `<td style="white-space:nowrap"><button class="btn small ${r.in_benchmark ? "" : "primary"}" data-pcm="compare" data-rid="${r.id}">Compare</button> <button class="btn small quiet" data-pcm="detail" data-rid="${r.id}">How it was read</button> <button class="btn small quiet danger" data-pcm="del" data-rid="${r.id}">Delete</button></td>` : ""}</tr>
        ${P.open["d" + r.id] ? `<tr><td colspan="8">${detailView(r.id)}</td></tr>` : ""}`).join("") + `</table></div>`;
  }
  function detailView(rid) {
    const d = P.detail[rid];
    if (!d) return `<p class="small muted">loading…</p>`;
    return `<div class="lbl2">Files of ${esc(d.result.label)}</div><div class="tbl"><table><tr><th>File</th><th>Role</th><th>Layout</th><th>Separator</th><th>Decimal comma</th><th>Rows</th><th>Values read</th><th>Columns not understood</th><th>Notes</th></tr>
      ${d.files.map(f => `<tr><td>${esc(f.name)}</td><td>${esc(f.role)}</td><td>${esc(f.layout || "-")}</td><td>${esc(f.separator === "\t" ? "tab" : f.separator || "-")}</td><td>${f.decimal_comma ? "yes" : "no"}</td><td>${n1(f.rows)}</td><td>${n1(f.values_read)}</td>
        <td class="small ${f.not_understood.length ? "err" : ""}">${f.not_understood.map(esc).join(", ") || "none"}</td><td class="tiny">${f.notes.map(esc).join("<br>")}</td></tr>`).join("")}</table></div>
      <p class="small muted">${n1(d.counts.metrics)} values · ${n1(d.counts.names)} metric names · ${n1(d.counts.traces)} traces · ${n1(d.counts.passes)} passes</p>
      <div class="tbl"><table><tr><th>Trace</th><th>What it records (UL)</th><th>rw bandwidth</th><th>rw average access</th><th>rw 99%</th><th>rw 99.99%</th><th>Passes</th></tr>
      ${d.traces.map(t => `<tr><td><b>${esc(t.trace)}</b></td><td class="small">${esc(t.words || "")}</td><td>${mbps(t.bw)}</td><td>${n1(t.aat)} µs</td><td>${n1(t.at99)} µs</td><td>${n1(t.at9999)} µs</td><td>${n1(t.passes)}</td></tr>`).join("")}</table></div>
      ${(d.result.notes || []).length ? `<p class="tiny muted">${d.result.notes.map(esc).join("<br>")}</p>` : ""}`;
  }
  function page1() {
    return banner() + `<section class="card"><div class="row" style="justify-content:space-between"><h2>Results found in the folder</h2><span class="row"><button class="btn small quiet" data-pcm="rescan">Look again</button>
      <button class="btn primary" data-pcm="analyze" ${P.busy === "analyze" ? "disabled" : ""}>${IC.play}${P.busy === "analyze" ? "reading…" : P.results.length ? "Read again" : "Read every result"}</button></span></div>${invView()}</section>
      <div class="sectionhead">Results read and stored</div><section class="card">${resultsTable(true)}</section>`;
  }
  function benchView() {
    const b = P.bench || {};
    const sc = `<span class="row small"><label><input type="radio" name="pcm-scope" data-pcm="scope" value="project" ${P.scope === "project" ? "checked" : ""}> baseline of this analysis</label>
      <label><input type="radio" name="pcm-scope" data-pcm="scope" value="all" ${P.scope === "all" ? "checked" : ""}> of every analysis</label></span>`;
    const lim = (P.status || {}).limits || {};
    if (!b.n) return `<section class="card"><div class="row" style="justify-content:space-between"><h2>Baseline</h2>${sc}</div><p class="err">No baseline result yet: tick "Baseline" for the good results below${lim.min_rw_bw_mbps || lim.max_rw_aat_us ? "" : " (or set pcm10.min_rw_bw_mbps / pcm10.max_rw_aat_us in the configuration so that PASS results join it)"}.</p></section>`;
    return `<section class="card"><div class="row" style="justify-content:space-between"><h2>Baseline · ${b.n} result(s)</h2>${sc}</div>
      <div class="tiles" style="margin-top:10px"><div class="tile"><div class="v">${mbps(b.rw_bw)}</div><div class="l">read/write bandwidth (mean)</div></div><div class="tile"><div class="v">${n1(b.rw_aat)} µs</div><div class="l">read/write average access time (mean)</div></div>
      ${b.score !== null && b.score !== undefined ? `<div class="tile"><div class="v">${n1(b.score)}</div><div class="l">score (mean)</div></div>` : ""}</div>
      <p class="small muted">${(b.results || []).map(r => esc(r.label)).join(", ")}</p></section>`;
  }
  function pctChart(res) {
    const per = res.percentiles || {};
    const traces = Object.keys(per);
    if (!traces.length) return `<p class="small muted">No access-time percentile in this result.</p>`;
    if (!per[P.pt]) P.pt = traces[0];
    const filters = Object.keys(per[P.pt]);
    if (!filters.includes(P.pf)) P.pf = filters.includes("rw") ? "rw" : filters[0];
    const pts = per[P.pt][P.pf];
    const f = P.scale === "log" ? v => Math.log10(1 + (v || 0)) : v => v || 0;
    const max = Math.max(...pts.map(p => Math.max(f(p.run), f(p.bench)))) || 1;
    const H = 200, gw = 90, L = 50, W = L + pts.length * gw + 20;
    let g = "";
    pts.forEach((p, i) => {
      const x = L + i * gw + 10, hb = (f(p.bench) / max) * H, hr = (f(p.run) / max) * H;
      g += `<g><title>${esc(p.words)}: this result ${n1(p.run)} µs, baseline ${n1(p.bench)} µs (${wtxt(p.worse_pct)})</title>
        <rect x="${x}" y="${H - hb}" width="30" height="${hb}" style="fill:var(--faint);opacity:.6"></rect><rect x="${x + 34}" y="${H - hr}" width="30" height="${hr}" style="fill:var(--accent);opacity:.8"></rect>
        <text x="${x}" y="${H + 16}" style="font-size:11px;fill:var(--muted)">${esc(p.words)}</text><text x="${x}" y="${H + 30}" style="font-size:10px;fill:var(--muted)">${esc(wtxt(p.worse_pct))}</text></g>`;
    });
    const top = P.scale === "log" ? Math.pow(10, max) - 1 : max;
    return `<div class="row" style="gap:14px;margin:6px 0">
        <label class="small">Trace <select data-pcm="pt">${traces.map(t => `<option value="${esc(t)}" ${t === P.pt ? "selected" : ""}>${esc(t)}</option>`).join("")}</select></label>
        <label class="small">Operations <select data-pcm="pf">${filters.map(x => `<option value="${esc(x)}" ${x === P.pf ? "selected" : ""}>${esc(x)}</option>`).join("")}</select></label>
        <span class="row"><button class="btn small ${P.scale === "lin" ? "primary" : ""}" data-pcm="scale" data-v="lin">linear</button><button class="btn small ${P.scale === "log" ? "primary" : ""}" data-pcm="scale" data-v="log">log</button></span></div>
      <div class="small"><span style="display:inline-block;width:10px;height:10px;background:var(--faint);opacity:.6"></span> baseline · <span style="display:inline-block;width:10px;height:10px;background:var(--accent);opacity:.8"></span> this result · access time in µs; hover a bar for its value</div>
      <div style="overflow-x:auto;border:1px solid var(--line);border-radius:10px;padding:8px"><svg width="${W}" height="${H + 40}" role="img" aria-label="access-time percentiles">
        <line x1="${L}" y1="${H}" x2="${W}" y2="${H}" style="stroke:var(--line)"></line><text x="2" y="12" style="font-size:10px;fill:var(--muted)">${esc(n1(top))} µs</text><text x="2" y="${H}" style="font-size:10px;fill:var(--muted)">0</text>${g}</svg></div>`;
  }
  function cmpView(res) {
    if (!res) return "";
    if (res.error && !res.headline) return `<section class="card"><p class="err">${esc(res.error)}</p></section>`;
    const r = res.result, sm = res.summary || {};
    let h = `<section class="card"><div class="row" style="justify-content:space-between"><h2>${esc(r.label)} against the baseline</h2>
      <span class="row"><a class="btn small" href="/api/pcm10/results/${r.id}/compare.csv?level=trace">${IC.ext}Traces CSV</a><a class="btn small" href="/api/pcm10/results/${r.id}/compare.csv?level=metric">${IC.ext}Metrics CSV</a><a class="btn small" href="/api/pcm10/results/${r.id}/compare.csv?level=percentile">${IC.ext}Percentiles CSV</a></span></div>
      ${res.error ? `<p class="err">${esc(res.error)}</p>` : ""}
      <div class="tiles" style="margin-top:10px">${(res.headline || []).map(x => `<div class="tile"><div class="v ${wcls(x.worse_pct)}">${x.metric === "rw_bw" ? mbps(x.run) : n1(x.run) + (x.metric === "rw_aat" ? " µs" : "")}</div>
        <div class="l">${esc(x.words)} · baseline ${x.metric === "rw_bw" ? mbps(x.bench) : n1(x.bench)} · <b>${esc(wtxt(x.worse_pct))} worse</b></div></div>`).join("")}
        <div class="tile"><div class="v ${res.metrics_worse ? "err" : ""}">${n1(res.metrics_worse)} / ${n1(res.metrics_compared)}</div><div class="l">metrics ${n1(res.flag_pct)}% or more worse</div></div></div>
      ${res.note ? `<p class="err">${esc(res.note)}</p>` : ""}
      <div class="lbl2" style="margin-top:12px">Summary · written by ${esc(sm.by || "the program")}</div>${sm.model_text ? `<div style="white-space:pre-wrap">${esc(sm.model_text)}</div>` : ""}
      ${(sm.likely_causes || []).length ? `<div class="small"><b>Likely causes (hypotheses):</b> ${sm.likely_causes.map(esc).join(" · ")}</div>` : ""}
      <details class="more" data-id="pcm-written" ${sm.model_text ? "" : "open"}><summary>${IC.chev}The summary written by the program</summary><div class="small" style="white-space:pre-wrap;margin-top:6px">${esc(sm.text || "")}</div></details></section>`;
    h += `<section class="card"><h2>Traces, worst first</h2><div class="tbl"><table><tr><th>Trace</th><th>What it records (UL)</th><th>rw bandwidth (vs baseline)</th><th>rw average access</th><th>Metrics worse</th><th>Worst metric</th></tr>
      ${(res.traces || []).map(t => `<tr><td><b>${esc(t.trace)}</b></td><td class="small">${esc(t.words)}</td>
        <td>${t.rw_bw ? `${mbps(t.rw_bw.run)} <span class="tiny muted">vs ${mbps(t.rw_bw.bench)}</span> <span class="${wcls(t.rw_bw.worse_pct)}">${esc(wtxt(t.rw_bw.worse_pct))}</span>` : "-"}</td>
        <td>${t.rw_aat ? `${n1(t.rw_aat.run)} µs <span class="tiny muted">vs ${n1(t.rw_aat.bench)}</span> <span class="${wcls(t.rw_aat.worse_pct)}">${esc(wtxt(t.rw_aat.worse_pct))}</span>` : "-"}</td>
        <td class="${t.n_worse ? "err" : ""}">${n1(t.n_worse)}</td><td class="small">${t.worst ? `${esc(t.worst.metric)}: ${esc(val(t.worst.run, t.worst.unit))} vs ${esc(val(t.worst.bench, t.worst.unit))} <span class="${wcls(t.worst.worse_pct)}">${esc(wtxt(t.worst.worse_pct))}</span>` : "-"}</td></tr>`).join("")}</table></div></section>`;
    h += `<section class="card"><h2>Access-time percentiles</h2><p class="small muted">UL's metrics _at50, _at90, _at95, _at99, _at9999 (µs) per kind of operation; "all_traces" is the aggregate over the traces.</p>${pctChart(res)}</section>`;
    h += `<section class="card"><h2>Metrics, worst first</h2><div class="tbl" style="max-height:480px;overflow:auto"><table><tr><th>Trace</th><th>Metric</th><th>Meaning (UL)</th><th>This result</th><th>Baseline</th><th>Worse</th></tr>
      ${(res.worst_metrics || []).slice(0, 50).map(m => `<tr><td>${esc(m.trace)}</td><td><b>${esc(m.metric)}</b></td><td class="small">${esc(m.filter)} · ${esc(m.ending)}</td><td>${esc(val(m.run, m.unit))}</td><td>${esc(val(m.bench, m.unit))}${m.bench_n > 1 ? ` <span class="tiny muted">±${esc(val(m.bench_std, m.unit))}</span>` : ""}</td><td class="${wcls(m.worse_pct)}">${esc(wtxt(m.worse_pct))}</td></tr>`).join("")}</table></div>
      ${(res.passes || []).length ? `<details class="more" data-id="pcm-passes"><summary>${IC.chev}Pass to pass: each trace's read/write bandwidth over the passes</summary><div class="tbl"><table><tr><th>Trace</th><th>Bandwidth per pass</th><th>Spread</th></tr>${res.passes.map(p => `<tr><td>${esc(p.trace)}</td><td>${p.values.map(mbps).join(" · ")}</td><td>${p.spread_pct === null ? "-" : n1(p.spread_pct) + "%"}</td></tr>`).join("")}</table></div></details>` : ""}</section>`;
    return h;
  }
  function page3() {
    let h = banner() + benchView() + `<div class="sectionhead">Results · choose one to compare with the baseline</div><section class="card">${resultsTable(true)}</section>`;
    if (P.busy === "compare") h += `<div class="working"><span class="spin"></span><div class="grow"><b>Comparing…</b></div></div>`;
    if (P.sel && P.cmp[P.sel]) h += `<div class="sectionhead" id="pcm-cmp">Comparison</div>` + cmpView(P.cmp[P.sel]);
    return h;
  }
  function page4() {
    let h = banner() + `<section class="card">${resultsTable(false)}</section>`;
    for (const r of P.results) {
      const c = P.cmp[r.id];
      if (c) h += `<section class="card"><h2>${esc(r.label)}</h2><div class="small" style="white-space:pre-wrap">${esc(((c.summary || {}).model_text ? c.summary.model_text + "\n\n" : "") + ((c.summary || {}).text || ""))}</div>
        <div class="row" style="margin-top:8px"><a class="btn small" href="/api/pcm10/results/${r.id}/compare.csv?level=metric">${IC.ext}Metrics CSV</a><a class="btn small" href="/api/pcm10/results/${r.id}/compare.csv?level=trace">${IC.ext}Traces CSV</a></div></section>`;
    }
    if (!P.results.some(r => P.cmp[r.id])) h += `<div class="card empty">No comparison yet: compare a result on page 3.</div>`;
    return h;
  }

  async function renderProject(m, p, wanted, quiet) {
    setProject(p.id);
    S.shown = null;
    crumb(`<b>${esc(p.name)}</b>`);
    if (!quiet) m.innerHTML = `<div class="card">Loading…</div>`;
    await load(p, !quiet);
    const s = states();
    const cur = wanted && ST.find(x => x.id === wanted) && (wanted === "data" || s[wanted] !== "waiting") ? wanted : (P.results.length ? "rules" : "data");
    const st = ST.find(x => x.id === cur), y = window.scrollY;
    let h = `<div class="phead"><div><h1>${esc(p.name)}</h1><div class="meta">${esc(p.folder)} · <b>PCMark 10 Storage</b></div></div></div>` + stepper(p.id, cur);
    h += `<div class="stitle"><div><div class="who">${esc(st.who)}</div><h2>${st.n} · ${esc(st.title)}</h2><p>${esc(st.text)}</p></div></div><div class="stack" id="pcm-page">`;
    h += cur === "data" ? page1() : cur === "tree" ? `<div class="card empty">${esc(ST[1].text)}</div>` : cur === "rules" ? page3() : page4();
    const i = ST.indexOf(st), prev = ST[i - 1], next = ST[i + 1];
    h += `</div><div class="navfoot">${prev ? `<button class="btn" data-act="stage" data-pid="${p.id}" data-stage="${prev.id}">${IC.left}${prev.n} · ${esc(prev.short)}</button>` : "<span></span>"}
      ${next ? `<button class="btn ${s[next.id] !== "waiting" ? "primary" : ""}" data-act="stage" data-pid="${p.id}" data-stage="${next.id}" ${s[next.id] !== "waiting" ? "" : "disabled"}>${next.n} · ${esc(next.short)} ${IC.chev}</button>` : ""}</div>`;
    m.innerHTML = h;
    if (quiet) window.scrollTo(0, y);
  }
  async function redraw(force) {
    const r = route(); if (r[0] !== "p" || !r[1]) return;
    const p = (S.state.projects || []).find(x => x.id === Number(r[1])); if (!p || p.source_tool !== CAT) return;
    if (force) P.bench = null;
    await renderProject($("main"), p, r[2], true);
  }
  $("main").addEventListener("click", async e => {
    const b = e.target.closest("[data-pcm]"); if (!b) return;
    const act = b.dataset.pcm, rid = Number(b.dataset.rid);
    if (["scope", "bench", "pt", "pf"].includes(act)) return;
    e.preventDefault();
    try {
      if (act === "analyze") { P.busy = "analyze"; await redraw(false); try { const o = await api("POST", "/api/pcm10/analyze", { project: P.pid }); toast(`${o.results.length} result(s) read`); } finally { P.busy = ""; } P.cmp = {}; P.detail = {}; await redraw(true); }
      else if (act === "rescan") { P.inv = null; await redraw(true); }
      else if (act === "detail") { P.open["d" + rid] = !P.open["d" + rid]; if (P.open["d" + rid] && !P.detail[rid]) P.detail[rid] = await api("GET", "/api/pcm10/results/" + rid); await redraw(false); }
      else if (act === "del") { if (!confirm("Delete this result from the store? Its files stay where they are.")) return; await api("DELETE", "/api/pcm10/results/" + rid); delete P.cmp[rid]; if (P.sel === rid) P.sel = null; await redraw(true); }
      else if (act === "compare") {
        P.busy = "compare"; P.sel = rid;
        if (route()[2] !== "rules") history.replaceState(null, "", `#/p/${P.pid}/rules`);
        await redraw(false);
        try { P.cmp[rid] = await api("POST", `/api/pcm10/results/${rid}/compare`, { scope: P.scope, llm: true }); } finally { P.busy = ""; }
        P.pt = "all_traces"; P.pf = "rw"; await redraw(false);
        const el = document.getElementById("pcm-cmp"); if (el) el.scrollIntoView({ behavior: "smooth" });
      }
      else if (act === "scale") { P.scale = b.dataset.v; await redraw(false); }
    } catch (err) { P.busy = ""; toast(err.message); await redraw(false); }
  });
  $("main").addEventListener("change", async e => {
    const b = e.target.closest("[data-pcm]"); if (!b) return;
    try {
      if (b.dataset.pcm === "scope") { P.scope = b.value; P.bench = null; await redraw(false); }
      else if (b.dataset.pcm === "bench") { await api("PUT", "/api/pcm10/results/" + b.dataset.rid, { in_benchmark: b.checked }); P.bench = null; await redraw(false); }
      else if (b.dataset.pcm === "pt") { P.pt = b.value; await redraw(false); }
      else if (b.dataset.pcm === "pf") { P.pf = b.value; await redraw(false); }
    } catch (err) { toast(err.message); }
  });
  window.PCM = { CAT, renderProject, isPcm: p => !!p && p.source_tool === CAT };
})();
