// The pages of an analysis of category Windows ADK (ETL + XML) (owner, 2026-11-24). Loaded after agents.js and uses its helpers
// ($, esc, api, nf, when, IC, toast, crumb, setProject, refreshState, S). Same four pages as every analysis:
//   1 Understand the data  the runs and iterations found in the folder (by content, whatever the files are called); "Analyse"
//                          decodes every trace with xperf into tables (no CSV needed) and stores each run, PASS or FAIL
//   2 One tree             not needed: each run is analysed by itself
//   3 Rules, defects, test cases   section "Windows ADK ETL analytics": the benchmark (the PASS runs pooled), and per run
//                          "Compare": phase > process > command (> file), ranked by the time added, per pre-logon / logon / post-logon
//   4 Report               every run's verdict and each comparison's summary, with the CSV exports
"use strict";
(function () {
  const CAT = "windows_adk_etl";
  const ST = [
    { id: "data", n: 1, short: "Understand the data", who: "Windows ADK · ETL and XML", title: "Understand the data",
      text: "Every run and iteration of the folder, found by what the files hold (not by their names): the assessment's timing XML gives the Fast Startup time, each trace (.etl) is decoded with xperf into tables (processes, disk commands, file I/O operations, every event type). A run is PASS when the mean Fast Startup time of its iterations is within the limit, else FAIL. Every run is stored: the PASS runs make the benchmark." },
    { id: "tree", n: 2, short: "One tree", who: "Not needed for Windows ADK", title: "One tree",
      text: "Not needed for Windows ADK: each run is analysed by itself and its traces are decoded into tables on page 1." },
    { id: "rules", n: 3, short: "Rules, defects, test cases", who: "Windows ADK ETL analytics", title: "Windows ADK ETL analytics",
      text: "The benchmark is the PASS runs pooled (each run averaged over its iterations, then over the runs). Compare puts a run against it: which phase took longer, and in each category (pre-logon, logon screen, post-logon) which processes added time, and inside each process which commands (DiskRead, DiskWrite, DiskFlush and file I/O operations) and which files. The summary is written by the program; with a model connected, the model's summary is added, every number checked against the comparison." },
    { id: "report", n: 4, short: "Report", who: "Windows ADK", title: "Report",
      text: "Every run with its verdict, and the summary of each comparison, with the CSV exports." },
  ];
  const CATS = [["all", "Whole trace"], ["pre_logon", "Pre-logon"], ["logon", "Logon screen"], ["post_logon", "Post-logon"]];
  const CATW = { pre_logon: "pre-logon", logon: "logon screen", post_logon: "post-logon", all: "whole trace" };
  const A = { pid: null, inv: null, invFolder: null, runs: [], job: null, status: null, bench: null, scope: "project", cmp: {}, sel: null,
              tab: "all", open: {}, runDetail: {}, timer: null, busy: "",
              h: { cmd: "", proc: "", scale: "lin", range: "1ms", adhoc: null }, hist: {},     // the latency histogram's selection, and its answers
              ac: { sort: "added", open: {}, data: {}, obj: {} } };                          // every command under each process
  const ms = us => us === null || us === undefined ? "-" : (us / 1000).toLocaleString(undefined, { maximumFractionDigits: 1 });
  const n1 = x => x === null || x === undefined || x === "" ? "-" : Number(x).toLocaleString(undefined, { maximumFractionDigits: 1 });
  const sgn = x => x === null || x === undefined ? "-" : (x > 0 ? "+" : "") + n1(x);
  const pct = x => x === null || x === undefined ? "" : ` (${x > 0 ? "+" : ""}${n1(x)}%)`;
  const dcls = x => x > 0 ? "err" : x < 0 ? "ok-t" : "";
  const verdictPill = v => v === "PASS" ? `<span class="pill ok">PASS</span>` : v === "FAIL" ? `<span class="pill bad">FAIL</span>` : `<span class="pill">${esc(v || "not analysed")}</span>`;

  async function load(p, force) {
    if (A.pid !== p.id) Object.assign(A, { pid: p.id, inv: null, invFolder: null, cmp: {}, sel: null, runDetail: {}, bench: null, job: null });
    const jobs = [];
    jobs.push(api("GET", "/api/adk/runs?project=" + p.id).then(r => A.runs = r));
    if (!A.status || force) jobs.push(api("GET", "/api/adk/status").then(r => A.status = r));
    if (!A.inv || A.invFolder !== p.folder || force) jobs.push(api("GET", "/api/adk/inventory?folder=" + encodeURIComponent(p.folder)).then(r => { A.inv = r; A.invFolder = p.folder; }).catch(e => { A.inv = { errors: [e.message], runs: [] }; }));
    jobs.push(api("GET", "/api/adk/jobs?project=" + p.id).then(js => { A.job = (js || []).find(j => j.state === "running" || j.state === "queued") || (A.job && A.job.state !== "done" && A.job.state !== "failed" ? A.job : (js || [])[0] || null); }));
    await Promise.all(jobs);
    if (!A.bench || force) A.bench = await api("GET", `/api/adk/benchmark?project=${p.id}&scope=${A.scope}`);
  }
  function stagesState() {
    const analysed = A.runs.filter(r => r.status === "done").length, running = A.job && (A.job.state === "running" || A.job.state === "queued");
    const compared = Object.keys(A.cmp).length || A.runs.some(r => r._compared);
    return {
      data: running ? "active" : analysed ? "done" : (A.job && A.job.state === "failed") ? "fail" : "waiting",
      tree: analysed ? "done" : "waiting",
      rules: analysed ? (compared ? "done" : "active") : "waiting",
      report: analysed ? "active" : "waiting",
    };
  }
  function stepper(pid, cur) {
    const s = stagesState();
    return `<nav class="stepper" aria-label="the stages">` + ST.map(st => {
      const x = s[st.id], reached = st.id === "data" || x !== "waiting";
      const sub = st.id === "tree" ? "not needed" : { done: "done", active: st.id === "data" ? "working" : "ready", fail: "failed", waiting: "not yet" }[x];
      const num = x === "done" ? IC.check : x === "fail" ? IC.x : x === "active" && st.id === "data" ? `<span class="spin"></span>` : st.n;
      return `<button class="stg ${x} ${st.id === cur ? "cur" : ""}" data-act="stage" data-pid="${pid}" data-stage="${st.id}" ${reached ? "" : "disabled"} title="${esc(st.who)}"><span class="num">${num}</span><span class="txt"><div class="t">${st.n} · ${esc(st.short)}</div><div class="s">${esc(sub)}</div></span></button>`;
    }).join("") + `</nav>`;
  }

  // ---------------------------------------------------------------- page 1
  function jobView() {
    const j = A.job; if (!j) return "";
    if (j.state === "running" || j.state === "queued") return `<div class="working"><span class="spin"></span><div class="grow"><b>Analysing the runs</b><div class="note">${esc(j.note || "")} · ${n1(j.pct || 0)} %</div>
      <div style="height:6px;background:var(--surface-2);border-radius:4px;margin-top:6px"><div style="height:6px;width:${Math.max(2, j.pct || 0)}%;background:var(--accent);border-radius:4px"></div></div></div></div>`;
    if (j.state === "failed") return `<div class="banner bad"><span>The analysis failed: ${esc((j.error || "").slice(0, 400))}</span><button class="btn small" data-adk="analyze">Run it again</button></div>`;
    return "";
  }
  function invView() {
    const v = A.inv || {};
    if ((v.errors || []).length) return `<p class="err">${esc(v.errors.join("; "))}</p>`;
    const rows = (v.runs || []).map(r => `<tr><td><b>${esc(r.label)}</b><div class="tiny muted">${esc(r.run_dir)}</div></td><td>${r.iterations}</td><td>${r.with_trace}</td><td>${r.with_xml}</td><td>${r.extra_traces}</td>
      <td class="small">${(r.problems || []).map(esc).join("<br>") || "-"}${r.ignored ? `<div class="tiny muted">${r.ignored} duplicate file(s) left out</div>` : ""}</td></tr>`).join("");
    const other = Object.entries(v.other_files || {}).map(([k, c]) => `${c} ${esc(k)}`).join(", ");
    return `<p class="small muted" style="margin:0 0 6px">${n1(v.etl_files)} trace(s) (.etl), ${n1(v.xml_files)} XML file(s)${other ? `; other files: ${other}` : ""}. Found in ${n1(v.seconds)} s.</p>
      <div class="tbl"><table><tr><th>Run</th><th>Iterations</th><th>With trace</th><th>With timing XML</th><th>Other traces (IO, analysis, verbose)</th><th>Said about the files</th></tr>${rows}</table></div>`;
  }
  function runsTable(withActions) {
    if (!A.runs.length) return `<div class="empty">No run analysed yet.</div>`;
    const lim = A.status ? A.status.limit_ms : 14000;
    return `<div class="tbl"><table><tr><th>Run</th><th>Verdict</th><th>Mean Fast Startup</th><th>Iterations (traced)</th><th>Time taken from</th><th>In the benchmark</th>${withActions ? "<th></th>" : ""}</tr>` +
      A.runs.map(r => `<tr><td><b>${esc(r.label)}</b>${r.status !== "done" ? ` <span class="pill ${r.status === "failed" ? "bad" : "run"}">${esc(r.status)}</span>` : ""}${r.error ? `<div class="err">${esc(r.error.slice(0, 300))}</div>` : ""}</td>
        <td>${verdictPill(r.verdict)}</td><td>${n1(r.boot_mean_ms)} ms <span class="tiny muted">limit ${n1(r.limit_ms || lim)}</span>${r.info && r.info.boot_values ? `<div class="tiny muted">${r.info.boot_values.map(n1).join(" · ")}</div>` : ""}</td>
        <td>${n1(r.iterations)} (${n1(r.traced)})</td><td class="small">${esc(r.boot_source || "-")}</td>
        <td>${r.verdict === "PASS" ? `<label class="small"><input type="checkbox" data-adk="bench" data-rid="${r.id}" ${r.in_benchmark ? "checked" : ""}> ${r.in_benchmark ? "yes" : "no"}</label>` : `<span class="tiny muted">only PASS runs</span>`}</td>
        ${withActions ? `<td style="white-space:nowrap"><button class="btn small ${r.verdict === "FAIL" ? "primary" : ""}" data-adk="compare" data-rid="${r.id}">Compare</button> <button class="btn small quiet" data-adk="detail" data-rid="${r.id}">Iterations</button> <button class="btn small quiet danger" data-adk="del" data-rid="${r.id}">Delete</button></td>` : ""}</tr>
        ${A.open["d" + r.id] ? `<tr><td colspan="7">${detailView(r.id)}</td></tr>` : ""}`).join("") + `</table></div>`;
  }
  function detailView(rid) {
    const d = A.runDetail[rid];
    if (!d) return `<p class="small muted">loading…</p>`;
    const its = d.iterations.map(it => `<tr><td>${it.n}</td><td>${n1(it.boot_ms)} ms<div class="tiny muted">${esc(it.boot_source || "")}</div></td>
      <td class="small">${it.milestones_ms ? Object.entries(it.milestones_ms).map(([k, v]) => `${esc(k)} ${n1(v)}`).join(" · ") : "-"}</td>
      <td class="small">${it.category_ms ? Object.entries(it.category_ms).map(([k, v]) => `${esc(CATW[k] || k)} ${n1(v)} ms`).join("<br>") : "-"}</td>
      <td class="small">${it.counts ? `${n1(it.counts.disk_commands)} disk commands · ${n1(it.counts.file_commands)} file ops · ${n1(it.counts.event_types)} event types` : "-"}</td>
      <td class="small">${(it.tables || []).map(t => `<a href="/api/adk/runs/${rid}/iterations/${it.n}/${t}.csv">${esc(t)}.csv</a>`).join(" · ") || "-"}</td>
      <td class="tiny">${(it.notes || []).map(esc).join("<br>")}<div class="muted">${esc(it.etl ? it.etl.split(/[\\/]/).pop() : "no trace")} · ${esc(it.xml ? it.xml.split(/[\\/]/).pop() : "no XML")}</div></td></tr>`).join("");
    return `<div class="lbl2">Iterations of ${esc(d.run.label)}</div><div class="tbl"><table><tr><th>#</th><th>Fast Startup</th><th>Milestones (ms from trace start)</th><th>Categories</th><th>Decoded</th><th>Tables (CSV)</th><th>Notes / files</th></tr>${its}</table></div>
      ${(d.run.notes || []).length ? `<p class="small err">${d.run.notes.map(esc).join("<br>")}</p>` : ""}`;
  }
  function page1(p) {
    const st = A.status || {};
    let h = "";
    if (st && !st.xperf_found) h += `<div class="banner bad"><span>${esc(st.why_no_xperf || "xperf not found")}</span></div>`;
    h += jobView();
    h += `<section class="card"><div class="row" style="justify-content:space-between"><h2>Runs found in the folder</h2><span class="row"><button class="btn small quiet" data-adk="rescan">Look again</button>
        <button class="btn primary" data-adk="analyze" ${A.job && (A.job.state === "running" || A.job.state === "queued") ? "disabled" : ""}>${IC.play}${A.runs.length ? "Analyse again" : "Analyse every run"}</button></span></div>
      <p class="small muted">${esc(st.xperf ? "xperf: " + st.xperf : "")}. PASS when the mean Fast Startup time of a run's iterations is at most <b>${n1(st.limit_ms)} ms</b>. A trace decoded once is never decoded again (also a copy under another name).</p>${invView()}</section>`;
    h += `<div class="sectionhead">Runs analysed and stored</div><section class="card">${runsTable(true)}</section>`;
    return h;
  }

  // ---------------------------------------------------------------- page 3
  function benchView() {
    const b = A.bench || {};
    const sc = `<span class="row small"><label><input type="radio" name="adk-scope" data-adk="scope" value="project" ${A.scope === "project" ? "checked" : ""}> PASS runs of this analysis</label>
      <label><input type="radio" name="adk-scope" data-adk="scope" value="all" ${A.scope === "all" ? "checked" : ""}> PASS runs of every analysis</label></span>`;
    if (!b.n_runs) return `<section class="card"><div class="row" style="justify-content:space-between"><h2>Benchmark</h2>${sc}</div><p class="err">No PASS run in the benchmark yet. Analyse runs whose mean Fast Startup time is within the limit (on page 1), or choose "every analysis".</p></section>`;
    const ph = (b.phases || []).map(x => `<tr><td>${esc(x.phase)}</td><td>${esc(CATW[x.category] || x.category)}</td><td>${n1(x.mean_ms)}</td><td>${n1(x.std_ms)}</td><td>${x.runs}</td></tr>`).join("");
    const tp = (b.top_processes || []).slice(0, 12).map(x => `<tr><td>${esc(x.process)}</td><td>${ms(x.disk_us)}</td></tr>`).join("");
    return `<section class="card"><div class="row" style="justify-content:space-between"><h2>Benchmark · ${b.n_runs} PASS run(s)</h2>${sc}</div>
      <div class="tiles" style="margin-top:10px"><div class="tile"><div class="v">${n1(b.boot_mean_ms)} ms</div><div class="l">mean Fast Startup time (std ${n1(b.boot_std_ms)} ms over the runs)</div></div>
      ${Object.entries(b.category_ms || {}).map(([k, v]) => `<div class="tile"><div class="v">${n1(v)} ms</div><div class="l">${esc(CATW[k] || k)}</div></div>`).join("")}</div>
      <details class="more" data-id="adk-bench-more"><summary>${IC.chev}Phases and the processes with the most disk I/O time in the benchmark</summary>
        <div class="grid2" style="margin-top:8px"><div class="tbl"><table><tr><th>Phase</th><th>Category</th><th>Mean ms</th><th>Std ms</th><th>Runs</th></tr>${ph}</table></div>
        <div class="tbl"><table><tr><th>Process</th><th>Disk I/O ms per boot</th></tr>${tp}</table></div></div>
        <p class="small muted">Runs: ${(b.runs || []).map(r => esc(r.label) + " (" + n1(r.boot_mean_ms) + " ms)").join(", ")}</p></details></section>`;
  }
  function cmpView(res) {
    if (!res) return "";
    if (res.error && !res.phases) return `<section class="card"><p class="err">${esc(res.error)}</p></section>`;
    const sm = res.summary || {};
    const r = res.run || {}, bo = res.boot || {};
    let h = `<section class="card"><div class="row" style="justify-content:space-between"><h2>${esc(r.label)} ${verdictPill(r.verdict)} against the benchmark</h2>
      <span class="row"><a class="btn small" href="/api/adk/runs/${r.id}/compare.csv?level=process">${IC.ext}Processes CSV</a><a class="btn small" href="/api/adk/runs/${r.id}/compare.csv?level=command">${IC.ext}Commands CSV</a><a class="btn small" href="/api/adk/runs/${r.id}/compare.csv?level=file">${IC.ext}Files CSV</a><a class="btn small" href="/api/adk/runs/${r.id}/compare.csv?level=phase">${IC.ext}Phases CSV</a><a class="btn small" href="/api/adk/runs/${r.id}/compare.csv?level=event">${IC.ext}Events CSV</a></span></div>
      <div class="tiles" style="margin-top:10px"><div class="tile"><div class="v">${n1(r.boot_mean_ms)} ms</div><div class="l">mean Fast Startup of this run (${r.iterations} iteration(s), ${r.traced} traced)</div></div>
        <div class="tile"><div class="v">${n1(bo.bench_ms)} ms</div><div class="l">benchmark (${res.benchmark.n_runs} PASS run(s), ${esc(res.benchmark.scope)})</div></div>
        <div class="tile"><div class="v ${dcls(bo.delta_ms)}">${sgn(bo.delta_ms)} ms</div><div class="l">difference${pct(bo.delta_pct)}</div></div></div>
      ${res.note ? `<p class="err">${esc(res.note)}</p>` : ""}
      <div class="lbl2" style="margin-top:14px">Summary · written by ${esc(sm.by || "the program")}</div>
      ${sm.model_text ? `<div class="md" style="white-space:pre-wrap">${esc(sm.model_text)}</div>` : ""}
      ${(sm.findings || []).length ? `<ul>${sm.findings.map(f => `<li><b>${esc(f.title || "")}</b> ${esc(f.detail || "")}${f.category ? ` <span class="tiny muted">${esc(f.category)}</span>` : ""}</li>`).join("")}</ul>` : ""}
      ${(sm.likely_causes || []).length ? `<div class="small"><b>Likely causes (hypotheses):</b> ${sm.likely_causes.map(esc).join(" · ")}</div>` : ""}
      ${(sm.unchecked || []).length ? `<details class="more" data-id="adk-unchecked"><summary>${IC.chev}${sm.unchecked.length} sentence(s) of the model left out: a number not in the comparison</summary><div class="small muted">${sm.unchecked.map(x => esc(typeof x === "string" ? x : JSON.stringify(x))).join("<br>")}</div></details>` : ""}
      <details class="more" data-id="adk-written" ${sm.model_text ? "" : "open"}><summary>${IC.chev}The summary written by the program</summary><div class="small" style="white-space:pre-wrap;margin-top:6px">${esc(sm.text || "")}</div></details>
      ${sm.model_error ? `<p class="tiny muted">The model was not used: ${esc(sm.model_error)}</p>` : ""}</section>`;
    h += `<section class="card"><h2>Categories and phases</h2><div class="grid2"><div class="tbl"><table><tr><th>Category</th><th>Run ms</th><th>Benchmark ms</th><th>Δ ms</th><th>Disk I/O run ms</th><th>Disk I/O bench ms</th><th>Δ disk I/O ms</th></tr>
      ${(res.categories || []).map(c => `<tr><td><b>${esc(CATW[c.category] || c.category)}</b></td><td>${n1(c.run_ms)}</td><td>${n1(c.bench_ms)}</td><td class="${dcls(c.delta_ms)}">${sgn(c.delta_ms)}</td><td>${n1(c.run_disk_io_ms)}</td><td>${n1(c.bench_disk_io_ms)}</td><td class="${dcls(c.delta_disk_io_ms)}">${sgn(c.delta_disk_io_ms)}</td></tr>`).join("")}</table></div>
      <div class="tbl"><table><tr><th>Phase</th><th>Category</th><th>Run ms</th><th>Benchmark ms</th><th>Δ ms</th></tr>
      ${(res.phases || []).map(x => `<tr><td>${esc(x.phase)}</td><td>${esc(CATW[x.category] || x.category)}</td><td>${n1(x.run_ms)}</td><td>${n1(x.bench_ms)}${x.bench_std_ms ? ` <span class="tiny muted">±${n1(x.bench_std_ms)}</span>` : ""}</td><td class="${dcls(x.delta_ms)}">${sgn(x.delta_ms)}${pct(x.delta_pct)}</td></tr>`).join("")}</table></div></div></section>`;
    const procs = (res.by_category || {})[A.tab] || [];
    h += `<section class="card"><div class="row" style="justify-content:space-between"><h2>Which process, and inside it which command, took more time</h2>
      <span class="row">${CATS.map(([k, w]) => `<button class="btn small ${A.tab === k ? "primary" : ""}" data-adk="tab" data-tab="${k}">${esc(w)}</button>`).join("")}</span></div>
      <p class="small muted">Per boot (each run averaged over its traced iterations). Disk I/O time = time from the disk command's start to its completion (queue + device), summed. Click a process for its commands; a command for its files. Sorted by the time added compared with the benchmark.</p>
      <div class="tbl"><table><tr><th>#</th><th>Process</th><th>Disk I/O run ms</th><th>Benchmark ms</th><th>Δ ms</th><th>Disk commands run / bench</th><th>File I/O Δ ms</th></tr>
      ${procs.map((p, i) => { const key = A.tab + "|" + p.process, open = A.open[key];
        return `<tr data-adk="proc" data-key="${esc(key)}" style="cursor:pointer"><td>${i + 1}</td><td><b>${esc(p.process)}</b>${p.new ? ` <span class="pill warn">not in the PASS runs</span>` : ""}</td><td>${ms(p.run_disk_us)}</td><td>${ms(p.bench_disk_us)}</td>
          <td class="${dcls(p.delta_disk_us)}"><b>${sgn(p.delta_disk_us / 1000)}</b>${pct(p.delta_pct)}</td><td>${n1(p.run_count)} / ${n1(p.bench_count)}</td><td class="${dcls(p.delta_file_us)}">${p.run_file_us || p.bench_file_us ? sgn(p.delta_file_us / 1000) : "-"}</td></tr>
          ${open ? `<tr><td></td><td colspan="6">${cmdTable(p, key)}</td></tr>` : ""}`; }).join("")}</table></div></section>`;
    h += allCmdCard(res);
    h += histCard(res);
    h += `<div class="grid2"><section class="card"><h2>Event types that changed most</h2><p class="small muted">Every event type of the traces, counted per process and per boot (SampledProfile = CPU samples, about one per millisecond).</p>
      <div class="tbl" style="max-height:420px;overflow:auto"><table><tr><th>Process</th><th>Event</th><th>Category</th><th>Run</th><th>Bench</th><th>Δ</th></tr>
      ${(res.events || []).slice(0, 40).map(e => `<tr><td>${esc(e.process)}</td><td>${esc(e.event)}</td><td>${esc(CATW[e.category] || e.category)}</td><td>${n1(e.run)}</td><td>${n1(e.bench)}</td><td class="${dcls(e.delta)}">${sgn(e.delta)}</td></tr>`).join("")}</table></div></section>
      <section class="card"><h2>Processes</h2><div class="lbl2">Not in the PASS runs (${(res.new_processes || []).length})</div><div class="small">${(res.new_processes || []).map(p => `${esc(p.process)} <span class="tiny muted">${esc(CATW[p.category] || p.category || "")} ${p.first_start_ms !== null ? "@" + n1(p.first_start_ms) + " ms" : ""}</span>`).join(" · ") || "-"}</div>
      <div class="lbl2" style="margin-top:10px">In most PASS runs, missing here (${(res.missing_processes || []).length})</div><div class="small">${(res.missing_processes || []).map(p => esc(p.process)).join(" · ") || "-"}</div>
      <div class="lbl2" style="margin-top:10px">Lived longer than in the benchmark</div><div class="tbl"><table><tr><th>Process</th><th>Run ms</th><th>Bench ms</th><th>Δ ms</th></tr>${(res.lifetimes || []).filter(x => x.delta_ms > 0).slice(0, 12).map(x => `<tr><td>${esc(x.process)}</td><td>${n1(x.run_ms)}</td><td>${n1(x.bench_ms)}</td><td class="err">${sgn(x.delta_ms)}</td></tr>`).join("")}</table></div>
      ${(res.xml || []).length ? `<div class="lbl2" style="margin-top:10px">Assessment XML numbers that grew</div><div class="tbl"><table><tr><th>Kind</th><th>Name</th><th>Measure</th><th>Run</th><th>Bench</th><th>Δ</th></tr>${res.xml.slice(0, 12).map(x => `<tr><td>${esc(x.kind)}</td><td>${esc(x.name)}</td><td>${esc(x.measure)}</td><td>${n1(x.run)}</td><td>${n1(x.bench)}</td><td class="${dcls(x.delta)}">${sgn(x.delta)}</td></tr>`).join("")}</table></div>` : ""}</section></div>`;
    return h;
  }
  function cmdTable(p, key) {
    return `<div class="tbl"><table><tr><th>Command</th><th>Run ms</th><th>Bench ms</th><th>Δ ms</th><th>Count run / bench</th><th>Mean µs run / bench</th><th>Max µs run / bench</th></tr>
      ${p.commands.map(c => { const k2 = key + "|" + c.source + "|" + c.command, open = A.open[k2];
        return `<tr data-adk="cmd" data-key="${esc(k2)}" style="cursor:pointer"><td><b>${esc(c.command)}</b> <span class="tiny muted">${esc(c.source)}</span>
          <button class="btn small quiet" data-adk="hshow" data-proc="${esc(p.process)}" data-cmd="${esc(c.source + "|" + c.command)}" title="its latency, in ${esc(String(hsOf().width))} µs buckets, against the benchmark">latency</button></td><td>${ms(c.run_us)}</td><td>${ms(c.bench_us)}</td><td class="${dcls(c.delta_us)}"><b>${sgn(c.delta_us / 1000)}</b>${pct(c.delta_pct)}</td>
          <td>${n1(c.run_count)} / ${n1(c.bench_count)}</td><td>${n1(c.run_mean_us)} / ${n1(c.bench_mean_us)}</td><td>${n1(c.run_max_us)} / ${n1(c.bench_max_us)}</td></tr>
          ${open ? `<tr><td colspan="7"><div class="tbl"><table><tr><th>File</th><th>Run ms</th><th>Bench ms</th><th>Δ ms</th><th>Count run</th></tr>${(c.files || []).map(f => `<tr><td class="small">${esc(f.file)}</td><td>${ms(f.run_us)}</td><td>${ms(f.bench_us)}</td><td class="${dcls(f.delta_us)}">${sgn(f.delta_us / 1000)}</td><td>${n1(f.run_count)}</td></tr>`).join("")}</table></div></td></tr>` : ""}`; }).join("")}</table></div>`;
  }
  // ---------------------------------------------------------------- every command under each process (owner, 2026-11-24: "all types of
  // commands under each .exe, all those under an ETL"): process > its commands (time, count, what the time is) > their objects
  const srcOf = cmd => /^Disk(Read|Write|Flush)$/.test(cmd) ? "disk" : /^FileIo/.test(cmd) ? "file" : "event";
  const msOf = us => us === null || us === undefined ? "-" : n1(us / 1000) + " ms";
  function acFetch(url, store, key) {
    if (store[key]) return store[key];
    store[key] = { loading: true };
    api("GET", url).then(x => { store[key] = x; redraw(false); }).catch(e => { store[key] = { error: e.message }; redraw(false); });
    return store[key];
  }
  function allCmdCard(res) {
    const rid = res.run.id, scope = res.scope || A.scope;
    const list = ((A.ac.sort === "longest" ? res.all_commands_longest : res.all_commands) || {})[A.tab] || [];
    let rows = "";
    list.forEach((p, i) => {
      const key = `${A.tab}|${p.process}`, open = A.ac.open[key];
      rows += `<tr data-adk="acproc" data-key="${esc(key)}" style="cursor:pointer"><td>${i + 1}</td><td><b>${esc(p.process)}</b>${p.new ? ` <span class="pill warn">not in the PASS runs</span>` : ""}</td><td>${n1(p.n_commands)}</td>
        <td class="small">${p.top_command ? `${esc(p.top_command)} <b class="${dcls(p.top_delta_us)}">${p.top_delta_us === null ? "" : sgn(p.top_delta_us / 1000) + " ms"}</b>${p.top_recorded_in_bench ? "" : ` <span class="pill">not recorded in the PASS traces</span>`}` : "-"}</td>
        <td class="small">${p.top_run_command ? `${esc(p.top_run_command)} <b>${msOf(p.top_run_us)}</b>` : "-"}</td></tr>`;
      if (open) rows += `<tr><td></td><td colspan="4">${acProcess(rid, scope, p.process)}</td></tr>`;
    });
    return `<section class="card" id="adk-allcmd"><div class="row" style="justify-content:space-between"><h2>Every command under each process</h2>
        <span class="row"><button class="btn small ${A.ac.sort === "added" ? "primary" : ""}" data-adk="acsort" data-v="added">Time added vs PASS</button><button class="btn small ${A.ac.sort === "longest" ? "primary" : ""}" data-adk="acsort" data-v="longest">Longest in this run</button>
        <a class="btn small" href="/api/adk/runs/${rid}/compare.csv?level=all_commands">${IC.ext}CSV</a></span></div>
      <p class="small muted">${esc(CATW[A.tab])}, per boot. Every kind of event a process caused in the trace: disk and file I/O, page faults (HardFault), CPU (run time from context switches; sampled CPU per module), waits by reason, processes and threads it started, DLLs it loaded, and every Windows component that logs a begin and an end (Code Integrity, PnP driver init and device start, service start, Prefetch, Shell ...). "What the time is" says where each time comes from; lifetimes overlap and are listed after the costs. A command the PASS traces did not record at all is marked: it cannot be compared. Click a process for all its commands, a command for its files / DLLs / drivers / services / modules.</p>
      ${res.all_commands_note ? `<p class="err">${esc(res.all_commands_note)}</p>` : ""}
      <div class="tbl"><table><tr><th>#</th><th>Process</th><th>Commands</th><th>Command that added most time vs PASS</th><th>Longest command in this run</th></tr>${rows || `<tr><td colspan="5" class="muted">No command in this category.</td></tr>`}</table></div></section>`;
  }
  function acProcess(rid, scope, proc) {
    const key = `${rid}|${A.tab}|${proc}|${scope}`;
    const d = acFetch(`/api/adk/runs/${rid}/commands?category=${encodeURIComponent(A.tab)}&process=${encodeURIComponent(proc)}&scope=${encodeURIComponent(scope)}`, A.ac.data, key);
    if (d.loading) return `<p class="small muted">reading every command of ${esc(proc)}…</p>`;
    if (d.error) return `<p class="err">${esc(d.error)}</p>`;
    const p = (d.processes || [])[0];
    if (!p) return `<p class="small muted">${esc(d.note || "no command")}</p>`;
    return `<div class="tbl"><table><tr><th>Command</th><th>What the time is</th><th>Count run / PASS</th><th>Time run / PASS</th><th>Δ time</th><th>Mean run / PASS</th><th>Max run</th></tr>
      ${p.commands.map(c => { const k2 = `${key}|${c.command}`, open = A.ac.open[k2];
        const lat = c.timed && !c.lifetime && !/^CPU /.test(c.command);
        return `<tr data-adk="accmd" data-key="${esc(k2)}" style="cursor:pointer"><td><b>${esc(c.command)}</b>${c.recorded_in_bench ? "" : ` <span class="pill">not recorded in the PASS traces</span>`}${c.new && c.recorded_in_bench ? ` <span class="pill warn">new</span>` : ""}
            ${lat ? `<button class="btn small quiet" data-adk="hshow" data-proc="${esc(proc)}" data-cmd="${esc(srcOf(c.command) + "|" + c.command)}" data-adhoc="1">latency</button>` : ""}</td>
          <td class="tiny">${esc(c.basis || "")}</td><td>${n1(c.run_count)} / ${n1(c.bench_count)}</td><td>${c.timed ? `${msOf(c.run_us)} / ${msOf(c.bench_us)}` : "-"}</td>
          <td class="${dcls(c.delta_us)}">${c.delta_us === null ? (c.delta_count ? sgn(c.delta_count) + " times" : "-") : sgn(c.delta_us / 1000) + " ms"}${pct(c.delta_pct)}</td>
          <td>${c.timed ? `${n1(c.run_mean_us)} / ${n1(c.bench_mean_us)} µs` : "-"}</td><td>${c.timed ? n1(c.run_max_us) + " µs" : "-"}</td></tr>
          ${open ? `<tr><td colspan="7">${acObjects(rid, scope, proc, c.command, c.timed)}</td></tr>` : ""}`; }).join("")}</table></div>`;
  }
  function acObjects(rid, scope, proc, cmd, timed) {
    const key = `${rid}|${A.tab}|${proc}|${cmd}|${scope}`;
    const d = acFetch(`/api/adk/runs/${rid}/commands/objects?category=${encodeURIComponent(A.tab)}&process=${encodeURIComponent(proc)}&command=${encodeURIComponent(cmd)}&scope=${encodeURIComponent(scope)}`, A.ac.obj, key);
    if (d.loading) return `<p class="small muted">reading…</p>`;
    if (d.error) return `<p class="err">${esc(d.error)}</p>`;
    if (!(d.objects || []).length) return `<p class="small muted">This command names no file, DLL, driver, service or module.</p>`;
    return `<div class="tbl"><table><tr><th>File / DLL / driver / service / module / command line / wait reason</th><th>Count run / PASS</th>${timed ? "<th>Time run / PASS</th><th>Δ time</th><th>Max run</th>" : "<th>Δ count</th>"}</tr>
      ${d.objects.map(o => `<tr><td class="small">${esc(o.object)}</td><td>${n1(o.run_count)} / ${n1(o.bench_count)}</td>${timed ? `<td>${msOf(o.run_us)} / ${msOf(o.bench_us)}</td><td class="${dcls(o.delta_us)}">${sgn((o.delta_us || 0) / 1000)} ms</td><td>${n1(o.run_max_us)} µs</td>` : `<td class="${dcls(o.delta_count)}">${sgn(o.delta_count)}</td>`}</tr>`).join("")}</table></div>`;
  }

  // ---------------------------------------------------------------- the I/O latency histogram (owner, 2026-11-24: "for each and every
  // five microseconds, how many commands are coming, especially for I/O"): one bucket per 5 µs, the run against the benchmark
  function hsOf(res) { return (res && res.histogram_settings) || (A.status && A.status.histogram) || { width: 5, fine_max: 10000 }; }
  const usTxt = us => us >= 1000 ? `${n1(us / 1000)} ms` : `${n1(us)} µs`;
  function histChoices(res) {
    const lat = ((res.latency || {})[A.tab] || []).filter(x => (x.run && x.run.count) || (x.bench && x.bench.count));
    const ad = A.h.adhoc && A.h.adhoc.tab === A.tab ? A.h.adhoc : null;      // a command chosen in "Every command under each process"
    if (ad) {
      const [s, c] = ad.cmd.split(/\|(.*)/s);
      if (!lat.some(x => x.source + "|" + x.command === ad.cmd)) lat.push({ source: s, command: c, adhoc: true, run: {}, bench: {} });
      return { lat, cmd: ad.cmd };
    }
    if (!lat.length) return { lat, cmd: "" };
    let cmd = A.h.cmd;
    if (!lat.some(x => x.source + "|" + x.command === cmd)) {
      const pref = lat.find(x => x.command === "DiskRead") || lat[0];
      cmd = pref.source + "|" + pref.command;
    }
    return { lat, cmd };
  }
  function histCard(res) {
    const hs = hsOf(res), { lat, cmd } = histChoices(res);
    if (!lat.length) return `<section class="card"><h2>I/O latency · commands per ${hs.width} µs</h2><p class="small muted">No I/O command in this category.</p></section>`;
    A.h.cmd = cmd;
    const procs = ((res.by_category || {})[A.tab] || []).map(p => p.process);
    if (A.h.adhoc && A.h.proc && !procs.includes(A.h.proc)) procs.unshift(A.h.proc);
    if (A.h.proc && !procs.includes(A.h.proc)) A.h.proc = "";
    const [source, command] = cmd.split(/\|(.*)/s);
    const rid = res.run.id;
    const q = `category=${encodeURIComponent(A.tab)}&command=${encodeURIComponent(command)}&source=${encodeURIComponent(source)}&process=${encodeURIComponent(A.h.proc)}&scope=${encodeURIComponent(res.scope || A.scope)}`;
    const key = rid + "?" + q;
    let d = A.hist[key];
    if (!d) {
      A.hist[key] = d = { loading: true };
      api("GET", `/api/adk/runs/${rid}/histogram?${q}`).then(x => { A.hist[key] = x; redraw(false); }).catch(e => { A.hist[key] = { error: e.message }; redraw(false); });
    }
    const st = lat.filter(x => !x.adhoc).map(x => `<tr ${x.source + "|" + x.command === cmd ? `style="background:var(--accent-soft)"` : ""}><td><b>${esc(x.command)}</b> <span class="tiny muted">${esc(x.source)}</span></td>
      <td>${n1(x.run.count)} / ${n1(x.bench.count)}</td><td>${n1(x.run.p50_us)} / ${n1(x.bench.p50_us)}</td><td>${n1(x.run.p90_us)} / ${n1(x.bench.p90_us)}</td>
      <td class="${dcls((x.run.p99_us || 0) - (x.bench.p99_us || 0))}">${n1(x.run.p99_us)} / ${n1(x.bench.p99_us)}</td><td>${n1(x.run.mean_us)} / ${n1(x.bench.mean_us)}</td>
      <td>${n1((x.above_1ms_pct || {}).run)} / ${n1((x.above_1ms_pct || {}).bench)}</td><td class="${dcls(((x.above_10ms_pct || {}).run || 0) - ((x.above_10ms_pct || {}).bench || 0))}">${n1((x.above_10ms_pct || {}).run)} / ${n1((x.above_10ms_pct || {}).bench)}</td></tr>`).join("");
    const ranges = [["1ms", "0 – 1 ms"], ["10ms", `0 – ${usTxt(hs.fine_max || 10000)}`], ["tail", `≥ ${usTxt(hs.fine_max || 10000)}`]];
    let chart;
    if (d.loading) chart = `<p class="small muted">reading the buckets…</p>`;
    else if (d.error) chart = `<p class="err">${esc(d.error)}</p>`;
    else chart = histSvg(d, hs) + histGrew(d);
    return `<section class="card" id="adk-hist"><div class="row" style="justify-content:space-between"><h2>I/O latency · how many commands in each ${hs.width} µs</h2>
        <a class="btn small" href="/api/adk/runs/${rid}/histogram.csv?${q}">${IC.ext}Histogram CSV</a></div>
      <p class="small muted">${esc(CATW[A.tab])}, ${esc(A.h.proc || "all processes")}, per boot. Latency = a disk command's IO time (issue to completion); a file operation's duration. ${hs.width} µs buckets ${hs.fine_max ? `up to ${esc(usTxt(hs.fine_max))}, doubling buckets above` : "everywhere"}. The category follows the tabs above.</p>
      <div class="tbl"><table><tr><th>Command (all processes)</th><th>Commands run / bench</th><th>p50 µs</th><th>p90 µs</th><th>p99 µs</th><th>Mean µs</th><th>&gt; 1 ms %</th><th>&gt; 10 ms %</th></tr>${st}</table></div>
      <div class="row" style="margin:10px 0 6px;gap:14px">
        <label class="small">Command <select data-adk="hcmd">${lat.map(x => `<option value="${esc(x.source + "|" + x.command)}" ${x.source + "|" + x.command === cmd ? "selected" : ""}>${esc(x.command)} (${esc(x.source)})</option>`).join("")}</select></label>
        <label class="small">Process <select data-adk="hproc"><option value="">All processes</option>${procs.map(p => `<option value="${esc(p)}" ${p === A.h.proc ? "selected" : ""}>${esc(p)}</option>`).join("")}</select></label>
        <span class="row">${ranges.map(([k, w]) => `<button class="btn small ${A.h.range === k ? "primary" : ""}" data-adk="hrange" data-v="${k}">${esc(w)}</button>`).join("")}</span>
        <span class="row"><button class="btn small ${A.h.scale === "lin" ? "primary" : ""}" data-adk="hscale" data-v="lin">linear</button><button class="btn small ${A.h.scale === "log" ? "primary" : ""}" data-adk="hscale" data-v="log">log</button></span></div>
      ${chart}</section>`;
  }
  function histBins(d, hs) {
    const w = hs.width, fine = hs.fine_max || 0, by = {};
    for (const b of d.buckets) by[b.lo_us] = b;
    if (A.h.range === "tail") {
      const edge = fine || 10000;
      return d.buckets.filter(b => b.lo_us >= edge);
    }
    const top = A.h.range === "1ms" ? Math.min(1000, fine || 1000) : (fine || 10000);
    const bins = [];
    for (let lo = 0; lo < top; lo += w) bins.push(by[lo] || { lo_us: lo, hi_us: lo + w, run: 0, bench: 0, delta: 0 });
    return bins;
  }
  function histSvg(d, hs) {
    const bins = histBins(d, hs);
    const inR = bins.reduce((a, b) => a + b.run, 0), inB = bins.reduce((a, b) => a + b.bench, 0);
    const allR = d.buckets.reduce((a, b) => a + b.run, 0), allB = d.buckets.reduce((a, b) => a + b.bench, 0);
    if (!bins.length || (!inR && !inB)) return `<p class="small muted">No command in this range (run ${n1(allR)}, benchmark ${n1(allB)} commands per boot in all ranges).</p>`;
    const f = A.h.scale === "log" ? v => Math.log10(1 + v) : v => v;
    const max = Math.max(...bins.map(b => Math.max(f(b.run), f(b.bench)))) || 1;
    const bw = Math.max(2, Math.min(14, Math.floor(1000 / bins.length))), H = 220, L = 46, B = 34;
    const W = L + bins.length * bw + 10;
    const y = v => H - (f(v) / max) * H;
    let bars = "";
    bins.forEach((b, i) => {
      const x = L + i * bw;
      const tip = `${n1(b.lo_us)}–${n1(b.hi_us)} µs: run ${n1(b.run)}, benchmark ${n1(b.bench)} commands per boot (${b.delta > 0 ? "+" : ""}${n1(b.delta)})`;
      bars += `<g><title>${esc(tip)}</title><rect x="${x}" y="${y(b.bench)}" width="${bw}" height="${H - y(b.bench)}" style="fill:var(--faint);opacity:.55"></rect>`
        + `<rect x="${x + (bw > 3 ? 1 : 0)}" y="${y(b.run)}" width="${Math.max(1, bw - (bw > 3 ? 2 : 0))}" height="${H - y(b.run)}" style="fill:var(--accent);opacity:.75"></rect></g>`;
    });
    const step = Math.max(1, Math.ceil(bins.length / 10));
    let ticks = "";
    for (let i = 0; i < bins.length; i += step) ticks += `<text x="${L + i * bw}" y="${H + 16}" style="font-size:10px;fill:var(--muted)">${esc(usTxt(bins[i].lo_us))}</text><line x1="${L + i * bw}" y1="${H}" x2="${L + i * bw}" y2="${H + 4}" style="stroke:var(--muted)"></line>`;
    const ymax = A.h.scale === "log" ? Math.pow(10, max) - 1 : max;
    const svg = `<svg width="${W}" height="${H + B}" role="img" aria-label="latency histogram">
      <line x1="${L}" y1="${H}" x2="${W}" y2="${H}" style="stroke:var(--line)"></line><line x1="${L}" y1="0" x2="${L}" y2="${H}" style="stroke:var(--line)"></line>
      <text x="2" y="10" style="font-size:10px;fill:var(--muted)">${esc(n1(ymax))}</text><text x="2" y="${H}" style="font-size:10px;fill:var(--muted)">0</text>
      <text x="2" y="${H / 2}" style="font-size:10px;fill:var(--muted)">${A.h.scale === "log" ? "log" : ""}</text>${bars}${ticks}</svg>`;
    return `<div class="small" style="margin:4px 0"><span style="display:inline-block;width:10px;height:10px;background:var(--accent);opacity:.75"></span> this run (${esc(d.run.label)}) ·
        <span style="display:inline-block;width:10px;height:10px;background:var(--faint);opacity:.55"></span> benchmark (${d.bench_runs} PASS run(s)) ·
        in this range: run ${n1(inR)} of ${n1(allR)}, benchmark ${n1(inB)} of ${n1(allB)} commands per boot · each bar ${esc(usTxt(bins[0].hi_us - bins[0].lo_us))}${A.h.range === "tail" ? " or more (doubling)" : ""}; hover a bar for its counts</div>
      <div style="overflow-x:auto;border:1px solid var(--line);border-radius:10px;padding:8px">${svg}</div>
      <div class="small" style="margin-top:6px">p50 ${n1(d.run_stats.p50_us)} µs vs ${n1(d.bench_stats.p50_us)} · p90 ${n1(d.run_stats.p90_us)} vs ${n1(d.bench_stats.p90_us)} · p99 ${n1(d.run_stats.p99_us)} vs ${n1(d.bench_stats.p99_us)} · commands ${n1(d.run_stats.count)} vs ${n1(d.bench_stats.count)} per boot</div>`;
  }
  function histGrew(d) {
    const g = d.buckets_that_grew || [];
    if (!g.length) return "";
    return `<details class="more" data-id="adk-hist-grew"><summary>${IC.chev}The ${g.length} buckets that gained most commands</summary><div class="tbl"><table><tr><th>Bucket</th><th>Run</th><th>Benchmark</th><th>Δ commands per boot</th></tr>
      ${g.map(b => `<tr><td>${esc(usTxt(b.lo_us))} – ${esc(usTxt(b.hi_us))}</td><td>${n1(b.run)}</td><td>${n1(b.bench)}</td><td class="err">+${n1(b.delta)}</td></tr>`).join("")}</table></div></details>`;
  }

  function page3() {
    let h = benchView();
    h += `<div class="sectionhead">Runs · choose one to compare with the benchmark</div><section class="card">${runsTable(true)}</section>`;
    if (A.busy === "compare") h += `<div class="working"><span class="spin"></span><div class="grow"><b>Comparing…</b></div></div>`;
    if (A.sel && A.cmp[A.sel]) h += `<div class="sectionhead" id="adk-cmp">Comparison</div>` + cmpView(A.cmp[A.sel]);
    return h;
  }
  function page4() {
    const fails = A.runs.filter(r => r.verdict === "FAIL"), passes = A.runs.filter(r => r.verdict === "PASS");
    let h = `<div class="tiles"><div class="tile"><div class="v">${A.runs.length}</div><div class="l">runs stored</div></div><div class="tile"><div class="v ok-t">${passes.length}</div><div class="l">PASS</div></div><div class="tile"><div class="v err">${fails.length}</div><div class="l">FAIL</div></div>
      <div class="tile"><div class="v">${n1((A.bench || {}).boot_mean_ms)} ms</div><div class="l">benchmark mean (${(A.bench || {}).n_runs || 0} PASS run(s))</div></div></div>`;
    h += `<section class="card">${runsTable(false)}</section>`;
    for (const r of A.runs) {
      const c = A.cmp[r.id];
      if (!c) continue;
      h += `<section class="card"><h2>${esc(r.label)} ${verdictPill(r.verdict)}</h2><div class="small" style="white-space:pre-wrap">${esc(((c.summary || {}).model_text ? c.summary.model_text + "\n\n" : "") + ((c.summary || {}).text || ""))}</div>
        <div class="row" style="margin-top:8px"><a class="btn small" href="/api/adk/runs/${r.id}/compare.csv?level=command">${IC.ext}Commands CSV</a><a class="btn small" href="/api/adk/runs/${r.id}/compare.csv?level=file">${IC.ext}Files CSV</a></div></section>`;
    }
    if (!Object.keys(A.cmp).length) h += `<div class="card empty">No comparison yet: compare a run on page 3.</div>`;
    return h;
  }

  async function loadComparisons() {
    for (const r of A.runs) {
      if (A.cmp[r.id] || A.cmp[r.id] === null) continue;
      try { A.cmp[r.id] = await api("GET", `/api/adk/runs/${r.id}/compare`); } catch (e) { A.cmp[r.id] = null; }
    }
    for (const k of Object.keys(A.cmp)) if (A.cmp[k] === null) delete A.cmp[k];
    if (!A.sel) { const f = A.runs.find(r => r.verdict === "FAIL" && A.cmp[r.id]) || A.runs.find(r => A.cmp[r.id]); A.sel = f ? f.id : null; }
  }

  async function renderProject(m, p, wanted, quiet) {
    setProject(p.id);
    S.shown = null;                         // the agent-flow watcher leaves this page alone: it polls its own job
    crumb(`<b>${esc(p.name)}</b>`);
    if (!quiet) m.innerHTML = `<div class="card">Loading…</div>`;
    await load(p, !quiet);
    await loadComparisons();
    const s = stagesState();
    const cur = wanted && ST.find(x => x.id === wanted) && (wanted === "data" || s[wanted] !== "waiting") ? wanted : (A.runs.length ? "rules" : "data");
    const st = ST.find(x => x.id === cur);
    const y = window.scrollY;
    let h = `<div class="phead"><div><h1>${esc(p.name)}</h1><div class="meta">${esc(p.folder)} · <b>Windows ADK (ETL + XML)</b></div></div></div>`;
    h += stepper(p.id, cur);
    h += `<div class="stitle"><div><div class="who">${esc(st.who)}</div><h2>${st.n} · ${esc(st.title)}</h2><p>${esc(st.text)}</p></div></div><div class="stack" id="adk-page">`;
    h += cur === "data" ? page1(p) : cur === "tree" ? `<div class="card empty">${esc(ST[1].text)}</div>` : cur === "rules" ? page3() : page4();
    h += `</div>`;
    const i = ST.indexOf(st), prev = ST[i - 1], next = ST[i + 1];
    h += `<div class="navfoot">${prev ? `<button class="btn" data-act="stage" data-pid="${p.id}" data-stage="${prev.id}">${IC.left}${prev.n} · ${esc(prev.short)}</button>` : "<span></span>"}
      ${next ? `<button class="btn ${s[next.id] !== "waiting" ? "primary" : ""}" data-act="stage" data-pid="${p.id}" data-stage="${next.id}" ${s[next.id] !== "waiting" ? "" : "disabled"}>${next.n} · ${esc(next.short)} ${IC.chev}</button>` : ""}</div>`;
    m.innerHTML = h;
    m.dataset.adkPid = p.id;
    m.dataset.adkStage = cur;
    if (quiet) window.scrollTo(0, y);
    poll(p);
  }
  function poll(p) {
    clearTimeout(A.timer);
    const running = A.job && (A.job.state === "running" || A.job.state === "queued");
    if (!running) return;
    A.timer = setTimeout(async () => {
      const r = route();
      if (r[0] !== "p" || Number(r[1]) !== p.id) return;
      try {
        const j = await api("GET", "/api/adk/jobs/" + A.job.id);
        const was = A.job.state; A.job = j;
        if (j.state !== was || j.state === "done" || j.state === "failed") { A.bench = null; A.cmp = {}; await redraw(true); if (j.state === "done") toast("Analysis finished"); return; }
        const box = document.querySelector("#adk-page .working .note");
        if (box) { box.textContent = `${j.note || ""} · ${n1(j.pct || 0)} %`; const bar = document.querySelector("#adk-page .working div[style*='width']"); if (bar) bar.style.width = Math.max(2, j.pct || 0) + "%"; }
      } catch (e) { /* next tick */ }
      poll(p);
    }, 1500);
  }
  async function redraw(force) {
    const r = route(); if (r[0] !== "p" || !r[1]) return;
    const p = (S.state.projects || []).find(x => x.id === Number(r[1])); if (!p) return;
    if (force) { A.bench = null; }
    await renderProject($("main"), p, r[2], true);
  }

  $("main").addEventListener("click", async e => {
    const b = e.target.closest("[data-adk]"); if (!b) return;
    const act = b.dataset.adk, rid = Number(b.dataset.rid);
    if (["scope", "bench", "hcmd", "hproc"].includes(act)) return;     // radios, boxes and lists: handled on change
    e.preventDefault();
    try {
      if (act === "analyze") { const j = await api("POST", "/api/adk/analyze", { project: A.pid }); A.job = { id: j.job, state: "queued", note: "starting", pct: 0 }; await redraw(false); }
      else if (act === "rescan") { A.inv = null; await redraw(true); }
      else if (act === "detail") { A.open["d" + rid] = !A.open["d" + rid]; if (A.open["d" + rid] && !A.runDetail[rid]) A.runDetail[rid] = await api("GET", "/api/adk/runs/" + rid); await redraw(false); }
      else if (act === "del") { if (!confirm("Delete this run from the store? Its traces stay where they are.")) return; await api("DELETE", "/api/adk/runs/" + rid); delete A.cmp[rid]; if (A.sel === rid) A.sel = null; await redraw(true); }
      else if (act === "compare") {
        A.busy = "compare"; A.sel = rid;
        if (route()[2] !== "rules") history.replaceState(null, "", `#/p/${A.pid}/rules`);
        await redraw(false);
        A.hist = {}; A.ac.data = {}; A.ac.obj = {};
        try { A.cmp[rid] = await api("POST", `/api/adk/runs/${rid}/compare`, { scope: A.scope, llm: true }); } finally { A.busy = ""; }
        A.tab = "all"; await redraw(false);
        const el = document.getElementById("adk-cmp"); if (el) el.scrollIntoView({ behavior: "smooth" });
      }
      else if (act === "tab") { A.tab = b.dataset.tab; await redraw(false); }
      else if (act === "hrange") { A.h.range = b.dataset.v; await redraw(false); }
      else if (act === "hscale") { A.h.scale = b.dataset.v; await redraw(false); }
      else if (act === "acsort") { A.ac.sort = b.dataset.v; await redraw(false); }
      else if (act === "acproc" || act === "accmd") { const k = b.dataset.key; A.ac.open[k] = !A.ac.open[k]; await redraw(false); }
      else if (act === "hshow") {
        A.h.proc = b.dataset.proc || ""; A.h.cmd = b.dataset.cmd || "";
        A.h.adhoc = b.dataset.adhoc ? { tab: A.tab, cmd: A.h.cmd } : null;
        await redraw(false);
        const el = document.getElementById("adk-hist"); if (el) el.scrollIntoView({ behavior: "smooth" });
      }
      else if (act === "proc" || act === "cmd") { const k = b.dataset.key; A.open[k] = !A.open[k]; await redraw(false); }
    } catch (err) { A.busy = ""; toast(err.message); await redraw(false); }
  });
  $("main").addEventListener("change", async e => {
    const b = e.target.closest("[data-adk]"); if (!b) return;
    try {
      if (b.dataset.adk === "scope") { A.scope = b.value; A.bench = null; A.hist = {}; A.ac.data = {}; A.ac.obj = {}; await redraw(false); }
      else if (b.dataset.adk === "bench") { await api("PUT", "/api/adk/runs/" + b.dataset.rid, { in_benchmark: b.checked }); A.bench = null; A.hist = {}; A.ac.data = {}; A.ac.obj = {}; await redraw(false); }
      else if (b.dataset.adk === "hcmd") { A.h.cmd = b.value; if (!A.h.adhoc || A.h.adhoc.cmd !== b.value) A.h.adhoc = null; await redraw(false); }
      else if (b.dataset.adk === "hproc") { A.h.proc = b.value; await redraw(false); }
    } catch (err) { toast(err.message); }
  });

  // the start page: a new category is kept and the folder looked at again with it
  $("main").addEventListener("change", e => {
    if (!e.target || e.target.id !== "np-cat") return;
    try { localStorage.setItem("agents.cat", e.target.value); } catch (err) { /* private window */ }
    const f = $("np-folder");
    if (f && f.value.trim() && typeof checkFolder === "function") checkFolder();
  });

  window.ADK = { CAT, renderProject, isAdk: p => !!p && p.source_tool === CAT };
})();
