"""PCMark 10 Storage results (pcm10): the routes behind the pages of an analysis of category PCMark 10.

    GET    /api/pcm10/status                       what is known (UL's documentation), the limits, the unverified note
    GET    /api/pcm10/catalog                      UL's statistics, metric endings, filters and traces, with units
    GET    /api/pcm10/inventory?folder=            the results of a folder, found by content
    POST   /api/pcm10/analyze                      {project | folder} -> every result read and stored (fast: no background job)
    GET    /api/pcm10/results?project=             the stored results
    GET    /api/pcm10/results/<id>                 one result: its files (layout, separator, columns not understood), per trace
    PUT    /api/pcm10/results/<id>                 {in_benchmark: true|false, label?}
    DELETE /api/pcm10/results/<id>
    GET    /api/pcm10/benchmark?project=&scope=    the baseline results pooled
    POST   /api/pcm10/results/<id>/compare         {scope?, llm?} -> the comparison and its summary (kept)
    GET    /api/pcm10/results/<id>/compare         the last comparison
    GET    /api/pcm10/results/<id>/compare.csv?level=metric|trace|percentile
"""
import csv
import io
import json
import os
import sys
import threading
import time

from flask import Blueprint, Response, jsonify, request

from . import as_text, svc, whole

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
from pcm10 import CATEGORY, CATEGORY_NAME, UNVERIFIED, analyze, catalog, compare, discover, store as pstore, summary   # noqa: E402

bp = Blueprint("pcm10", __name__)
_LOCK = threading.Lock()


def store_of(s=None):
    s = s or svc()
    with _LOCK:
        st = getattr(s, "pcm10_store", None)
        if st is None:
            st = s.pcm10_store = pstore.Store(os.path.join(s.root, "db", "pcmark10.sqlite"))
        return st


def _llm():
    return getattr(getattr(svc(), "s2", None), "llm", None)


def _scope(project, scope):
    return None if (scope or "project") == "all" or project is None else project


@bp.get("/api/pcm10/status")
def status():
    s = analyze.settings(svc().cfg)
    return jsonify({"category": CATEGORY, "category_name": CATEGORY_NAME, "unverified": UNVERIFIED,
                    "limits": {"min_rw_bw_mbps": s.get("min_rw_bw_mbps"), "max_rw_aat_us": s.get("max_rw_aat_us")},
                    "flag_pct": s.get("worse_pct"), "files": [catalog.METRICS_FILE, catalog.STATISTICS_FILE, catalog.SECONDARY_FILE]})


@bp.get("/api/pcm10/catalog")
def get_catalog():
    return jsonify({"statistics": catalog.STATISTICS, "endings": {k: {"unit": v[0], "words": v[1], "better": v[2]} for k, v in catalog.ENDINGS.items()},
                    "filters": catalog.FILTERS, "traces": catalog.TRACES})


@bp.get("/api/pcm10/inventory")
def inventory():
    inv = discover.discover(request.args.get("folder") or "")
    return jsonify({"folder": inv["folder"], "errors": inv["errors"], "problems": inv["problems"], "ignored": inv["ignored"],
                    "results": discover.brief(inv), "seconds": inv["seconds"]})


@bp.post("/api/pcm10/analyze")
def do_analyze():
    body = request.get_json(force=True) or {}
    project = body.get("project")
    project = whole(project, "project") if project not in (None, "") else None
    folder = as_text(body.get("folder"), "folder").strip().strip('"')
    if not folder and project is not None:
        from api.agentic_api import _project
        folder = ((_project(project) or {}).get("folder")) or ""
    if not os.path.isdir(folder):
        return jsonify({"error": "the folder does not exist: %s" % folder}), 400
    out = analyze.analyze_folder(folder, project, store_of(), svc().cfg, only=[x for x in body.get("results") or [] if isinstance(x, str)] or None)
    if out["errors"] and not out["results"]:
        return jsonify({"error": "; ".join(out["errors"]), "detail": out}), 400
    return jsonify(out)


@bp.get("/api/pcm10/results")
def results():
    p = request.args.get("project")
    return jsonify(store_of().results(whole(p, "project") if p else None))


@bp.get("/api/pcm10/results/<int:rid>")
def result(rid):
    st = store_of()
    r = st.result(rid)
    if not r:
        return jsonify({"error": "no such result"}), 404
    files = st.all("SELECT name, role, layout, separator, decimal_comma, rows, values_read, not_understood, notes FROM file WHERE result=?", (rid,))
    for f in files:
        f["not_understood"] = [x for x in (f["not_understood"] or "").split("|") if x]
        f["notes"] = [x for x in (f["notes"] or "").split("|") if x]
    per = {}
    for row in st.all("SELECT trace, filter, ending, AVG(value) v, COUNT(DISTINCT pass) passes FROM metric WHERE result=? AND filter='rw' "
                      "AND ending IN ('bw','aat','at99','at9999') GROUP BY trace, filter, ending", (rid,)):
        t = per.setdefault(row["trace"], {"trace": row["trace"], "words": catalog.TRACES.get(row["trace"], ""), "passes": row["passes"]})
        t[row["ending"]] = round(row["v"], 3)
    counts = st.one("SELECT COUNT(*) metrics, COUNT(DISTINCT trace) traces, COUNT(DISTINCT pass) passes, COUNT(DISTINCT metric) names FROM metric WHERE result=?", (rid,))
    last = st.one("SELECT id, created, scope FROM comparison WHERE result=? ORDER BY id DESC LIMIT 1", (rid,))
    return jsonify({"result": r, "files": files, "traces": sorted(per.values(), key=lambda t: (t["trace"] == "all_traces", t["trace"])),
                    "counts": counts, "last_comparison": last})


@bp.put("/api/pcm10/results/<int:rid>")
def put_result(rid):
    st = store_of()
    if not st.result(rid):
        return jsonify({"error": "no such result"}), 404
    body = request.get_json(force=True) or {}
    if "in_benchmark" in body:
        if not isinstance(body["in_benchmark"], bool):
            return jsonify({"error": "in_benchmark must be true or false"}), 400
        st.exec("UPDATE result SET in_benchmark=?, updated=? WHERE id=?", (1 if body["in_benchmark"] else 0, time.time(), rid))
    if "label" in body:
        st.exec("UPDATE result SET label=?, updated=? WHERE id=?", (as_text(body["label"], "label").strip()[:200], time.time(), rid))
    return jsonify(st.result(rid))


@bp.delete("/api/pcm10/results/<int:rid>")
def delete_result(rid):
    st = store_of()
    if not st.result(rid):
        return jsonify({"error": "no such result"}), 404
    st.delete(rid)
    return jsonify({"ok": True})


@bp.get("/api/pcm10/benchmark")
def get_benchmark():
    p = request.args.get("project")
    p = whole(p, "project") if p else None
    b = compare.benchmark(store_of(), _scope(p, request.args.get("scope")))
    return jsonify({k: b[k] for k in ("results", "n", "scope", "rw_bw", "rw_aat", "score")})


@bp.post("/api/pcm10/results/<int:rid>/compare")
def do_compare(rid):
    st = store_of()
    r = st.result(rid)
    if not r:
        return jsonify({"error": "no such result"}), 404
    body = request.get_json(silent=True) or {}
    scope = body.get("scope") or "project"
    if scope not in ("project", "all"):
        return jsonify({"error": "scope is project or all"}), 400
    res = compare.compare(st, rid, _scope(r["project"], scope), svc().cfg)
    res["scope"] = scope
    res["summary"] = summary.summarise(res, _llm() if body.get("llm", True) else None)
    res["unverified"] = UNVERIFIED
    res["created"] = time.time()
    res["id"] = st.exec("INSERT INTO comparison (result, scope, created, json) VALUES (?,?,?,?)", (rid, scope, res["created"], json.dumps(res)))
    return jsonify(res)


@bp.get("/api/pcm10/results/<int:rid>/compare")
def last_compare(rid):
    c = store_of().one("SELECT id, json FROM comparison WHERE result=? ORDER BY id DESC LIMIT 1", (rid,))
    if not c:
        return jsonify({"error": "this result was not compared yet"}), 404
    res = pstore.jload(c["json"], {})
    res["id"] = c["id"]
    return jsonify(res)


@bp.get("/api/pcm10/results/<int:rid>/compare.csv")
def compare_csv(rid):
    level = request.args.get("level") or "metric"
    if level not in ("metric", "trace", "percentile"):
        return jsonify({"error": "level is metric, trace or percentile"}), 400
    c = store_of().one("SELECT json FROM comparison WHERE result=? ORDER BY id DESC LIMIT 1", (rid,))
    if not c:
        return jsonify({"error": "this result was not compared yet"}), 404
    rows = compare.flat_rows(pstore.jload(c["json"], {}), level)
    buf = io.StringIO()
    if rows:
        fields = [k for k in rows[0] if not isinstance(rows[0][k], (list, dict))]
        w = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=pcmark10_result%d_compare_%s.csv" % (rid, level)})
