"""Windows ADK ETL + XML analytics (adk_etl): the routes behind the pages of an analysis of category Windows ADK.

    GET    /api/adk/status                         xperf found or not, the PASS limit, the categories of input
    GET    /api/adk/inventory?folder=              the runs / iterations / files of a folder, found by content
    POST   /api/adk/analyze                        {folder, project?, runs?: [run ids]} -> {job}: decode + store in the background
    GET    /api/adk/jobs/<jid>                     state, note, percentage, result
    GET    /api/adk/runs?project=                  the stored runs (PASS and FAIL), newest first
    GET    /api/adk/runs/<rid>                     one run: iterations (with their decoded CSV files), phases, top processes
    PUT    /api/adk/runs/<rid>                     {in_benchmark: true|false, label?}
    DELETE /api/adk/runs/<rid>
    GET    /api/adk/benchmark?project=&scope=      the PASS runs pooled (scope: project = this analysis, all = every analysis)
    POST   /api/adk/runs/<rid>/compare             {scope?, llm?: true} -> the comparison + its summary (kept in the store)
    GET    /api/adk/runs/<rid>/compare             the last comparison of this run
    GET    /api/adk/runs/<rid>/compare.csv?level=  process | command | file | phase | event
    GET    /api/adk/runs/<rid>/histogram?category=&process=&command=&source=&scope=
                                                   I/O latency in 5 µs buckets, the run against the benchmark (per boot)
    GET    /api/adk/runs/<rid>/histogram.csv?...   the same as CSV
    GET    /api/adk/runs/<rid>/commands?category=&process=&scope=
                                                   every command under one process (or every process), run against the benchmark
    GET    /api/adk/runs/<rid>/commands/objects?category=&process=&command=&scope=
                                                   the files / DLLs / drivers / services / modules / child command lines of one command
    GET    /api/adk/runs/<rid>/iterations/<n>/<table>.csv   a decoded table of one iteration's trace
                                                   (processes, disk_commands, file_commands, census, phases)
"""
import csv
import io
import json
import os
import re
import sys
import threading
import time
import uuid

from flask import Blueprint, Response, abort, jsonify, request, send_file

from . import as_text, svc, whole

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)
from adk_etl import CATEGORY, CATEGORY_NAME, analyze, compare, config, discover, store as adk_store, summary   # noqa: E402
from adk_etl import phases as adk_phases   # noqa: E402
from adk_etl import histogram   # noqa: E402

bp = Blueprint("adk", __name__)
_LOCK = threading.Lock()
TABLES = ("processes", "disk_commands", "file_commands", "census", "phases", "commands_all", "command_objects")
CATEGORIES = [
    {"key": "auto", "name": "Recognise it from the files", "sentence": "ETL / ADK XML files without CSV tables are analysed as Windows ADK; CSV tables go to the agent flow."},
    {"key": CATEGORY, "name": CATEGORY_NAME, "sentence": "Windows ADK assessment results (Fast Startup): ETL traces and the assessment's XML. "
     "No CSV is needed: every trace is decoded with xperf. Mean Fast Startup time <= the limit is PASS."},
    {"key": "teledyne_lecroy_pcie", "name": "Teledyne LeCroy PCIe (.pex exported to CSV)", "sentence": "the five-level CSV export of a recording; the tree can be built."},
    {"key": "pcmark10", "name": "PCMark 10 Storage", "sentence": "PCMark 10 Storage results: .pcmark10-result archives (any name) or the CSV / XML files "
     "taken out of them, read with UL's documented names; good results make the baseline, any result is compared with it. Built from UL's "
     "documentation: no real result file has been seen yet."},
    {"key": "another_tool", "name": "Another tool, or I do not know", "sentence": "CSV tables of any tool: the agents learn the columns from the files."},
]


def adk_store_of(s=None):
    s = s or svc()
    with _LOCK:
        st = getattr(s, "adk_store", None)
        if st is None:
            st = s.adk_store = adk_store.Store(os.path.join(s.root, "db", "adk_etl.sqlite"))
        return st


def _cfg():
    return svc().cfg


_MS_ORDER = ["kernel"] + [k for k, _i in adk_phases.MILESTONES] + ["end"]


def phase_order(phase):
    a = (phase or "").split("_to_")[0]
    return _MS_ORDER.index(a) if a in _MS_ORDER else 99


def _llm():
    s = svc()
    try:
        return getattr(getattr(s, "s2", None), "llm", None)
    except Exception:                                   # noqa: BLE001
        return None


@bp.get("/api/adk/status")
def status():
    s = config.settings(_cfg())
    x = config.find_xperf(_cfg())
    llm = _llm()
    return jsonify({"xperf": x, "xperf_found": bool(x), "limit_ms": s["limit_ms"], "histogram": histogram.settings(_cfg()),
                    "category": CATEGORY, "category_name": CATEGORY_NAME,
                    "categories": CATEGORIES, "model": getattr(llm, "name", None) if llm else None,
                    "why_no_xperf": None if x else ("xperf.exe was not found (Windows Performance Toolkit, part of the Windows ADK). Install it, "
                                                    "or set adk_etl.xperf in config/app_config.json. The XML files can still be read.")})


@bp.get("/api/adk/inventory")
def inventory():
    folder = request.args.get("folder") or ""
    inv = discover.discover(folder, _cfg())
    return jsonify({"folder": inv["folder"], "errors": inv["errors"], "problems": inv["problems"], "runs": discover.brief(inv),
                    "detail": [{"id": r["id"], "label": r["label"], "iterations": [{k: it[k] for k in ("n", "xml", "etl", "etl_role", "etl_bytes", "notes")}
                                                                                  | {"extra": len(it["extra_etls"])} for it in r["iterations"]],
                                "ignored": r["ignored"][:30], "machine_config": r["machine_config"]} for r in inv["runs"]],
                    "etl_files": inv["etl_files"], "xml_files": inv["xml_files"], "csv_files": inv["csv_files"], "other_files": inv["other_files"],
                    "looks_like_adk": discover.looks_like_adk(inv), "seconds": inv["seconds"]})


def _job_runner(app, jid, folder, project, only):
    with app.app_context():
        s = app.config["services"]
        st = adk_store_of(s)
        st.job_set(jid, state="running", note="looking at the folder", pct=0)
        try:
            res = analyze.analyze_folder(folder, project, st, s.cfg, analyze.cache_root_of(s.root),
                                         progress=lambda note, pct=None: st.job_set(jid, note=note[:300], pct=round(pct or 0, 1)),
                                         only_runs=only)
            if res.get("errors") and not res.get("runs"):
                st.job_set(jid, state="failed", error="; ".join(res["errors"])[:1000], result=res)
            else:
                st.job_set(jid, state="done", note="finished", pct=100, result=res)
        except Exception as exc:                        # noqa: BLE001
            st.job_set(jid, state="failed", error=str(exc)[:1000])


@bp.post("/api/adk/analyze")
def start_analysis():
    body = request.get_json(force=True) or {}
    folder = as_text(body.get("folder"), "folder").strip().strip('"')
    project = body.get("project")
    project = whole(project, "project") if project not in (None, "") else None
    if not folder and project is not None:
        from api.agentic_api import _project
        p = _project(project)
        folder = (p or {}).get("folder") or ""
    if not os.path.isdir(folder):
        return jsonify({"error": "the folder does not exist: %s" % folder}), 400
    only = [x for x in (body.get("runs") or []) if isinstance(x, str)] or None
    st = adk_store_of()
    running = st.one("SELECT id FROM job WHERE folder=? AND state IN ('queued','running') AND updated>?", (folder, time.time() - 600))
    if running:
        return jsonify({"job": running["id"], "already": True})
    jid = uuid.uuid4().hex[:12]
    st.job_set(jid, project=project, folder=folder, state="queued", note="waiting", pct=0)
    from flask import current_app
    threading.Thread(target=_job_runner, args=(current_app._get_current_object(), jid, folder, project, only), daemon=True).start()
    return jsonify({"job": jid})


@bp.get("/api/adk/jobs/<jid>")
def job(jid):
    j = adk_store_of().job(jid)
    return jsonify(j) if j else (jsonify({"error": "no such job"}), 404)


@bp.get("/api/adk/jobs")
def jobs():
    project = request.args.get("project")
    st = adk_store_of()
    if project:
        rows = st.all("SELECT id, project, folder, state, note, pct, created, updated, error FROM job WHERE project=? ORDER BY created DESC LIMIT 20", (whole(project, "project"),))
    else:
        rows = st.all("SELECT id, project, folder, state, note, pct, created, updated, error FROM job ORDER BY created DESC LIMIT 20")
    return jsonify(rows)


@bp.get("/api/adk/runs")
def runs():
    project = request.args.get("project")
    rows = adk_store_of().runs(whole(project, "project") if project else None)
    for r in rows:
        r["info"] = {k: r["info"].get(k) for k in ("boot_values", "boot_std_ms")} if isinstance(r.get("info"), dict) else {}
    return jsonify(rows)


@bp.get("/api/adk/runs/<int:rid>")
def run(rid):
    st = adk_store_of()
    r = st.run(rid)
    if not r:
        return jsonify({"error": "no such run"}), 404
    its = st.all("SELECT n, xml, etl, etl_bytes, boot_ms, boot_source, xml_boot_ms, etl_boot_ms, cache_dir, counts, notes, timeline FROM iteration WHERE run=? ORDER BY n", (rid,))
    for it in its:
        it["counts"] = adk_store.jload(it["counts"], {})
        it["notes"] = adk_store.jload(it["notes"], [])
        tl = adk_store.jload(it.pop("timeline"), None)
        it["milestones_ms"] = (tl or {}).get("milestones_ms")
        it["category_ms"] = (tl or {}).get("category_ms")
        it["tables"] = [t for t in TABLES if it["cache_dir"] and os.path.isfile(os.path.join(it["cache_dir"], t + ".csv"))]
    prof = compare.run_profile(st, rid)
    phases = [{"phase": k[0], "category": k[1], "mean_ms": round(v, 1)} for k, v in (prof or {}).get("phases", {}).items()]
    phases.sort(key=lambda p: phase_order(p["phase"]))
    top = {}
    for (p, src, cmd, cat), v in (prof or {}).get("commands", {}).items():
        if src != "disk":
            continue
        t = top.setdefault(p, {"process": p, "disk_us": 0.0, "count": 0.0})
        t["disk_us"] += v["total_us"]
        t["count"] += v["count"]
    tops = sorted(top.values(), key=lambda x: -x["disk_us"])[:25]
    for t in tops:
        t["disk_us"], t["count"] = round(t["disk_us"], 1), round(t["count"], 1)
    last = st.one("SELECT id, created, scope FROM comparison WHERE run=? ORDER BY id DESC LIMIT 1", (rid,))
    return jsonify({"run": r, "iterations": its, "phases": phases, "category_ms": (prof or {}).get("category_ms"),
                    "top_processes": tops, "last_comparison": last})


@bp.put("/api/adk/runs/<int:rid>")
def put_run(rid):
    body = request.get_json(force=True) or {}
    st = adk_store_of()
    if not st.run(rid):
        return jsonify({"error": "no such run"}), 404
    if "in_benchmark" in body:
        if not isinstance(body["in_benchmark"], bool):
            return jsonify({"error": "in_benchmark must be true or false"}), 400
        st.exec("UPDATE run SET in_benchmark=?, updated=? WHERE id=?", (1 if body["in_benchmark"] else 0, time.time(), rid))
    if "label" in body:
        st.exec("UPDATE run SET label=?, updated=? WHERE id=?", (as_text(body["label"], "label").strip()[:200], time.time(), rid))
    return jsonify(st.run(rid))


@bp.delete("/api/adk/runs/<int:rid>")
def delete_run(rid):
    st = adk_store_of()
    if not st.run(rid):
        return jsonify({"error": "no such run"}), 404
    st.delete_run(rid)
    return jsonify({"ok": True})


def _scope(project, scope):
    return None if (scope or "project") == "all" or project is None else project


@bp.get("/api/adk/benchmark")
def get_benchmark():
    project = request.args.get("project")
    project = whole(project, "project") if project else None
    b = compare.benchmark(adk_store_of(), _scope(project, request.args.get("scope")))
    out = {k: b.get(k) for k in ("runs", "n_runs", "traced_runs", "scope", "boot_mean_ms", "boot_std_ms")}
    out["phases"] = sorted([{"phase": k[0], "category": k[1], "mean_ms": round(v["mean"], 1), "std_ms": round(v["std"], 1), "runs": v["runs"]}
                            for k, v in (b.get("phases") or {}).items()], key=lambda x: (x["category"], -x["mean_ms"]))
    procs = {}
    for (p, src, cmd, cat), v in (b.get("commands") or {}).items():
        if src == "disk":
            procs[p] = procs.get(p, 0.0) + v["mean"]
    out["top_processes"] = [{"process": p, "disk_us": round(v, 1)} for p, v in sorted(procs.items(), key=lambda kv: -kv[1])[:25]]
    out["category_ms"] = {k: round(v["mean"], 1) for k, v in (b.get("category_ms") or {}).items()}
    return jsonify(out)


@bp.post("/api/adk/runs/<int:rid>/compare")
def do_compare(rid):
    body = request.get_json(silent=True) or {}
    st = adk_store_of()
    r = st.run(rid)
    if not r:
        return jsonify({"error": "no such run"}), 404
    scope = body.get("scope") or "project"
    if scope not in ("project", "all"):
        return jsonify({"error": "scope is project or all"}), 400
    res = compare.compare(st, rid, _scope(r["project"], scope), cfg=_cfg())
    res["scope"] = scope
    res["summary"] = summary.summarise(res, _llm() if body.get("llm", True) else None)
    res["created"] = time.time()
    cid = st.exec("INSERT INTO comparison (run, scope, created, result) VALUES (?,?,?,?)", (rid, scope, res["created"], json.dumps(res)))
    res["id"] = cid
    return jsonify(res)


@bp.get("/api/adk/runs/<int:rid>/compare")
def last_compare(rid):
    c = adk_store_of().one("SELECT id, result FROM comparison WHERE run=? ORDER BY id DESC LIMIT 1", (rid,))
    if not c:
        return jsonify({"error": "this run was not compared yet"}), 404
    res = adk_store.jload(c["result"], {})
    res["id"] = c["id"]
    return jsonify(res)


@bp.get("/api/adk/runs/<int:rid>/compare.csv")
def compare_csv(rid):
    level = request.args.get("level") or "command"
    if level not in ("process", "command", "file", "phase", "event", "all_commands"):
        return jsonify({"error": "level is process, command, file, phase, event or all_commands"}), 400
    c = adk_store_of().one("SELECT result FROM comparison WHERE run=? ORDER BY id DESC LIMIT 1", (rid,))
    if not c:
        return jsonify({"error": "this run was not compared yet"}), 404
    rows = compare.flat_rows(adk_store.jload(c["result"], {}), level)
    buf = io.StringIO()
    if rows:
        fields = []
        for r in rows:
            for k in r:
                if k not in fields and not isinstance(r[k], (list, dict)):
                    fields.append(k)
        w = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=adk_run%d_compare_%s.csv" % (rid, level)})


def _hist_args(rid):
    st = adk_store_of()
    r = st.run(rid)
    if not r:
        return None, None
    scope = request.args.get("scope") or "project"
    category = request.args.get("category") or "all"
    if category not in ("all",) + tuple(adk_phases.CATEGORIES):
        abort(400, description="category is all, pre_logon, logon or post_logon")
    bench = [b["id"] for b in compare.benchmark_runs(st, _scope(r["project"], scope), exclude=rid) if b.get("traced")] \
        if request.args.get("bench", "1") != "0" else []
    for x in [rid] + bench:
        histogram.ensure(st, x, _cfg())
    res = histogram.compare_hist(st, rid, bench, category, request.args.get("process") or None, request.args.get("command") or None,
                                 request.args.get("source") or None)
    res["settings"] = histogram.settings(_cfg())
    res["run"] = {"id": rid, "label": r["label"], "verdict": r["verdict"]}
    return st, res


@bp.get("/api/adk/runs/<int:rid>/histogram")
def get_histogram(rid):
    """The run's I/O latency histogram (5 µs buckets) against the benchmark, for one selection: ?category= (all, pre_logon,
    logon, post_logon) &process= &command= (DiskRead, DiskWrite, DiskFlush, FileIo...) &source= (disk, file) &scope= (project, all)
    &bench=0 (the run alone). Every bucket holding a command in the run or the benchmark; counts are per boot."""
    st, res = _hist_args(rid)
    if st is None:
        return jsonify({"error": "no such run"}), 404
    return jsonify(res)


@bp.get("/api/adk/runs/<int:rid>/histogram.csv")
def get_histogram_csv(rid):
    st, res = _hist_args(rid)
    if st is None:
        return jsonify({"error": "no such run"}), 404
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["category", "process", "command", "lo_us", "hi_us", "run_commands_per_boot", "benchmark_commands_per_boot", "delta"])
    for b in res["buckets"]:
        w.writerow([res["category"], res["process"] or "all processes", res["command"] or "all commands", b["lo_us"], b["hi_us"], b["run"], b["bench"], b["delta"]])
    name = "adk_run%d_latency_%s_%s_%s.csv" % (rid, res["category"], (res["process"] or "all").replace(" ", "_"), res["command"] or "all")
    return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=%s" % re.sub(r"[^\w.()-]", "_", name)})


def _cmd_args(rid):
    st = adk_store_of()
    r = st.run(rid)
    if not r:
        return None, None, None
    category = request.args.get("category") or "all"
    if category not in ("all",) + tuple(adk_phases.CATEGORIES):
        abort(400, description="category is all, pre_logon, logon or post_logon")
    bench = [b["id"] for b in compare.benchmark_runs(st, _scope(r["project"], request.args.get("scope")), exclude=rid) if b.get("traced")]
    return st, category, bench


@bp.get("/api/adk/runs/<int:rid>/commands")
def get_commands(rid):
    """Every command under one process (?process=), or every process with its commands (no process), the run against the
    benchmark: ?category= (all, pre_logon, logon, post_logon) &scope= (project, all)."""
    st, category, bench = _cmd_args(rid)
    if st is None:
        return jsonify({"error": "no such run"}), 404
    process = request.args.get("process") or None
    ra = compare.all_commands_of(st, rid, process)
    ba = compare.all_commands_bench(st, bench, process)
    sort = request.args.get("sort") or "added"
    if sort not in ("added", "longest"):
        return jsonify({"error": "sort is added or longest"}), 400
    table = compare.all_commands_table(ra, ba, category, process, top_processes=0 if process else 300, top_commands=0 if process else 15, sort=sort)
    return jsonify({"run": rid, "category": category, "process": process, "bench_runs": len(bench), "processes": table,
                    "note": None if ra["rows"] else "no command of this run was extracted: press Analyse again on page 1"})


@bp.get("/api/adk/runs/<int:rid>/commands/objects")
def get_command_objects(rid):
    """The objects of one command of one process (files, DLLs, drivers, services, modules, child command lines, wait reasons)."""
    st, category, bench = _cmd_args(rid)
    if st is None:
        return jsonify({"error": "no such run"}), 404
    process, command = request.args.get("process") or "", request.args.get("command") or ""
    if not process or not command:
        return jsonify({"error": "give process and command"}), 400
    return jsonify({"run": rid, "category": category, "process": process, "command": command, "bench_runs": len(bench),
                    "objects": compare.command_objects(st, rid, bench, category, process, command)})


@bp.get("/api/adk/runs/<int:rid>/iterations/<int:n>/<table>.csv")
def iteration_table(rid, n, table):
    if table not in TABLES:
        return jsonify({"error": "table is one of %s" % ", ".join(TABLES)}), 400
    it = adk_store_of().one("SELECT cache_dir FROM iteration WHERE run=? AND n=?", (rid, n))
    if not it or not it["cache_dir"]:
        return jsonify({"error": "this iteration has no decoded trace"}), 404
    p = os.path.join(it["cache_dir"], table + ".csv")
    if not os.path.isfile(p):
        return jsonify({"error": "not decoded: %s" % table}), 404
    return send_file(p, mimetype="text/csv", as_attachment=True, download_name="run%d_it%d_%s.csv" % (rid, n, table))
