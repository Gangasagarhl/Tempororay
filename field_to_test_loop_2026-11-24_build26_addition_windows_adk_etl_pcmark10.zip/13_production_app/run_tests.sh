#!/usr/bin/env bash
# Every test of the application, one after the other; a failing suite does not stop the others; a table at the end.
#
#   bash run_tests.sh              unit suites, then (server on :8077) the API suites, then (Chrome) the browser suites
#   bash run_tests.sh --real       also the agent suites with real model calls (Claude Code + the model connection)
#   bash run_tests.sh --no-browser without the browser suites
#   bash run_tests.sh --offline    only the suites that need no running application (they use their own temporary folders)
#
# On Windows run it in Git Bash (it comes with Git for Windows). There only the offline suites run: the suites through
# the running application restart a Linux service and were written for Linux (deploy/WINDOWS.md).
#
# The admin's own state (databases, logs, knowledge/) is saved first and put back at the end (tests/protect_state.py):
# do not use the application while the suite runs.
cd "$(dirname "$0")"
REAL=0; BROWSER=1; OFFLINE=0
for a in "$@"; do [ "$a" = "--real" ] && REAL=1; [ "$a" = "--no-browser" ] && BROWSER=0; [ "$a" = "--offline" ] && OFFLINE=1; done
# The Python that runs the suites: $PYTHON when it is given, else the first of python3, python and py that really starts
# and has the application's packages (on Windows "python3" is often a stub that only opens the Store, and a virtual
# environment there has "python" only).
PY=""
for c in "${PYTHON:-}" python3 python py; do
  [ -n "$c" ] && "$c" -c "import flask, numpy" >/dev/null 2>&1 && { PY="$c"; break; }
done
if [ -z "$PY" ]; then
  echo "No Python with the application's packages (flask, numpy) was found; tried \$PYTHON, python3, python, py."
  echo "Activate the virtual environment first, or name the program: PYTHON=<path of python> bash run_tests.sh"
  exit 2
fi
case "$(uname -s 2>/dev/null)" in MINGW*|MSYS*|CYGWIN*) WINDOWS=1 ;; *) WINDOWS=0 ;; esac
if [ $WINDOWS -eq 1 ] && [ $OFFLINE -eq 0 ]; then
  OFFLINE=1; echo "Windows: only the offline suites run (the suites through the running application were written for Linux; deploy/WINDOWS.md)."
fi
echo "Python: $PY ($("$PY" -c 'import sys; print(sys.version.split()[0])'))"
LOG=runs/suite_logs; mkdir -p "$LOG"
declare -a NAMES RESULTS
run() {   # run <name> <what it checks> <command...>
  local name="$1" what="$2"; shift 2
  local t0=$(date +%s)
  echo; echo "===== $name: $what"
  timeout 3600 "$@" > "$LOG/$name.log" 2>&1; local rc=$?
  local line=$(grep -E "checks, [0-9]+ failed|checks passed|^[0-9]+ passed|passed in|^Ran [0-9]+ tests|^OK|FAILED" "$LOG/$name.log" | tail -2 | tr '\n' ' ')
  local dt=$(( $(date +%s) - t0 ))
  if [ $rc -eq 0 ]; then echo "PASS  $name  ($dt s)  $line"; RESULTS+=("PASS"); else echo "FAIL  $name  ($dt s)  exit $rc  $line   -> $LOG/$name.log"; tail -15 "$LOG/$name.log"; RESULTS+=("FAIL"); fi
  NAMES+=("$name|$what|${dt}s|$line")
}

SERVER=0; [ $OFFLINE -eq 0 ] && curl -sf -m 5 http://127.0.0.1:8077/api/hier/uploads >/dev/null 2>&1 && SERVER=1
CHROME=0; { command -v google-chrome || command -v chromium || command -v chromium-browser; } >/dev/null 2>&1 && "$PY" -c "import websocket" 2>/dev/null && CHROME=1
[ $SERVER -eq 1 ] && "$PY" tests/protect_state.py save

# ---- unit suites (no server needed)
run unit_app      "packet workflow end to end, stage 2 (tests_v3, tests_v4), stage 1 engine fixtures and analyzer cases" "$PY" -W ignore tests/test_app.py
run unit_hier     "five-level loader, builder vs ground truth, rules, store, optimiser, real headers, parallel load, test file imports" "$PY" tests/test_nvme_hier.py
run unit_web      "web evidence: quotes checked on the fetched page, only internet pages, web tools per model, off when the admin says so" "$PY" -m pytest -q -p no:cacheprovider tests/test_web_evidence.py
run unit_rules    "rule evidence: every rule's columns are read by its code, sections made by the admin" "$PY" -m pytest -q -p no:cacheprovider tests/test_rule_evidence.py
run unit_procs    "procedures: Code it checks and tries the code, the admin verifies it, Run takes only verified code" "$PY" -m pytest -q -p no:cacheprovider tests/test_procedures.py
run unit_editcode "edit and code together: Save and code it, coding of the old text replaced, no overwrite of a change made meanwhile" "$PY" -m pytest -q -p no:cacheprovider tests/test_edit_and_code.py
run unit_delete   "delete an item: leaves the list, kept for Restore, seeds stay deleted, not while a Run or flow step of it is going" "$PY" -m pytest -q -p no:cacheprovider tests/test_delete_items.py
run unit_graph    "the reinforcement loop on the procedural graph: the four signals change the weights, the weights decide the next output" "$PY" -m pytest -q -p no:cacheprovider tests/test_graph_loop.py
run unit_attack   "trying to break it: bad signals, hostile CSV files, broken clocks, exact limits, signals at the same moment" "$PY" -m pytest -q -p no:cacheprovider tests/test_adversarial.py
run fuzz_kpi      "random attacks with a known answer: 179 hostile recordings (faults, noise, broken files, reordered queues) and random signal histories on the graph" "$PY" tests/fuzz_kpi.py 179 5000
run fuzz_app      "attacks on the whole application: 200 random hostile requests, corrupted files, generated scripts, agent code and page text" "$PY" tests/fuzz_app.py 200 7000
run fuzz_params   "every route, every parameter its own code reads, one hostile value at a time, for five minutes" "$PY" tests/fuzz_params.py 300 1
run attack3       "twenty targeted attacks: files outside the app, corrupted saved data, runaway agent code, simultaneous presses, a full disk, binary files" "$PY" tests/attack_round3.py
run unit_progress "every long step shows a percentage: tree, rules, long silent statements, steps with no progress of their own" "$PY" -m pytest -q -p no:cacheprovider tests/test_progress.py
run unit_limits   "big files and hard limits: a torn record, a crash during a write, runaway agent code, a file with no line ends, a stray quote, out of memory or disk" "$PY" -m pytest -q -p no:cacheprovider tests/test_limits.py
run unit_agents   "the agents themselves: bad model answers, outages, many at once, memory among thousands, whole flows together, and what an agent and its code can reach" "$PY" -m pytest -q tests/test_agent_layer.py
run unit_joins    "the rules that combine the five files: each ticked by the admin and tied to its code, and eleven damaged recordings caught on the right rule" "$PY" -m pytest -q -p no:cacheprovider tests/test_join_rules.py
run fuzz_deep     "deep attacks: the whole flow played at random, the graph against an independent model, parsers, generated scripts, signatures, the usual-time rule" "$PY" tests/fuzz_deep.py 100 9000
run attack6       "a hundred and thirty-four different attacks: damaged recordings, things that are not files, machines that run out, killed processes, corrupted saved data, approvals that try to slip past the checks, many requests at once" "$PY" tests/attack_round6.py
run kpi_proof     "measured KPI evidence: injected faults against ground truth, a trivial baseline, known failures coming back, generated tests on a simulated drive" "$PY" tests/test_kpi_proof.py
run unit_cmdrules  "the two NVMe command rules: timeout (never completed, aborted by the host, the host's limit, slower than usual per type) and read failure" "$PY" -m pytest -q -p no:cacheprovider tests/test_command_rules.py
run unit_errors   "the errors page and one error page (2026-11-11): the fixed dictionary, the evidence card, the same isolation whatever the window, the procedural graph, progress jobs, test approval, the 5W1H summary" "$PY" -m pytest -q -p no:cacheprovider tests/test_defect_graph.py tests/test_isolation_window.py tests/test_summary_and_choice.py tests/test_optional_references.py tests/test_model_settings.py tests/test_grounder_batches.py tests/test_stop_and_delete.py
run unit_calls    "model calls at the same time (2026-11-11): the number from the processor cores, stepping down on 'too many calls', the kinds of row that fill a column, the fast reference search" "$PY" -m pytest -q -p no:cacheprovider tests/test_calls_at_once.py
run unit_ask      "after Family 1 (2026-11-12): the admin's question to all the Managers (yes only with a name that is in the data, no only when every file was read), read the new files (only the new file gets its three agents), go to stage 2 or not" "$PY" -m pytest -q -p no:cacheprovider tests/test_admin_ask.py
run unit_family4 "Family 4, Coding (2026-11-12): the requirements with the admin, every kind of data asked of Family 1 (found, not found, cannot tell, an invented name dropped), the rounds of Coder and Tester (clean round, the number the admin set, what failed goes to the next round, a wrong expectation set aside for the admin, a stopped run), verified code used again" "$PY" -m pytest -q -p no:cacheprovider tests/test_family4.py
run unit_nvmerules "the rules for errors at the NVMe command level (2026-11-12): the detector's own command rules, their places in the NVMe specification, the columns they read and whether a recording carries them, a recording loaded from the NVMe command file alone, check again, the line of every error" "$PY" -m pytest -q -p no:cacheprovider tests/test_nvme_command_rules.py
run unit_f4research "Family 4 as the coding research family (2026-11-14): the data research measured in one pass (spellings of nothing, numbers as text, where the rule's words are stored), the ledger with its sources, the link facts counted in the tree, conflicts found by code with the fixed priority, a hidden decision as a requirement or a question, a data set that cannot fail, the whole-file run and its accounting, an unlicensed column, the four verdicts decided by code, the admin's decision on each requirement not shown to hold" "$PY" -m pytest -q -p no:cacheprovider tests/test_f4_research.py
run unit_colmatch "which column holds this kind of data (2026-11-14): one signature per column from what Family 1 knows, ranked by containment and never Jaccard, counters and flags and shared words not counted as support, the exact count in one pass with its cap, the model picking from the short list only, three levels of support decided by code, the same result with 1 call and with 8, the route" "$PY" -m pytest -q -p no:cacheprovider tests/test_column_match.py
run unit_stage2   "stage 2 as a choice, any CSV, REA once, a finished analysis opened again (2026-11-13): the fixed joining strategy is an option and never chosen when it cannot build the files, an item that reads the tree is blocked without one, REA findings are read once, opened again at a stage only what is new is computed" "$PY" -m pytest -q -p no:cacheprovider tests/test_stage_choice.py
run unit_rea      "the REA agent of the start page (2026-11-14): the findings read once in one pass and again only after a change, the join lines as the earlier search found them, passages by their words (also without full-text search), a made-up quote dropped, nothing found said plainly, the conversation kept, Family 2's Coder and chat agent served without a step, the routes" "$PY" -m pytest -q -p no:cacheprovider tests/test_rea_agent.py
run unit_terminal "opencode in a terminal with held sessions (2026-11-13): the program's model list and event lines, the read-only agents, one session per agent continued turn after turn and after a restart, a full or refused session going on as its next part with the earlier turns from the application's record, a refusal the program only logs, Stop, never the model connection" "$PY" -m pytest -q -p no:cacheprovider tests/test_terminal_sessions.py
run unit_treefast "the faster tree build (2026-11-14): each join gives the same rows as the join it replaced on 300 generated awkward recordings, the link window, one Ack for several packets, a whole build, the window comparison on a correct and on a spoiled tree" "$PY" -m pytest -q -p no:cacheprovider tests/test_tree_build_lookups.py
run unit_apisess  "the Model connection with a held conversation per agent (2026-11-14): earlier turns sent again and read from the cache, saved on disk and back after a restart, a step run again not sent twice, compaction at 95 % with the model's summary, the fallback when no summary can be made, an address without the caching field" "$PY" -m pytest -q -p no:cacheprovider tests/test_api_sessions.py
run unit_investig "the investigation agent after Family 1 (2026-11-14): one terminal session per analysis kept by name and opened again after a restart, what it is doing while it works, one question at a time, Stop, the CSV files it wrote listed, saved and added to the analysis without replacing a file" "$PY" -m pytest -q -p no:cacheprovider tests/test_investigate.py
run unit_termset  "Settings with opencode (2026-11-13): the program's own models and none chosen, a model of the list needed, every part moved to the terminal and back, Save and test, the sessions and conversations over the API, the endpoint lock, a deleted analysis takes its sessions" "$PY" -m pytest -q -p no:cacheprovider tests/test_terminal_settings.py
run flow_anycsv   "a whole flow without a server on a folder of one CSV that is not an analyzer export (2026-11-13): no tree, a rule on the file, Family 4's requirements and code, the result counted from the file, then opened again at the rules (nothing computed again) and at the data with one new CSV (only the new file is read)" "$PY" tests/flow_any_csv.py
run unit_tool     "the first question (2026-11-12): which tool exported the recording, kept with the analysis, refused when unknown or not ready, older databases, when a hierarchy is needed" "$PY" -m pytest -q -p no:cacheprovider tests/test_source_tool.py
run unit_known    "what is already known comes first (2026-11-12): the reference library and its quotes, the store of understood columns, approve and reject, the Data Grounder asking only what is open, large files read on all the processor cores with the same result" "$PY" -m pytest -q -p no:cacheprovider tests/test_column_knowledge.py tests/test_grounder_known.py tests/test_reject_hook.py tests/test_profile_parallel.py
run unit_forty    "the Data Grounder's calls (2026-11-12): at least 40 column names in a call with the 30 most frequent keywords of each, keyword meanings asked apart at the same time, the same result whichever call answers first, no more than 5 calls started in one second" "$PY" -m pytest -q -p no:cacheprovider tests/test_grounder_forty.py
run unit_nvmecmd  "every result an NVMe command can end with (2026-11-12): the list from the two NVMe specifications, counted for a recording from the command's own status columns, nothing dropped, no time limit on that page" "$PY" -m pytest -q -p no:cacheprovider tests/test_nvme_command_errors.py
run unit_hierpar  "the five files read in parts on all the processor cores (2026-11-12): the same tables, tree and findings as on one core, a part cut inside a quoted cell or a file with carriage-return line ends read on one core with the reason, one doorbell for several completion entries, the fast cell readers against the general ones" "$PY" -m pytest -q -p no:cacheprovider tests/test_hierarchy_parallel.py
run unit_joinproc "the joins of the tree in processes of their own (2026-11-12): the same tree as on one core with 2, 3 and 4 processes, a join whose process is killed, fails or leaves an unreadable result is run on one core with the reason, a stop ends the processes, a join process cannot write the recording, a rebuild keeps nothing of the build before, the priority for processor time on Linux and through a stand-in for the Windows calls" "$PY" -m pytest -q -p no:cacheprovider tests/test_joins_at_once.py
run unit_winlike  "the offline flow in a Python that behaves like Windows where it can be imitated on Linux (2026-11-12): no Unix-only module or call, text files without an encoding read in the Windows code page, a file that is open cannot be replaced or deleted, no /proc: load in parts, tree and rules, Data Explorer, Data Grounder, a procedure run, a test file. It is not a test on Windows: nothing under os.name == 'nt' runs here" "$PY" -m pytest -q -p no:cacheprovider tests/test_windows_like.py
run unit_family3 "Family 3 on the tree, the regression test of a defect, the side panel's agents (2026-11-10): a procedure reads the tree only through its read-only door, the test plan is checked against the recording and run both ways on the simulated drive, the agents' numbers are checked" "$PY" -m pytest -q -p no:cacheprovider tests/test_tree_contract.py tests/test_regression_tests.py tests/test_data_chat.py
run unit_searchmem "what a search learned is kept and starts the next search of the same kind (2026-11-14): one event per search, back after the database is opened again, the carried weight limited to 14 lab runs, a hostile or damaged history, switched off the search is as before, the reward from the detector's findings alone" "$PY" -m pytest -q -p no:cacheprovider tests/test_search_memory.py
run unit_cause    "the cause of a command that never completed (2026-11-14): the Abort that names it and the controller reset found by identity in the packets, the seven commands of the S17 sample, the same cause with any window, recordings with rows taken out or damaged" "$PY" -m pytest -q -p no:cacheprovider tests/test_cause_never_completed.py
run unit_seqwrap  "the link join when a sequence number comes round again (2026-11-14): a later Ack closes the packets it covers, the packet a round later is its own link transaction, a true resend stays a resend, both directions, damaged cells, 1, 2 and 4 join processes" "$PY" -m pytest -q -p no:cacheprovider tests/test_link_sequence_wrap.py
run unit_archive  "the knowledge base keeps what proved a result (2026-11-14): the rows around a validated error read back after the upload is gone, the size limit, a workload record kept as given and validated only by the admin, hostile requests" "$PY" -m pytest -q -p no:cacheprovider tests/test_knowledge_archive.py
run unit_search   "the search and the most stressful conditions on the page of one error (2026-11-14): against a random choice on a simulated drive with a hidden trigger, nothing invented, no illegal order, progress and stop, the real bench not connected, the written test unchanged when the search is not used" "$PY" -m pytest -q -p no:cacheprovider tests/test_replay_search.py
run unit_handover "approved tests as a package for a validation suite and its results back (2026-11-14): only approved and unchanged tests, nothing chosen in advance, the package's own command run, hostile result files refused" "$PY" -m pytest -q -p no:cacheprovider tests/test_handover.py
run unit_nearlimit "commands that completed but came close to the limit (2026-11-14): the four samples against a slow recomputation, stretched times, no command counted twice, streamed for 200,000 commands, the error list unchanged" "$PY" -m pytest -q -p no:cacheprovider tests/test_near_limit.py tests/test_application_code_items.py
run unit_anytool  "the start page takes a recording of any tool (2026-11-14): the answer 'Another tool, or I do not know', kept with the analysis, no fixed joining strategy for it, a chosen tool the files do not look like is said per file before the flow starts" "$PY" -m pytest -q -p no:cacheprovider tests/test_any_tool_start.py tests/test_start_without_tool_question.py
run unit_dialect  "a CSV as real tools write it (2026-11-14): semicolon, tab and vertical bar, a header that is not on line 1, UTF-16, decimal commas and thousands signs, a file that is no table refused in words, read in parts equal to one core, the samples unchanged" "$PY" -m pytest -q -p no:cacheprovider tests/test_csv_dialect.py
run unit_form     "the file's form reaches the agents and every reader (2026-11-14): the Data Explorer and the Data Grounder are told how the file is written, a Manager answers about it, a chosen tool is taken only for a file that looks like it, the coding family's readers on a semicolon and a UTF-16 file equal to the comma file" "$PY" -m pytest -q -p no:cacheprovider tests/test_form_reaches_the_agents.py tests/test_form_in_every_reader.py
run unit_othererr "errors a rule finds in a CSV file outside the tree (2026-11-14): each found row an error with its file, row and cells, an analytics item adds none, a result that does not name its rows refused, the page of one such error with meanings, the rows around it and a kept isolation, 300,000 rows without loading the file" "$PY" -m pytest -q -p no:cacheprovider tests/test_other_csv_errors.py
run unit_f4faults "Family 4 after the run with the real model (2026-11-14): requirements and procedure agree before any code round, the rounds stop early on a cause no code change repairs, unsupported surprises dropped at their source, the Tester's position in fixed words, the REA agent asked only with the admin's tick" "$PY" -m pytest -q -p no:cacheprovider tests/test_family4_real_run_faults.py tests/test_f4_research_sources.py
run unit_f4recheck "Family 4's code rechecked by the terminal agent (2026-11-15): its own program on the whole file against the family's result, a disagreement with real rows back to the Coder, an answer that fails the checks never counted as agreement, not ready or stopped said in words" "$PY" -m pytest -q -p no:cacheprovider tests/test_f4_recheck.py tests/test_recheck_profile.py
run unit_card     "a family's review card handed to the terminal agent (2026-11-15): the card written from the application's own records as a file of data, never from the browser, a card of another analysis refused, card files do not pile up, a question without a card as before" "$PY" -m pytest -q -p no:cacheprovider tests/test_terminal_card.py tests/test_terminal_folder.py
run unit_errpage  "the page of one error with the parts joined (2026-11-14): the rows kept in the knowledge base when the isolation is kept and the test approved, an archive fault never fails the admin's action, the hand-over part, why-lines and nothing pre-selected" "$PY" -m pytest -q -p no:cacheprovider tests/test_error_page_joined.py tests/test_chat_command_spellings.py
run unit_flowpage "the flow pages with the parts joined (2026-11-15): the errors of other files listed with their links, the REA tick, the three new settings accepted and garbage refused, why-lines and nothing pre-selected" "$PY" -m pytest -q -p no:cacheprovider tests/test_flow_page_joined.py tests/test_rule_hierarchy.py
run unit_floworder "the order of the flow (2026-11-15): a rule of the admin's own is written, coded, run on the tree and tested, and only after the admin approves its result are its rows filed as errors of the recording; the page of one error refuses until then; every found row names its row of the file; the header of a level's file" "$PY" -m pytest -q -p no:cacheprovider tests/test_flow_order.py
run unit_graphlearn "the procedural graph learns from lab runs (2026-11-15): lab counts kept apart from the admins' judgements and never changing them, timing kept as values with a bracket, the search on the page of one error starts from what the graph holds and writes back, an empty graph gives the released search, the measurement with same-kind, stale and wrong history on a simulated drive" "$PY" -m pytest -q -p no:cacheprovider tests/test_graph_learning.py
run unit_cmdfamilies "the rule families for errors at the NVMe command level (2026-11-15): 52 families as data with their sources, 38 seeded as items under Errors, NVMe commands, none chosen by default, an edited item never written over, the reference implementation on the samples, the comparison of a code with the reference, the speed on 200,000 commands" "$PY" -m pytest -q -p no:cacheprovider tests/test_command_error_rules.py
run unit_cmdflow "the rule families through the whole flow (2026-11-15): nothing listed before a result is approved, rows filed as errors with numbers, the same command found by two rules said once, an error of a family through stage 1, name, cause, solution and test, a family that finds nothing, run again without doubling, coded by Family 4 with the comparison when a model is connected, a code that calls the reference refused" "$PY" -m pytest -q -p no:cacheprovider tests/test_command_rules_flow.py
run unit_errjoin "the page of one error for an error of the admin's own rule (2026-11-15): the rule in words and never its key, the refusal of the search and the graph routes until the result is approved, a validation suite's result counted as lab runs once and only when the file states the bench and the counts, the page's message" "$PY" -m pytest -q -p no:cacheprovider tests/test_join_error_page.py
run unit_header "the header of a level's file kept with the tree at load (2026-11-15): both export layouts, in parts on several processes and on one, equal to the file's header, the three states of a column in the facts given to Family 4" "$PY" -m pytest -q -p no:cacheprovider tests/test_join_header.py
run unit_renumber "error numbers after the recording is checked again (2026-11-15): every number an analysis keeps follows to its new number in one transaction, by rule, file and row, an error no longer found taken out and said, the errors page checks its numbers before it draws a link" "$PY" -m pytest -q -p no:cacheprovider tests/test_renumber_follows_flows.py
run unit_famcause "the cause of an error found by a rule family (2026-11-15): the same cause, words and evidence as the detector's error of the same command, read from the command's own rows in the tree, an honest sentence where no fixed rule applies" "$PY" -m pytest -q -p no:cacheprovider tests/test_cause_for_family_errors.py
run unit_top3 "the three NVMe command errors kept by the owner (2026-11-15): timeout, read failed, aborted because the host asked, on S17 against an independent reading; a completed command with an empty status cell is not never completed; a status written 81h is read as hexadecimal" "$PY" -m pytest -q -p no:cacheprovider tests/test_top_three_rules.py
run unit_analytics1csv "Data analytics on one CSV file (2026-11-15): every rule of Data analytics reads its level's own file, never the tree; the two built-in items give the same numbers by file as by tree; a tree procedure there is refused with a sentence; Errors rules keep the tree; the near-limit item starts in Deleted items on a new installation" "$PY" -m pytest -q -p no:cacheprovider tests/test_analytics_on_one_csv.py
run unit_additem "a rule of the library added to an analysis and groups inside a level (2026-11-15): on the plan card, while the analysis works, after it finished (opened again at the rules), the rules already done keep their results, every refusal in words; add and delete a group" "$PY" -m pytest -q -p no:cacheprovider tests/test_add_item_to_analysis.py
run unit_adk "Windows ADK ETL + XML (2026-11-24): files found by content whatever their names, the ADK XML reader, pre-logon / logon / post-logon phases, xperf's text parsed, PASS when the mean Fast Startup time is at most 14 s, the PASS runs pooled into a benchmark, phase > process > command > file, every command under every process (times, counts, objects), 5 us latency buckets; with xperf and the Desktop traces also the real traces" "$PY" -m pytest -q -p no:cacheprovider tests/test_adk_etl.py
run unit_pcm10 "PCMark 10 Storage (2026-11-24): UL's documented names, the reader in every layout (wide, long, transposed; separators, decimal comma, UTF-16), archives found by content, the baseline, the comparison worst first, the model's numbers checked, the routes and the start page's category" "$PY" -m pytest -q -p no:cacheprovider tests/test_pcm10.py

if [ $SERVER -eq 1 ]; then
  # ---- API suites against the running application
  run e2e_hier     "five files through the HTTP API: load, tree, summary, rules, limits, defects, signals, test case" "$PY" tests/test_hier_e2e.py --cleanup-store
  run isolate      "the isolation tab: window, stateful chat, memory, evidence loop, test case, summary" "$PY" tests/test_isolate.py --cleanup-store
  run agents       "the agent families one by one (stand-in): dictionaries, strategy, build, testers, rules, resume" "$PY" tests/test_agentic.py
  run flow         "THE FLOW twice (stand-in): Family 1 -> 2 -> 3, stage 1, the four signals, stage 2, test file, report, reuse" "$PY" tests/test_flow.py
  run packet_loop  "the earlier packet workflow on the running app: stage 1, stage 2, every admin signal, cache, undo" "$PY" tests/exercise_loop.py
  if [ $BROWSER -eq 1 ] && [ $CHROME -eq 1 ]; then
    # ---- browser suites (headless Chrome)
    run ui_packets "the /packets stage-2 decision view: ranking, signals, corrected version, test script" "$PY" tests/ui_smoke.py
    run ui_tree    "the tree pages /hier: upload, tree, summary, defects, limits, signals" "$PY" tests/ui_smoke_hier.py
    run ui_pages   "the flow pages: home, top bar, settings, history, rules library, search, add an item" "$PY" tests/ui_smoke_agents.py
    run ui_flow    "a whole flow clicked through the four pages (light and dark screenshots)" "$PY" tests/ui_smoke_flow.py
    run ui_terminal "the terminal agent on every page (2026-11-14): the button, the panel, which session the page's questions go to, where the admin is" "$PY" tests/ui_smoke_terminal.py
  else
    echo; echo "browser suites skipped: $( [ $BROWSER -eq 0 ] && echo '--no-browser' || echo 'no Chrome or no websocket-client module')"
  fi
  if [ $REAL -eq 1 ]; then
    # ---- real model calls (cost money: Claude Code with ~/.claude/settings.json, the model connection for stage 1 and 2)
    run agent_folder "a real agent cannot read a file outside its own folder" env F2T_REAL=1 F2T_MODEL=claude-haiku-5-5 "$PY" -m pytest -q -k real_agent tests/test_agent_layer.py
    run agents_real "the agent families with real Claude Code and model-connection calls" "$PY" tests/test_agentic.py --real
    run flow_real   "THE FLOW twice with real Claude Code agents and the model connection" "$PY" tests/test_flow.py --real
  fi
  "$PY" tests/protect_state.py restore
else
  echo; echo "API and browser suites skipped: $( [ $OFFLINE -eq 1 ] && echo 'only the offline suites were asked for' || echo 'the application does not answer on http://127.0.0.1:8077 (start it first)')"
fi

echo; echo "================ summary"
fail=0
for i in "${!NAMES[@]}"; do IFS='|' read -r n w d l <<< "${NAMES[$i]}"; printf "%-5s %-12s %6s  %s\n        %s\n" "${RESULTS[$i]}" "$n" "$d" "$w" "$l"; [ "${RESULTS[$i]}" = "FAIL" ] && fail=1; done
exit $fail
