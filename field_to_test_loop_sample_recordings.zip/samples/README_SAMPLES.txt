Sample recordings for the Field-to-Test Loop application (2026-11-14)

Every recording here is SYNTHETIC: made by the project's own generator (data/generator in the code zip), none from a real
drive or from the field.

Unpack this zip INSIDE the application folder (13_production_app), so that these folders exist:

  13_production_app/samples/clean_five_files/S08_interrupt_before_completion   five CSV files of one recording
  13_production_app/samples/clean_five_files/S17_io_timeout_abort_reset        the recording of the worked example in document.html
  13_production_app/samples/clean_five_files/S27_lcrc_nak_replay
  13_production_app/samples/clean_five_files/demo_225_commands
  13_production_app/samples/hier_synth                                          225 commands, with the generator's own answer file

The tests of run_tests.sh read them; without them most of those tests are skipped and some fail. The start page of the
application can start a flow on any of the four folders under clean_five_files.
