# Read me first: Field-to-Test Loop

**What it is.** A web application that runs on one server. **The main page (/) is one flow** (page 3 changed
2026-11-11): the per-level CSV exports of one recording -> data dictionaries (page 1) -> one tree (page 2) -> rules and
errors (page 3) -> report (page 4). On page 3 the admin's patterns find **errors**; the errors page lists them, and
each error is taken through its own page: **stage 1**, the isolation of the defect (evidence card from the error's own
command and the cause by fixed rules, both by code; the name from a fixed dictionary; why and how by the model; kept per
error); **stage 2**, the procedural graph (defect -> cause -> solution, stored solutions ranked by the admin's
judgements); then **the test case** (answers checked by the admin, tried on a simulated drive, approved by the admin).

**The earlier single-CSV workflow** (`/packets`): an engineer gives it the path of a protocol-analyzer
capture of PCI Express (PCIe) / NVM Express (NVMe) traffic, exported as a 113-column CSV (comma-separated values)
file. **Stage 1** isolates every defect in the capture using rules taken from the specifications; an AI reviewer
(a large language model, LLM) gives a second opinion but never decides. **Stage 2** looks each defect up in a
knowledge base (`db/knowledge.sqlite`), an admin decides (**Correct** / **Needs changes** / **Not correct** and 23
more decisions), the lab reproduces the defect (a search over command sequences and timing, then a "most stressful
conditions" step), a lab check runs it on known-bad and fixed firmware, and a regression test is written to
`suite/`. No model is ever trained; the application learns by counting decisions and lab results.

**On Windows:** read `deploy/WINDOWS.md` first. The application has never run on Windows; that file says what was fixed by reading, gives the install and test commands for Windows and the 31 checks to do there (checks 28 to 31 are for the second round of 15 November). The sample recordings are a zip of their own (`field_to_test_loop_sample_recordings.zip`): unpack it inside this folder.

**What is still missing against the project's statement:** `docs/OPPORTUNITY_COVERAGE_2026-11-15.md` checks each of the 16 statements of `docs/OPPORTUNITY_STATEMENT.md` against this code under the owner's design: no code per measuring tool, any tool's recording is converted to CSV by the people who have the tool, and Family 1 learns the columns from the files (0 fully covered, 14 partly, 2 not; everything rests on synthetic recordings and a simulated drive). It also says, per statement, what was built on 14 and 15 November; its last part, "After the second round of 15 November", goes through the statements the second round touches (no verdict changes). It replaces `docs/OPPORTUNITY_COVERAGE_2026-11-14.md`, which put the question about VIAVI wrongly. `deploy/REAL_ENVIRONMENT_WORK.md` is the work list for whoever has real captures, a drive and a bench: what to evaluate, what to build, in which order.

**What was added on 2026-11-14/15:** learning from history in the search and a reward from the detector's findings; the cause of a command that never completed; the link join when a sequence number comes round again (with a switch); the knowledge base keeps the rows that proved a result; a search and the most stressful conditions on the page of one error; approved tests as a package for a validation suite; commands that came close to the limit; a start page and a reader for a recording of any tool; errors a rule finds in a CSV file outside the tree; repairs to Family 4 after a run with a real model, its code rechecked by the terminal agent, and a family's review card handed to the terminal agent. The record, part by part, with what each part's own tests showed and what is not done: `docs/CHANGES_2026-11-15.md`. Each part passed its own tests, as its report says. The whole test suite ran on the joined code (the line below); the browser test groups ran against the new pages, and no person has looked at them in a browser yet. Nothing ran on Windows, on a real capture of any tool, or on a real drive.

**What was added in the second round of 15 November (after build 23):** one field instead of two for the REA findings on the start page; no question "Which tool exported the recording?" (the tool is recognised from each file's own column names; a folder with no CSV table says so and "Start the flow" stays off; the terminal agent can be asked about the files of a folder before an analysis exists); the rules library and page 3 read section, kind of recording, level, items, with groups inside a level and "add" and "edit" in sight (the two built-in sections are "Data analytics" and "Errors"; "Errors" was called "Error roots"); 52 researched rule families for NVMe command errors, 38 of them runnable and offered under Errors, NVMe errors, NVMe command level errors, none chosen in advance; a strict order (rule, code, run, result approved, errors listed, isolation, cause and solution, test), with a rule of the admin's own and a rule of the application's rule set (one of the 38) now going the whole way and the page of one error refusing until the result is approved; without a model a chosen rule of the 38 runs the application's reference implementation and the admin decides one card, with a model Family 4 writes its code (at least 10 calls to the model and 3 cards for each rule, counted with the stand-in) and the Tester compares its rows with the reference; the same command found by two rules is said on both errors; timing kept as data on the procedural graph (lab counts apart from the admins' judgements, the gap before each step and the queue depth as values, a bracket), the search on the page of one error starting from it, and a validation suite's result counted as lab runs of a stored solution. No model is trained. The record, part by part, with the measured numbers, 45 decisions for the owner and what is not proven: `docs/CHANGES_2026-11-15_round2.md`. Each part passed its own tests, on synthetic recordings, a simulated drive and the stand-in or a scripted model; the run of the whole suite on that joined code is in the last section of that record. A fault of the engine was found in that round and fixed (section 0a of the record): Approve pressed at one exact moment could leave an analysis "running" with nothing running until the application was started again; one unit test and one clean run cover the fix, and one clean run does not prove that a race is gone. Measured on a simulated drive only: with stored timing of the same kind the search needed fewer lab runs in 28 of 30 cases; with stale or wrong stored timing it was worse in 25 of 30 and in 30 of 30. Nothing of that round ran on Windows, with a real model, on a real capture, on a real drive or in a real validation suite, and no person has looked at its pages in a browser.

TESTS ON THE JOINED CODE: on 15 November 2026, from 02:11 to 02:51, the whole suite ran on the joined code in five parts side by side: 60 offline groups and 10 groups through the running application and the browser. All 70 passed. After that run one module was corrected once more (the recheck by the terminal agent, after its trial with the real opencode program), and the eight groups that touch it were run again on the final code at 02:52: all eight passed (unit_f4recheck 60 tests, unit_family4 40, unit_f4faults 42, unit_flowpage 15, unit_form 20, the flow on any CSV 0 checks failed, the agent families through the application 86 checks, a whole flow twice 72 checks). This is synthetic data, a simulated drive, and the stand-in in place of the model in most groups.

**Read in this order**

| You are | Read |
|---|---|
| An engineer or AI coding agent installing or running it | 1. `deploy/AGENT_INSTRUCTIONS.md` (the master runbook: rules, ordered checklist, troubleshooting, report template) · 2. `deploy/INSTALL.md` and `deploy/DEPLOY.md` · 3. `deploy/OPERATIONS.md` (day to day) · 4. `deploy/BENCH_INTEGRATION.md` (connecting a real lab bench) |
| An operator or manager using it | `docs/APPLICATION_MAP.html` (open in a browser: every button and every piece of content, one entry each, with an arrow chain from the click to the database and back, the real code, and numbered screenshots) and `docs/OPERATOR_AND_BACKEND_GUIDE.html` (the background: what the numbers mean, the learning rules, the lab, how to check it) · then "Decide these three things before production" below |
| Someone checking what changed | `docs/CHANGES_2026-11-15_round2.md` (the newest: the second round of 15 November) · `docs/CHANGES_2026-11-15.md` (build 23) · `docs/CHANGES_2026-11-12.md` (what is already known about a column comes first, the Data Grounder's calls, the first question of the start page, the NVMe command errors page, the five files read on all the processor cores) · `docs/CHANGES_2026-11-11.md` (the errors page, the fixed dictionary, the model connection, the Data Grounder, Stop and Delete) · `docs/CHANGES_2026-10-27.md` · `README.md` (design and background) |

**Quick start** (Linux, Python 3.10 or newer; for a first look on your own machine — production goes through
`deploy/AGENT_INSTRUCTIONS.md`)

```bash
unzip <archive>.zip && cd 13_production_app        # every later command runs in this folder
python3 restore_names.py                            # ONLY for the mail-safe archive (*_MAIL_SAFE.zip): renames the 13 browser scripts and 3 shell scripts back to their names
python3 -m venv .venv && . .venv/bin/activate
python3 -m pip install -r deploy/requirements.txt
python3 deploy/preflight.py                         # PASS / WARN / FAIL per check; fix every FAIL (shipped config: 25 PASS, 2 WARN)
./run_tests.sh                                      # offline tests, about 90-110 s: expect "OK" (or "OK (skipped=1)"); writes ~166 MB to runs/_bench (may be deleted)
python3 run_app.py                                  # open http://127.0.0.1:8077 = upload the five per-level CSVs; /packets = the earlier single-CSV workflow   (--port N for another port; --standin = no model)
# to keep the server running independently of the terminal that started it (long loads of multi-GB exports):
systemd-run --user --unit=f2t-app --working-directory="$PWD" --property=KillMode=process --property=EnvironmentFile=$HOME/.config/f2t/env python3 run_app.py   # the env file holds ANTHROPIC_API_KEY=... (mode 600, outside the project)
systemctl --user stop f2t-app                        # stops it; systemctl --user status f2t-app shows it

# the model, for every part (the agents, stage 1 and 2, the error pages): open http://127.0.0.1:8077 -> Settings (top bar) ->
# "Model connection": URL (empty = Anthropic; otherwise the gateway's base address only, without /v1), model name, API key
# (written to ~/.config/f2t/env, file mode 600, never into the configuration or the project, so never into a zip; the page never
# shows the key, only its last 4 characters when it has 12 or more, and where it came from). "Save and test the connection" saves, then makes one real call through the
# model connection and one through what runs the agents, and shows the address it called and what an error means
# (HTTP 402 = the account behind the key has no credit left). run_app.py loads the saved key at every start, and it wins over a
# key already in the environment. Failed calls are retried 4 times (pauses 2, 4, 8 s); without a working model the stand-in
# answers and says so. With a URL of your own, every call goes there (the agents then use this connection, not Claude Code).
```

A first run from a synthetic sample through stage 2, the lab check and the regression test, without a browser, is
a copy-paste walk-through in `deploy/AGENT_INSTRUCTIONS.md` step 2.6 A.

**Decide these three things before production**

1. **The AI endpoint.** Set it on the main page: Settings (top bar) -> "Model connection" (URL, model name, API key),
   then **Save and test the connection** (see the quick start above). The shipped `config/app_config.json` has `llm.backend = "http"`
   (the Anthropic Messages API over HTTPS); the others are `cli` = the `claude` command-line login, `sdk` = the
   Anthropic Python package, `openai-compat` = any chat-completions endpoint, `standin` = no model. The key is never
   written into the configuration or the project: the Settings page keeps it in `~/.config/f2t/env` (mode 600).
   `http` (with the `anthropic` package installed), `cli`, `sdk` and `auto` give the `/packets` stage 1 its AI second
   opinion; with `openai-compat`, `ollama` or `standin` that stage 1 runs without a model. In production set
   `server.lock_endpoint: true` (`deploy/config.production.example.json`) so the Settings page cannot redirect the key
   to another server.
2. **A real lab bench, or simulated.** With `stage2.bench = "synthetic"` (the shipped setting) every lab run is
   **simulated**: the loop works end to end, but procedures found are not physically meaningful. A real drive needs
   `app/bench_hook.py` implemented (`deploy/BENCH_INTEGRATION.md`) and `stage2.bench = "hook"`.
3. **Who may reach the application.** It has **no login of its own** and the operator names are typed by the users
   themselves. It listens on 127.0.0.1 only and must be reached through an authenticating reverse proxy
   (`deploy/DEPLOY.md`). Name at least two admins: approving, retiring and deleting need a second, real person.

## How a defect is named and classified (2026-11-11)

- **The name is made by code, from codes in the recording**, never by the model and never typed by an admin
  (`nvme_hier/terms.py` `defect_term`, dictionary version 3). Its key is: the rule that found the error | the command's
  class and opcode | what happened (aborted by the host, never completed, completed late, slower than usual, error
  status) | the detector's stage code or the official NVMe status code. Example:
  `cmd.timeout|io.read|aborted_by_the_host|nvme.sc.0.07` = "Read aborted by the host, status Command Abort Requested".
  No measured value is in a key: on the S17 sample, the 746 findings of its two latency rules alone (link limit and
  split limit) give 12 keys, and the whole recording's 775 findings give 23 (counted 2026-11-11 with the current code). The key is the defect's identity in the procedural graph (`dg_defect.key` =
  `term:<key>`), so the same kind of defect from any admin, drive or day lands on the same stored defect.
  "Not the same kind of defect?" on the error page writes a note to `knowledge/dictionary/term_requests.jsonl`.
- **The cause is one of 20 fixed keywords** (`terms.CAUSES`, grouped by side: host, driver, device, interrupt path,
  link, PCIe, and `unknown_cause`), decided by fixed rules in a fixed order (`nvme_hier/evidence.py` `decide_cause`)
  from an evidence card computed from the error's own command, never from the window shown: the window size and
  "Isolate again" cannot change it, and it is kept per error (`dg_isolation`). The rules can decide 11 of the 20
  keywords; the other 9 can only be chosen by an admin. The error page has no box for a written cause; it offers only
  the 20 keywords, and the server refuses one outside the list. Every change is kept (`dg_occurrence_log`).
- **The model** writes only why and how around the facts code states (what, when, where, which, who), proposes the
  optimized sequence (the admin edits it before it is stored) and gives the Data Grounder's column meanings. It never
  names a defect and never picks the cause. Every action on the error page is recorded with the admin's name; one
  judgement per error and admin counts (the latest; every row is kept), and the four judgements only re-rank the
  stored solutions.
- **Decided on 2026-11-14, for a command that never completed** (built, its own 18 tests passed on the synthetic sample
  S17 and on hand-made copies of its tree; tested with the whole suite on synthetic data only, never seen on a real capture): the cause rules now
  look at the host's Abort that names the command, at the controller reset and at what the drive answered during the
  wait, all found by identity in the packets file. A command the drive lost while it answered other commands is
  "device internal delay"; "firmware stall" is given only when the drive answered no other command on any queue; an
  Abort the drive had not answered when the reset came before its limit is "host reset or driver recovery". On S17 this
  changes the cause of 6 of the 7 timeout errors (`docs/CHANGES_2026-11-15.md`, section 2).
- **Still open:** the owner's word on those keywords (the builder chose "device internal delay" for the four lost
  Writes of S17; "firmware stall" is one keyword swap away); a real capture (where an export gives only the length of a
  packet's data and not its bytes, such a command gets "unknown cause" with that reason); a cause outside the 20
  keywords can only be "unknown cause"; the judgements only re-rank, which is not yet reinforcement learning
  (`../reports/Procedural graph reinforcement and new causes.md`).
- **Stop and Delete** (main page): Stop is one click, no dialog, and stops every working step at once, including those
  working ahead and their Claude Code calls; afterwards "Run the flow again" starts a new flow, reusing what was already
  approved. Delete asks once and stops a running analysis first. The start page has one button, "Start the flow";
  reference documents are optional.

## Comparing with the analyzer's own error list

The analyzer software (Reports > Error Summary) counts 72 kinds of packet errors. Save that report as a CSV file
(columns Type, Upstream, Downstream, Sideband, Total), put it next to the trace as `Errors.csv` or type its path in
the "Analyzer error summary" box of step 1, and step 2 shows a table: every kind, the analyzer's count, this
analysis's count, and the reason when a kind cannot be seen. For the best match, export the trace with the
analyzer's **Errors** column included: without it, the analyzer writes some error packets without a packet number
and without the error name, and those kinds can only be reported as packets that could not be decoded.


## Step 3 · NVMe commands (added 2026-10-29)

After stage 1 the new step 3 leads with the errors found under NVMe commands, one row per failed command: the command, the parameters
it carries (decoded as NVMe Base 2.0 and the NVM Command Set define them), the measured latency of each step with a
label whose basis is stated (host driver limits, the capture's own percentiles), and the low-level PCIe packets and
errors under it. It needs the payload bytes (hex DATA or the side-car). Runs made before this version have no
command summary until stage 1 is run again. `docs/FAQ.html` entry 41 explains the page.
