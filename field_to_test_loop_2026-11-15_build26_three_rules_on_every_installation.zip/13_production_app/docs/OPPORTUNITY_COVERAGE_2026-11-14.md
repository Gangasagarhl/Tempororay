Superseded on 2026-11-15 by OPPORTUNITY_COVERAGE_2026-11-15.md: the question about VIAVI was put wrongly here, see there.

# No statement is fully covered yet

**Checked on 2026-11-14.** File paths are inside `13_production_app` unless they start with `/`. Test results are from that day's logs in `runs/suite_logs/`.

1. **Of the 16 statements: 0 are covered, 14 are partly covered, 2 are not covered** (S2, faster reproduction in the lab; S11, learning from historical data).
2. **Everything that is covered is covered on synthetic recordings and a simulated drive.** No row of a real analyzer capture was analysed. No generated test ran on a real drive. No engineer was timed.
3. **Gap 1: nothing has touched hardware.** The place where a real lab bench connects is not written (`app/bench_hook.py:47` stops with "not implemented").
4. **Gap 2: the "RL" of the title is weak and outside the main flow.** The shipped search is hill climbing with a bandit. It learns inside one search, forgets afterwards, and exists only in the earlier packet workflow.
5. **Gap 3: three promised things do not exist.** VIAVI files cannot be read. No test reaches the team's validation suite. The 50 % figure was never measured.

All 53 test groups passed that day (44 offline, 9 through the running application). That shows the code does what the tests check on synthetic data. It does not show the statement's promises.

## All 16 statements in one table

| No. | Statement in short | Verdict | Rests on | Main evidence | Gap |
|---|---|---|---|---|---|
| S1 | Isolate defects from a recording | Partly covered | Synthetic recordings | 300 of 300 written-in faults found, 0 false alarms on 665 clean commands (`runs/kpi_proof/kpi_proof.json`) | Cause wrong for 6 of 7 never-completed commands on sample S17 (`README_FIRST.md:98-101`). No real capture. |
| S2 | Reproduce failures faster in the lab | Not covered | Simulated drive | 22 of 22 test scripts reproduce the fault on the simulated drive (same file) | No lab bench. No time measured, with or without the tool. |
| S3 | Automated analysis, from bug to reproduction | Partly covered | Synthetic recordings, simulated drive | Test group `flow`: 72 checks, 0 failed | Reproduction is simulated only. |
| S4 | Look for weaknesses before the field | Partly covered (weak) | Simulated drive, earlier workflow | Sweep: 14 variants, 42 simulated lab runs, 3 filed as tests (`packet_loop.log:165`) | Starts only from a confirmed defect. Not in the main flow. |
| S5 | Pattern recognition, link-layer analysis, LeCroy and VIAVI | Partly covered | Real LeCroy header layout, synthetic rows | Join tests (`unit_joins`): 21 passed | VIAVI: nothing built. Patterns are fixed rules and exact keys. |
| S6 | Model writes the baseline scenario | Partly covered | Synthetic recordings, a real model on a small sample | A real model answered in 3 live test groups | Main flow: the model only picks rows; code writes the first sequence (`nvme_hier/optimise.py:86`). |
| S7 | RL agent optimizes sequence and timing | Partly covered | Simulated drive, earlier workflow | Shipped search and its reward (`stage2/optimizer.py:138`) | Forgets after each search. Reward comes from the simulator's hidden answer. |
| S8 | Most stressful conditions become scripts in the formal suite | Partly covered | Simulated drive | Stress step (`stage2/optimizer.py:243`); 49 of 237 test folders carry a stress entry | No link to any team suite. Scripts never ran on a drive. |
| S9 | Self-optimizing closed loop | Partly covered | Synthetic recordings, simulated drive | Test group `unit_graph`: 12 passed | Only the admin's judgements change the next result. Live store: 0 judgements. |
| S10 | Knowledge base of validated traces and workloads | Partly covered | Code reading, table counts | 65 solutions and 18 procedures stored | Traces are referenced, not stored. Workloads are not archived. Two separate stores. |
| S11 | RL applied to historical data | Not covered | Code reading | 257 returns of 22 known failures found their stored procedure: lookup, not learning | The learner starts empty at every search (`stage2/optimizer.py:128`). |
| S12 | Deployment: suite, AI pipeline, analyzers, scripts | Partly covered | Earlier workflow, simulated drive | Test group `packet_loop`: 65 of 65 checks | Suite is a folder of the application. A person exports the capture. Never run on Windows (`deploy/WINDOWS.md:4-7`). |
| S13 | About 50 % less manual triage effort | Partly covered | Synthetic recordings | Automatic first sort ran on 20 recordings without a person | The 50 % is not measured. |
| S14 | Better accuracy, full coverage, zero leakage | Partly covered | Synthetic recordings, simulated drive | 0 leaked of 257 returns; 300 of 300 found | Only 2 rules and 5 fault kinds measured. 19 of 48 mild slow-downs missed. |
| S15 | AI minimizes test-writing effort | Partly covered | Simulated drive | 22 scripts, 0 hand-written lines (`tests/test_kpi_proof.py:542`) | A fixed template writes the file. No person was timed. |
| S16 | One integrated closed-loop flow | Partly covered | Synthetic recordings | Test groups `flow` (72 checks) and `ui_flow` (40 checks), 0 failed | Search, stress step and workload input sit in a second workflow. |

The checkers gave verdicts per claim for S2, S8 and S13. The overall verdict for these three is set here, by the rule the checkers used for S11: a statement is "not covered" when its defining claim is missing.

## The problem statements hold only as mechanisms (S1 to S4)

**Finding and locating errors works on synthetic data.** The strongest argument against S1: the project's generator writes five kinds of fault, and the project's rules were written to find those five. So 300 of 300 shows the rules agree with the generator. That argument survives. S1 stays "partly" because the cause is also wrong in the one measured case, and because the joins have known open faults for real captures (`docs/CHANGES_2026-11-14.md:343-345`).

**S2 is not covered.** "Faster" is a comparison, and neither side was measured. "In the lab" needs a bench, and none is connected. The only times on record are the application's own: 272.4 s for one run of the earlier workflow on a simulated bench.

**S3 and S4 exist as working chains.** For S3 the last link, precise reproduction, was only simulated; the project says such results "are not physically meaningful" (`README_FIRST.md:69-70`). For S4 the sweep finds the edges of the project's own simulator. Both arguments survive, so both stay "partly".

## The solution statements: rules, a row-picking model, a forgetful search (S5 to S8)

**VIAVI is not supported.** The word appears in a screen label (`app/static/index.html:47`), one comment and four documents. There is no loader, column list, rule or test. The screen label promises more than the code does.

**The model selects; it does not write.** In the main flow the code builds the first sequence, and the model keeps or drops rows. In the earlier packet workflow the model does propose commands and timing. The 22 measured scripts used the stand-in, a fixed program that answers in place of the model (`tests/test_kpi_proof.py:412-422`).

**The search is not what "RL agent" suggests.** The shipped setting (`config/app_config.json`, "optimizer": "bandit") tries small changes and keeps the better one. A bandit, a set of counters, favours the change types that helped. An optional policy-gradient search exists (`stage2/ppo_optimizer.py`). It is not the shipped setting, and it also forgets after each search. In one comparison on the simulator the shipped search reproduced in 14 of 24 runs and the optional one in 15 of 24 (`stage2/bench_optimizers_result.json`). The argument "random search against a toy" does not reach "not covered", because a bandit is a simple form of reinforcement learning.

**No formal suite is linked.** For S8 the stress step runs, but no test checks its result, and "the suite" is the folder `suite/`.

## The goals: the loop turns only when a person judges (S9 to S11)

**The loop is closed through the admin.** Four buttons raise or lower counters, and the ranking changes. The project's own text says this is "not yet reinforcement learning" (`README_FIRST.md:100-101`). The owner's live store holds 1 defect, 2 causes, 1 solution and 0 judgements, so tests turned the loop, not use.

**S11 is not covered.** Nothing learned in one search helps the next. History is a lookup table and a count of clicks. The argument against wins.

## Deployment and outcomes: no measurement with people or hardware (S12 to S16)

**The 50 % is not measured.** The only figure is 93.4 % (lowest) and 93.8 % (median) fewer commands to read, on 20 synthetic runs. It follows from how many faults the test wrote in: 15 in about 240 commands. S13 is "partly" only because the automatic first sort exists.

**"Zero leakage" is 0 of 257 by construction.** The "other recording" is the same recording with another random seed. The simulated drive fails exactly where the test tells it to. A known defect that returns with a different key would count as new, not as a leak.

**S15 and S16.** Zero hand-written lines is measured; effort is not. One tested flow is real, but "the whole" is two workflows with two stores.

## Where the notes disagree

**Did a real model answer?** The brief said the live groups used the stand-in only. Checker B found a real Claude model in three groups. The spot checks support B: logs `isolate.log`, `e2e_hier.log` and `packet_loop.log`, not `flow.log`.

**"No model is ever trained."** Checker A and `README_FIRST.md:18` say this. Checkers C and E point to the optional policy-gradient search, which trains inside one search. The spot checks support C and E on the fact, and confirm it is not shipped.

**Is the flow integrated?** Checker A calls "one integrated flow" covered. Checker E calls it partly covered. The spot checks place the search and the stress step in the earlier workflow, which supports E.

## What would close each gap

1. **A real drive behind the bench hook, with defective and fixed firmware.** Unlocks most: S2, S3, S4, S7, S8, S9, S12, S14 and S15.
2. **One real LeCroy five-file capture with a confirmed defect.** Unlocks S1, S3, S5, S13 and S14, and settles the open join faults.
3. **Bring the reward search and the stress step into the main flow, and keep what a search learns.** Unlocks S7, S11, S16, and parts of S4 and S12.
4. **Timed engineers, with and without the tool, on real captures.** The only way to S13, and to "faster" in S2 and "effort" in S15.
5. **An agreed hand-over into the team's validation suite.** Unlocks S8 and S12.
6. **A VIAVI export, then a column list and loader.** Unlocks S5 and S12. Until then, correct the screen label.
7. **Smaller steps:** cause rules for never-completed commands; the real model on all measured faults; trace windows and workload records in one store; a test for the stress step.

## What was not checked

- The contents of the uploads and samples folders. "Every recording is synthetic" comes from documents and tests.
- The earlier packet engine's figures (437 of 485 and 483 of 485 error types). They were measured in October on one synthetic 4 GB trace and not measured again.
- Which answer seeded the search in the `packet_loop` run: the real model or the stand-in.
- The test plan written by the model: no log of a run with a real model was found.
- Settled by the coordinator, not open: an earlier `flow` run the same evening showed 1 failed check of 72 (`runs/suite_logs/_flow_again.log`). The check looked for the admin's line in the written test file on one line; the file had wrapped that text over two lines. The line was in the file. The test was corrected (`tests/test_flow.py`, `file_says`) and the group then passed, 72 checks, 0 failed.
- The rows of the databases (table counts only), and the coding family (`agentic/family4.py`).
- No checker ran a test. All results were read from the logs.

## The statement as transcribed

From four photographs of a screen. Whether the text continues below the last line cannot be seen.


**Problem Statement:** The current process faces challenges in effectively isolating defects and faster reproduction in lab environments. There is a critical need to integrate automated PCIe trace analysis to streamline the transition from basic bug identification to precise failure reproduction and proactive vulnerability analysis.

**Proposed Solution:**
- Detection & Isolation: Pattern recognition and PCIe/Link Layer trace analysis (LeCroy, VIAVI) to isolate the defect
- Baseline Generation: LLM creates an initial baseline test scenario mimicking the observed failure
- Iterative Optimization: RL agent uses the LLM scenario as a seed to iteratively optimize command sequences and timing parameters, guided by a reward function tied to reproduction of the failure signature
- Integration: Most stressful trigger conditions converted into executable test scripts and integrated into the formal validation suite

**Goals:**
- Self-optimizing analysis framework closing the loop between failure detection and reproduction
- Archives validated results (PCIe traces, external workloads) as a knowledge base
- RL applied to historical data to dynamically optimize test parameters and workload sequences

**Deployment:** Integrated validation suite + AI pipeline (LLM for baseline seeding -> RL Agent for sequence optimization); hardware analyzers (LeCroy/VIAVI) for trace analysis; executable test scripts converted from optimized RL sequences

**Expected Outcomes:**
- Efficiency & Speed: ~50% reduction in manual engineering effort for initial log analysis via automated first-level triage
- Quality & Coverage: Improved defect detection accuracy, comprehensive coverage, zero regression leakage for known failure signatures
- Productivity: AI-driven automation minimizes manual effort in test script design and authoring
