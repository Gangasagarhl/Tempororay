# Changes of 2026-11-15, second round: one REA field, no tool question, the rule hierarchy, the order of the flow, 52 rule families, timing on the graph

This record continues `docs/CHANGES_2026-11-15.md` (sections 0 to 19, the record of build 23). It covers the work done
after build 23, on 15 November 2026, from about 03:40 on. Two research reports came first, both written that
morning: "NVMe command errors become 52 rule families" and "Stored timing values should start every search". The
parts below were then built by builders working side by side, each in files of its own, and joined by a second set of
builders. Each left a report with file names, measured numbers and a list of what was not done. This record repeats
what those reports state. Where two reports disagree, the code was read, and the record says what the code does.

**Brought up to date on 15 November, from 06:30 on.** When this record was first written (05:56), two join reports did
not exist yet: "the rule families of the NVMe command level in the flow" and "the header with the tree, the near-limit
item, the facts of an empty column, the test leaks". Both exist now. They are kept in the project's research notes
(folder "NVMe command level error rules"), outside the application folder. Sections 0, 5, 6, 7 and 12 to 16 were
corrected from them, and section 0a is new: a fault of the engine that could reach the owner, and its fix. After the
two reports the coordinator made the small changes the reports had asked of others (section 12). Each of those was
read in the code before it was written here. Where a report and the code differ, the code is described and the
difference is said.

File paths are inside the application folder (`13_production_app`).

Words used in this record:

- **The admin**: the named person who approves every important step.
- **The stand-in**: the fixed answer the application gives when no model is connected.
- **S17**: the synthetic sample recording `samples/clean_five_files/S17_io_timeout_abort_reset` (608 NVMe commands).
  The three other clean samples are S08, S27 and `demo_225_commands`.
- **The tree**: the five files of one recording joined into one structure (packets, link transactions, split
  transactions, NVMe transactions, NVMe commands).
- **Page 3**: the page "Rules, defects, test cases" of an analysis.
- **The page of one error**: the page that takes one error through the isolation of the defect (stage 1), its cause and
  solution (stage 2) and its test.
- **The procedural graph**: the stored chain of defect, cause and solution.
- **A lab run**: one replay of a sequence of commands on a bench. Every bench in this record is a simulated drive.
- **The REA agent**: the optional agent of the start page that answers from the analyzer's decompiled code (REA stands
  for "Reverse Engineer Anything").
- **The terminal agent**: the agent that works through the opencode program in a terminal and can open files.
- **Family 4**: the coding research family. It researches the data, asks for the requirements, writes the code of a
  rule and proves it.

## 0. In one page

**What the owner asked, in this order.**

1. One field instead of two for the REA agent on the start page.
2. No question "Which tool exported the recording?" on the start page. A folder with no CSV file must say so. The
   terminal agent can be asked about the files of a folder before an analysis exists.
3. A clear hierarchy in the rules library and on page 3: section, then kind of recording, then level, then items, with
   "add" and "edit" in sight. Under Errors, NVMe errors, NVMe command level errors: a researched rule set, coded
   through Family 4. The order is strict: rule, code, run, result approved, errors listed, isolation, cause and
   solution, test.
4. The statement's "timing parameters": timing kept as data on the procedural graph, learned from earlier lab runs
   without training any model, and the search on the page of one error starting from what the graph holds.

**What was built.**

| Request | Built | Section |
|---|---|---|
| 1 | The folder of the REA findings is given in one place, the REA agent card. A new analysis keeps the folder that card has read | 1 |
| 2 | The tool is recognised from each file's own column names and is not asked. "Check" lists every file of the folder. A folder with no CSV table says so and "Start the flow" stays off. The terminal agent has a third place, "a folder before an analysis exists" | 2, 3 |
| 3 | The hierarchy with the new layer "kind of recording", groups of items inside a level, add and edit at every layer. A bridge that turns the rows of a coded rule into errors, only after the admin approves the result. A guard on the page of one error. 52 rule families for NVMe command errors, 38 of them runnable and offered in the library, none chosen in advance | 4, 5, 6, 7 |
| 4 | Three new tables on the procedural graph: lab counts, the timing of a sequence as values, and counts at a value from which a bracket is computed. The search on the page of one error tries what the graph holds first and writes its runs back. A result brought back from a validation suite is counted as lab runs of the solution its test was approved for | 8, 9 |

**The NVMe command level rules from the list to the test, as a person now sees them.** Under Errors, NVMe errors, NVMe
command level errors stand 38 rules in three closed groups (24, 8 and 6 rules, counted in the seed). None is chosen in
advance. Without a model connected, a chosen rule runs the application's reference implementation: no model is called,
and the admin decides one card, the result. With a model connected, Family 4 writes the rule's code: at least 10 calls
to the model and 3 cards (the requirements, the code, the result) for each rule, counted with the stand-in on the
sample S17. The Tester then compares the rows the code found with the reference implementation on the whole recording.
Nothing is listed before the admin approves the result. After the approval each found row is an error of the recording
with a page of its own, and goes through the isolation of the defect, its cause, its solution and its test. When two
chosen rules find the same command, both errors say so on the errors page, each with a link to the other. All of this
was walked on the synthetic sample S17 with the stand-in; no real model has coded a rule (section 6).

**What a person sees differently, page by page.**

- **Start page.** Three fields in the card "New analysis" (name of the person, name of the analysis, folder). No
  question about the tool. No second field for the REA folder: one line says whether this analysis keeps REA findings.
  "Check" says per CSV file which tool it was recognised as, and lists the other files of the folder by their ending,
  with count and size. A folder without a CSV table shows "No CSV table in this folder: the agent families read
  tables." and what the folder holds; "Start the flow" is off. A button "Ask the terminal agent about the files of this
  folder" opens the terminal agent's panel for that folder.
- **Rules library and the plan card of page 3.** The list on the left reads section, kind of recording, level. The
  section "Error roots" is now called "Errors". Under Errors the first kind is "NVMe errors" and its first level is
  "NVMe command level errors". That level shows the two older items first, then three closed groups: "Status the drive
  returned", "Behaviour over time" and "Rules of the protocol". An open group says under its meaning what choosing one
  of its rules costs. Every item card starts with a line that says its place. "Add a section", "Add a kind of
  recording", "Add a level" and "Add an item" are in the list, not in a closed fold. A search field finds an item
  inside one level.
- **Page 3 after the plan.** The chosen items stand under their section, kind, level and group. "Add an item" is there
  after the plan too. The result card of a rule of the admin's own, and of a rule of the application's rule set, says
  that approving files the found rows as errors, and whose rule it is. It also says which of the rows another chosen
  rule already lists, what an empty result means, and when the code and the reference implementation do not find the
  same rows.
- **Errors page.** The errors of a pattern are listed only after its result is approved. Until then a card "Not listed
  yet" says which pattern waits. Under an error of a rule family stands "Belongs together: ..." with the sentence of
  its episode. When another chosen rule found the same command: "The same command is also listed under ...", with a
  link to that error. A card "Rules that listed no error" names the chosen rules that found nothing or could not be
  checked.
- **The page of one error.** Opened for an error whose pattern's result is not approved, it shows only "This error
  cannot be opened yet" with the reason and the way to page 3. For an error found by a rule of the admin's own or by a
  rule of the application's rule set, the rule is said in words and a new row says where the defect's name comes from.
  The list of stored solutions shows two lines kept apart: "judged by admins" and "lab runs". The search part says
  what it started from and what it wrote back, and has a button "Store this sequence as a solution of the cause".
- **The page of the NVMe command rules** (`/nvme-rules`). The 52 rule families in three groups, each with what it
  means, why it happens, how it shows, its columns, its exceptions, and the count for the chosen recording. The bar of
  "check again" ends at 100 per cent.
- **The terminal agent's panel.** Opened for a folder, it says so, and each CSV file the agent wrote has the button
  "Put this CSV file into the folder".

**What is not proven.**

- **Nothing ran on Windows, on a real capture of any measuring tool, on a real drive, or in a real validation suite.**
  Every recording used is synthetic or was written by a test. Every lab run was on a simulated drive. Every "real
  drive" result in the tests is a hand-written result file.
- **No real model was called for any part of this round.** The stand-in or a scripted model answered. The real
  opencode program was not started for the new folder place.
- **The path "with a model connected" was walked without a model.** For a rule family a switch said that a model is
  connected, the stand-in answered for the agents, and programs written by hand for the test stood in for the code a
  model would write (section 6).
- **No page of this round was looked at by a person in a browser.** The builders ran page functions in Node against
  the real answers of the routes and did a syntax check. One joiner opened static pictures of the grouped list in a
  headless browser with no server.
- **The running application had not loaded the Python parts of this round when this record was brought up to date.**
  The application's service on the development machine was last started at 02:55 on 15 November (read from the system
  at 06:35), before this round's code. Page scripts are served from disk, so the new pages are already shown; each was
  written to work with the older server too. New routes answer only after the application is started again. The 38
  rules are put into the rules library by the new code, so the owner's own library shows them only after that start
  (read at 06:35: at that level it holds the two older items only).
- **The whole test suite on the joined code of this round** is the last section. It is written by the coordinator
  after the run.
- **A fault of the engine was found in this round and fixed** (section 0a). Approve pressed at one exact moment could
  leave an analysis standing still until the application was started again. One unit test makes the decision arrive in
  that moment, and one clean run of the tests that had shown the fault followed. One clean run does not prove that a
  race is gone.
- **The 52 rule families were checked on four small synthetic samples.** Those samples hold almost no command errors:
  16 found rows in all (section 6). No family was run on a real export.
- **The gain from stored timing was measured on a simulated drive only.** With history of the same kind the search
  needed fewer lab runs in 28 of 30 cases. With stale or wrong history it was worse in 25 of 30 and in 30 of 30 cases
  (section 8).
- **No model is trained or fine-tuned** anywhere in this round. What the graph stores is a count, a value, or counts
  at a value.

## 0a. A fault of the engine found in this round: a run could stay "running" with nothing running

Sources: the two join reports (the report on the rule families in the flow, its section 7; the report on the header
kept by the loader, its first item) and the code (`agentic/core.py`).

**This fault could reach the owner.** Approve pressed at the wrong instant could leave an analysis standing still. The
analysis stayed "running", its next step stayed "waiting", and nothing ran it. The next start of the server continues
such a run (`resume_all` in the same file; read, not run).

**What was seen.**

- It was seen in `tests/test_application_code_items.py`. That test runs four whole flows at once and approves every
  card the moment it appears. Since this round each of those flows carries 38 more items.
- The builder of the order of the flow saw the symptom first: two tests on the sample S08 had not ended when the
  test's 900 seconds were over (section 5). That builder did not investigate.
- The joiner of the header met it in the second run of three test files: `'no end in 900 s'`, with the run's last sign
  of life 565.2 seconds old. No check had stopped the flow. Every step before was done or approved, none had failed,
  none was running, and no thread had ended with an error.
- The joiner of the rule families met it twice. The first time (the flow "S08 without", last sign of life 572 seconds
  old) the test's records were not read. The second time they were read: the run was "running", its result card
  approved, its next step waiting, no step running, and the last sign of life 466 seconds old.

**The cause.** Each run has one loop, in a thread of its own. The loop read "this step waits for the admin" and was on
its way out. In that moment the admin's decision was stored. The wake-up call of the decision (`Engine.kick`) found
the loop's thread still alive and did nothing. The loop then ended, and nobody ran the next step.

- The fault was in the engine before this round (the file is of 14 November). The joiner of the rule families thinks
  the larger flows of this round made it likelier. That is not measured.
- The joiner of the header showed the fault outside the application, on a run of two steps with a temporary store. As
  the code was, the run finished. With the thread's way out made 0.5 seconds long, the run stayed "running" with its
  second step "waiting".

**The fix** (`agentic/core.py`: `Engine.again`, `Engine.leaving`, `_may_leave`). A wake-up call that finds the loop
alive now tells it to look once more before it ends. The loop asks before it leaves, under the same lock the wake-up
call takes, so no decision can fall between the two. Once the loop has decided to leave, a wake-up call starts a new
loop.

- The joiner of the header had proposed another form of the fix and had not applied it; that report still says
  "reported and not fixed". The code holds the fix described here, made by the joiner of the rule families.

**The test that covers it.** `test_a_decision_that_arrives_while_the_runs_loop_is_on_its_way_out_is_not_lost` in
`tests/test_command_rules_flow.py` (group `unit_cmdflow`). It makes the decision arrive in exactly that moment.

**What the runs after the fix show, and what they do not.**

- The seven test files that hold the four-flows test, on the final code: `93 passed, 2 skipped in 642.20s (0:10:42)`.
- Before the fix the same command had ended `1 failed, 92 passed, 2 skipped in 1160.21s (0:19:20)`. A second run was
  stopped when the same standstill was seen. A third was stopped because it had started 24 seconds before the last
  change to `agentic/core.py`.
- **One clean run does not prove that a race is gone.** The unit test covers the exact order of events that was found.
  Another order that nobody has seen is not excluded by it.

**Not established.**

- For two of the occurrences nobody read the records: the run of the builder of the order, and the first run of the
  joiner of the rule families. Each had the same symptom. Whether each had this cause cannot be said with certainty.
- In the first run of the joiner of the header the two S08 tests failed in another way. That run ended after 573
  seconds, so it was not this standstill. Only the end of its output was kept, and application files changed during
  it. Its cause is not established.
- The fix was not tried with a server that is started again while runs are left "running".
- Nothing of this was seen or tried in the running application, with a real model, or on Windows.

## 1. One field for the REA agent

No separate report exists for this part. What follows was read from the code (`app/static/js/agents.js`,
`app/api/agentic_api.py`, `agentic/admin_ask.py`, `agentic/family4.py`).

- **Before.** The folder of the REA findings could be given in two places on the start page: in the card "New
  analysis" and in the card "REA agent".
- **Now.** There is one folder field, "Folder with the decompiled findings", in the card "REA agent". The card "New
  analysis" has no such field. It says "Three fields. Everything else is asked when it is needed."
- **One line in the card "New analysis" says what will happen.** Either "REA findings: this analysis keeps the folder
  the REA agent below has read (the folder). Family 2 and Family 4 use them only if you tick the box for it at their
  step." Or "REA findings: none. To give them to this analysis, read a folder in the REA agent below before you start;
  they stay optional." The line is redrawn whenever the REA agent card changes.
- **Which folder is kept.** Only a folder the REA agent has read. A folder that was typed or only checked is not kept
  with the analysis. The page sends the folder with "Start the flow"; the server stores it with the analysis.
- **An analysis that exists already.** When "Start the flow" opens an existing analysis (the same name on the same
  folder) and the REA agent has read a folder that differs from the stored one, the stored folder is replaced.
- **The sentence the families give when nothing is kept.** Family 2's step and Family 4 both say: "no REA findings are
  kept with this analysis (the REA agent on the start page must read a folder before the analysis is started)".
  Family 4 says it only when the admin ticked the box and no folder is kept. Without the tick nothing is asked.
- **Unchanged.** The REA findings stay optional. No flow waits for them. Family 2 and Family 4 use them only with the
  admin's tick.
- **Checks.** The browser test file `tests/ui_smoke_flow.py` now looks for the absence of the old field and the
  presence of the line. It acts on the running application and belongs to the coordinator's run of the whole suite.
- **A leftover.** When the folder does not exist, the server still answers "the folder of the REA findings does not
  exist: ... (leave the field empty to start without)". The words "the field" describe the page as it was.

## 2. The start page without the tool question, and a folder with no CSV file

Source: the build report "Start page without the tool question".

- **The question is gone.** The start page no longer asks "Which tool exported the recording?". The tool is
  recognised from each file's own column names. The why-line of the folder field now ends: "Which tool exported them
  is not asked: it is recognised from each file's own column names. **Check** lists every file of the folder, says for
  each CSV table which tool it was recognised as, and names the files that are not tables."
- **What was checked first: the three uses of the stored answer.** (1) The reference document of a file: a tool is
  taken for a file only when the file's own header has at least 5 names and at least 30 in 100 of them are in that
  tool's list. The stored answer never forced a reference document onto a file. (2) The stored meanings: they are
  kept under the tool recognised from the header, never under the stored answer alone. (3) Whether the fixed joining
  strategy is offered: here the stored answer did matter. With "another tool" stored, the five Teledyne LeCroy files
  were refused by the answer alone. Now the files decide, so that case no longer happens.
- **What is stored with a new analysis.** When every recognised table of the folder is an export of one ready tool,
  that tool is stored. Otherwise "another tool" is stored. A folder that mixes exports of two ready tools also gets
  "another tool".
- **An analysis made earlier.** On opening it again, the recognised value replaces only an empty value or "another
  tool". A ready tool kept earlier stays.
- **A request that still sends the tool** (an older page, a test) is checked and stored as before.

**What "Check" shows now.**

- Per CSV file, one sentence. For example: "(file) looks like an export of Teledyne LeCroy PCIe Protocol Analysis: N
  of its M column names are in that tool's column list." Or: "(file) is a CSV file of a tool the application has no
  column list for: the agents learn its columns from the file."
- For the folder: "Recognised from the files: an export of Teledyne LeCroy PCIe Protocol Analysis (5 of the 5 CSV
  tables match that tool's column list)." Or: "Recognised from the files: no tool the application has a column list
  for, so the agents learn the columns from the files themselves, and the fixed joining strategy (written for the
  exports of Teledyne LeCroy PCIe Protocol Analysis) is not offered."
- **A folder with no CSV table.** For example: "No CSV table in this folder: the agent families read tables. This
  folder holds: 12 files ending .etl, 250.0 MB; 2 files ending .xml, 1.1 MB; 1 CSV file that cannot be read as a
  table; 1 subfolder (not read)." "Start the flow" is off. Its tooltip and the message say "Start the flow is off:"
  followed by that sentence. The start route of the server refuses such a folder with the same sentence, so the rule
  holds without the page too. Typing another folder turns "Start the flow" on again.
- **A folder with tables and other files.** "This folder also holds files that are not tables: ..."
- Under the groups of other files: "The agent families read tables: a file that is not a CSV table is not read, and
  must first be turned into one (a CSV file in this folder). The terminal agent can look at these files and say how,
  or turn them into a CSV file itself when they are text (XML, JSON or text logs)."
- Subfolders: "Subfolders are not read: only the files directly in this folder are. Subfolders: ..."
- The button "Ask the terminal agent about the files of this folder" (section 3). It appears only when the terminal
  agent's panel offers the folder place. It is pressed only by the admin.
- The other files are listed from their names and sizes only. Nothing of them is opened. Family 1 still reads only
  the files whose name ends in `.csv`.

**On the analysis page and in the list of analyses** one line is kept with each analysis: "recognised from the files:
an export of (tool)", or "recognised from the files: no tool the application has a column list for (the agents learn
the columns from the files themselves)", or, for an older analysis with nothing stored, "the tool was not recorded for
this analysis: each file's own column names say it".

**In the Manager's review** a file of a recognised tool now reads "An export of (tool), the tool recognised for this
analysis from its files: ..." (read from `agentic/family1.py`; the build report had left this sentence to the
coordinator).

**Tests, as the report gives them.**

- The builder's required set of test files: `135 passed in 23.83s`.
- `tests/flow_any_csv.py`: last lines `PASS  the flow finished`, `PASS  every card of every round is still with the
  flow  | 17`, `0 checks failed`.
- The page scripts pass the syntax check of Node.
- New test file `tests/test_start_without_tool_question.py` (14 test functions, counted in the file). It is in the
  group `unit_anytool` of `run_tests.sh`.
- **Expectations changed, each because the owner decided that the files decide.** In `tests/test_source_tool.py`
  three tests: without the field the stored value is now the recognised one, and the text of the reason for "another
  tool" is new. In `tests/test_any_tool_start.py` the two page-script tests now check that the question is gone. The
  browser test files `tests/ui_smoke_flow.py` and `tests/ui_smoke_agents.py` were adjusted and not run by the builder.

**Only after the application is started again.** With the older server the question is already gone and "Check" lists
the CSV files as before. The recognised lines, the groups of other files and the no-table sentence need the new
server; until then the page says "No CSV table in this folder: the agent families read tables." when the list of
files is empty. New analyses are stored with no tool until then, so the folder alone decides the hierarchy.

Files: `agentic/source_tools.py`, `agentic/family1.py` (`other_files`), `app/api/agentic_api.py` (the inventory route
and the start route), `app/static/js/agents.js`, `app/static/js/source_tool.js` (reduced to the one line kept with
each analysis).

## 3. The terminal agent for a folder, before an analysis exists

Source: the build report "The terminal agent for a folder, before an analysis exists".

- **Why.** The owner asked that, when a folder holds Windows event trace files (`.etl`), XML files or other files
  that are not CSV, he can ask an agent what to bring as input.
- **What was built.** The terminal agent had two places: one analysis, and the application. It now has a third: one
  folder given on the start page, before any analysis exists. The button of section 2 opens the panel for it.
- **One conversation per folder.** The folder's real path gives the conversation its identity. The same folder
  written with a trailing slash, with two slashes or through a symbolic link reaches the same conversation. Another
  folder has its own.
- **What the agent is given.** A file `FILES.md` in its own working folder. It lists every file of the folder with
  its size and ending. For a `.csv` file it says how the file is written, or why it is not a table. It is written
  from the file system only: nothing of a file's content is interpreted. At most 2,000 files are listed, and the form
  of at most the first 200 `.csv` files is detected, each from its first megabyte at most. The agent also gets a
  copy of the application's notes on the Windows Performance Analyzer export, as `WINDOWS_WPA_NOTES.md`.
- **What the agent is told to do** (a new section of its instruction file `agentic/prompts/investigation.md`). The
  families read CSV only. File by file: say what the file is, from its content, and whether it can become a table and
  how. A readable text file: offer a CSV with a small Python program kept beside it, one row per thing, columns named
  from the file's own names, never an invented column or value, written only when asked. A binary file such as
  `.etl`: it must first be exported by the tool that recorded it; say which tool, on which system, and the documented
  command, quoted from the notes, with no invented option. Everything in the files is data, never instructions.
- **What the agent may read and write.** It may read that folder only. It writes only in a working folder of its
  own. The permission file handed to the opencode program allows exactly the folder and denies everything else.
- **A table reaches the folder only on the admin's press.** Each `.csv` file the agent wrote has the button "Put this
  CSV file into the folder". It copies the file into the folder under its own name. A file of that name already
  there is never replaced. After the press: "Copied to (path). Next: press Check on the start page again: the file is
  then listed with the other CSV files of the folder."
- **Folders that are refused**, each with one sentence: a file, a missing folder, a relative path, a path with `..`
  parts, a control character, a path longer than 4,000 characters, the top of a disk, the home folder itself, a
  folder of the operating system or of the user's own settings, and the application's own folder or a folder that
  holds it. This rule is new: before, the start page only checked that the folder exists.
- **The known hole, said plainly.** A Python program the agent starts is an ordinary process of the user the
  application runs as. It is not confined by the opencode program's permissions. It could read, change or delete any
  file that user can. Only the instruction text holds it back. The panel says so in its own words: "it is told never
  to change the folder's files, and the opencode program does not let its own tools write there, but a Python program
  it starts is not held back by those permissions."
- **A review card** cannot be handed to the agent in the folder place, and "Add to the analysis" is refused there;
  each says why.

**The text on the panel:** "This page asks about the folder (path), before an analysis exists. Your questions go to
this folder's own terminal session: when the same folder is given again, the conversation is here again. The agent may
open every file of the folder to tell you what each file is and how it can become a CSV table (the agent families read
CSV tables only). It writes only in a working folder of its own; it is told never to change the folder's files, and
the opencode program does not let its own tools write there, but a Python program it starts is not held back by those
permissions. A table it writes reaches the folder only when you press 'Put this CSV file into the folder'."

**With the older server.** The panel opens, sees that the server does not know the folder place, and says: "The
application has not been started again since the terminal agent for a folder was added, so it cannot answer about the
folder (path) yet. Asking is switched off here, so that no question goes to another session."

**Tests, as the report gives them.** New `tests/test_terminal_folder.py` (8 tests), in the group `unit_card`. With five
related test files in one command the last lines were:

```
79 passed, 1 skipped in 236.86s (0:03:56)
```

The one skipped test was skipped in the same way before the builder's last edit; which test it is was not looked up.
The first full run had one failure: `tests/test_terminal_card.py` pinned the old list of the panel's functions; the
test now expects the list with the new function. The tests use a stand-in for the opencode program. 22 hostile folder
values through four routes all answered with a refusal in one sentence. The browser test `tests/ui_smoke_terminal.py`
got checks for the folder place; they were compiled, not run.

**Not done:** not seen in a browser; the real opencode program was not started; the application was not started
again.

Files: `agentic/investigate.py`, `app/api/investigate_api.py`, `agentic/prompts/investigation.md`,
`app/static/js/terminal_agent.js`.

## 4. The hierarchy of the rules library: section, kind of recording, level, group, items

Sources: the build report "the hierarchy of the rules library" and the join report "groups inside a level".

**The layers.**

| Layer | What it is | Built in | Can the admin add one |
|---|---|---|---|
| Section | One family of things to look for | "Data analytics" (its items give results only) and "Errors" (every error an item finds goes on to stage 1 and stage 2). "Errors" was called "Error roots" before | Yes |
| Kind of recording | One tool's set of files. **New layer** | The Teledyne LeCroy five-file export, and "Other CSV files (any tool)" | Yes |
| Level | One file of a kind of recording, and the place where its items are listed | Five levels under the five-file kind; one level under the other kind | Yes, but not under the five-file kind |
| Group | A named set of items inside a level. **New** | Three groups at Errors, NVMe command level (section 6) | Not from the screen |
| Item | One thing to look for in the data: one count, or one error | The seeded items | Yes |

**The names depend on the section.** Under a section whose items find defects the names read as errors:

| | Under a section that gives results only | Under a section whose items find defects |
|---|---|---|
| First kind | NVMe and PCIe recording (Teledyne LeCroy five-file export) | NVMe errors |
| Its levels, from the top | NVMe command level; NVMe transaction level; Split transaction level; Link transaction level; PCIe packet level | NVMe command level errors; NVMe transaction level errors; Split transaction level errors; Link transaction level errors; PCIe packet level errors |
| Second kind | Other CSV files (any tool) | Errors in other CSV files (any tool) |
| Its level | Other CSV files | Errors in other CSV files |

A section the admin added reads like "Errors" when its items find defects. A kind or a level the admin added has one
name, shown as given in every section.

**The place line.** Every open item card, every add form and every card of page 3 starts with the item's place. The
page writes the sign "›" between the parts, for example: "Errors › NVMe errors › NVMe command level errors › Status
the drive returned › A read could not be recovered". An item in no group has four parts.

**How to add, and where each thing is stored.**

| To add | Where on the screen | What is asked | Stored in |
|---|---|---|---|
| A section | "Add a section", at the end of the list on the left | Name; what it is for; what happens to its items (two choices, none chosen in advance) | `knowledge/rules/sections.json` |
| A kind of recording | "Add a kind of recording", at the end of each section | Name; which files it covers | `knowledge/rules/kinds.json`, list `kinds` |
| A level | "Add a level", at the end of each kind except the five-file kind | Name; the file it reads (a name or a pattern such as `bench_*.csv`); what one row of it is | `knowledge/rules/kinds.json`, list `levels` |
| An item | "Add an item to (level)", under the list of a level, also on page 3 after the plan | Name; in your own words what to look for; on a level with groups also which group, or "No group" | One file per item: `knowledge/rules/(section)/(level)/(item).json` |

- **Edit and Delete** stand beside every section, kind and level the admin made. An item is edited inside its card,
  as before, and keeps its Delete with Restore.
- **Delete is refused while something would lose its place.** A kind that holds a level, a level that holds an item,
  and a section that holds an item or a deleted item that can still be restored are refused with the count and the
  names. The built-in ones are refused as "part of the application".
- **Every field has a reason line under its label.** Nothing is chosen in advance: no group arrives open and no choice
  arrives ticked.
- **No screen shows a stored key.** Keys are only in attributes of the page (tested on the drawn pages).

**Why the stored key of an item did not change.** The key stays "section, level, item". Every stored level belongs to
exactly one built-in kind, so the kind never needs to be in the key. A level the admin adds is stored as a named
group of "Other CSV files" items: its item file lies under the level `other` with one more field that names the
admin's level. So every existing route, the step keys of older runs, the deleted store and the code folders work
without a change. The research had counted what a four-part key would break: every route, the stored step keys of old
runs, and 29 literal keys in 11 test files.

**A rule of an admin's level runs on that level's file.** When the item's procedure is written, only the files of the
analysis that match the level's file name or pattern are offered to the Rule writer. The match ignores upper and
lower case. When nothing matches, the list of files is left as it is.

**The file `kinds.json` is written only when the admin adds, edits or deletes a kind or a level.** A library of the
previous version opens with the default hierarchy and nothing is written. A damaged file reads as "none added". This
differs from the builder's brief, which said "created with defaults on first use".

**Groups inside a level.**

- A level with groups shows the items that are in no group first, in sight, under the line "Listed directly under
  this level, in no group". Then each group as a closed block: its name, a one-sentence meaning, and its count, for
  example "24 items, 1 chosen" on the plan card and "24 items" in the library.
- A group opens when clicked. It opens by itself when it holds the item whose card is open. A closed group that holds
  ticked items names them: "Chosen in this group: (name); (name); and 2 more."
- **A search field over one level**: "Find an item in this level". It matches a word of the item's name, of what it
  looks for, or of its group. Every typed word must match. The result line reads, for example, "6 of the 40 items of
  this level match 'abort'". The field is shown when the level has groups or more than 8 items.
- **The add form asks the group.** "NVMe command level errors lists its items in groups, so that one of many is found
  quickly. Say which group the new item is listed in, or that it is in no group. Nothing is chosen for you." Sent
  without an answer: "choose the group it is listed in, or 'No group': one of the 4".
- **Where a group's name and meaning come from.** From the module that seeds the items
  (`nvme_hier/command_error_rules.py`). When that module cannot be read, the groups are still shown by their names.
- **One stored field, two meanings.** The stored field `group` means "the admin's level" for an item of "Other CSV
  files", and "the group inside the level" for an item of one of the five analyzer levels. They are told apart by the
  item's stored level alone, never by the text of the field. A test makes the two collide on purpose.

**Real numbers from the real seed** (a temporary library, not the owner's): the level "NVMe command level errors"
holds 40 items: the 2 older ones and 38 rule families in three groups of 24, 8 and 6.

**The older names.** "Error roots", "Section 1" and "Section 2" were replaced on the screens and in the texts the
models read: the text of stage 3, the title of the plan step, the sentence about the detector's items, the guide the
application serves, and the list of deleted items. The stored reason of the installation's deleted rules now says "The
section Errors keeps only the NVMe command timeout and the read failure; restore this rule to use it" (the
coordinator's change in `agentic/family3.py`). A library made earlier keeps its stored text; the page shows it with
today's name.

**What cannot be done yet.**

1. A new group cannot be made from the screen. An item cannot be moved to another group. A group cannot be renamed.
2. A level the admin added cannot have groups: the stored field is taken there.
3. A level cannot be added under the five-file kind. The refusal says: "the five levels of this kind are the five
   files the analyzer exports ...". A level there would need reading code.
4. **A numbered section name is still on some texts.** One line of `agentic/family3.py` still builds "Section 2 ·
   Errors". It appears in the text of the plan review, in the Rule writer's review, in the HTML export and in the
   report. The page strips the number from stored reviews. Changing the line needs three test lines changed with it.
5. The plan does not yet mark an item of an admin's level as "cannot run here" when no file of the folder matches the
   level's pattern.
6. After Restore of an item that belongs to an admin's level, the browser selects the plain "Other CSV files" instead
   of the item's level. The item itself is listed under its level.
7. Six older field labels inside an item's own card have a hint and no reason line.
8. Nothing about `.etl` files or another format is built in. The only example is the placeholder of the form.

**Timings** (Node 22, the page's own functions, 40 real seeded items, median of 300 calls): drawing the item picker
of the level takes 0.31 to 0.33 milliseconds with the three groups closed (2 rows built instead of 40), against 0.44
to 0.48 milliseconds before. Page 3 with 43 chosen items takes 1.43 to 1.66 milliseconds, against 1.39 to 1.54
before: it writes more text now. On the server the hierarchy answer takes 39.5 milliseconds, against 32.1 before
(median of 7). The browser's own time to draw was not measured.

**Tests, as the reports give them.**

- `tests/test_rule_hierarchy.py` at the build: `25 passed in 7.17s`. After the join it holds 31 tests in 21 test
  functions: `31 passed in 22.72s`. It is in the group `unit_flowpage`.
- The build's six test files together, run twice in shuffled order: `1 failed, 66 passed in 39.15s` and `2 failed,
  65 passed in 36.52s`. Neither failure came from this work. One: the errors page test did not yet load a function
  another builder had added that morning (`errorsWaiting`); repaired by that builder. Two: a test of
  `tests/test_rule_evidence.py` failed in some orders only, because another test file left the uploads folder of the
  procedures module changed (section 12 says how this was closed).
- The join's three test files, last line of the last eleven runs, all on the final files: `54 passed in 25.08s`.
  Three earlier runs each had one of the two failures above.
- The other rule test files, run once: `64 passed, 1 skipped in 337.23s (0:05:37)`.
- `tests/flow_any_csv.py`: `0 checks failed`.

**Not tested:** anything in a browser against the running application. The clicks that send the forms and the click
that opens a group are covered only by the syntax check and by the route tests.

Files: `agentic/rule_hierarchy.py` (new), `app/api/rules_hierarchy_api.py` (new), `agentic/family3.py`,
`app/static/js/agents.js`, `agentic/pipeline.py`, `app/api/agentic_api.py`, `docs/HOW_THE_APP_WORKS.html`.

## 5. The order of the flow

Sources: the build report "the order of the flow", the join report "the page of one error, the order of the flow, and
lab runs from a validation suite", and, for the same command under two rules and the lock on the tree, the join report
"the rule families of the NVMe command level in the flow".

**The order, as the owner set it.**

1. The rule is written (Family 3, with the admin).
2. Its requirements and its code are written and checked (Family 4).
3. The code runs on the tree, and the Tester checks the result.
4. The admin approves the result.
5. Only then are the found rows listed as errors.
6. Each error: the isolation of the defect (stage 1).
7. Its cause and its solution (stage 2).
8. Its test.

**Three faults the research had found, and what was done.**

| Fault | What it was | What was done |
|---|---|---|
| A rule coded by Family 4 could not go on to isolation | The errors step read the rule's own output as if it were the detector's nine result columns. The first cell of each line was taken for a number of an error that did not exist. Nothing was ever written into the tree for such a rule, so the page of one error had nothing to open | A bridge files the found rows as errors of the tree after the admin approves the result (below) |
| The errors page listed errors before the result was approved | The page built a list from the run's output while the errors step was still empty | A list is taken only from a finished errors step. The older way is kept only for an analysis made before 11 November whose result is approved |
| The page of one error checked no state of the flow | Any error the detector filed could be isolated and given a test, whether or not its pattern was chosen, run or approved | A guard on the routes of the page (below) |

**The required column "row number in the file".** The result of a rule that finds errors on a level of the tree must
have a column named exactly "row number in the file". It holds the number of the found row in that level's file, as
the tree counts it: the first row under the header is row 1. It is a whole number written in digits only. There is
one result line per found row, and no row twice. The same words are used for the errors of other CSV files. The Rule
writer's card says "The procedure is not complete" when the output lacks the column or the procedure reads a file
instead of the tree. The Tester has a new check: "every found row says which row of nvme_command.csv it is (needed to
take it to the isolation of the defect)".

**The bridge** (`nvme_hier/coded_findings.py`, new).

- When the admin approves the result, each found row is filed in the tree as an error, in the same shape as the
  detector's errors. Nothing is listed before the approval.
- The error carries the key of the rule that found it: the word "admin", the section, the level, the item and the
  version of its procedure. No screen shows the key.
- **The same result approved again** keeps the errors of rows found again, with their numbers; removes the errors of
  rows no longer found; and adds the new ones. No error is listed twice. A newer version of the item's procedure
  replaces the errors of the older one. A number once given to an error is never given to another error later.
- **A hostile or broken result is refused in one sentence and nothing is changed**: a row past the end of the file, a
  negative number, zero, text, "1.0", an empty cell, a row named twice, no row column, two row columns.
- **The defect's name.** The fixed dictionary takes the part "what happened" from the admin's rule: "matched the
  admin's rule 'aborted commands'". The command, its status and the rest of the name come from the recording, as for
  the detector's errors. No model names it. On S17 the test's rule "aborted commands" finds one Read (row 144) and the
  name is "Read matched the admin's rule 'aborted commands', status Command Abort Requested". The dictionary itself
  was not changed.
- **A found row below the NVMe command level** is filed with the command above it in the tree. The window of
  commands, the evidence card and the cause rules are then computed from that command, not from the row itself. A row
  that belongs to no command is listed too, but its page has no command to work from. Tested only at the bridge.
- **An item that is deleted.** Its errors leave the tree at the next plan approval or at the errors gate of an
  analysis on that tree, not at once.

**The rule of the guard, in words.** The page of one error waits when an analysis on this recording holds the pattern
that found the error, and no round of that pattern has an approved result. It lets through: a recording that no
analysis uses; an error whose pattern no analysis of this recording holds (the recording's own findings page, as
before); and a pattern with an approved earlier round while a later round waits. The guard is a decision for the
owner to confirm (section 14).

**Where the guard stands.** At the top of nine routes of the page of one error (the header, the window, the chat, the
isolation, the test file and its approval, the judgement, the reorder, the summary). After the join also on the three
search routes that start, stop and store a search, and on four routes of the procedural graph (name a cause, tie the
error to a defect, store a solution, propose the optimized sequence). A request to the graph routes that names no
error works as before. Reading a stored search result is not guarded. Each refusal is the answer "conflict" (HTTP
status 409) with one sentence.

**The exact sentences a person sees.**

- Errors page, card "Not listed yet": "The result of aborted commands waits for your decision on page 3: its errors
  are listed here after you approve it." Or: "aborted commands has not reached its result yet (page 3 shows where it
  stands): its errors are listed here after you approve its result."
- Errors gate (the card before the report): "**Not listed yet:**" with the same sentence per waiting pattern, and
  "**Rules of your own whose rows could not be listed as errors:**" with each refusal. For an analysis without such
  patterns the gate's words are unchanged.
- Page of one error, refused: the heading "This error cannot be opened yet". Then the server's sentence, for example:
  "The result of 'NVMe command timed out' waits for your decision on page 3 of the analysis 'my analysis': this error
  can be opened and worked on (stage 1, stage 2 and its test) after you approve that result." Then "Go to page 3 of
  the analysis (the rules and their results), and approve the result there." Then "Nothing of this error was read or
  changed. After you approve the result there, open this page again from the errors page of the analysis."
- A later request refused by the flow, in the place where the result would have appeared: "**Not yet.**" and the
  server's sentence.
- Result card of a rule of the admin's own: "Approve to accept it and file the 1 row it found as an error of this
  recording (nvme_command.csv): each is then listed on the errors page and goes through stage 1, the isolation of
  the defect, stage 2, its cause and its solution, and its test, on its own page, as an error of the built-in checks
  does. Nothing is listed before you approve. In the name the fixed dictionary gives such a defect, the part 'matched
  the admin's rule 'aborted commands'' comes from your own rule aborted commands; the command, its status and the
  rest of the name come from the recording, as for the detector's errors. No model names it."
- Result card when nothing can be listed: "**No error can be listed from this result:** The result of 'aborted
  commands' does not say which rows of nvme_command.csv it found: it has no column named 'row number in the file'.
  No error is listed for it. Change the rule so that the result must say which rows of nvme_command.csv it found ...
  then code it and run it again."
- Other refusals of the bridge, for example: "Line 3 of the result of the rule 'x' does not name a row of
  nvme_command.csv: its 'row number in the file' is '-3', and it must be a whole number, 1 or more, written in digits
  only. No error is listed for this rule." And: "The result of the rule 'x' names row 999,999 of nvme_command.csv,
  and the tree has no such row (nvme_command.csv has 608 rows). No error is listed for this rule."
- In the errors list and on the page of one error: "aborted commands (found by the admin's own rule)".
- Below the command level: "This rule finds rows below the NVMe command level. Each found row is filed with the NVMe
  command it belongs to in the tree: the window of commands, the evidence card and the cause rules are computed from
  that command, not from the row itself. A row that belongs to no command is listed too, but its page has no command
  to build the window, the evidence card and the test from."

**The page of one error for an error of the admin's rule** (the join).

- "The pattern (rule)" reads: "Found by the admin's own rule 'aborted commands' (version 1 of its procedure, coded by
  Family 4)." The key is never shown, also when the words did not arrive.
- A new row "Where the defect's name comes from" with the sentence of the result card.
- The basis of such an error, on the findings page and wherever a basis is shown: "Source: the admin's own rule in
  the rules library, coded by Family 4 and approved on page 3." with the item's name and its meaning. An item that
  was deleted or moved: "The item 'aborted commands' cannot be read from the rules library any more (it may have been
  deleted or moved), so its meaning cannot be shown here."
- The findings page does not add "(a suspect)" to such an error. That is a decision to confirm (section 14).
- **For an error of a rule of the application's rule set** (section 6) the same rows of the page say whose rule it is,
  for example: "Found by the rule 'A command never completed' of the application's rule set for NVMe command level
  errors (version 1 of its procedure; the rows were found by the application's reference implementation of the rule,
  no model wrote its code)." The header of the page takes these words from the words kept with the error when it was
  filed. Before the join it built them again from the item's stored key and gave "matched the admin's rule 'cmd family
  behaviour 01'".
- **Two places still said "your own rule" for such an error when the join report was written. The coordinator
  corrected both afterwards** (read in the code). The hint under the defect's name now uses the short words the header
  sends: the rule "A command never completed" of the application's rule set for NVMe command level errors
  (`app/static/js/isolate.js`, `ruleShort`). The basis now reads: "Source: the application's rule set for NVMe command
  level errors (nvme_hier/command_error_rules.py, from the research notes on NVMe command level error rules); you
  chose the rule on page 3 and approved its result there." For the admin's version of such a rule it reads: "Source:
  the admin's own version of a rule of the application's rule set for NVMe command level errors; its procedure was
  changed by (the admin), coded by Family 4 and approved on page 3." (`nvme_hier/rules.py`, `basis`, from
  `family3.rule_origin`). No report gives a test result for these two changes.
- **The link to page 3 on the refusal** is built from the address the page was opened with, because the refusal
  carries a sentence and not the number of the analysis. Opened another way, the message points to the list of
  analyses instead.

**Rows found by a rule of the application's rule set** (the 38 rule families of section 6) go the same way since the
join of the rule families. Nothing is listed before the result is approved. Then each found row is an error of the
tree with its own number and its own page. Section 6 says how, and what the screens say.

**The same command found by two rules** (the join of the rule families).

- **What was there.** On S17, with the built-in rule "NVMe command timeout" and the rule family "A command never
  completed" both chosen, the detector lists 7 errors and the family files 6 of its own, on 6 of the same rows.
  Nothing told the admin. With the rules of the join's flow test, 7 rows of S17 are listed by more than one rule, and
  rows 216 and 358 by three.
- **What is built.** One error per rule and row stays. Two errors on one row are not merged into one, because two
  rules on one row can mean two faults: row 216 is an Abort that never completed, and it is also "the host sent an
  Abort".
- **The application says it in three places**, where the admin chooses what to isolate: on the result card of the
  later rule, before anything is filed; on the errors page, on both errors, each with a link to the other; and on the
  errors gate, one line per row. The errors page works it out from the lists, so the order of the approvals does not
  matter.
- **The match is by identity**: the level, and the row's number in the level's file. Never a time stamp.
- **The cost of not merging.** If the admin isolates both, one command gets two defect names on the procedural graph.
  This is a decision for the owner (section 14, decision 41).
- **Not built.** The page of one error itself does not say "the same command is also listed under ..." (section 15).
  The data to say it exists (`pipeline.same_command`).
- Result card: "**The same command, found twice:** 6 of these rows are a command that this analysis already lists as
  an error under 'NVMe command timeout' (rows 155, 216, 295, 358, 443, 509 of nvme_command.csv). After your approval
  it is listed under this rule as well, as an error of its own with its own page; the errors page says on each of the
  two that it is the same command and links the other, so that you do not isolate it twice without knowing."
- Errors page, under "What was found": "The same command is also listed under (the other rule, a link to that error):
  one command, found by more than one rule. Open that error before you isolate this one again."
- Errors gate: "**The same command under more than one rule:** 7 rows are listed as an error by more than one of the
  rules you chose. It is one command, found by each of them for its own reason: the errors page says so on each of
  these errors and links the others, so that you do not isolate the same command twice without knowing." Then, for
  example: "- row 216 of nvme_command.csv: 'NVMe command timeout', 'A command never completed' and 'The host sent an
  Abort'".

**The lock on the tree** (the join of the rule families).

- **Why.** Two analyses of one recording share its tree, and since this round the errors step writes into it. A code
  run reads the tree's file from a process of its own, as a file that cannot change. A write under such a reader, or
  the folding of the tree's write-ahead log into its main file, is undefined for that reader.
- **What is built** (`agentic/procedures.py`: `TreeLock`, `write_tree`, `run_code`). Code runs read together. Filing
  errors waits until none reads. No run starts while a write waits. The log is folded only when nobody reads. There is
  one lock per tree file, inside the application's one process.
- While it waits, the errors step says: "waiting until the code runs that read this recording's tree have finished:
  the errors are filed then".
- **The joiner did not see this fault happen.** It was closed because the join created the writes.
- **Not covered.** The check-again job of the page of the NVMe command rules and the loader also write the tree, and
  they do not take this lock (section 15). The lock was tested as a lock, and the four-flows test passes with it. Two
  real flows that both file rows at the same moment were not tried.

**The whole-flow test** (`tests/test_flow_order.py`, group `unit_floworder`). One flow on S17 with the stand-in: the
built-in timeout rule and a new item "aborted commands" ("commands where ST.SCT is 0 and ST.SC is 7"). It stops at
three points and writes down what the application answers.

- Point 1, the result of the timeout rule is open: its errors step waits and is empty; all nine routes refuse with
  the sentence; the page's own list holds nothing.
- Point 2, the result of the admin's rule is open: the steps came in the order write, research, requirements, code,
  run, test, export, result, errors; the result is one line (row 144, status code type 0, status code 7); no error is
  in the tree yet.
- Point 3, the errors gate: one error on row 144, listed; stage 1 by the stand-in; the name from the fixed
  dictionary; the cause "aborted by the host's tool or test"; a solution stored; the test file written, tried on the
  simulated drive and approved. The status goes new, isolated, cause, solved, tested.

**Tests, as the reports give them.**

- `tests/test_flow_order.py` alone: `29 passed in 56.39s`.
- Nine test files in one command, first run: `2 failed, 145 passed in 684.55s (0:11:24)`. Both failures were in
  `tests/test_rule_evidence.py` and neither came from this work: one asserted the old section name while another
  builder was renaming it; the other is the uploads-folder fault of section 12.
- **The same nine files, second run, on a loaded machine** (about twice as slow; other builders were running their
  tests): `3 failed, 144 passed in 1279.49s (0:21:19)`. Two failures were in `tests/test_application_code_items.py` on
  the sample S08: a whole flow with every item chosen had not ended when the test's 900 seconds were over, and the
  next test then found no report. Both had passed in the first run. **The builder did not investigate further.** The
  two joiners later met the same standstill, found its cause in the engine, and it was fixed (section 0a). For this
  run nobody read the records, so it cannot be said with certainty that it had the same cause. The third failure was
  the uploads-folder fault again.
- `tests/test_agent_layer.py`, the test "several whole flows": `1 passed, 40 deselected in 139.00s (0:02:19)`.
- The join's seven test files, after its last edit: `210 passed, 1 skipped in 390.03s (0:06:30)`. The one skipped
  test skips itself because the sentence it watched was corrected (section 7). The new file
  `tests/test_join_error_page.py` alone: `89 passed in 24.23s` (31 test functions).
- No existing test file was edited by the builder of the order. The joiner of the header later changed one expectation
  in `tests/test_flow_order.py`: a tree fresh from a load now answers "the header stored with the tree", where the
  test had expected "read from the file" (section 7).

**Behaviour that existing callers may notice.** The routes of the page of one error can now answer "conflict" (409).
The Rule writer's card can now say "The procedure is not complete" where a result without the row column was accepted
before (and then listed wrong errors).

Files: `nvme_hier/coded_findings.py` (new), `agentic/pipeline.py`, `agentic/family3.py`, `agentic/procedures.py`,
`app/api/isolate_api.py`, `app/api/dg_api.py`, `nvme_hier/isolate.py`, `nvme_hier/rules.py` (the basis of a rule),
`app/static/js/agents.js`, `app/static/js/isolate.js`, `app/static/isolate.html`.

## 6. The rule set "NVMe command level errors": 52 rule families

Sources: the research report "NVMe command errors become 52 rule families", the build report "the rule set NVMe
command level errors", the join report "the rule families of the NVMe command level in the flow", and the code. Each
statement about the join was read in the code as well; where the two differ, it is said.

**What a rule is.** The owner's definition is the working one: if the export has these columns, and this problem is
there, then this is the pattern. Each family is stored as data with: its name; its group; what it means; why it
happens; how it shows (every sentence with its source); the columns it reads, in both spellings of the export; what
it needs and the sentence it says when that is missing; its exceptions; whose fault it points to; the families it
belongs with; what a Linux host does next; and the places where the sources differ.

**The three groups.**

- **Status the drive returned** (24 families). The drive answered with a status that is not success. The pattern is
  the kind of queue, the command, the status code type and the status code.
- **Behaviour over time** (15 families). The fault is not a status: a command that never completed or completed
  late, the host's Abort, the reset that follows, a slower command, a retry. The pattern is a relation between rows,
  by identity. Time only orders rows and measures.
- **Rules of the protocol** (13 families). A rule of the NVMe protocol that the host or the controller broke, as
  conformance tests check it.

**Two reports give other group sizes.** The research report and one sentence of the build report say 24, 14 and 14.
The module holds 24, 15 and 13 (counted in the code), and the build report's own table agrees with the code. The
total is 52 in every source.

**38 run today, 14 are listed only.** A family that cannot be checked from the NVMe command export, or whose pass is
not built yet, is listed on the page of the NVMe command rules with what it would need. It is not an item of the
library. The research report had estimated, by reading and without running anything, that 37 could be checked from
the command export alone. The built count is 38.

**All 52 families.** "Found" is the number of rows found on the four clean samples, from trees built from the NVMe
command file and the NVMe transactions file of each sample (the build report). "0 in all four" means the family ran
and found nothing.

| No. | Group | Rule family | State | Found on the four samples |
|---|---|---|---|---|
| 1 | Status the drive returned | A read could not be recovered | Runs | 0 in all four |
| 2 | Status the drive returned | A write could not be committed | Runs | 0 in all four |
| 3 | Status the drive returned | An end-to-end protection check failed | Runs | 0 in all four |
| 4 | Status the drive returned | A Compare found different data | Runs | 0 in all four |
| 5 | Status the drive returned | A read of a block that holds no data | Runs | 0 in all four |
| 6 | Status the drive returned | Access refused by security | Runs | 0 in all four |
| 7 | Status the drive returned | The command was not understood or is not supported | Runs | 1 in `demo_225_commands` (row 207, Invalid Command Opcode); 0 in the other three |
| 8 | Status the drive returned | The parameters of an I/O command were rejected for this namespace | Runs | 0 in all four |
| 9 | Status the drive returned | The block range or the capacity was exceeded | Runs | 0 in all four |
| 10 | Status the drive returned | The data pointer of the command is faulty | Runs | 0 in all four |
| 11 | Status the drive returned | The data transfer or the transport failed | Runs | 0 in all four |
| 12 | Status the drive returned | A fused pair of commands was broken | Runs | 0 in all four |
| 13 | Status the drive returned | The command was aborted because the host asked | Runs | 1 in S17 (row 144, a Read); 0 in the other three |
| 14 | Status the drive returned | The command was aborted for a power loss | Runs | 0 in all four |
| 15 | Status the drive returned | An internal error of the drive | Runs | 0 in all four |
| 16 | Status the drive returned | The drive was not ready or busy: try later | Runs | 0 in all four |
| 17 | Status the drive returned | A write was refused: protected or read-only | Runs | 0 in all four |
| 18 | Status the drive returned | A reservation conflict | Runs | 0 in all four |
| 19 | Status the drive returned | A command identifier or sequence fault | Runs | 0 in all four |
| 20 | Status the drive returned | Admin: a queue could not be set up or removed | Runs | 0 in all four |
| 21 | Status the drive returned | Admin: a log page, a feature, an event request or an Abort was refused | Runs | 0 in all four |
| 22 | Status the drive returned | Admin: a maintenance command was refused | Runs | 0 in all four |
| 23 | Status the drive returned | A rule of a zoned namespace was broken | Runs | 0 in all four |
| 24 | Status the drive returned | A path, multi-host, vendor or other-command-set status | Runs | 0 in all four |
| 25 | Behaviour over time | A command never completed | Runs | 6 in S17 (rows 155, 216, 295, 358, 443, 509); 0 in the other three |
| 26 | Behaviour over time | A command completed after the host's limit | Runs | 0 in all four |
| 27 | Behaviour over time | The host sent an Abort | Runs | 5 in S17 (rows 145, 216, 358, 501, 570); 0 in the other three |
| 28 | Behaviour over time | The controller was set up again with commands lost (a reset) | Runs | 3 in S17 (rows 279, 427, 580); 0 in the other three |
| 29 | Behaviour over time | A command much slower than usual for its kind | Runs | 0 in all four |
| 30 | Behaviour over time | A command was sent again although the drive said "do not retry" | Runs | 0 in all four |
| 31 | Behaviour over time | A read of blocks that were deallocated or cleared before | Runs | 0 in all four |
| 32 | Behaviour over time | An admin command that I/O depends on failed | Runs | 0 in all four |
| 33 | Rules of the protocol | A command identifier was used again while its command was still open | Runs | 0 in all four |
| 34 | Rules of the protocol | A status value the specification reserves, or a status cell that cannot be read | Runs | 0 in all four |
| 35 | Rules of the protocol | "Do not retry" disagrees with the status | Runs | 0 in all four |
| 36 | Rules of the protocol | A retry delay was given together with "do not retry" | Runs | 0 in all four |
| 37 | Rules of the protocol | A block range beyond the end of the namespace | Runs | Could not be checked on any of the four: no Identify command of the samples carries the size of the namespace. The family says so in a sentence |
| 38 | Rules of the protocol | A first data pointer that is not aligned | Runs | 0 in all four |
| 39 | Behaviour over time | The whole drive paused | Listed only. Not built: it needs a threshold the admin sets (nothing is chosen in advance) and a pass over every completion time | Not run |
| 40 | Behaviour over time | A completion that matches no open command | Listed only. Such a completion is a row of the NVMe transaction level with no command above it, so it is not in the command export. The detector files it at the NVMe transaction level | Not run |
| 41 | Behaviour over time | A completion on the wrong queue | Listed only. The tree joins a completion to its command by queue and command identifier, so such a completion joins no command and is under no command row | Not run |
| 42 | Behaviour over time | A head pointer fault | Listed only. It would need a column for the submission queue head pointer of the completion; the export has none | Not run |
| 43 | Behaviour over time | More open commands than the queue allows | Listed only. Not built: the running count of open commands per queue; a reset, which is not a command, empties every queue | Not run |
| 44 | Behaviour over time | Order and dependency faults other than the read after a deallocate | Listed only. It would need the fuse bits of a command, the list of active namespaces and the controller's ready state; none is a column of the command export | Not run |
| 45 | Behaviour over time | A late verdict: an event or a log entry that names an earlier command | Listed only. It would need the decoded data of the Get Log Page command and the layout of the event's result, which the research did not quote | Not run |
| 46 | Rules of the protocol | The phase tag did not flip | Listed only. Not built: the pass over the completion rows of one completion queue in their order | Not run |
| 47 | Rules of the protocol | A reserved value was sent in a command | Listed only. It would need the fuse bits and the data pointer selector of the command; the export has no column for them | Not run |
| 48 | Rules of the protocol | A namespace identifier that is not valid for the command | Listed only. It would need the list of active namespaces (the data of an Identify command), which the command export does not carry | Not run |
| 49 | Rules of the protocol | A data transfer above the maximum transfer size | Listed only. It would need the block size of the namespace and the controller's limit (Identify data), which the command export does not carry | Not run |
| 50 | Rules of the protocol | Protection information that does not fit the namespace's format | Listed only. It would need the protection setting of the namespace (Identify data) | Not run |
| 51 | Rules of the protocol | Queue creation, deletion and Number of Queues out of order | Listed only. It would need the controller's resets: a reset deletes every queue and is not a command, so a queue created again after a reset cannot be told from a queue identifier in use | Not run |
| 52 | Rules of the protocol | A transient transport error four or more times, and a retry sooner than the delay | Listed only. Not built: the count of repeated transient transport errors; the delay values are not in the command export | Not run |

**Read the "found" column with care.** The four samples hold almost no command errors: 16 found rows in all, 15 of
them in S17. A count of 0 says the family ran without a fault and found nothing. It does not say the family finds its
case on a real export. Each status family was also tested on one recording made from S17 by changing cells: one case
per status family (24), plus the nearest cases that must not be flagged.

**The timeout chain is linked.** A command that never completed, the host's Aborts, the commands completed as aborted
and the reset are one chain. Each row of the four families carries the same sentence in the column "linked findings".
For example on S17: "Episode 2 of the recording (command rows 34 to 278): 2 commands never completed (rows 155, 216
of the NVMe command file); the host sent 2 Abort commands (rows 145, 216); 1 command was completed as aborted (row
144); the host then set the controller up again at row 279 ...". An episode is the stretch of command rows between
two set-ups of the controller.

**Two things the samples showed.**

- **Which command an Abort names is not in the command export.** The Abort family therefore says "sent while the
  commands in rows ... had no completion" and never claims the link. The link by identity exists only below the
  command level.
- **A command identifier used again while its command is open cannot be seen in a tree. On that half the rule cannot
  fire.** The build report had only read this through. The join tried it with a case made on S17. Command row 43 (I/O
  queue 1, identifier 1) is open from 412,479,130,750 to 412,503,227,750 picoseconds, and row 44 (the same queue, with
  the identifier 2) is sent in between. Row 44 and its NVMe transactions were given the identifier 1. The tree then
  joined every later row with that queue and identifier to row 44. Row 43 was left without a completion row, and the
  detector listed it as never completed. The second completion belonged to no command. The rule found nothing, and
  said that it could be checked. Now the family's text carries this limit with its source, and every result of the
  rule ends with: "Whether an identifier was used again while its command was still open cannot be seen at the command
  level: the tree joins every row with a queue and a command identifier to the newest command with that pair, so the
  earlier command shows as one that never completed. This result holds only commands that use the identifier FFFFh."
  The other half of the rule, the reserved identifier FFFFh, works and is tested. Not built: a rule that reads the
  pattern the tree does show. It needs a real capture first.

**What already existed.** The detector has 13 rules at the NVMe command level. The library offered two of them (the
choice of 9 November): the command timeout and the read failure. The other eleven were in "Deleted items". The module
maps each of the 13 to its families; three have no family (the analyzer's own error cell, its warning cell, and an
inference that assumes 512-byte blocks). Four families reuse the detector's own findings: never completed, over the
host's limit, slower than usual, and the read after a deallocate or after Write Zeroes. The detector itself was not
changed.

**In the library.** The seed writes one item per runnable family (38) under Errors, NVMe command level errors, each
with its name, description, definition, group, columns, fault and procedure. **None is chosen in advance.** The two
older items stay as they were. An existing item is never written over, and a deleted one does not come back. The
result of each item names its rows in the column "row number in the file" (section 5). The list of items carries each
item's group, and each item has a plain description: "List every row of the NVMe command file that matches the rule
'(name)' ((group)): (what it looks for) One line per found row, with the reason in plain words and whose fault it
points to ((fault)). After you approve the result, every found row is an error of the recording and goes on to stage 1
(isolation) and stage 2 (cause, solution and the test case)." The build report had listed both as missing; the join
added them.

**How an item gets its code.**

- **Without a model connected** (the stand-in, and every automatic test). The item runs the application's reference
  implementation of the family. Family 4's research, requirements and code steps are skipped with the sentence "this
  item runs code that is part of the application (nvme_hier/command_error_rules.py): there is nothing to research, to
  ask or to code", followed by "Its code is the application's reference implementation of this rule family ..., used
  because no model is connected to write the code from the rule's text."
- **With a model connected.** Family 4 researches, asks and codes from the item's stored procedure, as for any rule.
  The code is unverified until the admin approves it.
- **Which case holds** is asked of the running engine at every step. The switch is set where the engine is made
  (`app/api/agentic_api.py`): a model counts as connected when a call would not go to the stand-in. That says where a
  call would go. It does not say that the model answers. The build report says the switch "is not set anywhere yet";
  the join set it.
- **A model that is connected and does not answer.** The builder's design gave the stand-in Coder the reference
  implementation's code text for every family, "should the model not answer". The join removed those entries: that
  text would be compared with itself. Now the code card says: "no model answered, and the stand-in writes no code for
  a rule of the application's rule set for NVMe command level errors: with a model connected its code is written from
  the rule's text, so that the Tester's comparison with the application's reference implementation shows something.
  Ask again when the model answers; or choose no model in Settings: this rule then runs the application's reference
  implementation". The flow waits there (decision 14).

**A Coder's code may not reach the reference implementation or the detector's code.**

- The check of a code's text refuses every text that reaches either, except the application's own code text of such an
  item. The sentences that go back to the Coder: "it calls or reads the application's reference implementation of the
  NVMe command level rules (nvme_hier/command_error_rules.py): the code must find the rows itself from the tree, step
  by step as the procedure says, because the Tester compares its rows with that reference implementation, and a
  comparison of the reference with itself shows nothing"; "it calls or reads the detector's code (nvme_hier/rules.py):
  the code must do the procedure's steps itself; what the detector already filed for a recording is read with
  tree.findings(...), and only where the procedure says so"; and "reaches the module (name) through another module
  ((expression)): only what a module itself defines may be used".
- Caught and tested, each way round: an import in either form, the package's attribute, `importlib`, `__import__`,
  `getattr` on a module object, `operator.attrgetter`, a path or a name in any string (reading the file and running
  it), and a module reached through another module. The last way was open before this round for any code. The earlier
  refusals still come beside the new sentence; nothing was weakened.
- **A second line when the code runs.** In the process a Coder's code runs in, the reference module cannot be
  imported. Tested with a text that builds the module's name from pieces.
- **Not closed.** `tree.findings(...)` is a documented call, so a model's code may read what the detector filed for
  the recording. For the four families whose pattern is "the detector's rule judged it", the comparison then shows
  that the code picks the same rows from the detector's findings. It does not show that the code found them by itself
  (decision 44). The file of the reference module also stays readable to the confined process, because the tree
  library is in the same folder.

**The comparison with the reference, made honest.**

- **With a model's code** the Tester reads the result's "row number in the file", runs the reference implementation on
  the whole tree and says "only the code found rows ..." and "only the reference implementation found rows ...". This
  compares two programs.
- **Without a model** both sides are the application's own code. Before the join the Tester compared the reference
  with itself, twice, and said only "the same 6 rows". Now the second of those comparisons is left out for application
  code, and the one line says what it shows: "the rows found are the rows the application's reference implementation
  of this rule finds on the whole recording: the same 6 rows (the application's own code ran both times: this shows
  the result file is whole, not that a second program agrees)".
- For the reference itself a second count is still made another way (a query on the loader's typed columns), for the
  status families and the two families on the "do not retry" bits (the build report; read in the code).
- **When the code and the reference differ**, the result card says so and the admin may still approve: "**The code and
  the application's reference implementation of this rule do not find the same rows:** only the reference
  implementation found row 570. Approving files the rows of the code as they are. To have the code corrected first,
  choose Change and say which rows are missing or too many." (decision 45).
- **When the code listed nothing while the reference finds rows**: "The code of the rule '(name)' listed no row in
  this recording, and the application's reference implementation of the rule does not agree: (which rows). No error is
  listed for it; the code needs to be corrected first (choose Change on its result card)."

**The rows of a rule family become errors of the tree after the approval.**

- **The cause of the gap the build report had left.** One function decided which items file their rows as errors of
  the tree, and it left out every item whose code is part of the application. Without a model a rule family is such an
  item. So the errors step sent it down the older path, which reads the lines of a result as the detector's nine
  columns. The entry's "finding" was then the first cell, the family's name. Nothing was written into the tree, and
  the page of one error had nothing to open.
- **Now** a rule family goes through the bridge of section 5 in both cases, reference code or Family 4's code. Before
  a result is approved there is no error in the tree, the errors step called early files nothing, and all nine routes
  of the page of one error answer "conflict" (409). After the approval the rows are errors with numbers after the
  detector's.
- **What the bridge gained.** Whose rule it is comes in as words; without them the words are those of a rule of the
  admin's own, exactly as before. The result's optional columns "what was found" and "linked findings" are kept with
  each row, and a second run brings them up to date. A result that adds nothing writes nothing into the tree.
- **Run again**, the same result keeps its 6 errors and adds none. **An item that is deleted**: its 6 errors leave the
  tree, the others stay, and the page of such an error answers "not found" (404).
- The stored key of such an error keeps the form of a rule of the admin's own, also for the application's rules, with
  a new stored field that says whose rule it is. No screen shows either.

**Whose rule an error is, in words.** It is decided from two stored facts of the item: its kind, and who last changed
its procedure.

- **The application's rule as seeded.** "What happened" in the defect's name reads "matched the rule '(the family's
  name)'". The error's name reads "(item name) (found by a rule of the application's rule set for NVMe command level
  errors)". The family's name is taken from the module, so an item that was renamed keeps its defect. On S17: "Write
  matched the rule 'A command never completed'".
- **The admin's version** (an admin changed the procedure of such an item): "matched the admin's version of the rule
  '(the family's name)'", with "changed by (that admin)".
- **Anything else** is a rule of the admin's own, with the words of section 5.
- The rule in words, on the result card and on the page of one error: "Found by the rule 'A command never completed'
  of the application's rule set for NVMe command level errors (version 1 of its procedure; the rows were found by the
  application's reference implementation of the rule, no model wrote its code)." With a model it ends: "... (version 1
  of its procedure; the rows were found by code that Family 4 wrote from the rule's text and the admin approved)."
- **To know.** If a later version of the module rewords a family's name, new errors of that family become a new defect
  on the procedural graph (decision 40). The fixed dictionary itself was not changed.

**Episodes.** Each found row stays an error of its own. Its episode sentence is shown on the errors page under "What
was found", for example: "Belongs together: Episode 2 of the recording (command rows 34 to 278): 2 commands never
completed (rows 155, 216 of the NVMe command file); the host sent 2 Abort commands (rows 145, 216); 1 command was
completed as aborted (row 144); the host then set the controller up again at row 279 (...)." In the flow test all 12
errors of the three chosen families carry it, in three episodes. **The limit:** the sentence is whatever the code
wrote. The reference implementation writes it. A model's program carries it only if it works the episodes out, and the
test's hand-written programs leave it empty (decision 42).

**An empty result is a result.**

- For a rule of a section that finds defects, the Tester's failed check "the code wrote rows" became a passed check:
  "the code wrote rows, or found none (an empty list is a result for a rule that finds errors): 0 rows: this rule
  found no row in this recording. For a rule that finds errors an empty list is a result, not a failure (the check
  "the code wrote rows" is kept for rules that give a table: a share, a count, a pattern, where no line means nothing
  was read)".
- This holds for error rules on the tree and on other CSV files alike. The joiner asks whether it should be limited to
  the tree (decision 43). The check stays as it was for every rule of a section that gives results only.
- Result card, nothing found: "Approve to accept it. The rule 'A read could not be recovered' found no row in this
  recording (608 rows read): there is no error to list and nothing to isolate. An empty list is a result, not a
  failure."
- Result card, cannot be checked: "Approve to accept it. The rule 'A block range beyond the end of the namespace'
  cannot be checked on this recording: no Identify command of the recording carries the size of a namespace (column
  NSZE). No error is listed for it; that is what this recording allows, not a failure of the rule."
- The errors page shows the same two sentences, without "Approve to accept it.", in a card "Rules that listed no
  error". The errors gate shows them under "**Rules that listed no error:**".

**The result card when rows were found:** "Approve to accept it and file the 6 rows it found as errors of this
recording (nvme_command.csv): each is then listed on the errors page and goes through stage 1, the isolation of the
defect, stage 2, its cause and its solution, and its test, on its own page, as an error of the built-in checks does.
Nothing is listed before you approve. In the name the fixed dictionary gives such a defect, the part "matched the rule
'A command never completed'" comes from the rule *A command never completed* of the application's rule set for NVMe
command level errors, which you chose for this recording; the command, its status and the rest of the name come from
the recording, as for the detector's errors. No model names it." When another chosen rule already lists some of the
rows, the card says so (section 5, "The same command found by two rules").

**What choosing a rule costs, measured.** Counted with the stand-in on S17 (five files), on 15 November 2026:

| | Steps added to page 3 | Calls to the model | Cards for the admin |
|---|---|---|---|
| No model connected | 8 (the first 3 are skipped) | 0 | 1 (the result) |
| A model connected, the rule reads one file | 8 | 10 | 3 (the requirements, the code, the result) |
| A model connected, the rule reads two files | 8 | 11 | 3 |

- The calls are: 1 or 2 for the data research, 1 for the requirements, 5 questions to Family 1's Managers (one per
  file of the recording), 1 for the Coder, 1 for a second program, 1 for the Tester. A real model needs more when a
  round fails. No real model was counted.
- **Where the screen says it.** Under each open group of the level, in the rules library and in the list of the plan
  card: "What choosing a rule of this group costs: each chosen rule adds 8 steps to page 3 (data research,
  requirements, code, run on the tree, Tester, export, result, errors). With no model connected the first three are
  skipped: the rule runs the application's reference implementation, no model is called, and you decide 1 card (the
  result). With a model connected, Family 4 writes the rule's code from its stored procedure: that is at least 10
  calls to the model for each rule (counted with the stand-in on the sample recording S17, which has five files, on 15
  November 2026: 1 or 2 for the data research, 1 for the requirements, 5 to ask Family 1's Manager of each file, and 3
  for one round of code: the Coder, a second program, the Tester; a real model needs more when a round fails) and 3
  cards for you to decide (the requirements, the code, the result); on its requirements card a real model can also ask
  you what the rule's text leaves open, for example what to do with an empty cell. The Tester then compares the rows
  the code finds with the reference implementation on the whole recording."
- **Not on the plan card itself.** The plan card's stored text also holds the sentence, with which case holds now ("No
  model is connected now: each of them you tick runs the application's reference implementation, with no call to a
  model."). The page does not show the plan card's stored text, so on the screen the cost stands only under each open
  group (section 15). The first version of this record said "the plan card says what choosing costs"; that was read
  from the stored text and is corrected here.
- A test fails when the counts measured in the flow differ from the sentence.

**A fault in the seeded texts, fixed.** With a model said to be connected, the data research read "0h/00h Successful
Completion" in the exception sentence of every status family as one value that no column holds. It put a question on
the requirements card that had to be answered before any code: 24 families, 24 questions. The sentence now reads
"Successful Completion (0h/00h); ..." and the question is gone.

**The check-again job never shows "finished" below 100 per cent.**

- **The cause of the test that failed once at "progress 90".** The job wrote the state "done" first and the 100 per
  cent in a second write. A reader between the two saw a finished job at 90 per cent, the figure of the step before
  it. It was not the longer status call, which the builder had suspected: that call runs before the job exists.
- **Fixed** (`app/jobs.py`): one write says "done" and 100 per cent together. A failed job keeps the percentage it
  had.
- Apart from that, the check-again route no longer counts the families before its job starts. The page's own reading
  still counts them and shows no percentage.

**The page of the NVMe command rules** (`/nvme-rules`) draws the three groups, each family folded, with the count for
the chosen recording or the sentence why there is no number. The families now come from the route. The copy in
`app/static/nvme_command_families.json` is used only when the route sends none, which is the case of a server started
before this round. That file was written again from the module: 25 families changed (the exception sentence of the 24
status families, and the identifier rule). An untouched seeded item takes the new wording at the next seed.

**Measured.**

- 200,000 generated commands: loaded and built in 7.8 seconds; one status family streamed them in 9.5 seconds (21,102
  commands a second, on rows of 13 cells). The chain family took 35.5 seconds with the memory measuring switched on,
  which slows a run several times; the peak memory growth of that run was 8.1 megabytes (the build report).
- All 38 runnable families on one sample tree: 0.27 seconds (S08) to 0.98 seconds (S17) (the build report).
- The whole flow on S17 with the stand-in, every item of the plan chosen (43 items, 38 of them these families), every
  card approved, run alone: 116 seconds as the builder measured it, 90 seconds on the code after the join (the join
  report). No model and no stand-in agent was asked for any of the 38.

**Tests of the build, as its report gives them.** New `tests/test_command_error_rules.py` (16 tests), now the group
`unit_cmdfamilies`; one test added to `tests/test_nvme_command_rules.py`.

- Seven test files in one command, **while other builders ran their tests on the same machine**: `2 failed, 73 passed,
  1 skipped in 834.40s (0:13:54)`. One failure was the new test's own wrong expectation (it forgot the sample's own
  aborted Read, row 144); corrected. The other was the uploads-folder fault of section 13.
- After the repairs, five files in a fixed order: `49 passed in 215.60s (0:03:35)`. `tests/test_nvme_command_rules.py`
  alone: `17 passed, 1 skipped`.
- The builder did not repeat the full seven-file command after the repairs. The join did, on the final code (below).
- `tests/test_agent_layer.py`, "several whole flows": `1 passed, 40 deselected in 135.68s (0:02:15)`.
- `tests/flow_any_csv.py`: `0 checks failed`.
- **To know:** the flows that choose every item now carry 38 more items each, so those tests take several times
  longer. Their limit of 900 seconds per flow held in the builder's runs with four flows at once.

**Tests of the join, as its report gives them. All three lines are on the final code.**

- `tests/test_command_rules_flow.py` (new; 41 test functions counted in the file, 61 tests as the run counts them;
  group `unit_cmdflow`): `61 passed in 86.25s (0:01:26)`.
- The seven files `test_flow_order`, `test_command_error_rules`, `test_nvme_command_rules`, `test_rule_evidence`,
  `test_procedures`, `test_application_code_items` and `test_delete_items`: `93 passed, 2 skipped in 642.20s
  (0:10:42)`.
- `tests/test_agent_layer.py`, "several whole flows": `1 passed, 40 deselected in 79.01s (0:01:19)`.
- **The earlier runs of the seven files, said as they were.** The first: `1 failed, 92 passed, 2 skipped in 1160.21s
  (0:19:20)`; one whole flow stood still (section 0a). The second was stopped by the joiner when the same standstill
  was seen. The third was stopped because it had started 24 seconds before the last change to `agentic/core.py`. The
  fourth is the line above.
- The join report does not name the 2 skipped tests. By the other reports, one test of
  `tests/test_nvme_command_rules.py` skips in every run, and one test of `tests/test_flow_order.py` skips itself since
  the sentence it watched was corrected (section 7).

**What the new flow test does.** One application on a throw-away folder, two flows on S17 with the stand-in.

- **Flow 1, no model.** Chosen: the built-in timeout rule, "A command never completed", "The host sent an Abort", "The
  command was aborted because the host asked", "A read could not be recovered" (finds nothing) and "A block range
  beyond the end of the namespace" (cannot be checked). Checked in this order: nothing is chosen in advance; before
  each result is approved there is no error, and the page of one error refuses; after the approval the rows are errors
  with numbers; the words that say whose rule it is; the episode sentence on all 12 errors; the same command on 7
  rows, in both directions, in the page's own script run by Node; one error through stage 1, the name, the cause, a
  solution and the test, with the status going new, isolated, cause, solved, tested; the two "nothing" sentences on
  the card, the list, the gate and the page; run again; an item deleted; and the flow finishes with no call for a
  family.
- **Flow 2, a model said to be connected.** The stand-in answers, and the Coder's programs are written by hand for the
  test and read the tree themselves. Research, requirements card, code card and run come for each rule. Three programs
  agree with the reference ("the same 6 rows", "the same 1 row", "the same 0 rows"). The fourth, wrong on purpose, is
  caught: "only the reference implementation found row 570", on the Tester's line and on the result card. The error of
  flow 1 that is found again keeps its number.
- **Also:** the ways round the check of a code's text; the refusal when the code runs; whose rule from stored facts;
  the bridge with the words and what each row says; the same-command match by level and row; the job never seen "done"
  below 100 per cent; the made-up identifier case; the identifier FFFFh; the lock on the tree; the lost wake-up of
  section 0a; and that the page scripts compile.

**Expectations of existing tests that the join changed.** Only in `tests/test_command_error_rules.py` (the builder's
file), in three places. (1) The test of the seeded items had expected that the reference text passes the check of a
code's text and is the stand-in Coder's code. It now expects that the text passes only as the application's own code,
is refused otherwise, and is not among the stand-in's codes. (2) The test of the switch had expected the switch to be
unset at its start; the engine now sets it, so the test unsets it itself. (3) Its fixture unsets the switch and puts
it back.

**Not tested** (the join report):

- Nothing in a browser. The page's helpers were run by Node on real answers; the rest of the pages was not looked at.
- No real model: Family 4's path ran with the stand-in and hand-written programs.
- The admin's version of a family was tested as words and as a decision, not through a whole flow.
- A family on a level below the NVMe command; there is none today.
- The lock on the tree under two real flows that file rows at the same moment.
- The engine's fix under a start of the server with runs left "running".
- Windows.
- The route "try on a sample" with the new switch for the application's own code: changed, not called.

Files: `nvme_hier/command_error_rules.py` (new), `agentic/family3.py` (the seed, `rule_origin`, the Tester's check),
`agentic/procedures.py` (the check of a code's text, the lock on the tree), `agentic/pipeline.py`, `agentic/core.py`,
`nvme_hier/coded_findings.py`, `nvme_hier/nvme_command_rules.py`, `app/api/agentic_api.py`, `app/api/isolate_api.py`,
`app/api/nvme_errors_api.py`, `app/jobs.py`, `app/static/js/agents.js`, `app/static/js/nvme_command_rules.js`,
`app/static/nvme_command_families.json` (a copy for a server started before this round; a test keeps it equal to the
module).

## 7. The header of a level's file (`Tree.columns`), kept with the tree at the load

Sources: the build report "the order of the flow", part C; the join report "the header with the tree, the near-limit
item, the facts of an empty column, the test leaks"; and the code.

- **The fault.** `Tree.columns(level)` is the function a coded rule and Family 4 use to ask which columns a level of
  the tree has. It returned the columns of the first row only, and a row keeps only its filled cells. On S17 that was
  20 of the 1,598 named columns of the NVMe command file, and 9 of 402, 14 of 17, 15 of 34 and 5 of 113 for the other
  levels. A column the first row leaves empty looked as if it did not exist. This is why the item "Commands that came
  close to the limit" was told in build 23 that the file has no column for the number of blocks.
- **Now.** `Tree.columns(level)` gives every named column in the file's order. It takes the first of three sources
  that answers: (1) the header stored with the tree; (2) the level's file at the path of the load report, accepted
  only when the first row's cells are all in it; (3) for a reader that can open neither, the columns some row fills. A
  second function says which of the three it was, including "a column empty in every row is not listed".
- **A new function gives the state of one column**: "filled", "in the file, empty in every row", or "not in the file".
  The Coder's context carries it for a column whose first 5,000 rows hold no value.
- The result is always a superset of the old one, so a caller that worked before still works.

**The header is stored at the load** (the join; `nvme_hier/loader.py`: `header_names`, `store_header`, called in
`load_file`).

- The loader keeps the header of each level when its file is loaded, before any row is read, and commits it. The names
  are the named columns in the file's order, from the loader's own reading of the header; spacer cells are left out.
- **Once per file, by the right process.** The load runs in the process that owns the tree's database. The worker
  processes of a load in parts write only their own small part databases, which have no place for a header. The header
  is committed before the parts start, so the fall-back to one core keeps it.
- **Proven by a test that puts the call aside.** Without the call the header is nowhere in the database after a load
  in parts on three processes. With it, the call came once per file, from the loading process, with no row in the
  table yet.
- **A file that is not its level** ("none of the columns of this level are in the file") removes the header an earlier
  load of that level left, because its table has just been made again, empty. An empty file leaves the earlier table
  and its header as they are.
- **A tree loaded before this round** has no stored header and answers as before: from the file, else from the columns
  some row fills. When page 3's plan card is made, the header is written for it, letter for letter as the loader
  writes it. After a load from this round on, that step finds nothing left to write.
- **One writer of the header's form.** The join report left `nvme_hier/tree_api.py` with lines of its own for the
  names and for the write, because that file was not the joiner's. It gave the exact change, tried on a copy of the
  package. The coordinator applied it afterwards: `tree_api.py` now calls the loader's two functions (read in the
  code). Here the report and the code differ, and the code is described.
- **The running server** runs the code of before until it is started again. A recording it loads before that start
  gets no stored header at its load and answers from the file, as before.

**Loading speed: no measurable change.** One sample, the five files of S17 (64 megabytes; the packets file of 52
megabytes is read in 4 parts when worker processes are allowed), loaded into a temporary database by the loader of
before and by the present one in turn, six loads each, at low priority:

| | Before | After |
|---|---|---|
| One core, median of 6 loads | 11.840 seconds | 11.700 seconds |
| In parts, 4 worker processes, median of 6 loads | 4.676 seconds | 4.608 seconds |

- The spread between two loads of the same code is about 1 second, far larger than the difference. The single loads on
  one core ran from 10.957 to 12.065 seconds before and from 11.286 to 12.217 seconds after; in parts from 3.795 to
  6.970 seconds before and from 4.083 to 6.727 seconds after.
- The added lines by themselves, for all five levels with their commit: 3.3 milliseconds (best of 200).
- An earlier round of the same comparison, taken while other builders' tests loaded the machine, gave 15.000 against
  14.980 seconds on one core and 5.703 against 5.961 seconds in parts.
- **This is one sample of 64 megabytes.** No load of several gigabytes was timed.

**What followed.**

- Family 4's check "is this column in the file" is now true for a column the first row leaves empty.
- **The facts of an empty column** (`agentic/family4.py`, `data_facts`). For a column of the tree whose first 5,000
  rows hold no value, the fact now says which of the three states the column is in. For "filled" it adds that the
  first value comes after row 5,000, because "filled" beside a count of 0 would still leave a guess. A column with
  values in the first 5,000 rows is as before, and so are the sentences that stop a flow.
- **What that fact costs.** For a column that is empty in every row or not in the file, the whole level is read before
  the state can be said. Measured on S17: 0.8 milliseconds for a filled column; 8 milliseconds on 608 commands; 0.48
  to 0.68 seconds on 99,088 packets (a file of 49 megabytes). **On a packets file of 6 gigabytes that is about a
  minute for each such column** (the report's estimate from those figures, not a measurement), in each of the three
  places that ask for these facts, with no progress shown. The same cost is already in the Coder's context. A count of
  filled cells per column kept at the load would make it immediate. That is not built (section 15).
- **The item "Commands that came close to the limit"** (`nvme_hier/near_limit.py`). The number of blocks (the column
  NLB) is back among the tree columns of its procedure, and the clause "it is not one of the tree's named columns, so
  it is not listed under the source data" is removed from step 6. No check stops the flow with it. A test of
  `tests/test_flow_order.py` that watched the old sentence now skips itself with that reason.
- **The owner's rules library needs no hand work, by the report.** The item's stored procedure carries no code of a
  Coder, so the next seeding gives it the new wording; a procedure the admin edited is left alone. Both are tested in
  a temporary library. Read for this record at 06:40 on 15 November: the item in the owner's library still holds the
  older wording (no number of blocks among its tree columns). It should take the new wording at the first seeding by
  the new code, which is after the application is started again. That was not seen.
- **To know about that stored item.** Its file was written at 04:44:37 on 15 November, three minutes after
  `nvme_hier/near_limit.py` was changed, with the mark that a seeding wrote it. The join report on the rule families
  concludes that a test or a one-off command of some builder ran a seeding without pointing the knowledge folder at a
  temporary one, and could not tell which. Read for this record: the stored item holds the older wording, and the
  running server, started before this round, still holds the older wording in memory too. So the writer may also have
  been the running server answering a request. Who wrote it is not established. Nothing else in the owner's rules
  folder changed that morning, and it holds no item of a rule family yet.

**Tests, as the join report gives them.**

- `tests/test_join_header.py` (new, 17 tests, group `unit_header`): `17 passed in 19.67s` in the file's order; `17
  passed in 18.22s`, `17 passed in 18.32s` and `17 passed in 15.71s` in three shuffled orders.
- The loader's own files, `tests/test_nvme_hier.py` and `tests/test_hierarchy_parallel.py`: `31 passed in 106.94s
  (0:01:46)`.
- Family 4's files (`tests/test_family4.py`, `tests/test_f4_research.py`, `tests/test_tree_contract.py`,
  `tests/test_family4_real_run_faults.py`): `106 passed in 88.58s (0:01:28)`.
- `tests/test_agent_layer.py`, "several whole flows": `1 passed in 136.74s (0:02:16)`.
- The near-limit files (`tests/test_near_limit.py`, `tests/test_application_code_items.py`,
  `tests/test_rule_evidence.py`), third run: `31 passed in 553.83s (0:09:13)`. `tests/test_application_code_items.py`
  alone: `9 passed in 530.09s (0:08:50)`. The first two runs of the three files failed: `3 failed, 28 passed in
  573.64s (0:09:33)` and `2 failed, 29 passed in 985.32s (0:16:25)`. Section 13 says why.
- **What the new test file holds.** The header stored for each loaded level and for no other; equal to what is read
  from the file; in the file's order; for the samples' layout and for the real export's layout (one name per cell, a
  bare sub-name stored under its group, a cell without a label under its name); the customer's own stored header
  lines; the same text on one core, in parts on three processes, when every worker fails, when no worker can be
  started, for a file under the size for parts and with a row limit; `Tree.columns` without the file; the write on a
  database without the table it needs and on a damaged stored value; the three states of a column on a tree of 5,001
  commands; the near-limit item with the number of blocks; and a library seeded with the older wording.
- **One existing expectation changed:** in `tests/test_flow_order.py` a tree fresh from a load now answers "the header
  stored with the tree"; the test had expected "read from the file". Reading from the file is tested in the new file,
  for a tree without a stored header.

**Not tested** (the join report): nothing in a browser and nothing against the running application; no real model;
Windows; a real export file of the customer (the real layout is tested on the sample's rows rewritten under the real
export's header form, and on the customer's stored header lines without rows); a load of several gigabytes.

Files: `nvme_hier/tree_api.py`, `nvme_hier/loader.py`, `nvme_hier/near_limit.py`, `agentic/procedures.py`,
`agentic/pipeline.py`, `agentic/family4.py`.

## 8. Timing on the procedural graph, and the search that starts from it

Sources: the research report "Stored timing values should start every search" and the build report "the graph learns
from lab runs, and the error page's search starts from it".

**The two sentences of the statement this answers.** "RL agent uses the LLM scenario as a seed to iteratively
optimize command sequences and timing parameters, guided by a reward function tied to reproduction of the failure
signature" and "RL applied to historical data to dynamically optimize test parameters and workload sequences". RL
means reinforcement learning. LLM means large language model.

**What the research found before the build.** The timing search and the procedural graph were not connected in either
direction. The graph learned from the admin only. A search result stayed in one file per error that no later search
read. Recorded timing was lost on the way: the first sequence replaced every recorded gap between 10 microseconds and
100 milliseconds by 10 microseconds, and a search's gaps were keyed by the row numbers of one recording, so another
recording could not use them.

**No model is trained.** Everything stored is one of three things, and each table says which.

**The three tables, in words.**

1. **Lab counts.** One row per lab result of a stored solution: how many runs, in how many the same failure came
   back, the bench ("simulated drive" or "real drive"), what produced the row (the search, the two-way check of a
   written test, or a validation suite), the timing values used, the measured time of the failing command, the
   drive's model and firmware texts, when, and who.
2. **The timing of a sequence, as values.** Per step: the gap before it in microseconds, as recorded and as searched;
   and the queue depth (how many commands are kept open at once). The steps are keyed by the command and its place
   before the failing command, for example "the third Read counted back from the failing command", not by row
   numbers. So a stored timing can be put onto another recording.
3. **Counts at a value.** One row says "at this value of this timing value the failure came back in k of n runs",
   per kind of defect, cause, bench, drive model and firmware.

Rows are only added to the three tables. The code has no change and no deletion on them, and a test checks that. An
older database gains the tables when it is opened.

**The two ledgers, never mixed.**

- **The judgement ledger** is unchanged: the four signals of the admins (correct, correct with edits, wrong, wrong
  with edits). It alone decides the order in which stored solutions are shown.
- **The lab ledger** is new: the lab counts above, per bench. A row of the simulated drive and a row of a real drive
  are never added together, and a search on one bench never starts from the other bench's rows.
- On the page each stored solution shows two lines: "judged by admins: correct 3 of 4 (1 with edits)" (or "not judged
  yet") and "lab runs: the failure came back in 9 of 10 on the simulated drive" (or "lab runs: none yet"). Under
  them: "A lab run is one replay of this solution's sequence on a bench, counted by the search on this page or
  brought back from a validation suite. It never changes a judgement or the order, and a run without the failure
  counts against this solution, not against the cause."
- A test gives a solution judged wrong 50 lab runs with the failure in all 50: it stays where it was.
- **A failed lab run counts against the solution that was tried, never against the cause.** The owner has not
  decided otherwise (section 14).

**Which timing values are tracked.** The gap before each step, in microseconds, and the queue depth. Nothing else.

**How a search turns into counts at a value.** "Came back" is taken from every candidate with the failure in at least
half of at least 2 runs. "Stayed away" is taken only from a candidate without the failure that differs from a
candidate with the failure in that one value and nothing else. A candidate that fails because a command is missing
says nothing about a gap.

**The bracket.** It is computed when the rows are read; nothing is overwritten. For a gap it is: the largest value at
which the failure still came back, and the smallest value above it at which it did not. For the queue depth it is the
other way round. Runs without the failure that lie inside the range where it came back do not move the range; they
are counted and said in words ("a random miss or another condition"). The best stored value is the "came back" value
with the most runs behind it.

**Inheritance.** The rows a search may start from are, in this order: the same drive model and firmware; else another
firmware of the same model, marked "from an earlier firmware of the same drive model: used only as a starting point";
else what the defect holds from other models, marked likewise. Rows of the chosen cause are used when it has any,
else the defect's rows of all causes; the answer says which. Nothing is decayed run by run and no row is changed.

**Which stored solution leads.** One random draw per stored solution of the cause; the highest draw leads. The draw
uses the solution's own lab counts on this bench and the share of all solutions of the cause as a starting belief.
Counts from another firmware or model are scaled so that they are worth at most 2 runs. With no lab run anywhere
every solution has the same chance. **The admins' judgements are not in this formula**: the judgements order what is
shown, the lab counts order what is tried first.

**What the search tries first.** (a) The leading stored solution, put onto this recording by the step key,
unchanged. (b) The first sequence with its timing values set to the best stored values. Each costs 2 lab runs. One
that brings the failure back is confirmed like any candidate. If neither is confirmed the search goes on exactly as
before, starting from whichever of them is nearer to the failure than the first sequence. A stored step that has no
counterpart in this recording is said and dropped.

**An empty graph gives the released search**, run for run. A test compares 4 hidden triggers against the code of the
released zip.

**Write back.** A search that ends by itself writes one lab row for the stored solution that led (its own replay, k
of n) and the counts at a value. Nothing is stored as a solution by the search. A search the admin stopped writes
nothing. When a stored step had no counterpart, the lab row is kept and not counted, because the replay was not the
whole solution.

**The admin's press.** The button "Store this sequence as a solution of the cause" stores the searched sequence as a
new solution of the cause, or as the next version of a stored one. Its timing goes to the second table and the
search's own confirmation becomes its first lab row. It is not judged: no judgement is written for it. It needs the
admin's name and a named cause. The same sequence cannot be stored twice. The why-line says: "Nothing is stored by
itself. Your press stores the sequence the search found ... with its gaps in microseconds and its queue depth, as a
new solution of this error's cause. It is not judged ..."

**The two-way check of a written test is shown and not counted.** That simulated drive has the fault planted from the
test's own plan, so it cannot fail to reproduce. Counting it would inflate "k of n". This departs from the builder's
brief on purpose.

**The recorded gaps now reach the search.** The rows of the first sequence and the failing command had kept the
flattened gaps. They now get the measured gap. On S17, 2 of the first sequence's 3 gaps had been flattened to 10
microseconds; they are now 14 and 12 microseconds. The sequence the page shows and the test written without the
search are unchanged.

**The sentences on the page of one error, after a search** (a measured example from the test run):

- "What the search started from: Started from what the graph holds for this kind of defect and cause: solution 2,
  which came back in 9 of 10 runs on the simulated drive; the gap before the failing command started at 5697
  microseconds (the failure still came back at 45577 microseconds and no longer at 91154 microseconds; from this drive
  model and this firmware)."
- With an empty graph: "The procedural graph holds nothing for this kind of defect yet: the search started from the
  first sequence alone, as it does without the graph."
- "What this search wrote back: written to the graph: solution 2, replayed unchanged, brought the failure back in 9
  of 10 runs on the simulated drive; written to the graph: (number) count(s) at a value for the timing brackets of
  this kind of defect and cause. No judgement and no solution was stored by the search."

**The four constants are chosen, not measured.** None comes from a drive. None was tuned or compared with another
value.

| Constant in `nvme_hier/graph_learning.py` | Value | What it sets |
|---|---|---|
| `PRIOR_RUNS` | 2 runs | How many runs the cause's own lab share is worth in the draw of the leading solution |
| `STALE_CAP_RUNS` | 2 runs | Lab runs from another firmware or drive model count as at most this many runs in the draw |
| `YES_SHARE` | 0.5 | A value counts as "the failure came back" when it did in at least this share of its runs |
| `NO_MIN_RUNS` | 2 runs | A value counts as "the failure stayed away" only after at least this many runs, none with the failure |

**The measurement.** A simulated drive with a hidden trigger, the recording S17, 30 random triggers per row of the
table, 200 lab runs allowed per search. Measured: the lab runs to the first confirmed reproduction (the failure in 8
of 10 runs). A search without one counts as 201. The history is one earlier search of the trigger; it found the
failure in 30 of 30 cases. The acceptance was written before measuring: same-kind history better in at least 20 of
30; stale and wrong history at most 4 runs worse at the median and at most 3 of 30 more searches without a
reproduction.

| History | better | equal | worse | median lab runs | median with no history | median difference | worst single case | not reproduced (with / without) |
|---|---|---|---|---|---|---|---|---|
| Same kind of defect and firmware | 28 | 0 | 2 | 10 | 48 | 38 fewer | 8 more | 0 / 0 |
| Stale (the trigger moved: the gap limit a quarter, one needed command another) | 4 | 1 | 25 | 52 | 48 | 4 more | 48 more | 0 / 0 |
| Wrong (from another trigger) | 0 | 0 | 30 | 52 | 48 | 4 more | 84 more | 0 / 0 |

**Read plainly.**

- **Same-kind history: the claim holds on this simulated drive.** 28 of 30 searches were better; the median fell
  from 48 to 10 lab runs. The 10 runs are the confirmation of the stored solution itself.
- **Stale and wrong history pass the stated no-harm check at the median**: 4 runs more, exactly the cost of the two
  candidates from the graph, and no search was lost.
- **But stale and wrong history were worse in most single cases**: in 25 of 30 and in 30 of 30. Single cases were
  much worse: 48 and 84 lab runs more. The extra first runs shift the simulated drive's random misses and sometimes
  the starting point of the search. So "no harm" is true at the median and for searches lost. It is **not** true case
  by case. Stale history was better in only 4 of 30 cases: it did not help.

**What this measurement does not show.**

- It is a simulated drive, where a trigger stays the same between two searches unless the test moves it. A real drive
  need not behave so.
- The earlier search and the later one use the same recording, so the step key maps every step exactly. Mapping onto
  another recording was tested only on a copy with other row numbers, not on a second set of CSV files.
- Only one earlier search per graph. The draw between several stored solutions was tested for its formula, not
  measured.
- The inheritance from another firmware was tested for what is selected and said, not measured for benefit.

**Where the build differs from the research report's design.** The report proposed a draw that uses both ledgers; the
build keeps the admins' judgements out of the draw. The report proposed that a new firmware copies the bracket and
widens it by a factor; the build copies and widens nothing and only marks such rows as a starting point. The report
proposed tuning one timing value at a time inside the bracket, a spread of values around a stored point that fails,
and marking a stored point stale after repeated failures; none of the three is built. The code is as this section
describes.

**Tests, as the report gives them.** New `tests/test_graph_learning.py` (12 tests), group `unit_graphlearn`. Seven
test files in one command, after the last edit, **while other builders' tests were running**:

```
107 passed in 347.61s (0:05:47)
```

An earlier run of the same command, before the last small edit, ended with `107 passed in 169.46s (0:02:49)`. The new
file alone: `12 passed in 15.46s`. No expectation of an existing test was changed, and none of those files was
edited.

Files: `nvme_hier/graph_learning.py` (new), `nvme_hier/defect_graph.py`, `nvme_hier/replay_search.py`,
`app/api/isolate_api.py`, `app/api/dg_api.py`, `app/static/js/isolate.js`, `app/static/isolate.html`.

## 9. Lab runs from a validation suite's result

Source: the join report "the page of one error, the order of the flow, and lab runs from a validation suite", item 6.

Build 23 could hand approved tests over as a package and bring a result file back (`docs/CHANGES_2026-11-15.md`,
section 6). A result that came back was recorded per test and changed nothing on the procedural graph. Now it can be
counted as lab runs of a stored solution.

- **What ties a test to a solution.** When a test is approved, the test file's path is written on the version of the
  solution it was approved for. This file, that version. That is the only tie used. Not used: the error's number, the
  latest judgement, any time.
- **A test approved without a version of a solution** is tied to nothing, and nothing is invented for it. Two
  solutions that name one test file: tied to neither, said in words.
- **The package now says the tie.** Each entry of the manifest gains the stored solution, and the text manifest gains
  "Stored solution it was written from:". For example: "The test (name) was approved for version 1 of stored solution
  number 4 of the procedural graph: the graph keeps this test file as the approved test of that version. A result
  brought back for this test is counted as lab runs of that solution."
- **When a result is counted.** Only when all of this is stated: the test is tied to a solution; the case is the
  replay of the solution's sequence; the test was not skipped; the result file says which bench it ran on (a real
  drive or the simulated drive); the run looked for the error; the file gives in how many runs the failure came back;
  and the counts and the outcome agree. The bench "real drive" is written only when the file says so.
- **One run is counted once.** The same file again is refused whole, as before. The same run in another file is
  recorded as a result and not counted again. A run is identified by the time stamp the result file states for it,
  compared for equality; that is an identity stated by the file, not a join by time. A result without a time stamp is
  counted once; a second one without a time stamp is not counted, because it cannot be told from the same run given
  twice.
- **A package built before this round** is tied at the time the result comes in, and only while the test file still
  has the fingerprint the package carried.
- **Counting never fails the recording of the result.** Any problem becomes a sentence.

**The sentences beside "Bring in" on part 7 of the page of one error.**

- Counted: "The result of the test (name) was counted on the procedural graph as lab runs of stored solution number
  4: the failure came back in 1 of 3 runs on the real drive. No judgement and no order changed."
- Not counted, always starting "The result of the test (name) was kept, but it was not counted on the procedural
  graph, because ...". The thirteen reasons include: "... the result file does not say which bench it ran on (a real
  drive or the simulated drive)."; "... the application's records do not tie this test to a stored solution (it was
  approved without naming a version of a solution)."; "... the test was skipped, so no run was made."; "... the run
  looked for the fix, not for the error ..."; "... the result file does not say in how many runs the failure came
  back."; and "... a result of this package and this test for the same run ... is already counted there: one run is
  counted once."

**Three decisions the joiner took, for the owner to confirm** (section 14): a run that expects a fixed drive is kept
and not counted; a result without the replay library's own verdict line is not counted; a run is identified by its
time stamp as the file states it.

**Known limits.** If the application stops between marking a run and writing its lab row, that run stays marked and
is never counted. It errs towards not counting; it cannot be counted twice. The table "What came back" does not show
whether a result was counted; the sentence is in the answer of "Bring in", and part 5 shows the lab line.

**Tests.** Part of `tests/test_join_error_page.py` (section 5 gives the result lines). A real-drive result in these
tests is a hand-written result file. The package's own command is run on the simulated drive, never on a real one. No
real validation suite and no real drive were used.

Files: `nvme_hier/handover.py`, `app/static/js/isolate.js`.

## 10. New routes

Each refusal is the answer 400 with one sentence, a thing that does not exist is the answer 404, and a wait for the
order of the flow is the answer 409 (section 5). All new routes answer only after the application is started again.

| Method | Address | What it does |
|---|---|---|
| GET | `/api/agents/rule-hierarchy` | The hierarchy: sections, kinds of recording, levels, groups and items |
| POST | `/api/agents/rule-hierarchy/kinds` | Adds a kind of recording |
| PUT | `/api/agents/rule-hierarchy/kinds/<kind>` | Changes the name or the description of a kind the admin added |
| DELETE | `/api/agents/rule-hierarchy/kinds/<kind>` | Deletes a kind the admin added, when it holds no level |
| POST | `/api/agents/rule-hierarchy/kinds/<kind>/levels` | Adds a level under a kind, with the file it reads |
| PUT | `/api/agents/rule-hierarchy/levels/<level>` | Changes a level the admin added |
| DELETE | `/api/agents/rule-hierarchy/levels/<level>` | Deletes a level the admin added, when it holds no item |
| PUT | `/api/agents/rule-hierarchy/sections/<section>` | Changes the name or the description of a section the admin added |
| DELETE | `/api/agents/rule-hierarchy/sections/<section>` | Deletes a section the admin added, when it holds nothing |
| POST | `/api/agents/rule-hierarchy/items` | Adds an item at a level the admin added, or at a level with groups (with the group, or no group) |
| POST | `/api/agents/terminal/exports/<name>/put` | Copies a CSV file the terminal agent wrote into the folder the panel is open for; never over an existing file |
| POST | `/api/isolate/<upload>/<finding>/search/store` | The admin's press: stores the searched sequence as a solution of the cause, or as the next version of one |
| GET | `/api/dg/solutions/<solution>/lab` | The lab runs of one stored solution |
| POST | `/api/dg/solutions/<solution>/lab` | Adds one lab result to a stored solution |
| GET | `/api/dg/defects/<defect>/lab` | The lab runs of all solutions of a defect |
| GET | `/api/dg/defects/<defect>/timing` | The timing brackets of a defect |

**Existing routes that take or answer something new.**

- `GET /api/agents/inventory` (the "Check" of the start page) also answers the refused files with one line each, the
  groups of other files, the no-table sentence, and what was recognised.
- `POST /api/agents/projects` (the start) no longer needs the tool; it refuses a folder without a CSV table.
- `GET` and `POST /api/agents/terminal`, and its stop route, take a folder as the place.
- `GET /api/hier/nvme_command_rules` also answers the 52 rule families.
- The nine routes of the page of one error, the three search routes and four routes of the procedural graph can
  answer 409 (section 5).
- `GET /api/agents/source_tools` still exists for older pages and tests. No page calls it any more.
- Adding a section still goes through `POST /api/agents/rules/sections`, and adding an item at a built-in level
  without a group through `POST /api/agents/rules`.

The coordinator registered the hierarchy's routes in `app/server.py`.

## 11. New settings

None. No key was added to `config/app_config.json` in this round (the file was last changed at 02:51 on 15 November,
before this round). The four constants of section 8 are in the code, not in Settings. The hierarchy is stored in the
knowledge folder (section 4), not in the configuration.

## 12. The coordinator's own small changes

- **A shared test set-up file, `tests/conftest.py`.** The tests run in a shuffled order on the development machine. A
  test file that built an application of its own on a throw-away folder left the procedures module pointing at that
  folder's uploads. A test file that ran after it and expected the application's own uploads folder then failed, in
  some orders only. This was seen in `tests/test_rule_evidence.py` by four builders of this round (sections 4, 5 and
  6). The file keeps two values as they were when a test file started and puts them back when the file ends: the
  uploads folder, and the switch that says whether a model is connected (set where an engine is made). The second
  value was added after the join report on the header named it. The file imports nothing of the application. The join
  of the header found the cause in the test files themselves and repaired it there (section 13). With those repairs
  this file is a second line: it hides such a leak for every test file, and it covers only these two values.
- **`runs/suite_parallel/make_parts.py`.** It writes the parts of the parallel test run from `run_tests.sh`: the
  offline groups shared out by how long each took in the last run, and one part for the groups through the running
  application. A group never run before counts as 120 seconds.
- **`app/server.py`** registers the hierarchy's routes.
- **`agentic/family3.py`**: the stored reason of the installation's deleted rules now says "The section Errors keeps
  only the NVMe command timeout and the read failure; restore this rule to use it".
- **New groups in `run_tests.sh`**: six in this round (section 13).

**After the two join reports: the points they had asked of others.** Each was read in the code for this record. No
report gives a test result for them; the run of the whole suite is the last section.

- **`nvme_hier/rules.py`, the basis of an error.** For a rule of the application's rule set, or the admin's version of
  one, the kind and the source words now come from the stored facts of the item (`family3.rule_origin`). Before, such
  an error read "the admin's own rule in the rules library, coded by Family 4" (the join report on the rule families,
  "Needed from others", point 1; the words are in section 5).
- **`app/static/js/isolate.js`, the hint under the defect's name.** It uses the short words the header sends when they
  are there. Before, it said "your own rule" for every such error (the same report, point 2).
- **`nvme_hier/tree_api.py`** now calls the loader's two functions for the header, so the header's form has one writer
  (the join report on the header, "Needed from others", point 1; section 7).
- **`tests/conftest.py`** also puts the model switch back after each test file (the same report, point 3).
- **`tests/test_nvme_hier.py`, the test of the stored real header.** It sets the stored customer headers through the
  test's own put-back, so they are put back when the test ends. Before, it could leave the application without the
  stored customer headers when it was the last test of its group to run (the same report, point 5).
- **`nvme_hier/isolate.py`, the stand-in's chat answer** no longer ends a sentence with two full stops for an error of
  an admin's rule.
- **`run_tests.sh`** has four more groups, so every new test file of this round is in a group (section 13).
- **`deploy/build_code_zip.py`** lists this record, so the code zip carries it.

What the two reports asked of others and nobody has done yet is in section 15.

## 13. New test files and groups

`run_tests.sh` held 60 offline groups after build 23. It now holds **66 offline groups** (counted in the file on 15
November at 06:32: 66 lines that start a group before the part for the running application). The 10 groups through the
running application and the browser are unchanged in number.

**Six new groups.**

| Group | What it checks | Test file |
|---|---|---|
| `unit_floworder` | The order of the flow: a rule of the admin's own is written, coded, run on the tree and tested, and only after the admin approves its result are its rows filed as errors of the recording; the page of one error refuses until then; every found row names its row of the file; the header of a level's file | `tests/test_flow_order.py` |
| `unit_graphlearn` | The procedural graph learns from lab runs: lab counts kept apart from the admins' judgements and never changing them, timing kept as values with a bracket, the search on the page of one error starts from what the graph holds and writes back, an empty graph gives the released search, the measurement with same-kind, stale and wrong history on a simulated drive | `tests/test_graph_learning.py` |
| `unit_cmdfamilies` | The rule families for errors at the NVMe command level: 52 families as data with their sources, 38 seeded as items, none chosen in advance, an edited item never written over, the reference implementation on the samples, the comparison of a code with the reference, the speed on 200,000 commands | `tests/test_command_error_rules.py` |
| `unit_cmdflow` | The rule families through the whole flow: nothing listed before a result is approved, rows filed as errors with numbers, the same command found by two rules said, an error of a family through stage 1, name, cause, solution and test, a family that finds nothing, run again without doubling, coded by Family 4 with the comparison when a model is said to be connected, a code that calls the reference refused, the lost wake-up of the engine (section 0a) | `tests/test_command_rules_flow.py` |
| `unit_errjoin` | The page of one error for an error of the admin's own rule: the rule in words and never its key, the refusal of the search and the graph routes until the result is approved, a validation suite's result counted as lab runs once and only when the file states the bench and the counts | `tests/test_join_error_page.py` |
| `unit_header` | The header of a level's file kept with the tree at the load: both export layouts, in parts on several processes and on one, equal to the file's header, the three states of a column in the facts given to Family 4 | `tests/test_join_header.py` |

**Existing groups that gained a test file.**

| Group | Test file added | What it checks |
|---|---|---|
| `unit_anytool` | `tests/test_start_without_tool_question.py` | The start page without the tool question, every file of the folder listed, a folder without a CSV table refused |
| `unit_card` | `tests/test_terminal_folder.py` | The terminal agent for a folder before an analysis exists |
| `unit_flowpage` | `tests/test_rule_hierarchy.py` | The hierarchy of the rules library, its groups and the older names |

**Every new test file of this round is in a group now.** The first version of this record said that four new test
files were in no group. That is no longer so: the coordinator added the last four groups of the table above for them.

**The result lines of each part's own tests** are in sections 2 to 9. In short:

| Part | Result line of its own tests, as its report gives it |
|---|---|
| Start page | `135 passed in 23.83s` |
| Terminal agent for a folder | `79 passed, 1 skipped in 236.86s (0:03:56)` |
| Hierarchy and groups | `54 passed in 25.08s` (three files, the last eleven runs) |
| Order of the flow | `29 passed in 56.39s` (its own file) |
| Rule families | `49 passed in 215.60s (0:03:35)` (five files, after the repairs) |
| Timing on the graph | `107 passed in 347.61s (0:05:47)` |
| Page of one error joined, lab runs from a suite | `210 passed, 1 skipped in 390.03s (0:06:30)` |
| Rule families joined into the flow | `61 passed in 86.25s (0:01:26)` (its own file); `93 passed, 2 skipped in 642.20s (0:10:42)` (seven files, on the final code) |
| Header kept by the loader | `17 passed in 19.67s` (its own file); `135 passed, 2 skipped in 355.49s (0:05:55)` (seven test files of the round in one process, shuffled, without the shared set-up file) |

**Earlier runs that failed, and why.**

- **The order of the flow, second run of nine files, on a loaded machine:** `3 failed, 144 passed in 1279.49s
  (0:21:19)`. Two failures: a whole flow with every item chosen on the sample S08 had not ended in 900 seconds, and
  the test after it then found no report. Not investigated in that run. The same standstill was met later by the two
  joiners, its cause was found in the engine and fixed (section 0a); for this run it cannot be said with certainty.
  One failure: the uploads-folder fault.
- **The rule families, seven files, on a loaded machine:** `2 failed, 73 passed, 1 skipped in 834.40s (0:13:54)`. One
  failure was the new test's own wrong expectation; one was the uploads-folder fault.
- **The join of the rule families, the same seven-file command.** First run: `1 failed, 92 passed, 2 skipped in
  1160.21s (0:19:20)`; one whole flow on S08 stood still (section 0a). The second run was stopped by the joiner when
  the same standstill was seen. The third was stopped because it had started 24 seconds before the last change to
  `agentic/core.py`. The fourth, on the final code: `93 passed, 2 skipped in 642.20s (0:10:42)`.
- **The join of the header, three files** (`tests/test_near_limit.py`, `tests/test_application_code_items.py`,
  `tests/test_rule_evidence.py`). First run, at 04:43: `3 failed, 28 passed in 573.64s (0:09:33)`. One failure was the
  uploads-folder fault: the test process had read `tests/test_application_code_items.py` before its builder added the
  put-back of the uploads folder to it at 04:43:31. The two others were the two tests on S08, and their cause is not
  established: that run ended after 573 seconds, so it was not the standstill; only the end of its output was kept,
  and application files changed during it. Second run, at 05:18, while the joiner's other test batches ran: `2 failed,
  29 passed in 985.32s (0:16:25)`; both were the S08 tests, with the standstill of section 0a. Third run, with nothing
  else of the joiner running: `31 passed in 553.83s (0:09:13)`. The report does not say whether the engine's fix was
  in the code of that third run; a race does not show in every run.
- **Timing on the graph:** the run of 347.61 seconds passed; the same command took 169.46 seconds on a quieter
  machine.
- **One test of the check-again route failed once under load** ("progress 90, expected 100") and passed on every other
  run. The join found the cause and closed it: the job said "done" in one write and 100 per cent in a second (section
  6).

**The uploads-folder fault: the cause confirmed, and where it was repaired** (the join of the header).

- **The cause.** A test helper that builds an application on a throw-away folder (in `tests/test_other_csv_errors.py`,
  used by `tests/test_flow_page_joined.py` too) pointed the procedures module at that folder's uploads, and nothing
  put it back. `tests/test_rule_evidence.py` reads a recording from the application's own uploads folder and then
  found no file. A second value was left the same way: the switch that says whether a model is connected.
- **Shown without the shared set-up file**, which hides the fault. Before the repair, with the leaking file first: `1
  failed, 26 passed in 60.69s (0:01:00)`; with the other file first: `27 passed in 55.69s`. Before the repair, four
  shuffled orders: `27 passed in 32.40s`, `1 failed, 26 passed in 30.33s`, `27 passed in 29.95s`, `1 failed, 26 passed
  in 32.22s`. It failed exactly in the two orders that ran the leaking file first.
- **After the repair**, both orders: `27 passed in 55.94s`, `27 passed in 39.39s`. Five shuffled orders: `27 passed in
  34.36s`, `27 passed in 33.93s`, `27 passed in 48.67s`, `27 passed in 57.74s`, `27 passed in 36.91s`. Three of the
  five ran the leaking file first.
- **The repair.** The helper registers both values with the test's own put-back before it builds the application.
  `tests/test_rule_evidence.py` is unchanged.
- **Two more test files leaked the same way and were repaired**: `tests/test_terminal_folder.py` and
  `tests/test_graph_learning.py`. Each left six values pointed at a folder that is deleted afterwards: the engine's
  start (switched off), the knowledge folder, the settings save, the path of the key file, the uploads folder and the
  model switch. No test of the round's new files failed from it, but a file that ran after either did. With
  `tests/test_rule_evidence.py` after it: `1 failed, 15 passed in 68.71s (0:01:08)` and `1 failed, 19 passed in
  32.99s` before the repair; `16 passed in 65.62s (0:01:05)` and `20 passed in 27.89s` after.
- **The round's test files together**, one process, shuffled, without the shared set-up file. Before any repair, six
  files, three orders: `119 passed, 2 skipped in 172.19s (0:02:52)`, `1 failed, 118 passed, 2 skipped in 143.65s
  (0:02:23)`, `1 failed, 118 passed, 2 skipped in 143.49s (0:02:23)`. After the repairs, six files: `1 failed, 118
  passed, 2 skipped in 182.72s (0:03:02)`, `119 passed, 2 skipped in 152.64s (0:02:32)`, `119 passed, 2 skipped in
  206.72s (0:03:26)`. After the repairs, seven files: `135 passed, 2 skipped in 355.49s (0:05:55)`, `135 passed, 2
  skipped in 352.05s (0:05:52)`, `135 passed, 2 skipped in 360.08s (0:06:00)`.
- **The one failure of those rounds did not depend on the order.** It was the test that keeps
  `app/static/nvme_command_families.json` equal to the module. The file was older than the module while the module's
  builder was still changing it, and the test failed alone as well. The join of the rule families wrote the file
  again, and the three seven-file runs above passed.
- **The test of the errors page** (`tests/test_flow_page_joined.py`) loads the page's functions by name. The page
  gained functions twice that morning, and the test failed each time until the names were added. It now also holds
  what the page says with them. Last line: `15 passed in 5.25s`. If the page gains another function, this test fails
  the same way until the name is added to its list.
- Four files of this join together, in two shuffled orders: `59 passed in 42.19s`, `59 passed in 42.71s`; without the
  shared set-up file: `59 passed in 43.87s`.
- **Still left** (section 15): some test files set the number of worker processes to 1 for the rest of their test
  process.

**Browser test files extended and not run by their builders:** `tests/ui_smoke_agents.py`, `tests/ui_smoke_flow.py`,
`tests/ui_smoke_terminal.py`.

## 14. Decisions for the owner

Every open decision from every report, in one list. Each line ends with the cautious choice that is built today.

**The rule set and the hierarchy**

1. **Where a new error rule lives, so that it is coded by Family 4 and also isolated.** Built: the rows of a coded
   rule are filed as errors of the tree, after the admin approves the result.
2. **The size of a rule: one per family (52) or one per named status (166 in the catalogue).** Built: one per family.
   The detector's generic rule "any status that is not success" stays in "Deleted items".
3. **May a rule of the command level read the completion row under the command** ("do not retry", "more", the retry
   delay, the completion time)? Built: yes, the families read them there, and say "cannot be checked on this
   recording" when the NVMe transactions are not loaded.
4. **Which rules are offered and ticked.** Built: the 38 runnable families are offered and none is ticked in advance.
   The two older items stay as they were. The eleven detector rules stay in "Deleted items".
5. **Which revision of the specification the screens cite.** The three research notes read three revisions (2.3, 2.1
   and 2.0e); figure and section numbers differ in each. Built: each sentence carries its source as its note gives
   it, and "section to be confirmed" is carried where a number was not read from a heading.
6. **The hierarchy: a grouping on the screens with the stored key unchanged, or a four-part key.** Built: the
   grouping, key unchanged. The admin may add kinds of recording and levels; a level only under "Other CSV files" or
   under a kind the admin added.
7. **Whether the five-file kind should ever take a level from the screen.** Built: refused; it would need reading
   code.
8. **Whether the admin should be able to make, rename and move groups.** Built: no; groups come from the seeding
   module.
9. **The numbered section name ("Section 2 · Errors") in reviews, exports and the report.** Built: left as it is on
   those texts; the screens show the name without the number.
10. **The host's limits: the Linux values (30 seconds for I/O, 60 seconds for admin commands, 5 retries), the
    admin's value, or the limit measured from the Abort in the recording.** Built: the families reuse the detector's
    findings, which use the Linux values unless the admin set another limit. The limit measured from the Abort is not
    built.
11. **Test data: five-file sets with the statuses the samples lack** (a read that could not be recovered, a block
    range exceeded, namespace not ready, invalid field, write fault). Built: none generated; the status families were
    tested on a recording made from S17 by changing cells.
12. **The meaning of the column `Time Delta`** ("since the previous row" or "wait to the next command"). Built: no
    family uses it; the family "completed after the host's limit" uses the completion row's time.
13. **May a model's code call the application's reference implementation?** The build report had to allow the import
    and left the question open. Built: refused, with a sentence back to the Coder, so that the Tester's comparison
    shows something (the join; section 6).
14. **A model that is connected and does not answer, for a rule family.** Built: no code is written, the code card
    says so, and the flow waits there. The admin asks again, or chooses no model in Settings so that the rule runs the
    reference implementation. The builder's design had given the stand-in the reference code; the join removed that.

**The order of the flow**

15. **The rule of the guard on the page of one error** (section 5): wait only when an analysis on this recording
    holds the pattern and no round of it has an approved result. Built: as stated; a recording no analysis uses is
    let through.
16. **Must a detector item be approved before it runs?** Built: unchanged; the detector's code counts as verified,
    and only its result is approved.
17. **An error found below the command level is filed with the command above it.** Built: so; a row that belongs to
    no command is listed, and its page has no command to work from.
18. **An error of the admin's rule is shown as firm on the findings page**, not as "a suspect". Built: firm.
19. **When the errors of a deleted item leave the tree.** Built: at the next plan approval or errors gate, not at
    once.

**Timing on the graph**

20. **Should a failed lab run also count against the cause?** Built: no, against the solution only.
21. **Should a lab success raise the cause's weight?** Built: no; only the admin's choice counts for a cause.
22. **Should the lab ledger change the order of the solutions, or only be shown beside the judgements?** Built: shown
    beside. The judgements alone order what is shown; the lab counts order what the search tries first.
23. **How many lab runs is one judgement worth?** Built: no exchange; the judgements are not in the draw.
24. **May a solution judged wrong by admins still lead a search?** Built: yes, because the judgement plays no part in
    what is tried first.
25. **Should the two-way check of a written test stay "shown, not counted"?** Built: shown, not counted.
26. **The four constants** (`PRIOR_RUNS` 2, `STALE_CAP_RUNS` 2, `YES_SHARE` 0.5, `NO_MIN_RUNS` 2). Built: chosen by
    the builder, to be measured on a real bench.
27. **Does a fitted statistical model, such as a Gaussian process, count as "training a model"?** Built: nothing is
    fitted; only counts and a random draw from them.
28. **Which timing values matter most on the owner's bench?** Public reports point to the idle gap and the
    power-saving limit first. Built: the gap before each step and the queue depth only.
29. **Should host settings (power saving, time limits) become searchable?** They change the scenario and must be
    reported as changed. Built: not searchable.
30. **The lab-run budget per search on the real bench.** Built: not set; the measurement used 200 runs on the
    simulated drive.
31. **Should the written test also get the measured gaps?** The first sequence still flattens gaps between 10
    microseconds and 100 milliseconds. Built: only the search gets the measured gaps; the written test is unchanged.
32. **How the sentence names a stored solution: by its stored number or by its place in the list.** Built: by its
    stored number.

**Lab runs from a validation suite**

33. **A run that expects a fixed drive.** Built: kept, not counted. A row "0 of n" would count against the solution,
    and on a fixed drive the failure staying away says nothing against it.
34. **A result without the replay library's own verdict line** (a suite that writes its own result file). Built: not
    counted, because "passed" alone does not say in how many runs the failure came back.
35. **A run is identified by its time stamp as the result file states it.** Built: so.

**The start page and the terminal agent**

36. **A folder that mixes exports of two ready tools.** Built: stored as "another tool".
37. **An analysis that holds a ready tool from earlier.** Built: it keeps it; the recognised value replaces only an
    empty value or "another tool".
38. **Which folders the terminal agent refuses** (system folders, settings folders, the application's own). Built:
    the list of section 3.
39. **Whether the terminal agent for a folder may be used on real captures before its Python is confined.** Built:
    it ships; the panel states the hole; a table reaches the folder only on the admin's press.

**The rule families in the flow** (from the join report on the rule families)

40. **The words in a defect's name for a rule of the application's rule set.** Built: "matched the rule '(the family's
    name)'", with the name taken from the module, so an item that is renamed keeps its defect. When an admin changed
    the procedure of such an item: "matched the admin's version of the rule '...'". To know: if a later version of the
    module rewords a family's name, new errors of that family become a new defect on the procedural graph.
41. **The same command found by two rules: one error, or one for each rule?** Built: one for each rule and row, never
    merged, and said on the result card, on both errors of the errors page and on the errors gate. If the admin
    isolates both, one command gets two defect names on the graph.
42. **The commands of one episode** (never completed, the host's Aborts, completed as aborted, the reset): **one error
    for the episode, or one for each found row?** Built: one for each found row; each shows the sentence of its
    episode under "Belongs together".
43. **An empty list counts as a result for every rule of a section that finds defects**, on the tree and on other CSV
    files alike. Built: both. The joiner asks whether it should be limited to rules on the tree.
44. **May a model's code read what the detector already filed for the recording** (the documented call
    `tree.findings`)? Built: yes. For the four families that reuse the detector's findings, the Tester's comparison
    then shows only that the code picks the same rows from those findings.
45. **May the admin approve a result when the code and the reference implementation do not find the same rows?**
    Built: yes. The card says the difference in words and "Approving files the rows of the code as they are"; Change
    sends the code back.

## 15. Not done, known limits

Gathered from every report. Where a later joiner or the coordinator did the thing, the code was read and the point is
left out.

**For all parts**

- Not run on Windows. Not run on a real capture of any tool. Not run on a real drive or a real bench. Not run in a
  real validation suite.
- No real model was called. The real opencode program was not started for the folder place.
- No page of this round was looked at by a person in a browser against the running application.
- The application was not started again by any builder. A server started before this round has not loaded the Python
  parts.

**The engine (section 0a)**

- The fix of the lost decision is covered by one unit test and one clean run of the tests that had shown it. One clean
  run does not prove that a race is gone.
- The fix was not tried with a server that is started again while runs are left "running".
- For two of the occurrences nobody read the records, and the two S08 failures of the header joiner's first run have
  no established cause.

**One REA field (section 1)**

- The server's refusal for a missing REA folder still says "leave the field empty".
- No test of this part was run by a builder; the browser test that checks it acts on the running application.

**The start page (section 2)**

- Family 1 still reads only files whose name ends in `.csv`.
- The other files are listed by name and size only; nothing says what they are until the terminal agent is asked.

**The terminal agent for a folder (section 3)**

- A Python program the agent starts is not confined. Only the instruction text holds it back.
- The session of a folder stays in the application's session store after the folder is no longer used.
- Whether the real opencode program accepts the folder's permission exactly as it does for an analysis's data folder
  was not tried.

**The hierarchy (section 4)**

- The eight points under "What cannot be done yet".
- Above all point 4: the title of a section still reads "Section 2 · Errors" in the text of the plan review, in the
  Rule writer's review, in the HTML export and in the report. The name "Errors" is right; the number is still there.

**The order of the flow (section 5)**

- **The page of one error does not say "the same command is also listed under ...".** The result card, the errors page
  and the errors gate say it. The data to say it on the page exists.
- **The check-again job of the page of the NVMe command rules and the loader write the tree without the lock on the
  tree.** Only the code runs, the filing of errors and the removal of a deleted item's errors take it.
- The lock on the tree was not tried under two real flows that file rows at the same moment.
- The page of one error for an error with no command above it was not tested.
- The guard on the search and graph routes was tested with hand-made flow records, without the engine object; the path
  with the engine object is covered only for the nine routes of the page.
- The refusal does not carry the number of the analysis, so the link to page 3 works only when the page was opened
  from the errors page.
- A known hazard, not new: when a timing limit is applied again, the detector numbers all errors again by time, and
  when the rules are run fresh the table is dropped. Errors filed by a rule of the admin's own or by a rule family are
  then numbered again or lost like the detector's; the item must be run again.
- The two flow failures of the order builder's run on the loaded machine (the sample S08, 900 seconds) were not
  investigated in that run (section 0a).

**The rule families (section 6)**

- 14 of the 52 families do not run.
- The "used again while open" half of the command identifier family cannot be seen in a tree. The family says so in
  every result and finds only the reserved identifier value. A rule that reads the pattern the tree does show is not
  built.
- **The cost sentence stands under each open group, not on the plan card itself.** The plan card's stored text holds
  it; the page does not show that text.
- No real model has coded a rule family. The path with a model was walked only with a model "said to be connected",
  while the stand-in answered and programs written by hand for the test stood in for the Coder's code.
- A model's code may read what the detector filed (`tree.findings`). For the four families that reuse the detector's
  findings the comparison with the reference then does not show an independent finding (decision 44). The file of the
  reference module stays readable to the confined process.
- The episode sentence ("Belongs together") is there only when the code wrote it. The reference implementation does; a
  model's code need not.
- The admin's version of a rule family was tested as words and as a decision, not through a whole flow.
- No family works on a level below the NVMe command, so that path has no test with a family.
- The route "try on a sample" was changed for the application's own code and not called by a test.
- The count of the families for a recording is made by a pass up to 10,000 commands, above that by a query only.
- Carried from the research and not verified: the admin command code numbers (the application's own name lists are
  used instead), the section numbers marked "to be confirmed", and the layout of the result of an asynchronous event.
- One status in the detector's list of host aborts cannot arrive on a PCIe capture (a Linux host writes it only into
  its own records). Not followed up.

**The header of a level's file (section 7)**

- **The cost of an empty column on a very large file.** Family 4's facts about the data read a whole level to say that
  a column is empty in every row or not in the file: about a minute for each such column on a packets file of 6
  gigabytes, by the report's estimate, in each of three places, with no progress shown. A count of filled cells per
  column kept at the load is not built.
- A tree loaded before this round has no stored header until page 3's plan card is made once; until then
  `Tree.columns` reads the level's file, or, when it cannot, lists only the columns some row fills.
- A recording that the running server loads before it is started again gets no stored header at its load.
- The load timing is one sample of 64 megabytes. No load of several gigabytes was timed.
- No real export file of the customer was loaded. The real layout was tested on the sample's rows rewritten under the
  real export's header form, and on the customer's stored header lines without rows.
- The owner's stored item "Commands that came close to the limit" still held the older wording when this record was
  brought up to date; it should take the new wording at the first seeding by the new code. Not seen.

**The tests themselves (section 13)**

- `tests/test_other_csv_errors.py` and `tests/test_graph_learning.py` set the number of worker processes to 1
  (`F2T_WORKERS=1`) when they are loaded, for the rest of their test process. No failure was seen from it, and they
  were not changed (the join report on the header). Read in the code for this record:
  `tests/test_command_error_rules.py` and `tests/test_command_rules_flow.py` do the same.
- The shared set-up file hides a leak of the two values it puts back; a third value left changed by a test file would
  again show only in some orders.
- No report gives a test result for the coordinator's changes made after the two join reports (section 12).

**Timing on the graph (section 8)**

- The written test still replays gaps only and one command at a time. A stored queue depth above 1 is data on the
  graph that no written test replays.
- The first sequence still flattens recorded gaps (decision 31).
- A solution stored before this round has no timing row; its step keys are then counted within its own stored steps,
  and the answer says so. That is weaker.
- The step key counts within the commands the search was given, so both recordings must be read with the same window.
  It does not compare parameters.
- The S17 sample names no firmware, so its rows carry an empty firmware text.
- Tuning inside the bracket, a spread around a failing stored point, and marking a stored point stale are not built.
- The cost of wrong history case by case: up to 84 lab runs more in one simulated case.

**Lab runs from a validation suite (section 9)**

- A stop of the application between marking a run and writing its lab row leaves the run uncounted for good.
- Two result files brought in at the same moment were not tested.
- A test file path written on Windows is matched in a test as text only.
- The table "What came back" does not show whether a result was counted.

## 16. To try with a real model, the real opencode, a real capture, a real drive and a real validation suite

None of this has been tried.

**With a real model**

1. Choose one of the 38 rule families with a model connected. Read the requirements card (does the model ask what the
   rule's text leaves open, for example what to do with an empty cell?), the code, and the Tester's line that compares
   the code's rows with the reference implementation. How many model calls and seconds does one family cost? The
   screen says at least 10 calls and 3 cards; that was counted with the stand-in.
2. One family that finds nothing in the recording, coded by a real model: the Tester should accept the empty result
   ("the code wrote rows, or found none"). Does it? And a model's code that calls the reference implementation
   instead of reading the tree: is it refused with the sentence, and does the model then write its own code in the
   next round? Does a model's code carry the episode sentences ("Belongs together")?
3. Add an item of your own under Errors, NVMe command level errors, in words a model can turn into a procedure on
   the tree. Does the Rule writer put "row number in the file" first? Do the requirements and code cards come? Does
   the result card carry "Approve to accept it and file ..."?
4. A rule that names the number of blocks of a command: is it still refused by Family 4, now that the header is
   complete?

**With the real opencode program** (a throw-away folder, never the owner's sessions)

5. A folder with one XML file, one small `.etl` file and one CSV file. Ask "what is each file, and what do I need to
   bring?". Does the agent open the files itself, say what it saw, quote the notes for the `.etl` file, and invent no
   column?
6. Ask it to write the XML file as a table, press "Put this CSV file into the folder", press "Check" on the start
   page: is the file listed?
7. Does the real program accept the folder's permission, and can its own edit tool not write into the folder?
8. A Python program that tries to write into the folder is expected to succeed, since nothing confines it. Try it on
   a copy, and tell the owner the result.

**With a real capture**

9. Under which name the tree keeps the status cells of a real export, and how the cells are written.
10. Whether "do not retry", "more", the retry delay and the first value of the completion are filled on real
    completion rows.
11. Whether the size of the namespace is filled on an Identify row. Without it the block range family says "cannot
    be checked", as on all four samples.
12. Whether a real host's re-initialisation shows as the mark the reset family looks for.
13. How the analyzer itself writes a command identifier that is used again while its command is open. On the synthetic
    sample the tree hides it (section 6).
14. The speed of a family on real rows (up to 1,598 cells a row; the 21,102 commands a second were measured on 13
    cells).
15. `Tree.columns` on a real upload of the customer's layout: loaded with this round's code (the header is kept at the
    load), and loaded earlier (after the plan card was made once). On a file of several gigabytes: the load time, and
    how long Family 4's facts take for a column that is empty in every row of the packets file.
16. A real folder with files that are not CSV, on the start page: are the groups and sizes right?

**With a real drive and a bench**

17. Whether a trigger stays the same between two captures of the same kind of defect on the same firmware. The whole
    benefit of stored timing rests on it.
18. The four constants of section 8, and the real spread of reproduction from run to run. The simulated drive misses
    in 10 of 100 runs by construction.
19. Whether "stayed away" from 2 runs is enough on a real drive, and how often contradictory runs occur.
20. Whether timing found on one firmware is a useful starting point on the next, and across drive models.
21. Whether the step key finds the right commands in a second real recording of the same kind of defect with a
    different workload before the failure.
22. The cost of wrong history case by case.
23. Whether a host can place gaps under about 100 microseconds dependably.

**With a real validation suite**

24. Build a package from an error whose test was approved for a version of a solution. Read "Stored solution it was
    written from" in the manifest. Run it in the suite on a real drive. Bring the result file in. Is the result
    counted, with the right bench and "k of n"? Is the same file refused the second time?
25. A suite that writes its own result file without the replay library's verdict line: the result should be kept and
    not counted, with the sentence that says why.

**In a browser, after the application is started again**

26. The Rules library: section, kind, level in order; the two older items in sight; three closed groups with "24
    items", "8 items", "6 items"; the search field keeps the cursor while the list redraws.
27. Add a kind of recording, a level under it (for example the file pattern `bench_*.csv`), an item in it; Edit and
    Delete beside them; Delete of the level while it holds the item shows the reason and no "Delete it".
28. The errors page before a result is approved: "Not listed yet". The page of one error opened by its address
    then: the message card alone, with the link to page 3.
29. After approving a rule of the admin's own: its error page shows the rule in words and "Where the defect's name
    comes from". No key anywhere.
30. Part 5 of the page of one error: the two lines "judged by admins" and "lab runs". The search part: what it
    started from, what it wrote back, and the store button.
31. The start page with a folder that holds no CSV file: the sentence, "Start the flow" off, the terminal agent's
    button.

32. Rules library and plan card, under Errors, NVMe errors, NVMe command level errors: three groups, 38 rules, none
    ticked. Open a group and read the cost sentence under its meaning.
33. `/nvme-rules`: the families are drawn; the identifier rule shows its limit; the list of exceptions reads
    "Successful Completion (0h/00h); ...". The bar of the check-again button ends at 100 per cent.
34. A flow on S17 without a model, with the built-in timeout rule and the five families of the join's test (section
    6). Read each result card's sentences. Before approving: the errors page says "Not listed yet". After: "Belongs
    together", "The same command is also listed under" (the link opens the other error), and the card "Rules that
    listed no error".
35. Open an error of a family: the rule in words, the row "Where the defect's name comes from", and stage 1 gives
    "Write matched the rule 'A command never completed'". The hint under the name and the source line should name the
    application's rule set, not "your own rule".
36. An analysis made before this round: its errors and its error pages as before.
37. Leave an analysis "running" and start the application again: it should continue from its first unfinished step.
    And if an analysis ever stands still after Approve (its state "running", its next step "waiting", nothing
    working), write down which card it was: that is the fault of section 0a.

## 17. The run of the whole suite on the joined code

This section is the coordinator's own note; it is in no builder's report.

**What ran.** 15 November, 06:32 to 07:17, on the development machine (Linux): all 66 offline groups of `run_tests.sh`,
in four parts side by side (`runs/suite_parallel/make_parts.py` writes the parts from `run_tests.sh`), on the final
joined code. The stand-in took the place of the model. Synthetic recordings and a simulated drive only.

**The result. All 66 offline groups passed: 62 in the run of four parts at once, and the other 4 when they were run
again one after the other on a quiet machine.**

**The four that failed in the first run, and why.** `attack6` (6 of its 134 attacks, numbers 69, 70, 71, 76, 77 and
78: the ones that load a recording again), `fuzz_params` (1 answer of 6,067: status 507 on "load again"),
`unit_errors` (1 test: a load stopped) and `fuzz_kpi` (1 of 179 rounds could not open its database file). In three
of them the application's own message says the cause: "only 3.1 GB of memory is free, and a load needs at least
3.3 GB, so that the other programs keep theirs". That is the application's protection of other programs, working
as built. The machine was short of memory because four parts ran at once and the tests of the night had left
5.4 GB of files in the temporary folder, which on this machine is kept in memory. After those files were removed
(10 GB free), the four groups were run again one after the other: `unit_errors` 49 passed in 137 s, `fuzz_kpi`
179 rounds with 0 failed and 0 crashed, `fuzz_params` no problem in 301 s, `attack6` 134 attacks and none broke
anything. The fourth, `fuzz_kpi`, gave no memory message in its first run; that it passed on the quiet machine
fits the same cause but does not prove it.

**The six new groups of this round, in the run of four parts:** `unit_cmdfamilies` passed in 179 s,
`unit_cmdflow` in 115 s, `unit_floworder` in 98 s, `unit_errjoin` in 33 s, `unit_graphlearn` in 24 s,
`unit_header` in 22 s. The group that holds the test "several whole flows at the same time" (`unit_agents`)
passed in 301 s, and the every-item flows of `unit_nearlimit` in 612 s: no flow stood still in this run. One clean
run does not prove the engine fault of section 0a can never come back; the test written for that exact moment is
what covers it.

**Not run when this was written: the 10 groups that go through the running application and the browser.** They
need the application to be restarted on this round's code, and they must not run while the owner uses an analysis.
The running application was started at 02:55 on the code of build 23 and was not restarted during this round; it
serves this round's page files (they are read from disk) with build 23's Python. Until those groups have run, the
following are untested: every changed page in a browser (the start page, the rules library with its groups, page 3,
the errors page, the page of one error, the NVMe rules page), and the new routes against a running server.

**Later the same morning: the groups through a running application, a look in a browser, and what that found.**
Because the owner was using the application on port 8077, the zip of 07:18 was unpacked as a second copy on port 8078
(its own systemd unit, no key file, the stand-in in place of the model and of the opencode program) and the 10 groups
that need a running application and the browser were run there. With the stand-in every group passed except six checks
that require a real model's answer (one in `e2e_hier`, two in `isolate`, three in `packet_loop`); they were blocked
on purpose so that no real model was called. The tester also opened the new pages in a browser (headless Chrome,
screenshots) and found faults no group had caught. Each was repaired and tested the same morning:

1. **After "Check this recording again", the errors page of an analysis opened the wrong errors.** The check numbers
   the recording's errors anew; the stores followed, the analyses' error lists did not. Now every number an analysis
   keeps follows in one transaction, matched by rule, file and row; an error no longer found is taken out and said;
   the errors page checks its numbers against the recording before it draws a link (`agentic/pipeline.py`
   `follow_renumbering`, `error_numbers_check`; `nvme_hier/rules.py`; `app/api/hier_api.py`, `nvme_errors_api.py`;
   `tests/test_renumber_follows_flows.py`, 25 tests).
2. **An error found by a rule family got no cause** ("none of the fixed rules applies"), although the detector's error
   of the same command got one; and the aborted command of the sample got a wrong cause. The cause rules took the
   command's cycle and times only from facts the detector's errors carry. They now read them from the command's own
   rows in the tree (`nvme_hier/evidence.py`, card version 3; `tests/test_cause_for_family_errors.py`, 34 tests).
3. **The page of one error showed internal keys** (a rule key in the test table, a cause key in brackets), said
   "the model proposed it" over an empty box (the request for a proposal was never sent: a real fault of the page), and
   was 1,029 pixels wide in a 400-pixel window. Repaired in `app/static/js/isolate.js`, `isolate.html`,
   `nvme_hier/isolate.py` (tests in `tests/test_join_error_page.py`, 101 tests).
4. **The rules library said "needs code" for a rule family** that runs the application's reference implementation,
   and printed raw level keys; the top bar pushed every page sideways at phone width. Repaired in `agents.js`,
   `agents.html`, `app.css`, `terminal_agent.js`; the rules list now names the application file an item runs
   (`agentic/family3.py`).
5. **The older packet workflow's review failed with a traceback when no key was set** (`app/stage1_runner.py`): it now
   runs without a model. The bar of "Check this recording again" now ends at 100 per cent before it is put away.
   Three browser tests described the pages as they were before this round and were corrected.

A second copy made at 08:45 from the code of that moment ran the live and browser groups again (same result: all pass
but the six real-model checks; one page test failed under load and passed alone) and looked at the repaired pages:
no raw keys, the cause named for the family's error of command row 155, every link of the errors page opening the same
error after a re-check, no page wider than a 400-pixel window. Five small changes made after 08:45 were not in that
copy; they are covered by the offline groups below.

**The offline groups on the final code.** All 66 groups ran again from 08:44 in three parts, with temporary files on
disk. Three failed for reasons that were then removed: `unit_card` because the run's temporary folder was under
`/var`, which the terminal agent rightly refuses (the coordinator's set-up; 24 passed when run with another folder);
`unit_flowpage` because a new test still expected the list's earlier wording (corrected); `unit_search` because its
byte-for-byte comparison is made with the previous zip and the only difference was the intended one (a rule key
replaced by words in the written test file). `kpi_proof` failed on a real fault the coordinator had made: a change to
the expected outcome of rules without an entry of their own also changed it for two of the detector's rules, and the
generated tests then expected the wrong thing. The change is now limited to rules of the admin and of the rule set.
The nine groups that had run before the last repairs, or were added during the run, were run again and passed:
`fuzz_app`, `attack6`, `unit_nearlimit`, `unit_card`, `unit_errjoin`, `unit_famcause`, `unit_renumber`,
`unit_cmdflow`, `unit_errpage`.

**The measured evidence (`kpi_proof`) on the final code.** First rerun: every check passed except one, "a defect that
shows only 3 times in 10 is still caught", which found 8 of 10 where at least 9 are required (the run of 06:32 had found
10 of 10). That check draws the intermittent fault at random without a fixed seed, on the simulated drive. The second
rerun, on a quieter machine, passed every check: 0 checks failed, that one 10 of 10, in 1,011 s. The check is therefore
sometimes failed by chance; one failure in three runs does not prove more than that. A fixed seed for that check would
make it repeatable; not done.

**For the next person who runs it.** On a machine with less than about 16 GB of free memory, run the parts two at
a time, or clear the temporary folder first; a group that fails with the 3.3 GB message is the protection speaking,
not a fault of the code under test.

## 18. After build 24 (15 November 2026, afternoon)

Not in the zip of build 24; in the code since, tested, and running since the restart at 14:04.

1. **Page 3 and the Rules library are one tree** (section › kind of recording › level › group › item): a click opens one level down,
   only the way to the analysis's own rules opens by itself, "Add ..." at every level, every rule of a level listed with its state in
   the analysis and "Use it in this analysis" (`GET/POST /api/agents/runs/<rid>/items`; groups inside a level:
   `POST/DELETE /api/agents/rule-hierarchy/levels/<lid>/groups`). Tests: `tests/test_add_item_to_analysis.py`, `tests/test_rule_hierarchy.py`;
   the browser groups passed on a second copy (51, 49 and 117 checks).
2. **The owner kept three NVMe command errors**: NVMe command timeout, Read failed, The command was aborted because the host asked.
   The other 37 rule families were moved to Deleted items in the owner's library (Restore brings one back).
3. **An independent check of the three** on the five samples found the application's rows equal to rows computed from the raw CSV.
   On planted cases it found two faults, fixed: a completed command with empty status cells was called "never completed"
   (`nvme_hier/rules.py`, the timeout rule now also needs no completion entry in the tree); a value written "81h" was read as decimal
   (`nvme_hier/parse.py int_value` reads a whole cell ending in h as hexadecimal). Tests: `tests/test_top_three_rules.py`.
   Not changed, for the owner to decide: "Read failed" lists every error status of a Read, not only Unrecovered Read Error (2h/81h);
   the timeout rule calls an aborted command "the host gave up waiting", which the specification does not support; the saved
   description of the timeout rule names an older way of computing the usual time.
4. **Data analytics reads one CSV file, never the tree** (the owner's rule). The two built-in items already read
   `nvme_command.csv`; they now stream it and give the same numbers on S17. A Data analytics procedure on the tree is refused with
   one sentence. "Commands that completed but came close to the limit" needs the completion time, which is not in the NVMe
   command file: it was moved to Deleted items in the owner's library and starts there on a new installation. Errors rules keep
   the tree. Tests: `tests/test_analytics_on_one_csv.py`; three tests of `tests/test_family4.py` now make their tree rules in Errors.
5. **The measured-evidence test** gives a simulated command 5 s instead of 1 s before calling it a host timeout, and its simulated
   drive writes its counter whole: two of its generated scripts had failed once on an overloaded machine (shown by running the same
   scripts 20 of 20 times on a quiet machine and by reproducing the delay). Final run: 0 checks failed, 1,070 s.
7. **A new installation keeps only the three as well** (before, only the owner's library on the development machine did): on first
   start the 37 other rule families are seeded straight into Deleted items with the reason and the installation as who deleted
   them; an existing library is left as it is; a restored family stays restored. The NVMe rules page says a rule in Deleted
   items is restored first. Tests: `tests/test_top_three_rules.py` (11 tests); the fixtures of five test files restore the
   families they need; a new group `unit_additem` runs `tests/test_add_item_to_analysis.py`.
6. Two explainer pages beside `document.html`: `how_it_meets_the_statement.html` (the statement's parts step by step) and
   `how_the_error_page_works.html` (the page of one error, button by button).

Open, found on the way, not fixed: a written test file (older format, `nvme_hier/testcase.py nvme()`) throws away a Write's own
latency line and uses the process clock; the server records a failed two-way check of a test file but does not refuse its approval
(only the page keeps the button off); on the page of one error the window's "gap before it" for rows under a command shows the time to
the next row; the cause of S17's aborted Read rests on a 5.775 µs difference from the usual time.

Test runs on this code: every group touched (35 offline groups) passed; the measured evidence passed; the whole suite was not run again
as one, and the groups through the running application were last run on the second copy before items 2 to 5.
