# The 16 statements under the owner's design: still none fully covered, and what was built since

**Written on 2026-11-15.** It replaces `docs/OPPORTUNITY_COVERAGE_2026-11-14.md`. File paths are inside the application
folder (`13_production_app`). The statements are in `docs/OPPORTUNITY_STATEMENT.md` (S1 to S16).

**Why a new check.** The check of 14 November judged "VIAVI: not covered, there is no VIAVI loader". The owner
corrected it. The design has no loader per measuring tool, on purpose. Any tool's recording (Teledyne LeCroy, VIAVI,
anything) is converted to CSV by the people who have the tool. Family 1 learns the columns from the files. Family 2
(joining files into one tree) is optional. Family 3 is the admin with agents making rules. Family 4 is the coding
research family, which codes the rules with evidence. So "is there a VIAVI loader?" was the wrong question. The right
one is: how far does any CSV get? A second research report of 14 November asked that, and this document follows it.

**Withdrawn, explicitly.** The sentence of 14 November "VIAVI files cannot be read" was too hard and is withdrawn.
Correct is: a VIAVI recording converted to CSV would be read, its columns learned and a rule counted on it; its rows
would not go on to a cause, the graph and a test. The advice "a VIAVI export, then a column list and loader" is
withdrawn too: a column list in code contradicts the design. The earlier check had also not read Family 4 at all.

## The answer in six lines

1. **The verdict counts do not change: 0 of 16 covered, 14 partly covered, 2 not covered** (S2, faster reproduction in
   the lab; S11, learning from historical data). The reasons change for S5, S12 and S16.
2. **Everything that is covered is covered on synthetic recordings and a simulated drive.** No row of a real capture of
   any tool was analysed. No generated test ran on a real drive. No engineer was timed.
3. **"Any CSV" held for the first half** when the research was done: read the file, learn the columns, write a rule
   with the admin, code it with proof, count the result, write the report. It stopped at the result table.
4. **Much was built on 14 and 15 November** against the gaps (the last column of the table below).
5. **The rule of this document: a verdict changes only when the part is tested as a whole and, where the statement
   needs it, on real data. Nothing built on 14 and 15 November raises a verdict here.**
6. **The most important number of the one run with a real model:** 11 of 15 column meanings had no source the program
   can check. All 15 were right, on one easy file of 608 rows.

**The state of what was built on 14 and 15 November.** Each part passed its own tests, as its report says
(`docs/CHANGES_2026-11-15.md`). The whole test suite ran once on the joined code (15 November, 01:00 to 01:45): 58 of
60 offline groups passed, and 8 of 10 groups through the running application and the browser. The four failures were
repaired; one was a real fault of this round (the new item of S4 stopped every flow in which it was chosen; section 19
of the change record). A second run on the final code followed at 02:11; its result is the line below. No new page
was looked at by a person in a browser; the browser test groups ran against the application (`ui_packets`, `ui_tree`,
`ui_pages` and `ui_terminal` passed, `ui_flow` failed 2 of 42 checks that described the page as it was before).
Nothing ran on Windows, on a real capture of any tool, or on a real drive. **One run of the test suite raises no
verdict here.**

TESTS ON THE JOINED CODE: on 15 November 2026, from 02:11 to 02:51, the whole suite ran on the joined code in five parts side by side: 60 offline groups and 10 groups through the running application and the browser. All 70 passed. After that run one module was corrected once more (the recheck by the terminal agent, after its trial with the real opencode program), and the eight groups that touch it were run again on the final code at 02:52: all eight passed (unit_f4recheck 60 tests, unit_family4 40, unit_f4faults 42, unit_flowpage 15, unit_form 20, the flow on any CSV 0 checks failed, the agent families through the application 86 checks, a whole flow twice 72 checks). This is synthetic data, a simulated drive, and the stand-in in place of the model in most groups.

## All 16 statements in one table

"Earlier" is the verdict of 14 November. "Simulated bench" and "simulated drive" mean a program in place of the lab.
"Stand-in" means the fixed answer the application gives when no model is connected.

| No. | Statement in short | Earlier | Under the owner's design | Why | Built on 2026-11-14/15, tested with the whole suite on synthetic data only |
|---|---|---|---|---|---|
| S1 | Isolate defects from a recording | Partly | Partly | Unchanged. Isolation with cause exists only for the five-file tree. No real capture | **The cause of a command that never completed** now looks at the host's Abort, the controller reset and what the drive answered meanwhile: the 7 timeout errors of the synthetic sample S17 get causes their rows justify (18 tests). **The link join** has a rule for a sequence number that comes round again, behind a switch, with four known limits kept as tests; all its evidence is hand-made or generated data. **A page of one error for a file outside the tree** isolates and goes no further |
| S2 | Reproduce failures faster in the lab | Not covered | Not covered | No bench, no time measured. The input format does not matter | Nothing that touches this: the search on the page of one error runs on a simulated drive, and choosing the real bench answers "not connected yet" |
| S3 | Automated analysis, from bug to reproduction | Partly | Partly | Unchanged. Another tool's CSV stops at "rows found"; reproduction is simulated only | Rows a rule finds in a file outside the tree become errors with a page of their own (stand-in in place of the model). On the page of one error of the tree: search, most stressful conditions, written test (simulated drive) |
| S4 | Look for weaknesses before the field | Partly (weak) | Partly (weak) | The sweep sits in the earlier workflow and starts from a confirmed defect | A rules-library item lists commands that completed but came close to the host's time limit. **On the four synthetic samples it lists nothing at any sensible share** (largest share about 0.0013 per cent). The sweep from such a command is a function only: no route, no page. **In the first run of the whole suite this item stopped every flow in which it was chosen** (the flow sent it through the coding family although its code is part of the application). Repaired on 15 November: its code is application code, as the detector's rules are; no model is asked for it; two flows with every item chosen finish (stand-in, synthetic samples S08 and S17) |
| S5 | Pattern recognition, link-layer analysis, LeCroy and VIAVI | Partly | Partly | **Reason changed.** "VIAVI: nothing built" is wrong. Reading, meanings and admin-made rules work for any CSV. Isolation with cause does not. Rules are written by a person, not learned | The start page has the answer "Another tool, or I do not know". The reader takes comma, semicolon, tab and vertical bar, a header that is not on line 1, UTF-8 and UTF-16, decimal commas; a file that is no table is refused in a sentence. A chosen tool is taken for a file only when the file looks like it. **No VIAVI export and no real export of any other tool has been read** |
| S6 | Model writes the baseline scenario | Partly | Partly | The scenario is built from the tree's commands; in the main flow code writes the first sequence and the model picks rows | Nothing new for this statement |
| S7 | RL agent optimizes sequence and timing | Partly | Partly | Does not depend on the input file. The search forgot after each search; the reward came from the simulator's hidden answer | A search on the page of one error, seeded with the first sequence (simulated drive): with the drive's time hint it found 50 of 50 hidden triggers against 37 of 50 for a random choice; **without the hint 33 of 50 against 37 of 50, worse than random**. A reward computed from the detector's findings alone exists and was tested with hand-made records; real findings carry no measured timing yet |
| S8 | Most stressful conditions become scripts in the formal suite | Partly | Partly | Unchanged. No link to any team suite; scripts never ran on a drive | The most-stressful-conditions step on the page of one error, and a test written from its result (simulated drive). Approved tests can be downloaded as one package with their approval records, and a result file can be brought back (23 tests). **No suite is linked**; ten questions wait for the owner |
| S9 | Self-optimizing closed loop | Partly | Partly | The loop closes only with the tree, and only the admin's judgements change the next result | What a search learned starts the next search of the same kind (see S11). Nothing ties a result from a real drive to the procedural graph |
| S10 | Knowledge base of validated traces and workloads | Partly | Partly | Small addition found by the research: an unknown tool's meanings are kept under the file's header. Traces were referenced, not stored; workloads not archived; two stores | The rows around an error are kept in the knowledge base and were read back after the upload was deleted (synthetic sample; 0.5 to 1.8 megabytes compressed per error). A table for workload records, kept as given and validated only by the admin; routes only, no screen. One look-up across both stores, which will answer "no link" on real data because no reliable mapping between the two stores exists |
| S11 | RL applied to historical data | Not covered | Not covered | Unchanged at the time of the research: the learner started empty at every search | **Learning from history built and measured on the simulated bench:** the second search of the same kind of defect needed fewer lab runs than the first in 49 of 60 pairs, the same in 11, more in 0 (median 301 -> 72 lab runs, 300 allowed). **The gain comes from the stored best procedure, not from the carried counts** (the counts alone: 26 better, 18 equal, 16 worse). Not measured on a real bench: there is none. It is in the earlier packet workflow's search |
| S12 | Deployment: suite, AI pipeline, analyzers, scripts | Partly | Partly | **Reason changed.** Any tool's CSV can be opened and counted; it is not analysed to a test. A person still exports with the maker's software. Never run on Windows | The hand-over package (S8). The start page for any tool (S5). The commands in the package's README are written for a Unix shell |
| S13 | About 50 % less manual triage effort | Partly | Partly | Still not measured | Nothing: no person was timed |
| S14 | Better accuracy, full coverage, zero leakage | Partly | Partly | The measured figures are the tree detector's, on synthetic recordings | No new measurement of accuracy, coverage or leakage. The cause repair (S1) corrects 6 causes on one synthetic sample |
| S15 | AI minimizes test-writing effort | Partly | Partly | Family 4 writes rule code, not test scripts. No person was timed | Family 4: the three faults the real-model run showed are repaired (scripted model only; one of its tests was failing at the report of 00:23 on 15 November because its expectation was out of date; the expectation was changed since). Family 4's finished code can be rechecked by the terminal agent with a program of its own (tested with a stand-in terminal program only). **It ships as "only when the admin asks on the card", not "always".** The data files are recorded before the recheck and compared after it; a change refuses the recheck. That watch detects and prevents nothing: the Python the terminal agent starts is not confined. A trial with the real opencode program was started on 2026-11-15; its result is in the project's research notes. Family 4 asks the REA agent only with the admin's tick |
| S16 | One integrated closed-loop flow | Partly | Partly | **Reason changed.** For another tool's CSV the flow is one, but short. The search and stress step sat in a second workflow | The search and the stress step are on the page of one error of the main flow. Errors of files outside the tree are in the flow. **The second half for any CSV is missing:** cause, graph and replay test are still only for NVMe commands of the Teledyne LeCroy five-file export. Two workflows and two stores remain |

## The evidence and the gap of each statement, as measured on 14 November

These figures are from the first check (logs of 14 November, when all 53 test groups passed). They are kept here so
that the earlier document need not be read. Two entries are corrected and marked.

| No. | Rests on | Main evidence | Gap |
|---|---|---|---|
| S1 | Synthetic recordings | 300 of 300 written-in faults found, 0 false alarms on 665 clean commands | The cause was wrong for 6 of 7 timeout errors on sample S17 (corrected: the earlier text said "6 of 7 never-completed commands"; the file holds 6 commands that never completed and 7 errors). Code for it now exists, see above. No real capture |
| S2 | Simulated drive | 22 of 22 test scripts reproduce the fault on the simulated drive | No lab bench. No time measured, with or without the tool |
| S3 | Synthetic recordings, simulated drive | Test group `flow`: 72 checks, 0 failed | Reproduction is simulated only |
| S4 | Simulated drive, earlier workflow | Sweep: 14 variants, 42 simulated lab runs, 3 filed as tests | Starts only from a confirmed defect |
| S5 | Real LeCroy header layout, synthetic rows | Join tests: 21 passed | (Corrected: "VIAVI: nothing built" is withdrawn.) Patterns are fixed rules and exact keys. No real export of another tool read |
| S6 | Synthetic recordings, a real model on a small sample | A real model answered in 3 live test groups | Main flow: the model only picks rows; code writes the first sequence |
| S7 | Simulated drive, earlier workflow | The shipped search and its reward | The reward comes from the simulator's hidden answer |
| S8 | Simulated drive | Stress step; 49 of 237 test folders carry a stress entry | No link to any team suite. Scripts never ran on a drive |
| S9 | Synthetic recordings, simulated drive | Test group `unit_graph`: 12 passed | Only the admin's judgements change the next result. Live store: 0 judgements |
| S10 | Code reading, table counts | 65 solutions and 18 procedures stored | Two separate stores |
| S11 | Code reading | 257 returns of 22 known failures found their stored procedure: lookup, not learning | Not measured on a real bench |
| S12 | Earlier workflow, simulated drive | Test group `packet_loop`: 65 of 65 checks | A person exports the capture. Never run on Windows |
| S13 | Synthetic recordings | Automatic first sort ran on 20 recordings without a person | The 50 % is not measured |
| S14 | Synthetic recordings, simulated drive | 0 leaked of 257 returns; 300 of 300 found | Only 2 rules and 5 fault kinds measured. 19 of 48 mild slow-downs missed |
| S15 | Simulated drive | 22 scripts, 0 hand-written lines | A fixed template writes the file. No person was timed |
| S16 | Synthetic recordings | Test groups `flow` (72 checks) and `ui_flow` (40 checks), 0 failed | Two workflows with two stores |

Three arguments of the first check still stand. The generator writes five kinds of fault and the rules were written to
find those five, so 300 of 300 shows that the rules agree with the generator. "Zero leakage" is 0 of 257 by
construction: the other recording is the same recording with another random seed. The only figure near the 50 % is
about 93 % fewer commands to read on 20 synthetic runs, which counts rows, not an engineer's time.

## What the one run with a real model proved, and what it did not

**The input was not a VIAVI file.** No VIAVI export exists on the development machine. The file was made from the
project's own synthetic sample S17: 608 NVMe commands, 15 columns, with disguised column names and times converted to
other units. The reference library matched 0 of the 15 names, so the file went the way of an unknown tool.

**The run.** One run on 14 November, a real model over the application's own Model connection, web search off: 652 s
and 24 model calls.

**Proved.** The data dictionary was right for 15 of 15 columns against a private answer sheet. The admin's rule was one
sentence that named no column; the Rule writer chose the right column. The code's result on the whole file was the same
6 rows as an independent count.

**Not proved.** 11 of the 15 column meanings and 13 of 13 keyword meanings carry the label "from the model's knowledge
(no source to check)". The dictionary was approved unread, and everything after it stood on those meanings. They were
right here because the names were short English abbreviations. A real export can have hundreds of columns whose names
give no hint. It was one run, one file, a rule that compares no times. Isolation was not run. The person who answered
the admin's cards knew the answer sheet.

**It exposed three faults** in Family 4 (a dead end that cost 5 rounds and 423 s, false findings of the data research
step, a card that contradicted itself). They are repaired since, tested with a scripted model only.

The run's evidence is kept with the project's research notes; it is not in the code zip.

## The loop's stages: which run for any CSV

"At the research" is what the second research report found on 14 November, on the tested code. The last column is what
was built since, tested with the whole suite on synthetic data only.

| Stage | At the research | Built on 2026-11-14/15, tested with the whole suite on synthetic data only |
|---|---|---|
| Start page: "which tool exported the recording" | No from the page: only Teledyne LeCroy could be chosen | The answer "Another tool, or I do not know" |
| Reading the file | Yes, only for comma, header on line 1, UTF-8, a name ending `.csv` | Semicolon, tab, vertical bar, a header lower down, UTF-16, decimal commas. Still only names ending `.csv` |
| Family 1: Explorer, Grounder, Manager | Yes | They are told how a file that is not plain is written |
| Step after Family 1 | Yes, only "go on without stage 2" | Says why the fixed joining strategy is not offered |
| Family 2: the tree | Only with the Teledyne LeCroy five-file export | Unchanged, by design: Family 2 is optional |
| Rules plan, Family 3 Rule writer | Yes, level "Other CSV files" | A rule that finds defects must name its rows |
| Family 4: research, requirements, code, proof | Yes | The three repairs, the REA agent with the admin's tick, the recheck by the terminal agent (only when the admin asks on the card; the data files are watched before and after). Family 4's readers take a file in its own form (semicolon, a header lower down, UTF-16, decimal commas) |
| Result table, CSV, report | Yes | The report has a section for errors of files outside the tree |
| Errors list and errors page | Only with the tree | Errors of a file outside the tree are stored and listed apart, and the flow's errors page shows them in a section of their own with a link per error (run in Node against the routes' answers, not seen in a browser) |
| Page of one error, isolation | Only with the tree | A page of one such error with meanings, the rows around it and a kept isolation |
| Cause, graph, outcomes, test file, replay | Only with the tree | **Still only with the tree.** The page says so |
| Earlier single-file workflow (`/packets`) | No: needs the 113 column names of the Teledyne LeCroy export | Unchanged |

## What stood between the design and "works for any CSV", and what was built against it

The six points of the research, in its order of weight.

1. **The start page let only Teledyne LeCroy be chosen.** Built: the fourth answer; a chosen tool is taken for a file
   only when the file's own column names pass the recognition limits.
2. **The reader took only comma, header on line 1 and UTF-8.** Built: the reader of Family 1 and the form handed to the
   agents. Then the form in every reader: the readers of Family 3 and Family 4, the data research, the stand-in's code
   templates, the terminal agent's table of files, the recheck's task file, the check on the start page and the error
   page of a file outside the tree now read a file in its own form; one recording written three ways (plain, semicolon
   with a title line and decimal commas, UTF-16) gives the same result in each (files written by the tests, stand-in in
   place of the model). Still assuming the plain form: the stand-in of Family 2, "Ask all the Managers", and the list
   of refused files on the flow pages. Three decisions of that builder wait for the owner (change record, section 9).
3. **Rows found in another tool's file never became errors that reach isolation.** Built: they become errors with a
   page that isolates. Cause, graph and test are not built for them.
4. **Family 4 did not ask the REA agent.** Built: only with the admin's tick; only answers with file, lines and a
   checked quote are used.
5. **Meanings without a source.** Not built. The label is honest; the meaning is not checked. With web search off, an
   unknown tool's meanings can only come from the column's contents or the model's knowledge.
6. **Nothing has run on a real file of any tool.** Unchanged. Only the real environment can change it.

## VIAVI and other tools: what public documents say about a CSV export

- **A delimited text export exists in VIAVI's software.** VIAVI's release notes name the tool "Export To Text" (Xgig
  Analyzer 8.5.4 release notes, 2017). A user guide of 2015 says the trace viewer "can export the traces to a delimited
  format that can be used by other databases and spreadsheets" (seen as a search excerpt only).
- **Its columns are shown in no public document that could be read:** not the names, not the separator, not the time
  unit, no sample file.
- **Three consequences for the design.** The viewer's columns are chosen by the user, so two VIAVI exports need not
  match; that supports "learn the columns from the file". "Delimited" does not say comma. VIAVI's documents show two
  levels (events, and exchanges that group them), not five, so a five-file tree should not be expected.
- Teledyne LeCroy documents an export "to CSV or text formats". For Keysight's PCIe analyzers no public statement of a
  CSV export was found. For SerialTek's PCIe line only a JSON interface is stated. Linux block traces are plain text,
  not CSV.

## What would close each gap

1. **A real drive behind the bench hook, with defective and fixed firmware.** Unlocks most: S2, S3, S4, S7, S8, S9, S12,
   S14 and S15. It also decides whether the search as built is better than a random choice on a real drive.
2. **One real Teledyne LeCroy five-file capture with a confirmed defect.** Unlocks S1, S3, S5, S13 and S14, and settles
   the link join's switch and the cause rules.
3. **One real export of another tool, converted to delimited text by the people who have the tool** (for VIAVI with
   its own "Export to Text File" tool), started on the start page with "Another tool, or I do not know". No loader and
   no column list in code. Unlocks the honest half of S5 and S12.
4. **The second half for any CSV:** a cause, a place in the graph and a test for an error of a file outside the tree.
5. **Sources for meanings:** a way to check an unknown tool's column meanings before everything stands on them.
6. **Timed engineers, with and without the tool, on real captures.** The only way to S13, and to "faster" in S2 and
   "effort" in S15.
7. **The owner's answers about the team's validation suite.** Unlocks S8 and S12.
8. **The whole suite on the joined code, a restart, and the new pages seen in a browser.** Before that, nothing in the
   last column counts.

The work list for whoever has the real environment is `deploy/REAL_ENVIRONMENT_WORK.md`.

## What was not checked

- No VIAVI export was at hand. Which of its column names coincide with a known tool's list is unknown.
- Web search on for an unknown tool: whether it raises the share of checked meanings was not measured.
- The real-model run was done once.
- A rule on two files of an unknown tool was never run.
- Windows. The confinement of agent-written code is absent there.
- The second research report ran no test itself; it read the logs of the day and five notes. The last column of the
  tables repeats the builders' reports; this document ran nothing.
- The earlier packet engine's figures (437 of 485 and 483 of 485 error types) were measured in October on one synthetic
  trace of 4 gigabytes and not measured again.

## After the second round of 15 November

**Written on 2026-11-15, after the work recorded in `docs/CHANGES_2026-11-15_round2.md`.** Nothing above this line was
changed. This part goes through only the statements that round touches. The others (S4, S6, S13, S15) stand as above.

**The round in four lines.** (1) The start page no longer asks which tool exported the recording; a folder with no CSV
table says so, and the terminal agent can be asked about a folder's files before an analysis exists. (2) The rules
library has the layer "kind of recording", and 52 researched rule families for NVMe command errors, 38 of them
runnable. (3) A rule of the admin's own that Family 4 coded, and a rule of the application's rule set (one of the 38),
now go the whole way in a strict order: the rows become errors only after the admin approves the result, and each
error is then isolated, given a cause and a solution, and a test. (4) The procedural graph keeps lab counts and timing
values, the search on the page of one error starts from them, and a result brought back from a validation suite is
counted as lab runs of a stored solution.

**No verdict changes: still 0 of 16 covered, 14 partly covered, 2 not covered (S2 and S11).** The rule of this document
holds: a verdict changes only when the part is tested as a whole and, where the statement needs it, on real data.
Everything of this round was tested on synthetic recordings, on a simulated drive, with the stand-in or a scripted
model in place of a real model, and with hand-written result files in place of a real validation suite. Each part
passed its own tests, as its report says. The run of the whole suite on the joined code of this round is recorded in
the last section of `docs/CHANGES_2026-11-15_round2.md`; this part does not rest on it. No page of the round was looked
at by a person in a browser. Nothing ran on Windows.

| No. | Statement in short | Verdict | What is now built toward it | What still stands between it and "covered" |
|---|---|---|---|---|
| S1 | Isolate defects from a recording | Partly, unchanged | A rule of the admin's own on a level of the tree now reaches isolation: after the admin approves its result, each found row is an error with a page of its own, a name from the fixed dictionary, a cause and a solution. The same holds for the rows of one of the 38 rule families. Two flow tests show the whole chain on the synthetic sample S17, with the stand-in: one for a rule of the admin's own, one for a rule family. The page of one error refuses to open until the pattern's result is approved. When two chosen rules find the same command, the errors page says so on both errors | A real capture. An error found below the NVMe command level is worked from the command above it, and the page for a row with no command above it was not tested. Two errors on one command are not merged; the page of one error does not yet say that another rule lists the same command. For a CSV file outside the tree the cause, the graph and the test are still not built |
| S2 | Reproduce failures faster in the lab | Not covered, unchanged | On a simulated drive, a search that starts from stored timing of the same kind of defect needed fewer lab runs in 28 of 30 cases (median 10 against 48 lab runs, 200 allowed) | No bench is connected and no time was measured. Lab runs on a simulated drive are not lab time. With stale or wrong stored timing the search was worse in 25 of 30 and in 30 of 30 cases |
| S3 | Automated analysis, from bug to reproduction | Partly, unchanged | The order of the flow is now enforced: rule, code, run, result approved, errors listed, isolation, cause and solution, test. Before, a rule coded by Family 4 stopped at its result table, the errors page listed errors before the approval, and the page of one error checked nothing | Reproduction is simulated only. The guard was tested with the stand-in and with hand-made flow records. **A fault of the engine was found by the tests of this round and fixed:** Approve pressed at one exact moment could leave an analysis standing still until the application was started again (`docs/CHANGES_2026-11-15_round2.md`, section 0a). One unit test and one clean run cover the fix; one clean run does not prove that a race is gone |
| S5 | Pattern recognition, link-layer analysis, LeCroy and VIAVI | Partly, unchanged | The tool is recognised from each file's own column names and is not asked. A folder's other files are listed by ending, count and size. The terminal agent can be asked what each file of a folder is and how it becomes a CSV table. The library has a layer "kind of recording" that the admin can add to, with levels that name their file. 52 rule families for NVMe command errors, each with its meaning, its columns, its exceptions and its sources | **No VIAVI export and no real export of any other tool has been read.** The patterns are still rules that people researched and wrote; nothing is learned from data. 14 of the 52 families do not run. On the four synthetic samples the 38 runnable families found 16 rows in all, so most families have only been seen on cells changed by a test. Nothing at the link layer was added in this round |
| S7 | RL agent optimizes sequence and timing | Partly, unchanged | Timing is now data on the procedural graph: the gap before each step in microseconds and the queue depth, keyed by the command and its place and not by row numbers; counts at a value; a bracket computed from them. The search on the page of one error tries the stored solution and the best stored values first, then goes on as before, and writes its runs back. The recorded gaps now reach the search | Simulated drive only. The reward is still the simulated drive's answer. Only two timing values are tracked; the idle gap as its own value, the power-saving limit and the host's time limits are not searched. The four constants of the method were chosen, not measured. No model is trained, by the owner's rule: this mimics reinforcement learning with counts and a random draw, it is not a trained agent. Tuning inside the bracket is not built |
| S8 | Most stressful conditions become scripts in the formal suite | Partly, unchanged | A result brought back from a validation suite is now counted as lab runs of the stored solution its test was approved for, once per run, and only when the result file states the bench, that the run looked for the error, and in how many runs the failure came back | **No suite is linked.** Every "real drive" result in the tests is a hand-written file. The owner's ten questions about the suite still wait, and three more decisions were taken by the builder for the owner to confirm |
| S9 | Self-optimizing closed loop | Partly, unchanged | Two links that were missing now have code. The search reads the graph and writes back to it. A result from a suite reaches the graph as lab runs. The earlier text above said "Nothing ties a result from a real drive to the procedural graph": code for that tie now exists | The tie has never carried a result of a real drive. The lab counts change only what the search tries first; the order of the solutions shown still changes only with the admins' judgements. A real bench must show that a trigger stays the same between two captures; the whole benefit rests on it |
| S10 | Knowledge base of validated traces and workloads | Partly, unchanged | The graph now keeps every lab result of a stored solution with its bench, its timing values, the drive's model and firmware texts, the date and the person. Rows are only added | These are counts and values, not traces or workloads. The two stores remain. The synthetic sample names no firmware |
| S11 | RL applied to historical data | Not covered, unchanged | Learning from earlier lab runs is now in the main flow, not only in the earlier packet workflow: the next search of the same kind of defect and cause starts from what earlier searches and lab runs left on the graph, with rows of another firmware or drive model used only as a marked starting point. Measured on a simulated drive, 30 hidden triggers: better in 28, worse in 2, median 10 against 48 lab runs | **It would change to "partly" only after a run on real data, and it stays "not covered" here for that reason.** One earlier search per graph was measured; the choice between several stored solutions was tested for its formula only. Stale history did not help (better in 4 of 30) and wrong history was worse in 30 of 30. No real bench, no real history |
| S12 | Deployment: suite, AI pipeline, analyzers, scripts | Partly, unchanged | A folder of any tool's files can be given without naming the tool. A folder with files that are not CSV says what it holds, and the terminal agent can say how each file becomes a table. A suite's result is counted on the graph (S8) | A person still exports with the maker's software. The Python a terminal agent starts is not confined. Never run on Windows. No real suite |
| S14 | Better accuracy, full coverage, zero leakage | Partly, unchanged | The earlier gap said "only 2 rules and 5 fault kinds measured". The library now offers 38 runnable rule families for NVMe command errors beside the 2 older rules. Without a model a chosen rule runs the application's reference implementation. With a model Family 4 writes the code, and the Tester compares its rows with that reference on the whole recording | **No new measurement of accuracy, coverage or leakage.** The rule families were checked for agreement with their own reference on synthetic cells, which shows that the code does what its text says, not that it finds real faults. No real model has coded one: the path with a model was walked with the stand-in and programs written by hand for the test. One family, a command identifier used again while its command is open, cannot fire on that half, because the tree hides the case. None is chosen in advance, so the default analysis finds what it found before |
| S16 | One integrated closed-loop flow | Partly, unchanged | The flow now holds its order by code, also when a page is opened by its address. The search, the graph and the suite's results are connected inside the main flow | The second half for any CSV is still missing. Two workflows and two stores remain |

**What would move a verdict, in the order of weight.** The list "What would close each gap" above still holds. This
round adds three points to it:

1. One real five-file capture run through the 38 rule families, with the counts compared against what a person finds
   by hand. That is the first honest figure for S14 after this round.
2. A real bench where the same kind of defect is captured twice on the same firmware, to see whether stored timing
   reproduces again. That decides S7, S9 and S11.
3. One package run in the team's validation suite on a real drive, with its result brought back and counted. That
   decides the new half of S8 and S9.

**Not checked for this part.** This part ran nothing. It repeats the builders' reports and what the code holds. Two
reports of joining parts (the rule families through a whole flow; the header of a level's file kept by the loader) had
not arrived when this part was first written. Both arrived later the same morning and were worked in; the change
record gives their test lines (sections 6, 7 and 13). Where the research report and the build report on the rule
families give different group sizes (24, 14 and 14 against 24, 15 and 13), the code holds 24, 15 and 13.
