"""What the procedural graph learns from lab runs, kept apart from the admins' judgements (owner, 2026-11-15: "Reinforcement learning
should learn from the previous things. That's where the procedural graph's mimicking of the reinforcement learning kicks in.").

No model is trained here. Everything stored is one of three things, and each table says which:
  dg_lab         COUNTS. One row per lab result of a stored solution (and its revision): runs, in how many the same failure came back,
                 the bench ("simulated drive" or "real drive"), what produced it, the timing values used (data), the measured time of
                 the failing command, the drive's model and firmware texts, when, who. Rows are only added. No row here changes one of
                 the four verdict counts or the ranking by judgements (defect_graph.solutions sorts by the verdicts alone).
  dg_seq_timing  VALUES. The timing of a solution's sequence as data: the gap before each step in microseconds, as recorded and as
                 searched, and the queue depth, keyed by the step's command and its place before the failing command (step_keys), not
                 by row numbers of one recording. Rows are only added; the newest row of a revision is the one used.
  dg_timing      COUNTS AT A VALUE. One row = "at this value of this timing value the failure came back in k of n runs", per kind of
                 defect, cause, bench, drive model and firmware. The BRACKET (the largest value at which the failure still came back,
                 the smallest at which it did not) and the best stored value are computed from these rows when they are read
                 (bracket()); nothing is overwritten and nothing is decayed run by run.

Decisions (the owner has not decided otherwise; each is also in the report):
  - a failed lab run counts against the SOLUTION that was tried, never against the cause;
  - a result of the simulated drive and a result of a real drive are never added together, and one is never the start of the other;
  - evidence from another firmware of the same drive model is marked "from an earlier firmware" and used only as a starting point;
    evidence from another drive model likewise; the admins' counts are never touched by any of this.

The constants below are CHOSEN HERE, TO BE MEASURED on a real bench; none comes from a drive.
"""
import json
import random
import time

BENCH_SIM = "simulated drive"
BENCH_REAL = "real drive"
BENCHES = (BENCH_SIM, BENCH_REAL)
SOURCES = {"search": "the search on the page of one error",
           "two_way_check": "the two-way check of a written test (mechanics only: the simulated drive's fault is planted from the test's own plan)",
           "validation_suite": "a result brought back from a validation suite"}
NOT_COUNTED_SOURCES = ("two_way_check",)   # shown, never counted in "the failure came back in k of n": the fault there is planted, it cannot stay away
PRIOR_RUNS = 2.0        # chosen here, to be measured: how many runs the cause's own lab share is worth in the draw of the leading solution
STALE_CAP_RUNS = 2.0    # chosen here, to be measured: lab runs from another firmware or drive model count as at most this many runs in the draw
YES_SHARE = 0.5         # chosen here, to be measured: a value counts as "the failure came back" when it did in at least this share of its runs
NO_MIN_RUNS = 2         # chosen here, to be measured: a value counts as "the failure stayed away" only after at least this many runs, none with the failure
MAX_RUNS = 10 ** 6
GAP_LIMIT_US = 600 * 10 ** 6

SCHEMA = """
CREATE TABLE IF NOT EXISTS dg_lab (id INTEGER PRIMARY KEY, solution_id INTEGER, revision_id INTEGER, defect_id INTEGER, cause_id INTEGER,
  bench TEXT, source TEXT, runs INTEGER, reproduced INTEGER, counted INTEGER DEFAULT 1, timing TEXT, fault_time_us REAL, model TEXT, firmware TEXT,
  upload_id TEXT, finding_id INTEGER, at REAL, by TEXT, note TEXT);
CREATE TABLE IF NOT EXISTS dg_seq_timing (id INTEGER PRIMARY KEY, solution_id INTEGER, revision_id INTEGER, timing TEXT, queue_depth INTEGER,
  key_basis TEXT, upload_id TEXT, finding_id INTEGER, model TEXT, firmware TEXT, at REAL, by TEXT);
CREATE TABLE IF NOT EXISTS dg_timing (id INTEGER PRIMARY KEY, defect_id INTEGER, cause_id INTEGER, value_key TEXT, unit TEXT, value REAL,
  runs INTEGER, reproduced INTEGER, bench TEXT, model TEXT, firmware TEXT, source TEXT, upload_id TEXT, finding_id INTEGER, at REAL, by TEXT);
CREATE INDEX IF NOT EXISTS ix_dg_lab ON dg_lab (solution_id);
CREATE INDEX IF NOT EXISTS ix_dg_lab_defect ON dg_lab (defect_id);
CREATE INDEX IF NOT EXISTS ix_dg_seq_timing ON dg_seq_timing (solution_id);
CREATE INDEX IF NOT EXISTS ix_dg_timing ON dg_timing (defect_id, value_key);
"""


def _text(v, what, limit=200):
    if v is None:
        return None
    if not isinstance(v, str):
        raise ValueError("%s must be text" % what)
    return " ".join(v.split())[:limit] or None


def _count(v, what, least=0, most=MAX_RUNS):
    if isinstance(v, bool) or not isinstance(v, int) or not least <= v <= most:
        raise ValueError("%s must be a whole number between %d and %d" % (what, least, most))
    return v


def _number(v, what, least=0.0, most=float(GAP_LIMIT_US)):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v or not least <= v <= most:
        raise ValueError("%s must be a number between %s and %s" % (what, int(least), int(most)))
    return v


def bench_label(kind_or_label):
    """'simulated' / 'simulated drive' -> "simulated drive"; 'real' / 'real bench' / 'real drive' -> "real drive"."""
    k = str(kind_or_label or "").strip().lower()
    if k in ("simulated", BENCH_SIM):
        return BENCH_SIM
    if k in ("real", "real bench", BENCH_REAL):
        return BENCH_REAL
    raise ValueError("the bench is one of: %s" % ", ".join(BENCHES))


def clean_values(values):
    """The timing values of a lab row as stored: a list of named values with their units, at most 400."""
    if values is None:
        return []
    if not isinstance(values, list) or len(values) > 400:
        raise ValueError("the timing values must be a list of at most 400 named values")
    out = []
    for v in values:
        if not isinstance(v, dict):
            raise ValueError("every timing value needs a name, a value and a unit")
        name, unit, key = _text(v.get("name"), "the name of a timing value"), _text(v.get("unit"), "the unit of a timing value", 60), _text(v.get("key"), "the key of a timing value", 80)
        if not name or not unit:
            raise ValueError("every timing value needs a name, a value and a unit")
        out.append({"name": name, "key": key, "value": _number(v.get("value"), "the value of '%s'" % name), "unit": unit})
    return out


# ---------------------------------------------------------------------------------------------- the key of a step (point 2)
def _class(step):
    return "admin" if step.get("admin") else "io"


def step_keys(pool):
    """{row of the recording: key} for every command of the pool; the failing command's key is "fault".

    The key is "<class>/<opcode>h/-<n>": the n-th command of that class (admin or io) and opcode counted BACK from the failing command
    among the recorded commands the search may use ("io/02h/-3" = the third Read before the failing command). It names no row number,
    so a stored sequence can be put onto another recording of the same kind of defect.
    Limits: it counts within the commands the search was given (the window above the failing command plus the first sequence), so two
    recordings must be read with the same window for the same key to mean the same place; it does not compare parameters (the blocks
    come from the recording the sequence is applied to, never from the stored one); a recording with another workload before the
    failure gives another command for the same key, or none (said, and the step is dropped)."""
    seen, out = {}, {}
    for r in sorted(pool.rows, reverse=True):
        s = pool.by_row[r]
        k = (_class(s), s.get("opc"))
        seen[k] = seen.get(k, 0) + 1
        out[r] = "%s/%s/-%d" % (k[0], ("%02Xh" % k[1]) if isinstance(k[1], int) else "?", seen[k])
    out[pool.frow] = "fault"
    return out


def _nth(n):
    return "%d%s" % (n, "th" if 10 <= n % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th"))


def key_words(key, command=None):
    if key == "fault":
        return "the failing command"
    try:
        n = int(str(key).rsplit("/-", 1)[1])
    except (IndexError, ValueError):
        return str(command or key)
    return "the %s %s before the failing command" % (_nth(n), command or "command %s" % key.split("/")[1])


def timing_of_steps(pool, steps, queue_depth):
    """The timing of a sequence of this recording as data (dg_seq_timing.timing): per step its key, its command, the gap before it as
    recorded and as searched (microseconds). `steps` are replay steps of the pool (source_row, gap_us), the failing command last."""
    keys = step_keys(pool)
    out = []
    for s in steps:
        r = s.get("source_row")
        if r not in keys or s.get("position") == "below":
            continue
        out.append({"key": keys[r], "command": s.get("command"), "gap_recorded_us": int(pool.recorded_gap[r]), "gap_searched_us": int(s.get("gap_us") or pool.recorded_gap[r])})
    return {"steps": out, "queue_depth": int(queue_depth or 1), "key_basis": "class, opcode and place counted back from the failing command, among the commands the search was given"}


def timing_from_stored_steps(steps):
    """For a solution stored before timing was kept: keys counted within its own stored steps (weaker: the recording's other commands
    are not known), gaps as stored."""
    above = [s for s in steps or [] if s.get("position") not in ("fault", "below")]
    fault = next((s for s in steps or [] if s.get("position") == "fault"), None)
    seen, out = {}, []
    for s in reversed(above):
        k = (_class(s), s.get("opc"))
        seen[k] = seen.get(k, 0) + 1
        g = s.get("gap_us")
        out.append({"key": "%s/%s/-%d" % (k[0], ("%02Xh" % k[1]) if isinstance(k[1], int) else "?", seen[k]), "command": s.get("command"),
                    "gap_recorded_us": g, "gap_searched_us": g})
    out.reverse()
    if fault is not None:
        out.append({"key": "fault", "command": fault.get("command"), "gap_recorded_us": fault.get("gap_us"), "gap_searched_us": fault.get("gap_us")})
    return {"steps": out, "queue_depth": 1, "key_basis": "counted within the solution's own stored steps (it was stored before timing was kept)"}


def named_values(timing):
    """The timing values of a sequence as a list of named values with units (dg_lab.timing)."""
    out = []
    for s in (timing or {}).get("steps") or []:
        if s.get("gap_searched_us") is None:
            continue
        out.append({"name": "the gap before %s" % key_words(s["key"], s.get("command")), "key": "gap:" + s["key"], "value": s["gap_searched_us"], "unit": "microseconds"})
    out.append({"name": "the queue depth (commands kept open at once)", "key": "queue_depth", "value": int((timing or {}).get("queue_depth") or 1), "unit": "commands"})
    return out


def apply_timing(pool, timing):
    """A stored sequence put onto this recording, unchanged: each stored step is the command of this recording with the same key.
    -> (candidate of the pool, said: what was dropped or changed, in words, dropped: how many steps had no counterpart)."""
    by_key = {k: r for r, k in step_keys(pool).items()}
    rows, gaps, said, dropped = [], {}, [], 0
    for i, s in enumerate((timing or {}).get("steps") or []):
        key = s.get("key")
        r = by_key.get(key)
        if key == "fault":
            if s.get("gap_searched_us"):
                gaps[pool.frow] = int(s["gap_searched_us"])
            continue
        if r is None or r in rows:
            dropped += 1
            said.append("stored step %d (%s) has no counterpart in this recording: dropped" % (i + 1, key_words(key, s.get("command"))))
            continue
        rows.append(r)
        if s.get("gap_searched_us"):
            gaps[r] = int(s["gap_searched_us"])
    if not pool.legal(rows):
        rows = sorted(rows)
        said.append("the stored order is not a legal order in this recording (commands that depend on each other): the recorded order is used")
    qd = int((timing or {}).get("queue_depth") or 1)
    if qd > pool.max_queue_depth:
        said.append("the stored queue depth of %d commands is deeper than this recording showed (%d): %d is used" % (qd, pool.max_queue_depth, pool.max_queue_depth))
    gaps = {r: max(1, min(GAP_LIMIT_US, g)) for r, g in gaps.items()}
    return pool.candidate(rows, gaps, qd), said, dropped


# ---------------------------------------------------------------------------------------------- brackets (point 3)
def direction_of(value_key):
    """A gap is stressful downwards (the failure is looked for at and below a value); the queue depth upwards."""
    return "at_least" if value_key == "queue_depth" else "at_most"


def value_name(value_key, command=None):
    if value_key == "queue_depth":
        return "the queue depth (commands kept open at once)"
    return "the gap before %s" % key_words(value_key.split(":", 1)[1] if ":" in value_key else value_key, command)


def observations(result, pool):
    """What one finished search says about each timing value, as counts at a value: [{"key", "unit", "value", "runs", "reproduced"}].

    "The failure came back at this value": every timing value of a candidate that brought the failure back in at least YES_SHARE of at
    least two runs. "It stayed away at this value": only from a candidate without the failure (at least NO_MIN_RUNS runs) that differs
    from a candidate with the failure in THIS ONE value and nothing else (same commands, same order, every other value equal): a
    candidate that fails because a command is missing says nothing about a gap."""
    keys = step_keys(pool)
    cands = []
    for c in result.get("candidates") or []:
        if not c.get("runs"):
            continue
        vals = {"queue_depth": c["queue_depth"]}
        for r, g in zip(c["rows"], c["gaps_us"]):
            if r in keys:
                vals["gap:" + keys[r]] = g
        cands.append({"rows": tuple(c["rows"]), "vals": vals, "runs": c["runs"], "k": c["reproduced"]})
    yes = [c for c in cands if c["runs"] >= 2 and c["k"] >= 1 and c["k"] >= YES_SHARE * c["runs"]]
    agg = {}

    def add(key, value, runs, k):
        a = agg.setdefault((key, value), [0, 0])
        a[0] += runs
        a[1] += k
    for c in yes:
        for key, v in c["vals"].items():
            add(key, v, c["runs"], c["k"])
    for c in cands:
        if c["k"] or c["runs"] < NO_MIN_RUNS:
            continue
        for y in yes:
            if y["rows"] != c["rows"]:
                continue
            diff = [k for k in c["vals"] if c["vals"][k] != y["vals"].get(k)]
            if len(diff) == 1:
                add(diff[0], c["vals"][diff[0]], c["runs"], 0)
                break
    return [{"key": k, "unit": "commands" if k == "queue_depth" else "microseconds", "value": v, "runs": a[0], "reproduced": a[1]} for (k, v), a in sorted(agg.items())]


def bracket(rows, value_key):
    """The bracket and the best stored value of one timing value from its counts at a value (rows: dicts with value, runs, reproduced).

    A value "came back" when the failure came back in at least YES_SHARE of all its runs; it "stayed away" when it has at least
    NO_MIN_RUNS runs and none with the failure; anything between is unclear and moves neither end.
    For a gap: came_back_at = the LARGEST value at which the failure still came back; stayed_away_at = the SMALLEST value above it at
    which it did not. (For the queue depth the other way round.)
    Contradictory runs (the failure stayed away at a value at or inside the came-back end): the came-back end stays, because a run
    with the failure proves the failure is possible there while a run without it can be a random miss or another condition; those
    runs are counted in "contradicted_runs" and said in the words. The best stored value is the came-back value with the most runs
    behind it (on a tie the higher share, then the one nearer the came-back end)."""
    per = {}
    for r in rows:
        a = per.setdefault(r["value"], [0, 0])
        a[0] += int(r["runs"])
        a[1] += int(r["reproduced"])
    yes = {v: a for v, a in per.items() if a[1] >= 1 and a[1] >= YES_SHARE * a[0]}
    no = {v: a for v, a in per.items() if a[1] == 0 and a[0] >= NO_MIN_RUNS}
    down = direction_of(value_key) == "at_most"
    unit = "commands" if value_key == "queue_depth" else "microseconds"
    out = {"key": value_key, "unit": unit, "direction": direction_of(value_key), "came_back_at": None, "came_back_runs": None, "stayed_away_at": None,
           "stayed_away_runs": None, "best": None, "best_runs": None, "contradicted_runs": 0, "runs": sum(a[0] for a in per.values())}
    if yes:
        edge = max(yes) if down else min(yes)
        out["came_back_at"], out["came_back_runs"] = edge, [yes[edge][1], yes[edge][0]]
        best = max(yes, key=lambda v: (yes[v][0], yes[v][1] / yes[v][0], v if down else -v))
        out["best"], out["best_runs"] = best, [yes[best][1], yes[best][0]]
        outside = [v for v in no if (v > edge if down else v < edge)]
        out["contradicted_runs"] = sum(no[v][0] for v in no if v not in outside)
    else:
        outside = list(no)
    if outside:
        e2 = min(outside) if down else max(outside)
        out["stayed_away_at"], out["stayed_away_runs"] = e2, [0, no[e2][0]]
    return out


def _num(v):
    return "%d" % v if float(v) == int(v) else "%s" % v


def bracket_words(b, name):
    parts = []
    if b["came_back_at"] is not None:
        parts.append("the failure still came back at %s %s (in %d of %d runs)" % (_num(b["came_back_at"]), b["unit"], b["came_back_runs"][0], b["came_back_runs"][1]))
    if b["stayed_away_at"] is not None:
        parts.append("it %s at %s %s (0 of %d runs)" % ("no longer came back" if b["came_back_at"] is not None else "did not come back", _num(b["stayed_away_at"]), b["unit"], b["stayed_away_runs"][1]))
    if b["contradicted_runs"]:
        parts.append("%d run(s) without the failure lie inside the range where it came back (a random miss or another condition): they do not move the range" % b["contradicted_runs"])
    return "%s: %s" % (name, "; ".join(parts) if parts else "no run says yet where the failure comes back")


# ---------------------------------------------------------------------------------------------- firmware and model inheritance
def _same(a, b):
    return " ".join(str(a or "").lower().split()) == " ".join(str(b or "").lower().split())


LEVEL_WORDS = {"same_firmware": "from this drive model and this firmware",
               "earlier_firmware": "from an earlier firmware of the same drive model: used only as a starting point",
               "other_model": "from other drive models with this kind of defect: used only as a starting point"}


def scope(rows, model, firmware):
    """The rows a search may start from, by inheritance: the same drive model and firmware; else another firmware of the same model
    (marked "from an earlier firmware"); else what the defect holds from other models. -> (rows, level) ; ([], None) when none."""
    same = [r for r in rows if _same(r.get("model"), model) and _same(r.get("firmware"), firmware)]
    if same:
        return same, "same_firmware"
    fw = [r for r in rows if _same(r.get("model"), model)]
    if fw:
        return fw, "earlier_firmware"
    return (list(rows), "other_model") if rows else ([], None)


# ---------------------------------------------------------------------------------------------- which stored solution leads (point 4)
def lead_draw(solutions, rnd):
    """One draw per stored solution; the highest leads. solutions: [{"id", "k", "n", "level"}] (lab runs on this bench, counted rows only).

        p_cause = (K + 1) / (N + 2)                    K of N = the lab runs of all solutions of the cause (its own share, neutral start)
        k', n'  = k, n                                 for rows of this drive model and firmware
                  k * w, n * w with w = min(1, STALE_CAP_RUNS / n)     for rows of another firmware or model (a starting point only)
        draw    ~ Beta(k' + PRIOR_RUNS * p_cause, (n' - k') + PRIOR_RUNS * (1 - p_cause))
    With no lab run anywhere every solution draws from Beta(1, 1). The admins' judgements are not in this formula: they order what is
    SHOWN; the lab counts order what is TRIED first. -> (the leading solution or None, [{"id", "draw", "alpha", "beta"}])."""
    if not solutions:
        return None, []
    big_k, big_n = sum(s["k"] for s in solutions), sum(s["n"] for s in solutions)
    p = (big_k + 1.0) / (big_n + 2.0)
    out = []
    for s in solutions:
        k, n = float(s["k"]), float(s["n"])
        if s.get("level") != "same_firmware" and n > 0:
            w = min(1.0, STALE_CAP_RUNS / n)
            k, n = k * w, n * w
        a, b = k + PRIOR_RUNS * p, (n - k) + PRIOR_RUNS * (1 - p)
        out.append({"id": s["id"], "alpha": round(a, 4), "beta": round(b, 4), "draw": rnd.betavariate(a, b)})
    top = max(out, key=lambda x: (x["draw"], -x["id"]))
    return next(s for s in solutions if s["id"] == top["id"]), out


def plan(graph, pool, seed, defect_id, cause_id, bench, model, firmware, rng_seed=0):
    """What a search on this recording starts from, read from the graph. None when the graph holds nothing usable for this kind of defect
    (the search then runs exactly as without the graph).
    -> {"first": [{"cand", "how", "role", ...}] the candidates tried before anything else (the stored solution unchanged; the first
        sequence with its timing values at the stored best values), "words": the sentence for the admin, "said": what was dropped,
        "lead": the solution that leads with its counts, "draws", "brackets", "level"}"""
    bench = bench_label(bench)
    sols = graph.lab_candidates(defect_id, cause_id, bench, model, firmware)
    br = graph.timing_brackets(defect_id, cause_id, bench, model, firmware)
    lead, draws = lead_draw(sols, random.Random((int(rng_seed or 0) * 2654435761 + 97) % (2 ** 32)))
    first, said, parts = [], [], []
    if lead is not None:
        cand, said, dropped = apply_timing(pool, lead["timing"])
        lab = ("came back in %d of %d runs on the %s" % (lead["shown_k"], lead["shown_n"], bench)) if lead["shown_n"] else "has no lab run on the %s yet" % bench
        if lead["shown_n"] and lead["level"] != "same_firmware":
            lab += " (%s)" % LEVEL_WORDS[lead["level"]]
        parts.append("solution %s, which %s" % (lead["label"], lab))
        first.append({"cand": cand, "role": "stored_solution", "solution_id": lead["id"], "revision_id": lead["revision_id"], "dropped": dropped,
                      "how": "from the graph: stored solution %s put onto this recording, unchanged%s" % (lead["label"], (" (%d step(s) without counterpart dropped)" % dropped) if dropped else "")})
    best = {b["key"]: b for b in (br or {}).get("values") or [] if b.get("best") is not None}
    if best:
        keys = step_keys(pool)
        gaps, qd, moved = dict(seed["gaps"]), seed["queue_depth"], []
        for r in list(seed["rows"]) + [pool.frow]:
            b = best.get("gap:" + keys[r])
            if b is not None and int(b["best"]) != gaps[r]:
                gaps[r] = max(1, min(GAP_LIMIT_US, int(b["best"])))
                moved.append(r)
        if "queue_depth" in best:
            qd = max(1, min(pool.max_queue_depth, int(best["queue_depth"]["best"])))
        cand2 = pool.candidate(seed["rows"], gaps, qd)
        if moved or qd != seed["queue_depth"]:
            first.append({"cand": cand2, "role": "stored_timing", "how": "from the graph: the first sequence with its timing values at the best stored values"})
        fb = best.get("gap:fault")
        if fb is not None:
            lo, hi = fb["came_back_at"], fb["stayed_away_at"]
            parts.append("the gap before the failing command started at %s microseconds (the failure still came back at %s microseconds%s; %s)" % (
                _num(fb["best"]), _num(lo), (" and no longer at %s microseconds" % _num(hi)) if hi is not None else "; no run says yet where it stops coming back",
                LEVEL_WORDS[br["level"]]))
    if not first:
        return None
    words = "Started from what the graph holds for this kind of defect%s: %s." % (" and cause" if (br or {}).get("cause_used") or (lead and cause_id) else "", "; ".join(parts) or "its stored timing values")
    return {"first": first, "words": words, "said": said, "lead": {k: v for k, v in (lead or {}).items() if k != "timing"} or None, "draws": draws,
            "brackets": (br or {}).get("values") or [], "level": (br or {}).get("level"),
            "formula": "draw ~ Beta(k + %g * p, (n - k) + %g * (1 - p)); p = (K + 1) / (N + 2) over the cause's lab runs; runs of another firmware or model count as at most %g runs "
                       "(all three constants chosen here, to be measured)" % (PRIOR_RUNS, PRIOR_RUNS, STALE_CAP_RUNS)}


# ---------------------------------------------------------------------------------------------- the tables' functions (mixed into DefectGraph)
class LabLedger:
    """The functions of dg_lab, dg_seq_timing and dg_timing. defect_graph.DefectGraph inherits them (self._con() is its connection)."""

    def add_lab(self, solution_id, bench, source, runs, reproduced, by, revision_id=None, timing=None, fault_time_us=None, model=None, firmware=None,
                upload_id=None, finding_id=None, counted=True, note=None):
        """One lab result of a stored solution: a row is added, nothing else changes (no verdict, no ranking). A failed run counts against
        this solution, never against its cause (the owner has not decided otherwise). -> the row's id.
        Also the function a validation suite's results can be brought in with (source "validation_suite"; nvme_hier/handover.py)."""
        bench = bench_label(bench)
        if source not in SOURCES:
            raise ValueError("what produced the lab result is one of: %s" % ", ".join(SOURCES))
        runs = _count(runs, "the number of runs", 1)
        reproduced = _count(reproduced, "the number of runs in which the failure came back", 0)
        if reproduced > runs:
            raise ValueError("the failure cannot have come back in more runs than were made")
        who = _text(by, "who started it")
        if not who:
            raise ValueError("say who started the lab runs (a name)")
        values = clean_values(timing)
        if fault_time_us is not None:
            fault_time_us = float(_number(fault_time_us, "the measured time of the failing command (microseconds)", 0.0, 10.0 ** 13))
        if isinstance(solution_id, bool) or not isinstance(solution_id, int) or not 0 < solution_id < 2 ** 62:
            raise ValueError("no such stored solution")
        if finding_id is not None and (isinstance(finding_id, bool) or not isinstance(finding_id, int) or not -2 ** 62 < finding_id < 2 ** 62):
            raise ValueError("the error's number must be a whole number")
        con = self._con()
        try:
            s = con.execute("SELECT s.id, s.cause_id, c.defect_id FROM dg_solution s LEFT JOIN dg_cause c ON c.id = s.cause_id WHERE s.id=?", (solution_id,)).fetchone()
            if s is None:
                raise ValueError("no such stored solution")
            if revision_id is None:
                revision_id = con.execute("SELECT id FROM dg_revision WHERE solution_id=? ORDER BY version DESC LIMIT 1", (solution_id,)).fetchone()["id"]
            elif isinstance(revision_id, bool) or not isinstance(revision_id, int) or con.execute("SELECT 1 FROM dg_revision WHERE id=? AND solution_id=?", (revision_id, solution_id)).fetchone() is None:
                raise ValueError("that version is not a version of this solution")
            keep = 0 if (source in NOT_COUNTED_SOURCES or not counted) else 1
            rid = con.execute("INSERT INTO dg_lab (solution_id, revision_id, defect_id, cause_id, bench, source, runs, reproduced, counted, timing, fault_time_us, model, firmware, "
                              "upload_id, finding_id, at, by, note) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                              (solution_id, revision_id, s["defect_id"], s["cause_id"], bench, source, runs, reproduced, keep, json.dumps(values), fault_time_us,
                               _text(model, "the drive's model"), _text(firmware, "the drive's firmware"), _text(upload_id, "the recording"), finding_id, time.time(), who,
                               _text(note, "the note", 600))).lastrowid
            con.commit()
            return rid
        finally:
            con.close()

    @staticmethod
    def _lab_row(r):
        d = dict(r)
        d["timing"] = json.loads(d.get("timing") or "[]")
        d["counted"] = bool(d.get("counted"))
        d["source_words"] = SOURCES.get(d["source"], d["source"])
        d["when"] = time.strftime("%Y-%m-%d %H:%M", time.localtime(d.get("at") or 0))
        d["words"] = "the failure came back in %d of %d run%s on the %s (%s)%s" % (d["reproduced"], d["runs"], "" if d["runs"] == 1 else "s", d["bench"], d["source_words"],
                                                                                 "" if d["counted"] else "; shown, not counted")
        return d

    def lab_rows(self, solution_id=None, defect_id=None):
        con = self._con()
        try:
            if solution_id is not None:
                q = con.execute("SELECT * FROM dg_lab WHERE solution_id=? ORDER BY id", (int(solution_id),))
            else:
                q = con.execute("SELECT * FROM dg_lab WHERE defect_id=? ORDER BY id", (int(defect_id),))
            return [self._lab_row(r) for r in q]
        finally:
            con.close()

    def lab_summary(self, con, solution_id):
        """The lab ledger of one solution for the page: per bench "the failure came back in k of n" over the counted rows, kept apart from
        the judgements. -> {"simulated": {...} or None, "real": {...} or None, "lines": [words], "not_counted": words or None}."""
        out = {"simulated": None, "real": None, "lines": [], "not_counted": None}
        rows = [dict(r) for r in con.execute("SELECT bench, source, runs, reproduced, counted, model, firmware FROM dg_lab WHERE solution_id=?", (solution_id,))]
        for name, bench in (("simulated", BENCH_SIM), ("real", BENCH_REAL)):
            mine = [r for r in rows if r["bench"] == bench and r["counted"]]
            if not mine:
                continue
            k, n = sum(r["reproduced"] for r in mine), sum(r["runs"] for r in mine)
            fw = sorted({"%s, firmware %s" % (r["model"] or "a drive not named", r["firmware"] or "not named") for r in mine})
            out[name] = {"reproduced": k, "runs": n, "results": len(mine), "drives": fw,
                         "words": "lab runs: the failure came back in %d of %d on the %s" % (k, n, bench)}
            out["lines"].append(out[name]["words"])
        rest = [r for r in rows if not r["counted"]]
        if rest:
            out["not_counted"] = ("%d further run(s) are kept but not counted (the written test's own check on a simulated drive with the fault planted, or a replay in which a "
                                  "stored step had no counterpart)" % sum(r["runs"] for r in rest))
        if not out["lines"]:
            out["lines"].append("lab runs: none yet")
        return out

    # ------------------------------------------------------------------ timing of a solution's sequence (values)
    def set_seq_timing(self, solution_id, timing, by, revision_id=None, upload_id=None, finding_id=None, model=None, firmware=None):
        if not isinstance(timing, dict) or not isinstance(timing.get("steps"), list) or len(timing["steps"]) > 2000:
            raise ValueError("the timing of a sequence is a list of steps with their gaps")
        steps = []
        for s in timing["steps"]:
            if not isinstance(s, dict) or not isinstance(s.get("key"), str) or len(s["key"]) > 80:
                raise ValueError("every step of a sequence's timing needs its key")
            x = {"key": s["key"], "command": _text(s.get("command"), "the command", 120)}
            for g in ("gap_recorded_us", "gap_searched_us"):
                x[g] = None if s.get(g) is None else int(_number(s.get(g), "a gap (microseconds)", 1))
            steps.append(x)
        qd = _count(timing.get("queue_depth", 1), "the queue depth", 1, 65535)
        con = self._con()
        try:
            if con.execute("SELECT 1 FROM dg_solution WHERE id=?", (int(solution_id),)).fetchone() is None:
                raise ValueError("no such stored solution")
            if revision_id is None:
                revision_id = con.execute("SELECT id FROM dg_revision WHERE solution_id=? ORDER BY version DESC LIMIT 1", (int(solution_id),)).fetchone()["id"]
            rid = con.execute("INSERT INTO dg_seq_timing (solution_id, revision_id, timing, queue_depth, key_basis, upload_id, finding_id, model, firmware, at, by) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                              (int(solution_id), revision_id, json.dumps(steps), qd, _text(timing.get("key_basis"), "the key's basis", 300), upload_id, finding_id, model, firmware, time.time(), by)).lastrowid
            con.commit()
            return rid
        finally:
            con.close()

    def seq_timing(self, solution_id, con=None):
        """The stored timing of a solution's current sequence, or what its stored steps give when none was kept. None when it has no steps."""
        own = con is None
        con = con or self._con()
        try:
            cur = con.execute("SELECT * FROM dg_revision WHERE solution_id=? ORDER BY version DESC LIMIT 1", (int(solution_id),)).fetchone()
            if cur is None:
                return None
            r = con.execute("SELECT * FROM dg_seq_timing WHERE solution_id=? AND revision_id=? ORDER BY id DESC LIMIT 1", (int(solution_id), cur["id"])).fetchone()
            if r is not None:
                return {"steps": json.loads(r["timing"]), "queue_depth": r["queue_depth"], "key_basis": r["key_basis"], "stored": True, "revision_id": cur["id"]}
            t = timing_from_stored_steps(json.loads(cur["error_seq"] or "[]"))
            return dict(t, stored=False, revision_id=cur["id"]) if t["steps"] else None
        finally:
            if own:
                con.close()

    # ------------------------------------------------------------------ counts at a value, and the brackets read from them
    def add_timing(self, defect_id, cause_id, obs, bench, by, model=None, firmware=None, source="search", upload_id=None, finding_id=None):
        """Counts at a value from one search (observations()). Rows are added; the brackets are computed when read. -> how many rows."""
        bench = bench_label(bench)
        con = self._con()
        try:
            n = 0
            for o in obs or []:
                con.execute("INSERT INTO dg_timing (defect_id, cause_id, value_key, unit, value, runs, reproduced, bench, model, firmware, source, upload_id, finding_id, at, by) "
                            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (int(defect_id), int(cause_id) if cause_id else None, str(o["key"])[:80], str(o["unit"])[:40], _number(o["value"], "a timing value"),
                             _count(o["runs"], "runs", 1), _count(o["reproduced"], "reproduced", 0), bench, _text(model, "model"), _text(firmware, "firmware"), source,
                             upload_id, finding_id, time.time(), by))
                n += 1
            con.commit()
            return n
        finally:
            con.close()

    def timing_brackets(self, defect_id, cause_id=None, bench=BENCH_SIM, model=None, firmware=None):
        """Per timing value its bracket and best stored value for this kind of defect (and cause, when it has rows), on one bench, by
        inheritance (scope): this model and firmware; else an earlier firmware of the model; else what the defect holds. None when empty."""
        bench = bench_label(bench)
        con = self._con()
        try:
            rows = [dict(r) for r in con.execute("SELECT * FROM dg_timing WHERE defect_id=? AND bench=?", (int(defect_id), bench))]
        finally:
            con.close()
        mine = [r for r in rows if cause_id and r["cause_id"] == int(cause_id)]
        cause_used = bool(mine)
        used, level = scope(mine or rows, model, firmware)
        if not used:
            return None
        by_key = {}
        for r in used:
            by_key.setdefault(r["value_key"], []).append(r)
        values = []
        for key in sorted(by_key, key=lambda k: (k != "gap:fault", k != "queue_depth", k)):
            b = bracket(by_key[key], key)
            b["name"] = value_name(key)
            b["words"] = bracket_words(b, b["name"])
            values.append(b)
        return {"bench": bench, "level": level, "level_words": LEVEL_WORDS[level], "cause_used": cause_used,
                "basis_words": "for this kind of defect and this cause" if cause_used else "for this kind of defect (all its causes together)", "values": values}

    def lab_candidates(self, defect_id, cause_id, bench, model, firmware):
        """The stored solutions a search may start from (those of the cause when one is chosen, else all of the defect's causes), each with
        its timing and its lab counts on this bench by inheritance. The order is by id: the draw decides which leads."""
        bench = bench_label(bench)
        con = self._con()
        try:
            if cause_id:
                causes = [int(cause_id)]
            else:
                causes = [r["id"] for r in con.execute("SELECT id FROM dg_cause WHERE defect_id=?", (int(defect_id),))]
            out = []
            for cid in causes:
                ranks = {x["id"]: x["rank"] for x in self.solutions(cid, con)}
                for sid, rank in sorted(ranks.items()):
                    t = self.seq_timing(sid, con)
                    if t is None:
                        continue
                    rows = [dict(r) for r in con.execute("SELECT runs, reproduced, model, firmware FROM dg_lab WHERE solution_id=? AND bench=? AND counted=1", (sid, bench))]
                    used, level = scope(rows, model, firmware)
                    k, n = sum(r["reproduced"] for r in used), sum(r["runs"] for r in used)
                    out.append({"id": sid, "revision_id": t["revision_id"], "cause_id": cid, "rank": rank, "label": "%d" % sid, "timing": t, "k": k, "n": n,
                                "shown_k": k, "shown_n": n, "level": level or "same_firmware", "timing_stored": t["stored"]})
            return out
        finally:
            con.close()

    def lab_context(self, upload_id, finding_id):
        """The defect and the cause the admin recorded for one error of one recording, or None when it is not in the graph."""
        con = self._con()
        try:
            r = con.execute("SELECT id, defect_id, cause_id, device, firmware FROM dg_occurrence WHERE upload_id=? AND finding_id=?", (str(upload_id), int(finding_id))).fetchone()
            return dict(r) if r else None
        finally:
            con.close()

    def store_searched(self, cause_id, steps, timing, by, bench, runs, reproduced, revision_of=None, fault_time_us=None, model=None, firmware=None,
                       upload_id=None, finding_id=None, note=None):
        """The admin's press "Store this sequence as a solution of the cause": the searched sequence becomes a new solution of the cause
        (not judged: no verdict is written) or, with revision_of, the next version of a stored solution of that cause. Its timing is
        stored as data and the search's own result as its first lab row. -> {"solution_id", "revision_id", "lab_id", "new"}."""
        who = _text(by, "your name")
        if not who:
            raise ValueError("say who you are (your name) first: a solution is stored with the name of the admin who stored it")
        con = self._con()
        try:
            c = con.execute("SELECT id FROM dg_cause WHERE id=?", (int(cause_id),)).fetchone()
            if c is None:
                raise ValueError("no such cause")
            if revision_of is not None:
                s = con.execute("SELECT id, cause_id, status FROM dg_solution WHERE id=?", (int(revision_of),)).fetchone()
                if s is None or s["status"] != "active" or s["cause_id"] != int(cause_id):
                    raise ValueError("that stored solution is not a solution of this cause")
        finally:
            con.close()
        text = note or "sequence found by the replay search on the %s; stored by %s" % (bench_label(bench), who)
        if revision_of is None:
            sid, rid = self.add_solution(int(cause_id), steps, [], text, "replay search, stored by %s" % who, who, upload_id, finding_id)
        else:
            sid = int(revision_of)
            con = self._con()
            try:
                rid = self.revise(con, sid, steps, None, text, who)
                con.commit()
            finally:
                con.close()
        self.set_seq_timing(sid, timing, who, revision_id=rid, upload_id=upload_id, finding_id=finding_id, model=model, firmware=firmware)
        lab = self.add_lab(sid, bench, "search", runs, reproduced, who, revision_id=rid, timing=named_values(timing), fault_time_us=fault_time_us, model=model,
                           firmware=firmware, upload_id=upload_id, finding_id=finding_id, note="the search's own confirmation of this sequence")
        return {"solution_id": sid, "revision_id": rid, "lab_id": lab, "new": revision_of is None}


# ---------------------------------------------------------------------------------------------- after a search: what is written back
def write_back(graph, pool, result, plan_used, defect_id, cause_id, by, model=None, firmware=None, upload_id=None, finding_id=None):
    """After a finished search: the lab row of the stored solution that led (its own replay: k of n; a failure counts against that
    solution, never against the cause), and the counts at a value for the brackets. Nothing is stored as a solution here.
    -> {"lab_rows": [...ids], "timing_rows": n, "words": [...]}"""
    bench = bench_label((result.get("bench") or {}).get("kind"))
    out = {"lab_rows": [], "timing_rows": 0, "words": []}
    for f in (result.get("started_from") or []):
        if f.get("role") != "stored_solution" or not f.get("runs"):
            continue
        counted = not f.get("dropped")
        lid = graph.add_lab(f["solution_id"], bench, "search", f["runs"], f["reproduced"], by, revision_id=f.get("revision_id"), timing=named_values(timing_of_steps(pool, f.get("steps") or [], f.get("queue_depth"))),
                            fault_time_us=f.get("mean_time_us"), model=model, firmware=firmware, upload_id=upload_id, finding_id=finding_id, counted=counted,
                            note=None if counted else "%d stored step(s) had no counterpart in this recording: the replay was not the whole solution, so it is not counted" % f["dropped"])
        out["lab_rows"].append(lid)
        out["words"].append("written to the graph: solution %s, replayed unchanged, brought the failure back in %d of %d runs on the %s%s" % (
            f["solution_id"], f["reproduced"], f["runs"], bench, "" if counted else " (kept, not counted: a stored step had no counterpart)"))
    if defect_id:
        obs = observations(result, pool)
        out["timing_rows"] = graph.add_timing(defect_id, cause_id, obs, bench, by, model=model, firmware=firmware, upload_id=upload_id, finding_id=finding_id)
        if out["timing_rows"]:
            out["words"].append("written to the graph: %d count(s) at a value for the timing brackets of this kind of defect%s" % (out["timing_rows"], " and cause" if cause_id else ""))
    return out
