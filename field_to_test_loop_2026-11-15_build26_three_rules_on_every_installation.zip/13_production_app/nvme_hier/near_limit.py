"""Commands that completed but came close to the limit (project statement S4, "proactive vulnerability analysis"; work item B8).

Everything else in the main flow starts from an error that is already in the recording. This module reports the commands that did NOT
fail by time but came close: for each completed command, how much of the host's limit for its kind it used, and how many times slower
it was than the usual time of its own type and size in this recording. It works on a recording with or without errors.

What it is, and is not:
  - It is an ANALYTICS item, never an error. It opens the recording read-only: it cannot add to the error list (the finding table), the
    error counts or the report's error numbers. A command at or above the host's limit, a command the host aborted and a command without
    a status are the timeout rule's (cmd.timeout, nvme_hier/rules.py) and are never listed here, so no command is counted twice. A
    listed command that the timeout rule also files as "slower than usual" says so in its own column.
  - No limit is invented. The host's limit is exactly what the timeout rule uses (rules.DEFAULT_LIMITS: the Linux NVMe driver's
    defaults, 30 seconds for an I/O command and 60 seconds for an admin command, because the NVMe specification sets no per-command
    limit), or the limit the admin set for the recording. limits_of() reads it the way the timeout rule does.
  - "Usual" is the timeout rule's own: rules.usual_bar() on rules.group_values(rules.TIMEOUT_USUAL_SQL), per command type and size, of
    the completed commands under the host's limit, measured only with at least rules.USUAL_MIN of them. Nothing is defined a second
    time here; tests/test_near_limit.py compares the numbers with the ones the timeout rule itself stores.
  - The share of the limit above which a command is listed is the ADMIN's. The default (DEFAULT_SHARE_PERCENT) is shown with its
    reason, it is the application's starting value and not a number from any specification, and the result always says which value
    was used and who set it.
  - A recording can be 6 GB and more: the list is written to a CSV file row by row, ordered by the database (never sorted in Python
    memory); what comes back in memory is the summary (one entry per command kind) and at most SHOWN_AT_ONCE rows.
  - A command's time is from its Time Stamp to its FIRST completion entry, joined to it in the tree by identity (queue and command
    identifier), never by time stamp. Without the NVMe transactions file no time can be measured, and the result says so.

    result = near_limit.run(db_path, out_csv, share=80, set_by="the admin")      # the list (CSV) and the summary of the recording
    start = near_limit.window(db_path, row)                                       # the starting point of a sweep from one such command
"""
import csv
import json
import math
import os
import sqlite3

from . import names as N
from . import optimise as OPT
from . import osfile as OSF
from . import parse as P
from . import rules as RL

DEFAULT_SHARE_PERCENT = 50.0
DEFAULT_SHARE_REASON = ("50 per cent: a command that used half of the host's limit or more would be over the limit if it took twice as long. "
                        "This is the application's starting value, not a number from the NVMe specification or from the Linux driver; "
                        "the admin can state any share above 0 and below 100 per cent.")
SET_BY_DEFAULT = "nobody: the application's starting value (%s)" % DEFAULT_SHARE_REASON
SHOWN_AT_ONCE = 200               # rows of the list that come back in memory (the whole list is in the CSV file)
PROGRESS_EVERY = 2000             # rows written between two progress reports
STAGE = "Commands close to the limit"
HOST_ABORT_SQL = "((COALESCE(c.sct, 0) = 0 AND c.sc IN (7, 8)) OR (c.sct = 3 AND c.sc = 113))"      # the same three statuses as rules.HOST_ABORT
LIMIT_SQL = "(CASE WHEN c.sqid = 0 THEN ? ELSE ? END)"               # the admin limit for queue 0, the I/O limit for every other queue (as the timeout rule)
# a completed command that the timeout rule does not file for its time or its abort: it has a first completion entry, a Time Stamp and a
# status, the host did not abort it, and it is not one of the commands that are long by nature or wait by design
COMPLETED_SQL = ("FROM cmd c JOIN temp.cmd_end e ON e.rid = c.rowid_file WHERE c.t_ps IS NOT NULL AND " + RL.NOT_TIMED_SQL +
                 " AND NOT (c.sct IS NULL AND c.sc IS NULL) AND NOT " + HOST_ABORT_SQL)
LIST_SQL = ("SELECT c.rowid_file, c.n, c.opc, c.sqid, c.cid, " + RL.BLOCKS_SQL + ", c.sct, c.sc, " + RL.CMD_TIME_SQL + " AS dur, b.n, b.median_ps, b.bar_ps "
            "FROM cmd c JOIN temp.cmd_end e ON e.rid = c.rowid_file "
            "LEFT JOIN temp.nl_usual b ON b.adm = (c.sqid = 0) AND b.opc = c.opc AND b.blocks = " + RL.BLOCKS_SQL +
            " WHERE c.t_ps IS NOT NULL AND " + RL.NOT_TIMED_SQL + " AND NOT (c.sct IS NULL AND c.sc IS NULL) AND NOT " + HOST_ABORT_SQL +
            " AND " + RL.CMD_TIME_SQL + " < " + LIMIT_SQL + " AND " + RL.CMD_TIME_SQL + " >= " + LIMIT_SQL +
            " ORDER BY (" + RL.CMD_TIME_SQL + " * 1.0 / " + LIMIT_SQL + ") DESC, c.rowid_file")

# every column of the list, with its meaning (no column without its meaning)
OUTPUT_COLUMNS = [
    ("row of the NVMe command file", "the command's row in the NVMe command file, counted under the header (row 1 is line 2 of the file)"),
    ("command number (column NVMe Cmd)", "the analyzer's own number of the command, the cell of the column NVMe Cmd"),
    ("submission queue (column SQID)", "the queue the command was sent on: queue 0 carries the admin commands, every other queue the I/O commands"),
    ("command identifier (column CID)", "the identifier the host gave the command; with the queue it joins the command to its completion entry"),
    ("command kind", "which command it is, named from its command code (column OPC) by the NVMe specification's lists"),
    ("size (blocks)", "the number of blocks the command names (column NLB plus 1, because NLB counts from 0); empty for an admin command or when the cell is empty"),
    ("measured time", "from the command's Time Stamp to its first completion entry in the NVMe transactions file, with its unit"),
    ("measured time (picoseconds)", "the same time as a whole number of picoseconds (1 second = 1,000,000,000,000 picoseconds)"),
    ("the host's limit for this kind", "the time after which the host gives the command up, with its unit"),
    ("source of the limit", "where the limit comes from: the Linux NVMe driver's default, or the admin's own value (the NVMe specification sets no limit per command)"),
    ("share of the limit used (per cent)", "measured time divided by the host's limit, times 100; never rounded up"),
    ("margin left (per cent of the limit)", "100 minus the share used: how much of the limit was still free"),
    ("usual time for its kind and size", "the middle time of the normal completed commands of the same kind and size in this recording (the timeout rule's own measure), with its unit"),
    ("times slower than the usual time", "measured time divided by the usual time; empty when no usual time could be measured"),
    ("about the usual time", "how many commands the usual time was measured on, or why there is none"),
    ("what the timeout rule says of this command", "whether the timeout rule also files this command as an error (slower than usual); a near-limit entry itself is never an error"),
    ("status the drive answered", "the status code type and status code of the completion (columns ST.SCT and ST.SC); 0h/00h is Successful Completion"),
]
SUMMARY_COLUMNS = [
    ("command kind", "which command, named from its command code by the NVMe specification's lists"),
    ("completed commands measured", "how many commands of this kind completed with a measurable time and are judged here"),
    ("the host's limit for this kind", "the time after which the host gives the command up, with its unit"),
    ("source of the limit", "where the limit comes from"),
    ("largest share of the limit used (per cent)", "the slowest completed command of this kind under the limit, as a share of the limit; never rounded up"),
    ("slowest time under the limit", "that command's measured time, with its unit"),
    ("row of that command", "its row in the NVMe command file, counted under the header"),
    ("commands at or above the admin's share", "how many commands of this kind are in the list"),
    ("margin left (per cent of the limit)", "100 minus the largest share"),
    ("at or above the limit (errors of the timeout rule, not counted here)", "completed commands of this kind that took the host's limit or longer: the timeout rule files them, this item does not"),
    ("in plain words", "one sentence for this kind"),
]

# ---- the item as a built-in item of the rules library (Section 1, data analytics; level NVMe command), in the structure of the two
# existing analytics items (agentic/family3.py seed(): the item; agentic/procedures.py SEEDS: its procedure; STANDIN_CODE: its code).
# This module does not write the item anywhere: agentic/ and knowledge/ are not its files. See "needed from others" in the build report.
ITEM_ID = "near_limit"
ITEM = {
    "id": ITEM_ID, "section": "analytics", "level": "nvme_command", "name": "Commands that completed but came close to the limit",
    "description": "Which commands did not fail but used a large share of the time the host allows, and how much margin every command kind had left.",
    "definition": "Every NVMe command that completed is measured from its Time Stamp to its first completion entry (joined to it in the tree by queue and "
                  "command identifier). The time is compared with the host's limit for its kind: 30 seconds for an I/O command and 60 seconds for an admin "
                  "command, the Linux NVMe driver's defaults, unless the admin set another limit for the recording (the NVMe specification sets no limit "
                  "per command). A command is listed when it used at least the share of the limit the admin states and stayed under the limit. A command at "
                  "or above the limit, a command the host aborted and a command without a status are errors of the timeout rule and are not listed here. "
                  "Each listed command also says how many times slower it was than the usual time of its own kind and size in this recording (the timeout "
                  "rule's measure, with at least 20 completed commands of that kind and size). The summary gives, per command kind, the largest share used, "
                  "how many are listed and the margin left. This is analytics: it never adds to the errors.",
    "kind": "near_limit", "plan": {"share_percent": DEFAULT_SHARE_PERCENT, "share_reason": DEFAULT_SHARE_REASON, "share_set_by": SET_BY_DEFAULT},
    "family1": {"columns": ["OPC", "SQID", "CID", "NLB", "ST.SCT", "ST.SC", "Time Stamp"]},
    "source": "the project statement, S4 (proactive vulnerability analysis); work item B8 of deploy/REAL_ENVIRONMENT_WORK.md",
}
PROCEDURE = {
    "source_data": [{"file": "the tree", "columns": ["nvme_command: OPC", "nvme_command: SQID", "nvme_command: CID", "nvme_command: NLB", "nvme_command: ST.SCT",
                                                     "nvme_command: ST.SC", "nvme_command: Time Stamp", "nvme_transaction: Type", "nvme_transaction: Time Stamp"]}],
    "steps": [
        "The admin's share: %s per cent of the host's limit (%s). The result says which value was used and who set it." % ("%g" % DEFAULT_SHARE_PERCENT, DEFAULT_SHARE_REASON),
        "The host's limit: 30 seconds for a command on an I/O queue (SQID not 0) and 60 seconds for an admin command (SQID 0), the Linux NVMe driver's "
        "defaults, unless the admin set another limit for this recording. The NVMe specification sets no limit per command.",
        "For each command of the tree: its end is the Time Stamp of its first completion entry among its NVMe transactions (Type is an Admin or I/O Completion "
        "Queue Entry). Its time = that Time Stamp minus the command's Time Stamp. A command without a completion entry has no time and is left out.",
        "Left out, because the timeout rule judges them: a command without a status (ST.SCT and ST.SC empty), a command the host aborted (status 0h/07h, "
        "0h/08h or 3h/71h), a command whose time is the limit or more. Left out, because they are never judged for time: Format NVM, Sanitize, Device "
        "Self-test, Firmware Commit, Firmware Image Download and Asynchronous Event Request.",
        "Share used = time / limit x 100. A command is listed when its share is at or above the admin's share.",
        "Usual time: per command kind (OPC and admin or I/O) and size (the number of blocks the tree keeps for each command, read from the "
        "file's NLB cell when the recording was loaded), the middle time of the normal completed commands under the limit, as the "
        "timeout rule measures it, only with at least 20 of them. Times slower = time / usual time. With fewer than 20 the line says there is no usual time.",
        "Write one line per listed command, the one closest to the limit first (same share: file order).",
        "Summary per command kind: completed commands measured, the largest share used, how many are listed, the margin left (100 minus the largest "
        "share), and when none is listed the sentence that no command of this kind came closer to the limit than that share.",
    ],
    "output": {"columns": [c for c, _m in OUTPUT_COLUMNS], "order": "the largest share of the limit first; the same share in file order"},
    # no open question is seeded: an open question stops the requirements step until the admin answers it, and the share has a stated
    # starting value (step 1 says which and why, the result says that nobody chose it). The admin changes it by editing step 1.
    "open_questions": [],
}


def code_for(share_percent=DEFAULT_SHARE_PERCENT, set_by=None):
    """The code of the item as a procedure on the tree (run(tree, out_csv)), with the admin's share written into it."""
    s = share_of(share_percent, set_by)
    return ("from nvme_hier import near_limit\n\n"
            "SHARE_PER_CENT = %r        # the share of the host's limit a command must reach to be listed\n"
            "SET_BY = %r\n\n\n"
            "def run(tree, out_csv):\n"
            "    # every step of the procedure is done by nvme_hier/near_limit.py, which is part of the application (as the detector's rules are)\n"
            "    return near_limit.run_on_tree(tree, out_csv, share=SHARE_PER_CENT, set_by=SET_BY)\n") % (s["percent"], s["set_by"])


def evidence():
    """What the rules browser shows of an item, for this one: its plain text, its columns with their meaning, its code (file and lines) and what it
    reads, in the structure agentic/rule_evidence.py uses for a detector rule (the columns as (level, internal name), the test in words)."""
    here = os.path.abspath(__file__)
    with open(here, encoding="utf-8") as fh:
        lines = fh.read().split("\n")

    def span(name):
        a = next(i for i, ln in enumerate(lines) if ln.startswith("def %s(" % name))
        b = next((i for i in range(a + 1, len(lines)) if lines[i] and not lines[i][0].isspace() and not lines[i].startswith("#")), len(lines))
        while b > a and not lines[b - 1].strip():
            b -= 1
        return {"function": name, "from": a + 1, "to": b, "text": "\n".join(lines[a:b])}
    return {"name": ITEM["name"], "words": ITEM["definition"],
            "reads": [("nvme_command", "opc"), ("nvme_command", "sqid"), ("nvme_command", "cid"), ("nvme_command", "nlb"), ("nvme_command", "sct"),
                      ("nvme_command", "sc"), ("nvme_command", "t_ps"), ("nvme_transaction", "type"), ("nvme_transaction", "t_ps"),
                      ("nvme_transaction", "parent"), ("nvme_transaction", "parent_level")],
            "test_in_words": "A completed command is listed when (time to its first completion entry) / (the host's limit for its queue) x 100 is at or above the "
                             "admin's share and the time is under the limit.",
            "columns": [{"file": "nvme_command", "column": c, "use": u} for c, u in (
                ("OPC", "the command code: names the command kind and tells the long-by-nature commands apart"),
                ("SQID", "the submission queue: queue 0 (admin commands) has the 60 second limit, every other queue the 30 second limit"),
                ("CID", "the command identifier: shown with each listed command"),
                ("NLB", "the number of blocks, counted from 0: the usual time is measured per command kind and size"),
                ("ST.SCT", "the status code type: a command without a status or aborted by the host is the timeout rule's"),
                ("ST.SC", "the status code: the same"),
                ("Time Stamp", "when the command was sent, from the start of the recording"))] + [
                {"file": "nvme_transaction", "column": "Type", "use": "which NVMe transaction of the command is its completion entry"},
                {"file": "nvme_transaction", "column": "Time Stamp", "use": "when the completion entry was written: the end of the command's time"}],
            "output_columns": [{"column": c, "meaning": m} for c, m in OUTPUT_COLUMNS],
            "summary_columns": [{"column": c, "meaning": m} for c, m in SUMMARY_COLUMNS],
            "code": {"path": os.path.join("nvme_hier", "near_limit.py"), "snippets": [span(f) for f in ("share_of", "limits_of", "usual_times", "run")]},
            "reused_from_the_timeout_rule": ["rules.DEFAULT_LIMITS", "rules.Rules._limits", "rules.FIRST_CQE_SQL", "rules.TIMEOUT_USUAL_SQL", "rules.group_values",
                                             "rules.usual_bar", "rules.USUAL_MIN", "rules.NOT_TIMED_SQL", "rules.BLOCKS_SQL", "rules.CMD_TIME_SQL"]}


# ---------------------------------------------------------------------------------------------- the admin's share
class Refused(ValueError):
    """What was asked cannot be done, said in plain words (a share that is not a share, a row that is not a near-limit command)."""


def share_of(value=None, set_by=None):
    """The share of the host's limit a command must reach to be listed -> {"percent", "set_by", "is_default", "words"}.
    None or an empty text = the default (DEFAULT_SHARE_PERCENT), said as nobody's choice with its reason. Otherwise a number above 0 and
    below 100, as a number or as text ("80", "80 %", "80 per cent"). Refused in plain words: 0 or less (every completed command would be
    listed: nothing would be selected), 100 or more (a command at the limit or above is an error of the timeout rule, so nothing could be
    listed), text that is not a number, yes/no values, and numbers that are not finite."""
    if (isinstance(set_by, str) and set_by.strip() == SET_BY_DEFAULT and isinstance(value, (int, float)) and not isinstance(value, bool)
            and value == DEFAULT_SHARE_PERCENT):
        value = None            # the starting value as the item's code carries it (code_for() with no share stated): still nobody's choice
    if value is None or (isinstance(value, str) and not value.strip()):
        return {"percent": DEFAULT_SHARE_PERCENT, "set_by": SET_BY_DEFAULT, "is_default": True,
                "words": "The share used is %s per cent of the host's limit. Nobody set it: it is the application's starting value. %s" % (_pc(DEFAULT_SHARE_PERCENT), DEFAULT_SHARE_REASON)}
    ask = "State a share of the host's limit as a number above 0 and below 100 (per cent), for example 80."
    if isinstance(value, bool):
        raise Refused("The share must be a number, not yes or no. " + ask)
    if isinstance(value, str):
        text = value.strip().lower()
        for tail in ("per cent", "percent", "%"):
            if text.endswith(tail):
                text = text[:-len(tail)].strip()
        try:
            v = float(text)
        except ValueError:
            raise Refused("\"%s\" is not a number. %s" % (value.strip()[:60], ask)) from None
    elif isinstance(value, (int, float)):
        try:
            v = float(value)
        except OverflowError:
            raise Refused("The number is too large to be a share. " + ask) from None
    else:
        raise Refused("The share must be a number. " + ask)
    if math.isnan(v) or math.isinf(v):
        raise Refused("The share must be a real number. " + ask)
    if v <= 0:
        raise Refused("A share of %s per cent would list every completed command, so it selects nothing. %s" % (_num(v), ask))
    if v >= 100:
        raise Refused("A share of %s per cent cannot be used: a command that used 100 per cent of the host's limit or more is an error of the timeout rule "
                      "and is never listed here. %s" % (_num(v), ask))
    who = (str(set_by).strip() if set_by is not None else "") or "the person who ran this item (no name was given)"
    return {"percent": v, "set_by": who, "is_default": False, "words": "The share used is %s per cent of the host's limit, set by %s." % (_num(v), who)}


def _num(v):
    return "%g" % v if abs(v) < 1e15 else "%.3g" % v


def _floor(v, places=6):
    """v cut (never rounded up) to `places` decimals, so a command under the limit never shows as 100 per cent."""
    k = 10 ** places
    return math.floor(v * k) / k


def _pc(v):
    """A percentage as text, cut and never rounded up: 99.9999 stays below 100; a very small one keeps its first digits."""
    if v is None:
        return ""
    if 0 < v < 0.001:
        return "%.2g" % v
    return ("%.3f" % _floor(v, 3)).rstrip("0").rstrip(".")


# ---------------------------------------------------------------------------------------------- the limit and the usual time
def _ro(db_path, immutable=False, scratch=None):
    """The recording's database, read-only: nothing here can change the error list. (Temporary tables live outside the file.)
    immutable: the main file alone is read (no write-ahead-log side files), for a process that may only read. scratch: the folder SQLite puts its
    temporary tables and its sorting in (a confined process may write only beside its output); where SQLite does not take the folder, its own default stays."""
    con = sqlite3.connect("file:%s?mode=ro%s" % (os.path.abspath(db_path).replace("\\", "/").replace("%", "%25").replace("?", "%3f").replace("#", "%23"),
                                                  "&immutable=1" if immutable else ""), uri=True)
    if scratch:
        try:
            con.execute("PRAGMA temp_store_directory = '%s'" % os.path.abspath(scratch).replace("'", "''"))
        except sqlite3.Error:
            pass
    con.create_function("part_key", 1, N.part_key, deterministic=True)        # the function rules.FIRST_CQE_SQL names a completion entry by
    return con


def _meta(con, key, default=None):
    try:
        r = con.execute("SELECT v FROM meta WHERE k=?", (key,)).fetchone()
        return json.loads(r[0]) if r and r[0] else default
    except (sqlite3.Error, ValueError, TypeError):
        return default


def limits_of(con, thresholds=None):
    """The host's limits exactly as the timeout rule takes them -> {"io": {...}, "admin": {...}}, each with ps, text, source, set_by_admin.
    thresholds given (the recording's own, as the application passes them to the rules): rules.Rules._limits decides, as in the timeout rule.
    Not given: the limits the last check of this recording used (the recording's own record of them), else rules.DEFAULT_LIMITS."""
    if thresholds is not None:
        got = RL.Rules._limits(None, thresholds or {})        # the method reads only its argument
        io, adm = got.get("nvme_command"), got.get("nvme_command_admin")
    else:
        kept = (_meta(con, "rules", {}) or {}).get("limits") or {}
        io, adm = kept.get("nvme_command"), kept.get("nvme_command_admin")
        io = {"ps": int(io["ps"]), "source": io.get("source"), "admin": bool(io.get("set_by_admin"))} if io and io.get("ps") else None
        adm = {"ps": int(adm["ps"]), "source": adm.get("source"), "admin": bool(adm.get("set_by_admin"))} if adm and adm.get("ps") else None
    io = io or dict(RL.DEFAULT_LIMITS["nvme_command"], admin=False)                       # as command_timeout(): the default when none is set
    adm = adm or dict(RL.DEFAULT_LIMITS["nvme_command_admin"], admin=False)
    def one(v):
        return {"ps": int(v["ps"]), "text": P.fmt_ps(int(v["ps"])), "source": v.get("source") or "set by the admin", "set_by_admin": bool(v.get("admin"))}
    return {"io": one(io), "admin": one(adm)}


def usual_times(con, io_ps, adm_ps):
    """The usual time per command kind and size, measured by the timeout rule's own functions (rules.group_values on rules.TIMEOUT_USUAL_SQL,
    rules.usual_bar on the times under the host's limit, only with rules.USUAL_MIN of them). Needs temp.cmd_end. Fills temp.nl_usual
    (adm, opc, blocks, n, median_ps, bar_ps: median_ps and bar_ps are empty when no usual time is measured) -> {(adm, opc, blocks): {...}}."""
    con.execute("DROP TABLE IF EXISTS temp.nl_usual")
    con.execute("CREATE TEMP TABLE nl_usual (adm INTEGER, opc INTEGER, blocks INTEGER, n INTEGER, median_ps REAL, bar_ps INTEGER)")
    out = {}
    for (adm, opc, blocks), (n, times) in RL.group_values(con, RL.TIMEOUT_USUAL_SQL, ("adm", "opc", "blocks"), "dur_ps").items():
        within = [v for v in times if v < (adm_ps if adm else io_ps)]
        u = RL.usual_bar(within) if len(within) >= RL.USUAL_MIN else None
        out[(adm, opc, blocks)] = {"n": n, "usual_ps": u["centre_ps"] if u else None, "bar_ps": u["bar_ps"] if u else None, "normal": u["normal"] if u else None}
        con.execute("INSERT INTO temp.nl_usual VALUES (?,?,?,?,?,?)", (adm, opc, blocks, n, u["centre_ps"] if u else None, u["bar_ps"] if u else None))
    return out


def _no_usual(n):
    k = int(n or 0)
    return ("no usual time: only %d completed command%s of this kind and size in this recording, and at least %d are needed to measure one"
            % (k, "" if k == 1 else "s", RL.USUAL_MIN))


def _sized(opc, sqid, blocks):
    return blocks + 1 if blocks is not None and blocks >= 0 and sqid != 0 else None


def _status(sct, sc):
    if (sct or 0) == 0 and (sc or 0) == 0:
        return "0h/00h Successful Completion"
    return "status code type %Xh, status code %02Xh (not Successful Completion: the status rule of the errors page names it)" % (sct or 0, sc or 0)


def _entry(row, lims, share):
    rid, cn, opc, sqid, cid, blocks, sct, sc, dur, n_kind, usual, bar = row
    lim = lims["admin"] if sqid == 0 else lims["io"]
    used = dur * 100.0 / lim["ps"]
    has_usual = usual is not None and usual > 0
    if not has_usual:
        about = _no_usual(n_kind)
    else:
        about = "measured on the %s completed commands of this kind and size in this recording" % "{:,}".format(n_kind)
    if has_usual and bar is not None and dur > bar:
        rule = ("also filed as an error by the timeout rule: slower than usual (above %s, which is %d times the slowest normal command of its kind and size)"
                % (P.fmt_ps(int(bar)), RL.USUAL_JUMP))
    else:
        rule = "nothing: not an error of the timeout rule"
    return {"row": rid, "command_number": cn, "queue": sqid, "command_identifier": cid, "kind": N.opcode_name(opc, sqid), "size_blocks": _sized(opc, sqid, blocks),
            "time_ps": dur, "time": P.fmt_ps(dur), "limit_ps": lim["ps"], "limit": lim["text"], "limit_source": lim["source"],
            "share_per_cent": _floor(used), "margin_per_cent": round(100.0 - _floor(used), 6),
            "usual_ps": int(usual) if has_usual else None, "usual": P.fmt_ps(int(usual)) if has_usual else "",
            "times_slower_than_usual": round(dur / usual, 2) if has_usual else None, "about_the_usual_time": about,
            "timeout_rule": rule, "also_slower_than_usual": bool(has_usual and bar is not None and dur > bar), "status": _status(sct, sc)}


def _line(e):
    return [e["row"], e["command_number"], e["queue"], e["command_identifier"], e["kind"], "" if e["size_blocks"] is None else e["size_blocks"],
            e["time"], e["time_ps"], e["limit"], e["limit_source"], e["share_per_cent"], e["margin_per_cent"], e["usual"],
            "" if e["times_slower_than_usual"] is None else e["times_slower_than_usual"], e["about_the_usual_time"], e["timeout_rule"], e["status"]]


def _prepare(con, thresholds):
    """temp.cmd_end (each command's first completion entry, read once from the tree, by the timeout rule's own SQL), the limits and the usual
    times -> (limits, usual, why_not): why_not says in words why no time can be measured, "" when it can."""
    lims = limits_of(con, thresholds)
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "cmd" not in tables:
        return lims, {}, "This recording was loaded without its NVMe command file: there is no command to measure."
    if "ntx" not in tables:
        return lims, {}, ("This recording was loaded without its NVMe transactions file. A command's time ends at its completion entry, which is read from that "
                          "file, so no command's time can be measured and nothing can be said about how close a command came to the limit.")
    con.execute("DROP TABLE IF EXISTS temp.cmd_end")
    con.execute("CREATE TEMP TABLE cmd_end (rid INTEGER PRIMARY KEY, t_end INTEGER)")
    con.execute(RL.FIRST_CQE_SQL)
    return lims, usual_times(con, lims["io"]["ps"], lims["admin"]["ps"]), ""


def _summary(con, lims, thr_io, thr_adm, share):
    """One entry per command kind (admin or I/O, and the command code), from two passes of the database (nothing held per command)."""
    io, adm = lims["io"]["ps"], lims["admin"]["ps"]
    kinds = {}
    for a, opc, n, listed, over in con.execute(
            "SELECT (c.sqid = 0), c.opc, COUNT(*), SUM(CASE WHEN " + RL.CMD_TIME_SQL + " < " + LIMIT_SQL + " AND " + RL.CMD_TIME_SQL + " >= " + LIMIT_SQL +
            " THEN 1 ELSE 0 END), SUM(CASE WHEN " + RL.CMD_TIME_SQL + " >= " + LIMIT_SQL + " THEN 1 ELSE 0 END) " + COMPLETED_SQL + " GROUP BY 1, 2",
            (adm, io, thr_adm, thr_io, adm, io)):
        kinds[(a, opc)] = {"n": n, "listed": listed or 0, "over": over or 0, "max": None, "row": None}
    # the slowest command under the limit of each kind: SQLite gives the other columns of the row that holds the MAX
    for a, opc, top, rid in con.execute("SELECT (c.sqid = 0), c.opc, MAX(" + RL.CMD_TIME_SQL + "), c.rowid_file " + COMPLETED_SQL +
                                        " AND " + RL.CMD_TIME_SQL + " < " + LIMIT_SQL + " GROUP BY 1, 2", (adm, io)):
        if (a, opc) in kinds:
            kinds[(a, opc)].update(max=top, row=rid)
    out = []
    for (a, opc), k in kinds.items():
        lim = lims["admin"] if a else lims["io"]
        name = N.opcode_name(opc, 0 if a else 1)
        e = {"kind": name, "admin": bool(a), "completed_measured": k["n"], "limit_ps": lim["ps"], "limit": lim["text"], "limit_source": lim["source"],
             "largest_share_per_cent": None, "slowest_time_ps": k["max"], "slowest_time": P.fmt_ps(k["max"]) if k["max"] is not None else "",
             "row_of_the_slowest": k["row"], "at_or_above_the_share": k["listed"], "margin_per_cent": None, "at_or_above_the_limit": k["over"]}
        if k["max"] is None:
            e["words"] = ("No %s command completed under the host's limit of %s, so no share can be given. %d took the limit or longer: the timeout rule "
                          "files them as errors." % (name, lim["text"], k["over"]))
        else:
            used = max(0.0, k["max"] * 100.0 / lim["ps"])
            e["largest_share_per_cent"], e["margin_per_cent"] = _floor(used), round(100.0 - _floor(used), 6)
            if k["listed"]:
                e["words"] = ("%s of the %s %s commands that completed used %s per cent of the limit or more. The slowest took %s, which is %s per cent of the "
                              "host's limit of %s and leaves %s per cent." % ("{:,}".format(k["listed"]), "{:,}".format(k["n"]), name, _num(share), e["slowest_time"],
                                                                                _pc(used), lim["text"], _pc(100.0 - _floor(used))))
            else:
                e["words"] = ("No %s command came closer to the limit than %s per cent of it: the slowest of the %s that completed took %s of the %s the host "
                              "allows, which leaves %s per cent. (The admin's share is %s per cent.)" % (
                                  name, _pc(used), "{:,}".format(k["n"]), e["slowest_time"], lim["text"], _pc(100.0 - _floor(used)), _num(share)))
            if k["over"]:
                e["words"] += " %s more took the limit or longer: the timeout rule files them as errors, and they are not counted here." % "{:,}".format(k["over"])
        out.append(e)
    out.sort(key=lambda e: (-(e["largest_share_per_cent"] if e["largest_share_per_cent"] is not None else -1.0), e["kind"]))
    return out


def _summary_line(e):
    return [e["kind"], e["completed_measured"], e["limit"], e["limit_source"], "" if e["largest_share_per_cent"] is None else e["largest_share_per_cent"],
            e["slowest_time"], "" if e["row_of_the_slowest"] is None else e["row_of_the_slowest"], e["at_or_above_the_share"],
            "" if e["margin_per_cent"] is None else e["margin_per_cent"], e["at_or_above_the_limit"], e["words"]]


def _write(path, header, lines, tell=None):
    """Rows written one by one to a part file, which then takes the place of `path` (a reader never sees half a file). -> rows written."""
    tmp = "%s.%d.part" % (path, os.getpid())
    n = 0
    try:
        with open(tmp, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(header)
            for line in lines:
                w.writerow(line)
                n += 1
                if tell and n % PROGRESS_EVERY == 0:
                    tell(n)
        OSF.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
    return n


def run(db_path, out_csv, share=None, set_by=None, thresholds=None, progress=None, summary_csv=None, immutable=False, scratch=None):
    """The item on one recording. The list goes to out_csv row by row (the closest to the limit first); the summary per command kind comes back
    (and goes to summary_csv when one is named). share: the admin's share of the limit in per cent (see share_of; None = the default, said so);
    set_by: who stated it; thresholds: the recording's limits as the application passes them to the rules (None = the limits its last check used);
    progress(stage, detail): told what is being done, with a percentage while the list is written. Raises Refused for a share that is not one."""
    s = share_of(share, set_by)
    tell = progress or (lambda stage, detail: None)
    con = _ro(db_path, immutable, scratch)
    try:
        tell(STAGE, "reading each command's completion entry and the usual times (0 %)")
        lims, _usual, why_not = _prepare(con, thresholds)
        header = [c for c, _m in OUTPUT_COLUMNS]
        base = {"item": ITEM["name"], "is_an_error_rule": False, "adds_to_the_error_list": False, "share": s, "limits": lims, "csv": out_csv,
                "columns": [{"column": c, "meaning": m} for c, m in OUTPUT_COLUMNS], "summary_columns": [{"column": c, "meaning": m} for c, m in SUMMARY_COLUMNS],
                "order": PROCEDURE["output"]["order"], "min_for_usual": RL.USUAL_MIN}
        if why_not:
            _write(out_csv, header, [])
            if summary_csv:
                _write(summary_csv, [c for c, _m in SUMMARY_COLUMNS], [])
            return dict(base, can_be_measured=False, why_not=why_not, listed=0, completed_measured=0, rows=[], has_more=False, summary=[], summary_csv=summary_csv,
                        words=why_not, rows_read=0, rows_written=0, total=0)
        io, adm = lims["io"]["ps"], lims["admin"]["ps"]
        thr_io, thr_adm = io * s["percent"] / 100.0, adm * s["percent"] / 100.0
        tell(STAGE, "the summary per command kind (20 %)")
        summary = _summary(con, lims, thr_io, thr_adm, s["percent"])
        total = sum(e["at_or_above_the_share"] for e in summary)
        shown = []

        def lines():
            for row in con.execute(LIST_SQL, (adm, io, thr_adm, thr_io, adm, io)):
                e = _entry(row, lims, s["percent"])
                if len(shown) < SHOWN_AT_ONCE:
                    shown.append(e)
                yield _line(e)
        written = _write(out_csv, header, lines(),
                         lambda n: tell(STAGE, "%s of %s listed commands written (%d %%)" % ("{:,}".format(n), "{:,}".format(total), 20 + int(80 * n / max(1, total)))))
        if summary_csv:
            _write(summary_csv, [c for c, _m in SUMMARY_COLUMNS], (_summary_line(e) for e in summary))
        measured = sum(e["completed_measured"] for e in summary)
        over = sum(e["at_or_above_the_limit"] for e in summary)
        if not measured:
            words = "No command of this recording completed with a time that can be measured, so nothing can be said about how close a command came to the limit."
        elif not written:
            top = next((e for e in summary if e["largest_share_per_cent"] is not None), None)
            words = ("No command came close to the limit: none of the %s completed commands used %s per cent of the host's limit or more." % ("{:,}".format(measured), _num(s["percent"]))
                     + (" The closest was a %s command at %s per cent of its limit of %s (%s)." % (top["kind"], _pc(top["largest_share_per_cent"]), top["limit"], top["slowest_time"]) if top else ""))
        else:
            words = "%s of the %s completed commands used %s per cent of the host's limit or more without reaching it. The closest: %s, row %s, %s, which is %s per cent of %s." % (
                "{:,}".format(written), "{:,}".format(measured), _num(s["percent"]), shown[0]["kind"], shown[0]["row"], shown[0]["time"], _pc(shown[0]["share_per_cent"]), shown[0]["limit"])
        if over:
            words += " %s completed command%s took the limit or longer: the timeout rule files them as errors, and this item does not count them." % ("{:,}".format(over), "" if over == 1 else "s")
        words += " " + s["words"] + " This is analytics: it adds nothing to the errors of the recording."
        tell(STAGE, "done (100 %)")
        return dict(base, can_be_measured=True, why_not="", listed=written, completed_measured=measured, at_or_above_the_limit=over, rows=shown,
                    has_more=written > len(shown), summary=summary, summary_csv=summary_csv, words=words,
                    rows_read=measured, rows_written=written, total=written)
    finally:
        con.close()


def run_on_tree(tree, out_csv, share=None, set_by=None):
    """The same on the tree a procedure's code is given (run(tree, out_csv) of agentic/procedures.py): the tree's own database, read-only.
    That code runs in a confined process: it may read the tree's main file and write only beside its output. So the file is opened alone
    (immutable) when its write-ahead log is empty (procedures.run_code folds it first), and SQLite's temporary tables go beside the output."""
    wal = tree.db + "-wal"
    return run(tree.db, out_csv, share=share, set_by=set_by, immutable=not os.path.exists(wal) or os.path.getsize(wal) == 0,
               scratch=os.path.dirname(os.path.abspath(out_csv)))


# ---------------------------------------------------------------------------------------------- the result, checked and shown
def result_checks(out_csv, result):
    """The checks the Tester makes on a result of this item, from the result file (read line by line) and what run() gave back
    -> [{"check", "ok", "detail"}]. Nothing listed is a result of this item, not a failure: the summary then says how close the commands came."""
    result = result if isinstance(result, dict) else {}
    want = [c for c, _m in OUTPUT_COLUMNS]
    share = (result.get("share") or {}).get("percent")
    i_share = want.index("share of the limit used (per cent)")
    n, bad, order_ok, last, cols = 0, 0, True, None, []
    with open(out_csv, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        cols = next(rd, [])
        for row in rd:
            n += 1
            try:
                v = float(row[i_share])
            except (ValueError, IndexError):
                bad += 1
                continue
            if not (v < 100 and (share is None or v >= _floor(float(share)))):
                bad += 1
            if last is not None and v > last:
                order_ok = False
            last = v
    kinds = [e for e in result.get("summary") or [] if isinstance(e, dict)]
    counted = sum(int(e.get("at_or_above_the_share") or 0) for e in kinds)
    share_words = ("%s per cent" % _num(float(share))) if share is not None else "the share"
    checks = [{"check": "the output has the item's columns, in its order", "ok": cols == want, "detail": "%d columns" % len(cols)},
              {"check": "the list holds exactly the commands the summary counts per command kind", "ok": n == counted == int(result.get("listed") or 0),
               "detail": ("%s listed, %s counted" % ("{:,}".format(n), "{:,}".format(counted))) + (
                   "" if n else ": no completed command used %s of the host's limit or more (an empty list is a result here, not a failure)" % share_words)},
              {"check": "every listed command is at or above the share and under the host's limit", "ok": bad == 0,
               "detail": "%s of %s are not" % ("{:,}".format(bad), "{:,}".format(n)) if bad else ("all %s" % "{:,}".format(n) if n else "nothing is listed")},
              {"check": "the list is in its order: the largest share of the limit first", "ok": order_ok, "detail": "yes" if order_ok else "a later line has a larger share"}]
    if result.get("can_be_measured") is False:
        checks.append({"check": "the result says why nothing can be measured", "ok": bool(result.get("why_not")), "detail": str(result.get("why_not") or "no reason given")[:300]})
    else:
        said = [e for e in kinds if str(e.get("words") or "").strip()]
        checks.append({"check": "every command kind has its summary sentence", "ok": bool(kinds) and len(said) == len(kinds) or not result.get("completed_measured"),
                       "detail": "%d of %d command kinds" % (len(said), len(kinds))})
    checks.append({"check": "it is analytics: it adds nothing to the errors of the recording", "ok": result.get("adds_to_the_error_list") is False and result.get("is_an_error_rule") is False,
                   "detail": "the recording is opened for reading only; the errors list and its counts are not touched"})
    return checks


def card_lines(result):
    """What the result card says of this item: the result in plain words, which share was used and who set it, and one sentence per command kind
    -> (the lines, the same as data for the page). With nothing listed the sentences are the result ("no command of this kind came closer than ...")."""
    result = result if isinstance(result, dict) else {}
    kinds = [e for e in result.get("summary") or [] if isinstance(e, dict) and str(e.get("words") or "").strip()]
    lines = []
    if result.get("words"):
        lines += ["", "**In plain words:** " + str(result["words"])]
    if kinds:
        lines += ["", "**Per command kind** (how close the completed commands of each kind came to the host's limit):"] + ["- " + str(e["words"]) for e in kinds]
    lines += ["", "This is analytics: nothing of it is an error, and nothing of it is counted among the errors of the recording."]
    data = {"words": result.get("words"), "share": result.get("share"), "listed": result.get("listed"), "completed_measured": result.get("completed_measured"),
            "kinds": [{"kind": e.get("kind"), "words": e.get("words"), "completed_measured": e.get("completed_measured"),
                       "largest_share_per_cent": e.get("largest_share_per_cent"), "at_or_above_the_share": e.get("at_or_above_the_share"),
                       "margin_per_cent": e.get("margin_per_cent")} for e in kinds],
            "summary_columns": result.get("summary_columns"), "is_an_error_rule": False}
    return lines, data


# ---------------------------------------------------------------------------------------------- the starting point of a sweep
def window(db_path, row, n=5, m=5, same_queue=True, thresholds=None):
    """The starting point of a sweep from one near-limit command: the same kind of window and first sequence the page of one error builds for a
    failed command (the window of app/api/hier_api.py _window at the NVMe command level: n commands above, the command, m below, each with its
    cells, its position and the errors filed on it; then optimise.optimise() for the first sequence with its gaps).
    The command stands where a failed command stands, so its position is "fault" (the name the window code and optimise.py use for the row in
    the middle); here it is NOT a fault: "anchor" says so, and its step expects it to complete near the limit, not to fail.
    Raises Refused when the row is not a command that completed under the host's limit with a measurable time."""
    try:
        row, n, m = int(row), max(0, min(int(n), 1000)), max(0, min(int(m), 1000))
    except (TypeError, ValueError, OverflowError):
        raise Refused("The row and the numbers of commands above and below must be whole numbers.") from None
    con = _ro(db_path)
    try:
        lims, _usual, why_not = _prepare(con, thresholds)
        con.row_factory = sqlite3.Row
        if why_not:
            raise Refused(why_not)
        got = con.execute("SELECT c.rowid_file, c.n, c.opc, c.sqid, c.cid, " + RL.BLOCKS_SQL + ", c.sct, c.sc, " + RL.CMD_TIME_SQL + " AS dur, b.n, b.median_ps, b.bar_ps "
                          "FROM cmd c LEFT JOIN temp.cmd_end e ON e.rid = c.rowid_file LEFT JOIN temp.nl_usual b ON b.adm = (c.sqid = 0) AND b.opc = c.opc AND b.blocks = "
                          + RL.BLOCKS_SQL + " WHERE c.rowid_file = ?", (row,)).fetchone()
        if got is None:
            raise Refused("The NVMe command file of this recording has no row %d." % row)
        got = tuple(got)
        lim = lims["admin"] if got[3] == 0 else lims["io"]
        if got[8] is None or (got[6] is None and got[7] is None):
            raise Refused("The command in row %d has no completion with a measurable time, so it is not a near-limit command (a command that never completed is the timeout rule's)." % row)
        if got[8] >= lim["ps"] or got[8] < 0:
            raise Refused("The command in row %d took %s, which is not under the host's limit of %s: it is an error of the timeout rule, not a near-limit command." % (
                row, P.fmt_ps(got[8]), lim["text"]))
        e = _entry(got, lims, None)
        anchor = dict(con.execute("SELECT * FROM cmd WHERE rowid_file = ?", (row,)).fetchone())
        cond, args = "", []
        if same_queue and anchor.get("sqid") is not None:
            cond, args = " AND sqid=?", [anchor["sqid"]]
        above = [dict(r) for r in con.execute("SELECT * FROM cmd WHERE rowid_file<?%s ORDER BY rowid_file DESC LIMIT ?" % cond, [row] + args + [n])][::-1]
        below = [dict(r) for r in con.execute("SELECT * FROM cmd WHERE rowid_file>?%s ORDER BY rowid_file LIMIT ?" % cond, [row] + args + [m])]
        has_findings = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='finding'").fetchone() is not None
        rows = []
        for pos, lst in (("above", above), ("fault", [anchor]), ("below", below)):
            for r in lst:
                r["raw"] = json.loads(r["raw"]) if isinstance(r.get("raw"), str) and r.get("raw") else (r.get("raw") if isinstance(r.get("raw"), dict) else {})
                for k in ("t_ps", "delta_ps", "dur_ps"):
                    if r.get(k) is not None:
                        r[k + "_text"] = P.fmt_ps(r[k])
                r["position"] = pos
                r["summary"] = "%s, queue %s, command id %s" % (N.opcode_name(r.get("opc"), r.get("sqid")), r.get("sqid"), r.get("cid"))
                r["findings"] = [dict(x) for x in con.execute("SELECT id, rule, name, severity FROM finding WHERE level=? AND rowid=?", ("nvme_command", r["rowid_file"]))] if has_findings else []
                rows.append(r)
        for i in range(1, len(rows)):
            a, b = rows[i - 1].get("t_ps"), rows[i].get("t_ps")
            rows[i]["gap_text"] = P.fmt_ps(b - a) if a is not None and b is not None else ""
    finally:
        con.close()
    expected = ("completes, but close to the limit: in the recording it took %s, %s per cent of the host's limit of %s (%s). A sweep starts from here: "
                "it is not a fault." % (e["time"], _pc(e["share_per_cent"]), e["limit"], e["limit_source"]))
    out = OPT.optimise(rows)
    for st in out.get("steps") or []:
        if st.get("position") == "fault":
            st["expected"], st["why"] = expected, ["the near-limit command the sweep starts from"]
    for r in out.get("rows") or []:
        if r.get("position") == "fault":
            r["why"] = ["the near-limit command the sweep starts from"]
    out["window"] = {"level": "nvme_command", "label": "NVMe command", "n": n, "m": m, "same_queue": bool(same_queue), "anchor_rowid": row,
                     "anchor": "near_limit", "note": "The row in the middle (position \"fault\" in the window's own naming) is a command that completed close to the "
                                                    "host's limit. It is not an error and no error was filed for it."}
    out["near_limit"] = e
    return out
