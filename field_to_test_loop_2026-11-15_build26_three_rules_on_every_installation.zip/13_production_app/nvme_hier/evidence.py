"""The evidence card of one error, and its cause by fixed rules (owner, 2026-11-11: "even if I draw 1,000 lines from above or below, the
causation should always be proper, one; otherwise it keeps on changing").

The card is computed by code from the error's OWN command, never from the window the admin happens to show: the stages its cycle reached
(the NVMe transactions under it, in time order), the time between them and the longest wait, the row just before that wait (where the
defect started), the time it took against the host's limit and against the usual time of its command type in this recording, the link
problems of its own packets, the host's Abort of it (if any), and what else ran and which link events happened during its own interval.
The same error therefore always gets the same card, whatever n and m are; the cause keyword is decided from the card by fixed rules in a
fixed order (the first that applies), so the same card always gives the same cause. The model only explains, in words, around these facts.
"""
import hashlib
import json
import sqlite3

from . import names as N
from . import rules as RL
from . import terms as TERMS

# 2 (2026-11-14): the "after" section of a command that never completed (its Abort, the reset, who stopped first)
# 3 (2026-11-15): the card and the cause no longer depend on WHICH RULE found the error. Until then the steps of the command's cycle, the
#   host's limit and the usual time were taken only from the detail the detector keeps with its two rules "NVMe command timeout" and "Read
#   failure"; an error of the same command found by any other rule (a rule family of the NVMe command level, an admin's own rule, another
#   rule of the detector) carries none of them, so its card said "not completed: unknown" and the cause rules ended in "none of the fixed
#   rules applies" (seen on sample S17, command row 155). Now whatever a finding does not carry is read from the command's own rows in the
#   tree, by the same code the detector uses (rules.command_cycle), and from the measured times the detector kept in the tree (_measured);
#   the Abort of a completed command is matched by the Abort's own parameters, as for a command that never completed; card["read_from_tree"]
#   says what was read there.
CARD_VERSION = 3
ABORT_OPC = 0x08
LINK_RULES = ("pkt.link_down", "pkt.speed_change", "pkt.electrical_idle")
CC_TYPE = "Controller Register (CC)"        # the analyzer's own Type text of an access to the controller configuration register
SQE_LIKE = "%Submission Queue Entry"        # the analyzer's Type text of the 64-byte entry the drive fetched (admin or I/O)
CQE_LIKE = "%Completion Queue Entry"
LOOK = 64               # at most this many candidate rows (Aborts, register accesses) are examined for one card
KEEP = 5                # at most this many example rows are kept in one list of the card (a 6 GB recording still gives a small card)


def _ps(x):
    """A time in picoseconds as a whole number, or None for an empty or damaged value (a damaged detail never stops the card)."""
    if x is None or isinstance(x, bool):
        return None
    try:
        return int(x)
    except (TypeError, ValueError, OverflowError):
        return None


def fmt(ps):
    if ps is None:
        return "-"
    a = abs(ps)
    return "%.3f s" % (ps / 1e12) if a >= 1e12 else "%.3f ms" % (ps / 1e9) if a >= 1e9 else "%.3f µs" % (ps / 1e6) if a >= 1e6 else "%d ns" % round(ps / 1e3)

# ---------------------------------------------------------------------------------------------------------------------------------------
# What happened AFTER the last step of a command that never completed (2026-11-14). Everything is joined by identity; time only orders the
# rows and bounds the wait (from the command's doorbell to the controller reset that ended it, or to the end of the recording):
#   * the host's Abort FOR THIS command: an Abort (admin, opcode 08h) whose own parameters name this command's queue and identifier. The
#     parameters are in the 64-byte submission queue entry the drive fetched (the data bytes of the read completion under the Abort's own
#     "Submission Queue Entry" NVMe transaction): bytes 40-41 the queue identifier, bytes 42-43 the command identifier (NVMe Base
#     specification, Abort command, Command Dword 10: SQID in bits 15:0, CID in bits 31:16; section number to be confirmed. On the S17
#     sample the five Aborts name exactly the aborted Read and the four Writes that never completed). An Abort whose bytes cannot be read
#     is NEVER given to a command because it is near in time: it is listed as unreadable.
#   * the controller reset: a memory write to the controller configuration register (the analyzer's "Controller Register (CC)" NVMe
#     transaction, through its own link row and packet) whose first data byte has bit 0 (CC.EN) = 0 (the data generator's scenario S17
#     describes the reset as "CC write EN=0 then EN=1"; NVMe Base specification, Controller Configuration register, EN bit; section to be
#     confirmed). A register access that is a read is not a reset; a write whose bytes cannot be read is listed as unreadable.
#   * who stopped first: the earliest command sent since the previous reset that also never completed (command rows, in time order).
#   * whether the drive answered other commands during the wait: counted over the command rows sent in the wait (an index range, summed
#     by the database; no table is loaded into memory).
def _bytes(cell):
    """'08 00 0F 00 ...' -> [8, 0, 15, 0, ...], or None when the cell is not a list of bytes (blank, '4 B', damaged)."""
    parts = str(cell or "").split()
    if not parts:
        return None
    out = []
    for p in parts:
        if len(p) > 2:
            return None
        try:
            out.append(int(p, 16))
        except ValueError:
            return None
    return out


def _packets_under(con, ntx_row):
    """The packets under one NVMe transaction, through the tree's parent links only (split > link > packet, or link > packet for a posted
    write): [(packet row, TLP type, data bytes or None)], at most LOOK."""
    links = [r[0] for r in con.execute("SELECT rowid_file FROM lnk WHERE parent_level='nvme_transaction' AND parent=? ORDER BY rowid_file LIMIT ?", (ntx_row, LOOK))]
    for sp in con.execute("SELECT rowid_file FROM spl WHERE parent_level='nvme_transaction' AND parent=? ORDER BY rowid_file LIMIT ?", (ntx_row, LOOK)).fetchall():
        links += [r[0] for r in con.execute("SELECT rowid_file FROM lnk WHERE parent_level='split' AND parent=? ORDER BY rowid_file LIMIT ?", (sp[0], LOOK))]
    out = []
    for ln in links[:LOOK]:
        for r in con.execute("SELECT rowid_file, tlp_type, raw FROM pkt WHERE parent_level='link' AND parent=? AND (relation IS NULL OR relation!='context') "
                             "ORDER BY rowid_file LIMIT ?", (ln, LOOK)).fetchall():
            try:
                raw = json.loads(r[2]) if r[2] else {}
            except ValueError:
                raw = {}
            cell = raw.get("DATA") if raw.get("DATA") not in (None, "") else raw.get("Data")
            out.append((r[0], str(r[1] or raw.get("TLP Type") or ""), _bytes(cell)))
    return out


def _abort_target(con, abort_row, abort_cid):
    """((queue, identifier) the Abort names, None) from the Abort's own fetched entry, or (None, why it cannot be read)."""
    sqe = con.execute("SELECT rowid_file FROM ntx WHERE parent_level='nvme_command' AND parent=? AND type LIKE ? ORDER BY t_ps, rowid_file LIMIT 1", (abort_row, SQE_LIKE)).fetchone()
    if sqe is None:
        return None, "the drive's fetch of the Abort's entry is not in the recording"
    seen = False
    for _row, tlp, data in _packets_under(con, sqe[0]):
        if not tlp.startswith("Cpl"):
            continue
        seen = True
        if data is None or len(data) < 44:
            continue
        if data[0] != ABORT_OPC or (abort_cid is not None and (data[2] | data[3] << 8) != abort_cid):
            return None, "the bytes under the Abort's entry are not this Abort's own entry (opcode or identifier differ)"
        return (data[40] | data[41] << 8, data[42] | data[43] << 8), None
    return None, ("the data bytes of the Abort's entry cannot be read" if seen else "the packets of the Abort's entry are not in the recording")


def _cc_write(con, ntx_row):
    """What one access to the controller configuration register was: ("write", EN bit, packet row), ("read", None, None) or
    ("unreadable", None, packet row or None)."""
    wrote = None
    for row, tlp, data in _packets_under(con, ntx_row):
        if tlp.startswith("MWr"):
            if data:
                return "write", data[0] & 1, row
            wrote = row
    if wrote is not None:
        return "unreadable", None, wrote
    return "read", None, None


def _reset(con, t_ps, backwards=False):
    """The first controller reset after a time (or the last one before it): ({"row", "at_ps", "packet_row"} or None, the register writes
    met on the way whose value could not be read). Looking back stops at an unreadable write too (it may have been a reset)."""
    q = ("SELECT rowid_file, t_ps FROM ntx WHERE t_ps<? AND type=? ORDER BY t_ps DESC, rowid_file DESC" if backwards else
         "SELECT rowid_file, t_ps FROM ntx WHERE t_ps>? AND type=? ORDER BY t_ps, rowid_file")
    unread, n = [], 0
    for row, at in con.execute(q, (t_ps, CC_TYPE)):
        what, en, pkt = _cc_write(con, row)
        if what == "write" and en == 0:
            return {"row": row, "at_ps": at, "packet_row": pkt}, unread
        if what == "unreadable":
            if len(unread) < KEEP:
                unread.append({"row": row, "at_ps": at})
            if backwards:
                return {"row": row, "at_ps": at, "packet_row": pkt, "unreadable": True}, unread
        n += 1
        if n >= LOOK:
            if not backwards:           # never "no reset" by silence: more accesses followed than are examined
                unread.insert(0, {"row": row, "at_ps": at, "capped": True})
            break
    return None, unread


def _after(con, c, t_last):
    """The "after" section of the card of a command that never completed (c: its command row; t_last: the time of its last step)."""
    row, t0, q, cid = c["rowid_file"], c["t_ps"], c["sqid"], c["cid"]
    if q is None or cid is None:
        return {"unreadable": "this command's own queue or identifier cannot be read, so no Abort can be matched to it by identity"}
    end = max(x for x in (con.execute("SELECT MAX(t_ps) FROM cmd").fetchone()[0], con.execute("SELECT MAX(t_ps) FROM ntx").fetchone()[0], t_last) if x is not None)
    reset, unread_w = _reset(con, t_last)
    hi = reset["at_ps"] if reset else end
    a = {"last_step_ps": t_last, "wait_end_ps": hi, "wait_end": "controller reset" if reset else "end of the recording", "wait_ps": hi - t_last,
         "outstanding_ps": hi - t0, "abort": None, "aborts_for_others": 0, "aborts_unreadable": [], "reset": None, "register_writes_unreadable": unread_w,
         "episode_from": None, "first_stopped": None, "outstanding_others": 0, "others": None, "names": None}
    # the host's Abort for THIS command, by the Abort's own parameters
    n = 0
    for ab in con.execute("SELECT rowid_file, cid, t_ps, sct, sc, dur_ps FROM cmd WHERE sqid=0 AND opc=? AND t_ps>? AND t_ps<=? AND rowid_file!=? ORDER BY t_ps, rowid_file LIMIT ?",
                          (ABORT_OPC, t0, hi, row, LOOK + 1)).fetchall():
        n += 1
        if n > LOOK:
            if a["abort"] is None:      # never "no Abort" by silence: more Aborts were sent than are examined
                a["aborts_unreadable"] = [{"row": ab["rowid_file"], "after_doorbell_ps": ab["t_ps"] - t0,
                                           "why": "only the first %d Aborts sent during the wait were examined and none of them names this command" % LOOK}]
            break
        target, why = _abort_target(con, ab["rowid_file"], ab["cid"])
        if target is None:
            if len(a["aborts_unreadable"]) < KEEP:
                a["aborts_unreadable"].append({"row": ab["rowid_file"], "after_doorbell_ps": ab["t_ps"] - t0, "why": why})
        elif target == (q, cid):
            if a["abort"] is None:
                cq = con.execute("SELECT dw0 FROM ntx WHERE parent_level='nvme_command' AND parent=? AND type LIKE ? ORDER BY t_ps LIMIT 1", (ab["rowid_file"], CQE_LIKE)).fetchone()
                a["abort"] = {"row": ab["rowid_file"], "after_doorbell_ps": ab["t_ps"] - t0, "names": [q, cid], "answered": ab["sct"] is not None,
                              "answer_after_ps": ab["dur_ps"] if ab["sct"] is not None else None,
                              "status": [ab["sct"], ab["sc"]] if ab["sct"] is not None else None, "dw0": cq[0] if cq else None}
        else:
            a["aborts_for_others"] += 1
    if reset:
        a["reset"] = {"row": reset["row"], "packet_row": reset["packet_row"], "after_doorbell_ps": reset["at_ps"] - t0, "after_last_step_ps": reset["at_ps"] - t_last,
                      "after_abort_ps": (reset["at_ps"] - t0 - a["abort"]["after_doorbell_ps"]) if a["abort"] else None}
    # who stopped first since the previous reset
    before, _u = _reset(con, t0, backwards=True)
    lo = before["at_ps"] if before else -1
    if before:
        a["episode_from"] = {"row": before["row"], "ps": before["at_ps"], "unreadable": bool(before.get("unreadable"))}
    first = con.execute("SELECT rowid_file, opc, sqid, cid, t_ps FROM cmd WHERE t_ps>? AND t_ps<? AND sct IS NULL AND rowid_file!=? ORDER BY t_ps, rowid_file LIMIT 1",
                        (lo, t0, row)).fetchone()
    if first is not None:
        a["first_stopped"] = {"row": first["rowid_file"], "opc": first["opc"], "queue": first["sqid"], "id": first["cid"], "doorbell_ps": first["t_ps"],
                              "before_this_ps": t0 - first["t_ps"], "before_wait_end_ps": hi - first["t_ps"]}
    a["outstanding_others"] = con.execute("SELECT COUNT(*) FROM cmd WHERE t_ps>? AND t_ps<=? AND sct IS NULL AND rowid_file!=?", (lo, hi, row)).fetchone()[0] or 0
    # did the drive answer other commands during the wait (sent after this command's last step, answered before the wait ended)
    o = con.execute("SELECT COUNT(*), SUM(CASE WHEN sct IS NOT NULL AND t_ps+COALESCE(dur_ps,0)<=:hi THEN 1 ELSE 0 END), "
                    "SUM(CASE WHEN sct IS NOT NULL AND t_ps+COALESCE(dur_ps,0)<=:hi AND sqid=:q THEN 1 ELSE 0 END), "
                    "SUM(CASE WHEN sct IS NOT NULL AND t_ps+COALESCE(dur_ps,0)<=:hi AND sqid=0 THEN 1 ELSE 0 END), "
                    "COUNT(DISTINCT CASE WHEN sct IS NOT NULL AND t_ps+COALESCE(dur_ps,0)<=:hi THEN sqid END) "
                    "FROM cmd WHERE t_ps>:lo AND t_ps<=:hi AND rowid_file!=:row", {"lo": t_last, "hi": hi, "q": q, "row": row}).fetchone()
    rows = [r[0] for r in con.execute("SELECT rowid_file FROM cmd WHERE t_ps>? AND t_ps<=? AND sct IS NOT NULL AND t_ps+COALESCE(dur_ps,0)<=? AND rowid_file!=? "
                                      "ORDER BY t_ps, rowid_file LIMIT ?", (t_last, hi, hi, row, KEEP))]
    a["others"] = {"sent": o[0] or 0, "answered": o[1] or 0, "answered_same_queue": o[2] or 0, "answered_admin": o[3] or 0, "queues_answered": o[4] or 0, "rows": rows}
    # when this command is itself an Abort: the command its own parameters name (the latest command with that queue and identifier sent before it)
    if c["opc"] == ABORT_OPC and q == 0:
        a["names"] = _names(con, row, cid, t0)
    return a


def _names(con, row, cid, t0):
    """The command an Abort (command row `row`, identifier `cid`, sent at t0) names by its own parameters: the latest command with that queue
    and identifier sent before it. {"queue", "id", "row", "opc", "completed", "sent_before_ps"}, or {"unreadable": why}."""
    target, why = _abort_target(con, row, cid)
    if target is None:
        return {"unreadable": why}
    t = con.execute("SELECT rowid_file, opc, sct, t_ps FROM cmd WHERE sqid=? AND cid=? AND t_ps<=? AND rowid_file!=? ORDER BY t_ps DESC, rowid_file DESC LIMIT 1",
                    (target[0], target[1], t0, row)).fetchone()
    return {"queue": target[0], "id": target[1], "row": t["rowid_file"] if t else None, "opc": t["opc"] if t else None,
            "completed": (t["sct"] is not None) if t else None, "sent_before_ps": (t0 - t["t_ps"]) if t else None}


# ---------------------------------------------------------------------------------------------------------------------------------------
# What a finding does not carry is read from the command's own rows (2026-11-15). The detector keeps, with the findings of its rules "NVMe
# command timeout" and "Read failure" only, how far the command's cycle got; with the timeout rule also the host's limit and the usual
# time. Every other rule that finds the SAME command (a rule family of the NVMe command level, an admin's own rule, the detector's "never
# completed: no completion entry") keeps none of that, and a detail can be damaged. The cause must not depend on which rule found the
# command, so the card reads what is missing from the tree itself:
#   * the cycle: rules.command_cycle, the detector's own code, on the command's NVMe transactions and their link rows (joined by the tree's
#     parent links). "Never completed" is said only when no completion entry is under the command AND its own row has no status; when the
#     row carries a status and no completion entry is joined under it, the card says that it cannot tell (cycle_unread), never a guess.
#   * the host's limit, the usual bar and the median of this command's type and size: what the detector measured on this recording and
#     kept in the tree (meta "rules", "timing": the limits it used, and one entry per queue kind, command code and block count). A tree the
#     detector never ran on has none: the numbers stay empty and the rules that need them say so.
#   * a command the detector never judges for time (rules.LONG_BY_NATURE, rules.WAITS_BY_DESIGN on the admin queue) is marked not_timed and
#     gets no limit: an Asynchronous Event Request without a completion is not a fault.
NOT_TIMED = {**{k: (v, "it is long by nature") for k, v in RL.LONG_BY_NATURE.items()},
             **{k: (v, "it stays open until an event occurs") for k, v in RL.WAITS_BY_DESIGN.items()}}
STEP_WORDS = dict(RL.CYCLE)
READ_CYCLE = "the steps of the command and the link's answer to each of its packets, from the command's own rows in the tree"
READ_TIMES = "the host's limit and the usual time of this command type and size, as the built-in checks measured them on this recording"


def _detail(f):
    """The finding's detail as a dict ({} for none, for text that is not JSON and for anything that is not an object)."""
    d = f.get("detail")
    if isinstance(d, (str, bytes)):
        try:
            d = json.loads(d)
        except ValueError:
            d = None
    return d if isinstance(d, dict) else {}


def _stored_cycle(d):
    """The cycle the detector kept with its finding, when it is whole (the steps as a list, completed as yes or no, the counts as whole
    numbers); None when the finding keeps none or it is damaged: the cycle is then read from the tree."""
    cyc = d.get("cycle")
    if not isinstance(cyc, dict) or not isinstance(cyc.get("reached"), list) or not isinstance(cyc.get("completed"), bool):
        return None
    if any(not (cyc.get(k) is None or (isinstance(cyc.get(k), int) and not isinstance(cyc.get(k), bool))) for k in ("nak", "unacked", "tlps")):
        return None
    if not all(isinstance(x, str) for x in cyc["reached"]) or not (cyc.get("stopped_after") is None or isinstance(cyc.get("stopped_after"), str)):
        return None
    return cyc


def _measured(con, c, not_timed):
    """{"host_limit_ps", "usual_ps", "median_ps"} of one command row, from what the detector measured on this recording and kept in the tree."""
    try:
        r = con.execute("SELECT v FROM meta WHERE k='rules'").fetchone()
        t = (json.loads(r[0]) if r and r[0] else {}).get("timing")
    except (sqlite3.Error, ValueError, TypeError, AttributeError):
        return {}
    if not isinstance(t, dict):
        return {}
    adm = c["sqid"] == 0
    out = {"host_limit_ps": None if not_timed else _ps(t.get("host_admin_ps" if adm else "host_io_ps"))}
    blocks = None if adm or c.get("nlb") is None else c["nlb"] + 1          # the key the detector groups by (rules.BLOCKS_SQL): the block count, none for an admin command
    for u in t.get("usual") if isinstance(t.get("usual"), list) else []:
        if isinstance(u, dict) and bool(u.get("admin")) == adm and u.get("opc") == c["opc"] and u.get("blocks") == blocks:
            out["median_ps"], out["usual_ps"] = _ps(u.get("median_ps")), _ps(u.get("bar_ps"))
            break
    return out


def _read_from_tree(con, out, c, stages, no_cycle):
    """Fill what the finding did not carry (see the note above). out["read_from_tree"] lists what was read here, in words."""
    read = []
    if c["sqid"] == 0 and c["opc"] in NOT_TIMED:
        out["not_timed"] = {"name": NOT_TIMED[c["opc"]][0], "why": NOT_TIMED[c["opc"]][1]}
    if no_cycle:
        try:
            cy = RL.command_cycle(con, c["rowid_file"], c["t_ps"])
        except sqlite3.Error:
            cy = None
        if cy is None:
            out["cycle_unread"] = ("the NVMe transactions of this recording are not in the tree, so the steps of this command, and whether a completion entry was "
                                   "written for it, cannot be read")
        else:
            completed = cy["completed"]
            if not completed and (c["sct"] is not None or c["sc"] is not None):
                completed = None
                out["cycle_unread"] = ("the command's own row carries a status, but no completion entry is joined under it in the tree, so where its cycle ended "
                                       "cannot be read")
            out.update(reached=cy["reached"], completed=completed, stopped_after=cy["stopped_after"] if completed is False else None, answer=cy["answer"],
                       nak=cy["nak"], unacked=cy["unacked"], packets=cy["tlps"])
            read.append(READ_CYCLE)
    need = [k for k in ("host_limit_ps", "usual_ps", "median_ps") if out[k] is None]
    if need:
        m = _measured(con, c, "not_timed" in out)
        got = [k for k in need if m.get(k) is not None]
        for k in got:
            out[k] = m[k]
        if got:
            read.append(READ_TIMES)
    if not isinstance(out["times_median"], (int, float)) or isinstance(out["times_median"], bool):
        out["times_median"] = None
    if out["times_median"] is None and out["median_ps"] and out["completed"] and c["t_ps"] is not None:
        # the detector's own measure: the command's Time Stamp to its FIRST completion entry, over the median of its type and size
        first = min((s["t_ps"] for s in stages if s["t_ps"] is not None and N.part_key(s["type"]) == "cqe"), default=None)
        if first is not None and first > c["t_ps"]:
            out["times_median"] = round((first - c["t_ps"]) / out["median_ps"], 2)
    if read:
        out["read_from_tree"] = read


def card(con, f):
    """The evidence card of a finding (an error) from its own command in the tree (an sqlite connection to hier.sqlite). The same command
    gives the same evidence whichever rule found it: what the finding's detail does not carry is read from the tree (_read_from_tree)."""
    d = _detail(f)
    cyc = _stored_cycle(d)
    kept = cyc or {}
    sig = f.get("signature")
    fields = sig.get("fields") if isinstance(sig, dict) else None
    fields = fields if isinstance(fields, dict) else {}
    out = {"version": CARD_VERSION, "rule": f.get("rule"), "level": f.get("level"), "error_row": f.get("rowid"), "kind": d.get("kind") if isinstance(d.get("kind"), str) else None,
           "status": fields.get("st"), "reached": kept.get("reached") or [], "completed": kept.get("completed"), "stopped_after": kept.get("stopped_after"),
           "answer": kept.get("answer"), "nak": kept.get("nak") or 0, "unacked": kept.get("unacked") or 0, "packets": kept.get("tlps"),
           "host_limit_ps": _ps(d.get("host_limit_ps")), "usual_ps": _ps(d.get("usual_bar_ps")), "median_ps": _ps(d.get("median_ps")),
           "times_median": d.get("times_median"), "command": None, "stages": [], "longest_wait": None, "stall_row": None, "abort": None,
           "during": None, "link_events": [], "after": None}
    cmd_row = f.get("cmd_rowid") or (f.get("rowid") if f.get("level") == "nvme_command" else None)
    if not cmd_row:
        return out
    con.row_factory = sqlite3.Row
    c = con.execute("SELECT rowid_file, opc, sqid, cid, nlb, sct, sc, t_ps, dur_ps FROM cmd WHERE rowid_file=?", (cmd_row,)).fetchone()
    if c is None:
        return out
    c = dict(c)
    t0 = c["t_ps"]
    try:
        stages = [dict(r) for r in con.execute("SELECT rowid_file, type, t_ps FROM ntx WHERE parent_level='nvme_command' AND parent=? ORDER BY t_ps, rowid_file", (cmd_row,))]
    except sqlite3.Error:           # a recording loaded without its NVMe transactions file: the card holds the command's own row, and says what it cannot read
        stages = []
    _read_from_tree(con, out, c, stages, cyc is None)
    prev = t0
    for s in stages:
        s["after_doorbell_ps"] = (s["t_ps"] - t0) if s["t_ps"] is not None and t0 is not None else None
        s["gap_ps"] = (s["t_ps"] - prev) if s["t_ps"] is not None and prev is not None else None
        prev = s["t_ps"] if s["t_ps"] is not None else prev
    end = (t0 + c["dur_ps"]) if (t0 is not None and c.get("dur_ps")) else (stages[-1]["t_ps"] if stages else t0)
    out["command"] = {"row": cmd_row, "opc": c["opc"], "queue": c["sqid"], "id": c["cid"], "doorbell_ps": t0, "end_ps": end, "elapsed_ps": c.get("dur_ps"),
                      "status": [c["sct"], c["sc"]] if c["sct"] is not None else None}
    out["stages"] = [{"row": s["rowid_file"], "what": s["type"], "after_doorbell_ps": s["after_doorbell_ps"], "gap_ps": s["gap_ps"]} for s in stages]
    if len(stages) >= 2:
        w = max(range(1, len(stages)), key=lambda i: (stages[i]["gap_ps"] or 0, -i))
        out["longest_wait"] = {"from_row": stages[w - 1]["rowid_file"], "from_what": stages[w - 1]["type"], "to_row": stages[w]["rowid_file"], "to_what": stages[w]["type"],
                               "ps": stages[w]["gap_ps"]}
    # where the defect started: the last step the command made before its longest wait (completed late), or the last step it reached (stopped)
    if out["completed"] is False and stages:
        last = stages[-1]
        out["stall_row"] = {"level": "nvme_transaction", "row": last["rowid_file"], "what": last["type"], "why": "the last step the command reached; nothing came after it"}
    elif out["longest_wait"]:
        lw = out["longest_wait"]
        out["stall_row"] = {"level": "nvme_transaction", "row": lw["from_row"], "what": lw["from_what"], "why": "the last step before the longest wait (%s)" % fmt(lw["ps"])}
    elif stages:
        out["stall_row"] = {"level": "nvme_transaction", "row": stages[0]["rowid_file"], "what": stages[0]["type"], "why": "the command's first step"}
    # a command that never completed: what happened after its last step (its own interval ends where the stall begins), joined by identity
    link_to = end
    if out["completed"] is False and t0 is not None:
        t_last = max([s["t_ps"] for s in stages if s["t_ps"] is not None] + [t0])
        try:
            out["after"] = _after(con, c, t_last)
            link_to = out["after"].get("wait_end_ps", end)
            if out["after"].get("abort"):
                out["abort"] = {"row": out["after"]["abort"]["row"], "after_doorbell_ps": out["after"]["abort"]["after_doorbell_ps"]}
        except (__import__("sqlite3").Error, ValueError, TypeError, KeyError, IndexError) as e:
            out["after"] = {"unreadable": "%s: %s" % (type(e).__name__, e)}
    # the host's Abort of a command that completed: an Abort (admin) sent while it was outstanding WHOSE OWN PARAMETERS NAME THIS COMMAND
    # (2026-11-15: until then the first Abort sent in the command's interval was taken, by time alone; now every rule's error of a completed
    # command reaches this point, so it is joined by identity like the Abort of a command that never completed). An Abort that names
    # another command is not this command's; one whose parameters cannot be read is listed (abort_unreadable), never given by nearness.
    if t0 is not None and end is not None and out["completed"] is not False:
        for ab in con.execute("SELECT rowid_file, cid, t_ps FROM cmd WHERE opc=? AND sqid=0 AND rowid_file!=? AND t_ps>=? AND t_ps<=? ORDER BY t_ps, rowid_file LIMIT ?",
                              (ABORT_OPC, cmd_row, t0, end, LOOK)).fetchall():
            if c["sqid"] is None or c["cid"] is None:
                target, why = None, "this command's own queue or identifier cannot be read, so no Abort can be matched to it by identity"
            else:
                try:
                    target, why = _abort_target(con, ab["rowid_file"], ab["cid"])
                except sqlite3.Error:
                    target, why = None, "the rows under the Abort (its NVMe transactions, link rows or packets) are not in the tree"
            if target is None:
                out.setdefault("abort_unreadable", {"row": ab["rowid_file"], "after_doorbell_ps": ab["t_ps"] - t0, "why": why})
            elif target == (c["sqid"], c["cid"]):
                out["abort"] = {"row": ab["rowid_file"], "after_doorbell_ps": ab["t_ps"] - t0}
                out.pop("abort_unreadable", None)
                break
        # when this command is itself an Abort that the drive answered: the command its own parameters name (for one that never completed: after.names)
        if c["opc"] == ABORT_OPC and c["sqid"] == 0:
            try:
                out["names"] = _names(con, cmd_row, c["cid"], t0)
            except sqlite3.Error:
                out["names"] = {"unreadable": "the rows under the Abort (its NVMe transactions, link rows or packets) are not in the tree"}
    if t0 is not None and end is not None:
        # what else ran in its own interval, and the link events in it
        other = con.execute("SELECT COUNT(*), SUM(CASE WHEN sct IS NOT NULL THEN 1 ELSE 0 END), SUM(CASE WHEN sqid=? THEN 1 ELSE 0 END) FROM cmd "
                            "WHERE rowid_file!=? AND t_ps>=? AND t_ps<=?", (c["sqid"], cmd_row, t0, end)).fetchone()
        out["during"] = {"commands": other[0] or 0, "completed": other[1] or 0, "same_queue": other[2] or 0, "from_ps": t0, "to_ps": end}
        out["link_events"] = [{"rule": r[0], "row": r[1], "level": r[2]} for r in con.execute(
            "SELECT rule, rowid, level FROM finding WHERE level IN ('packets','link','split') AND t_ps>=? AND t_ps<=? ORDER BY t_ps LIMIT 20", (t0, end))]
        if link_to is not None and link_to > end:
            # the wait of a command that never completed: the link events in it (only the link rules, so that other findings cannot crowd them out)
            out["link_events"] += [{"rule": r[0], "row": r[1], "level": r[2]} for r in con.execute(
                "SELECT rule, rowid, level FROM finding WHERE level IN ('packets','link','split') AND rule IN (%s) AND t_ps>? AND t_ps<=? ORDER BY t_ps LIMIT 20"
                % ",".join("?" * len(LINK_RULES)), LINK_RULES + (end, link_to))]
    return out


def card_hash(c):
    return hashlib.sha256(json.dumps(c, sort_keys=True, default=str).encode()).hexdigest()[:16]


OPC_WORDS = {0x00: "Flush", 0x01: "Write", 0x02: "Read", 0x08: "Abort"}


def _cmd_words(opc, queue, cid, row):
    name = ("Abort" if opc == ABORT_OPC else "admin command %02Xh" % opc) if queue == 0 and opc is not None else OPC_WORDS.get(opc, "command %02Xh" % opc if opc is not None else "command")
    return "%s, NVMe command row %s (queue %s, identifier %s)" % (name, row, queue, cid)


def _reaction_words(c):
    """What the host did after the command's last step, in plain words with the measured times (the same for the same card)."""
    a = c.get("after") or {}
    ab, rs, out = a.get("abort"), a.get("reset"), []
    if ab:
        out.append("The host sent an Abort for this command %s after it was submitted (NVMe command row %s, whose own parameters name queue %s, identifier %s); %s."
                   % (fmt(ab["after_doorbell_ps"]), ab["row"], ab["names"][0], ab["names"][1],
                      ("the drive answered the Abort after %s but never completed this command" % fmt(ab["answer_after_ps"])) if ab.get("answered")
                      else "the drive did not answer the Abort either"))
    elif a.get("aborts_for_others"):
        out.append("No Abort named this command (%d Abort sent during the wait named another command)." % a["aborts_for_others"])
    else:
        out.append("The host sent no Abort for this command.")
    if rs:
        out.append("The controller was reset %s after this command was submitted (a write of EN = 0 to the controller configuration register, NVMe transaction row %s%s)."
                   % (fmt(rs["after_doorbell_ps"]), rs["row"], (", %s after the Abort" % fmt(rs["after_abort_ps"])) if rs.get("after_abort_ps") is not None else ""))
    else:
        out.append("No controller reset followed before the recording ended, %s after this command was submitted." % fmt(a.get("outstanding_ps")))
    fs = a.get("first_stopped")
    if fs:
        out.append("It was not the first command to stop: %s was sent %s earlier and also never completed." % (_cmd_words(fs["opc"], fs["queue"], fs["id"], fs["row"]), fmt(fs["before_this_ps"])))
    else:
        out.append("It was the first command to stop since the %s." % ("previous controller reset" if a.get("episode_from") else "start of the recording"))
    return " ".join(out)


def _never_completed(c):
    """The cause of a command that never completed, from the card's "after" section. Fixed rules in this order, the first that applies:

    N0  the after section could not be read from the tree                                              -> unknown_cause (with the reason)
    N1  no Abort names this command, but an Abort sent during the wait has parameters that cannot be read (damaged or missing bytes):
        the code cannot tell whether that Abort was for this command, and never gives it by nearness in time  -> unknown_cause
    N2  a write to the controller configuration register after this command's last step, before any readable reset, cannot be read:
        the code cannot tell whether (and so when) the controller was reset                                 -> unknown_cause
    N2b no Abort names this command, no controller reset followed, and the recording ended before the command had been outstanding for the
        host's limit (or no limit is known for this recording): it was still open when the recording ended    -> unknown_cause
        (the detector's timeout rule never files such a command; another rule can)
    N3  an Abort that names this command came sooner than this command type usually takes here (the median of the recording): the same
        evidence as for a completed command (keyword's own evidence: "an Abort with a short, fixed delay; no driver timeout")
                                                                                                        -> host_abort_by_tool_or_test
    N4  a controller reset ended the wait BEFORE this command had been outstanding for the host's limit for it, so it had not timed out:
        a) an earlier command sent since the previous reset also never completed (it stopped first): this command was only outstanding
           when the driver reset the controller after that command's timeout (Linux drivers/nvme/host/pci.c nvme_timeout(): Abort, then
           controller reset, as cited in nvme_hier/rules.py BASIS "cmd.timeout")                         -> host_reset_or_driver_recovery
        b) no earlier command was outstanding: the recording does not show why the host reset                -> unknown_cause
    N5  the drive answered at least one other command, sent after this command's last step, before the wait ended: the drive as a whole
        had not stopped, it held this one command; link clean, packets acknowledged (the keyword's own evidence: "fetched, then a long
        wait before the answer; all packets acknowledged"; here the answer never came)                    -> device_internal_delay
    N6  the drive answered no other command on any queue during the wait (others were sent, none answered; or none was sent, which the
        words then say), link clean (the keyword's own evidence: "fetched, then nothing on any queue; link clean") -> firmware_stall
    The link rules (a link event during the wait, refused or unacknowledged packets) are checked before these, in decide_cause.
    The host's Abort at its limit and the reset are the host's reaction: they are stated in the words and do not decide N5 or N6."""
    a, reached, st = c.get("after"), c.get("reached") or [], c.get("stopped_after")
    if not a or a.get("unreadable") or not a.get("others"):
        return "unknown_cause", ("the command never completed, and what happened after its last step could not be read from the tree (%s), so the fixed rules cannot decide"
                                 % ((a or {}).get("unreadable") or "the command's own row or its time is missing"))
    ab, rs, med, limit, o = a.get("abort"), a.get("reset"), c.get("median_ps"), c.get("host_limit_ps"), a["others"]
    if ab is None and a.get("aborts_unreadable"):
        u = a["aborts_unreadable"][0]
        return "unknown_cause", ("an Abort was sent %s after this command was submitted (NVMe command row %s), but %s, so the code cannot tell whether it was for this "
                                 "command and does not decide by nearness in time") % (fmt(u["after_doorbell_ps"]), u["row"], u["why"])
    if a.get("register_writes_unreadable"):
        u = a["register_writes_unreadable"][0]
        if u.get("capped"):
            return "unknown_cause", ("more than %d accesses to the controller configuration register followed this command's last step and none of the first %d is a reset "
                                     "(the last examined: NVMe transaction row %s, %s after the last step), so the code cannot tell whether the controller was reset later"
                                     % (LOOK, LOOK, u["row"], fmt(u["at_ps"] - a["last_step_ps"])))
        return "unknown_cause", ("a write to the controller configuration register followed %s after this command's last step (NVMe transaction row %s), but its value "
                                 "cannot be read, so the code cannot tell whether the controller was reset") % (fmt(u["at_ps"] - a["last_step_ps"]), u["row"])
    if ab is None and rs is None and (not limit or (a.get("outstanding_ps") or 0) < limit):
        # (2026-11-15) no Abort names it, no controller reset followed, and the recording ended before the host's limit for it (or no limit is
        # known for this recording): the host had not given it up. The detector's timeout rule never files such a command ("still open when
        # the recording ended"); another rule can, and its error must not be given the cause of a stall
        if not limit:
            return "unknown_cause", ("no completion of this command is in the recording, which ended %s after it was submitted; no Abort names it and no controller reset "
                                     "followed, and the host's limit for it is not known for this recording (the built-in checks kept none in the tree), so the code "
                                     "cannot tell whether the host had given it up. To name a cause the rules need that limit, or an Abort or a reset after it"
                                     % fmt(a.get("outstanding_ps")))
        return "unknown_cause", ("the recording ended %s after this command was submitted, before the host's limit for it (%s): it was still open when the recording "
                                 "ended. No Abort names it and no controller reset followed, so the recording does not show whether the drive would have answered "
                                 "it. To name a cause the recording would have to go on until the host's limit") % (fmt(a.get("outstanding_ps")), fmt(limit))
    react = _reaction_words(c)
    where = "the drive never fetched the command (it stopped after the doorbell)" if st in ("doorbell", None) and "fetched" not in reached else \
        "the drive took the command and stopped after the %s, with all of its packets acknowledged" % (st or "last step")
    if ab is not None and med and ab["after_doorbell_ps"] < med:
        return "host_abort_by_tool_or_test", ("the host sent an Abort for this command %s after it was submitted, sooner than this command type usually takes here (median %s); "
                                              "the host's driver limit is %s, so the Abort came from a program or test, not from the driver's timeout. %s"
                                              % (fmt(ab["after_doorbell_ps"]), fmt(med), fmt(limit), react))
    if rs is not None and limit and rs["after_doorbell_ps"] < limit:
        fs = a.get("first_stopped")
        if fs:
            nm = a.get("names") or {}
            own = " This command is the host's Abort for that command." if nm.get("row") == fs["row"] else ""
            return "host_reset_or_driver_recovery", ("this command had been outstanding for %s, less than the host's limit for it (%s), when the driver reset the controller (NVMe "
                                                     "transaction row %s): it had not timed out itself. The command that stopped first was %s, sent %s before the reset.%s "
                                                     "In the %s it waited, the drive answered %d other command(s).%s"
                                                     % (fmt(rs["after_doorbell_ps"]), fmt(limit), rs["row"], _cmd_words(fs["opc"], fs["queue"], fs["id"], fs["row"]),
                                                        fmt(fs["before_wait_end_ps"]), own, fmt(a["wait_ps"]), o["answered"],
                                                        (" This command type usually takes %s here." % fmt(med)) if med else ""))
        return "unknown_cause", ("the controller was reset %s after this command was submitted, before the host's limit for it (%s), and no earlier command was outstanding: "
                                 "the recording does not show why the host reset the controller. %s") % (fmt(rs["after_doorbell_ps"]), fmt(limit), react)
    if o["answered"] > 0:
        return "device_internal_delay", ("%s; in the %s wait that followed (until the %s) the drive answered %d other command(s) on %d queue(s), %d of them on this command's "
                                         "queue %s, so the drive as a whole had not stopped: it held this one command, and the recording cannot tell why inside the drive. %s"
                                         % (where, fmt(a["wait_ps"]), a["wait_end"], o["answered"], o["queues_answered"], o["answered_same_queue"], (c.get("command") or {}).get("queue"), react))
    return "firmware_stall", ("%s; in the %s wait that followed (until the %s) the drive answered no other command on any queue (%s); the link was clean. %s"
                              % (where, fmt(a["wait_ps"]), a["wait_end"],
                                 ("%d were sent, none was answered" % o["sent"]) if o["sent"] else "none was sent, so the recording cannot show the drive answering anything", react))


def decide_cause(c):
    """(cause keyword, the rule that decided it, in words). Fixed rules in a fixed order: the first that applies decides.

    1  the rule itself is a link event                                                          -> link_retraining_recovery
    2  the command's own packets were refused (Nak) or left unacknowledged                      -> link_replay_storm
    3  a link event happened while the command was outstanding (for a command that never completed: until the controller reset that
       ended its wait, or the end of the recording)                                             -> link_retraining_recovery
    4  the command never completed                                                              -> the rules N0-N6 of _never_completed
       (a command the detector never judges for time, such as an Asynchronous Event Request     -> unknown_cause, said so)
    5  the host's Abort while the command was outstanding, naming this command by its own parameters: sooner than the usual time ->
       host_abort_by_tool_or_test; before the driver's limit -> host_timer_shorter_than_drive_latency; after it ->
       host_reset_or_driver_recovery; the limit not known, or an Abort whose parameters cannot be read -> unknown_cause, said so
    6  completion entry without interrupt -> interrupt_lost; interrupt without head doorbell -> host_missed_completion
    7  media error status -> media_retry_or_read_error; slower than the usual bar -> device_internal_delay; else -> unknown_cause, with
       what the command's own rows show and what the rules would have needed (_nothing_applies)

    The rules read only the card, and the card is the same for the same command whichever rule found it (2026-11-15): "rule" is looked at
    by rule 1 alone (is the error itself a link event), never to tell a timeout from another error.
    """
    rule = c.get("rule") or ""
    if rule in LINK_RULES:
        return "link_retraining_recovery", "the rule itself is a link event (%s)" % rule
    if (c.get("nak") or 0) > 0 or (c.get("unacked") or 0) > 0:
        return "link_replay_storm", "the command's own packets were refused or left unacknowledged on the link (Nak %s, unacknowledged %s)" % (c.get("nak"), c.get("unacked"))
    if any(e["rule"] in LINK_RULES for e in c.get("link_events") or []):
        return "link_retraining_recovery", "a link event happened while the command was outstanding (%s)" % ", ".join(sorted({e["rule"] for e in c["link_events"]}))
    if c.get("completed") is False:
        nt = c.get("not_timed")
        if nt:
            return "unknown_cause", ("this command (%s, on the admin queue) is never judged for time by the fixed rules, because %s: that the recording holds no "
                                     "completion for it is not a fault by them, so no cause is named. To name one the recording would have to show an error of "
                                     "another kind on this command") % (nt.get("name"), nt.get("why"))
        return _never_completed(c)
    ab, med, usual, limit = c.get("abort"), c.get("median_ps"), c.get("usual_ps"), c.get("host_limit_ps")
    if ab is None and c.get("abort_unreadable"):
        u = c["abort_unreadable"]
        return "unknown_cause", ("an Abort was sent %s after this command's doorbell, while it was outstanding (NVMe command row %s), but %s, so the code cannot tell "
                                 "whether it was for this command and does not decide by nearness in time") % (fmt(u.get("after_doorbell_ps")), u.get("row"), u.get("why"))
    if ab is not None:
        t = ab["after_doorbell_ps"]
        if med and t < med:
            return "host_abort_by_tool_or_test", ("the host sent the Abort %s after the doorbell, sooner than this command type usually takes here (median %s); "
                                                  "the host's driver limit is %s, so the Abort came from a program or test, not from the drive's slowness") % (fmt(t), fmt(med), fmt(limit))
        if limit and t < limit:
            return "host_timer_shorter_than_drive_latency", ("the host sent the Abort %s after the doorbell, after the usual time (median %s) but long before "
                                                             "the driver's limit (%s): the host's own timer was shorter than the drive's answer") % (fmt(t), fmt(med), fmt(limit))
        if not limit:
            # (2026-11-15) without the host's limit the Abort cannot be placed before or after it: until then this fell through to "after its limit (-)"
            return "unknown_cause", ("the host sent an Abort for this command %s after the doorbell (NVMe command row %s), but the host's limit for this command is not "
                                     "known for this recording (the built-in checks kept none in the tree), so the code cannot tell whether the Abort came before or "
                                     "after the driver's limit. To name a cause the rules need that limit" % (fmt(t), ab.get("row")))
        return "host_reset_or_driver_recovery", "the host aborted the command after its limit (%s)" % fmt(limit)
    reached = c.get("reached") or []
    if "completed" in reached and "interrupt" not in reached:
        return "interrupt_lost", "the completion entry was written but no interrupt followed it"
    if "interrupt" in reached and "consumed" not in reached:
        return "host_missed_completion", "the interrupt was sent but the host never took the completion (no head doorbell)"
    st = _status_of(c)
    if st and st[0] == 2:
        return "media_retry_or_read_error", "the drive answered with a media error status (%s)" % st[2]
    if usual and (c.get("command") or {}).get("elapsed_ps") and c["command"]["elapsed_ps"] > usual:
        return "device_internal_delay", ("the drive answered after %s, longer than this command type's usual bar here (%s), with a clean link; "
                                         "the recording cannot tell why inside the drive") % (fmt(c["command"]["elapsed_ps"]), fmt(usual))
    return "unknown_cause", _nothing_applies(c)


RULES_NEED = ("a link event or packets of the command that were refused or left unacknowledged, no completion of the command, an Abort of the host that names it, "
              "a completion entry without its interrupt or its head doorbell, a media error status, or an answer slower than usual for its command type and size")


def _status_of(c):
    """(status code type, status code, official name) of the error's command: from the page's signature, else from the command's own row."""
    st = TERMS._status(c.get("status"))
    if st:
        return st
    cs = (c.get("command") or {}).get("status")
    if isinstance(cs, (list, tuple)) and len(cs) == 2 and cs[0] is not None:
        sct, sc = int(cs[0]), int(cs[1] or 0)
        return sct, sc, TERMS.NVME_STATUS.get((sct, sc), "status %Xh/%02Xh" % (sct, sc))
    return None


def _nothing_applies(c):
    """The words of an error that no fixed rule covers: what the command's own rows show, then what the rules would have needed. It never
    names a cause, and it is the same for the same card."""
    head = "none of the fixed rules applies to this evidence"
    cmd = c.get("command")
    if not cmd:
        return head + (": this error belongs to no NVMe command of the tree, and every fixed rule reads the rows of the error's own command. To name a cause the "
                       "error's row would have to belong to a command through the tree's parent links")
    if c.get("cycle_unread"):
        return "%s: %s. To name a cause the rules need one of these in the command's own rows: %s" % (head, c["cycle_unread"], RULES_NEED)
    shown = []
    st, took = _status_of(c), cmd.get("elapsed_ps")
    if c.get("completed"):
        shown.append("the command completed %s%s" % (("with status %Xh/%02Xh (%s)" % st) if st and st[:2] != (0, 0) else "with success" if st else "(its status cannot be read)",
                                                     (" after %s" % fmt(took)) if took else ""))
    steps = [STEP_WORDS.get(k, k) for k in c.get("reached") or []]
    if steps:
        n = c.get("packets")
        shown.append("its steps in the recording are %s%s" % (", ".join(steps), (", and the link acknowledged all %d of its packets" % n) if n else ""))
    shown.append("no link event happened while it was outstanding")
    shown.append("no Abort sent while it was outstanding names it")
    if c.get("usual_ps") and took:
        shown.append("it was not slower than usual for its command type and size here (the usual bar is %s)" % fmt(c["usual_ps"]))
    elif c.get("usual_ps"):
        shown.append("its own time is not in its row, so it cannot be compared with the usual bar of its command type and size (%s)" % fmt(c["usual_ps"]))
    else:
        shown.append("no usual time is measured in this recording for its command type and size")
    out = "%s: %s. To name a cause the rules need one of these in the command's own rows: %s." % (head, "; ".join(shown), RULES_NEED)
    nm = c.get("names")
    if isinstance(nm, dict):
        if nm.get("unreadable"):
            out += " This command is the host's Abort; which command it names cannot be read (%s)." % nm["unreadable"]
        elif nm.get("row") is None:
            out += (" This command is the host's Abort; its own parameters name queue %s, identifier %s, and no command with that queue and identifier was sent "
                    "before it in the recording." % (nm.get("queue"), nm.get("id")))
        else:
            out += (" This command is the host's Abort; its own parameters name %s, which %s: why the host sent the Abort is decided on the error of that command."
                    % (_cmd_words(nm.get("opc"), nm.get("queue"), nm.get("id"), nm.get("row")), "completed" if nm.get("completed") else "never completed"))
    return out


def facts(c, term, cause_key):
    """The parts of the isolation code states itself (what, when, where, which, who), the same for the same card."""
    cmd = c.get("command") or {}
    cz = TERMS.cause_of(cause_key) or {}
    st = c.get("stall_row") or {}
    elapsed = cmd.get("elapsed_ps")
    what = term["name"] + ("; it took %s" % fmt(elapsed) if elapsed else "")
    if c.get("median_ps"):
        what += " (this command type usually takes %s here; the host's driver limit is %s)" % (fmt(c["median_ps"]), fmt(c.get("host_limit_ps")))
    when = ("from %s (the doorbell) to %s in the recording" % (fmt(cmd.get("doorbell_ps")), fmt(cmd.get("end_ps")))) if cmd.get("doorbell_ps") is not None else "-"
    if c.get("abort"):
        when += "; the host's Abort came %s after the doorbell (row %s)" % (fmt(c["abort"]["after_doorbell_ps"]), c["abort"]["row"])
    rs = (c.get("after") or {}).get("reset")
    if rs:
        when += "; the controller was reset %s after the doorbell (NVMe transaction row %s)" % (fmt(rs["after_doorbell_ps"]), rs["row"])
    where = ("NVMe command row %s (queue %s, id %s)" % (cmd.get("row"), cmd.get("queue"), cmd.get("id"))) if cmd else "row %s, %s level" % (c.get("error_row"), c.get("level"))
    if c.get("stages"):
        where += "; its NVMe transactions: " + ", ".join("row %s %s" % (s["row"], s["what"]) for s in c["stages"])
    which = ("NVMe transaction row %s (%s): %s" % (st.get("row"), st.get("what"), st.get("why"))) if st else where
    who = cz.get("side_words") or "not decided"
    return {"what": what, "when": when, "where": where, "which": which, "who": who}
