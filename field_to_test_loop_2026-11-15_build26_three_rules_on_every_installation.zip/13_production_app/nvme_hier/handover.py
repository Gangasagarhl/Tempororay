"""Hand-over of approved tests to a team's validation suite (statement S8, item B7 of deploy/REAL_ENVIRONMENT_WORK.md; 2026-11-14).

The application writes tests into its own folders:
  suite/hier/<upload>_f<finding>_v<n>.py     the main flow; beside it <file>.approved.json (who approved, when, the file's fingerprint)
                                             and the replay library f2t_nvme.py
  suite/<test id>/                           the earlier packet workflow: test_*.py, manifest.json, conftest.py; the approval there is
                                             recorded on the PROCEDURE the test was written from (db/knowledge.sqlite, table solution,
                                             status 'admin-approved'), with no fingerprint of the test file

Which validation suite takes these tests, and in what form, is the owner's answer to give. This module builds the general part:

  list_tests(root)                         every test with its approval state
  build_package(root, names, who)          one zip of the tests an admin SELECTED (never all), approved ones only; a test changed after its
                                           approval is refused. The zip holds the test files unchanged, the replay library beside them, a
                                           manifest (JSON and text), a results template and a README with the exact command
  read_results(root, data, who)            a JUnit XML file made from such a package: per test passed / failed / skipped with the reason,
                                           the date and who brought it in, kept in tables of this module's own (handover_*) in
                                           db/hier_knowledge.sqlite
  results(root)                            what came back, per test
  packages(root)                           the packages built so far

Nothing here runs a test or touches a drive. Every refusal is a HandoverError whose text is a plain sentence for a person.
"""
import ast
import hashlib
import io
import json
import os
import pathlib
import re
import sqlite3
import time
import uuid
import zipfile
from xml.parsers import expat

MAX_RESULT_BYTES = 5 * 1024 * 1024        # a JUnit result file of a package is some kilobytes; 5 megabytes is refused
MAX_XML_ELEMENTS = 200000
MAX_XML_DEPTH = 32
MAX_SELECTION = 500
MAX_TEST_BYTES = 8 * 1024 * 1024
REASON_CHARS = 600
LIBRARY_NAME = "f2t_nvme.py"
MAIN, PACKET = "main flow", "earlier packet workflow"
MAIN_FOLDER, PACKET_FOLDER = "tests", "packet_workflow"

NAME_MAIN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_+\-]*(\.[A-Za-z0-9_+\-]+)*\.py$")
NAME_PACKET = re.compile(r"^T-[A-Za-z0-9_+\-]+(\.[A-Za-z0-9_+\-]+)*$")
ENV_ASSIGN = re.compile(r"(?<![A-Za-z0-9_])([A-Z][A-Z0-9_]{2,})=(\S+)")
ENV_READ = re.compile(r"os\.environ(?:\.get\(|\[)\s*[\"']([A-Z][A-Z0-9_]{2,})[\"']")

SCHEMA = """
CREATE TABLE IF NOT EXISTS handover_package (
  package_id TEXT PRIMARY KEY, built_at REAL, built_by TEXT, zip_sha256 TEXT, n_tests INTEGER);
CREATE TABLE IF NOT EXISTS handover_package_test (
  package_id TEXT, test TEXT, workflow TEXT, classname TEXT, sha256 TEXT, PRIMARY KEY (package_id, test));
CREATE TABLE IF NOT EXISTS handover_result (
  id INTEGER PRIMARY KEY, package_id TEXT, test TEXT, case_name TEXT, outcome TEXT, reason TEXT, drive_kind TEXT, expect TEXT,
  drive_model TEXT, drive_firmware TEXT, run_at TEXT, brought_in_at REAL, brought_in_by TEXT, file_sha256 TEXT);
CREATE INDEX IF NOT EXISTS handover_result_test ON handover_result (test, brought_in_at);
CREATE TABLE IF NOT EXISTS handover_lab (
  package_id TEXT, test TEXT, run_key TEXT, solution_id INTEGER, revision_id INTEGER, lab_row INTEGER, bench TEXT, runs INTEGER, reproduced INTEGER,
  counted_at REAL, counted_by TEXT, PRIMARY KEY (package_id, test, run_key));
"""
# Lab runs brought back from a validation suite (2026-11-15; nvme_hier/graph_learning.py LabLedger.add_lab, source "validation_suite").
# handover_lab holds one row per run that was counted on the procedural graph: the package, the test and the run's own time stamp as the
# result file states it (run_key; empty when the file states none). Its primary key is what keeps one run from being counted twice.
# handover_package_test gains solution_id and revision_id (added to an older database when it is opened): the stored solution a test was
# written from, found when the package is built and written into the package's manifest.
REPLAY_CASE = "test_defect_reproduces_or_stays_fixed"     # the case of a main-flow test file that replays the solution's sequence (nvme_hier/testplan.py writes it)
MAX_LAB_RUNS = 10 ** 6


class HandoverError(ValueError):
    """A refusal a person reads: its text is one plain sentence (or a few)."""


# ---------------------------------------------------------------------------------------------- small helpers
def when(seconds):
    """A moment as text with its zone."""
    try:
        return time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime(float(seconds)))
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for part in iter(lambda: fh.read(1 << 20), b""):
            h.update(part)
    return h.hexdigest()


def suite_dir(root):
    return os.path.join(root, "suite")


def knowledge_db(root):
    return os.path.join(root, "db", "hier_knowledge.sqlite")


def _con(root):
    """The main flow's knowledge database, opened the way nvme_hier/defect_graph.py opens it; the tables are this module's own."""
    path = knowledge_db(root)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    con = sqlite3.connect(path, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.executescript(SCHEMA)
    have = [r[1] for r in con.execute("PRAGMA table_info(handover_package_test)")]
    for col in ("solution_id", "revision_id"):          # a database made before 2026-11-15 gains the two columns here
        if col not in have:
            try:
                con.execute("ALTER TABLE handover_package_test ADD COLUMN %s INTEGER" % col)
            except sqlite3.OperationalError:            # another request added it in the same moment
                pass
    con.commit()
    return con


def _read_only(path):
    """Another part's database, for reading only (None when it is not there)."""
    if not os.path.isfile(path):
        return None
    try:
        con = sqlite3.connect(pathlib.Path(os.path.abspath(path)).as_uri() + "?mode=ro", uri=True, timeout=5)
        con.row_factory = sqlite3.Row
        return con
    except sqlite3.Error:
        return None


def _who(who):
    if not isinstance(who, str) or not who.strip():
        raise HandoverError("Say who you are (your name) first: the record keeps who did this.")
    who = " ".join(who.split())
    if "\x00" in who or len(who) > 120:
        raise HandoverError("The name must be plain text of at most 120 characters.")
    return who


# ---------------------------------------------------------------------------------------------- names and paths
def check_name(name):
    """A test's name as the listing gives it: a file name of suite/hier (ends in .py) or a folder name of the earlier workflow (T-...).
    Returns (workflow, name); anything else is refused in words. A name is never a path."""
    if not isinstance(name, str):
        raise HandoverError("A test is chosen by its name as the list shows it; %s is not a name." % _show(name))
    if "\x00" in name:
        raise HandoverError("A test name cannot hold a NUL character.")
    if not name or len(name) > 200:
        raise HandoverError("A test name must be between 1 and 200 characters long.")
    if "/" in name or "\\" in name or os.sep in name or (os.altsep and os.altsep in name) or ":" in name:
        raise HandoverError("Choose a test by its name as the list shows it, not by a path: %s holds a folder separator." % _show(name))
    if ".." in name:
        raise HandoverError("A test name cannot hold '..': %s is refused." % _show(name))
    if name == LIBRARY_NAME or name == "conftest.py":
        raise HandoverError("%s is not a test: it is a helper file of the tests. The package brings the library by itself." % _show(name))
    if NAME_MAIN.match(name):
        return MAIN, name
    if NAME_PACKET.match(name):
        return PACKET, name
    raise HandoverError("There is no test named %s. Choose a name from the list of tests." % _show(name))


def _show(v):
    s = repr(v) if not isinstance(v, str) else '"%s"' % "".join(c if c.isprintable() else "?" for c in v)
    return s if len(s) <= 90 else s[:87] + '..."'


def _inside(folder, name):
    """folder/name as a real path, or a refusal: the entry must exist in that folder itself and must not be a link out of it."""
    base = os.path.realpath(folder)
    plain = os.path.join(base, name)
    try:
        real = os.path.realpath(plain)
        link = os.path.islink(plain)
    except (OSError, ValueError):
        raise HandoverError("The name %s cannot be used as a file name on this computer." % _show(name))
    if link or os.path.normcase(real) != os.path.normcase(plain):
        raise HandoverError("%s is a link to another place, not a file of the application's test folder: it is refused." % _show(name))
    return real


def _main_path(root, name):
    path = _inside(os.path.join(suite_dir(root), "hier"), name)
    if not os.path.isfile(path):
        raise HandoverError("There is no test named %s. Choose a name from the list of tests." % _show(name))
    return path


def _packet_files(root, name):
    """The files of one earlier-workflow test folder: {file name: real path} (the test file(s), manifest.json, conftest.py)."""
    folder = _inside(suite_dir(root), name)
    if not os.path.isdir(folder) or not os.path.isfile(os.path.join(folder, "manifest.json")):
        raise HandoverError("There is no test named %s. Choose a name from the list of tests." % _show(name))
    out = {}
    for f in sorted(os.listdir(folder)):
        if f == "manifest.json" or f == "conftest.py" or (f.startswith("test_") and f.endswith(".py")):
            out[f] = _inside(folder, f)
            if not os.path.isfile(out[f]):
                raise HandoverError("%s in the test folder %s is not a plain file: it is refused." % (_show(f), _show(name)))
    if not any(f.startswith("test_") for f in out):
        raise HandoverError("The test folder %s holds no test file." % _show(name))
    return out


# ---------------------------------------------------------------------------------------------- reading a test file (never run, never imported)
def _read_text(path):
    if os.path.getsize(path) > MAX_TEST_BYTES:
        raise HandoverError("The test file %s is larger than %d megabytes: it is refused." % (_show(os.path.basename(path)), MAX_TEST_BYTES >> 20))
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def header_of(text):
    """The file's own header (its first docstring) as lines, read with the parser: the file is never run."""
    try:
        tree = ast.parse(text)
    except (SyntaxError, ValueError, RecursionError, MemoryError):
        return []
    return (ast.get_docstring(tree, clean=False) or "").splitlines()


def block_of(lines, title):
    """The indented lines under a title line of the header ('How to run', 'Resource Requirements', ...)."""
    out, inside = [], False
    for line in lines:
        if not inside:
            inside = line.strip() == title or line.strip().startswith(title + " (")
            continue
        if line.strip() and not line.startswith((" ", "\t")):
            break
        if line.strip():
            out.append(line.strip())
    return out


def plan_of(text):
    """The PLAN the file carries (data only), read with the parser. {} when the file has none or it is not plain data."""
    try:
        tree = ast.parse(text)
    except (SyntaxError, ValueError, RecursionError, MemoryError):
        return {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "PLAN" for t in node.targets):
            try:
                v = ast.literal_eval(node.value)
            except (ValueError, SyntaxError, RecursionError, MemoryError, TypeError):
                return {}
            return v if isinstance(v, dict) else {}
    return {}


def needs_of(text, extra_text=""):
    """What the test needs to run, taken from the file itself: its 'How to run' lines, the environment variables those lines and the rest
    of the header name (NAME=value) and, for the earlier workflow, the ones its fixture file reads (os.environ)."""
    head = header_of(text)
    how = block_of(head, "How to run")
    setup = [x for x in block_of(head, "Test Setup")]
    names = {}
    for where, lines in (("the 'How to run' lines", how), ("the header", head)):
        for line in lines:
            for m in ENV_ASSIGN.finditer(line):
                names.setdefault(m.group(1), {"name": m.group(1), "as_written": m.group(0).rstrip(".,;:)"), "named_in": where})
    for m in ENV_READ.finditer(extra_text or ""):
        names.setdefault(m.group(1), {"name": m.group(1), "as_written": m.group(1), "named_in": "the fixture file beside the test (conftest.py)"})
    return {"how_to_run": how, "resource_requirements": block_of(head, "Resource Requirements"), "safety_gate": _safety_lines(setup),
            "simulated_drive_line": next((x for x in block_of(head, "Possible Problems") if "NVME_BACKEND=sim" in x), None),
            "environment_variables": list(names.values())}


def _safety_lines(setup):
    out, inside = [], False
    for line in setup:
        if re.match(r"^\d+\.\s", line):
            inside = "safety gate" in line.lower()
        if inside:
            out.append(line)
    return out


# ---------------------------------------------------------------------------------------------- approval
def _approval_main(path):
    """The approval record beside a main-flow test file -> state. States: approved / not approved / changed after approval /
    approval record unreadable."""
    rec_path = path + ".approved.json"
    name = os.path.basename(path)
    now = sha256_of(path)
    base = {"approval_kind": "of this test file (record %s beside it)" % (name + ".approved.json"), "fingerprint_now": now}
    if os.path.islink(rec_path) or not os.path.isfile(rec_path):
        return dict(base, state="not approved", can_hand_over=False,
                    why_not="The test %s has not been approved: there is no approval record beside it. Approve it on its error page first." % name)
    try:
        with open(rec_path, encoding="utf-8") as fh:
            rec = json.load(fh)
        if not isinstance(rec, dict):
            raise ValueError("not a record")
    except (OSError, ValueError):
        return dict(base, state="approval record unreadable", can_hand_over=False,
                    why_not="The approval record of the test %s cannot be read. Approve the test again on its error page." % name)
    who, sha = rec.get("approved_by"), rec.get("sha256")
    out = dict(base, approved_by=who if isinstance(who, str) else None, approved_at=when(rec.get("at")), approved_at_seconds=rec.get("at") if isinstance(rec.get("at"), (int, float)) else None,
               comment=rec.get("comment") if isinstance(rec.get("comment"), str) else "", fingerprint_at_approval=sha if isinstance(sha, str) else None,
               upload=rec.get("upload_id") if isinstance(rec.get("upload_id"), str) else None, finding=rec.get("finding") if isinstance(rec.get("finding"), int) else None,
               two_sided=rec.get("two_sided"))
    if rec.get("status") != "approved" or not out["approved_by"] or not out["fingerprint_at_approval"]:
        return dict(out, state="not approved", can_hand_over=False,
                    why_not="The record beside the test %s does not say it is approved (it needs the word 'approved', the approver's name and the file's fingerprint). Approve it on its error page." % name)
    if sha != now:
        return dict(out, state="changed after approval", can_hand_over=False,
                    why_not="The test %s was changed after %s approved it%s: the file's fingerprint no longer matches the approval record. It must be approved again before it is handed over." % (
                        name, out["approved_by"], (" on " + out["approved_at"]) if out["approved_at"] else ""))
    return dict(out, state="approved", can_hand_over=True, why_not="")


def _approval_packet(root, name, manifest):
    """The earlier workflow keeps no approval record beside the test. What it keeps: the status of the PROCEDURE the test was written from
    (db/knowledge.sqlite, table solution: 'admin-approved' and the approver), and the approval event with its time."""
    base = {"approval_kind": "of the procedure this test was written from (the earlier workflow keeps no approval record and no fingerprint of the test file itself)"}
    key = manifest.get("source_solution") if isinstance(manifest, dict) else None
    if not isinstance(key, str) or not key:
        return dict(base, state="not approved", can_hand_over=False,
                    why_not="The test %s does not name the procedure it was written from, so no approval can be found for it." % name)
    con = _read_only(os.path.join(root, "db", "knowledge.sqlite"))
    if con is None:
        return dict(base, state="not approved", can_hand_over=False,
                    why_not="The earlier workflow's database (db/knowledge.sqlite) is not on this computer, so no approval can be found for the test %s." % name)
    try:
        row = con.execute("SELECT status, approved_by FROM solution WHERE vhash = ?", (key,)).fetchone()
        at = None
        if row is not None and row["status"] == "admin-approved":
            for ev in con.execute("SELECT ts, payload FROM event WHERE kind = 'solution_approve' AND undone = 0 ORDER BY id DESC"):
                try:
                    if json.loads(ev["payload"] or "{}").get("vhash") == key:
                        at = ev["ts"]
                        break
                except ValueError:
                    continue
    except sqlite3.Error:
        return dict(base, state="not approved", can_hand_over=False,
                    why_not="The earlier workflow's database could not be read, so no approval can be found for the test %s." % name)
    finally:
        con.close()
    if row is None:
        return dict(base, state="not approved", can_hand_over=False,
                    why_not="The procedure the test %s was written from is not in the earlier workflow's database any more, so it has no approval." % name)
    if row["status"] != "admin-approved" or not row["approved_by"]:
        return dict(base, state="not approved", can_hand_over=False, procedure_status=row["status"],
                    why_not="The procedure the test %s was written from has the status '%s', not 'admin-approved': a second admin has not approved it." % (name, row["status"]))
    return dict(base, state="approved", can_hand_over=True, why_not="", approved_by=row["approved_by"], approved_at=when(at) if at else None, approved_at_seconds=at,
                procedure_status=row["status"], comment="", fingerprint_at_approval=None, two_sided=None,
                caution="No fingerprint was taken at approval in the earlier workflow: a change to the test file after the approval cannot be detected. "
                        "The fingerprint in the package is of the file as it was when the package was built.")


# ---------------------------------------------------------------------------------------------- the stored solution a test was written from
# What ties a test to a stored solution (found 2026-11-15): when a test is approved on the page of one error, or by the flow, the procedural
# graph writes the test file's path on the VERSION of the solution it was approved for (dg_revision.test_path; app/api/isolate_api.py
# approve_testcase, POST /api/dg/revisions/<id>/test). That is an identity: this file, that version. Nothing else is used: not the error's
# number, not the latest judgement, not a time. A test approved without a version of a solution has no such row and is tied to nothing.
NOT_TIED = ("The application's records do not tie the test %s to a stored solution of the procedural graph: it was approved without naming a "
            "version of a solution.")


def _names_this_test(stored, want, name):
    """True when a path the graph keeps for a version of a solution is this test file: the same real path, or (the application's folder was
    moved, or the path was written on another system) a path that ends in suite/hier/<the test's name>."""
    if not isinstance(stored, str) or not stored or "\x00" in stored:
        return False
    try:
        if want and os.path.normcase(os.path.realpath(stored)) == os.path.normcase(want):
            return True
    except (OSError, ValueError):
        pass
    return stored.replace("\\", "/").endswith("/suite/hier/" + name)


def solution_of_test(root, name):
    """The stored solution a test was written from, by identity (see above), read from the graph's records without changing them.
    -> {"solution_id", "revision_id", "version", "words"}; the three are None, and the words say why, when the test is tied to none."""
    workflow, name = check_name(name)
    none = {"solution_id": None, "revision_id": None, "version": None}
    if workflow != MAIN:
        return dict(none, words="The test %s belongs to the earlier packet workflow, which keeps its own procedures: it is not tied to a solution of the procedural graph." % name)
    try:
        want = _main_path(root, name)
    except HandoverError:
        want = None                                    # the file is not in the test folder any more: only the stored path can name it
    con = _read_only(knowledge_db(root))
    if con is None:
        return dict(none, words=NOT_TIED % name)
    try:
        rows = [dict(r) for r in con.execute("SELECT r.id, r.solution_id, r.version, r.test_path FROM dg_revision r JOIN dg_solution s ON s.id = r.solution_id "
                                             "WHERE r.test_path IS NOT NULL AND substr(r.test_path, ?) = ? ORDER BY r.version DESC, r.id DESC", (-len(name), name))]
    except sqlite3.Error:
        rows = []                                      # a knowledge base without the graph's tables holds no solution
    finally:
        con.close()
    hits = [r for r in rows if _names_this_test(r["test_path"], want, name)]
    if not hits:
        return dict(none, words=NOT_TIED % name)
    if len({r["solution_id"] for r in hits}) > 1:
        return dict(none, words="More than one stored solution of the procedural graph names the test %s as its approved test (solutions number %s), so the "
                                "test is not tied to one of them." % (name, ", ".join(str(x) for x in sorted({r["solution_id"] for r in hits}))))
    top = hits[0]
    return {"solution_id": top["solution_id"], "revision_id": top["id"], "version": top["version"],
            "words": "The test %s was approved for version %s of stored solution number %d of the procedural graph: the graph keeps this test file as the "
                     "approved test of that version." % (name, top["version"], top["solution_id"])}


# ---------------------------------------------------------------------------------------------- the listing
def _load_json(path):
    try:
        with open(path, encoding="utf-8") as fh:
            v = json.load(fh)
        return v if isinstance(v, dict) else {}
    except (OSError, ValueError):
        return {}


def _recording_main(root, upload):
    """The recording a main-flow test came from: the upload's number and the names of its files (never its rows)."""
    if not upload or not isinstance(upload, str) or not re.match(r"^[A-Za-z0-9][A-Za-z0-9_.\-]*$", upload) or ".." in upload:
        return {"upload": None, "files": [], "words": "The test does not name the recording it came from."}
    meta = _load_json(os.path.join(root, "uploads", upload, "meta.json"))
    files = meta.get("files") if isinstance(meta.get("files"), dict) else {}
    names = [{"level": str(k), "file": os.path.basename(str(v).replace("\\", "/"))} for k, v in files.items() if v]
    words = ("Upload %s, files: %s." % (upload, ", ".join("%s (%s)" % (n["file"], n["level"]) for n in names))) if names else \
        "Upload %s. The record of its file names is not on this computer any more." % upload
    return {"upload": upload, "files": names, "device": meta.get("device") if isinstance(meta.get("device"), str) else None, "words": words}


def _real_drive_results(root):
    """Per test, the results brought in whose result file says they ran on a real drive."""
    out = {}
    if not os.path.isfile(knowledge_db(root)):
        return out
    con = _read_only(knowledge_db(root))
    if con is None:
        return out
    try:
        for r in con.execute("SELECT test, outcome, brought_in_at FROM handover_result WHERE drive_kind = 'real' ORDER BY brought_in_at"):
            out.setdefault(r["test"], []).append({"outcome": r["outcome"], "brought_in_at": when(r["brought_in_at"])})
    except sqlite3.Error:
        pass
    finally:
        con.close()
    return out


def _run_history(real):
    if real:
        last = real[-1]
        return {"only_simulated_drive": False, "words": "A result from a real drive was brought into this application for this test (%s, on %s). "
                                                        "Everything before that was on the simulated drive." % (last["outcome"], last["brought_in_at"])}
    return {"only_simulated_drive": True, "words": "Only ever run on a simulated drive, as far as this application's records show: no result from a real drive "
                                                   "has been brought in for this test. A simulated run checks the test's mechanics, never a drive."}


def _two_sided_words(v):
    if isinstance(v, dict):
        runs = v.get("runs") if isinstance(v.get("runs"), list) else []
        lines = ["%s drive, expecting '%s': wanted %s, got %s" % (r.get("drive"), r.get("expect"), r.get("wanted"), r.get("got")) for r in runs if isinstance(r, dict)]
        return {"recorded": True, "passed": bool(v.get("ok")), "words": "Two-way check on the simulated drive recorded at approval: %s%s" % (
            str(v.get("words") or ("passed" if v.get("ok") else "not passed")), (" (" + "; ".join(lines) + ")") if lines else "")}
    if v is True or v is False:
        return {"recorded": True, "passed": v, "words": "Two-way check on the simulated drive (the test must find the fault on a faulty simulated drive and pass on a correct one) "
                                                        "recorded at approval as %s. It checks the test's mechanics, never a drive." % ("passed" if v else "NOT passed")}
    return {"recorded": False, "passed": None, "words": "No two-way result was recorded at approval."}


def describe(root, name, real=None):
    """Everything the listing and the manifest say of one test. Raises HandoverError when the name is not a test."""
    workflow, name = check_name(name)
    real = _real_drive_results(root) if real is None else real
    if workflow == MAIN:
        path = _main_path(root, name)
        text = _read_text(path)
        plan = plan_of(text)
        ap = _approval_main(path)
        upload = plan.get("upload") if isinstance(plan.get("upload"), str) else ap.get("upload")
        lib_path = os.path.join(os.path.dirname(path), LIBRARY_NAME)
        lib_now = sha256_of(lib_path) if os.path.isfile(lib_path) and not os.path.islink(lib_path) else None
        named = plan.get("library") if isinstance(plan.get("library"), str) else None
        same = bool(named and lib_now and lib_now.startswith(named))
        library = {"file": LIBRARY_NAME, "fingerprint_sha256": lib_now, "named_by_the_test": named, "same_as_named": same,
                   "words": "The replay library is not beside the test: the test cannot run without it." if not lib_now else
                            "The package brings the replay library the test was written with (fingerprint starts with %s)." % named if same else
                            "The test does not name the replay library it was written with; the package brings the one beside it now." if not named else
                            "The test was written with replay library %s; the library beside it today is a later one (fingerprint starts with %s). The package brings "
                            "today's library, the only one beside the test. The test has not been run again with it by this package." % (named, lib_now[:16])}
        defect = " ".join(str(plan.get("observed") or "").split())
        scenario = " ".join(str(plan.get("scenario") or "").split())
        d = {"name": name, "workflow": workflow, "files": [name], "version": plan.get("version"),
             "defect": defect or "The test file does not say in words which defect it reproduces.", "scenario": scenario or None,
             "recording": _recording_main(root, upload), "finding": plan.get("finding") if isinstance(plan.get("finding"), int) else ap.get("finding"),
             "needs": needs_of(text), "library": library, "two_way_result_at_approval": _two_sided_words(ap.get("two_sided")),
             "size_bytes": os.path.getsize(path)}
        if ap.get("can_hand_over") and not lib_now:
            ap = dict(ap, can_hand_over=False, why_not="The replay library (%s) is not beside the test %s: without it the test cannot run, so it is not handed over." % (LIBRARY_NAME, name))
    else:
        files = _packet_files(root, name)
        manifest = _load_json(files["manifest.json"])
        ap = _approval_packet(root, name, manifest)
        test_files = [f for f in files if f.startswith("test_")]
        text = _read_text(files[test_files[0]])
        conf = _read_text(files["conftest.py"]) if "conftest.py" in files else ""
        sig = manifest.get("signature") if isinstance(manifest.get("signature"), dict) else {}
        doc = " ".join(" ".join(header_of(text)[:2]).split())
        defect = " ".join(str(sig.get("detail") or "").split()) or doc or "The test's own record does not say in words which defect it reproduces."
        cap = manifest.get("capture") if isinstance(manifest.get("capture"), dict) else {}
        d = {"name": name, "workflow": workflow, "files": sorted(files), "version": None, "defect": defect, "scenario": None,
             "recording": {"upload": None, "files": [], "incident": manifest.get("incident_id"), "device": manifest.get("device") if isinstance(manifest.get("device"), str) else None,
                           "words": "Incident %s of the earlier packet workflow (capture: %s). That workflow's test record does not keep the recording's file names." % (
                               manifest.get("incident_id") or "(not named)", cap.get("tool") or "not named")},
             "finding": None, "needs": needs_of(text, conf),
             "library": {"file": None, "fingerprint_sha256": None, "named_by_the_test": None, "same_as_named": None,
                         "words": "This test does not use the replay library. Its fixture file (conftest.py) imports the application's own stage-2 program "
                                  "(testgen.py, found through the environment variable STAGE2_DIR): it runs only where that program folder is present." if "STAGE2_DIR" in conf else
                                  "This test does not use the replay library; see its fixture file (conftest.py) for what it imports."},
             "two_way_result_at_approval": _closed_loop_words(manifest), "size_bytes": sum(os.path.getsize(p) for p in files.values())}
        ap = dict(ap, fingerprint_now=sha256_of(files[test_files[0]]))
    d["approval"] = {k: ap.get(k) for k in ("state", "can_hand_over", "why_not", "approval_kind", "approved_by", "approved_at", "comment", "fingerprint_at_approval",
                                            "fingerprint_now", "procedure_status", "caution") if ap.get(k) is not None}
    d["approval"].setdefault("can_hand_over", False)
    d["run_history"] = _run_history(real.get(name))
    return d


def _closed_loop_words(manifest):
    v = manifest.get("closed_loop_at_generation")
    if v is None:
        return {"recorded": False, "passed": None, "words": "No two-way result was recorded for this test."}
    def n(k):
        return v.get(k) if isinstance(v, dict) and isinstance(v.get(k), int) and not isinstance(v.get(k), bool) else None
    if None in (n("known_bad_hits"), n("known_bad_n"), n("fixed_hits"), n("fixed_n")):
        return {"recorded": False, "passed": None, "words": "The earlier workflow's record of its two-way check for this test cannot be read as run counts."}
    passed = v.get("passed") if isinstance(v.get("passed"), bool) else None
    return {"recorded": True, "passed": passed, "counts": {k: n(k) for k in ("known_bad_hits", "known_bad_n", "fixed_hits", "fixed_n")},
            "words": "Recorded by the earlier workflow when the test was written, on its simulated bench: the defect showed in %d of %d runs with the faulty firmware "
                     "and in %d of %d runs with the fixed firmware%s. A simulated bench checks the test's mechanics, never a drive." % (
                         n("known_bad_hits"), n("known_bad_n"), n("fixed_hits"), n("fixed_n"),
                         "" if passed is None else "; the workflow's own check of this is recorded as %s" % ("passed" if passed else "not passed"))}


def list_tests(root):
    """Every test of the application's test folders with its approval state. Nothing is chosen: the admin chooses."""
    out, problems = [], []
    real = _real_drive_results(root)
    hier = os.path.join(suite_dir(root), "hier")
    names = []
    if os.path.isdir(hier):
        names += [f for f in sorted(os.listdir(hier)) if f.endswith(".py") and f not in (LIBRARY_NAME, "conftest.py")]
    if os.path.isdir(suite_dir(root)):
        names += [f for f in sorted(os.listdir(suite_dir(root))) if f.startswith("T-") and os.path.isfile(os.path.join(suite_dir(root), f, "manifest.json"))]
    for n in names:
        try:
            out.append(describe(root, n, real))
        except HandoverError as e:
            problems.append({"name": n, "problem": str(e)})
        except OSError as e:
            problems.append({"name": n, "problem": "The test %s could not be read (%s)." % (n, e.strerror or "the file system refused")})
    return {"tests": out, "not_listed": problems,
            "counts": {"tests": len(out), "can_be_handed_over": sum(1 for t in out if t["approval"]["can_hand_over"])},
            "note": "Nothing is chosen in advance. Only approved tests whose file is unchanged since the approval can be handed over."}


# ---------------------------------------------------------------------------------------------- the package
def _selection(names):
    if names is None or names == "" or names == []:
        raise HandoverError("Nothing was selected. Choose the tests to hand over: the application never takes all of them by itself.")
    if not isinstance(names, (list, tuple)):
        raise HandoverError("The selection must be a list of test names as the list of tests shows them.")
    if len(names) > MAX_SELECTION:
        raise HandoverError("At most %d tests go into one package; %d were selected." % (MAX_SELECTION, len(names)))
    seen, out = set(), []
    for n in names:
        workflow, n = check_name(n)
        if n not in seen:
            seen.add(n)
            out.append((workflow, n))
    return out


def _classname(*parts):
    """The name pytest writes for a test file in its JUnit result (the path from the folder it runs in, dots for separators, no .py)."""
    p = "/".join(parts)
    return (p[:-3] if p.endswith(".py") else p).replace("/", ".")


def build_package(root, names, who, record=True):
    """One zip of the selected, approved tests. -> {"package_id", "zip": bytes, "file_name", "manifest"}. Refuses (HandoverError) when nothing is
    selected, when a name is not a test, when a test is not approved or was changed after its approval. Nothing is written beside the tests."""
    who = _who(who)
    chosen = _selection(names)
    real = _real_drive_results(root)
    tests, refused = [], []
    for workflow, n in chosen:
        d = describe(root, n, real)
        if not d["approval"]["can_hand_over"]:
            refused.append(d["approval"].get("why_not") or "The test %s cannot be handed over." % n)
        tests.append(d)
    if refused:
        raise HandoverError(" ".join(refused) + " No package was built.")
    now = time.time()
    package_id = "handover-%s-%s" % (time.strftime("%Y%m%d-%H%M%S", time.gmtime(now)), uuid.uuid4().hex[:6])
    members, entries, libs = [], [], {}
    for d in tests:
        if d["workflow"] == MAIN:
            path = _main_path(root, d["name"])
            with open(path, "rb") as fh:
                data = fh.read()
            sha = hashlib.sha256(data).hexdigest()
            if sha != d["approval"].get("fingerprint_at_approval"):          # changed between the check and the read
                raise HandoverError("The test %s changed while the package was being built: its fingerprint no longer matches the approval record. No package was built." % d["name"])
            lib = os.path.join(os.path.dirname(path), LIBRARY_NAME)
            with open(lib, "rb") as fh:
                libs[MAIN_FOLDER + "/" + LIBRARY_NAME] = fh.read()
            member = MAIN_FOLDER + "/" + d["name"]
            members.append((member, data))
            packed = [{"file": member, "sha256": sha, "bytes": len(data)}]
        else:
            files = _packet_files(root, d["name"])
            packed, sha, member = [], None, None
            for f, p in sorted(files.items()):
                with open(p, "rb") as fh:
                    data = fh.read()
                m = "%s/%s/%s" % (PACKET_FOLDER, d["name"], f)
                members.append((m, data))
                packed.append({"file": m, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
                if f.startswith("test_") and member is None:
                    member, sha = m, packed[-1]["sha256"]
        e = {"name": d["name"], "workflow": d["workflow"], "file_in_package": member, "files_in_package": packed, "result_name": _classname(member),
             "defect": d["defect"], "scenario": d["scenario"], "recording": d["recording"], "finding_number_in_the_recording": d["finding"],
             "approved_by": d["approval"].get("approved_by"), "approved_at": d["approval"].get("approved_at"), "approval_comment": d["approval"].get("comment") or "",
             "approval_is": d["approval"].get("approval_kind"), "approval_caution": d["approval"].get("caution"),
             "fingerprint_sha256": sha, "fingerprint_matches_the_approval": True if d["workflow"] == MAIN else None,
             "needs_to_run": d["needs"], "replay_library": d["library"], "run_history": d["run_history"],
             "two_way_result_at_approval": d["two_way_result_at_approval"]}
        # the stored solution the test was written from, kept with the package from now on (2026-11-15): a result brought back for this
        # test is counted as lab runs of that solution; a test tied to none says so
        e["stored_solution"] = solution_of_test(root, d["name"])
        e["stored_solution"]["words"] += (" A result brought back for this test is counted as lab runs of that solution." if e["stored_solution"]["solution_id"] is not None else
                                          " A result brought back for it is kept, but it is not counted as lab runs of a solution.")
        entries.append(e)
    for m, data in libs.items():
        members.append((m, data))
    manifest = {"package": package_id, "built_at": when(now), "built_by": who, "made_by": "RL-Powered Field-to-Test Loop application, hand-over of approved tests",
                "what_this_is": "Approved regression tests chosen by %s for a validation suite. The tests are unchanged copies of the application's files." % who,
                "tests": entries,
                "replay_library": [{"file": m, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)} for m, data in sorted(libs.items())],
                "result_file": {"format": "JUnit XML, written by pytest's own --junit-xml option", "bring_back": "Give the result file to the application (Hand over to the validation suite, Bring a result file in)."}}
    extra = [("manifest.json", json.dumps(manifest, indent=1, ensure_ascii=False).encode("utf-8")),
             ("manifest.txt", manifest_text(manifest).encode("utf-8")),
             ("README.txt", readme_text(manifest).encode("utf-8")),
             ("results_template.csv", results_template(manifest).encode("utf-8")),
             ("pytest.ini", pytest_ini(manifest).encode("utf-8")),
             ("conftest.py", (PACKAGE_CONFTEST % {"id": package_id}).encode("utf-8"))]
    buf = io.BytesIO()
    stamp = time.gmtime(now)[:6]
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for m, data in extra + members:
            info = zipfile.ZipInfo(m, date_time=stamp)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, data)
    data = buf.getvalue()
    if record:
        con = _con(root)
        try:
            with con:
                con.execute("INSERT INTO handover_package (package_id, built_at, built_by, zip_sha256, n_tests) VALUES (?,?,?,?,?)",
                            (package_id, now, who, hashlib.sha256(data).hexdigest(), len(entries)))
                con.executemany("INSERT INTO handover_package_test (package_id, test, workflow, classname, sha256, solution_id, revision_id) VALUES (?,?,?,?,?,?,?)",
                                [(package_id, e["name"], e["workflow"], e["result_name"], e["fingerprint_sha256"], e["stored_solution"]["solution_id"],
                                  e["stored_solution"]["revision_id"]) for e in entries])
        finally:
            con.close()
    return {"package_id": package_id, "zip": data, "file_name": package_id + ".zip", "manifest": manifest, "zip_sha256": hashlib.sha256(data).hexdigest()}


def pytest_ini(manifest):
    """The package's own pytest settings. The main flow's test files are named <upload>_f<error number>_v<version>.py, which pytest does not
    take for test files when it is given a folder (it looks for test_*.py); so each of them is named here, exactly."""
    names = [e["name"] for e in manifest["tests"] if e["workflow"] == MAIN]
    return ("[pytest]\n# Written by the hand-over package. It makes this folder the place pytest runs from, so the result file names the tests the same way\n"
            "# everywhere, and it names the test files of this package (pytest alone would only take files called test_*.py from a folder).\n"
            "junit_family = xunit2\npython_files =\n    test_*.py\n" + "".join("    %s\n" % n for n in names))


PACKAGE_CONFTEST = '''"""Written by the hand-over package, not by a test: it puts the package's number into the JUnit result file, so the application that
built the package knows which package a result belongs to. It changes nothing in the tests."""
import pytest

HANDOVER_PACKAGE = "%(id)s"


@pytest.fixture(scope="session", autouse=True)
def _handover_package(record_testsuite_property):
    record_testsuite_property("handover_package", HANDOVER_PACKAGE)
'''


def _wrap(text, indent="    ", width=110):
    out, line = [], ""
    for word in str(text).split():
        if line and len(line) + 1 + len(word) > width - len(indent):
            out.append(indent + line)
            line = word
        else:
            line = (line + " " + word) if line else word
    if line:
        out.append(indent + line)
    return out or [indent]


def manifest_text(manifest):
    """The manifest for a person to read: the same facts as manifest.json."""
    lines = ["HAND-OVER PACKAGE %s" % manifest["package"], "Built %s by %s." % (manifest["built_at"], manifest["built_by"]),
             "%d test%s, each an unchanged copy of the application's approved file." % (len(manifest["tests"]), "" if len(manifest["tests"]) == 1 else "s"), ""]
    for i, e in enumerate(manifest["tests"], 1):
        lines += ["%d. %s   (%s)" % (i, e["name"], e["workflow"]), "  File in this package: %s" % e["file_in_package"], "  The defect it reproduces:"] + _wrap(e["defect"])
        if e.get("scenario"):
            lines += ["  Scenario:"] + _wrap(e["scenario"])
        lines += ["  The recording it came from:"] + _wrap(e["recording"]["words"])
        lines += ["  Approval:"] + _wrap("Approved by %s%s. The approval is %s." % (e["approved_by"], (" on " + e["approved_at"]) if e["approved_at"] else " (the record keeps no time)", e["approval_is"]))
        if e.get("approval_comment"):
            lines += _wrap("The approver's comment: %s" % e["approval_comment"])
        if e.get("approval_caution"):
            lines += _wrap(e["approval_caution"])
        lines += ["  Fingerprint of the file (SHA-256):", "    %s%s" % (e["fingerprint_sha256"], "  (the same as in the approval record)" if e["fingerprint_matches_the_approval"] else "")]
        lines += ["  Replay library:"] + _wrap(e["replay_library"]["words"])
        need = e["needs_to_run"]
        lines += ["  What it needs to run (from the test file's own header):"]
        lines += ["    " + x for x in need["resource_requirements"]] or ["    (the file's header lists no requirements)"]
        lines += ["  Environment variables the file names:"]
        lines += ["    %s   (as written in %s: %s)" % (v["name"], v["named_in"], v["as_written"]) for v in need["environment_variables"]] or ["    (none named)"]
        lines += ["  Run so far:"] + _wrap(e["run_history"]["words"])
        if isinstance(e.get("stored_solution"), dict):
            lines += ["  Stored solution it was written from:"] + _wrap(e["stored_solution"]["words"])
        lines += ["  Two-way result:"] + _wrap(e["two_way_result_at_approval"]["words"]) + [""]
    return "\n".join(lines) + "\n"


def readme_text(manifest):
    """The package's README: what is inside, the exact commands, the safety switches a person sets, how results come back."""
    main = [e for e in manifest["tests"] if e["workflow"] == MAIN]
    packet = [e for e in manifest["tests"] if e["workflow"] == PACKET]
    L = ["HAND-OVER PACKAGE %s" % manifest["package"], "",
         "What this is",
         "    %d approved regression test%s from the Field-to-Test Loop application, chosen by %s on %s." % (len(manifest["tests"]), "" if len(manifest["tests"]) == 1 else "s", manifest["built_by"], manifest["built_at"]),
         "    Every test file is an unchanged copy; manifest.txt (and manifest.json, the same facts for a program) says for each test",
         "    which defect it reproduces, which recording it came from, who approved it and when, and the file's fingerprint.", "",
         "Read this first",
         "    Every test in this package has, as far as the application's records show, only ever been run on a SIMULATED drive", "    unless manifest.txt says otherwise for a test. A simulated run checks the test's mechanics, never a drive.",
         "    A skipped test is not a passed test: the skip reason names the precondition that was not met.", "",
         "What is inside",
         "    README.txt              this file",
         "    manifest.txt / .json    the facts of every test",
         "    results_template.csv    one line per test for a suite that keeps its own sheet (the application reads the JUnit file, not this sheet)",
         "    pytest.ini, conftest.py written by the package: they fix the folder pytest runs from, name the test files of this package for pytest",
         "                            (pytest alone takes only files called test_*.py from a folder) and put the package's number into the result file"]
    if main:
        L += ["    %s/                  the tests of the main flow and their replay library (%s) beside them" % (MAIN_FOLDER, LIBRARY_NAME)]
    if packet:
        L += ["    %s/        the tests of the earlier packet workflow, one folder each (test file, its record manifest.json, its fixture file conftest.py)" % PACKET_FOLDER]
    L += [""]
    if main:
        hows = []
        for e in main:
            for x in e["needs_to_run"]["how_to_run"][:1]:
                x = x.replace("<this file>", MAIN_FOLDER)
                if x not in hows:
                    hows.append(x)
        sims = sorted({e["needs_to_run"]["simulated_drive_line"] for e in main if e["needs_to_run"]["simulated_drive_line"]})
        gates = []
        for e in main:
            for x in e["needs_to_run"]["safety_gate"]:
                if x not in gates:
                    gates.append(x)
        notes = []
        for e in main:
            for x in e["needs_to_run"]["how_to_run"][1:]:
                if x not in notes:
                    notes.append(x)
        L += ["Run all tests of the main flow and write a JUnit XML result file",
              "    Unpack the zip, go into the unpacked folder, and run (one line; a Linux shell, as the test files require Linux for a real drive):", ""]
        L += ["        " + x for x in hows] or ["        python3 -m pytest -q --junit-xml=result.xml %s" % MAIN_FOLDER]
        L += ["", "    This line is the one the test files' own headers give (their 'How to run' part), with the folder %s in place of one file." % MAIN_FOLDER,
              "    The values in it are examples from the header: a person replaces them (see the safety switches below).",
              "    The result file is result.xml in the unpacked folder."]
        L += ["    " + x for x in notes]
        L += ["", "Check the package without a drive (simulated drive)", "", "        NVME_BACKEND=sim python3 -m pytest -q --junit-xml=result.xml %s" % MAIN_FOLDER, ""]
        L += ["    The test files' headers say of this: " + x for x in sims]
        L += ["    On the simulated drive with no settings file of its own, a test is either skipped (the simulated drive is not the recorded model, or is",
              "    smaller than the recorded blocks need: the skip reason says which) or reports 'failed' because a drive without the fault does not show",
              "    the recorded fault. Either answer shows that the package runs; neither says anything about a real drive.", ""]
        L += ["Safety switches: set by a person, never by this package",
              "    The tests write to the drive they are given. The test files' headers say (copied from them):"]
        L += ["        " + x for x in gates] or ["        (the headers of these tests name no safety gate)"]
        L += ["    In plain words:",
              "    - The allow-list (environment variable NVME_ALLOW) is a text file a person writes: one line per permitted drive, holding the drive's",
              "      serial number and the namespace number. A drive that is not in it is never touched: the test is skipped.",
              "    - The erase confirmation is two environment variables a person sets for a test that writes: NVME_DESTRUCTIVE=1 and",
              "      NVME_CONFIRM=ERASE-<the drive's serial number>. Without both, a writing test is skipped.",
              "    - Nothing in this package holds a serial number, an allow-list or a confirmation. Do not put them into a shared script without", "      the drive owner's word.", ""]
    if packet:
        envs = sorted({v["name"] for e in packet for v in e["needs_to_run"]["environment_variables"]})
        L += ["The tests of the earlier packet workflow (%s/)" % PACKET_FOLDER,
              "    These tests are not self-contained: their fixture file (conftest.py) imports the application's own stage-2 program and runs",
              "    on its simulated bench. They run only on a computer that has the application's stage-2 folder%s:" % ((", named by the environment variable%s %s" % ("" if len(envs) == 1 else "s", ", ".join(envs))) if envs else ""), "",
              "        STAGE2_DIR=<the application's stage2 folder> python3 -m pytest -q --junit-xml=result_packet.xml %s" % PACKET_FOLDER, "",
              "    Their approval is of the procedure they were written from; the earlier workflow took no fingerprint of the test file (see manifest.txt).", ""]
    L += ["Bring the results back",
          "    Give the JUnit XML result file (result.xml) to the application: Hand over to the validation suite, Bring a result file in.",
          "    The application records for each test of this package: passed, failed or skipped with the reason, the date, and who brought the file in.",
          "    It refuses a result for a test that is in no package it built.", "",
          "Not decided yet",
          "    Which validation suite takes these tests, and in what form, is for the owner of the application to say. This package is the general",
          "    form: plain pytest files and a JUnit XML result."]
    return "\n".join(L) + "\n"


def results_template(manifest):
    """One line per test for a suite to fill (CSV). The columns after the first three are empty: nothing is filled in advance."""
    def q(v):
        return '"%s"' % str(v if v is not None else "").replace('"', '""')
    cols = ["test", "file in this package", "name in the JUnit result file", "result (passed / failed / skipped)", "reason (for failed or skipped)",
            "date of the run", "run by", "drive model", "drive firmware", "real drive or simulated drive", "EXPECT used (fault or fixed)"]
    rows = [",".join(q(c) for c in cols)]
    for e in manifest["tests"]:
        rows.append(",".join([q(e["name"]), q(e["file_in_package"]), q(e["result_name"])] + ['""'] * (len(cols) - 3)))
    return "\r\n".join(rows) + "\r\n"


# ---------------------------------------------------------------------------------------------- results coming back
class _Refused(Exception):
    pass


def parse_junit(data):
    """The test cases of a JUnit XML result file, parsed with entity handling off: a file that declares a document type or an entity is
    refused before anything is expanded (no 'billion laughs', no external entity). -> {"suites": [{"timestamp", "properties": [(name, value)]}],
    "cases": [{"classname", "name", "outcome", "reason", "suite": index}]}"""
    if not isinstance(data, (bytes, bytearray)):
        raise HandoverError("The result file must be given as a file, not as text fields.")
    if len(data) == 0:
        raise HandoverError("The result file is empty.")
    if len(data) > MAX_RESULT_BYTES:
        raise HandoverError("The result file is larger than %d megabytes: a JUnit result file of a package is far smaller, so it is refused." % (MAX_RESULT_BYTES >> 20))
    p = expat.ParserCreate()
    st = {"depth": 0, "n": 0, "suites": [], "cases": [], "case": None, "kind": None, "root": None, "text": []}

    def refuse_doctype(*a):
        raise _Refused("The result file declares a document type or an entity. A JUnit result file needs neither, and they can be used to attack the reader: the file is refused.")

    def start(tag, attrs):
        st["depth"] += 1
        st["n"] += 1
        if st["depth"] > MAX_XML_DEPTH or st["n"] > MAX_XML_ELEMENTS:
            raise _Refused("The result file is nested too deeply or holds too many entries to be a JUnit result file of a package: it is refused.")
        if st["root"] is None:
            st["root"] = tag
            if tag not in ("testsuites", "testsuite"):
                raise _Refused("The file is XML, but not a JUnit result file: its first element is '%s', not 'testsuites' or 'testsuite'." % tag[:40])
        if tag == "testsuite":
            st["suites"].append({"timestamp": attrs.get("timestamp"), "name": attrs.get("name"), "properties": []})
        elif tag == "property" and st["suites"] and st["case"] is None:
            st["suites"][-1]["properties"].append((str(attrs.get("name") or ""), str(attrs.get("value") or "")))
        elif tag == "testcase":
            if not st["suites"]:
                raise _Refused("The file is not a JUnit result file: a test case stands outside a test suite.")
            st["case"] = {"classname": str(attrs.get("classname") or ""), "name": str(attrs.get("name") or ""), "outcome": "passed", "reason": "", "suite": len(st["suites"]) - 1}
        elif tag in ("failure", "error", "skipped") and st["case"] is not None:
            c = st["case"]
            kind = {"failure": "failed", "error": "failed", "skipped": "skipped"}[tag]
            if c["outcome"] == "passed" or (kind == "failed" and c["outcome"] == "skipped"):
                c["outcome"] = kind
                c["reason"] = ("The test could not be run: " if tag == "error" else "") + str(attrs.get("message") or "")
            st["kind"], st["text"] = tag, []

    def end(tag):
        st["depth"] -= 1
        if tag in ("failure", "error", "skipped") and st["case"] is not None and st["kind"] == tag:
            if not st["case"]["reason"].strip() or st["case"]["reason"] == "The test could not be run: ":
                st["case"]["reason"] += " ".join("".join(st["text"]).split())
            st["kind"] = None
        elif tag == "testcase" and st["case"] is not None:
            st["case"]["reason"] = " ".join(st["case"]["reason"].split())[:REASON_CHARS]
            st["cases"].append(st["case"])
            st["case"] = None

    def chars(s):
        if st["kind"] is not None and sum(len(x) for x in st["text"]) < 4 * REASON_CHARS:
            st["text"].append(s)

    p.StartDoctypeDeclHandler = refuse_doctype
    p.EntityDeclHandler = refuse_doctype
    p.UnparsedEntityDeclHandler = refuse_doctype
    p.ExternalEntityRefHandler = refuse_doctype
    p.StartElementHandler, p.EndElementHandler, p.CharacterDataHandler = start, end, chars
    try:
        p.Parse(bytes(data), True)
    except _Refused as e:
        raise HandoverError(str(e))
    except expat.ExpatError:
        raise HandoverError("The file is not a JUnit XML result file: it cannot be read as XML. Give the file that pytest wrote with its --junit-xml option.")
    except (RecursionError, MemoryError, ValueError, LookupError):
        raise HandoverError("The file cannot be read as a JUnit XML result file: it is refused.")
    if st["root"] is None:
        raise HandoverError("The file is not a JUnit XML result file: it holds no test suite.")
    return {"suites": st["suites"], "cases": st["cases"]}


def _facts_per_test(props):
    """What the replay library wrote into the result file per test (test_id, test_version, backend, expect, drive_model, drive_firmware):
    groups that start at each 'test_id'. -> {"<id>_v<version>.py": {...}}"""
    out, cur = {}, None
    for k, v in props:
        if k == "test_id":
            cur = {"test_id": v}
            out.setdefault(v, cur)
        elif cur is not None:
            cur.setdefault(k, v)
    named = {}
    for cur in out.values():
        if cur.get("test_version"):
            named["%s_v%s.py" % (cur["test_id"], cur["test_version"])] = cur
    return named


def _lab_counts(outcome, verdict):
    """(runs, reproduced) of one replay that looked for the error, read from the result's own words (the replay library writes the property
    'verdict': "reproduced k of n" or "not reproduced in n runs"), or (None, why it cannot be counted). Nothing is assumed: a result that
    does not state its counts, or whose counts and outcome do not agree, is not counted."""
    v = " ".join(str(verdict or "").split())
    m = re.fullmatch(r"reproduced ([0-9]{1,7}) of ([0-9]{1,7})", v)
    n = re.fullmatch(r"not reproduced in ([0-9]{1,7}) runs?", v)
    if m:
        k, runs = int(m.group(1)), int(m.group(2))
    elif n:
        k, runs = 0, int(n.group(1))
    else:
        return None, "the result file does not say in how many runs the failure came back"
    if not 1 <= runs <= MAX_LAB_RUNS or k > runs:
        return None, "the run counts in the result file are not possible (the failure in %d of %d runs)" % (k, runs)
    if (outcome == "passed") != (k > 0):
        return None, "its outcome (%s) and its own count (the failure came back in %d of %d runs) do not agree" % (outcome, k, runs)
    return (runs, k), ""


def _count_on_graph(root, con, r, who):
    """One recorded result of a hand-over package, counted as lab runs of the stored solution its test was written from
    (defect_graph.DefectGraph.add_lab, source "validation_suite"), or the plain sentence that says why it was kept and not counted.
    Counted only when everything is stated: the test is tied to a stored solution by identity, the case is the replay of the solution's
    sequence, the result file says which bench it ran on and that the run looked for the error, and it gives its run counts. One run
    (package, test, the run's own time stamp from the result file) is counted once: handover_lab's primary key refuses the second.
    Never raises: the result itself is already recorded. -> {"counted", "words", "solution_id", "lab_row"}"""
    name, tie = r["test"], r["_tie"]
    kept = "The result of the test %s was kept, but it was not counted on the procedural graph, because " % name

    def no(why):
        return {"counted": False, "words": kept + why + ".", "solution_id": tie.get("solution_id"), "lab_row": None}
    if tie.get("workflow") != MAIN:
        return no("a test of the earlier packet workflow is not tied to a solution of the procedural graph")
    if r["case_name"] != REPLAY_CASE:
        return no("this case of the test file is not the replay of the solution's sequence")
    sid, rev = tie.get("solution_id"), tie.get("revision_id")
    if sid is None:
        # a package built before 2026-11-15 did not keep the solution: looked up now by the same identity, and only while the test file is
        # still the file the package carried (the same fingerprint)
        try:
            same = bool(tie.get("sha256")) and sha256_of(_main_path(root, name)) == tie.get("sha256")
        except (HandoverError, OSError):
            same = False
        found = solution_of_test(root, name) if same else {"solution_id": None, "revision_id": None}
        sid, rev = found["solution_id"], found["revision_id"]
        if sid is None:
            return no("the application's records do not tie this test to a stored solution (it was approved without naming a version of a solution"
                      + ("" if same else ", or the test file was changed or removed since the package was built") + ")")
    if r["outcome"] == "skipped":
        return dict(no("the test was skipped, so no run was made"), solution_id=sid)
    bench = {"simulated": "simulated", "real": "real"}.get(r["drive_kind"])
    if bench is None:
        return dict(no("the result file does not say which bench it ran on (a real drive or the simulated drive)"), solution_id=sid)
    if r["expect"] != "fault":
        return dict(no("the run looked for the fix, not for the error: a run that expects a fixed drive does not say whether this solution's sequence brings the failure back"
                       if r["expect"] == "fixed" else "the result file does not say that the run looked for the error"), solution_id=sid)
    counts, why = _lab_counts(r["outcome"], r["_verdict"])
    if counts is None:
        return dict(no(why), solution_id=sid)
    runs, reproduced = counts
    run_key = " ".join(str(r["run_at"] or "").split())[:80]
    try:
        with con:
            con.execute("INSERT INTO handover_lab (package_id, test, run_key, solution_id, revision_id, bench, runs, reproduced, counted_at, counted_by) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (r["package_id"], name, run_key, sid, rev, bench, runs, reproduced, time.time(), who))
    except sqlite3.IntegrityError:
        return dict(no("a result of this package and this test for the same run (%s) is already counted there: one run is counted once" % ("run on %s" % run_key) if run_key else
                       "the result file does not say when the run was made, and a result of this package and this test without a run time is already counted there: "
                       "it cannot be told from the same run given twice"), solution_id=sid)
    except sqlite3.Error as e:
        return dict(no("the application's database could not be written just now (%s)" % type(e).__name__), solution_id=sid)
    m = re.match(r"^(.+)_f([0-9]{1,12})_v[0-9]+\.py$", name)
    try:
        from . import defect_graph as DG
        g = DG.DefectGraph(knowledge_db(root))
        lab = g.add_lab(int(sid), bench, "validation_suite", runs, reproduced, who, revision_id=rev, model=r["drive_model"] or None, firmware=r["drive_firmware"] or None,
                        upload_id=m.group(1) if m else None, finding_id=int(m.group(2)) if m else None,
                        note="hand-over package %s, test %s%s" % (r["package_id"], name, (", run on %s" % run_key) if run_key else ""))
    except Exception as e:      # noqa: BLE001 - the result is recorded; the graph's refusal is said in words and the run stays free to be counted later
        try:
            with con:
                con.execute("DELETE FROM handover_lab WHERE package_id = ? AND test = ? AND run_key = ? AND lab_row IS NULL", (r["package_id"], name, run_key))
        except sqlite3.Error:
            pass
        return dict(no("the procedural graph did not take it (%s)" % (str(e)[:200] if isinstance(e, ValueError) else type(e).__name__)), solution_id=sid)
    try:                        # the lab row is written: which row it is goes beside the run's mark; a failure here never frees the run to be counted again
        with con:
            con.execute("UPDATE handover_lab SET lab_row = ? WHERE package_id = ? AND test = ? AND run_key = ?", (lab, r["package_id"], name, run_key))
    except sqlite3.Error:
        pass
    label = "real drive" if bench == "real" else "simulated drive"
    return {"counted": True, "solution_id": sid, "lab_row": lab,
            "words": "The result of the test %s was counted on the procedural graph as lab runs of stored solution number %d: the failure came back in %d of %d run%s on the %s. "
                     "No judgement and no order changed." % (name, sid, reproduced, runs, "" if runs == 1 else "s", label)}


def read_results(root, data, who):
    """Record a JUnit XML result file of a hand-over package. -> {"recorded": [...], "package": ..., "counts": {...}}. All or nothing: a file that
    holds a result for a test that is in no package is refused whole. Each recorded result then says, under "graph", whether it was counted
    as lab runs of a stored solution on the procedural graph (see _count_on_graph); that part never fails the recording."""
    who = _who(who)
    parsed = parse_junit(data)
    if not parsed["cases"]:
        raise HandoverError("The result file holds no test case: nothing was recorded.")
    file_sha = hashlib.sha256(bytes(data)).hexdigest()
    props = [p for s in parsed["suites"] for p in s["properties"]]
    named_package = next((v for k, v in props if k == "handover_package"), None)
    con = _con(root)
    try:
        before = con.execute("SELECT brought_in_at, brought_in_by FROM handover_result WHERE file_sha256 = ? LIMIT 1", (file_sha,)).fetchone()
        if before is not None:
            raise HandoverError("This result file was already brought in on %s by %s: it is not recorded twice." % (when(before["brought_in_at"]), before["brought_in_by"]))
        if named_package is not None and con.execute("SELECT 1 FROM handover_package WHERE package_id = ?", (named_package,)).fetchone() is None:
            raise HandoverError("The result file names the package %s, which this application did not build: nothing was recorded." % _show(named_package))
        rows = con.execute("SELECT t.package_id, t.test, t.classname, t.workflow, t.sha256, t.solution_id, t.revision_id, p.built_at "
                           "FROM handover_package_test t JOIN handover_package p USING (package_id) "
                           + ("WHERE t.package_id = ? " if named_package is not None else "") + "ORDER BY p.built_at DESC",
                           (named_package,) if named_package is not None else ()).fetchall()
        facts = _facts_per_test(props)
        now, out, unknown = time.time(), [], []
        for c in parsed["cases"]:
            cn = c["classname"]
            hit = next((r for r in rows if cn == r["classname"]), None) or \
                next((r for r in rows if cn == r["classname"].rsplit(".", 1)[-1] or cn.endswith("." + r["classname"].rsplit(".", 1)[-1])), None)
            if hit is None:
                unknown.append("%s (%s)" % (cn or "(no name)", c["name"] or "no test name"))
                continue
            f = facts.get(hit["test"], {})
            out.append({"package_id": hit["package_id"], "test": hit["test"], "case_name": c["name"], "outcome": c["outcome"], "reason": c["reason"],
                        "drive_kind": {"sim": "simulated", "real": "real"}.get(f.get("backend")), "expect": f.get("expect"), "drive_model": f.get("drive_model"),
                        "drive_firmware": f.get("drive_firmware"), "run_at": parsed["suites"][c["suite"]].get("timestamp"), "brought_in_at": now, "brought_in_by": who,
                        "_verdict": f.get("verdict"), "_tie": {k: hit[k] for k in ("workflow", "sha256", "solution_id", "revision_id")}})
        if unknown:
            raise HandoverError("The result file holds %s for %s not in %s: %s. Nothing was recorded." % (
                "a result" if len(unknown) == 1 else "results", "a test that is" if len(unknown) == 1 else "tests that are",
                ("the package %s" % named_package) if named_package is not None else "any package this application built",
                "; ".join(_show(u) for u in unknown[:5]) + (" and %d more" % (len(unknown) - 5) if len(unknown) > 5 else "")))
        with con:
            con.executemany("INSERT INTO handover_result (package_id, test, case_name, outcome, reason, drive_kind, expect, drive_model, drive_firmware, run_at, "
                            "brought_in_at, brought_in_by, file_sha256) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            [(r["package_id"], r["test"], r["case_name"], r["outcome"], r["reason"], "real" if r["drive_kind"] == "real" else "sim" if r["drive_kind"] == "simulated" else None,
                              r["expect"], r["drive_model"], r["drive_firmware"], r["run_at"], r["brought_in_at"], r["brought_in_by"], file_sha) for r in out])
        # the results are recorded; now each one is counted on the procedural graph when everything it needs is stated, else said in words
        for r in out:
            try:
                r["graph"] = _count_on_graph(root, con, r, who)
            except Exception as e:      # noqa: BLE001 - counting follows a recording that is already stored: it never fails it
                r["graph"] = {"counted": False, "solution_id": None, "lab_row": None,
                              "words": "The result of the test %s was kept, but it was not counted on the procedural graph (%s)." % (r["test"], type(e).__name__)}
    finally:
        con.close()
    for r in out:
        r.pop("_verdict", None)
        r.pop("_tie", None)
        r["brought_in_at"] = when(r["brought_in_at"])
        r["drive_kind"] = r["drive_kind"] or "not said in the result file"
    counts = {k: sum(1 for r in out if r["outcome"] == k) for k in ("passed", "failed", "skipped")}
    said = list(dict.fromkeys(r["graph"]["words"] for r in out))
    return {"recorded": out, "packages": sorted({r["package_id"] for r in out}), "counts": counts,
            "words": "%d result%s recorded: %d passed, %d failed, %d skipped." % (len(out), "" if len(out) == 1 else "s", counts["passed"], counts["failed"], counts["skipped"]),
            "graph": {"counted": sum(1 for r in out if r["graph"]["counted"]), "not_counted": sum(1 for r in out if not r["graph"]["counted"])},
            "graph_words": " ".join(said)}


def _row(r):
    return {"package_id": r["package_id"], "test": r["test"], "case_name": r["case_name"], "outcome": r["outcome"], "reason": r["reason"] or "",
            "drive_kind": {"sim": "simulated", "real": "real"}.get(r["drive_kind"], "not said in the result file"), "expect": r["expect"],
            "drive_model": r["drive_model"], "drive_firmware": r["drive_firmware"], "run_at": r["run_at"],
            "brought_in_at": when(r["brought_in_at"]), "brought_in_by": r["brought_in_by"]}


def results(root, test=None):
    """What came back, per test: the newest result first. test: one test's name, or None for all."""
    if test is not None:
        test = check_name(test)[1]
    if not os.path.isfile(knowledge_db(root)):
        return {"tests": [], "note": "No result file has been brought in yet."}
    con = _con(root)
    try:
        rows = con.execute("SELECT * FROM handover_result " + ("WHERE test = ? " if test else "") + "ORDER BY brought_in_at DESC, id DESC", (test,) if test else ()).fetchall()
    finally:
        con.close()
    by = {}
    for r in rows:
        by.setdefault(r["test"], []).append(_row(r))
    out = [{"test": t, "latest": v[0], "results": v, "count": len(v)} for t, v in by.items()]
    return {"tests": out, "note": "" if out else "No result file has been brought in yet." if test is None else "No result has been brought in for this test yet."}


def packages(root):
    """The packages built so far, newest first, with the tests in each."""
    if not os.path.isfile(knowledge_db(root)):
        return {"packages": []}
    con = _con(root)
    try:
        out = []
        for p in con.execute("SELECT * FROM handover_package ORDER BY built_at DESC").fetchall():
            tests = [r["test"] for r in con.execute("SELECT test FROM handover_package_test WHERE package_id = ? ORDER BY test", (p["package_id"],))]
            out.append({"package_id": p["package_id"], "built_at": when(p["built_at"]), "built_by": p["built_by"], "zip_sha256": p["zip_sha256"], "tests": tests})
    finally:
        con.close()
    return {"packages": out}
