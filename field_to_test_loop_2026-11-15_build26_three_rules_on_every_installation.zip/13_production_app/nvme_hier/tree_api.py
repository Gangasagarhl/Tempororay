"""The tree Family 2 built, as the only door Family 3's code has to the data (owner, 2026-11-10: "it needs to talk to family two and family one
... the data building and the rules ... otherwise it is just a waste of time"; research: reports/Connecting agent families for rules.md).

A rule's code gets a Tree and never the raw CSV files, so it cannot join the levels again by repeating values (Tag, Address, CID): every row
already knows its parent, by the approved identity rules (NVMe command > NVMe transaction > split transaction > link transaction > packet;
posted writes hang directly under their NVMe transaction; flow-control and link-event packets are context rows of the unit whose time window
holds them). Rows that the approved joins left without a parent stay without one: unlinked() lists them; nothing here guesses a parent.

    for cmd in tree.rows("nvme_command"):                       # file order; cmd["OPC"] is the cell exactly as the export wrote it
        for ntx in tree.children("nvme_command", cmd.row):     # its NVMe transactions
            ...
    for pkt in tree.rows("packets", with_ancestor="nvme_command"):
        pkt.ancestor                                            # the row of the command it belongs to, or None (outside any command)

Read only: the database is opened read-only (and the process that runs a rule's code can open nothing else). Every call is counted, so the
approval card can show what the code used.
"""
import collections
import json
import re
import sqlite3

LEVELS = ("nvme_command", "nvme_transaction", "split", "link", "packets")
TABLE = {"nvme_command": "cmd", "nvme_transaction": "ntx", "split": "spl", "link": "lnk", "packets": "pkt"}
FILE = {"nvme_command": "nvme_command.csv", "nvme_transaction": "NVME_Transactions.csv", "split": "split.csv", "link": "link.csv", "packets": "packets.csv"}
# the parent levels a row of each level can have, as the approved joins build them (a link row: its split transaction, or for a posted write
# its NVMe transaction; a packet: its link transaction, or as a context row any unit)
UP = {"nvme_transaction": ("nvme_command",), "split": ("nvme_transaction",), "link": ("split", "nvme_transaction"), "packets": ("link",)}
CHILD = {"nvme_command": ("nvme_transaction",), "nvme_transaction": ("split", "link"), "split": ("link",), "link": ("packets",), "packets": ()}
BATCH = 5000
HEADERS_KEY = "level_headers"       # meta: {level: [the named columns of its file, in the file's order]} (store_headers)
SPACER = re.compile(r"^column \d+$")  # a value under a blank header cell is kept under its position ("column 23"): not a named column
FILLED, EMPTY, MISSING = "filled", "in the file, empty in every row", "not in the file"       # Tree.column_state


def header_of_file(con, level):
    """The named columns of a level's file in the file's order, read from the file the tree was loaded from with the loader's own
    alignment (the names are the ones the rows carry), or None when the file is not there, cannot be opened or no longer reads as that
    level. Blank spacer cells are not named columns."""
    import io
    import os
    try:
        from . import loader as L
        r = con.execute("SELECT v FROM meta WHERE k = 'load_reports'").fetchone()
        path = ((json.loads(r[0]) if r and r[0] else {}).get(level) or {}).get("path")
        if not path or not os.path.isfile(path):
            return None
        fb = open(path, "rb")
        with io.TextIOWrapper(fb, encoding="utf-8-sig", errors="replace", newline="") as fh:
            header = next(L.read_csv(fh, path), None)
        if not header:
            return None
        al = L.align_header(level, header, L.prescan_values(path, L.ambiguous_columns(level, header)))
        return L.header_names(al) or None
    except Exception:           # noqa: BLE001 - a header that cannot be read is not a fault here: the caller says where the columns came from instead
        return None


def store_headers(db_path):
    """Write each level's header into the tree's own database (meta, HEADERS_KEY), once, so that every later reader (also a process that
    may open nothing but the tree) gets the file's header from columns(). Returns {level: number of named columns} of what is stored now.
    A level whose file cannot be read keeps what was stored before, or nothing."""
    from . import loader as L           # the loader writes the header at the load; the same two functions write it here for a tree loaded before 2026-11-15
    con = sqlite3.connect(db_path, timeout=60)
    try:
        con.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
        r = con.execute("SELECT v FROM meta WHERE k = ?", (HEADERS_KEY,)).fetchone()
        have = json.loads(r[0]) if r and r[0] else {}
        todo = [lv for lv, t in TABLE.items() if lv not in have and con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (t,)).fetchone()]
        for lv in todo:
            names = header_of_file(con, lv)
            first = con.execute("SELECT raw FROM %s ORDER BY rowid_file LIMIT 1" % TABLE[lv]).fetchone()
            keys = list(json.loads(first[0]).keys()) if first and first[0] else []
            if names and all(c in set(names) or SPACER.match(c) for c in keys):      # the file still is the one the tree was loaded from
                have[lv] = names
                L.store_header(con, lv, names)
        con.commit()
        return {lv: len(c) for lv, c in have.items()}
    finally:
        con.close()


class NotInTree(LookupError):
    """A relation the approved joins did not build: the code must not invent it."""


class Row(dict):
    """One row: its cells by the exact header of its file (row["OPC"]), plus .level, .row (its row in the file, counted under the header),
    .number (the analyzer's own number for it), .parent (level, row) or None, .relation (member, context or orphan), .time_ps, .ancestor."""
    __slots__ = ("level", "row", "number", "parent", "relation", "time_ps", "ancestor")

    def __repr__(self):
        return "<%s row %s of %s>" % (self.level, self.row, FILE.get(self.level))


def _row(level, r, cols):
    d = dict(zip(cols, r))
    raw = d.get("raw")
    out = Row(json.loads(raw) if isinstance(raw, str) and raw else {})
    out.level, out.row, out.number = level, d.get("rowid_file"), d.get("n")
    out.parent = (d.get("parent_level"), d.get("parent")) if d.get("parent") is not None else None
    out.relation, out.time_ps, out.ancestor = d.get("relation"), d.get("t_ps"), d.get("_anc")
    return out


def _paths(level, to):
    """Every way up from level to the level `to`, through the parent levels the joins build: [[level, ..., to]]."""
    if level == to:
        return [[level]]
    out = []
    for p in UP.get(level, ()):
        for rest in _paths(p, to):
            out.append([level] + rest)
    return out


class Tree:
    def __init__(self, db_path, meanings=None, immutable=False):
        """immutable=True reads the main database file only (no -wal or -shm): for a confined process that may only read, once the server has
        folded the write-ahead log into the file (procedures.run_code does)."""
        self.db = db_path
        self.con = sqlite3.connect("file:%s?mode=ro%s" % (db_path, "&immutable=1" if immutable else ""), uri=True, check_same_thread=False)
        self.con.execute("PRAGMA query_only=1")
        self.meanings = meanings or {}
        self.calls = collections.Counter()
        self.present = {lv for lv, t in TABLE.items() if self.con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (t,)).fetchone()}
        self._headers = {}          # level -> (the header's columns, where they were read from): read once for this Tree

    def close(self):
        self.con.close()

    def _need(self, level):
        if level not in TABLE:
            raise ValueError("no level %r: the levels are %s" % (level, ", ".join(LEVELS)))
        if level not in self.present:
            raise NotInTree("this recording has no %s (its file was not loaded)" % FILE[level])

    def _cols(self, t, alias="x"):
        return [r[1] for r in self.con.execute("PRAGMA table_info(%s)" % t)]

    # ---------------------------------------------------------------- reading
    def levels(self):
        """{level: number of rows} of the levels this recording has."""
        self.calls["levels"] += 1
        return {lv: self.con.execute("SELECT COUNT(*) FROM %s" % TABLE[lv]).fetchone()[0] for lv in LEVELS if lv in self.present}

    def columns(self, level):
        """The named columns of the level's file, in the file's order: the header, whether or not the first row (or any row) fills them.
        (Until 2026-11-15 this gave the cells filled in the first row only, so a column that row left empty looked missing.)
        Where the header comes from, first that answers: (1) the header stored with the tree (store_headers, written once after the tree is
        built); (2) the level's file itself, when it is still where it was loaded from and its first row agrees with the tree, read with the
        loader's own alignment; (3) when neither can be read (a process that may open only the tree), every column that some row of the level
        fills, in the order first seen: a column empty in every row is then not listed, and columns_from(level) says which of the three it was."""
        self.calls["columns"] += 1
        self._need(level)
        return list(self._header(level)[0])

    def columns_from(self, level):
        """Where columns(level) was read from, in words (for a card or a report)."""
        self._need(level)
        return self._header(level)[1]

    def _first_keys(self, level):
        r = self.con.execute("SELECT raw FROM %s ORDER BY rowid_file LIMIT 1" % TABLE[level]).fetchone()
        return list(json.loads(r[0]).keys()) if r and r[0] else []

    def _header(self, level):
        got = self._headers.get(level)
        if got is not None:
            return got
        first = self._first_keys(level)
        names, where = None, ""
        try:
            r = self.con.execute("SELECT v FROM meta WHERE k = ?", (HEADERS_KEY,)).fetchone()
            stored = (json.loads(r[0]) if r and r[0] else {}).get(level)
            if isinstance(stored, list) and stored:
                names, where = [str(c) for c in stored], "the header stored with the tree"
        except (sqlite3.Error, ValueError, AttributeError):
            pass
        if names is None:
            names = header_of_file(self.con, level)
            if names is not None and all(c in set(names) or SPACER.match(c) for c in first):
                where = "the header of %s, read from the file" % FILE[level]
            else:
                names = None
        if names is None:
            # no stored header and no file to read: what the rows themselves fill (the whole level is read once, by the database)
            names = [r[0] for r in self.con.execute("SELECT j.key FROM %s x, json_each(x.raw) j GROUP BY j.key ORDER BY MIN(x.rowid_file), MIN(j.id)" % TABLE[level])]
            where = "the columns that at least one row of %s fills (its header could not be read: a column empty in every row is not listed)" % FILE[level]
        names = list(dict.fromkeys(names + [c for c in first if c not in set(names)]))     # a value under a blank header cell ("column 23") stays listed
        self._headers[level] = (names, where)
        return self._headers[level]

    def column_state(self, level, column):
        """One of FILLED, EMPTY ("in the file, empty in every row") or MISSING ("not in the file") for a column of a level: a column that
        the header names and no row fills is in the file, not missing. The rows are read only until the first one that fills it."""
        self._need(level)
        column = str(column)
        key = json.dumps(column) + ":"
        hit = self.con.execute("SELECT 1 FROM %s WHERE instr(raw, ?) > 0 AND COALESCE(json_extract(raw, ?), '') != '' LIMIT 1" % TABLE[level],
                               (key, "$." + json.dumps(column))).fetchone()
        if hit:
            return FILLED
        return EMPTY if column in self._header(level)[0] else MISSING

    def rows(self, level, with_ancestor=None, include_context=True):
        """Every row of a level in file order. with_ancestor=<a higher level>: each row's .ancestor is the row (in that level's file) it belongs to
        through the approved parent links, or None when it belongs to none."""
        self.calls["rows"] += 1
        self._need(level)
        t = TABLE[level]
        where = "" if include_context else " WHERE (x.relation IS NULL OR x.relation != 'context')"
        if not with_ancestor:
            cur = self.con.execute("SELECT x.* FROM %s x%s ORDER BY x.rowid_file" % (t, where))
        else:
            self._need(with_ancestor)
            paths = _paths(level, with_ancestor)
            if not paths:
                raise NotInTree("a %s has no %s above it in the tree (the levels go: %s)" % (level, with_ancestor, " > ".join(LEVELS)))
            joins, ends = [], []
            for k, path in enumerate(paths):
                prev = "x"
                for i, lv in enumerate(path[1:], 1):
                    a = "p%d_%d" % (k, i)
                    joins.append("LEFT JOIN %s %s ON %s.parent_level = '%s' AND %s.rowid_file = %s.parent" % (TABLE[lv], a, prev, lv, a, prev))
                    prev = a
                ends.append("%s.rowid_file" % prev)
            cur = self.con.execute("SELECT x.*, COALESCE(%s) AS _anc FROM %s x %s%s ORDER BY x.rowid_file" % (", ".join(ends), t, " ".join(joins), where))
        cols = [c[0] for c in cur.description]
        while True:
            batch = cur.fetchmany(BATCH)
            if not batch:
                return
            for r in batch:
                yield _row(level, r, cols)

    def get(self, level, row):
        """One row by its row number in its file, or NotInTree."""
        self.calls["get"] += 1
        self._need(level)
        cur = self.con.execute("SELECT * FROM %s WHERE rowid_file = ?" % TABLE[level], (int(row),))
        r = cur.fetchone()
        if r is None:
            raise NotInTree("%s has no row %s" % (FILE[level], row))
        return _row(level, r, [c[0] for c in cur.description])

    def children(self, level, row, child_level=None, include_context=False):
        """The rows directly under one row (all child levels, or only child_level), in file order. Context rows (time-window attachments) are
        left out unless include_context=True."""
        self.calls["children"] += 1
        self._need(level)
        want = [child_level] if child_level else [c for c in CHILD[level] if c in self.present]
        if child_level and child_level not in CHILD[level]:
            raise NotInTree("a %s is never directly under a %s (the levels go: %s)" % (child_level, level, " > ".join(LEVELS)))
        out = []
        for cl in want:
            self._need(cl)
            q = "SELECT * FROM %s WHERE parent_level = ? AND parent = ?%s ORDER BY rowid_file" % (TABLE[cl], "" if include_context else " AND (relation IS NULL OR relation != 'context')")
            cur = self.con.execute(q, (level, int(row)))
            cols = [c[0] for c in cur.description]
            out += [_row(cl, r, cols) for r in cur.fetchall()]
        if include_context and level != "packets" and "packets" not in want and "packets" in self.present:
            cur = self.con.execute("SELECT * FROM pkt WHERE parent_level = ? AND parent = ? AND relation = 'context' ORDER BY rowid_file", (level, int(row)))
            cols = [c[0] for c in cur.description]
            out += [_row("packets", r, cols) for r in cur.fetchall()]       # link events and flow control attached to this unit by its time window
        return out

    def parent(self, level, row):
        """The row directly above, or None when the approved joins gave it no parent (outside any command, or unlinked)."""
        self.calls["parent"] += 1
        r = self.get(level, row)
        if not r.parent or r.parent[0] not in TABLE:
            return None
        return self.get(r.parent[0], r.parent[1])

    def ancestor(self, level, row, to_level):
        """The row at to_level that this row belongs to, or None (outside any such row)."""
        self.calls["ancestor"] += 1
        if LEVELS.index(to_level) >= LEVELS.index(level):
            raise NotInTree("%s is not above %s in the tree (the levels go: %s)" % (to_level, level, " > ".join(LEVELS)))
        r = self.get(level, row)
        while r is not None and r.level != to_level:
            r = self.parent(r.level, r.row) if r.parent else None
        return r

    def descendants(self, level, row, to_level, include_context=False):
        """Every row at to_level under one row (through all levels in between), in file order."""
        self.calls["descendants"] += 1
        if LEVELS.index(to_level) <= LEVELS.index(level):
            raise NotInTree("%s is not below %s in the tree (the levels go: %s)" % (to_level, level, " > ".join(LEVELS)))
        frontier, out = [self.get(level, row)], []
        while frontier:
            nxt = []
            for r in frontier:
                for c in self.children(r.level, r.row, include_context=include_context):
                    (out if c.level == to_level else nxt).append(c)
            frontier = [r for r in nxt if LEVELS.index(r.level) < LEVELS.index(to_level)]
        return sorted(out, key=lambda r: r.row)

    def unlinked(self, level):
        """The rows the approved joins left without a parent (and that are not context rows): they belong to no unit above."""
        self.calls["unlinked"] += 1
        self._need(level)
        cur = self.con.execute("SELECT * FROM %s WHERE parent IS NULL AND (relation IS NULL OR relation != 'context') ORDER BY rowid_file" % TABLE[level])
        cols = [c[0] for c in cur.description]
        for r in cur:
            yield _row(level, r, cols)

    def findings(self, rule=None, level=None):
        """The defects the detector's rules found: {id, level, rule, name, severity, row, command_row, time_ps}."""
        self.calls["findings"] += 1
        q, a = "SELECT id, level, rule, name, severity, rowid, cmd_rowid, t_ps FROM finding WHERE 1=1", []
        if rule:
            q, a = q + " AND rule = ?", a + [rule]
        if level:
            q, a = q + " AND level = ?", a + [level]
        for r in self.con.execute(q + " ORDER BY id", a):
            yield {"id": r[0], "level": r[1], "rule": r[2], "name": r[3], "severity": r[4], "row": r[5], "command_row": r[6], "time_ps": r[7]}

    def meaning(self, level, column):
        """Family 1's approved meaning of a column of a level's file, or '' when none is approved."""
        self.calls["meaning"] += 1
        return (self.meanings.get(level) or {}).get(column, "")


# the words the Rule writer and the Coder are given (one place, so the prompts and the code agree)
GUIDE = """THE TREE (built by Family 2 with the joining rules the admin approved; use it, never the raw CSV files):
  levels, top down: nvme_command (nvme_command.csv) > nvme_transaction (NVME_Transactions.csv) > split (split.csv) > link (link.csv) > packets (packets.csv)
  every row already knows its parent: a posted write's link row hangs directly under its NVMe transaction; flow-control and link-event packets are
  context rows of the unit whose time window holds them; rows the joins could not place have no parent (tree.unlinked(level) lists them).
  Never join two levels again by Tag, Address, CID, RequesterID or time: the tree already joined them by identity.
THE CALLS (tree is given to run(tree, out_csv)):
  tree.levels() -> {level: rows}            tree.columns(level) -> the file's header (every named column; a row leaves out the cells it has empty: use row.get(column))
  tree.rows(level, with_ancestor=None) -> rows in file order; with_ancestor="nvme_command" sets row.ancestor to the command's row (or None)
  tree.get(level, row)   tree.children(level, row, child_level=None)   tree.parent(level, row)
  tree.ancestor(level, row, to_level)   tree.descendants(level, row, to_level)   tree.unlinked(level)
  tree.findings(rule=None, level=None)      tree.meaning(level, column) -> Family 1's approved meaning
A row: row["OPC"] is the cell exactly as the export wrote it (text); row.level, row.row (its row in its file), row.number (the analyzer's own
number), row.parent (level, row) or None, row.relation (member, context, orphan), row.time_ps (its Time Stamp in picoseconds), row.ancestor.
A relation the tree does not have raises tree_api.NotInTree: report it, never guess."""
