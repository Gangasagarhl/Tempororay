"""The rows an admin's own rule found on the tree, filed as errors of the tree (owner, 2026-11-15: "whatever the input ... he must be able
to give the proper command level errors, and that has to be coded with the help of the coding fourth family agent ... after the error
analysis is done, that comes ... isolation of the defect").

Until today only the built-in detector filed findings; a rule of the rules library that Family 4 coded listed rows in a CSV file and the
flow stopped there (its rows were read as if they were the detector's output). This module is the bridge, and nothing more:

  * WHAT A RESULT MUST CARRY. The result CSV of such a rule must have a column named exactly ROW_COLUMN ("row number in the file"), holding
    for each found row its row number in the file of the item's level, as the tree gives it (row.row: the first row under the header is
    row 1). requirement_words(level) is the sentence the Rule writer and the Coder get; result_problem() checks the result's header;
    file_findings() checks every line (a whole number, 1 or more, a row the level has, no row twice) and refuses the whole result in one
    plain sentence otherwise: nothing is filed from a result that does not name its rows.
  * THE RULE KEY of such a finding:  admin.<section>.<level>.<item id>.v<procedure version>   (rule_key). One item, one procedure
    version, one key. item_of(rule) reads it back.
  * FILED ONCE. Running the same version again keeps the findings it already filed for the rows found again (their numbers stay, so the
    isolation, the cause and the test stored for them stay theirs), removes those no longer found and adds the new ones. Findings of an
    OLDER version of the same item are removed when a newer version is filed. remove() takes every finding of an item away (the item was
    deleted). A finding's number is never given to another error later (the last number used is kept in the tree's meta table).
  * THE NAME OF THE DEFECT comes from the fixed dictionary (nvme_hier/terms.py defect_term) without a model: the finding's detail carries
    "kind" = kind_words(item id), for example "matched the admin's rule 'aborted commands'", which the dictionary uses as the "what
    happened" part. It is made from the item's id (which never changes), not from its display name, so the defect's key stays the same.
  * THE COMMAND. A finding on the NVMe command level is its own command. A finding on a lower level is filed with the command it belongs
    to through the tree's parent links (never by a time stamp); a row that belongs to no command is filed without one, and CANNOT_DO says
    what the page of such an error can and cannot do.

  * WHOSE RULE IT IS (2026-11-15, the rule families of the NVMe command level). The words above are those of a rule the admin wrote. A rule
    of the application's own rule set (nvme_hier/command_error_rules.py, seeded into the rules library) is filed the same way, under the
    same key form, but its words say truthfully whose rule it is: file_findings(origin=...) takes the "what happened" words, the words
    after the rule's name and the sentence of where the rule comes from (agentic/family3.rule_origin decides it from stored facts of the
    item: its kind and who last changed its procedure). Without an origin the words are the admin's own rule's, as before.
  * WHAT EACH FOUND ROW SAYS. When the result has a column named "what was found" (the reason of that row in plain words) or "linked
    findings" (the sentence that names the rows that belong together, for example one episode of a timeout), the cell of each found row is
    kept in its finding's detail ("reason", "linked") and shown on the errors list, so the admin sees why the row was found and which
    errors belong together. A result without these columns is filed as before.

Streaming: the result is read line by line and the row numbers are kept in a temporary table of the database, not in Python's memory.
"""
import csv
import json
import re
import sqlite3

from . import names as N
from . import tree_api as T

ROW_COLUMN = "row number in the file"          # the same words as for a CSV file that is not part of the tree (agentic/other_errors.ROW_COLUMN)
RULE_PREFIX = "admin."
LAST_ID_KEY = "coded_findings_last_id"          # meta: the highest finding number this module ever gave in this tree
BATCH = 5000
REASON_COLUMN, LINKED_COLUMN = "what was found", "linked findings"      # optional columns of a result, kept with each found row
EXTRA_CHARS = 3000                              # of such a cell, at most (a sentence, not a document)
# the finding table as nvme_hier/rules.py creates it (a test keeps the two equal): made here only for a tree the detector never ran on
FINDING_DDL = """CREATE TABLE IF NOT EXISTS finding (id INTEGER PRIMARY KEY, level TEXT, rule TEXT, name TEXT, severity TEXT, cat_ref TEXT,
    table_name TEXT, rowid INTEGER, row_n INTEGER, t_ps INTEGER, value_ps INTEGER, limit_ps INTEGER, limit_source TEXT,
    detail TEXT, cmd_rowid INTEGER, part TEXT, cause_level TEXT, cause_rule TEXT, cause_finding INTEGER)"""
LEVEL_WORDS = {"nvme_command": "NVMe command", "nvme_transaction": "NVMe transaction", "split": "split transaction", "link": "link transaction", "packets": "packet"}
CANNOT_DO = ("This rule finds rows below the NVMe command level. Each found row is filed with the NVMe command it belongs to in the tree: the "
             "window of commands, the evidence card and the cause rules are computed from that command, not from the row itself. A row that "
             "belongs to no command is listed too, but its page has no command to build the window, the evidence card and the test from.")


class Refused(ValueError):
    """A result that cannot give errors: the message is one plain sentence for the admin."""


def rule_key(section, level, rid, version):
    """The rule key of the findings of one item at one procedure version: admin.<section>.<level>.<item id>.v<version>."""
    return "%s%s.%s.%s.v%d" % (RULE_PREFIX, section, level, rid, int(version or 0))


def _prefix(section, level, rid):
    return "%s%s.%s.%s.v" % (RULE_PREFIX, section, level, rid)


def is_coded(rule):
    return str(rule or "").startswith(RULE_PREFIX)


def item_of(rule):
    """'admin.errors.nvme_command.aborted_commands.v2' -> ('errors', 'nvme_command', 'aborted_commands', 2), or None for any other rule."""
    m = re.match(r"^admin\.([^.]+)\.(%s)\.(.+)\.v(\d+)$" % "|".join(T.LEVELS), str(rule or ""))
    return (m.group(1), m.group(2), m.group(3), int(m.group(4))) if m else None


def kind_words(rid):
    """The "what happened" part of the defect's name for a rule of the admin's own: stated, stable (made from the item's id)."""
    return "matched the admin's rule '%s'" % str(rid or "").replace("_", " ").strip()


def kind_sentence(rid, name=None):
    """Said on the cards: where that part of the defect's name comes from."""
    return ("In the name the fixed dictionary gives such a defect, the part \"%s\" comes from your own rule%s; the command, its "
            "status and the rest of the name come from the recording, as for the detector's errors. No model names it."
            % (kind_words(rid), (" *%s*" % name) if name else ""))


def admins_origin(rid, name, version):
    """What is said of a finding that a rule of the admin's own filed (the origin when file_findings is given none)."""
    return {"is": "admin", "kind": kind_words(rid), "found_by": "found by the admin's own rule", "kind_comes_from": "the admin's rule",
            "words": "Found by the admin's own rule '%s' (version %d of its procedure, coded by Family 4)." % (name, int(version or 0)),
            "sentence": kind_sentence(rid, name), "short": "your own rule \u201c%s\u201d" % name}


def requirement_words(level):
    """The requirement the Coder's code must meet, in words (given to the Rule writer and the Coder, shown with a refusal)."""
    f = T.FILE.get(level, "the level's file")
    return ("the result must say which rows of %s it found: a column named exactly \"%s\" holding the row's number in that file as the tree "
            "gives it (row.row of a row of the level %s: the first row under the header is row 1), a whole number written in digits only, one "
            "result line per found row and no row twice" % (f, ROW_COLUMN, level))


def result_problem(columns, level, rule=""):
    """Why a result cannot give errors, in plain words, or "": checked on the result's header alone (file_findings checks the lines)."""
    cols = [str(c) for c in columns or []]
    name = ("'%s'" % rule) if rule else "this rule"
    if level not in T.TABLE:
        return "The result of %s is not on a level of the tree, so its rows cannot be filed as errors of the tree." % name
    if ROW_COLUMN not in cols:
        return ("The result of %s does not say which rows of %s it found: it has no column named \"%s\". No error is listed for it. "
                "Change the rule so that %s; then code it and run it again." % (name, T.FILE[level], ROW_COLUMN, requirement_words(level)))
    if cols.count(ROW_COLUMN) > 1:
        return "The result of %s has more than one column named \"%s\", so the row of a found line is not certain. No error is listed for it." % (name, ROW_COLUMN)
    return ""


def _is_item(prefix):
    """SQL (and its values) that is true for a rule key of one item, at any version: the prefix, then digits only."""
    return "(substr(rule, 1, ?) = ? AND substr(rule, ?) != '' AND substr(rule, ?) NOT GLOB '*[^0-9]*')", [len(prefix), prefix, len(prefix) + 1, len(prefix) + 1]


def _chain(con, level, rowid):
    """(the row of the command this row belongs to or None, the part of the command) through the tree's parent links."""
    part = "none"
    for _ in range(6):
        if level == "nvme_command":
            return rowid, part
        t = T.TABLE.get(level)
        if not t:
            return None, part
        if level == "nvme_transaction":
            r = con.execute("SELECT 'nvme_command', parent, type FROM ntx WHERE rowid_file = ?", (rowid,)).fetchone()
            if r:
                part = N.part_key(r[2])
        else:
            r = con.execute("SELECT parent_level, parent FROM %s WHERE rowid_file = ?" % t, (rowid,)).fetchone()
        if not r or r[1] is None or r[0] not in T.TABLE:
            return None, part
        level, rowid = r[0], r[1]
    return None, part


def _tables(con):
    return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def _open(db):
    con = sqlite3.connect(db, timeout=60)
    con.execute("PRAGMA temp_store=FILE")
    return con


def _recount(con, level, rows_sql):
    """The per-row count of error findings (the pages read it) for the rows this call touched."""
    t = T.TABLE[level]
    if "n_findings" not in [r[1] for r in con.execute("PRAGMA table_info(%s)" % t)]:
        return
    con.execute("UPDATE %s SET n_findings = NULLIF((SELECT COUNT(*) FROM finding f WHERE f.level = ? AND f.rowid = %s.rowid_file AND f.severity = 'error'), 0) "
                "WHERE rowid_file IN (%s)" % (t, t, rows_sql), (level,))


def file_findings(db, section, level, rid, version, name, out_csv, approved_by="", progress=None, origin=None):
    """File the rows of one result as findings of the tree `db` under rule_key(section, level, rid, version); see the module's words.
    -> {"rule", "total", "kept", "added", "removed", "without_a_command"}. Raises Refused (nothing is changed) for a result that does
    not name its rows. origin: whose rule it is, in words (admins_origin() when None; family3.rule_origin for a rule of the application's set)."""
    who = "'%s'" % name
    origin = dict(admins_origin(rid, name, version), **(origin or {}))
    if level not in T.TABLE:
        raise Refused("The rule %s is not on a level of the tree, so its rows cannot be filed as errors of the tree." % who)
    f, t = T.FILE[level], T.TABLE[level]
    key, prefix = rule_key(section, level, rid, version), _prefix(section, level, rid)
    con = _open(db)
    try:
        if t not in _tables(con):
            raise Refused("The tree of this recording has no %s (that file was not loaded), so the rows the rule %s found cannot be filed. No error is listed for it." % (f, who))
        con.execute(FINDING_DDL)
        con.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
        con.execute("DROP TABLE IF EXISTS temp.cf_found")
        con.execute("CREATE TEMP TABLE cf_found (row INTEGER PRIMARY KEY, reason TEXT, linked TEXT)")
        try:
            fh = open(out_csv, newline="", encoding="utf-8")
        except OSError:
            raise Refused("The result file of the rule %s is not there any more, so its rows cannot be read. No error is listed for it: run the rule again." % who) from None
        with fh:
            rd = csv.reader(fh)
            cols = next(rd, [])
            lacks = result_problem(cols, level, name)
            if lacks:
                raise Refused(lacks)
            ir, k = cols.index(ROW_COLUMN), 0
            i_reason = cols.index(REASON_COLUMN) if cols.count(REASON_COLUMN) == 1 else None
            i_linked = cols.index(LINKED_COLUMN) if cols.count(LINKED_COLUMN) == 1 else None
            extra = lambda line, i: (" ".join(line[i].split())[:EXTRA_CHARS] or None) if i is not None and i < len(line) else None      # noqa: E731
            for line in rd:
                k += 1
                cell = (line[ir] if ir < len(line) else "").strip()
                if not re.fullmatch(r"[0-9]{1,18}", cell) or int(cell) < 1:
                    raise Refused("Line %s of the result of the rule %s does not name a row of %s: its \"%s\" is %s, and it must be a whole number, 1 or more, "
                                  "written in digits only. No error is listed for this rule." % ("{:,}".format(k), who, f, ROW_COLUMN, ("\"%s\"" % cell[:40]) if cell else "empty"))
                try:
                    con.execute("INSERT INTO cf_found (row, reason, linked) VALUES (?, ?, ?)", (int(cell), extra(line, i_reason), extra(line, i_linked)))
                except sqlite3.IntegrityError:
                    raise Refused("The result of the rule %s names row %s of %s twice (the second time on its line %s): one line per found row is needed, so that "
                                  "one error is not listed twice. No error is listed for this rule." % (who, "{:,}".format(int(cell)), f, "{:,}".format(k))) from None
                if progress and k % 50000 == 0:
                    progress("%s result lines read" % "{:,}".format(k))
        bad = con.execute("SELECT c.row FROM cf_found c LEFT JOIN %s x ON x.rowid_file = c.row WHERE x.rowid_file IS NULL ORDER BY c.row LIMIT 1" % t).fetchone()
        if bad:
            n_rows = con.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
            raise Refused("The result of the rule %s names row %s of %s, and the tree has no such row (%s has %s row%s). No error is listed for this rule."
                          % (who, "{:,}".format(bad[0]), f, f, "{:,}".format(n_rows), "" if n_rows == 1 else "s"))
        total = con.execute("SELECT COUNT(*) FROM cf_found").fetchone()[0]
        # ---- from here on the tree is changed, in one transaction
        is_item, a = _is_item(prefix)
        con.execute("DROP TABLE IF EXISTS temp.cf_touched")
        con.execute("CREATE TEMP TABLE cf_touched (row INTEGER PRIMARY KEY)")
        con.execute("INSERT OR IGNORE INTO cf_touched SELECT rowid FROM finding WHERE level = ? AND %s AND (rule != ? OR rowid NOT IN (SELECT row FROM cf_found))" % is_item, [level] + a + [key])
        removed = con.execute("DELETE FROM finding WHERE %s AND (rule != ? OR level != ? OR rowid NOT IN (SELECT row FROM cf_found))" % is_item, a + [key, level]).rowcount
        kept = con.execute("SELECT COUNT(*) FROM finding WHERE rule = ?", (key,)).fetchone()[0]
        words = "%s (%s)" % (name, origin["found_by"])
        # the field keeps its name "admin_rule" (the page of one error reads its "words"); "origin" says whose rule it is: "admin", or what
        # family3.rule_origin states for a rule of the application's own rule set
        fixed = {"kind": origin["kind"], "admin_rule": {"item": "%s/%s/%s" % (section, level, rid), "procedure_version": int(version or 0), "name": name,
                                                        "approved_by": approved_by or "", "kind_comes_from": origin["kind_comes_from"],
                                                        "origin": origin["is"], "words": origin["words"]}}
        if origin["is"] != "admin":         # a rule of the application's rule set: where the name's part comes from, and how a page names the rule in a few words
            fixed["admin_rule"].update(kind_from=str(origin.get("sentence") or "").replace("*", ""), short=origin.get("short") or "")

        def detail_of(reason, linked):
            d = dict(fixed)
            if reason:
                d["reason"] = reason
            if linked:
                d["linked"] = linked
            return json.dumps(d)
        detail = detail_of(None, None)
        con.execute("UPDATE finding SET name = ?, detail = ? WHERE rule = ?", (words, detail, key))
        if i_reason is not None or i_linked is not None:        # the findings kept from an earlier run take what this run says of their rows
            after = 0
            while True:
                part = con.execute("SELECT f.id, c.reason, c.linked FROM finding f JOIN cf_found c ON c.row = f.rowid WHERE f.rule = ? AND f.id > ? "
                                   "AND (c.reason IS NOT NULL OR c.linked IS NOT NULL) ORDER BY f.id LIMIT ?", (key, after, BATCH)).fetchall()
                if not part:
                    break
                con.executemany("UPDATE finding SET detail = ? WHERE id = ?", [(detail_of(rs, ln), fid) for fid, rs, ln in part])
                after = part[-1][0]
        last = (json.loads((con.execute("SELECT v FROM meta WHERE k = ?", (LAST_ID_KEY,)).fetchone() or ["0"])[0]) or 0)
        nxt = max(int(last), con.execute("SELECT COALESCE(MAX(id), 0) FROM finding").fetchone()[0])
        cur = con.cursor()
        cur.execute("SELECT c.row, x.n, x.t_ps, c.reason, c.linked FROM cf_found c JOIN %s x ON x.rowid_file = c.row WHERE c.row NOT IN (SELECT rowid FROM finding WHERE rule = ?) ORDER BY c.row" % t, (key,))
        added = no_cmd = 0
        while True:
            batch = cur.fetchmany(BATCH)
            if not batch:
                break
            rows = []
            for row, n, t_ps, reason, linked in batch:
                nxt += 1
                cmd, part = _chain(con, level, row)
                no_cmd += cmd is None
                rows.append((nxt, level, key, words, "error", None, t, row, n, t_ps, None, None, None, detail_of(reason, linked) if (reason or linked) else detail, cmd, part))
            con.executemany("INSERT INTO finding (id, level, rule, name, severity, cat_ref, table_name, rowid, row_n, t_ps, value_ps, limit_ps, limit_source, detail, "
                            "cmd_rowid, part) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            added += len(rows)
            if progress:
                progress("%s of %s errors filed" % ("{:,}".format(kept + added), "{:,}".format(total)))
        if added:               # a number was given: remembered, so that it is never given again. A result that adds nothing writes nothing here
            con.execute("INSERT OR REPLACE INTO meta (k, v) VALUES (?, ?)", (LAST_ID_KEY, json.dumps(nxt)))
        con.execute("INSERT OR IGNORE INTO cf_touched SELECT row FROM cf_found")
        _recount(con, level, "SELECT row FROM cf_touched")
        con.commit()
        return {"rule": key, "total": total, "kept": kept, "added": added, "removed": removed, "without_a_command": no_cmd}
    except Refused:
        con.rollback()
        raise
    finally:
        con.close()


def remove(db, section, level, rid):
    """Take every finding of one item (all its versions) out of the tree: the item was deleted. -> how many were removed."""
    con = _open(db)
    try:
        if "finding" not in _tables(con):
            return 0
        is_item, a = _is_item(_prefix(section, level, rid))
        con.execute("DROP TABLE IF EXISTS temp.cf_touched")
        con.execute("CREATE TEMP TABLE cf_touched (row INTEGER PRIMARY KEY)")
        con.execute("INSERT OR IGNORE INTO cf_touched SELECT rowid FROM finding WHERE level = ? AND %s" % is_item, [level] + a)
        n = con.execute("DELETE FROM finding WHERE %s" % is_item, a).rowcount
        if n and level in T.TABLE and T.TABLE[level] in _tables(con):
            _recount(con, level, "SELECT row FROM cf_touched")
        con.commit()
        return n
    finally:
        con.close()


def filed_items(db):
    """[(section, level, item id, version, number of findings)] of the admins' rules that have findings in this tree."""
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        if "finding" not in _tables(con):
            return []
        out = []
        for rule, n in con.execute("SELECT rule, COUNT(*) FROM finding WHERE substr(rule, 1, ?) = ? GROUP BY rule ORDER BY rule", (len(RULE_PREFIX), RULE_PREFIX)):
            it = item_of(rule)
            if it:
                out.append(it + (n,))
        return out
    finally:
        con.close()


def listed(db, rule, limit=200):
    """(the first `limit` findings of one rule key in the detector's result shape, the number of all of them): each line is
    [finding, level, rule, what was found, severity, number in its file, time stamp (ps), command's file row, data row in its file]."""
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        if "finding" not in _tables(con):
            return [], 0
        total = con.execute("SELECT COUNT(*) FROM finding WHERE rule = ?", (rule,)).fetchone()[0]
        rows = [list(r) for r in con.execute("SELECT id, level, rule, name, severity, row_n, t_ps, cmd_rowid, rowid FROM finding WHERE rule = ? ORDER BY rowid LIMIT ?", (rule, int(limit)))]
        return rows, total
    finally:
        con.close()


def facts_of(db, ids):
    """{finding number: its detail as a dict} for some findings of the tree (the reason and the linked findings of a found row are in it)."""
    ids = [int(i) for i in ids][:2000]
    if not ids:
        return {}
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        out = {}
        for fid, detail in con.execute("SELECT id, detail FROM finding WHERE id IN (%s)" % ",".join("?" * len(ids)), ids):
            try:
                out[fid] = json.loads(detail) if detail else {}
            except ValueError:
                out[fid] = {}
        return out
    finally:
        con.close()


def rule_of(db, finding):
    """The rule key of one finding of the tree, or None."""
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        if "finding" not in _tables(con):
            return None
        r = con.execute("SELECT rule FROM finding WHERE id = ?", (int(finding),)).fetchone()
        return r[0] if r else None
    finally:
        con.close()
