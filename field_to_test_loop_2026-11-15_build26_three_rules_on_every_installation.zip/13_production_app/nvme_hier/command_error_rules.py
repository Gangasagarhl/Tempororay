"""The rule families of the NVMe command level, as DATA an admin can read, choose and extend, and one implementation that runs them
(owner, 2026-11-15: "figure out what are the NVMe command level errors that are possible, and try to write the rules ... if this kind of
problem is there, then this is the pattern").

Where every family comes from: the four research notes in research_notes/"NVMe command level error rules"/ (R1 the statuses a controller
returns, R2 the faults that are not a status, R4 the protocol checks of test suites, R3 what the application already has). Nothing here
is invented: a family, a status value or a place in a document is the note's. Where a note marks a section number as reconstructed or not
verified, the mark is carried ("section to be confirmed"). Where the notes disagree, the family says so and accepts the set of values.

What this module holds:
  FAMILIES        every family: name, group, what / why / how (each sentence with its source), the columns it reads and at which level,
                  what it needs that an export may lack and the sentence it then says, its exceptions, whose fault it points to, the
                  families it belongs with, the host's expected reaction, and "check": the pattern as data for find()
  find()          ONE data-driven implementation: given a family and an opened tree (nvme_hier/tree_api.Tree) it yields the rows it finds,
                  each with the reason in plain words and the values that matched. It streams (tree.rows), reads both spellings of the
                  status columns (ST.SCT / ST.SC in the samples, bare SCT / SC in the real export), and reads "do not retry", "more" and
                  the retry delay from the completion row under the command. It never guesses: a family that cannot be checked on a
                  recording says "cannot be checked on this recording: ..." and why.
  run_on_tree()   the same as the code of a library item (run(tree, out_csv)); code_for() is that code's text; result_checks() is what
                  the Tester checks: the rows of a result against the reference implementation, and against a second count made another
                  way (SQL on the loader's typed columns) where there is one.
  items()         one library item per checkable family (agentic/family3.py seed() writes them; never chosen by default). The owner kept
                  only the top 3 NVMe command errors (2026-11-15): a new installation has "The command was aborted because the host asked"
                  as a live item and starts every other family in Deleted items, from where Restore brings it back.
  NOT_SEEDED      the families that are listed and not offered as items, each with the reason.

Only the NVMe command level: a command row, and under it its own completion row at the NVMe transaction level for the bits. Rows are
related by identity (queue and command identifier; opcode, namespace and block range for a retry); time only orders rows and measures.
"""
import csv
import json
import os

from . import names as N
from . import nvme_command_errors as NE
from . import rules as RL

ROW_COLUMN = "row number in the file"          # the same name agentic/other_errors.ROW_COLUMN uses for a found row (a test compares the two)
CMD_FILE_NAME = "nvme_command.csv"
STATUS, BEHAVIOUR, PROTOCOL = "Status the drive returned", "Behaviour over time", "Rules of the protocol"
GROUP_MEANINGS = [
    (STATUS, "The drive answered the command with a status that is not Successful Completion. The pattern is the queue kind, the command, the "
             "status code type and the status code of the command's row."),
    (BEHAVIOUR, "The fault is not a status: a command that never completed or completed late, the host's Abort, the reset that follows, a command "
                "slower than usual, a retry. The pattern is a relation between rows, by identity; time only orders rows and measures."),
    (PROTOCOL, "A rule of the NVMe protocol that the host or the controller broke, as the conformance tests check it."),
]
# What choosing one of these rules costs, said where they are chosen (the rules library shows a group's meaning when the group is open). The counts
# are the flow's own: STEPS_PER_RULE from agentic/pipeline.item_steps for an item of a section that finds defects; the calls and the cards were
# measured with the stand-in on sample S17 on 15 November 2026 (tests/test_command_rules_flow.py checks them again on every run).
STEPS_PER_RULE, CARDS_WITHOUT_A_MODEL, CARDS_WITH_A_MODEL, CALLS_WITH_A_MODEL = 8, 1, 3, 10
COST_WORDS = ("What choosing a rule of this group costs: each chosen rule adds %d steps to page 3 (data research, requirements, code, run on the tree, "
              "Tester, export, result, errors). With no model connected the first three are skipped: the rule runs the application's reference "
              "implementation, no model is called, and you decide %d card (the result). With a model connected, Family 4 writes the rule's code from "
              "its stored procedure: that is at least %d calls to the model for each rule (counted with the stand-in on the sample recording S17, "
              "which has five files, on 15 November 2026: 1 or 2 for the data research, 1 for the requirements, 5 to ask Family 1's Manager of each "
              "file, and 3 for one round of code: the Coder, a second program, the Tester; a real model needs more when a round fails) and "
              "%d cards for you to decide (the requirements, the code, the result); on its requirements card a real model can also ask you what "
              "the rule's text leaves open, for example what to do with an empty cell. The Tester then compares the rows the code finds with the "
              "reference implementation on the whole recording." % (STEPS_PER_RULE, CARDS_WITHOUT_A_MODEL, CALLS_WITH_A_MODEL, CARDS_WITH_A_MODEL))
GROUPS = [(name, meaning + " " + COST_WORDS) for name, meaning in GROUP_MEANINGS]
NOT_CHECKABLE = "not checkable from the NVMe command export"
ITEM_PREFIX = "cmd_family_"
KIND = "command_error"                        # the kind of the library items (agentic/procedures.py APPLICATION_KINDS)
THIS_FILE = "nvme_hier/command_error_rules.py"
SHOWN = 12                                    # rows named in one sentence at most
KEPT_MOST = 50000                             # entries of a look-up table kept in memory at most (bounded memory on a 6 GB recording)
STREAM_COUNT_MOST = 10000                     # the page counts the families that need a pass of their own up to this many commands

# ---- the documents, named as the research notes name them
B23 = "NVM Express Base Specification, Revision 2.3"
N12 = "NVM Express NVM Command Set Specification, Revision 1.2"
B21 = "NVM Express Base Specification, Revision 2.1"
N11 = "NVM Express NVM Command Set Specification, Revision 1.1"
B20 = "NVM Express Base Specification, Revision 2.0e"
TBC = " (section to be confirmed: the research note read it by text extraction)"
L_PCI = "Linux kernel v6.17, drivers/nvme/host/pci.c"
L_CORE = "Linux kernel v6.17, drivers/nvme/host/core.c"
L_CORE_M = "Linux kernel, master branch read on 2026-11-15, drivers/nvme/host/core.c"
L_NVME = "Linux kernel v6.17, drivers/nvme/host/nvme.h"
FAST16 = "Schroeder, Lagisetty, Merchant, Flash Reliability in Production, USENIX FAST 2016"
FAST13 = "Zheng, Tucek, Qin, Lillibridge, Understanding the Robustness of SSDs under Power Fault, USENIX FAST 2013"
ATC22 = "Lu et al., NVMe SSD Failures in the Field: the Fail-Stop and the Fail-Slow, USENIX ATC 2022"
FAST18 = "Gunawi et al., Fail-Slow at Scale, USENIX FAST 2018"
UNH15 = "UNH-IOL Test Plan for NVMe Conformance, Version 15.0"
UNH26 = "UNH-IOL Test Plan for NVM Command Set Conformance, Version 26.0"
QEMU = "QEMU hw/nvme/ctrl.c, master branch (to be confirmed at a fixed commit, as the research note says)"
R1N, R2N, R4N = "research note R1, section 7 (the researcher's grouping)", "research note R2, section 9 (the researcher's proposal)", "research note R4, section 6 (the researcher's proposal)"
FIG100 = B23 + ", Figure 100 (status field)"
DISPOSITION = L_CORE_M + ", function nvme_decide_disposition (lines 408 to 431)"
ERR_STATUS = L_CORE_M + ", function nvme_error_status (lines 286 to 325)"
NVME_TIMEOUT = L_PCI + ", function nvme_timeout (lines 1586 to 1725)"
REACT_DNR = [("The Linux driver completes the command with the error when 'do not retry' is 1 or the retry count reached 5; otherwise it sends the same command again.", DISPOSITION)]

# ---- the columns, by the names in the samples and in the real export, with their meaning (no column without its meaning)
C_OPC = {"level": "nvme_command", "names": ["OPC"], "meaning": "the command code: which command it is (Read, Write, Abort and so on)"}
C_SQID = {"level": "nvme_command", "names": ["SQID"], "meaning": "the submission queue the command was sent on: queue 0 carries the admin commands, every other queue the I/O commands"}
C_CID = {"level": "nvme_command", "names": ["CID"], "meaning": "the command identifier the host gave the command; with the queue it names the command while it is open"}
C_SCT = {"level": "nvme_command", "names": ["ST.SCT", "SCT"], "meaning": "the status code type of the completion: which family of result (written ST.SCT in the samples, bare SCT after ST in the real export)"}
C_SC = {"level": "nvme_command", "names": ["ST.SC", "SC"], "meaning": "the status code of the completion: which result inside that type (written ST.SC in the samples, bare SC in the real export)"}
C_NSID = {"level": "nvme_command", "names": ["NSID"], "meaning": "the namespace the command addresses"}
C_SLBA = {"level": "nvme_command", "names": ["SLBA"], "meaning": "the first block the command addresses"}
C_NLB = {"level": "nvme_command", "names": ["NLB"], "meaning": "the number of blocks, counted from 0 (the command covers NLB + 1 blocks)"}
C_TIME = {"level": "nvme_command", "names": ["Time Stamp"], "meaning": "when the command was sent, from the start of the recording; it orders the rows and measures, it never joins them"}
C_FID = {"level": "nvme_command", "names": ["FID"], "meaning": "the feature a Set Features command sets (07h is the Number of Queues)"}
C_NSZE = {"level": "nvme_command", "names": ["NSZE"], "meaning": "the size of the namespace in blocks, on the row of the Identify command that returned it",
          "in_source_data": False}       # many recordings carry no value in it: the Tester asks Family 1 for every column of the source data, so it is named in a step instead
C_PRP1 = {"level": "nvme_command", "names": ["PRP1"], "meaning": "the first data pointer of the command (a memory address)"}
C_TYPE = {"level": "nvme_transaction", "names": ["Type"], "meaning": "which step of the command the NVMe transaction is; the completion row is the Admin or I/O Completion Queue Entry"}
C_DNR = {"level": "nvme_transaction", "names": ["DNR"], "meaning": "'do not retry' of the completion row under the command: 1 means the same command is expected to fail again"}
C_M = {"level": "nvme_transaction", "names": ["M"], "meaning": "'more' of the completion row: 1 means the drive kept more about this error in its Error Information log"}
C_CRD = {"level": "nvme_transaction", "names": ["CRD"], "meaning": "the command retry delay of the completion row: which of the drive's three delay values the host should wait before a retry"}
C_DW0 = {"level": "nvme_transaction", "names": ["DW0"], "meaning": "the first four bytes of the completion row; for an Abort, bit 0 set to 1 means the command was not aborted at once"}
C_NTIME = {"level": "nvme_transaction", "names": ["Time Stamp"], "meaning": "when the completion row was written; it measures the command's time"}
STATUS_COLS = [C_OPC, C_SQID, C_SCT, C_SC]
BITS_COLS = [C_TYPE, C_DNR, C_M, C_CRD]
NO_BITS = ("cannot be checked on this recording: 'do not retry', 'more' and the retry delay are only on the completion row of the NVMe transaction level, "
           "and %s")
NEED_STATUS = {"what": "the status columns of the NVMe command file (ST.SCT and ST.SC; SCT and SC in the real export)",
               "says": "cannot be checked on this recording: no row of the NVMe command file carries a value in the status columns (ST.SCT and ST.SC, written SCT and SC in the real export)"}
NEED_NTX = {"what": "the NVMe transactions file, loaded and joined to the commands in the tree (the completion row is read under each command)",
            "says": NO_BITS % "the NVMe transactions file is not loaded for this recording"}
NEED_BITS = {"what": "the columns DNR, M and CRD on the completion rows of the NVMe transactions file",
             "says": NO_BITS % "the export has no column DNR on the completion rows of the NVMe transactions file"}
NEED_DETECTOR = {"what": "the detector's rules, run when the recording was loaded (nvme_hier/rules.py)",
                 "says": "cannot be checked on this recording: the detector's rules have not run on it (load the recording again)"}

# ---- statuses that are not failures (R1 section 7, cross-cutting checks; the catalogue's kind 'status' and 'success')
EXCEPTIONS = [
    {"queue": "any", "sct": 0, "sc": 0x00, "name": "Successful Completion", "why": "the command completed without error", "source": B23 + ", Figure 102"},
    {"queue": "admin", "sct": 1, "sc": 0x0B, "name": "Firmware Activation Requires Conventional Reset", "why": "the firmware was accepted; a reset is needed to activate it: accepted, not failed",
     "source": B23 + ", Figure 103; " + R1N},
    {"queue": "admin", "sct": 1, "sc": 0x10, "name": "Firmware Activation Requires NVM Subsystem Reset", "why": "the firmware was accepted; a reset is needed to activate it: accepted, not failed",
     "source": B23 + ", Figure 103; " + R1N},
    {"queue": "admin", "sct": 1, "sc": 0x11, "name": "Firmware Activation Requires Controller Level Reset", "why": "the firmware was accepted; a reset is needed to activate it: accepted, not failed",
     "source": B23 + ", Figure 103; " + R1N},
    {"queue": "io", "sct": 1, "sc": 0x9C, "name": "Successful Media Verification Read", "why": "named by the specification as a success-like outcome inside the command specific type",
     "source": B23 + ", Figure 104; " + R1N},
]
STAYS_OPEN = "The Asynchronous Event Request (admin command 0Ch) is meant to stay open until an event occurs: it is never judged for time."
STAYS_OPEN_SRC = L_PCI + ", lines 1287 to 1297 (\"AEN requests are special as they don't time out\")"
LONG_BY_NATURE = "Format NVM, Sanitize, Device Self-test, Firmware Commit and Firmware Image Download are long by nature and are never judged for time (the detector's list, nvme_hier/rules.py LONG_BY_NATURE)."


def _is_exception(admin, sct, sc):
    for e in EXCEPTIONS:
        if (e["sct"], e["sc"]) == (sct, sc) and (e["queue"] == "any" or (e["queue"] == "admin") == bool(admin)):
            return e
    return None


FAMILIES = []


def _fam(fid, group, name, what, why, how, check, fault, columns, needs=(), exceptions=(), belongs=(), reaction=(), detector=(), differs=(), from_notes=()):
    FAMILIES.append({"id": fid, "group": group, "name": name, "what": what, "why": list(why), "how": list(how), "check": check, "fault": fault,
                     "columns": list(columns), "needs": list(needs), "exceptions": list(exceptions), "belongs_with": list(belongs),
                     "reaction": list(reaction), "detector_rules": list(detector), "differs": list(differs), "from_notes": list(from_notes),
                     "checkable": check.get("kind") != "none"})


def _st(n, name, what, why, match, fault, src, reaction=REACT_DNR, belongs=(), exceptions=(), differs=(), detector=("cmd.status_error",), check_kind="status", extra_how=()):
    """One family of group 'Status the drive returned'. match: [(queue kind, status code type, [status codes], [command names] or None)]."""
    fid = "status_%02d" % n
    _fam(fid, STATUS, name, what, why,
         [("%s" % _pattern_words(match), src)] + list(extra_how) +
         [("The bits are read from the completion row under the command and are given with every found row: 'do not retry', 'more' and the retry delay.", FIG100)],
         {"kind": check_kind, "match": match, **({"role": "aborted"} if check_kind == "chain" else {})}, fault, STATUS_COLS + BITS_COLS,
         needs=[NEED_STATUS, dict(NEED_NTX, optional=True, says="the bits are not given on this recording: " + NEED_NTX["says"].split(": ", 1)[1])],
         exceptions=[("A status that is not a failure is never flagged: %s." % "; ".join("%s (%Xh/%02Xh)" % (e["name"], e["sct"], e["sc"]) for e in EXCEPTIONS), R1N)] + list(exceptions),
         belongs=belongs, reaction=reaction, detector=detector, differs=differs, from_notes=["R1 family %d" % n])
    return fid


def _status_name(sct, sc):
    e = NE.lookup(sct, sc)
    return (e or {}).get("name") or "a value the application's catalogue does not name"


QUEUE_WORDS = {"any": "any queue", "io": "an I/O queue (SQID not 0)", "admin": "the admin queue (SQID 0)"}


def _pattern_words(match):
    parts = []
    for q, sct, codes, ops in match:
        parts.append("a command on %s%s whose status code type is %Xh and whose status code is %s" % (
            QUEUE_WORDS[q], (" that is %s" % " or ".join(ops)) if ops else "", sct,
            " or ".join("%02Xh (%s)" % (c, _status_name(sct, c)) for c in codes)))
    return "The pattern in the columns: " + "; or ".join(parts) + "."


D23 = "defined in Base 2.3; the application's catalogue (/nvme-errors) was read from Base 2.1, where this value is reserved"
READS = ("Read", "Compare", "Verify", "Copy")
_st(1, "A read could not be recovered",
    "The drive could not return the stored data, even after its own recovery.",
    [("The specification: \"The read data could not be recovered from the media.\"", B23 + ", Figure 106; " + N12 + ", Figure 19"),
     ("It is the most common failure a user sees on flash drives: final read errors are about two orders of magnitude more frequent than any other error the drive cannot hide.", FAST16 + ", section 3.1"),
     ("The host can make such blocks itself: after a Write Uncorrectable command, a read of those blocks returns this status until they are written again.", N12 + ", Write Uncorrectable command")],
    [("any", 2, [0x81], None)], "the controller (the drive's media), unless an earlier Write Uncorrectable on the same blocks is in the recording (then the host made the error)",
    R1N + "; values: " + B23 + ", Figure 106",
    reaction=REACT_DNR + [("The Linux driver reports it to the block layer as a medium error.", ERR_STATUS)], detector=("cmd.read_failure", "cmd.status_error"))
_st(2, "A write could not be committed",
    "The drive could not place the written data on its media.",
    [("The specification: \"The write data could not be committed to the media.\"", B23 + ", Figure 106"),
     ("It is rare in the field, because a drive retries a failed write at another location; when it shows, the drive is suspect.", FAST16 + ", section 3.1")],
    [("any", 2, [0x80], None)], "the controller (the drive)", R1N + "; values: " + B23 + ", Figure 106",
    reaction=REACT_DNR + [("The Linux driver reports it to the block layer as a medium error.", ERR_STATUS)])
_st(3, "An end-to-end protection check failed",
    "The guard, the application tag, the reference tag or the storage tag of the protection information did not match.",
    [("The specification: the command was aborted due to an end-to-end guard, application tag, reference tag or storage tag check failure.", B23 + ", Figure 106")],
    [("any", 2, [0x82, 0x83, 0x84, 0x88], None)], "it cannot be told from this rule alone: either side can have produced the wrong tag", R1N + "; values: " + B23 + ", Figure 106",
    reaction=[("The Linux driver reports guard, application tag and reference tag errors to the block layer as a protection error.", ERR_STATUS)])
_st(4, "A Compare found different data",
    "The data on the drive differs from the data the host supplied with a Compare command.",
    [("The specification: \"The command failed due to a miscompare during a Compare command.\"", N12 + ", Figure 19")],
    [("any", 2, [0x85], None)], "neither side by itself: it is a normal outcome of a compare", R1N + "; values: " + N12 + ", Figure 19", belongs=["status_12"],
    reaction=[("The Linux driver reports it as a medium error, although the specification's definition shows it is not a media failure.", ERR_STATUS)])
_st(5, "A read of a block that holds no data",
    "The command read, verified or copied a block that was deallocated or never written, and the host had asked for an error in that case.",
    [("The specification: \"The command failed due to an attempt to copy from, read from, or verify an LBA range containing a deallocated or unwritten logical block.\"", N12 + ", Figure 19"),
     ("The error is returned only when the host enabled it; it is off by default.", N11 + ", section 3.3.3.2.1 (by cross-reference; number not verified)")],
    [("any", 2, [0x87], None)], "the host (it read blocks that hold no data)", R1N + "; values: " + N12 + ", Figure 19", belongs=["behaviour_13"])
_st(6, "Access refused by security",
    "The drive refused the command because of access rights, a key or a lockdown.",
    [("The specification: access to the namespace or user data is denied due to lack of access rights (2h/86h); the command was denied due to lack of access rights (0h/15h); "
      "prohibited by Command and Feature Lockdown (0h/23h); invalid key tag (0h/25h); incorrect key (0h/28h).", B23 + ", Figures 102 and 106")],
    [("any", 2, [0x86], None), ("any", 0, [0x15, 0x23, 0x25, 0x28], None)], "the host (it must unlock or correct the key first)", R1N + "; values: " + B23 + ", Figures 102 and 106",
    differs=[("0h/15h", "a drive built to Base Specification 1.2.1 or earlier may return 15h for 'SGL Data Block Granularity Invalid'; the current meaning is Operation Denied. The family accepts 15h and says both.",
              N12 + ", Figure 17, note")])
_st(7, "The command was not understood or is not supported",
    "The drive does not know the command code, a field value, the namespace or its format.",
    [("The specification: a reserved or unsupported value in the opcode field (01h), in another field (02h), or an invalid namespace or format (0Bh).", B23 + ", Figure 102"),
     ("For Identify, the command specific status 2Ch says the I/O command set is invalid.", B23 + ", Figure 103")],
    [("admin", 1, [0x2C], ["Identify"]), ("any", 0, [0x01, 0x02, 0x0B], None)], "the host's command (or a feature the drive does not have)", R1N + "; values: " + B23 + ", Figures 102 and 103",
    reaction=REACT_DNR + [("The Linux driver reports these to the block layer as not supported.", ERR_STATUS)],
    differs=[("1h/2Ch", "the Linux header lists 'Invalid I/O Command Set' with the generic value 2Ch; Base 2.3 defines it as the command specific value 2Ch of Identify. The family follows the specification.",
              "research note R1, section 2, differences between sources")])
_st(8, "The parameters of an I/O command were rejected for this namespace",
    "The attributes, the protection settings, a size limit or the copy ranges of an I/O command do not fit the namespace.",
    [("The specification: conflicting attributes (80h), invalid protection information (81h), command size limit exceeded (83h), and for Copy incompatible format (85h), fast copy not possible (86h), "
      "overlapping I/O range (87h), insufficient resources (89h); atomic write unit exceeded (0h/14h).", N12 + ", Figures 17 and 18")],
    [("io", 1, [0x80, 0x81, 0x83, 0x85, 0x86, 0x87, 0x89], None), ("any", 0, [0x14], None)], "the host (it built the command wrongly for this namespace)", R1N + "; values: " + N12 + ", Figures 17 and 18")
_st(9, "The block range or the capacity was exceeded",
    "The command addresses blocks beyond the end of the namespace, or the namespace has no capacity left.",
    [("The specification: \"The command references an LBA that exceeds the size of the namespace.\" (80h); the namespace utilization exceeds the namespace capacity (81h).", N12 + ", Figure 17")],
    [("any", 0, [0x80, 0x81], None)], "the host for 80h (a wrong range); for 81h the namespace is full", R1N + "; values: " + N12 + ", Figure 17", belongs=["protocol_11"],
    reaction=[("The Linux driver reports 80h as a target error and 81h as no space.", ERR_STATUS)])
_st(10, "The data pointer of the command is faulty",
    "A PRP entry or an SGL descriptor of the command is wrong, or the controller memory buffer is used in a way the drive does not support.",
    [("The specification: invalid SGL segment descriptor (0Dh), invalid number of SGL descriptors (0Eh), data or metadata SGL length invalid (0Fh, 10h), SGL descriptor type invalid (11h), "
      "invalid use of controller memory buffer (12h), PRP offset invalid (13h), SGL offset invalid (16h), SGL data block granularity invalid (1Eh), command not supported for queue in CMB (1Fh).",
      B23 + ", Figure 102")],
    [("any", 0, [0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x16, 0x1E, 0x1F], None)], "the host (its driver built the pointer wrongly, or its memory is corrupted)", R1N + "; values: " + B23 + ", Figure 102",
    belongs=["protocol_13"])
_st(11, "The data transfer or the transport failed",
    "The drive could not fetch or deliver the data of the command.",
    [("The specification: \"Transferring the data or metadata associated with a command had an error.\" (04h); a transient transport error was detected (22h), to be treated as persistent after four failures.",
      B23 + ", Figure 102")],
    [("any", 0, [0x04, 0x22], None)], "it cannot be told from this rule alone (the cause is below the command level, which is outside these rules)", R1N + "; values: " + B23 + ", Figure 102")
_st(12, "A fused pair of commands was broken",
    "One command of a fused pair (Compare and Write) was aborted because the other failed or was missing.",
    [("The specification: aborted due to the other command in a fused operation failing (09h); aborted because the adjacent entry was not the matching fused command (0Ah).", B23 + ", Figure 102")],
    [("any", 0, [0x09, 0x0A], None)], "09h: look at the partner's status; 0Ah: the host (wrong order in the queue)", R1N + "; values: " + B23 + ", Figure 102", belongs=["status_04"])
_st(13, "The command was aborted because the host asked",
    "The drive ended the command because the host sent an Abort for it, deleted its queue, or pre-empted a reservation.",
    [("The specification: aborted due to an Abort or Cancel command that specified this command (07h); due to a Delete I/O Submission Queue for its queue (08h); "
      "due to a Reservation Acquire with pre-empt and abort (1Bh).", B23 + ", Figure 102"),
     ("The Linux driver sends an Abort after its time limit for an I/O command has passed (30 seconds unless changed).", NVME_TIMEOUT)],
    [("any", 0, [0x07, 0x08, 0x1B], None)], "nothing is wrong with the drive by this status alone: the trigger is the host's (a time-out, a tear-down, a reservation)",
    R1N + "; values: " + B23 + ", Figure 102", belongs=["behaviour_01", "behaviour_02", "behaviour_03", "behaviour_04"], detector=("cmd.timeout", "cmd.status_error"), check_kind="chain",
    reaction=[("The driver's Abort only logs its own completion; the aborted command is completed when its entry arrives.", L_PCI + ", function abort_endio (lines 1524 to 1533)")],
    differs=[("0h/07h", "libnvme's text names only the Abort command as the cause; Base 2.3 adds the Cancel command. The family names both.", "research note R1, section 2, differences between sources")],
    extra_how=[("Reported as a linked finding of its episode: the commands that never completed, the Aborts and the controller set-up that follows are named with it.", R2N + ", note on B1 to B4")])
_st(14, "The command was aborted for a power loss",
    "The drive was told that power is going away and dropped the command.",
    [("The specification: \"Indicates that the command was aborted due to a power loss notification.\"", B23 + ", Figure 102"),
     ("After a power fault, thirteen of fifteen drives tested showed failures such as shorn writes and corrupted data: blocks written just before should be verified.", FAST13)],
    [("any", 0, [0x05], None)], "neither side: the power was removed", R1N + "; values: " + B23 + ", Figure 102")
_st(15, "An internal error of the drive",
    "The firmware or the hardware of the controller failed while it handled the command.",
    [("The specification: \"The command was not completed successfully due to an internal error. Details on the internal device error should be reported as an asynchronous event.\" (0h/06h); "
      "a controller internal error specific to the controller processing the command (3h/00h).", B23 + ", Figures 102 and 107")],
    [("any", 0, [0x06], None), ("any", 3, [0x00], None)], "the controller (the drive)", R1N + "; values: " + B23 + ", Figures 102 and 107")
_st(16, "The drive was not ready or busy: try later",
    "The namespace or the media was not ready, or a format, a sanitize or a self-test was running.",
    [("The specification: namespace not ready (82h), format in progress (84h, 'do not retry' shall be 0), sanitize in progress (1Dh, 2Ch), command interrupted (21h, 'do not retry' shall be 0), "
      "admin command media not ready (24h, admin commands only).", B23 + ", Figure 102"),
     ("For Device Self-test, the command specific status 1Dh says a self-test is in progress.", B23 + ", Figure 103")],
    [("admin", 1, [0x1D], ["Device Self-test"]), ("any", 0, [0x82, 0x84, 0x1D, 0x2C, 0x21], None), ("admin", 0, [0x24], None)],
    "the controller when it stays not ready, or sets 'do not retry' on 84h or 21h; otherwise a passing state", R1N + "; values: " + B23 + ", Figures 102 and 103", belongs=["protocol_06"],
    reaction=[("The Linux driver waits the delay the completion selects (the drive's value times 100 milliseconds) and sends the command again.", L_CORE_M + ", function nvme_retry_req (lines 327 to 344)")],
    differs=[("0h/2Ch", D23, B23 + ", Figure 102")])
_st(17, "A write was refused: protected or read-only",
    "The namespace is write protected, the range holds read-only blocks, or the last sanitize failed.",
    [("The specification: the command is prohibited while the namespace is write protected (0h/20h); the LBA range contains read-only blocks (1h/82h); "
      "the most recent sanitize operation failed (0h/1Ch, 0h/2Bh).", B23 + ", Figure 102; " + N12 + ", Figure 18")],
    [("io", 1, [0x82], None), ("any", 0, [0x20, 0x1C, 0x2B], None)], "the host (it must change the state before it writes)", R1N + "; values: " + B23 + ", Figure 102; " + N12 + ", Figure 18",
    reaction=[("The Linux driver reports 1h/82h to the block layer as a medium error.", ERR_STATUS)], differs=[("0h/2Bh", D23, B23 + ", Figure 102")])
_st(18, "A reservation conflict",
    "Another host holds a reservation on the namespace that forbids this command.",
    [("The specification: \"The command was aborted due to a conflict with a reservation held on the accessed namespace.\" (0h/83h); the namespace is dispersed (1h/2Eh on the reservation commands).",
      B23 + ", Figures 102 and 103")],
    [("any", 1, [0x2E], ["Reservation Register", "Reservation Report", "Reservation Acquire", "Reservation Release"]), ("any", 0, [0x83], None)],
    "neither side: another host holds the reservation", R1N + "; values: " + B23 + ", Figures 102 and 103",
    reaction=[("The Linux driver has a block-layer error of its own for it (reservation conflict).", ERR_STATUS)])
_st(19, "A command identifier or sequence fault",
    "The host used a command identifier that was still in use, or broke the order of a multi-command sequence.",
    [("The specification: \"The command identifier is already in use. Note: It is implementation specific how many commands are searched for a conflict.\" (03h); "
      "aborted due to a protocol violation in a multi-command sequence (0Ch).", B23 + ", Figure 102")],
    [("any", 0, [0x03, 0x0C], None)], "the host", R1N + "; values: " + B23 + ", Figure 102", belongs=["protocol_01"])
_st(20, "Admin: a queue could not be set up or removed",
    "A command that creates or deletes an I/O queue was refused.",
    [("The specification: completion queue invalid (00h), invalid queue identifier (01h), invalid queue size (02h), invalid interrupt vector (08h), invalid queue deletion (0Ch).", B23 + ", Figure 103")],
    [("admin", 1, [0x00, 0x01, 0x02, 0x08, 0x0C], None)], "the host (its driver's set-up); later I/O on that queue will not work", R1N + "; values: " + B23 + ", Figure 103", belongs=["behaviour_14"])
_st(21, "Admin: a log page, a feature, an event request or an Abort was refused",
    "The drive does not offer that log page or cannot save, change or scope that feature, or too many Aborts or event requests were outstanding.",
    [("The specification: abort command limit exceeded (03h), asynchronous event request limit exceeded (05h), invalid log page (09h), feature not saveable, not changeable, not namespace specific "
      "(0Dh, 0Eh, 0Fh), overlapping range for Set Features (14h), I/O command set combination rejected (2Bh), invalid power limit (3Eh).", B23 + ", Figure 103; " + N12 + ", Figure 92")],
    [("admin", 1, [0x14], ["Set Features"]), ("admin", 1, [0x03, 0x05, 0x09, 0x0D, 0x0E, 0x0F, 0x2B, 0x3E], None)],
    "usually nobody: host tools probe what the drive offers; 03h and 05h are the host's (too many outstanding)", R1N + "; values: " + B23 + ", Figure 103", belongs=["behaviour_03"],
    differs=[("1h/3Eh", D23, B23 + ", Figure 103")])
_st(22, "Admin: a maintenance command was refused",
    "A firmware, namespace management, format, sanitize, virtualization or capacity command was refused.",
    [("The specification names the status and the commands it belongs to (firmware slot or image invalid, invalid format, namespace insufficient capacity, namespace already attached and so on).",
      B23 + ", Figure 103"),
     ("The full definition of each value is in the figure of its own command, which the research did not read: the meaning given with a found row is the catalogue's.", "research note R1, section 3, gaps")],
    [("admin", 1, [0x06, 0x07, 0x0A, 0x12, 0x13, 0x14, 0x15, 0x16, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x29, 0x2A, 0x2D, 0x39, 0x3C, 0x3D], None)],
    "per value; it cannot be told from this rule alone", R1N + "; values: " + B23 + ", Figure 103",
    differs=[("1h/04h", "Base 2.3 says Reserved; Linux and libnvme name it 'Abort Command Is Missing'. The family does not accept it; the rule for reserved values reports it.", "research note R1, section 3, differences between sources"),
             ("1h/3Ch", D23, B23 + ", Figure 103"), ("1h/3Dh", D23, B23 + ", Figure 103")])
_st(23, "A rule of a zoned namespace was broken",
    "A write was not at the write pointer, the zone is full, read-only or offline, or too many zones are open or active.",
    [("The specification lists the zoned values B8h to BFh; \"Zone Boundary Error: The command specifies logical blocks in more than one zone.\"",
      B23 + ", Figure 104; NVM Express Zoned Namespace Command Set Specification, Revision 1.2 (only a few lines were read)")],
    [("io", 1, [0xB8, 0xB9, 0xBA, 0xBB, 0xBC, 0xBD, 0xBE, 0xBF], None)], "the host (its zone handling)", R1N + "; values: " + B23 + ", Figure 104",
    differs=[("1h/B8h", "Base 2.3 writes 'Zoned Boundary Error'; the zoned specification writes 'Zone Boundary Error'.", "research note R1, section 3, differences between sources")])
_st(24, "A path, multi-host, vendor or other-command-set status",
    "A status about the path to the drive, about several hosts, one the vendor defines, or one of a command set outside the NVM command set.",
    [("The specification: path related status should be retried on another path; 70h and 71h of the path type are written by the host itself and should never be seen in a PCIe recording.",
      B23 + ", Figure 107 and section 4.2.3.4; " + L_CORE_M + ", lines 536 and 552"),
     ("Vendor specific values (status code type 7h, and status codes C0h to FFh of every type) can only be explained with the vendor's documentation.", B23 + ", Figure 101 and section 4.2.3"),
     ("The Key Value, computational program, placement, discovery and zoning values belong to other command sets or features; the research places them in no family of their own, so they are reported here.",
      "research note R1, section 7, gaps")],
    [("any", 3, [0x01, 0x02, 0x03, 0x60, 0x70, 0x71], None), ("any", 0, [0x18, 0x19, 0x1A, 0x26, 0x27], None)],
    "it cannot be told from this rule alone", R1N + "; values: " + B23 + ", Figures 101, 102 and 107",
    extra_how=[("Also every status that is not Successful Completion, is not one of the exceptions, is not reserved, and that no other family names: vendor specific values and values of other command sets.", R1N)])
FAMILIES[-1]["check"]["rest"] = True

# ---------------------------------------------------------------------------------------------- behaviour over time (R2)
CHAIN = ["behaviour_01", "behaviour_02", "behaviour_03", "behaviour_04", "status_13"]
CHAIN_HOW = ("Reported as linked findings of one episode, never as unrelated errors: an episode is the stretch of command rows between two set-ups of the controller; "
             "its commands without a completion, its Aborts, its aborted commands and the set-up that ends it are named together.", R2N + ", note: B1 to B4 form one causal chain")
NO_TARGET = ("Which command an Abort names is in the Abort's own parameters (Command Dword 10: queue and command identifier), and the NVMe command export has no column for them: "
             "the link from an Abort to its command is therefore said as 'sent while these commands were open', never guessed.")
_fam("behaviour_01", BEHAVIOUR, "A command never completed",
     "The command was sent and no completion came, although the recording went on for the host's time limit or longer.",
     [("The specification sets no time limit for a command; the limit is the host's.", "research note R2, section 1 (" + B21 + ": the only limit it defines is for the controller becoming ready)"),
      ("The Linux driver's limits are 30 seconds for an I/O command and 60 seconds for an admin command, both changeable.", L_CORE + ", lines 51 to 59"),
      ("A drive that stops responding for seconds and then recovers, or that restarts after an internal fault, is a known firmware failure.", FAST18)],
     [("The command's row has no status (the status columns are empty) and the recording's last Time Stamp is the host's limit or more after the command's Time Stamp. "
       "A command sent later than that is 'still open when the recording ended' and is not flagged.", R2N + ", family B1; the detector's rule (nvme_hier/rules.py, command_timeout)"), CHAIN_HOW],
     {"kind": "chain", "role": "never"}, "it cannot be told from this rule alone (the drive did not answer, or the answer was lost below the command level)",
     [C_OPC, C_SQID, C_CID, C_SCT, C_SC, C_TIME], needs=[NEED_DETECTOR],
     exceptions=[(STAYS_OPEN, STAYS_OPEN_SRC), (LONG_BY_NATURE, "nvme_hier/rules.py, LONG_BY_NATURE")], belongs=[x for x in CHAIN if x != "behaviour_01"],
     reaction=[("After its limit the Linux driver first reads the completion queue itself, then sends one Abort for an I/O command; a second time-out of the same command, or any admin time-out, resets the controller.", NVME_TIMEOUT)],
     detector=("cmd.timeout", "cmd.incomplete", "cmd.not_fetched", "cmd.doorbell_missing", "cmd.no_interrupt"), from_notes=["R2 B1"])
_fam("behaviour_02", BEHAVIOUR, "A command completed after the host's limit",
     "The completion came, but later than the host waits.",
     [("The Linux driver's limits are 30 seconds for an I/O command and 60 seconds for an admin command.", L_CORE + ", lines 51 to 59"),
      ("A completion after the limit with no Abort before it matches a completion the host collected late (\"completion polled\") or a used-up Abort budget.", NVME_TIMEOUT + "; " + R2N + ", family B2")],
     [("The time from the command's Time Stamp to the Time Stamp of its first completion row (joined to it in the tree by queue and command identifier) is the host's limit or more.",
       R2N + ", family B2; the detector's rule (nvme_hier/rules.py, command_timeout)"), CHAIN_HOW],
     {"kind": "detector", "rule": "cmd.timeout", "detail_kinds": ["over the host's limit"]}, "the controller (it answered late), unless the host's own limit is shorter than the drive's stated time",
     [C_OPC, C_SQID, C_CID, C_TIME, C_TYPE, C_NTIME], needs=[NEED_DETECTOR, dict(NEED_NTX, says="cannot be checked on this recording: the NVMe transactions file is not loaded, and a command's time ends at its completion row")],
     exceptions=[(STAYS_OPEN, STAYS_OPEN_SRC), (LONG_BY_NATURE, "nvme_hier/rules.py, LONG_BY_NATURE")], belongs=[x for x in CHAIN if x != "behaviour_02"],
     reaction=[("No Abort is sent when the completion is found by reading the queue (\"completion polled\").", L_PCI + ", lines 1626 to 1637")],
     detector=("cmd.timeout", "cmd.latency_over_limit"), from_notes=["R2 B2"])
_fam("behaviour_03", BEHAVIOUR, "The host sent an Abort",
     "The host gave up waiting for a command and asked the drive to abort it; the Abort itself has an outcome.",
     [("The Linux driver sends one Abort (admin command 08h, naming the queue and the command identifier) at the first time-out of an I/O command.", L_PCI + ", lines 1677 to 1713"),
      ("The specification: the aborted command completes with Command Abort Requested; bit 0 of the Abort's completion set to 1 says an immediate abort was not performed.", B21 + ", section 5.1.1 (by cross-reference)"),
      ("An older revision requires the aborted command's completion before the Abort's; Revision 2.1 allows either order: the order is therefore not judged here.", UNH15 + ", Test 1.5; " + B21 + ", section 5.1.1")],
     [("Every Abort command (admin queue, command code 08h) is found with its own outcome: no completion, or its status and bit 0 of the first four bytes of its completion row.", R2N + ", family B3; " + R4N + ", rule 19"),
      (NO_TARGET, "research note R3, section 3 (the columns of the command export)"), CHAIN_HOW],
     {"kind": "chain", "role": "abort"}, "the host sent it; whether the drive answered it rightly cannot be told without the Abort's parameters",
     [C_OPC, C_SQID, C_CID, C_SCT, C_SC, C_TYPE, C_DW0], needs=[dict(NEED_NTX, optional=True, says="the Abort's outcome bit is not given on this recording: the NVMe transactions file is not loaded")],
     belongs=[x for x in CHAIN if x != "behaviour_03"] + ["status_21"],
     reaction=[("If the Abort is not answered either, the Abort (an admin command) times out and the driver resets the controller.", NVME_TIMEOUT)], detector=("cmd.timeout",), from_notes=["R2 B3", "R4 rule 19"])
_fam("behaviour_04", BEHAVIOUR, "The controller was set up again with commands lost (a reset)",
     "The host set the controller up again in the middle of the recording while commands were still without a completion.",
     [("The Linux driver disables and resets the controller at the second time-out of a command, or at any admin time-out.", L_PCI + ", lines 1661 to 1675"),
      ("The Number of Queues feature shall only be set during initialization, before any I/O queue is created, and its value does not change between resets: a second successful Set Features of it after I/O queues existed therefore marks a reset.",
       B21 + ", section 5.1.25.2.1")],
     [("A Set Features command with feature identifier 07h (Number of Queues) that completed with success after an I/O queue had been created earlier in the recording, "
       "while at least one command sent before it has no completion.", R2N + ", family B4; research note R2, section 7 (the set-up burst is the command-level mark of a reset)"), CHAIN_HOW],
     {"kind": "chain", "role": "reset"}, "it cannot be told from this rule alone: the host reset the controller because commands were not answered",
     [C_OPC, C_SQID, C_FID, C_SCT, C_SC], needs=[{"what": "the feature identifier of the Set Features commands (column FID)",
                                                   "says": "cannot be checked on this recording: no Set Features command carries a value in the column FID"}],
     belongs=[x for x in CHAIN if x != "behaviour_04"],
     reaction=[("After the reset the driver ends every open request itself with a host-made status and sends the same I/O again.", L_CORE + ", lines 521 to 535")], from_notes=["R2 B4"])
_fam("behaviour_05", BEHAVIOUR, "A command much slower than usual for its kind",
     "The command completed, but took far longer than commands of the same kind and size usually take in this recording.",
     [("Fail-slow drives are a failure mode of their own: slow, with a success status, and not shown by the drive's health counters.", ATC22),
      ("Causes named by the field study: firmware that throttles or pauses, read retries on worn flash, and heavy garbage collection on a partly failing drive.", FAST18)],
     [("The command's time (its Time Stamp to its first completion row) is above the bar the timeout rule measures for commands of the same command code and block count in this recording, "
       "with at least %d completed commands of that kind and size." % RL.USUAL_MIN, "the detector's rule (nvme_hier/rules.py, usual_bar); " + R2N + ", family B5"),
      ("The studies use a bar of third quartile plus 2 times the interquartile range; on this application's data that bar called healthy commands slow, so the detector looks for the jump where the normal group ends. The difference is said here on purpose.",
       ATC22 + "; nvme_hier/rules.py, the note above USUAL_MIN")],
     {"kind": "detector", "rule": "cmd.timeout", "detail_kinds": ["slower than usual"]}, "the controller is the first suspect; load on the host can do the same and is not ruled out by this rule",
     [C_OPC, C_SQID, C_NLB, C_TIME, C_TYPE, C_NTIME], needs=[NEED_DETECTOR, dict(NEED_NTX, says="cannot be checked on this recording: the NVMe transactions file is not loaded, and a command's time ends at its completion row")],
     exceptions=[(STAYS_OPEN, STAYS_OPEN_SRC), (LONG_BY_NATURE, "nvme_hier/rules.py, LONG_BY_NATURE")], belongs=["behaviour_01", "behaviour_02"],
     reaction=[("The driver does nothing while the command is under its limit.", NVME_TIMEOUT)], detector=("cmd.timeout",), from_notes=["R2 B5"])
_fam("behaviour_09", BEHAVIOUR, "A command was sent again although the drive said 'do not retry'",
     "A command failed with 'do not retry' set, and the same operation was sent again.",
     [("The specification: with 'do not retry' set to 1 the same command, sent again, is expected to fail.", B21 + ", status field, Do Not Retry; " + FIG100),
      ("The Linux driver never retries such a command: a resubmission points at another layer of the host.", L_CORE + ", function nvme_decide_disposition (lines 399 to 422)")],
     [("An I/O command that completed with an error status and 'do not retry' = 1 on its completion row, followed later by a command with the same command code, namespace, first block and number of blocks. "
       "The command identifier is not used as the link: it is a queue slot.", R2N + ", family B9; " + R4N + ", rule 8")],
     {"kind": "retry_after_dnr"}, "the host (an inefficiency, not a breach of the protocol)", [C_OPC, C_SQID, C_NSID, C_SLBA, C_NLB, C_SCT, C_SC, C_TYPE, C_DNR],
     needs=[NEED_NTX, NEED_BITS], exceptions=[("A repeated range after a successful first attempt is not a retry and is not flagged.", "research note R2, section 5, inferences")],
     reaction=REACT_DNR, from_notes=["R2 B9", "R4 rule 8", "R1 check on DNR"])
_fam("behaviour_13", BEHAVIOUR, "A read of blocks that were deallocated or cleared before",
     "A Read addresses blocks that an earlier Dataset Management (deallocate) or Write Zeroes command of the recording covered.",
     [("The specification: a read of a deallocated block returns zeros, FFh or the same value until it is written, as the drive declares; with the error enabled it is aborted instead.",
       N11 + ", section 3.3.3.2.1 (by cross-reference; number not verified)")],
     [("A Read on an I/O queue whose block range overlaps a range deallocated or cleared earlier on the same namespace; the detector judges the returned bytes when the packets are loaded, otherwise it files a check.",
       "the detector's rules (nvme_hier/rules.py, _deallocate_readback and _write_zeroes_readback); " + R2N + ", family B13 (a)")],
     {"kind": "detector", "rule": ["cmd.deallocate_readback", "cmd.write_zeroes_readback"]}, "the controller when the bytes are not what it declared; otherwise something to check",
     [C_OPC, C_SQID, C_NSID, C_SLBA, C_NLB], needs=[NEED_DETECTOR], belongs=["status_05"],
     reaction=[("The driver takes the data as it comes: the fault shows above the driver, as wrong data.", R2N + ", family B13")],
     detector=("cmd.deallocate_readback", "cmd.write_zeroes_readback"), from_notes=["R2 B13 (a)"])
_fam("behaviour_14", BEHAVIOUR, "An admin command that I/O depends on failed",
     "An Identify, the Set Features for the Number of Queues, or a command that creates an I/O queue completed with an error.",
     [("I/O depends on a short chain of admin commands; a failure there explains missing or fewer queues later.", "research note R2, section 7"),
      ("The Linux driver logs a failed Number of Queues step as \"Could not set queue count\".", L_CORE + ", lines 1719 to 1751")],
     [("A command on the admin queue that is Identify, Create I/O Completion Queue, Create I/O Submission Queue, or Set Features with feature identifier 07h, whose status is not Successful Completion.",
       R2N + ", family B14 (a)")],
     {"kind": "setup_failed", "ops": ["Identify", "Create I/O Completion Queue", "Create I/O Submission Queue"], "set_features_fid": 7},
     "the host when the status says its parameters are wrong; otherwise the controller", [C_OPC, C_SQID, C_FID, C_SCT, C_SC], needs=[NEED_STATUS], belongs=["status_20", "status_07"],
     reaction=[("The driver falls back to fewer queues or gives the controller up.", L_CORE + ", lines 1719 to 1751")], from_notes=["R2 B14 (a)"])

# ---------------------------------------------------------------------------------------------- rules of the protocol (R4, with R1's checks on the bits)
# Found by a constructed case on 2026-11-15 (tests/test_command_rules_flow.py): two commands of one queue were given the same identifier while the
# first was still open. The tree joined every later row with that queue and identifier to the newer command, so the pattern above found nothing.
# The family says so in its text and in the summary of every run: it never stays silent about the half it cannot see.
CID_LIMIT = ("This half of the rule cannot be seen at the command level in this application, and the rule says so in every result: the tree joins each row that carries a queue and a "
             "command identifier to the newest command with that pair, so the earlier command is left without its completion row. It then shows as a command "
             "that never completed (the built-in checks and the rule 'A command never completed' list it), the later command carries the completions, and "
             "a second completion with the same pair belongs to no command. Only the identifier FFFFh is found by this rule.")
CID_LIMIT_SRC = "the application's own join of NVMe transactions to commands (nvme_hier/builder.py, ntx_to_cmds); a constructed case on sample S17, 15 November 2026 (tests/test_command_rules_flow.py)"
CID_LIMIT_SAYS = ("Whether an identifier was used again while its command was still open cannot be seen at the command level: the tree joins every row with a queue and "
                  "a command identifier to the newest command with that pair, so the earlier command shows as one that never completed. This result holds only "
                  "commands that use the identifier FFFFh.")
_fam("protocol_01", PROTOCOL, "A command identifier was used again while its command was still open",
     "Two commands of one submission queue carried the same command identifier at the same time.",
     [("The specification: the command identifier is unique for the command together with the submission queue identifier; FFFFh should not be used.", B21 + ", section 4.1; " + B20 + ", section 3.3.3.1, Figure 89" + TBC),
      ("The Linux driver builds the identifier from a 4-bit counter and a 12-bit tag to catch completions that match no live command.", L_NVME + ", lines 583 to 596")],
     [("A command whose submission queue and command identifier equal those of an earlier command of the recording that completed, where the earlier command's first completion row is later than this command's Time Stamp: "
       "both were open at once. An earlier command without any completion is not used: a reset frees its identifier.", R4N + ", rule 1; " + R2N + ", family B7"),
      (CID_LIMIT, CID_LIMIT_SRC),
      ("The identifier FFFFh is reported as advice only.", R4N + ", rule 1")],
     {"kind": "cid_reuse"}, "the host; the controller's answer Command ID Conflict is optional", [C_SQID, C_CID, C_TIME, C_TYPE, C_NTIME],
     needs=[dict(NEED_NTX, says="cannot be checked on this recording: the NVMe transactions file is not loaded, and whether the earlier command was still open is read from its completion row")],
     belongs=["status_19"], reaction=[("The driver drops a completion that matches no request and logs \"invalid id ... completed on queue ...\".", L_PCI + ", lines 1299 to 1305")], from_notes=["R4 rule 1", "R2 B7"])
_fam("protocol_05", PROTOCOL, "A status value the specification reserves, or a status cell that cannot be read",
     "The completion carries a status code type or status code that the specification keeps for later use, or the status cell is damaged.",
     [("The specification: status code types 4h to 6h are reserved; reserved parts shall not be sent.", B23 + ", Figure 101; " + B20 + ", section 3.3.3.2.1, Figure 96" + TBC),
      ("Such a value means a violation by the drive or a wrong decode of the column.", "research note R1, section 5, inferences")],
     [("A command whose status code type is 4h, 5h or 6h, or whose status is one of the entries the application's catalogue (/nvme-errors) lists as reserved; or a status cell that is not a number.", R4N + ", rule 5")],
     {"kind": "status", "match": [], "reserved": True}, "the controller, or the decode of the recording", STATUS_COLS, needs=[NEED_STATUS],
     exceptions=[("A value a family names from Base 2.3 that the catalogue (Base 2.1) still lists as reserved belongs to that family, which says so.", R1N)],
     reaction=[("The driver treats an unknown status like any error: it follows 'do not retry'.", DISPOSITION)], detector=("cmd.status_error",), from_notes=["R4 rule 5", "R1 family 24 (reserved part)"])
_fam("protocol_06", PROTOCOL, "'Do not retry' disagrees with the status",
     "The 'do not retry' bit of the completion is set where the specification says it is 0.",
     [("The specification: if the status is success, 'do not retry' should be 0.", FIG100),
      ("The specification: with Command Interrupted (21h) and Format In Progress (84h) the controller shall clear 'do not retry' to 0.", B23 + ", Figure 102")],
     [("The completion row under a command has DNR = 1 and status type 0h with status code 00h (should be 0), 21h or 84h (shall be 0).", R4N + ", rule 6; " + R1N + ", cross-cutting checks")],
     {"kind": "bits", "test": "dnr_disagrees"}, "the controller", BITS_COLS + [{"level": "nvme_transaction", "names": ["SCT", "SC"], "meaning": "the status code type and status code on the completion row itself"}],
     needs=[NEED_NTX, NEED_BITS], belongs=["status_16"], reaction=[("The driver does not retry a command whose completion has 'do not retry' set, whatever the status.", DISPOSITION)], from_notes=["R4 rule 6", "R1 checks 1 and 2"])
_fam("protocol_07", PROTOCOL, "A retry delay was given together with 'do not retry'",
     "The completion selects a retry delay although it also says the command must not be retried.",
     [("The specification: the retry delay only has meaning when 'do not retry' is 0 and the host enabled Advanced Command Retry; otherwise the field is reserved.", FIG100)],
     [("The completion row under a command has CRD not 0 and DNR = 1.", R4N + ", rule 7"),
      ("Whether the host enabled Advanced Command Retry is in the data of a Set Features command, which the command export does not carry: that half of the rule is not checked and is said so.", R4N + ", rule 7 and gaps")],
     {"kind": "bits", "test": "crd_with_dnr"}, "the controller", BITS_COLS, needs=[NEED_NTX, NEED_BITS],
     reaction=[("The driver reads the delay only on the retry path, which 'do not retry' closes.", L_CORE_M + ", function nvme_retry_req (lines 327 to 344)")], from_notes=["R4 rule 7", "R1 check 4"])
_fam("protocol_11", PROTOCOL, "A block range beyond the end of the namespace",
     "The first block plus the number of blocks of an I/O command goes past the size of the namespace.",
     [("The specification: such a command is answered with LBA Out of Range.", N11 + ", section 3.1 (status 80h)" + TBC),
      ("When two faults coincide the specification leaves the status to the vendor, so another error status is a weaker finding than success.", "research note R4, section 6, notes on applying the list; " + UNH26),
      ("The same check in a device model: slba + nlb > nsze gives LBA Out of Range.", QEMU + ", nvme_check_bounds")],
     [("An I/O command with a first block (SLBA) and a number of blocks (NLB, counted from 0) on a namespace whose size (NSZE) an earlier Identify command of the recording returned, where SLBA + NLB + 1 is larger than NSZE. "
       "The found row says what the drive answered: LBA Out of Range (as expected), another error, or success (then the controller is at fault too).", R4N + ", rule 11")],
     {"kind": "lba_range"}, "the host; the controller as well when it answered success", [C_OPC, C_SQID, C_NSID, C_SLBA, C_NLB, C_NSZE, C_SCT, C_SC],
     needs=[{"what": "the size of the namespace (column NSZE on the row of an Identify command for that namespace)",
             "says": "cannot be checked on this recording: no Identify command of the recording carries the size of a namespace (column NSZE)"}],
     exceptions=[("Dataset Management carries its ranges in its data, not in SLBA and NLB, and a drive may skip a range past the end with success: it is not judged here.", "research note R4, section 5, inferences (QEMU)")],
     belongs=["status_09"], reaction=[("The driver reports LBA Out of Range to the block layer as a target error.", ERR_STATUS)], from_notes=["R4 rule 11"])
_fam("protocol_13", PROTOCOL, "A first data pointer that is not aligned",
     "The first PRP entry of a command has its two lowest bits set.",
     [("The specification: the offset of a PRP entry is invalid when it is not dword aligned (bits 1:0 not 00b); the controller should answer PRP Offset Invalid.", B23 + ", Figure 102 (status 13h); " + B20 + ", section 4.1.1, Figure 113" + TBC)],
     [("A command whose PRP1 value has bit 0 or bit 1 set. The second entry and the page size are not judged: they need the memory page size, which the command row does not carry.", R4N + ", rule 13")],
     {"kind": "prp_offset"}, "the host; the controller's answer is only a 'should'", [C_OPC, C_SQID, C_PRP1, C_SCT, C_SC],
     needs=[{"what": "the first data pointer (column PRP1)", "says": "cannot be checked on this recording: no row of the NVMe command file carries a value in the column PRP1"}],
     belongs=["status_10"], reaction=[("The driver builds its pointers from mapped pages; a misaligned pointer is a driver or memory fault.", R4N + ", rule 13")], from_notes=["R4 rule 13"])


def _none(fid, group, name, what, why, how, needed, from_notes, belongs=(), seeded_reason=None):
    _fam(fid, group, name, what, why, how, {"kind": "none"}, "see the family's text", [], needs=[{"what": needed, "says": "%s: %s" % (NOT_CHECKABLE, needed)}],
         belongs=belongs, from_notes=from_notes)
    FAMILIES[-1]["not_checkable"] = seeded_reason or ("%s: %s" % (NOT_CHECKABLE, needed))


_none("behaviour_06", BEHAVIOUR, "The whole drive paused", "For a while commands were open and no completion came on any queue; then many completed at once.",
      [("A bad batch of drives stopped responding for seconds and then recovered.", FAST18)],
      [("An interval with open commands and no completion on any queue, longer than a threshold the admin sets.", R2N + ", family B6")],
      "a threshold set by the admin (no value is chosen in advance) and each command's completion time; not built yet", ["R2 B6"], belongs=["behaviour_01"],
      seeded_reason="not seeded yet: the rule needs a threshold the admin sets, and nothing is chosen in advance; the pass over every completion time is not built")
_none("behaviour_08", BEHAVIOUR, "A completion that matches no open command", "The drive wrote a completion for a queue and command identifier that is not open.",
      [("Controllers that send a completion twice were seen in the wild.", "Linux commit e7006de6c238 (2021-06-16)")],
      [("A completion whose queue and command identifier name no open command.", R2N + ", family B8; " + R4N + ", rule 2")],
      "the completions that joined no command: they are rows of the NVMe transaction level without a command above them, so they are not in the command export (the detector files them at the NVMe transaction level)",
      ["R2 B8", "R4 rule 2"], belongs=["behaviour_01"])
_none("behaviour_10", BEHAVIOUR, "A completion on the wrong queue", "The completion names another submission queue than the one the command was sent on.",
      [("The conformance plan verifies that the completion's queue identifier is the queue used to issue the command.", UNH15 + ", Test 5.2")],
      [("The completion's queue differs from the command's.", R2N + ", family B10")],
      "a completion with another queue: the tree joins a completion to its command by queue and command identifier, so such a completion joins no command and is not under any command row", ["R2 B10"], belongs=["behaviour_08"])
_none("behaviour_11", BEHAVIOUR, "A head pointer fault", "The submission queue head the drive reports moves backwards, passes the host's tail or stops.",
      [("The specification: the head pointer tells which entries were consumed.", B21 + ", section 4.2")],
      [("Per submission queue, in completion order, the head must only move forward.", R2N + ", family B11; " + R4N + ", rule 3")],
      "the export has no column for the submission queue head pointer of the completion (SQHD)", ["R2 B11", "R4 rule 3"])
_none("behaviour_12", BEHAVIOUR, "More open commands than the queue allows", "More commands were open on a queue than its size minus one.",
      [("The specification: a full queue holds one entry less than its size.", B21 + ", section 3.3.1 (sub-number not verified)")],
      [("A running count of open commands on a queue above its size minus 1.", R2N + ", family B12")],
      "each command's completion time for a running count, and the queue size from its Create row; a reset in between cannot be seen at the command level, so the count would be wrong after one", ["R2 B12"],
      seeded_reason="not seeded yet: the running count of open commands per queue is not built, and a reset (not a command) empties every queue")
_none("behaviour_13b", BEHAVIOUR, "Order and dependency faults other than the read after a deallocate",
      "I/O before a queue or the controller was ready, I/O to a namespace that is not attached, a write after a write-protect that returns success, a fused pair that is not adjacent.",
      [("The specification states each of these orders.", B21 + ", sections 3.4 and 3.5; " + N11)],
      [("A command related to the earlier command that set the state.", R2N + ", family B13 (b) to (e); " + R4N + ", rules 14, 18")],
      "the fuse bits of a command, the list of active namespaces and the controller's ready state: none is a column of the command export; the statuses the drive returns in these cases are found by the status families", ["R2 B13 (b)-(e)", "R4 rules 14, 18"])
_none("behaviour_14b", BEHAVIOUR, "A late verdict: an event or a log entry that names an earlier command",
      "An Asynchronous Event Request completed with an error event, or a Get Log Page returned Error Information entries that name earlier commands.",
      [("The specification: details of an internal error should be reported as an asynchronous event; a completion with 'more' set announces an Error Information log entry.", B23 + ", Figures 100 and 102")],
      [("The event type is in the first four bytes of the event's completion; the log entries are in the data of the Get Log Page.", R2N + ", family B14 (b) and (c)")],
      "the decoded data of the Get Log Page, and the layout of the event's result, which the research did not quote (to be confirmed)", ["R2 B14 (b), (c)", "R1 check on M"])
_none("protocol_04", PROTOCOL, "The phase tag did not flip", "The phase bit of the completions of one completion queue is not inverted on each pass.",
      [("The specification: the controller inverts the phase tag each time the completion queue wraps.", B23 + ", section 4.2.4")],
      [("Within one pass of a completion queue the bit differs, or it does not flip after exactly the queue's size.", R4N + ", rule 4")],
      "the order of the completions in each completion queue and the queue's size across a reset: the phase column is on the completion rows, but the pass over a whole completion queue is not built",
      ["R4 rule 4"], seeded_reason="not seeded yet: the pass over the completion rows of one completion queue in their order is not built")
_none("protocol_09", PROTOCOL, "A reserved value was sent in a command", "The host sent reserved fuse bits, a reserved data pointer selector or a reserved command code.",
      [("The specification: reserved coded values shall not be sent.", B20 + ", section 1.4.1.6" + TBC)],
      [("Fused bits 11b, selector 11b, or a reserved opcode, answered with success.", R4N + ", rule 9")],
      "the fuse bits and the data pointer selector of the command: the export has no column for them (a reserved command code answered with an error is found by the family 'not understood or not supported')", ["R4 rule 9"])
_none("protocol_10", PROTOCOL, "A namespace identifier that is not valid for the command", "The command names namespace 0, an identifier above the count, or an inactive namespace.",
      [("Sources differ on the status: a device model returns Invalid Namespace or Format for the broadcast value where the specification says the controller should return Invalid Field in Command; the conformance plan only demands 'not successful'. A rule must accept both.",
        "research note R4, section 5, inferences")],
      [("The namespace identifier against the list of active namespaces.", R4N + ", rule 10")],
      "the list of active namespaces (the data of an Identify command), which the command export does not carry", ["R4 rule 10"], belongs=["status_07"])
_none("protocol_12", PROTOCOL, "A data transfer above the maximum transfer size", "The command moves more data than the controller's limit.",
      [("The specification: the host should not exceed the maximum data transfer size.", B20 + ", section 5.17.2.1" + TBC)],
      [("Block count times block size above the limit; Write Zeroes and Write Uncorrectable move no data and are exempt.", R4N + ", rule 12")],
      "the block size of the namespace and the controller's limit (Identify data), which the command export does not carry", ["R4 rule 12"])
_none("protocol_15", PROTOCOL, "Protection information that does not fit the namespace's format", "The protection bits or the reference tag of a command do not fit the format.",
      [("The specification: such a command is answered with Invalid Protection Information.", N11 + ", section 5.3" + TBC)],
      [("The protection bits against the namespace's protection setting.", R4N + ", rule 15")],
      "the protection setting of the namespace (Identify data); the status the drive returns is found by the family 'parameters rejected'", ["R4 rule 15"], belongs=["status_08"])
_none("protocol_16", PROTOCOL, "Queue creation, deletion and Number of Queues out of order",
      "A queue identifier in use was created again, a completion queue was deleted before its submission queues, or the Number of Queues was set after queues existed.",
      [("The specification states the order and the status for each case; sources differ on the status for completion queue 0 (a device model uses one code where the specification and the conformance plan split two).",
        B20 + ", sections 5.4 to 5.7 and 5.27.1.5" + TBC + "; research note R4, section 5, inferences")],
      [("The Create, Delete and Set Features rows against a map of the queues built from earlier rows.", R4N + ", rules 16, 17, 18, 20")],
      "the controller's resets: a reset deletes every queue and is not a command, so at the command level a queue created again after a reset cannot be told from a queue identifier in use (S17 holds four such set-ups)",
      ["R4 rules 16, 17, 18, 20"], belongs=["status_20", "behaviour_04"])
_none("protocol_22", PROTOCOL, "A transient transport error four or more times, and a retry sooner than the delay",
      "The same operation failed four or more times with Transient Transport Error, or was sent again before the delay the completion selected.",
      [("The specification: four or more transient transport errors should be treated as persistent; the host should not retry before the selected delay, but it is not an error to do so.", B23 + ", Figures 100 and 102")],
      [("Count the failures of one operation; compare the resubmission time with the selected delay.", R1N + ", cross-cutting checks")],
      "the drive's three delay values (Identify data) for the delay; the count of repeated failures is not built yet", ["R1 checks 3, 4, 7"], belongs=["status_11", "behaviour_09"],
      seeded_reason="not seeded yet: the count of repeated transient transport errors is not built, and the delay values are not in the command export")

BY_ID = {f["id"]: f for f in FAMILIES}
NOT_SEEDED = [{"id": f["id"], "name": f["name"], "group": f["group"], "why": f["not_checkable"]} for f in FAMILIES if not f["checkable"]]
# the detector's 13 command-level rules (nvme_hier/rules.py), each with its family; None = it stays the detector's own rule, in no family, and why
DETECTOR_MAP = {
    "cmd.timeout": (["behaviour_01", "behaviour_02", "behaviour_05", "status_13"], "its four cases are four families: never completed, over the host's limit, slower than usual, aborted by the host"),
    "cmd.read_failure": (["status_01"], "a Read with an error status; its top case is the read that could not be recovered; every other status of a Read is in the family of that status"),
    "cmd.status_error": ([f["id"] for f in FAMILIES if f["group"] == STATUS] + ["protocol_05"], "any status that is not success: each such row is in exactly one status family, or in the rule for reserved values"),
    "cmd.incomplete": (["behaviour_01"], "no completion row under the command: the same commands as never completed, without the host's limit"),
    "cmd.not_fetched": (["behaviour_01"], "where the cycle of a command stopped: context of a command that never completed"),
    "cmd.doorbell_missing": (["behaviour_01"], "where the cycle of a command stopped: context, a suspect only"),
    "cmd.no_interrupt": (["behaviour_01"], "a step of the cycle after the completion: context, a suspect only"),
    "cmd.latency_over_limit": (["behaviour_02"], "the analyzer's Time Delta against the limit; the library and the detector disagree on what Time Delta measures, so the family uses the completion row's time instead"),
    "cmd.deallocate_readback": (["behaviour_13"], "the read after a deallocate"),
    "cmd.write_zeroes_readback": (["behaviour_13"], "the read after Write Zeroes"),
    "cmd.analyzer_error": (None, "the analyzer's own error cell: not a rule of the NVMe protocol, so it is in no family and stays the detector's rule"),
    "cmd.analyzer_warning": (None, "the analyzer's own warning cell: not a rule of the NVMe protocol, so it is in no family and stays the detector's rule"),
    "cmd.bytes_short": (None, "an inference that assumes 512-byte blocks: the research gives no such rule, so it is in no family and stays the detector's rule"),
}

OUTPUT_COLUMNS = [
    ("rule family", "the name of the rule that found the row"),
    ("file", "the file the row is in: the NVMe command file"),
    (ROW_COLUMN, "the row of the NVMe command file that was found, counted under the header (row 1 is line 2 of the file); one line per found row, no row twice"),
    ("what was found", "the reason in plain words, with the values of this row"),
    ("whose fault it points to", "the host, the controller, or that it cannot be told from this rule alone"),
    ("command number (column NVMe Cmd)", "the analyzer's own number of the command"),
    ("time stamp (ps)", "the command's Time Stamp as a whole number of picoseconds (1 second = 1,000,000,000,000 picoseconds); it orders the rows"),
    ("the values that matched", "the cells the pattern was checked on, as the export wrote them, each with its column"),
    ("data row in its file", "the same row of the NVMe command file once more, under the name the detector's results use"),
    ("command", "which command it is, named from its command code (column OPC) by the NVMe specification's lists"),
    ("submission queue (column SQID)", "the queue the command was sent on: 0 is the admin queue"),
    ("command identifier (column CID)", "the identifier the host gave the command"),
    ("linked findings", "the other findings of the same episode (the timeout chain), or empty"),
]


# ---------------------------------------------------------------------------------------------- reading cells
def num(cell):
    """A cell as a whole number -> (value or None, readable). '0x02 (Read)' and '2' are 2; '81h' is 129; '' is (None, True); 'zz' is (None, False)."""
    if cell is None:
        return None, True
    t = str(cell).strip()
    if not t:
        return None, True
    first = t.split()[0].rstrip(",;")
    try:
        if first.lower().startswith("0x"):
            return int(first, 16), True
        if first[-1] in "hH" and len(first) > 1:
            return int(first[:-1], 16), True
        return int(first), True
    except ValueError:
        return None, False


def cell(row, names):
    """The first non-empty cell of a row under one of the names a column has (the samples' and the real export's) -> (text or None, name)."""
    for n in names:
        v = row.get(n)
        if v is not None and str(v).strip() != "":
            return v, n
    return None, names[0]


def command(row):
    """What the rules read of one command row, from its cells as the export wrote them."""
    c = {"row": row.row, "number": row.number, "t_ps": row.time_ps, "damaged": [], "cells": {}}
    for key, col in (("opc", C_OPC), ("sqid", C_SQID), ("cid", C_CID), ("nsid", C_NSID), ("slba", C_SLBA), ("nlb", C_NLB), ("sct", C_SCT), ("sc", C_SC)):
        text, name = cell(row, col["names"])
        v, ok = num(text)
        c[key] = v
        if text is not None:
            c["cells"][name] = text
            if not ok:
                c["damaged"].append((name, text))
    c["admin"] = c["sqid"] == 0
    c["name"] = N.opcode_name(c["opc"], c["sqid"]) if c["opc"] is not None else "a command without a command code"
    return c


def _is(name, ops):
    return any(name == o or name.startswith(o + " ") or name.startswith(o + "(") for o in ops)


def _reserved(sct, sc):
    if sct in (4, 5, 6):
        return True
    e = NE.lookup(sct, sc)
    return bool(e) and e.get("kind") == "reserved"


def _matches(m, admin, name, sct, sc):
    q, t, codes, ops = m
    return t == sct and sc in codes and (q == "any" or (q == "admin") == bool(admin)) and (not ops or _is(name, ops))


_STATUS_FAMILIES = [f for f in FAMILIES if f["check"]["kind"] in ("status", "chain") and f["check"].get("match")]
_SPECIFIC = [(f["id"], m) for f in _STATUS_FAMILIES for m in f["check"]["match"] if m[3]]
_GENERAL = [(f["id"], m) for f in _STATUS_FAMILIES for m in f["check"]["match"] if not m[3]]


def family_of_status(admin, name, sct, sc):
    """The one family a completion status belongs to -> its id, or None for success and the statuses that are not failures.
    admin: the command was on queue 0; name: the command's name from the application's lists (nvme_hier/names.py)."""
    sct, sc = sct or 0, sc or 0
    if _is_exception(admin, sct, sc):
        return None
    for fid, m in _SPECIFIC + _GENERAL:             # a status tied to one command first, then the general ones
        if _matches(m, admin, name, sct, sc):
            return fid
    if _reserved(sct, sc):
        return "protocol_05"
    return "status_24"


def _hx(sct, sc):
    return "%Xh/%02Xh" % (sct or 0, sc or 0)


def _queue(c):
    return "the admin queue" if c["admin"] else ("I/O queue %s" % c["sqid"] if c["sqid"] is not None else "a queue the row does not name")


def completion_row(tree, row):
    """The command's own completion row at the NVMe transaction level (the first Admin or I/O Completion Queue Entry under it), or None."""
    if "nvme_transaction" not in tree.present:
        return None
    for n in tree.children("nvme_command", row, "nvme_transaction"):
        if N.part_key(n.get("Type")) == "cqe":
            return n
    return None


def bits(tree, row):
    """'do not retry', 'more' and the retry delay of a command, from its completion row -> ({"DNR", "M", "CRD"} or None, the sentence when they cannot be read)."""
    if "nvme_transaction" not in tree.present:
        return None, "the bits were not read: the NVMe transactions file is not loaded"
    n = completion_row(tree, row)
    if n is None:
        return None, "the bits were not read: the command has no completion row"
    out = {k: num(n.get(k))[0] for k in ("DNR", "M", "CRD")}
    if out["DNR"] is None:
        return None, "the bits were not read: the completion row has no value in the column DNR"
    return dict(out, row=n.row), ""


def _finding(f, c, reason, values, linked=""):
    return {"row": c["row"], "number": c["number"], "t_ps": c["t_ps"], "reason": reason, "values": values, "command": c["name"], "sqid": c["sqid"], "cid": c["cid"],
            "fault": f["fault"], "linked": linked, "family": f["id"]}


def _bits_words(b, why):
    if b is None:
        return why
    return "do not retry = %s, more = %s, retry delay = %s (completion row %s of the NVMe transactions file)" % (b["DNR"], b["M"] if b["M"] is not None else "not given", b["CRD"] if b["CRD"] is not None else "not given", b["row"])


# ---------------------------------------------------------------------------------------------- the one implementation
def find(family, tree, info=None):
    """The rows of the recording one family finds, streamed: dicts {"row" (of the NVMe command file), "reason", "values", "fault", "linked", ...}.
    info (a dict) is filled as the pass goes: rows_read, damaged_cells, can_be_checked, why_not (the sentence, never silent)."""
    f = BY_ID[family] if isinstance(family, str) else family
    info = info if info is not None else {}
    info.update({"family": f["id"], "rows_read": 0, "damaged_cells": 0, "can_be_checked": True, "why_not": "", "notes": []})
    kind = f["check"]["kind"]
    if kind == "none":
        info.update(can_be_checked=False, why_not=f["not_checkable"])
        return
    if "nvme_command" not in tree.present:
        info.update(can_be_checked=False, why_not="cannot be checked on this recording: the NVMe command file is not loaded")
        return
    need_ntx = [n for n in f["needs"] if n is NEED_NTX or (n.get("what") == NEED_NTX["what"] and not n.get("optional"))]
    if need_ntx and "nvme_transaction" not in tree.present:
        info.update(can_be_checked=False, why_not=need_ntx[0]["says"])
        return
    yield from {"status": _find_status, "chain": _find_chain, "detector": _find_detector, "bits": _find_bits, "retry_after_dnr": _find_retry,
                "cid_reuse": _find_cid, "lba_range": _find_lba, "prp_offset": _find_prp, "setup_failed": _find_setup}[kind](f, tree, info)


def _commands(tree, info):
    for row in tree.rows("nvme_command"):
        info["rows_read"] += 1
        c = command(row)
        info["damaged_cells"] += len(c["damaged"])
        yield row, c


def _no_status_seen(info, seen):
    if info["rows_read"] and not seen:
        info.update(can_be_checked=False, why_not=NEED_STATUS["says"])


def _status_reason(f, c, tree):
    e = NE.lookup(c["sct"] or 0, c["sc"] or 0)
    b, why = bits(tree, c["row"])
    reason = "%s on %s completed with status %s %s: %s %s." % (c["name"], _queue(c), _hx(c["sct"], c["sc"]), (e or {}).get("name") or "(a value the catalogue does not name)",
                                                               f["what"].rstrip("."), "(%s)" % _bits_words(b, why))
    values = dict(c["cells"])
    if b:
        values.update({"DNR": b["DNR"], "M": b["M"], "CRD": b["CRD"]})
    return reason, values


def _find_status(f, tree, info):
    seen = 0
    for _row, c in _commands(tree, info):
        bad = [d for d in c["damaged"] if d[0] in C_SCT["names"] + C_SC["names"]]
        if bad:
            seen += 1
            if f["check"].get("reserved"):
                yield _finding(f, c, "%s on %s: the status cell %s holds '%s', which is not a number: the status of this command cannot be read." % (
                    c["name"], _queue(c), bad[0][0], str(bad[0][1])[:60]), dict(c["cells"]))
            continue
        if c["sct"] is None and c["sc"] is None:
            continue
        seen += 1
        if family_of_status(c["admin"], c["name"], c["sct"], c["sc"]) == f["id"]:
            reason, values = _status_reason(f, c, tree)
            yield _finding(f, c, reason, values)
    _no_status_seen(info, seen)


def _find_setup(f, tree, info):
    seen = 0
    for row, c in _commands(tree, info):
        if c["sct"] is None and c["sc"] is None:
            continue
        seen += 1
        if not c["admin"] or not (c["sct"] or c["sc"]) or _is_exception(True, c["sct"] or 0, c["sc"] or 0):
            continue
        fid_text, _n = cell(row, C_FID["names"])
        is_set = _is(c["name"], ["Set Features"]) and num(fid_text)[0] == f["check"]["set_features_fid"]
        if _is(c["name"], f["check"]["ops"]) or is_set:
            reason, values = _status_reason(f, c, tree)
            if fid_text is not None:
                values["FID"] = fid_text
            yield _finding(f, c, reason.replace(f["what"].rstrip("."), "I/O depends on this admin command"), values)
    _no_status_seen(info, seen)


def _detector_rows(tree, rules):
    """The detector's findings of some rules at the command level, in file order: (command row, the detector's sentence, the kind in its detail)."""
    try:
        marks = ",".join("?" * len(rules))
        cur = tree.con.execute("SELECT rowid, name, detail, severity FROM finding WHERE rule IN (%s) AND level = 'nvme_command' ORDER BY rowid, id" % marks, list(rules))
    except Exception:      # noqa: BLE001 - no finding table: the detector has not run
        return None
    return cur


def _find_detector(f, tree, info):
    rules = f["check"]["rule"] if isinstance(f["check"]["rule"], list) else [f["check"]["rule"]]
    cur = _detector_rows(tree, rules)
    if cur is None:
        info.update(can_be_checked=False, why_not=NEED_DETECTOR["says"])
        return
    kinds, before = f["check"].get("detail_kinds"), None
    for rid, name, detail, sev in cur:
        info["rows_read"] += 1
        if rid == before:                                   # one line per found row: a row two of the detector's rules filed is listed once
            continue
        try:
            k = (json.loads(detail) if detail else {}).get("kind")
        except ValueError:
            k = None
        if kinds and k not in kinds:
            continue
        try:
            c = command(tree.get("nvme_command", rid))
        except LookupError:
            continue
        before = rid
        yield _finding(f, c, "%s.%s" % (str(name).rstrip("."), "" if sev == "error" else " (the detector files this as: %s)" % sev), dict(c["cells"]))


def _find_bits(f, tree, info):
    test = f["check"]["test"]
    where = {"dnr_disagrees": "n.dnr = 1 AND COALESCE(n.sct, 0) = 0 AND COALESCE(n.sc, 0) IN (0, 33, 132)", "crd_with_dnr": "n.dnr = 1 AND COALESCE(n.crd, 0) != 0"}[test]
    base = "FROM ntx n WHERE n.parent_level = 'nvme_command' AND n.parent IS NOT NULL AND n.type LIKE '%Completion Queue Entry%'"
    total, with_dnr = tree.con.execute("SELECT COUNT(*), SUM(CASE WHEN n.dnr IS NOT NULL THEN 1 ELSE 0 END) " + base).fetchone()
    info["rows_read"] = total or 0
    if total and not with_dnr:
        info.update(can_be_checked=False, why_not=NEED_BITS["says"])
        return
    if not total:
        info["notes"].append("no command of this recording has a completion row")
    before = None
    for crow, nrow, sct, sc, dnr, more, crd in tree.con.execute("SELECT n.parent, n.rowid_file, n.sct, n.sc, n.dnr, n.more, n.crd " + base + " AND " + where + " ORDER BY n.parent, n.rowid_file"):
        if crow == before:                                  # one line per found row: a command with two such completion rows is listed once
            continue
        before = crow
        try:
            c = command(tree.get("nvme_command", crow))
        except LookupError:
            continue
        if test == "dnr_disagrees":
            said = "should be 0 on a success" if not (sct or sc) else "shall be 0 with %s" % _status_name(0, sc)
            reason = "%s on %s: its completion row (row %s of the NVMe transactions file) has 'do not retry' = 1 with status %s; the specification says it %s." % (c["name"], _queue(c), nrow, _hx(sct, sc), said)
        else:
            reason = "%s on %s: its completion row (row %s of the NVMe transactions file) gives retry delay %s together with 'do not retry' = 1; the delay only has meaning when 'do not retry' is 0." % (
                c["name"], _queue(c), nrow, crd)
        yield _finding(f, c, reason, dict(c["cells"], DNR=dnr, M=more, CRD=crd, **{"completion row": nrow}))


def _find_retry(f, tree, info):
    failed, any_bits, failures = {}, False, 0
    for _row, c in _commands(tree, info):
        if c["admin"] or c["slba"] is None or c["nlb"] is None or c["opc"] is None:
            continue
        key = (c["opc"], c["nsid"], c["slba"], c["nlb"])
        if key in failed:
            first = failed[key]
            yield _finding(f, c, "%s of blocks %s to %s on namespace %s was sent again (row %s) although the same operation in row %s had failed with status %s and 'do not retry' = 1." % (
                c["name"], c["slba"], c["slba"] + c["nlb"], c["nsid"], c["row"], first["row"], first["status"]),
                dict(c["cells"], **{"row of the failed command": first["row"], "its status": first["status"], "its DNR": 1}))
        if (c["sct"] or c["sc"]) and not _is_exception(False, c["sct"] or 0, c["sc"] or 0):
            failures += 1
            b, _why = bits(tree, c["row"])
            if b is not None:
                any_bits = True
                if b["DNR"] == 1 and len(failed) < KEPT_MOST:
                    failed[key] = {"row": c["row"], "status": _hx(c["sct"], c["sc"])}
    if failures and not any_bits:
        info.update(can_be_checked=False, why_not=NEED_BITS["says"])


def _first_completion_ps(tree, row):
    r = tree.con.execute("SELECT MIN(t_ps) FROM ntx WHERE parent_level = 'nvme_command' AND parent = ? AND type LIKE '%Completion Queue Entry%' AND t_ps IS NOT NULL", (int(row),)).fetchone()
    return r[0] if r else None


def _find_cid(f, tree, info):
    info["notes"].append(CID_LIMIT_SAYS)          # never silent about the half the tree cannot show (see CID_LIMIT)
    last = {}
    for _row, c in _commands(tree, info):
        if c["sqid"] is None or c["cid"] is None:
            continue
        if c["cid"] == 0xFFFF:
            yield _finding(f, c, "%s on %s uses the command identifier FFFFh, which the specification advises against (the Error Information log uses it for 'no command'). Advice only." % (c["name"], _queue(c)), dict(c["cells"]))
        key = (c["sqid"], c["cid"])
        p = last.get(key)
        if p is not None and p[1] and c["t_ps"] is not None and c["cid"] != 0xFFFF:        # one line per found row
            end = _first_completion_ps(tree, p[0])
            if end is not None and end > c["t_ps"]:
                yield _finding(f, c, "%s on %s was sent with command identifier %s while the command in row %s, with the same queue and identifier, was still open: its completion came %s picoseconds after this command was sent." % (
                    c["name"], _queue(c), c["cid"], p[0], "{:,}".format(end - c["t_ps"])),
                    dict(c["cells"], **{"row of the earlier command": p[0], "its completion (ps)": end, "this command sent (ps)": c["t_ps"]}))
        if key in last or len(last) < KEPT_MOST * 4:
            last[key] = (c["row"], c["sct"] is not None or c["sc"] is not None)


def _find_lba(f, tree, info):
    size = {}
    for row, c in _commands(tree, info):
        if c["admin"]:
            text, _n = cell(row, C_NSZE["names"])
            v, ok = num(text)
            if _is(c["name"], ["Identify"]) and v is not None and ok and not (c["sct"] or c["sc"]) and len(size) < KEPT_MOST:
                size[c["nsid"]] = (v, c["row"])
            continue
        if c["slba"] is None or c["nlb"] is None or c["nsid"] not in size or _is(c["name"], ["Dataset Management"]):
            continue
        nsze, where = size[c["nsid"]]
        if c["slba"] + c["nlb"] + 1 > nsze:
            if c["sct"] is None and c["sc"] is None:
                said = "the drive gave no completion"
            elif (c["sct"] or 0, c["sc"] or 0) == (0, 0x80):
                said = "the drive answered LBA Out of Range (0h/80h), as the specification expects: the host's fault"
            elif not (c["sct"] or c["sc"]):
                said = "the drive answered Successful Completion: the controller is at fault as well"
            else:
                said = "the drive answered another error (%s %s): a weaker finding, because the specification leaves the status to the vendor when two faults coincide" % (_hx(c["sct"], c["sc"]), _status_name(c["sct"] or 0, c["sc"] or 0))
            yield _finding(f, c, "%s on %s addresses blocks %s to %s of namespace %s, whose size is %s blocks (Identify in row %s): the range goes past the end; %s." % (
                c["name"], _queue(c), c["slba"], c["slba"] + c["nlb"], c["nsid"], "{:,}".format(nsze), where, said), dict(c["cells"], NSZE=nsze, **{"row of the Identify": where}))
    if info["rows_read"] and not size:
        info.update(can_be_checked=False, why_not=f["needs"][0]["says"])


def _find_prp(f, tree, info):
    seen = 0
    for row, c in _commands(tree, info):
        text, _n = cell(row, C_PRP1["names"])
        v, ok = num(text)
        if text is None:
            continue
        seen += 1
        if ok and v is not None and v & 3:
            yield _finding(f, c, "%s on %s has the first data pointer %s, whose two lowest bits are not 0: a PRP entry must be aligned to four bytes. The drive answered %s." % (
                c["name"], _queue(c), text, ("status %s" % _hx(c["sct"], c["sc"])) if c["sct"] is not None or c["sc"] is not None else "with no completion"), dict(c["cells"], PRP1=text))
    if info["rows_read"] and not seen:
        info.update(can_be_checked=False, why_not=f["needs"][0]["says"])


ABORT_OPC, AER = 0x08, set(RL.WAITS_BY_DESIGN)


def episodes(tree, info=None):
    """The timeout chain as episodes, in ONE pass over the command rows in file order. An episode is the stretch of rows between two set-ups of
    the controller (a successful Set Features 07h after an I/O queue was created). Yields each closed episode that holds something:
    {"n", "from", "to", "never": [command facts], "open_at_end": k, "aborts": [...], "aborted": [...], "reset": command facts or None, "words"}."""
    info = info if info is not None else {}
    info.setdefault("rows_read", 0)
    info.setdefault("damaged_cells", 0)
    never_by_detector, cur = {}, _detector_rows(tree, ["cmd.timeout"])
    info["detector"] = cur is not None
    for rid, name, detail, _sev in cur or ():
        if '"never completed"' in (detail or "") and len(never_by_detector) < KEPT_MOST:
            never_by_detector[rid] = name
    ep = {"n": 1, "from": None, "to": None, "never": [], "open": 0, "aborts": [], "aborted": [], "reset": None}
    queue_created, fid_seen, set_features = False, False, 0

    def close(ep, reset):
        ep["reset"] = reset
        if not (ep["never"] or ep["aborts"] or ep["aborted"]):
            return None
        rows = lambda xs: ", ".join(str(x["row"]) for x in xs[:SHOWN]) + (" and %d more" % (len(xs) - SHOWN) if len(xs) > SHOWN else "")      # noqa: E731
        parts = []
        if ep["never"]:
            parts.append("%d command%s never completed (row%s %s of the NVMe command file)" % (len(ep["never"]), "" if len(ep["never"]) == 1 else "s", "" if len(ep["never"]) == 1 else "s", rows(ep["never"])))
        if ep["aborts"]:
            parts.append("the host sent %d Abort command%s (row%s %s)" % (len(ep["aborts"]), "" if len(ep["aborts"]) == 1 else "s", "" if len(ep["aborts"]) == 1 else "s", rows(ep["aborts"])))
        if ep["aborted"]:
            parts.append("%d command%s completed as aborted (row%s %s)" % (len(ep["aborted"]), " was" if len(ep["aborted"]) == 1 else "s were", "" if len(ep["aborted"]) == 1 else "s", rows(ep["aborted"])))
        end = ("the host then set the controller up again at row %s (Set Features, Number of Queues, completed with success after I/O queues existed: the specification allows that only after a reset)" % reset["row"]
               if reset else "the recording ended without a new set-up of the controller")
        ep["words"] = "Episode %d of the recording (command rows %s to %s): %s; %s." % (ep["n"], ep["from"], ep["to"], "; ".join(parts), end)
        return ep
    for row, c in _commands(tree, info):
        if ep["from"] is None:
            ep["from"] = c["row"]
        if c["admin"] and _is(c["name"], ["Create I/O Submission Queue", "Create I/O Completion Queue"]) and not (c["sct"] or c["sc"]) and c["sct"] is not None:
            queue_created = True
        if c["admin"] and _is(c["name"], ["Set Features"]):
            set_features += 1
            fid_text, _n = cell(row, C_FID["names"])
            fid_seen = fid_seen or fid_text is not None
            if num(fid_text)[0] == 7 and queue_created and c["sct"] is not None and not (c["sct"] or c["sc"]):
                done = close(ep, dict(c, lost=len(ep["never"])))
                if done:
                    yield done
                ep = {"n": ep["n"] + 1, "from": c["row"], "to": None, "never": [], "open": 0, "aborts": [], "aborted": [], "reset": None}
                queue_created = False
        ep["to"] = c["row"]
        no_status = c["sct"] is None and c["sc"] is None and not c["damaged"]
        if c["admin"] and c["opc"] == ABORT_OPC:
            b = None
            if not no_status:
                n = completion_row(tree, c["row"])
                dw0, ok = num(n.get("DW0")) if n is not None else (None, True)
                b = None if dw0 is None or not ok else dw0 & 1
            if len(ep["aborts"]) < KEPT_MOST:
                ep["aborts"].append(dict(c, answered=not no_status, not_performed=b, open_before=[x["row"] for x in ep["never"][-SHOWN:]]))
        if no_status and not (c["admin"] and c["opc"] in AER):
            if c["row"] in never_by_detector and len(ep["never"]) < KEPT_MOST:
                ep["never"].append(dict(c, detector=never_by_detector[c["row"]]))
            else:
                ep["open"] += 1
        elif (c["sct"] or 0, c["sc"] or 0) in ((0, 0x07), (0, 0x08), (0, 0x1B)) and len(ep["aborted"]) < KEPT_MOST:
            ep["aborted"].append(c)
    info["fid_seen"], info["set_features"] = fid_seen, set_features
    done = close(ep, None)
    if done:
        yield done


def _find_chain(f, tree, info):
    role = f["check"]["role"]
    for ep in episodes(tree, info):
        link = ep["words"]
        if role == "never":
            for c in ep["never"]:
                yield _finding(f, c, "%s." % str(c["detector"]).rstrip("."), dict(c["cells"]), link)
        elif role == "abort":
            for c in ep["aborts"]:
                if not c["answered"]:
                    out = "the Abort itself got no completion"
                else:
                    bit = {None: "the outcome bit of its completion row could not be read", 0: "bit 0 of its completion is 0: the drive says it aborted the command at once",
                           1: "bit 0 of its completion is 1: the drive did not abort the command at once"}[c["not_performed"]]
                    out = "the Abort completed with status %s (%s); %s" % (_hx(c["sct"], c["sc"]), _status_name(c["sct"] or 0, c["sc"] or 0), bit)
                was = ("it was sent while the command%s in row%s %s had no completion" % ("" if len(c["open_before"]) == 1 else "s", "" if len(c["open_before"]) == 1 else "s", ", ".join(map(str, c["open_before"])))
                       if c["open_before"] else "no command judged as never completed was open before it in this episode")
                yield _finding(f, c, "The host sent an Abort (row %s): %s; %s. Which command it names is not a column of the NVMe command export." % (c["row"], out, was), dict(c["cells"]), link)
        elif role == "aborted":
            for c in ep["aborted"]:
                if family_of_status(c["admin"], c["name"], c["sct"], c["sc"]) == f["id"]:
                    reason, values = _status_reason(f, c, tree)
                    yield _finding(f, c, reason, values, link)
        elif role == "reset" and ep["reset"] is not None and ep["never"]:
            c = ep["reset"]
            yield _finding(f, c, "The host set the controller up again at row %s (Set Features, Number of Queues, completed with success after I/O queues existed) while %d command%s sent before it had no completion (row%s %s)." % (
                c["row"], len(ep["never"]), "" if len(ep["never"]) == 1 else "s", "" if len(ep["never"]) == 1 else "s",
                ", ".join(str(x["row"]) for x in ep["never"][:SHOWN])), dict(c["cells"], FID=7, **{"commands lost": len(ep["never"])}), link)
    if not info.get("detector") and role in ("never", "reset"):
        info.update(can_be_checked=False, why_not=NEED_DETECTOR["says"])
    elif role == "reset" and info.get("set_features") and not info.get("fid_seen"):
        info.update(can_be_checked=False, why_not=f["needs"][0]["says"])


# ---------------------------------------------------------------------------------------------- as the code of a library item
def code_for(family_id):
    """The code of a family's item as a procedure on the tree (run(tree, out_csv)): the application's reference implementation."""
    if family_id not in BY_ID or not BY_ID[family_id]["checkable"]:
        raise ValueError("no such rule family that can be run")
    return ("from nvme_hier import command_error_rules\n\n"
            "FAMILY = %r        # %s\n\n\n"
            "def run(tree, out_csv):\n"
            "    # every step of the procedure is done by the application's reference implementation of this rule family (%s)\n"
            "    return command_error_rules.run_on_tree(tree, out_csv, FAMILY)\n") % (family_id, BY_ID[family_id]["name"], THIS_FILE)


def _line(f, x):
    return [f["name"], CMD_FILE_NAME, x["row"], x["reason"], x["fault"], x["number"], x["t_ps"], json.dumps(x["values"], ensure_ascii=False, default=str), x["row"],
            x["command"], x["sqid"], x["cid"], x["linked"]]


def run_on_tree(tree, out_csv, family_id):
    """Run one family on the tree and write the found rows to out_csv, one at a time (nothing is held in memory) -> the summary of the run."""
    f = BY_ID[family_id]
    info, n = {}, 0
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow([c for c, _m in OUTPUT_COLUMNS])
        for x in find(f, tree, info):
            w.writerow(_line(f, x))
            n += 1
    if not info["can_be_checked"]:
        words = "The rule '%s' %s." % (f["name"], info["why_not"])
    elif n:
        words = "The rule '%s' found %s row%s of the NVMe command file (%s rows read)." % (f["name"], "{:,}".format(n), "" if n == 1 else "s", "{:,}".format(info["rows_read"]))
    else:
        words = "The rule '%s' found no row in this recording (%s rows read): an empty list is a result here, not a failure." % (f["name"], "{:,}".format(info["rows_read"]))
    if info["can_be_checked"] and info.get("notes"):
        words += " " + " ".join(dict.fromkeys(str(x) for x in info["notes"]))      # what this run could not see, said with the result
    return {"family": f["id"], "name": f["name"], "rows_read": info["rows_read"], "rows_written": n, "can_be_checked": info["can_be_checked"], "why_not": info["why_not"],
            "damaged_cells": info["damaged_cells"], "notes": info.get("notes") or [], "words": words, "tree_db": tree.db, "is_an_error_rule": True}


def reference_rows(db_path, family_id, immutable=False):
    """The rows the reference implementation finds on a recording's tree -> (sorted row numbers, info)."""
    from . import tree_api as T
    tree = T.Tree(db_path, immutable=immutable)
    try:
        info = {}
        return sorted({x["row"] for x in find(BY_ID[family_id], tree, info)}), info
    finally:
        tree.close()


def sql_counts(db_path):
    """A second count made another way, for the families that have one: SQL on the loader's typed columns (not the cells the reference reads)
    -> {family id: rows}. Status families from the command table; the two families on the bits from the completion rows; None = no table."""
    import sqlite3
    con = sqlite3.connect("file:%s?mode=ro" % db_path.replace("?", "%3f").replace("#", "%23"), uri=True)
    try:
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if "cmd" not in tables:
            return None
        out = {f["id"]: 0 for f in FAMILIES if f["group"] == STATUS or f["id"] == "protocol_05"}
        for adm, opc, sct, sc, k in con.execute("SELECT (sqid = 0), opc, sct, sc, COUNT(*) FROM cmd WHERE sct IS NOT NULL OR sc IS NOT NULL GROUP BY 1, 2, 3, 4"):
            fid = family_of_status(bool(adm), N.opcode_name(opc, 0 if adm else 1) if opc is not None else "", sct, sc)
            if fid in out:
                out[fid] += k
        if "ntx" in tables:
            base = "SELECT COUNT(*) FROM ntx n WHERE n.parent_level = 'nvme_command' AND n.parent IS NOT NULL AND n.type LIKE '%Completion Queue Entry%' AND "
            base = base.replace("COUNT(*)", "COUNT(DISTINCT n.parent)")
            out["protocol_06"] = con.execute(base + "n.dnr = 1 AND COALESCE(n.sct, 0) = 0 AND COALESCE(n.sc, 0) IN (0, 33, 132)").fetchone()[0]
            out["protocol_07"] = con.execute(base + "n.dnr = 1 AND COALESCE(n.crd, 0) != 0").fetchone()[0]
        return out
    finally:
        con.close()


def compare_with_reference(out_csv, db_path, family_id, immutable=False):
    """What the Tester says of ANY code of a family's item (the Coder's, or the application's own): the rows its result names against the rows
    the reference implementation finds on the whole recording, and which rows only one of them found -> one check {"check", "ok", "detail"}."""
    name = "the rows found are the rows the application's reference implementation of this rule finds on the whole recording"
    try:
        with open(out_csv, newline="", encoding="utf-8") as fh:
            rd = csv.reader(fh)
            head = next(rd, [])
            if ROW_COLUMN not in head:
                return {"check": name, "ok": False, "detail": "the result has no column named \"%s\", so its rows cannot be compared" % ROW_COLUMN}
            i, got, unread = head.index(ROW_COLUMN), set(), 0
            for row in rd:
                v, ok = num(row[i] if i < len(row) else "")
                if v is None or not ok:
                    unread += 1
                else:
                    got.add(v)
        ref, info = reference_rows(db_path, family_id, immutable=immutable)
    except Exception as e:      # noqa: BLE001 - said, never silent
        return {"check": name, "ok": False, "detail": "the comparison could not be made: %s" % e}
    ref = set(ref)
    only_code, only_ref = sorted(got - ref), sorted(ref - got)
    few = lambda xs: ", ".join(map(str, xs[:SHOWN])) + (" and %d more" % (len(xs) - SHOWN) if len(xs) > SHOWN else "")      # noqa: E731
    if not info["can_be_checked"]:
        return {"check": name, "ok": not got, "detail": "the reference says: %s; the code's result has %d row%s" % (info["why_not"], len(got), "" if len(got) == 1 else "s")}
    detail = "the same %s row%s" % ("{:,}".format(len(ref)), "" if len(ref) == 1 else "s") if not (only_code or only_ref or unread) else "; ".join(x for x in (
        "only the code found row%s %s" % ("" if len(only_code) == 1 else "s", few(only_code)) if only_code else "",
        "only the reference implementation found row%s %s" % ("" if len(only_ref) == 1 else "s", few(only_ref)) if only_ref else "",
        "%d row number%s of the result cannot be read" % (unread, "" if unread == 1 else "s") if unread else "") if x)
    return {"check": name, "ok": not (only_code or only_ref or unread), "detail": detail}


def result_checks(out_csv, result):
    """The Tester's checks of a result of the application's own code of a family (an empty list is a result, not a failure)."""
    result = result if isinstance(result, dict) else {}
    fid, db = result.get("family"), result.get("tree_db")
    want = [c for c, _m in OUTPUT_COLUMNS]
    with open(out_csv, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        cols = next(rd, [])
        n = sum(1 for _ in rd)
    checks = [{"check": "the output has the item's columns, in its order", "ok": cols == want, "detail": "%d columns" % len(cols)},
              {"check": "the list holds exactly the rows the run counted", "ok": n == int(result.get("rows_written") or 0),
               "detail": "%s listed%s" % ("{:,}".format(n), "" if n else ": this rule found no row in this recording (an empty list is a result here, not a failure)")}]
    if result.get("can_be_checked") is False:
        checks.append({"check": "the result says why the rule cannot be checked on this recording", "ok": bool(result.get("why_not")) and n == 0, "detail": str(result.get("why_not") or "no reason given")[:400]})
    if fid in BY_ID and db and os.path.exists(db):
        same = compare_with_reference(out_csv, db, fid)
        # said as it is: here the application's own code made the result, so this is the same implementation run a second time. It shows that the
        # result file holds every row the rule finds; it is not a second program agreeing (the second count below, where there is one, is)
        same["detail"] += " (the application's own code ran both times: this shows the result file is whole, not that a second program agrees)"
        checks.append(same)
        try:
            second = sql_counts(db)
        except Exception as e:      # noqa: BLE001
            second = None
            checks.append({"check": "a second count, made another way, agrees", "ok": True, "detail": "not made: %s" % e})
        if second is not None and fid in second and result.get("damaged_cells"):
            checks.append({"check": "a second count, made another way, agrees", "ok": True,
                           "detail": "not compared: %s cell%s could not be read as a number, and the columns the loader read do not hold such a cell" % (
                               "{:,}".format(result["damaged_cells"]), "" if result["damaged_cells"] == 1 else "s")})
        elif second is not None and fid in second and result.get("can_be_checked") is not False:
            checks.append({"check": "a second count, made another way (SQL on the columns the loader read, not the cells the rule reads), agrees", "ok": second[fid] == n,
                           "detail": "%s by the second count, %s listed" % ("{:,}".format(second[fid]), "{:,}".format(n))})
    return checks


def card_lines(result):
    """What the result card says of a family's item under the Tester's checks -> (lines, data for the page)."""
    result = result if isinstance(result, dict) else {}
    f = BY_ID.get(result.get("family")) or {}
    lines = ["", "**In plain words:** " + str(result.get("words") or "")]
    if result.get("damaged_cells"):
        lines.append("%s cell%s of the columns this rule reads could not be read as a number; the rule for reserved values and unreadable status cells lists the status cells among them." % (
            "{:,}".format(result["damaged_cells"]), "" if result["damaged_cells"] == 1 else "s"))
    if f:
        lines += ["", "**Whose fault a found row points to:** %s." % f["fault"]]
        if f["belongs_with"]:
            lines.append("**Belongs with:** %s." % "; ".join(BY_ID[b]["name"] for b in f["belongs_with"] if b in BY_ID))
    return lines, {"words": result.get("words"), "family": result.get("family"), "can_be_checked": result.get("can_be_checked"), "why_not": result.get("why_not"),
                   "rows": result.get("rows_written"), "is_an_error_rule": True}


# ---------------------------------------------------------------------------------------------- the library items (agentic/family3.py seed())
def item_id(family_id):
    return ITEM_PREFIX + family_id


def _src(pairs):
    return " ".join("%s [%s]" % (s, src) for s, src in pairs)


def procedure(f):
    """The item's procedure: the source data, numbered steps a person can read, and the output columns (the found row is named in ROW_COLUMN)."""
    cols = []
    for c in f["columns"]:
        for n in c["names"][:1]:
            name = "%s: %s" % (c["level"], n)
            if name not in cols and c.get("in_source_data", True):
                cols.append(name)
    steps = ["What is looked for: %s" % f["what"]]
    steps += ["The pattern: %s" % s for s, _src_ in f["how"]]
    steps.append("The columns are read by the names the export gives them: %s." % "; ".join(
        "%s (%s)" % (" or ".join(c["names"]), "the NVMe command file" if c["level"] == "nvme_command" else "the completion row of the NVMe transaction level under the command") for c in f["columns"]))
    for c in f["columns"]:
        if not c.get("in_source_data", True):
            steps.append("The cell %s (%s) is read from the row when the export carries it; it is not listed under the source data, because many recordings carry no value in it." % (c["names"][0], c["meaning"]))
    for n in f["needs"]:
        steps.append("When the recording lacks %s, the result says: \"%s\". Nothing is guessed." % (n["what"], n["says"]))
    for s, _src_ in f["exceptions"]:
        steps.append("Not flagged: %s" % s)
    steps.append("Each found row is written with the reason in plain words, the values that matched, whose fault it points to (%s) and its row in the NVMe command file." % f["fault"])
    return {"source_data": [{"file": "the tree", "columns": cols}], "steps": steps,
            "output": {"columns": [c for c, _m in OUTPUT_COLUMNS], "order": "in the order of the NVMe command file; the findings of one episode together"},
            "open_questions": []}


def item(f):
    """One library item of a checkable family: section errors, level NVMe commands, never chosen by default."""
    return {"id": item_id(f["id"]), "section": "errors", "level": "nvme_command", "name": f["name"], "group": f["group"],
            "description": f["what"],
            "definition": "WHAT: %s WHY: %s HOW: %s" % (f["what"], _src(f["why"]), _src(f["how"])),
            "kind": KIND, "plan": {"family": f["id"]},
            "family1": {"columns": sorted({n for c in f["columns"] for n in c["names"]})},
            "columns": [{"level": c["level"], "names": c["names"], "meaning": c["meaning"]} for c in f["columns"]],
            "fault": f["fault"], "belongs_with": [BY_ID[b]["name"] for b in f["belongs_with"] if b in BY_ID],
            "source": "the research notes on NVMe command level error rules (%s); every sentence of the definition names its own source" % ", ".join(f["from_notes"]),
            "procedure": dict(procedure(f), version=1, edited_by="seed")}


def items():
    return [item(f) for f in FAMILIES if f["checkable"]]


def family_of_item(r):
    """The family id of a library item of this module that still has the application's own procedure, else None."""
    if not isinstance(r, dict) or r.get("kind") != KIND:
        return None
    fid = (r.get("plan") or {}).get("family") if isinstance(r.get("plan"), dict) else None
    return fid if fid in BY_ID and BY_ID[fid]["checkable"] else None


# ---------------------------------------------------------------------------------------------- the page /nvme-rules
def families_for_page():
    """Every family for the page, grouped, in plain words (no key of the code is a text of the screen)."""
    out = []
    for f in FAMILIES:
        out.append({"key": f["id"], "group": f["group"], "name": f["name"], "what": f["what"],
                    "why": [{"text": s, "source": src} for s, src in f["why"]], "how": [{"text": s, "source": src} for s, src in f["how"]],
                    "columns": [{"where": "the NVMe command file" if c["level"] == "nvme_command" else "the completion row of the NVMe transactions file, under the command",
                                 "level": c["level"], "names": c["names"], "meaning": c["meaning"]} for c in f["columns"]],
                    "needs": [{"what": n["what"], "says": n["says"]} for n in f["needs"]],
                    "exceptions": [{"text": s, "source": src} for s, src in f["exceptions"]], "fault": f["fault"],
                    "belongs_with": [BY_ID[b]["name"] for b in f["belongs_with"] if b in BY_ID],
                    "reaction": [{"text": s, "source": src} for s, src in f["reaction"]],
                    "differs": [{"value": v, "text": s, "source": src} for v, s, src in f["differs"]],
                    "can_be_run": f["checkable"], "not_run_because": f.get("not_checkable", ""),
                    "in_the_library": f["checkable"], "from": ", ".join(f["from_notes"])})
    return {"groups": [{"name": g, "about": a} for g, a in GROUP_MEANINGS], "families": out,
            "exceptions": [{"status": "%Xh/%02Xh %s" % (e["sct"], e["sc"], e["name"]), "why": e["why"], "source": e["source"]} for e in EXCEPTIONS],
            "detector_rules": [{"families": [BY_ID[x]["name"] for x in (fams or [])], "words": words} for _rule, (fams, words) in DETECTOR_MAP.items()]}


def counts_for_page(db_path, commands=None):
    """How many rows each family finds on one recording, for the page: {family key: {"found": n or None, "words"}}. The status families and the two
    on the bits are counted by SQL (any size). The others run the reference implementation, up to STREAM_COUNT_MOST commands; above that the
    page says where the count is made instead of making the reader wait."""
    from . import tree_api as T
    out = {}
    second = sql_counts(db_path) or {}
    tree = T.Tree(db_path)
    try:
        n_cmd = commands if commands is not None else (tree.levels().get("nvme_command") or 0)
        ntx = "nvme_transaction" in tree.present
        chain = None
        if n_cmd <= STREAM_COUNT_MOST and "nvme_command" in tree.present:
            # the four families of the timeout chain from ONE pass over the commands
            info, chain = {}, {"never": 0, "abort": 0, "aborted": 0, "reset": 0}
            for ep in episodes(tree, info):
                chain["never"] += len(ep["never"])
                chain["abort"] += len(ep["aborts"])
                chain["aborted"] += len(ep["aborted"])
                chain["reset"] += 1 if (ep["reset"] is not None and ep["never"]) else 0
            chain["info"] = info
        for f in FAMILIES:
            role = f["check"].get("role")
            if chain is not None and role and f["id"] not in second:
                no = ((role in ("never", "reset") and not chain["info"].get("detector") and NEED_DETECTOR["says"])
                      or (role == "reset" and chain["info"].get("set_features") and not chain["info"].get("fid_seen") and f["needs"][0]["says"]) or "")
                out[f["id"]] = {"found": None, "words": no} if no else {"found": chain[role], "words": "%s row%s" % ("{:,}".format(chain[role]), "" if chain[role] == 1 else "s")}
                continue
            if not f["checkable"]:
                out[f["id"]] = {"found": None, "words": f["not_checkable"]}
            elif f["id"] in second and (f["check"]["kind"] != "bits" or ntx):
                out[f["id"]] = {"found": second[f["id"]], "words": "%s row%s" % ("{:,}".format(second[f["id"]]), "" if second[f["id"]] == 1 else "s")}
            elif f["check"]["kind"] == "bits":
                out[f["id"]] = {"found": None, "words": NEED_NTX["says"]}
            elif f["check"]["kind"] == "detector":
                # counted from the detector's own findings, at any size (one row is counted once)
                rules = f["check"]["rule"] if isinstance(f["check"]["rule"], list) else [f["check"]["rule"]]
                need = [n for n in f["needs"] if n.get("what") == NEED_NTX["what"] and not n.get("optional")]
                try:
                    q = "SELECT COUNT(DISTINCT rowid) FROM finding WHERE level = 'nvme_command' AND rule IN (%s)" % ",".join("?" * len(rules))
                    kinds = f["check"].get("detail_kinds")
                    if kinds:
                        q += " AND (%s)" % " OR ".join("detail LIKE ?" for _k in kinds)
                    k = tree.con.execute(q, rules + ['%%"kind": "%s"%%' % x for x in (kinds or [])]).fetchone()[0]
                    out[f["id"]] = ({"found": None, "words": need[0]["says"]} if need and not ntx
                                    else {"found": k, "words": "%s row%s" % ("{:,}".format(k), "" if k == 1 else "s")})
                except Exception:      # noqa: BLE001 - no finding table
                    out[f["id"]] = {"found": None, "words": NEED_DETECTOR["says"]}
            elif n_cmd > STREAM_COUNT_MOST:
                out[f["id"]] = {"found": None, "words": "not counted on this page: this recording has %s commands, and this rule needs a pass of its own (the page makes it up to %s commands). "
                                                         "Choose the rule at stage 3 of the flow to run it." % ("{:,}".format(n_cmd), "{:,}".format(STREAM_COUNT_MOST))}
            else:
                info = {}
                k = sum(1 for _ in find(f, tree, info))
                out[f["id"]] = ({"found": k, "words": "%s row%s" % ("{:,}".format(k), "" if k == 1 else "s")} if info["can_be_checked"]
                                else {"found": None, "words": info["why_not"]})
    finally:
        tree.close()
    return out
