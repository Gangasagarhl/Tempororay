"""The knowledge base keeps what proved a result (the project statement: "archives validated results (PCIe traces, external workloads)
as a knowledge base"; coverage check of 2026-11-14, row S10, work item B6).

Before this file a validated defect only named its recording by the upload and the error's number: when the upload was deleted, the rows
that proved the defect were gone. Two things are kept here, in the same database as the procedural graph (db/hier_knowledge.sqlite):

1. THE TRACE OF A VALIDATED RESULT (tables kb_trace, kb_trace_level, kb_trace_log). The window around the error: the error's own NVMe
   command and, per level (NVMe command, NVMe transaction, split transaction, link transaction, packets), the rows that hang under it by
   the tree's own parent links, plus the n commands above and m below that the admin's window used, each with its rows. Read through the
   tree's indexed look-ups (one parent at a time, never a whole table), kept as one compressed block per level with the column names of
   that level's file. Never the whole recording: a window has a size limit (WINDOW_LIMIT_BYTES); above it the error's own rows are kept
   first, then the neighbouring commands nearest first, and the record says in words what was left out.

2. EXTERNAL WORKLOADS (tables kb_workload, kb_workload_log). The host workload that was running: the tool's name, its definition (the
   command line or the job file, as given) and its result (text or JSON, as given). Nothing is read into it and nothing is derived from
   it. A record is "validated" only by an admin's own action, stored with who and when.

across_stores() looks one defect up in this store and, read-only, in the earlier packet workflow's knowledge base (db/knowledge.sqlite):
a link is reported only when the data itself holds one (the same identifier in both stores); nothing is matched by similar words.
"""
import hashlib
import json
import os
import pathlib
import sqlite3
import time
import zlib

from . import tree_api as T

DEFAULT_ABOVE, DEFAULT_BELOW = 15, 15     # the owner's window (2026-11-11): 15 NVMe commands above the error's command and 15 below
MAX_NEIGHBOURS = 100                      # the most commands above, and below, a window may ask for (the isolation page allows 100)
# One archived window holds at most this many bytes of rows (counted as the JSON text of the rows, before compression).
# Measured on the sample S17_io_timeout_abort_reset on 2026-11-14, every one of its 1346 errors with the window of 15 commands above and
# 15 below: the largest window is 7,123,484 bytes of rows (15,131 rows); among the 20 command-level errors the smallest is 2,044,536
# bytes, the middle one 4,450,818 bytes and the largest 7,042,479 bytes; compressed they take 520,684, 1,148,763 and 1,760,750 bytes.
# The limit is 32 megabytes (33,554,432 bytes): about 4.7 times the largest default window measured, so the owner's default window is
# kept whole and so is a window several times wider, while one runaway or hostile window (a command with very many packets, or very
# long cells) cannot add more than 32 megabytes of rows to the knowledge base. It is a choice made from one sample: measure a real
# capture before a release and change the number here if its windows are larger.
WINDOW_LIMIT_BYTES = 32 * 1024 * 1024

# an external workload record: limits chosen so that one record cannot fill the knowledge base (they are choices, not measurements)
TOOL_NAME_CHARS = 200                     # characters in the tool's name
DEFINITION_LIMIT_BYTES = 256 * 1024       # the command line or the job file text
RESULT_LIMIT_BYTES = 4 * 1024 * 1024      # the result, text or JSON
NOTE_CHARS = 2000
NAME_CHARS = 200

NO_LINK = "no link between the two stores for this defect"

SCHEMA = """
CREATE TABLE IF NOT EXISTS kb_trace (id INTEGER PRIMARY KEY, upload_id TEXT, finding_id INTEGER, rule TEXT, finding_name TEXT, finding_level TEXT,
  finding_row INTEGER, command_row INTEGER, n_above INTEGER, m_below INTEGER, same_queue INTEGER, window_source TEXT, files TEXT, trace_name TEXT,
  device TEXT, firmware TEXT, archived_by TEXT, archived_at REAL, reason TEXT, bytes_rows INTEGER, bytes_stored INTEGER, limit_bytes INTEGER,
  complete INTEGER, left_out TEXT, commands TEXT, fingerprint TEXT, UNIQUE (upload_id, finding_id));
CREATE TABLE IF NOT EXISTS kb_trace_level (trace_id INTEGER, level TEXT, file TEXT, columns TEXT, n_rows INTEGER, bytes_rows INTEGER, data BLOB,
  PRIMARY KEY (trace_id, level));
CREATE TABLE IF NOT EXISTS kb_trace_log (id INTEGER PRIMARY KEY, trace_id INTEGER, upload_id TEXT, finding_id INTEGER, reason TEXT, by TEXT, at REAL, did TEXT);
CREATE TABLE IF NOT EXISTS kb_workload (id INTEGER PRIMARY KEY, tool TEXT, definition TEXT, result TEXT, result_kind TEXT, defect_id INTEGER,
  occurrence_id INTEGER, note TEXT, added_by TEXT, added_at REAL, validated_by TEXT, validated_at REAL);
CREATE TABLE IF NOT EXISTS kb_workload_log (id INTEGER PRIMARY KEY, workload_id INTEGER, action TEXT, by TEXT, at REAL);
CREATE INDEX IF NOT EXISTS ix_kb_workload_defect ON kb_workload (defect_id);
CREATE INDEX IF NOT EXISTS ix_kb_trace_log ON kb_trace_log (trace_id);
"""

LEVEL_WORDS = {"nvme_command": "NVMe commands", "nvme_transaction": "NVMe transactions", "split": "split transactions", "link": "link transactions",
               "packets": "packets"}
ROW_FIELDS = ("row", "number", "parent_level", "parent_row", "relation", "time_ps", "command_row")     # kept with every row, before its cells


class Refused(ValueError):
    """A request this store refuses, in words a person can read."""


def ensure(con):
    """The tables of this file, created when they are not there (a database made before 2026-11-14 gains them the first time it is opened)."""
    con.executescript(SCHEMA)


def _con(path):
    con = sqlite3.connect(path, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    ensure(con)
    return con


def _when(t):
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(t)) if t else None


def megabytes(n):
    return "%.2f megabytes" % (n / (1024.0 * 1024.0))


def whole(x, what, least=0, most=(1 << 63) - 1):
    """A whole number between least and most, or a refusal in words (True and 1.5 are not whole numbers)."""
    if isinstance(x, bool) or isinstance(x, float):
        raise Refused("%s must be a whole number" % what)
    try:
        v = int(x)
    except (TypeError, ValueError, OverflowError):
        raise Refused("%s must be a whole number" % what)
    if v < least:
        raise Refused("%s must not be below %d" % (what, least))
    if v > most:
        raise Refused("%s must not be above %d" % (what, most))
    return v


def name_text(x, what, most=NAME_CHARS, needed=True):
    """A short name on one line: text, no control character, at most `most` characters."""
    if x is None and not needed:
        return ""
    if not isinstance(x, str):
        raise Refused("%s must be text" % what)
    if any(ord(c) < 32 or ord(c) == 127 for c in x):
        raise Refused("%s must be one line of plain text (it holds a control character, for example a line break or a NUL character)" % what)
    v = " ".join(x.split())
    if needed and not v:
        raise Refused("%s is needed" % what)
    if len(v) > most:
        raise Refused("%s is too long: %d characters, at most %d characters are kept" % (what, len(v), most))
    return v


def upload_name(x):
    """An upload's name as the application makes it (letters, digits, dot, dash, underscore): a path or anything else is refused."""
    v = name_text(x, "the upload's name", most=120)
    if v.startswith(".") or not all(c.isalnum() or c in "-_." for c in v) or not v.isascii():
        raise Refused("the upload's name is a name, not a path: letters, digits, dashes, underscores and dots only")
    return v


# ============================================================================================ the trace of a validated result
def _finding(tree, finding_id):
    try:
        r = tree.con.execute("SELECT id, level, rule, name, severity, rowid, cmd_rowid, t_ps FROM finding WHERE id=?", (finding_id,)).fetchone()
    except sqlite3.OperationalError:
        raise Refused("this recording has no list of errors yet (its rules were not run)")
    if r is None:
        raise Refused("this recording has no error with the number %d" % finding_id)
    return {"id": r[0], "level": r[1], "rule": r[2], "name": r[3], "severity": r[4], "row": r[5], "command_row": r[6], "time_ps": r[7]}


def _encode(row, command_row, columns):
    """One row as it is kept: its place in the tree, then its cells in the order of the level's columns (or by name when this row's
    columns differ from the level's)."""
    lv = row.level
    cols = columns.setdefault(lv, list(row.keys()))
    cells = list(row.values()) if list(row.keys()) == cols else dict(row)
    par = row.parent or (None, None)
    return [row.row, row.number, par[0], par[1], row.relation, row.time_ps, command_row, cells]


def _size(enc):
    return len(json.dumps(enc, ensure_ascii=False, separators=(",", ":")).encode("utf-8", "surrogatepass"))


def _under(tree, level, row):
    """Every row below one row, level by level, by the tree's parent links (members and the context rows attached to a unit), one parent
    at a time through the index on (parent level, parent row): never a scan of a whole table. Yields tree rows."""
    frontier = [(level, row)]
    while frontier:
        nxt = []
        for lv, r in frontier:
            kids = [c for c in T.CHILD.get(lv, ()) if c in tree.present]
            if lv != "packets" and "packets" not in kids and "packets" in tree.present:
                kids.append("packets")           # flow-control and link-event packets the tree attached to this unit
            for cl in kids:
                cur = tree.con.execute("SELECT * FROM %s WHERE parent_level = ? AND parent = ? ORDER BY rowid_file" % T.TABLE[cl], (lv, int(r)))
                cols = [c[0] for c in cur.description]
                for x in cur:
                    out = T._row(cl, x, cols)
                    yield out
                    if cl != "packets":
                        nxt.append((cl, out.row))
        frontier = nxt


def _neighbours(tree, anchor, n, m, same_queue):
    """The rows (in nvme_command.csv) of the n commands above and the m below the error's command, by the file's own order."""
    cond, args = "", []
    if same_queue:
        r = tree.con.execute("SELECT sqid FROM cmd WHERE rowid_file = ?", (anchor,)).fetchone()
        if r is not None and r[0] is not None:
            cond, args = " AND sqid = ?", [r[0]]
    above = [r[0] for r in tree.con.execute("SELECT rowid_file FROM cmd WHERE rowid_file < ?%s ORDER BY rowid_file DESC LIMIT ?" % cond, [anchor] + args + [n])]
    below = [r[0] for r in tree.con.execute("SELECT rowid_file FROM cmd WHERE rowid_file > ?%s ORDER BY rowid_file LIMIT ?" % cond, [anchor] + args + [m])]
    return above, below          # each nearest first


def collect(tree, finding_id, n=DEFAULT_ABOVE, m=DEFAULT_BELOW, same_queue=False, limit_bytes=WINDOW_LIMIT_BYTES):
    """The window of one error, read from the tree: {"finding", "command_row", "levels": {level: [kept rows]}, "columns", "bytes",
    "complete", "left_out", "commands"}. The error's own rows first (they are always tried first), then the neighbouring commands' own
    rows, then the rows under each neighbour, nearest first; what does not fit under limit_bytes is left out and named."""
    f = _finding(tree, finding_id)
    columns, levels, used = {}, {lv: [] for lv in T.LEVELS}, 0
    left = {"own_rows_cut": None, "command_rows_left_out": [], "commands_without_their_lower_rows": []}
    anchor, own_level, own_row, note = f["command_row"], "nvme_command", f["command_row"], ""
    if anchor is None and f["level"] == "nvme_command":
        anchor = own_row = f["row"]
    if anchor is None and f["level"] in T.LEVELS and f["level"] in tree.present and f["level"] != "nvme_command" and "nvme_command" in tree.present:
        try:
            up = tree.ancestor(f["level"], f["row"], "nvme_command")
        except T.NotInTree:
            up = None
        anchor = own_row = up.row if up is not None else None
    if anchor is None or "nvme_command" not in tree.present:
        # the error belongs to no NVMe command: its own row and the rows under it are kept; no neighbour is guessed by time
        anchor, own_level, own_row = None, f["level"], f["row"]
        note = "this error belongs to no NVMe command in the tree: its own row and the rows under it are kept, without neighbouring commands"
        if own_level not in tree.present:
            raise Refused("the row of this error is not in the tree (its level's file was not loaded)")

    def keep(row, command_row):
        nonlocal used
        enc = _encode(row, command_row, columns)
        size = _size(enc)
        if used + size > limit_bytes:
            return False
        used += size
        levels[row.level].append(enc)
        return True

    # 1. the error's own rows: its command (or its own row) and everything under it
    try:
        first = tree.get(own_level, own_row)
    except T.NotInTree:
        raise Refused("the row of this error is not in the tree any more: load the recording again")
    if not keep(first, anchor):
        left["own_rows_cut"] = {"level": own_level, "row": own_row, "kept_before_it": 0}
    else:
        kept_own = 1
        for row in _under(tree, own_level, own_row):
            if not keep(row, anchor):
                left["own_rows_cut"] = {"level": row.level, "row": row.row, "kept_before_it": kept_own}
                break
            kept_own += 1
    commands = [{"row": anchor, "position": "the error's command", "lower_rows": left["own_rows_cut"] is None}] if anchor is not None else []
    # 2. the neighbouring commands' own rows, 3. the rows under each, nearest first (one above, one below, and so on)
    if anchor is not None:
        above, below = _neighbours(tree, anchor, n, m, same_queue)
        order = []
        for i in range(max(len(above), len(below))):
            order += [(r, "above") for r in above[i:i + 1]] + [(r, "below") for r in below[i:i + 1]]
        stopped = left["own_rows_cut"] is not None
        kept_cmd = []
        for r, pos in order:
            if stopped or not keep(tree.get("nvme_command", r), r):
                stopped = True
                left["command_rows_left_out"].append(r)
            else:
                kept_cmd.append((r, pos))
        full = left["own_rows_cut"] is not None or bool(left["command_rows_left_out"])
        for r, pos in kept_cmd:
            whole_ = not full
            if whole_:
                mark, buf, size = used, [], 0
                for row in _under(tree, "nvme_command", r):
                    enc = _encode(row, r, columns)
                    size += _size(enc)
                    if mark + size > limit_bytes:
                        whole_ = False
                        break
                    buf.append((row.level, enc))
                if whole_:
                    used = mark + size
                    for lv, enc in buf:
                        levels[lv].append(enc)
                else:
                    full = True              # a command's rows are kept whole or not at all; every command farther away is left out too
            if not whole_:
                left["commands_without_their_lower_rows"].append(r)
            commands.append({"row": r, "position": pos, "lower_rows": whole_})
    for lv in levels:
        levels[lv].sort(key=lambda e: e[0])
    commands.sort(key=lambda c: c["row"])
    complete = left["own_rows_cut"] is None and not left["command_rows_left_out"] and not left["commands_without_their_lower_rows"]
    words = []
    if not complete:
        words.append("This window is larger than the limit of %s of rows for one archived window, so not all of it is kept." % megabytes(limit_bytes))
        if left["own_rows_cut"]:
            c = left["own_rows_cut"]
            words.append("Of the error's own rows the first %d are kept; from row %d of %s on they are left out." % (c["kept_before_it"], c["row"], T.FILE.get(c["level"], c["level"])))
        else:
            words.append("The error's own rows are all kept.")
        if left["command_rows_left_out"]:
            words.append("%d neighbouring command%s left out entirely (rows %s of nvme_command.csv)." % (
                len(left["command_rows_left_out"]), " is" if len(left["command_rows_left_out"]) == 1 else "s are", _some(left["command_rows_left_out"])))
        if left["commands_without_their_lower_rows"]:
            k = len(left["commands_without_their_lower_rows"])
            words.append("%d neighbouring command%s kept as the command row only, without the rows of the lower levels under %s (rows %s of nvme_command.csv)." % (
                k, " is" if k == 1 else "s are", "it" if k == 1 else "them", _some(left["commands_without_their_lower_rows"])))
    if note:
        words.append(note[0].upper() + note[1:] + ".")
    return {"finding": f, "command_row": anchor, "levels": {lv: rows for lv, rows in levels.items() if rows}, "columns": columns, "bytes": used,
            "complete": complete, "left_out": {"words": " ".join(words), "detail": left if not complete else None}, "commands": commands}


def _some(rows, most=40):
    rows = sorted(rows)
    return ", ".join(str(r) for r in rows[:most]) + (" and %d more" % (len(rows) - most) if len(rows) > most else "")


def _record(r, log=None):
    d = dict(r)
    for k in ("files", "left_out", "commands"):
        d[k] = json.loads(d[k]) if d.get(k) else ({} if k != "commands" else [])
    d["complete"] = bool(d["complete"])
    d["same_queue"] = bool(d["same_queue"])
    d["archived_at_text"] = _when(d["archived_at"])
    d["size_words"] = "%s of rows, kept compressed in %s" % (megabytes(d["bytes_rows"] or 0), megabytes(d["bytes_stored"] or 0))
    d["window_words"] = ("the error's command with %d command%s above and %d below" % (d["n_above"], "" if d["n_above"] == 1 else "s", d["m_below"])
                         if d["command_row"] is not None else "the error's own row and the rows under it")
    if log is not None:
        d["log"] = [{"reason": x["reason"], "by": x["by"], "at": _when(x["at"]), "did": x["did"]} for x in log]
    return d


def archive_window(kb_path, tree_db, upload_id, finding_id, by, reason, n=None, m=None, same_queue=None, files=None, device=None, firmware=None,
                   trace_name=None, limit_bytes=WINDOW_LIMIT_BYTES):
    """Copy the window around one error from the upload's tree into the knowledge base. One archived window per error of a recording:
    asked again it is not copied twice (the same rows: nothing is written but a line in its log; a wider window: the rows are replaced;
    a narrower one: the wider one stays). When the recording is gone and a window was archived before, that window stays as it is.
    -> the record, with "did" (what happened, in words)."""
    upload_id = upload_name(upload_id)
    finding_id = whole(finding_id, "the error's number")
    by = name_text(by, "your name")
    reason = name_text(reason, "the reason for archiving", most=300)
    con = _con(kb_path)
    try:
        old = con.execute("SELECT * FROM kb_trace WHERE upload_id=? AND finding_id=?", (upload_id, finding_id)).fetchone()
        src = "the numbers given with this request"
        if n is None and m is None:
            if old is not None:
                n, m, src = old["n_above"], old["m_below"], old["window_source"]
            else:
                n, m, src = DEFAULT_ABOVE, DEFAULT_BELOW, "the default window (15 commands above, 15 below): no window was given with the request"
        n = whole(DEFAULT_ABOVE if n is None else n, "the number of commands above", most=MAX_NEIGHBOURS)
        m = whole(DEFAULT_BELOW if m is None else m, "the number of commands below", most=MAX_NEIGHBOURS)
        if old is not None and (n < old["n_above"] or m < old["m_below"]):
            n, m = max(n, old["n_above"]), max(m, old["m_below"])       # the widest window the admin used stays
        if same_queue is None:
            same_queue = bool(old["same_queue"]) if old is not None else False
        now = time.time()

        def log(trace_id, did):
            con.execute("INSERT INTO kb_trace_log (trace_id, upload_id, finding_id, reason, by, at, did) VALUES (?,?,?,?,?,?,?)",
                        (trace_id, upload_id, finding_id, reason, by, now, did))
            con.commit()

        if not tree_db or not os.path.exists(tree_db):
            if old is None:
                raise Refused("the recording of this upload is not on this computer any more and nothing of it was archived before, so there are no rows to keep")
            did = "kept as archived on %s: the recording is not on this computer any more" % _when(old["archived_at"])
            log(old["id"], did)
            return dict(_record(old), did=did, changed=False)
        tree = T.Tree(tree_db)
        try:
            w = collect(tree, finding_id, n, m, bool(same_queue), limit_bytes)
        finally:
            tree.close()
        blobs, h = {}, hashlib.sha256(("%d/%d/%d" % (n, m, 1 if same_queue else 0)).encode("ascii"))
        for lv in T.LEVELS:
            rows = w["levels"].get(lv)
            if not rows:
                continue
            raw = json.dumps({"columns": w["columns"][lv], "fields": list(ROW_FIELDS) + ["cells"], "rows": rows}, ensure_ascii=False,
                             separators=(",", ":")).encode("utf-8", "surrogatepass")
            h.update(lv.encode("ascii") + b"\0" + raw)
            names = list(w["columns"][lv])           # the column names of this level seen in the kept rows, in the order they first appear
            seen = set(names)                        # (the tree keeps only the cells a row has, so two rows of one file can differ)
            for e in rows:
                if isinstance(e[7], dict):
                    for k in e[7]:
                        if k not in seen:
                            seen.add(k)
                            names.append(k)
            blobs[lv] = (json.dumps(names, ensure_ascii=False), len(rows), len(raw), zlib.compress(raw, 6))
        fp = h.hexdigest()
        if old is not None and old["fingerprint"] == fp:
            did = "already archived on %s with the same rows: nothing was copied again" % _when(old["archived_at"])
            log(old["id"], did)
            return dict(_record(old), did=did, changed=False)
        f = w["finding"]
        vals = (f["rule"], f["name"], f["level"], f["row"], w["command_row"], n, m, 1 if same_queue else 0, src,
                json.dumps(files or {}, ensure_ascii=False), trace_name, device, firmware, by, now, reason, w["bytes"],
                sum(len(b[3]) for b in blobs.values()), limit_bytes, 1 if w["complete"] else 0, json.dumps(w["left_out"], ensure_ascii=False),
                json.dumps(w["commands"]), fp)
        if old is None:
            tid = con.execute("INSERT INTO kb_trace (rule, finding_name, finding_level, finding_row, command_row, n_above, m_below, same_queue, window_source, "
                              "files, trace_name, device, firmware, archived_by, archived_at, reason, bytes_rows, bytes_stored, limit_bytes, complete, left_out, "
                              "commands, fingerprint, upload_id, finding_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                              vals + (upload_id, finding_id)).lastrowid
            did = "archived: %d row%s in %s" % (sum(b[1] for b in blobs.values()), "" if sum(b[1] for b in blobs.values()) == 1 else "s", megabytes(w["bytes"]))
        else:
            tid = old["id"]
            con.execute("UPDATE kb_trace SET rule=?, finding_name=?, finding_level=?, finding_row=?, command_row=?, n_above=?, m_below=?, same_queue=?, "
                        "window_source=?, files=?, trace_name=?, device=COALESCE(?, device), firmware=COALESCE(?, firmware), archived_by=?, archived_at=?, "
                        "reason=?, bytes_rows=?, bytes_stored=?, limit_bytes=?, complete=?, left_out=?, commands=?, fingerprint=? WHERE id=?", vals + (tid,))
            con.execute("DELETE FROM kb_trace_level WHERE trace_id=?", (tid,))
            did = "archived again, in place of the window kept on %s (the window or its rows changed)" % _when(old["archived_at"])
        for lv, (cols, nrows, nraw, blob) in blobs.items():
            con.execute("INSERT INTO kb_trace_level (trace_id, level, file, columns, n_rows, bytes_rows, data) VALUES (?,?,?,?,?,?,?)",
                        (tid, lv, (files or {}).get(lv) or T.FILE[lv], cols, nrows, nraw, sqlite3.Binary(blob)))
        log(tid, did)
        return dict(_record(con.execute("SELECT * FROM kb_trace WHERE id=?", (tid,)).fetchone()), did=did, changed=True)
    finally:
        con.close()


def read_window(kb_path, upload_id=None, finding_id=None, trace_id=None, levels=None, rows=True):
    """The archived window of one error, from the knowledge base alone (the upload may be gone): the record and, per level, the file's
    name, its column names and the rows: {"row", "number", "parent": [level, row] or None, "relation", "time_ps", "command_row", "cells"}.
    None when nothing is archived for it. levels: only these levels; rows=False: the record and the counts only."""
    if levels is not None:
        bad = [lv for lv in levels if lv not in T.LEVELS]
        if bad:
            raise Refused("no such level: %s. The levels are: %s" % (", ".join(str(b) for b in bad), ", ".join(T.LEVELS)))
    con = _con(kb_path)
    try:
        if trace_id is not None:
            r = con.execute("SELECT * FROM kb_trace WHERE id=?", (whole(trace_id, "the archived window's number"),)).fetchone()
        else:
            r = con.execute("SELECT * FROM kb_trace WHERE upload_id=? AND finding_id=?", (upload_name(upload_id), whole(finding_id, "the error's number"))).fetchone()
        if r is None:
            return None
        out = _record(r, con.execute("SELECT * FROM kb_trace_log WHERE trace_id=? ORDER BY id DESC LIMIT 20", (r["id"],)).fetchall())
        out["levels"] = {}
        for x in con.execute("SELECT level, file, columns, n_rows, bytes_rows%s FROM kb_trace_level WHERE trace_id=?" % (", data" if rows else ""), (r["id"],)):
            if levels is not None and x["level"] not in levels:
                continue
            blk = {"file": x["file"], "label": LEVEL_WORDS.get(x["level"], x["level"]), "columns": json.loads(x["columns"]), "count": x["n_rows"],
                   "bytes_rows": x["bytes_rows"]}
            if rows:
                d = json.loads(zlib.decompress(bytes(x["data"])).decode("utf-8", "surrogatepass"))
                cols = d["columns"]
                blk["rows"] = [{"row": e[0], "number": e[1], "parent": [e[2], e[3]] if e[3] is not None else None, "relation": e[4], "time_ps": e[5],
                                "command_row": e[6], "cells": e[7] if isinstance(e[7], dict) else dict(zip(cols, e[7]))} for e in d["rows"]]
            out["levels"][x["level"]] = blk
        out["levels"] = {lv: out["levels"][lv] for lv in T.LEVELS if lv in out["levels"]}
        return out
    finally:
        con.close()


def windows(kb_path, pairs=None, limit=500):
    """The archived windows (records only, newest first), all of them or those of the given (upload, error number) pairs."""
    con = _con(kb_path)
    try:
        if pairs is None:
            rs = con.execute("SELECT * FROM kb_trace ORDER BY archived_at DESC LIMIT ?", (limit,)).fetchall()
        else:
            rs = [r for r in (con.execute("SELECT * FROM kb_trace WHERE upload_id=? AND finding_id=?", p).fetchone() for p in list(pairs)[:limit]) if r is not None]
        return [_record(r) for r in rs]
    finally:
        con.close()


# ============================================================================================ external workloads
def _workload(r, full=True):
    d = dict(r)
    d["validated"] = bool(d["validated_by"])
    d["added_at_text"], d["validated_at_text"] = _when(d["added_at"]), _when(d["validated_at"])
    d["validation_words"] = ("validated by %s on %s" % (d["validated_by"], d["validated_at_text"])) if d["validated"] else \
        "not validated: kept as given; an admin has not confirmed this result"
    d["definition_bytes"], d["result_bytes"] = len(d["definition"].encode("utf-8", "surrogatepass")), len(d["result"].encode("utf-8", "surrogatepass"))
    if full:
        if d["result_kind"] == "json":
            d["result"] = json.loads(d["result"])
    else:
        d.pop("definition")
        d.pop("result")
    return d


def _given_text(x, what, limit, needed=True):
    """Text kept exactly as given: only its kind and its size are checked."""
    if not isinstance(x, str):
        raise Refused("%s must be text, exactly as the tool takes or gives it; a number, a list or a set of fields is refused" % what)
    if "\x00" in x:
        raise Refused("%s holds a NUL character: it is not text" % what)
    try:
        size = len(x.encode("utf-8"))
    except UnicodeEncodeError:
        raise Refused("%s holds characters that are not text" % what)
    if needed and not x.strip():
        raise Refused("%s is needed" % what)
    if size > limit:
        raise Refused("%s is too large: %s, at most %s are kept. Nothing was stored." % (what, megabytes(size), megabytes(limit)))
    return x


def add_workload(kb_path, tool, definition, result, by, defect_id=None, occurrence_id=None, note=None):
    """Store one external workload with its result, as given. -> its number. Never validated here: validate_workload() is the admin's own action."""
    tool = name_text(tool, "the tool's name", most=TOOL_NAME_CHARS)
    by = name_text(by, "your name")
    definition = _given_text(definition, "the workload's definition (the command line or the job file)", DEFINITION_LIMIT_BYTES)
    if isinstance(result, (dict, list)):
        try:
            text = json.dumps(result, ensure_ascii=False, allow_nan=False)
        except (TypeError, ValueError, RecursionError):
            raise Refused("the workload's result cannot be kept as JSON (it holds a value JSON does not have)")
        if "\\u0000" in text or len(text.encode("utf-8", "surrogatepass")) > RESULT_LIMIT_BYTES:
            raise Refused("the workload's result holds a NUL character" if "\\u0000" in text else
                          "the workload's result is too large: %s, at most %s are kept. Nothing was stored." % (megabytes(len(text.encode("utf-8", "surrogatepass"))), megabytes(RESULT_LIMIT_BYTES)))
        if not result:
            raise Refused("the workload's result is needed")
        kind = "json"
    else:
        text, kind = _given_text(result, "the workload's result", RESULT_LIMIT_BYTES), "text"
    if note is not None and not isinstance(note, str):
        raise Refused("the note must be text")
    note = (note or "")
    if "\x00" in note or len(note) > NOTE_CHARS:
        raise Refused("the note is too long or holds a NUL character: at most %d characters are kept" % NOTE_CHARS)
    con = _con(kb_path)
    try:
        if defect_id is not None:
            defect_id = whole(defect_id, "the defect's number", least=1)
            if con.execute("SELECT 1 FROM sqlite_master WHERE name='dg_defect'").fetchone() is None or \
                    con.execute("SELECT 1 FROM dg_defect WHERE id=?", (defect_id,)).fetchone() is None:
                raise Refused("there is no stored defect with the number %d" % defect_id)
        if occurrence_id is not None:
            occurrence_id = whole(occurrence_id, "the occurrence's number", least=1)
            o = con.execute("SELECT defect_id FROM dg_occurrence WHERE id=?", (occurrence_id,)).fetchone() \
                if con.execute("SELECT 1 FROM sqlite_master WHERE name='dg_occurrence'").fetchone() else None
            if o is None:
                raise Refused("there is no stored occurrence of a defect with the number %d" % occurrence_id)
            if defect_id is not None and o["defect_id"] != defect_id:
                raise Refused("that occurrence belongs to another defect than the one named")
            defect_id = defect_id if defect_id is not None else o["defect_id"]
        now = time.time()
        wid = con.execute("INSERT INTO kb_workload (tool, definition, result, result_kind, defect_id, occurrence_id, note, added_by, added_at) VALUES (?,?,?,?,?,?,?,?,?)",
                          (tool, definition, text, kind, defect_id, occurrence_id, note, by, now)).lastrowid
        con.execute("INSERT INTO kb_workload_log (workload_id, action, by, at) VALUES (?,?,?,?)", (wid, "stored as given, not validated", by, now))
        con.commit()
        return wid
    finally:
        con.close()


def workload(kb_path, workload_id):
    con = _con(kb_path)
    try:
        r = con.execute("SELECT * FROM kb_workload WHERE id=?", (whole(workload_id, "the workload record's number", least=1),)).fetchone()
        if r is None:
            return None
        d = _workload(r)
        d["log"] = [{"action": x["action"], "by": x["by"], "at": _when(x["at"])} for x in con.execute("SELECT * FROM kb_workload_log WHERE workload_id=? ORDER BY id", (r["id"],))]
        return d
    finally:
        con.close()


def workloads(kb_path, defect_id=None, occurrence_id=None, limit=200):
    """The stored workload records, newest first (without the definition and result texts: their sizes are given), all or one defect's or occurrence's."""
    q, a = "SELECT * FROM kb_workload WHERE 1=1", []
    if defect_id is not None:
        q, a = q + " AND defect_id=?", a + [whole(defect_id, "the defect's number", least=1)]
    if occurrence_id is not None:
        q, a = q + " AND occurrence_id=?", a + [whole(occurrence_id, "the occurrence's number", least=1)]
    con = _con(kb_path)
    try:
        return [_workload(r, full=False) for r in con.execute(q + " ORDER BY id DESC LIMIT ?", a + [whole(limit, "the number of records", least=1, most=1000)])]
    finally:
        con.close()


def validate_workload(kb_path, workload_id, by, confirm, withdraw=False):
    """The admin's own action: this workload's result is validated (who, when), or the validation is taken back. confirm must be exactly True."""
    by = name_text(by, "your name")
    if confirm is not True:
        raise Refused("a workload's result is validated only by your explicit confirmation: send \"confirm\": true with your name")
    wid = whole(workload_id, "the workload record's number", least=1)
    con = _con(kb_path)
    try:
        r = con.execute("SELECT * FROM kb_workload WHERE id=?", (wid,)).fetchone()
        if r is None:
            return None
        now = time.time()
        if withdraw:
            con.execute("UPDATE kb_workload SET validated_by=NULL, validated_at=NULL WHERE id=?", (wid,))
            action = "validation taken back"
        else:
            con.execute("UPDATE kb_workload SET validated_by=?, validated_at=? WHERE id=?", (by, now, wid))
            action = "validated"
        con.execute("INSERT INTO kb_workload_log (workload_id, action, by, at) VALUES (?,?,?,?)", (wid, action, by, now))
        con.commit()
    finally:
        con.close()
    return workload(kb_path, wid)


# ============================================================================================ one look-up across both stores
def across_stores(kb_path, packet_kb_path, defect):
    """What both knowledge bases hold for one defect of the main flow, named by its number, its key or its name. Read-only.

    The earlier packet workflow (stage2/kgdb.py, db/knowledge.sqlite) files what it knows under a signature: the identifier of the error
    type its detector gave, with a pattern family. The main flow files a defect under a term made by nvme_hier/terms.py and the rule that
    found the error. The two were made independently and no table maps one to the other. So a link is reported only when the data holds
    one: the defect's rule, key or name is, letter for letter (upper or lower case), a signature or a pattern family of the earlier
    store. Nothing is matched by similar words. Without such a row the answer says: "no link between the two stores for this defect"."""
    from . import defect_graph as DG
    con = _con(kb_path)
    try:
        con.executescript(DG.SCHEMA)
        d = None
        if isinstance(defect, int) and not isinstance(defect, bool):
            d = con.execute("SELECT * FROM dg_defect WHERE id=?", (whole(defect, "the defect's number"),)).fetchone()
        else:
            text = name_text(defect, "the defect's key or name", most=400)
            for key in (text, "term:" + text, DG.norm_key(text)):
                d = con.execute("SELECT * FROM dg_defect WHERE key=?", (key,)).fetchone()
                if d is not None:
                    break
            if d is None:                    # by its name, whatever the case or punctuation (one row per kind of defect: a short table)
                want = DG.norm_key(text)
                hit = [r["id"] for r in con.execute("SELECT id, name FROM dg_defect") if want and DG.norm_key(r["name"]) == want]
                if len(hit) == 1:
                    d = con.execute("SELECT * FROM dg_defect WHERE id=?", (hit[0],)).fetchone()
        if d is None:
            return None
        occ = con.execute("SELECT upload_id, finding_id FROM dg_occurrence WHERE defect_id=?", (d["id"],)).fetchall()
        kept = sum(1 for o in occ if con.execute("SELECT 1 FROM kb_trace WHERE upload_id=? AND finding_id=?", (o["upload_id"], o["finding_id"])).fetchone())
        main = {"store": "the main flow's knowledge base (the procedural graph)", "id": d["id"], "key": d["key"], "name": d["name"], "rule": d["rule"], "level": d["level"],
                "occurrences": len(occ), "causes": con.execute("SELECT COUNT(*) FROM dg_cause WHERE defect_id=?", (d["id"],)).fetchone()[0],
                "solutions": con.execute("SELECT COUNT(*) FROM dg_solution WHERE status='active' AND cause_id IN (SELECT id FROM dg_cause WHERE defect_id=?)", (d["id"],)).fetchone()[0],
                "archived_windows": kept, "workloads": con.execute("SELECT COUNT(*) FROM kb_workload WHERE defect_id=?", (d["id"],)).fetchone()[0],
                "validated_workloads": con.execute("SELECT COUNT(*) FROM kb_workload WHERE defect_id=? AND validated_by IS NOT NULL", (d["id"],)).fetchone()[0]}
    finally:
        con.close()
    out = {"defect": main, "packet_store": None, "link": NO_LINK,
           "why": "The earlier packet workflow files its knowledge under the error type its own detector names; the main flow files a defect under its "
                  "own term and rule. A link is reported only when one of this defect's identifiers is, letter for letter, an error type or a pattern "
                  "family of the earlier store. Nothing is matched by similar words."}
    if not packet_kb_path or not os.path.exists(packet_kb_path):
        out["why"] = "The earlier packet workflow's knowledge base is not on this computer. " + out["why"]
        return out
    cands = []
    for c in (d["rule"], d["key"], (d["key"] or "")[5:] if (d["key"] or "").startswith("term:") else None, d["name"]):
        if c and str(c).strip() and str(c).strip().lower() not in [x.lower() for x in cands]:
            cands.append(str(c).strip())
    try:
        pk = sqlite3.connect(pathlib.Path(os.path.abspath(packet_kb_path)).as_uri() + "?mode=ro", uri=True, timeout=5)
    except sqlite3.Error:
        out["why"] = "The earlier packet workflow's knowledge base cannot be opened for reading. " + out["why"]
        return out
    try:
        pk.execute("PRAGMA query_only=1")
        hits = []
        for c in cands:
            for sig, pattern, seen in pk.execute("SELECT sig, pattern, seen FROM signature WHERE sig = ? COLLATE NOCASE OR pattern = ? COLLATE NOCASE", (c, c)):
                if sig in [h["error_type"] for h in hits]:
                    continue
                hits.append({"error_type": sig, "pattern_family": pattern, "times_seen": seen, "matched_on": c,
                             "causes": pk.execute("SELECT COUNT(*) FROM node WHERE sig=? AND kind='cause' AND status='active'", (sig,)).fetchone()[0],
                             "solutions_by_status": dict(pk.execute("SELECT COALESCE(status, 'no status'), COUNT(*) FROM solution WHERE sig=? GROUP BY 1", (sig,)).fetchall()),
                             "lessons": pk.execute("SELECT COUNT(*) FROM lesson WHERE sig=?", (sig,)).fetchone()[0],
                             "artifacts": pk.execute("SELECT COUNT(*) FROM artifact WHERE sig=?", (sig,)).fetchone()[0]})
    except sqlite3.Error:
        out["why"] = "The earlier packet workflow's knowledge base cannot be read (it may be from another version). " + out["why"]
        return out
    finally:
        pk.close()
    if hits:
        out["packet_store"] = {"store": "the earlier packet workflow's knowledge base", "error_types": hits}
        out["link"] = "the same identifier is used in both stores: %s" % ", ".join("“%s”" % h["matched_on"] for h in hits)
    return out
