"""Search and stress step for the page of one error (project statement: "an optimizer iteratively changes command sequences and
timing, guided by a reward tied to reproducing the failure; the most stressful trigger conditions become the test").

What is searched (nothing is invented: every command and every parameter is a row of the recording):
  selection    which of the recorded commands before the failing command are replayed (the "pool": the commands of the window above it
               and the commands of the first sequence)
  order        the recorded order, changed only where it is legal (must_keep_order: see there for the rule)
  timing       the gap before each command (microseconds), and the queue depth (how many commands the bench keeps open at once) where
               the recording has several I/O queues; never deeper than the recording itself showed
Seed           the first sequence of the page (nvme_hier/optimise.py or the model's chosen rows), unchanged.
Reward         first: how often the same failure came back (k of n runs); second: how close the measured time of the failing command
               is to the recorded one. Compared in that order.
Budget         a fixed number of bench runs for the search and its confirmation; the stress step afterwards has its own, smaller, fixed
               allowance, reported separately.
Search         hill climbing from the seed, in three parts: (1) two anchors, the seed and "every recorded command before the failing one,
               as recorded"; (2) one pass that changes one value at a time and keeps the first improvement (the gap before the failing
               command, the queue depth, each command left out, each missing command put back); (3) for the rest of the budget random
               changes, the operator chosen by a Thompson bandit (the idea of stage2/optimizer.py). Each candidate is run EVAL_RUNS times; a candidate that brings the failure back is run up to CONFIRM_RUNS times and reported with
               the exact lower bound of its rate (f2t_nvme.lower_bound), never from one lucky run.
Stress step    from the confirmed sequence each timing value is pushed step by step in its stressful direction (gap halved, queue one
               deeper) while the failure still comes back in at least 2 of 3 runs; the furthest value that still does is reported with
               its measured count.

Benches (one interface: run(steps, queue_depth, n) -> n results {"reproduced", "time_us"}):
  HiddenTriggerBench  a simulated drive whose failure appears only under conditions the search cannot see (TRIGGER), with a stated share
                      of random misses. For tests and demonstrations; every result of it carries the label SIMULATED.
  RealBench           the application's bench connection (app/bench_hook.py). It raises NotImplementedError today: BenchNotReady says so
                      in plain words. Nothing in this module runs on a real device by itself.
"""
import os
import random
import sys

from . import optimise as OPT
from . import testplan as TP

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "regress"))
import f2t_nvme as T   # noqa: E402  (the fixed replay library: its Result, its rules for what is sent, its judgement of "the fault is seen")

SIMULATED = "simulated drive"
REAL = "real bench"
EVAL_RUNS = 2            # runs of one candidate while searching
CONFIRM_RUNS = 10        # runs of a candidate that brought the failure back: "k of 10"
CONFIRM_NEED = 8         # the search stops when a candidate brings the failure back in this many of CONFIRM_RUNS
STRESS_RUNS = 3          # runs per stress step
STRESS_NEED = 2          # ... of which the failure must come back in this many for the step to be kept
STRESS_MAX_RUNS = 90     # the stress step's own allowance of bench runs
BUDGET_DEFAULT = 200     # bench runs for the search: the explained default of the page (measured: tests/test_replay_search.py)
BUDGET_MIN, BUDGET_MAX = 20, 5000
SWEEP_MARGIN = 0.03      # in the one-value-at-a-time pass a change is kept only when the closeness grows by more than this (above the 5 per cent jitter of two runs)
CLOSE_NOISE = 0.01       # two candidates whose closeness differs by less than this are treated as equally good
MIN_GAP_US = 1
MAX_GAP_US = 600 * 10 ** 6
WRITERS = {0x01, 0x04, 0x08, 0x09, 0x19}          # Write, Write Uncorrectable, Write Zeroes, Dataset Management, Copy: they change blocks
RANGE_OPS = {0x01, 0x02, 0x04, 0x05, 0x08, 0x09, 0x0C, 0x19}
RESERVATIONS = {0x0D, 0x0E, 0x11, 0x15}
SEARCHABLE = ("status", "timeout", "latency", "any_error")       # the kinds of failure one command's outcome shows (testplan.oracle_of)

OPERATOR_WORDS = {
    "add": "add one recorded command", "add_some": "add up to three recorded commands", "remove": "leave one command out",
    "add_all": "keep every recorded command before the failing one, in the recorded order", "remove_some": "leave two or three commands out",
    "resample": "a fresh random choice of commands, order, gaps and queue depth",
    "swap": "swap two neighbouring commands (only where the order is free)", "gap_shorter": "halve the gap before one command",
    "gap_longer": "double the gap before one command", "gap_recorded": "put one gap back to the measured one",
    "fault_gap_shorter": "halve the gap before the failing command", "fault_gap_longer": "double the gap before the failing command",
    "queue_deeper": "keep one more command open at once", "queue_shallower": "keep one command fewer open at once"}


class Stopped(Exception):
    """The admin stopped the search: nothing is stored."""


class BenchNotReady(Exception):
    """The bench cannot run (the real bench has no implementation yet): the message is for the admin, in plain words."""


def wilson_lower(k, n, z=1.96):
    """The same bound stage2/optimizer.py reports (kept here so this module does not import stage 2)."""
    if n == 0:
        return 0.0
    p = k / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    r = z * ((p * (1 - p) / n + z * z / (4 * n * n)) ** 0.5)
    return max(0.0, (c - r) / d)


# ---------------------------------------------------------------------------------------------- the commands and the order rule
def ranges_of(step):
    """The blocks a step touches: [(namespace, first block, last block)]; [] when it names none."""
    if step.get("admin") or step.get("opc") not in RANGE_OPS:
        return []
    p = step.get("parameters") or {}
    if step.get("opc") == 0x09 and p.get("ranges"):
        return [(p.get("nsid"), int(s), int(s) + int(n) - 1) for s, n in p["ranges"]]
    if p.get("slba") is None:
        return []
    return [(p.get("nsid"), int(p["slba"]), int(p["slba"]) + int(p.get("nlb") or 0))]


def must_keep_order(a, b, fused=()):
    """Why two recorded commands (a recorded before b) must stay in that order, or None when they may be swapped.

    The decision, from the commands' own fields only (the rules D1 to D6 of nvme_hier/optimise.py, read as an order rule):
      - an admin command stays where it was: it reads or changes controller, queue or feature state;
      - a Flush, a Write with Force Unit Access, half of a fused pair and a reservation command are ordering barriers;
      - two commands on overlapping blocks of the same namespace stay in order when at least one of them changes the blocks
        (a write before its read of the same blocks, two writes of the same blocks, a deallocate and a read);
      - a command that changes blocks but whose blocks the export does not give, and a command this code does not know, stay in order.
    Everything else (two reads; a read and a write of different blocks; different namespaces) is independent."""
    for x in (a, b):
        if x.get("admin"):
            return "an admin command keeps its recorded place (it reads or changes the drive's state)"
        opc = x.get("opc")
        if opc == 0x00:
            return "a Flush is an ordering barrier"
        if opc == 0x01 and (x.get("parameters") or {}).get("fua"):
            return "a Write with Force Unit Access is an ordering barrier"
        if x.get("source_row") in fused:
            return "half of a fused pair"
        if opc in RESERVATIONS:
            return "a reservation command changes who may write"
        if opc not in RANGE_OPS:
            return "a command this code does not know keeps its recorded place"
        if opc in WRITERS and not ranges_of(x):
            return "it changes blocks, but the export does not say which"
    if a.get("opc") in WRITERS or b.get("opc") in WRITERS:
        for ra in ranges_of(a):
            for rb in ranges_of(b):
                if ra[0] == rb[0] and ra[1] <= rb[2] and rb[1] <= ra[2]:
                    return "both touch blocks %d to %d of namespace %s and one of them changes them" % (max(ra[1], rb[1]), min(ra[2], rb[2]), ra[0])
    return None


def is_sent(step):
    """Whether the replay library sends this step to a drive (f2t_nvme.send_step: queue commands are the driver's, some are never sent)."""
    opc = step.get("opc")
    if step.get("admin"):
        if opc in T.NEVER_REPLAYED or opc == 0x08:
            return False
        if opc == 0x09:
            return False            # Set Features: sent only with the feature's value, which a pool step does not carry
        return opc in (0x06, 0x02, 0x0A, 0x18)
    return opc in (0x00, 0x01, 0x02, 0x04, 0x08, 0x09, 0x0C)


def fingerprint(step):
    """What a drive sees of a command: admin or I/O, the opcode, the namespace, the first block and the block count."""
    p = step.get("parameters") or {}
    rg = ranges_of(step)
    return ("admin" if step.get("admin") else "io", step.get("opc"), p.get("nsid"), rg[0][1] if rg else None, (rg[0][2] - rg[0][1]) if rg else None)


class Pool:
    """The recorded commands the search may use, and the failing command. Built from steps in the shape of optimise.step_of.

    above: steps recorded before the failing command (any order given; kept sorted by their row of the recording);
    fault: the step of the failing command; times: {row: (start in picoseconds, duration in picoseconds)} when known."""

    def __init__(self, above, fault, times=None, fused=()):
        self.fault = dict(fault, position="fault")
        self.frow = self.fault.get("source_row")
        self.by_row = {}
        for s in above:
            rid = s.get("source_row")
            if rid is None or rid == self.frow or rid in self.by_row:
                continue
            self.by_row[rid] = dict(s, position="above")
        self.rows = sorted(self.by_row)                                  # the row number of the export is the recorded order
        self.fused = set(fused or ())
        self.times = dict(times or {})
        self.recorded_gap = {r: max(MIN_GAP_US, min(MAX_GAP_US, int(self.by_row[r].get("gap_us") or OPT.DEFAULT_GAP_US))) for r in self.rows}
        self.recorded_gap[self.frow] = max(MIN_GAP_US, min(MAX_GAP_US, int(self.fault.get("gap_us") or OPT.DEFAULT_GAP_US)))
        queues = {s.get("queue") for s in list(self.by_row.values()) + [self.fault] if not s.get("admin") and s.get("queue") is not None}
        self.io_queues = len(queues)
        self.max_queue_depth = self._max_open() if self.io_queues > 1 else 1

    def _max_open(self):
        """The largest number of commands that were open at the same moment in the recording (from start time and duration)."""
        ev = []
        for r in self.rows + [self.frow]:
            t = self.times.get(r)
            if t and t[0] is not None:
                ev.append((t[0], 1))
                ev.append((t[0] + (t[1] or 0), -1))
        open_now = most = 0
        for _t, d in sorted(ev, key=lambda e: (e[0], e[1])):
            open_now += d
            most = max(most, open_now)
        return max(1, most)

    def step(self, row):
        return self.fault if row == self.frow else self.by_row[row]

    def legal(self, rows):
        """True when no pair of the given order breaks must_keep_order (only pairs that are the other way round than recorded are checked)."""
        for i in range(len(rows)):
            for j in range(i + 1, len(rows)):
                if rows[i] > rows[j] and must_keep_order(self.by_row[rows[j]], self.by_row[rows[i]], self.fused) is not None:
                    return False
        return True

    def candidate(self, rows, gaps=None, queue_depth=1):
        gaps = dict(gaps or {})
        rows = [r for r in rows if r in self.by_row]
        return {"rows": list(rows), "gaps": {r: int(gaps.get(r, self.recorded_gap[r])) for r in rows + [self.frow]},
                "queue_depth": max(1, min(self.max_queue_depth, int(queue_depth or 1)))}

    def steps_of(self, cand, note=None):
        """The replay steps of a candidate: the kept commands in its order, then the failing command; every field copied from the pool."""
        out = []
        for r in cand["rows"] + [self.frow]:
            s = dict(self.step(r))
            s["parameters"] = dict(s.get("parameters") or {})
            s["step"] = len(out) + 1
            s["gap_us"] = int(cand["gaps"][r])
            if note:
                s["why"] = [note] + [w for w in (s.get("why") or []) if w != note]
            out.append(s)
        return out


def key_of(cand):
    return (tuple(cand["rows"]), tuple(cand["gaps"][r] for r in cand["rows"]), cand["gaps"][max(cand["gaps"], key=lambda r: r not in cand["rows"])], cand["queue_depth"])


# ---------------------------------------------------------------------------------------------- the benches
def _judge_plan(oracle, steps):
    return {"oracle_fault": oracle, "steps": steps, "fault_step": len(steps)}


class HiddenTriggerBench:
    """A simulated drive with a hidden trigger, beside f2t_nvme.SimDrive (same Result, same rule for what is sent, same judgement).

    trigger = {"needed": [fingerprints], "k": at least this many of them were sent before the failing command,
               "gap_min_us", "gap_max_us": the gap before the failing command lies between them,
               "blocker": a fingerprint that must NOT have been sent (it clears the state), or None,
               "queue_depth_min": at least this many commands kept open,
               "miss_share": the share of runs in which the failure stays away although every condition is met}
    When every condition is met (and the run is not a miss) the failing command shows the recorded failure. Otherwise it completes
    normally; with slope=True its time grows with the share of conditions met (a drive that gets slower near its fault): this is the
    only hint the search gets, and only through the measured time. With slope=False there is no hint at all."""
    kind = "simulated"
    label = SIMULATED

    def __init__(self, oracle, trigger, recorded_time_us, usual_time_us=50.0, seed=0, slope=True):
        if oracle.get("kind") not in SEARCHABLE:
            raise BenchNotReady("this kind of failure (%s) does not show in the outcome of one command, so a replay search cannot look for it" % (oracle.get("words") or oracle.get("kind")))
        self.oracle, self.trigger, self.slope = oracle, dict(trigger), slope
        self.limit_us = float(oracle.get("limit_us") or 0) or None
        self.recorded_us = float(recorded_time_us or self.limit_us or 1000.0)
        self.usual_us = float(usual_time_us or 50.0)
        self.rnd = random.Random(seed)
        self.runs = 0

    def conditions(self, steps, queue_depth):
        """(conditions met, conditions in all) for a sequence: what the hidden drive checks. Not available to the search."""
        tr = self.trigger
        seen = [fingerprint(s) for s in steps[:-1] if is_sent(s)]
        met = total = 0
        need = list(tr.get("needed") or [])
        if need:
            k = int(tr.get("k") or len(need))
            total += k
            met += min(k, sum(1 for fp in need if tuple(fp) in seen))
        gap = steps[-1].get("gap_us") or 0
        total += 1
        met += 1 if float(tr.get("gap_min_us") or 0) <= gap <= float(tr.get("gap_max_us") if tr.get("gap_max_us") is not None else MAX_GAP_US) else 0
        if tr.get("blocker") is not None:
            total += 1
            met += 0 if tuple(tr["blocker"]) in seen else 1
        if int(tr.get("queue_depth_min") or 1) > 1:
            total += 1
            met += 1 if queue_depth >= int(tr["queue_depth_min"]) else 0
        if tr.get("impossible"):
            total += 1
        return met, total

    def _one(self, steps, queue_depth):
        self.runs += 1
        met, total = self.conditions(steps, queue_depth)
        o = self.oracle
        jitter = 1 + (self.rnd.random() - 0.5) * 0.1                      # the measured time varies by 5 per cent either way
        if met == total and self.rnd.random() >= float(self.trigger.get("miss_share") or 0):
            if o["kind"] == "timeout":
                res = T.Result(T.HOST_ABORTED, seconds=(self.limit_us or self.recorded_us) / 1e6, timed_out=True)
            elif o["kind"] == "latency":
                res = T.Result(0, seconds=max(self.recorded_us, (self.limit_us or 0) * 1.05) * (1 + abs(jitter - 1)) / 1e6)
            else:
                st = ((o.get("sct") if o.get("sct") is not None else 0) << 8) | (o.get("sc") if o.get("sc") is not None else 6)
                res = T.Result(st, seconds=self.recorded_us * jitter / 1e6)
        else:
            near = (met / total) ** 2 if (self.slope and total) else 0.0
            top = min(self.recorded_us, 0.8 * self.limit_us) if (self.limit_us and o["kind"] in ("timeout", "latency")) else self.recorded_us
            us = self.usual_us + max(0.0, 0.8 * top - self.usual_us) * near
            if self.limit_us and o["kind"] in ("timeout", "latency"):
                us = min(us, 0.8 * self.limit_us / 1.05)                  # a run without the failure never crosses the limit by itself
            res = T.Result(0, seconds=us * jitter / 1e6)
        seen, _why = T.fault_seen(_judge_plan(o, steps), res, 512, 1, 0, 1)
        return {"reproduced": bool(seen), "time_us": round(res.seconds * 1e6, 3)}

    def run(self, steps, queue_depth, n):
        return [self._one(steps, queue_depth) for _ in range(n)]


def random_trigger(pool, rnd, miss_share=0.1, impossible=False, needed=(4, 6)):
    """A hidden trigger for the simulated drive, drawn from the pool: `needed` (lowest, highest number) commands that must all have
    been sent, a largest gap before the failing command below the first sequence's gap, in half of the cases a command that must be
    left out, and a queue depth where the recording has several queues."""
    sent = [r for r in pool.rows if is_sent(pool.by_row[r])]
    fps = []
    for r in sent:
        fp = fingerprint(pool.by_row[r])
        if fp not in fps and fp != fingerprint(pool.fault):
            fps.append(fp)
    rnd.shuffle(fps)
    n_need = max(1, min(len(fps) - 1, rnd.randint(*needed)))
    needed, rest = fps[:n_need], fps[n_need:]
    seed_gap = pool.recorded_gap[pool.frow]
    gap_max = max(MIN_GAP_US, seed_gap // (2 ** rnd.randint(1, 3)))
    tr = {"needed": [list(x) for x in needed], "k": n_need, "gap_min_us": 0, "gap_max_us": gap_max,
          "blocker": list(rest[0]) if (rest and rnd.random() < 0.5) else None,
          "queue_depth_min": rnd.randint(1, min(2, pool.max_queue_depth)), "miss_share": miss_share}
    if impossible:
        tr["impossible"] = True
    return tr


def trigger_words(tr, pool):
    """The hidden trigger in plain words (shown after a search on the simulated drive, so the admin can compare)."""
    names = {tuple(fingerprint(s)): s for s in pool.by_row.values()}

    def cmd(fp):
        s = names.get(tuple(fp))
        return "%s (row %s of the recording)" % (s.get("command"), s.get("source_row")) if s else "a command"
    out = []
    if tr.get("needed"):
        out.append("at least %d of these commands were sent before the failing command: %s" % (int(tr.get("k") or len(tr["needed"])), "; ".join(cmd(fp) for fp in tr["needed"])))
    lo, hi = tr.get("gap_min_us") or 0, tr.get("gap_max_us")
    out.append("the gap before the failing command is %s%s" % (("at least %s microseconds and " % lo) if lo else "", "at most %s microseconds" % hi))
    if tr.get("blocker") is not None:
        out.append("this command was not sent before it: %s" % cmd(tr["blocker"]))
    if int(tr.get("queue_depth_min") or 1) > 1:
        out.append("at least %d commands were kept open at once" % int(tr["queue_depth_min"]))
    out.append("even then the failure stays away in about %d of 100 runs (random misses)" % round(100 * float(tr.get("miss_share") or 0)))
    return out


class RealBench:
    """The application's bench connection (app/bench_hook.py HardwareBench). One call of its run() per run; the scenario carries the
    recorded steps and the queue depth. Its run() raises NotImplementedError until the site writes it: BenchNotReady, in plain words."""
    kind = "real"
    label = REAL

    def __init__(self, signature, workdir, hook=None):
        self.signature, self.workdir, self.hook, self.runs = signature, workdir, hook, 0

    def _bench(self):
        if self.hook is None:
            app_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "app")
            if app_dir not in sys.path:
                sys.path.insert(0, app_dir)
            try:
                import bench_hook
                self.hook = bench_hook.HardwareBench(self.signature, workdir=self.workdir)
            except Exception as e:      # noqa: BLE001 - the admin reads why
                raise BenchNotReady("the real bench could not be opened (%s: %s). Nothing was run on a device." % (type(e).__name__, str(e)[:200]))
        return self.hook

    def run(self, steps, queue_depth, n):
        bench, out = self._bench(), []
        scenario = {"commands": [{"op": s.get("command"), "opc": s.get("opc"), "admin": bool(s.get("admin")), "parameters": s.get("parameters"), "gap_us": s.get("gap_us"),
                                  "source_row": s.get("source_row")} for s in steps],
                    "timing": {"qd": queue_depth, "inter_cmd_us": steps[-1].get("gap_us")}, "power_state": "none", "steps": steps, "queue_depth": queue_depth}
        for _ in range(n):
            try:
                r = bench.run(scenario)
            except NotImplementedError:
                raise BenchNotReady("The real bench is not connected yet: the bench connection of this application (app/bench_hook.py) has no code "
                                    "that drives a device. Nothing was run on a device. Choose the simulated drive, or have the bench connection "
                                    "written first (deploy/BENCH_INTEGRATION.md says how).")
            self.runs += 1
            if not isinstance(r, dict):
                raise BenchNotReady("the real bench answered with something that is not a result (see deploy/BENCH_INTEGRATION.md); nothing is counted")
            t = r.get("fault_time_us")
            out.append({"reproduced": bool(r.get("reproduced")), "time_us": float(t) if isinstance(t, (int, float)) else None})
        return out


# ---------------------------------------------------------------------------------------------- the search
class _Runner:
    """Counts every bench run against the budget and keeps every candidate tried, so nothing is hidden."""

    def __init__(self, pool, bench, recorded_time_us, budget, progress=None, stop=None):
        self.pool, self.bench, self.recorded_us = pool, bench, recorded_time_us
        self.budget, self.used, self.used_by = int(budget), 0, {"search": 0, "confirm": 0, "smaller": 0, "stress": 0}
        self.stats, self.order, self.progress, self.stop = {}, [], progress, stop
        self.extra = 0                       # the stress step's allowance, added when it starts

    def left(self):
        return self.budget + self.extra - self.used

    def run(self, cand, n, phase, how):
        if self.stop is not None and self.stop():
            raise Stopped()
        n = min(n, self.left())
        k = key_of(cand)
        st = self.stats.get(k)
        if st is None:
            st = self.stats[k] = {"cand": cand, "runs": 0, "reproduced": 0, "times": [], "phase": phase, "how": how, "no": len(self.order) + 1}
            self.order.append(k)
        if n <= 0:
            return st
        for r in self.bench.run(self.pool.steps_of(cand), cand["queue_depth"], n):
            st["runs"] += 1
            st["reproduced"] += 1 if r.get("reproduced") else 0
            if r.get("time_us") is not None:
                st["times"].append(r["time_us"])
        self.used += n
        self.used_by[phase] = self.used_by.get(phase, 0) + n
        if self.progress is not None:
            self.progress(self.used, self.budget + self.extra, phase, st)
        return st

    def closeness(self, st):
        if not st["times"] or not self.recorded_us:
            return 0.0
        return sum(max(0.0, 1 - abs(t - self.recorded_us) / self.recorded_us) for t in st["times"]) / len(st["times"])

    def reward(self, st):
        """(share of runs in which the failure came back, closeness of the measured time to the recorded one): compared in this order."""
        return (st["reproduced"] / st["runs"] if st["runs"] else 0.0, round(self.closeness(st), 4))

    def row(self, st):
        c, pool = st["cand"], self.pool
        steps = pool.steps_of(c)
        return {"no": st["no"], "phase": st["phase"], "how": st["how"], "rows": list(c["rows"]) + [pool.frow],
                "commands": [s.get("command") for s in steps], "gaps_us": [s["gap_us"] for s in steps], "queue_depth": c["queue_depth"],
                "runs": st["runs"], "reproduced": st["reproduced"],
                "mean_time_us": round(sum(st["times"]) / len(st["times"]), 3) if st["times"] else None}


def _insert(pool, rows, r):
    """Put a recorded command into an order at its recorded place (before the first command recorded after it)."""
    at = next((i for i, x in enumerate(rows) if x > r), len(rows))
    return rows[:at] + [r] + rows[at:]


def mutate(pool, cand, op, rnd):
    """One change of a candidate. -> the new candidate, or None when the operator does not apply. Only selection, order, gaps and queue
    depth change; the result is always a legal order of commands of the pool."""
    rows, gaps, qd = list(cand["rows"]), dict(cand["gaps"]), cand["queue_depth"]
    out_rows = [r for r in pool.rows if r not in rows]
    if op in ("add", "add_some"):
        if not out_rows:
            return None
        for r in rnd.sample(out_rows, min(len(out_rows), 1 if op == "add" else rnd.randint(2, 3))):
            new = _insert(pool, rows, r)
            if pool.legal(new):
                rows = new
                gaps[r] = pool.recorded_gap[r]
    elif op == "add_all":
        if not out_rows:
            return None
        rows = list(pool.rows)
        for r in out_rows:
            gaps[r] = pool.recorded_gap[r]
    elif op == "resample":
        return random_candidate(pool, rnd)
    elif op in ("remove", "remove_some"):
        if not rows:
            return None
        for r in rnd.sample(rows, min(len(rows), 1 if op == "remove" else rnd.randint(2, 3))):
            rows.remove(r)
            gaps.pop(r, None)
    elif op == "swap":
        idx = [i for i in range(len(rows) - 1)]
        rnd.shuffle(idx)
        for i in idx:
            new = rows[:i] + [rows[i + 1], rows[i]] + rows[i + 2:]
            if pool.legal(new):
                rows = new
                break
        else:
            return None
    elif op in ("gap_shorter", "gap_longer", "gap_recorded"):
        if not rows:
            return None
        r = rnd.choice(rows)
        gaps[r] = max(MIN_GAP_US, gaps[r] // 2) if op == "gap_shorter" else min(MAX_GAP_US, gaps[r] * 2) if op == "gap_longer" else pool.recorded_gap[r]
    elif op == "fault_gap_shorter":
        gaps[pool.frow] = max(MIN_GAP_US, gaps[pool.frow] // 2)
    elif op == "fault_gap_longer":
        gaps[pool.frow] = min(MAX_GAP_US, max(pool.recorded_gap[pool.frow], MIN_GAP_US) * 4, gaps[pool.frow] * 2)
    elif op == "queue_deeper":
        if qd >= pool.max_queue_depth:
            return None
        qd += 1
    elif op == "queue_shallower":
        if qd <= 1:
            return None
        qd -= 1
    else:
        return None
    new = pool.candidate(rows, gaps, qd)
    return None if key_of(new) == key_of(cand) else new


def operators_for(pool):
    ops = ["add", "add_some", "add_all", "remove", "remove_some", "swap", "gap_shorter", "gap_longer", "gap_recorded", "fault_gap_shorter", "fault_gap_longer", "resample"]
    if pool.max_queue_depth > 1:
        ops += ["queue_deeper", "queue_shallower"]
    return ops


def _confirm(run, st, phase="confirm"):
    """Run a candidate up to CONFIRM_RUNS times in all (as far as the budget goes)."""
    more = min(CONFIRM_RUNS - st["runs"], run.left())
    return run.run(st["cand"], more, phase, st["how"]) if more > 0 else st


def _climb(run, pool, seed, rnd, first=None):
    """Hill climbing from the seed with a Thompson bandit over the operators. -> (the confirmed candidate's record or None, operator counts).

    first (2026-11-15): candidates read from the procedural graph (nvme_hier/graph_learning.plan), tried before anything else, in their
    order: the best stored solution put onto this recording unchanged, then the first sequence with the stored timing values. One that
    brings the failure back is confirmed like any other; one that does not costs EVAL_RUNS runs and the search goes on as without the
    graph. With first empty or None nothing here runs and the search is exactly the one of 2026-11-14."""
    ops = operators_for(pool)
    ab = {o: [1, 1] for o in ops}                     # per operator: 1 + times it made a candidate better, 1 + times it did not
    led = []
    for f in first or ():
        if run.left() < EVAL_RUNS or key_of(f["cand"]) in run.stats:
            continue
        st = run.run(f["cand"], EVAL_RUNS, "search", f["how"])
        led.append(st)
        if st["reproduced"]:
            st = _confirm(run, st)
            if st["runs"] >= CONFIRM_RUNS and st["reproduced"] >= CONFIRM_NEED:
                return st, ab
    cur = run.run(seed, EVAL_RUNS if key_of(seed) not in run.stats else 0, "search", "the first sequence, unchanged")
    if cur["reproduced"]:
        cur = _confirm(run, cur)
        if cur["runs"] >= CONFIRM_RUNS and cur["reproduced"] >= CONFIRM_NEED:
            return cur, ab
    for st in led:                                    # a graph candidate that is nearer to the failure than the first sequence is where the climb starts
        ra, rb = run.reward(st), run.reward(cur)
        if ra[0] > rb[0] or (ra[0] == rb[0] and ra[1] > rb[1] + SWEEP_MARGIN):
            cur = st
    # 1. the two anchors: the first sequence (above) and every recorded command before the failing one, as recorded
    # 2. one pass over each value by itself (first improvement is kept): the gap before the failing command down its halving ladder,
    #    the queue depth, each command left out, each missing command put back
    def better(st, ref):
        a_, b_ = run.reward(st), run.reward(ref)
        return a_[0] > b_[0] or (a_[0] == b_[0] and a_[1] > b_[1] + SWEEP_MARGIN)

    def moves(c):
        g = c["gaps"][pool.frow]
        while g > MIN_GAP_US:
            g = max(MIN_GAP_US, g // 2)
            yield pool.candidate(c["rows"], dict(c["gaps"], **{}) | {pool.frow: g}, c["queue_depth"]), "fault_gap_shorter"
        for q in range(c["queue_depth"] + 1, pool.max_queue_depth + 1):
            yield pool.candidate(c["rows"], c["gaps"], q), "queue_deeper"
        for r in list(c["rows"]):
            yield pool.candidate([x for x in c["rows"] if x != r], c["gaps"], c["queue_depth"]), "remove"
        for r in [x for x in pool.rows if x not in c["rows"]]:
            new = _insert(pool, list(c["rows"]), r)
            if pool.legal(new):
                yield pool.candidate(new, c["gaps"], c["queue_depth"]), "add"
    full = mutate(pool, seed, "add_all", rnd)
    if full is not None and run.left() >= EVAL_RUNS:
        st = run.run(full, EVAL_RUNS, "search", OPERATOR_WORDS["add_all"])
        ab["add_all"][0 if better(st, cur) else 1] += 1
        if st["reproduced"]:
            st = _confirm(run, st)
            if st["runs"] >= CONFIRM_RUNS and st["reproduced"] >= CONFIRM_NEED:
                return st, ab
        if run.reward(st) >= run.reward(cur):
            cur = st
    moved = True
    while moved and run.left() >= EVAL_RUNS:
        moved = False
        for kind in ("fault_gap_shorter", "queue_deeper", "remove", "add"):
            for cand, op in [m for m in moves(cur["cand"]) if m[1] == kind]:
                if run.left() < EVAL_RUNS:
                    break
                if op in ("remove", "add") and len(set(cand["rows"]) ^ set(cur["cand"]["rows"])) != 1:
                    continue                     # the list was made before an improvement was kept: the next pass tries this command again
                if op == "remove":
                    cand = pool.candidate(cand["rows"], cur["cand"]["gaps"], cur["cand"]["queue_depth"])
                elif op == "add":
                    cand = pool.candidate(cand["rows"], dict(cur["cand"]["gaps"], **{}) | {r: cand["gaps"][r] for r in cand["rows"] if r not in cur["cand"]["gaps"]}, cur["cand"]["queue_depth"])
                if key_of(cand) in run.stats:
                    continue
                st = run.run(cand, EVAL_RUNS, "search", "one value at a time: " + OPERATOR_WORDS[op])
                good = better(st, cur)
                ab[op][0 if good else 1] += 1
                if st["reproduced"]:
                    st = _confirm(run, st)
                    if st["runs"] >= CONFIRM_RUNS and st["reproduced"] >= CONFIRM_NEED:
                        return st, ab
                if good:
                    cur, moved = st, True
    # 3. the rest of the budget: random changes, the operator chosen by the bandit
    idle = 0
    while run.left() >= EVAL_RUNS and idle < 400:
        op = max(ops, key=lambda o: rnd.betavariate(ab[o][0], ab[o][1]))
        parent = cur
        if rnd.random() < 0.15 and len(run.order) > 3:                    # now and then from one of the best five so far
            best5 = sorted(run.stats.values(), key=run.reward, reverse=True)[:5]
            parent = rnd.choice(best5)
        cand = mutate(pool, parent["cand"], op, rnd)
        if cand is None or key_of(cand) in run.stats:
            idle += 1
            continue
        idle = 0
        st = run.run(cand, EVAL_RUNS, "search", OPERATOR_WORDS[op])
        better = run.reward(st) > run.reward(parent)
        ab[op][0 if better else 1] += 1
        if st["reproduced"]:
            st = _confirm(run, st)
            if st["runs"] >= CONFIRM_RUNS and st["reproduced"] >= CONFIRM_NEED:
                return st, ab
        rs, rc = run.reward(st), run.reward(cur)
        if (rs[0], rs[1] + CLOSE_NOISE) >= rc:              # as good within the noise of the measured time: move on (lets the search drift on a plateau)
            cur = st
    return None, ab


def _smaller(run, pool, best):
    """Leave out every command the failure does not need (one pass, 2 of 3 runs), then confirm the smaller sequence; kept only when
    the confirmation holds and the budget allows it."""
    cur = best["cand"]
    for r in list(reversed(cur["rows"])):
        if run.left() < STRESS_RUNS + CONFIRM_RUNS:
            break
        trial = pool.candidate([x for x in cur["rows"] if x != r], cur["gaps"], cur["queue_depth"])
        st = run.run(trial, STRESS_RUNS, "smaller", "leave one command out: is it needed?")
        if st["runs"] >= STRESS_RUNS and st["reproduced"] >= STRESS_NEED:
            cur = trial
    if key_of(cur) == key_of(best["cand"]) or run.left() < 1:
        return best
    st = _confirm(run, run.run(cur, 0, "smaller", "the smaller sequence"), "smaller")
    return st if (st["runs"] >= CONFIRM_RUNS and st["reproduced"] >= CONFIRM_NEED) else best


def stress(run, pool, start, max_runs=STRESS_MAX_RUNS):
    """Push each timing value step by step in its stressful direction while the failure still comes back in STRESS_NEED of STRESS_RUNS
    runs. Values, in this order: the gap before the failing command, the queue depth, the gaps before the other commands (last first).
    A gap step halves the gap (never below MIN_GAP_US); a queue step keeps one more command open (never more than the recording
    showed). -> {"candidate", "steps": every step tried with its count, "conditions": the furthest value kept per timing value}."""
    run.extra = max_runs
    spent0 = run.used
    cur = start
    tried, conds = [], []

    def name(r):
        s = pool.step(r)
        return "the gap before the failing command (%s)" % s.get("command") if r == pool.frow else "the gap before %s (row %s of the recording)" % (s.get("command"), r)
    values = [("gap", pool.frow), ("queue", None)] + [("gap", r) for r in reversed(start["rows"])]
    for kind, r in values:
        first = cur["gaps"][r] if kind == "gap" else cur["queue_depth"]
        last_kept, last_count = first, None
        while run.used - spent0 + STRESS_RUNS <= max_runs:
            v = cur["gaps"][r] if kind == "gap" else cur["queue_depth"]
            nv = max(MIN_GAP_US, v // 2) if kind == "gap" else min(pool.max_queue_depth, v + 1)
            if nv == v:
                break
            gaps2 = dict(cur["gaps"])
            if kind == "gap":
                gaps2[r] = nv
            trial = pool.candidate(cur["rows"], gaps2, nv if kind == "queue" else cur["queue_depth"])
            st = run.run(trial, STRESS_RUNS, "stress", "stress step: %s" % ("halve " + name(r) if kind == "gap" else "keep one more command open"))
            kept = st["runs"] >= STRESS_RUNS and st["reproduced"] >= STRESS_NEED
            tried.append({"value": name(r) if kind == "gap" else "the queue depth (commands kept open at once)", "unit": "microseconds" if kind == "gap" else "commands",
                          "from": v, "to": nv, "kept": kept, "reproduced": st["reproduced"], "runs": st["runs"]})
            if not kept:
                break
            cur, last_kept, last_count = trial, nv, (st["reproduced"], st["runs"])
        if last_count is not None:
            conds.append({"value": name(r) if kind == "gap" else "the queue depth (commands kept open at once)", "unit": "microseconds" if kind == "gap" else "commands",
                          "from": first, "to": last_kept, "reproduced": last_count[0], "runs": last_count[1],
                          "words": "%s: pushed from %s to %s %s; at %s the failure came back in %d of %d runs" % (
                              name(r) if kind == "gap" else "the queue depth (commands kept open at once)", first, last_kept, "microseconds" if kind == "gap" else "commands",
                              last_kept, last_count[0], last_count[1])})
    return {"candidate": cur, "steps": tried, "conditions": conds, "runs": run.used - spent0, "changed": key_of(cur) != key_of(start)}


def describe(pool, cand, seed):
    """What differs between a candidate and the seed, in plain words."""
    out = []
    added = [r for r in cand["rows"] if r not in seed["rows"]]
    left = [r for r in seed["rows"] if r not in cand["rows"]]
    if added:
        out.append("added %d recorded command(s): %s" % (len(added), "; ".join("%s (row %s)" % (pool.by_row[r].get("command"), r) for r in added)))
    if left:
        out.append("left out %d command(s) of the first sequence: %s" % (len(left), "; ".join("%s (row %s)" % (pool.by_row[r].get("command"), r) for r in left)))
    if cand["rows"] != sorted(cand["rows"]):
        out.append("the order differs from the recorded one (only between commands that do not depend on each other)")
    fg, sg = cand["gaps"][pool.frow], seed["gaps"][pool.frow]
    if fg != sg:
        out.append("the gap before the failing command is %d microseconds (first sequence: %d)" % (fg, sg))
    other = [r for r in cand["rows"] if r in seed["rows"] and cand["gaps"][r] != seed["gaps"][r]]
    if other:
        out.append("the gap before %d other command(s) changed" % len(other))
    if cand["queue_depth"] != seed["queue_depth"]:
        out.append("%d commands are kept open at once (first sequence: %d)" % (cand["queue_depth"], seed["queue_depth"]))
    return out or ["the same as the first sequence"]


def _summary_of(run, pool, st, seed, note):
    c = st["cand"]
    return {"steps": pool.steps_of(c, note), "rows": list(c["rows"]) + [pool.frow], "queue_depth": c["queue_depth"], "reproduced": st["reproduced"], "runs": st["runs"],
            "lower_bound": round(T.lower_bound(st["reproduced"], st["runs"]), 4) if st["runs"] else 0.0,
            "lower_bound_basis": "exact one-sided 95 per cent lower bound of the rate (f2t_nvme.lower_bound)",
            "mean_time_us": round(sum(st["times"]) / len(st["times"]), 3) if st["times"] else None, "changes": describe(pool, c, seed)}


def search(pool, seed, bench, budget=BUDGET_DEFAULT, recorded_time_us=None, rng_seed=0, progress=None, stop=None, do_stress=True, strategy="search", first=None):
    """The whole step: search from the seed within the budget, make the sequence smaller, then the stress step.

    strategy "search" is the hill climbing; "random" is the plain baseline (random candidates, one run each, the same budget and the
    same confirmation), kept for the measured comparison. Raises Stopped (nothing to store) and BenchNotReady.
    -> the result (see the keys); "found" is True only when a candidate brought the failure back in CONFIRM_NEED of CONFIRM_RUNS."""
    budget = max(1, int(budget))
    rnd = random.Random(rng_seed)
    run = _Runner(pool, bench, recorded_time_us, budget, progress, stop)
    if strategy == "random":
        best, ab = _random_walk(run, pool, seed, rnd), {}
    else:
        best, ab = _climb(run, pool, seed, rnd, first)
    seed_st = run.stats.get(key_of(seed)) or {"reproduced": 0, "runs": 0}     # with a graph candidate confirmed first, the first sequence was not run
    note = "kept by the replay search on the %s" % bench.label
    out = {"bench": {"kind": bench.kind, "label": bench.label, "simulated": bench.kind == "simulated"}, "strategy": strategy,
           "seed": {"steps": pool.steps_of(seed), "queue_depth": seed["queue_depth"], "reproduced": seed_st["reproduced"], "runs": seed_st["runs"]},
           "pool": {"commands": len(pool.rows), "io_queues": pool.io_queues, "max_queue_depth": pool.max_queue_depth},
           "recorded_time_us": recorded_time_us, "found": best is not None, "stress": None, "best": None, "most_stressful": None}
    if best is not None:
        if strategy == "search":
            best = _smaller(run, pool, best)
        out["best"] = _summary_of(run, pool, best, seed, note)
        out["verdict"] = "the failure came back in %d of %d runs on the %s" % (best["reproduced"], best["runs"], bench.label)
        if do_stress:
            sx = stress(run, pool, best["cand"])
            last = run.stats[key_of(sx["candidate"])]
            out["stress"] = {"steps": sx["steps"], "conditions": sx["conditions"], "runs": sx["runs"], "changed": sx["changed"],
                             "need": "a step is kept when the failure comes back in at least %d of %d runs" % (STRESS_NEED, STRESS_RUNS)}
            if sx["changed"]:
                out["most_stressful"] = _summary_of(run, pool, last, seed, "most stressful conditions found by the stress step on the %s" % bench.label)
    else:
        seen = [st for st in run.stats.values() if st["reproduced"]]
        if seen:
            top = max(seen, key=lambda st: (T.lower_bound(st["reproduced"], st["runs"]), st["reproduced"]))
            out["closest"] = _summary_of(run, pool, top, seed, note)
            out["verdict"] = ("not reproduced within the budget: no sequence brought the failure back in %d of %d runs; the best one did in %d of %d"
                              % (CONFIRM_NEED, CONFIRM_RUNS, top["reproduced"], top["runs"]))
        else:
            out["verdict"] = "not reproduced within the budget: the failure did not come back in any of the %d runs" % run.used
    out["budget"] = {"asked": budget, "used": run.used, "search": run.used_by.get("search", 0), "confirm": run.used_by.get("confirm", 0),
                     "smaller": run.used_by.get("smaller", 0), "stress": run.used_by.get("stress", 0), "stress_allowance": STRESS_MAX_RUNS if (best is not None and do_stress) else 0,
                     "unit": "bench runs (one run = the whole candidate sequence replayed once)"}
    if first and strategy != "random":               # what the graph gave, with what each brought (nothing here when the graph gave nothing)
        out["started_from"] = []
        for f in first:
            st = run.stats.get(key_of(f["cand"]))
            row = run.row(st) if st else {"runs": 0, "reproduced": 0, "mean_time_us": None}
            out["started_from"].append(dict({k: v for k, v in f.items() if k != "cand"}, runs=row["runs"], reproduced=row["reproduced"], mean_time_us=row["mean_time_us"],
                                            steps=pool.steps_of(f["cand"]), queue_depth=f["cand"]["queue_depth"]))
    out["operators"] = [{"operator": OPERATOR_WORDS[o], "tried": ab[o][0] + ab[o][1] - 2, "made_it_better": ab[o][0] - 1} for o in ab]
    out["candidates"] = [run.row(run.stats[k]) for k in run.order]
    return out


def random_candidate(pool, rnd):
    """A plain random candidate: every pool command kept with probability one half, a few random legal swaps, every gap drawn from the
    halving ladder below its recorded value, a random queue depth."""
    rows = [r for r in pool.rows if rnd.random() < 0.5]
    for _ in range(rnd.randint(0, 3)):
        if len(rows) > 1:
            i = rnd.randrange(len(rows) - 1)
            new = rows[:i] + [rows[i + 1], rows[i]] + rows[i + 2:]
            if pool.legal(new):
                rows = new
    gaps = {}
    for r in rows + [pool.frow]:
        g = pool.recorded_gap[r]
        ladder = [g]
        while ladder[-1] > MIN_GAP_US:
            ladder.append(max(MIN_GAP_US, ladder[-1] // 2))
        gaps[r] = rnd.choice(ladder)
    return pool.candidate(rows, gaps, rnd.randint(1, pool.max_queue_depth))


def _random_walk(run, pool, seed, rnd):
    """The baseline: the seed, then random candidates, EVAL_RUNS runs each; the first that brings the failure back is confirmed."""
    st = run.run(seed, EVAL_RUNS, "search", "the first sequence, unchanged")
    idle = 0
    while True:
        if st["reproduced"]:
            st = _confirm(run, st)
            if st["runs"] >= CONFIRM_RUNS and st["reproduced"] >= CONFIRM_NEED:
                return st
        if run.left() < EVAL_RUNS or idle > 400:
            return None
        cand = random_candidate(pool, rnd)
        if key_of(cand) in run.stats:
            idle += 1
            continue
        idle = 0
        st = run.run(cand, EVAL_RUNS, "search", "a random choice of commands, order, gaps and queue depth")


def invented(pool, result):
    """Every row a result uses that is not a command of the pool (must be empty): the check behind 'nothing invented'."""
    ok = set(pool.rows) | {pool.frow}
    bad = [r for c in result.get("candidates") or [] for r in c["rows"] if r not in ok]
    parts = [result.get(part) or {} for part in ("best", "most_stressful", "closest")] + list(result.get("started_from") or [])     # also what came from the graph
    for part in parts:
        for s in part.get("steps") or []:
            src = pool.step(s["source_row"]) if s.get("source_row") in ok else None
            if src is None or src.get("opc") != s.get("opc") or (src.get("parameters") or {}) != (s.get("parameters") or {}):
                bad.append(s.get("source_row"))
    return bad
