// One error of a CSV file that is not part of the tree (2026-11-14): 1 the error -> 2 the row with the meaning of every column ->
// 3 the rows around it (n above, m below; "only rows with the same value" only for a column the dictionary or the admin names) ->
// 4 the isolation of the defect -> 5 what this page cannot do for a file of a tool the application does not know.
// Every text about a column comes from the server, which copies it from Family 1's approved dictionary. Nothing is chosen in advance.
import { api, $, esc } from "./api.js";

const QUERY = new URLSearchParams(location.search);
const RUN = QUERY.get("run"), ERR = QUERY.get("error");
const BASE = `/api/other-errors/${encodeURIComponent(RUN)}/${encodeURIComponent(ERR)}`;
const USE_STANDIN = QUERY.get("standin") === "1";
const STATE = { error: null, window: null };
const ALL_ROWS = "all";             // the select's value for "every row"; an offered column is "c" + its place in the offered list, never its name

const adminName = () => ($("name").value || "").trim();
const setStatus = (id, text, cls = "") => { const e = $(id); if (e) { e.textContent = text; e.className = "status " + cls; } };
const whole = x => Number(x).toLocaleString("en-US");
const whenWords = ts => ts ? new Date(ts * 1000).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "at a time that was not kept";
const meaningOf = c => c.meaning ? esc(c.meaning) : `<span class="unsourced">no meaning known</span>`;
const sourceOf = c => `<span class="${c.sourced ? "" : "unsourced"}">${esc(c.source_words)}</span>`;

function showError(d) {
  document.title = `Row ${whole(d.row)} of ${d.file}`;
  $("page-title").textContent = `One error: row ${whole(d.row)} of ${d.file}`;
  $("back-link").textContent = d.analysis ? `Back to the analysis “${d.analysis}”` : "Back to the analysis";
  const steps = (d.rule.steps || []).map(s => `<li>${esc(s)}</li>`).join("");
  $("error-out").innerHTML = `
    <div class="kv" style="display:grid;grid-template-columns:220px minmax(0,1fr);gap:6px 14px">
      <b>Where</b><span>${esc(d.where)}</span>
      <b>Found by the rule</b><span>${esc(d.rule.name)}${d.rule.section ? ` <span class="hint">· section “${esc(d.rule.section)}”, group “Other CSV files”</span>` : ""}</span>
      <b>The rule in your words</b><span>${esc(d.rule.admin_words || "no description was kept with the rule")}</span>
      <b>The file's folder</b><span>${esc(d.folder || "not kept")}</span>
      <b>The data dictionary</b><span>${esc(d.dictionary.words)}</span>
    </div>
    ${steps ? `<details style="margin-top:8px"><summary>The steps of the rule, as you approved them</summary><ol>${steps}</ol></details>` : ""}`;
}

function showRow(d) {
  const body = d.columns.map(c => `<tr><td><b>${esc(c.column)}</b></td><td>${esc(c.value)}${c.value_meaning ? `<span class="why">this value, by the dictionary: ${esc(c.value_meaning)}</span>` : ""}</td>
    <td>${meaningOf(c)}</td><td>${sourceOf(c)}</td></tr>`).join("");
  const extra = (d.cells_beyond_the_header || []).map(x => `<tr><td><i>cell ${whole(x.position)}, beyond the line of column names</i></td><td>${esc(x.value)}</td>
    <td><span class="unsourced">no meaning known: the file names no column for this cell</span></td><td></td></tr>`).join("");
  $("row-out").innerHTML = `<div class="wrap"><table class="rows"><thead><tr>
      <th>Column<span class="why">its name in the file's first line</span></th>
      <th>Value in this row<span class="why">exactly as the file holds it</span></th>
      <th>What the column means<span class="why">copied from the approved data dictionary</span></th>
      <th>Where the meaning comes from<span class="why">as the dictionary marks it</span></th></tr></thead><tbody>${body}${extra}</tbody></table></div>`;
}

function showChoices(d) {
  const def = d.window_default;
  $("why-n").textContent = `A whole number from 0 to ${whole(def.most)} rows to show before this row. Leave it empty to use ${def.n} rows. ${def.why}`;
  $("why-m").textContent = `A whole number from 0 to ${whole(def.most)} rows to show after this row. Leave it empty to use ${def.m} rows. ${def.why}`;
  const keep = $("win-same").value;
  const offered = d.same_value_columns || [];
  $("win-same").innerHTML = `<option value="">choose which rows to show</option><option value="${esc(ALL_ROWS)}">every row of the file around this one</option>` +
    offered.map((c, i) => `<option value="c${i}">only rows with the same value of “${esc(c.column)}” as this row</option>`).join("");
  $("win-same").value = keep;
  const reasons = offered.map(c => `“${c.column}”: ${c.why}`).join(" · ");
  $("why-same").textContent = `${d.same_value_rule} ${offered.length ? "Offered here: " + reasons : "No column of this file is named so yet, so only “every row” can be chosen; you can name one below."}`;
  const keepCol = $("grp-col").value;
  $("grp-col").innerHTML = `<option value="">choose a column of the file</option>` + d.all_columns.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join("");
  $("grp-col").value = keepCol;
}

function showCannot(d) {
  const m = d.cannot.mapping;
  const rows = m.needs.map(x => `<tr><td><b>${esc(x.words)}</b></td><td>${esc(x.sentence)}${(x.found || []).some(f => f.columns.some(h => !h.sourced))
    ? `<span class="why unsourced">At least one of these meanings is marked “meaning not sourced” in the dictionary.</span>` : ""}</td></tr>`).join("");
  $("cannot-out").innerHTML = `<p>${esc(d.cannot.words)}</p><p>${esc(d.cannot.would_need)}</p>
    <div class="wrap"><table class="rows"><thead><tr><th>What the later stages need<span class="why">one column for each of these six things</span></th>
      <th>What the approved dictionary says today<span class="why">${esc(m.basis)}</span></th></tr></thead><tbody>${rows}</tbody></table></div>
    <p class="mark">${esc(m.verdict)}</p>`;
}

function answerHtml(iso) {
  const a = iso.answer || {}, by = iso.written_by || {};
  const keys = ["what", "why", "when", "where", "who", "which", "how"];
  const lines = keys.map(k => `<b>${esc(iso.labels[k])}</b><span>${esc(a[k] || "not answered")}${by[k] ? `<span class="by">written by ${esc(by[k])}</span>` : ""}</span>`).join("");
  const cited = (a.cited_rows || []).length ? `rows ${a.cited_rows.map(whole).join(", ")} of the file (each checked by the code to be among the rows of section 3)` : "no row";
  const sameWords = iso.same_column ? `, only rows with the same value of “${esc(iso.same_column)}”` : "";
  return `${iso.refused ? `<div class="mark bad"><b>The model's answer was refused.</b> ${esc(iso.refused)}</div>` : ""}
    ${iso.marked ? `<div class="mark"><b>${esc(iso.marked)}</b></div>` : ""}
    <div class="answer ${iso.standin ? "standin" : ""}"><div class="q">${lines}<b>The rows it rests on</b><span>${cited}</span></div>
    ${(iso.problems || []).length ? `<p class="status warn">Checked by the code: ${esc(iso.problems.join("; "))}</p>` : ""}
    <p class="hint">Asked by ${esc(iso.asked_by || "nobody named")} on ${esc(whenWords(iso.asked_at))} · window: ${whole(iso.n)} rows above and ${whole(iso.m)} rows below${sameWords} · answered by ${esc(iso.standin ? "the stand-in (no model)" : iso.producer)}</p></div>`;
}

function showHistory(list) {
  $("history-out").innerHTML = list.length ? list.map(answerHtml).join("") : `<p class="locked">None yet.</p>`;
}

async function loadError() {
  if (!RUN || !ERR) { $("error-out").innerHTML = `<p class="status bad">This page needs the number of the analysis run and the number of the error in its address.</p>`; return; }
  try {
    const d = await api("GET", BASE);
    STATE.error = d;
    showError(d); showRow(d); showChoices(d); showCannot(d); showHistory(d.isolations || []);
  } catch (e) {
    $("error-out").innerHTML = `<p class="status bad">${esc(e.message)}</p>`;
    for (const id of ["row-out", "cannot-out"]) $(id).innerHTML = `<p class="locked">Not shown: the error could not be read.</p>`;
  }
}

function windowChoice() {
  // -> { n, m, same } or null with a sentence in the status when the admin has not chosen which rows to show
  const pick = $("win-same").value;
  if (!pick) { setStatus("window-status", "Choose which rows to show first: nothing is chosen for you.", "warn"); return null; }
  const offered = (STATE.error && STATE.error.same_value_columns) || [];
  const col = pick === ALL_ROWS ? null : offered[Number(pick.slice(1))];
  if (pick !== ALL_ROWS && !col) { setStatus("window-status", "Choose which rows to show again: the list of columns changed.", "warn"); return null; }
  return { n: $("win-n").value.trim(), m: $("win-m").value.trim(), same: col ? col.column : "" };
}

function showWindow(w) {
  const d = STATE.error;
  const meaning = {};
  for (const c of d.columns) meaning[c.column] = c;
  const head = w.header.map(h => `<th>${esc(h)}<span class="why">${meaning[h] && meaning[h].meaning ? esc(meaning[h].meaning) : "no meaning known"}</span></th>`).join("");
  const line = r => `<tr class="${r.position === "the error" ? "err" : ""}"><td class="num">${whole(r.row)}</td><td>${r.position === "the error" ? "THE ERROR" : r.position === "above" ? "before the error" : "after the error"}${r.also_found ? `<span class="why">also found by the same rule</span>` : ""}</td>${w.header.map((_h, i) => `<td>${esc(r.cells[i] ?? "")}</td>`).join("")}</tr>`;
  const sameWords = w.same ? ` Only rows whose “${esc(w.same.column)}” is “${esc(w.same.value)}”, the value of this row.` : " Every row of the file in that range.";
  const setBy = (who, v) => who === "default" ? `${whole(v)} (the starting value: nobody chose it)` : `${whole(v)} (typed by you)`;
  $("window-out").innerHTML = `<p class="guide">Asked for: ${setBy(w.n_set_by, w.n)} rows above and ${setBy(w.m_set_by, w.m)} rows below. Shown: ${whole(w.above)} above and ${whole(w.below)} below, in ${esc(w.order)}.${sameWords}
      The server read ${whole(w.rows_read)} rows of the ${whole(w.file_rows)} rows of the file for this, in ${w.seconds} seconds (measured by the server). ${esc(w.default_reason || "")} ${esc(w.note || "")}</p>
    <div class="wrap"><table class="rows"><thead><tr><th>Row<span class="why">its number in the file; row 1 is the first under the column names</span></th>
      <th>Position<span class="why">before or after the row the rule found</span></th>${head}</tr></thead><tbody>${w.rows.map(line).join("")}</tbody></table></div>`;
}

async function loadWindow() {
  const c = windowChoice();
  if (!c) return;
  setStatus("window-status", "Reading the rows around the error from the file…");
  try {
    const q = new URLSearchParams();
    if (c.n) q.set("n", c.n);
    if (c.m) q.set("m", c.m);
    if (c.same) q.set("same", c.same);
    const w = await api("GET", `${BASE}/window?${q}`);
    STATE.window = c;
    showWindow(w);
    setStatus("window-status", `${whole(w.rows.length)} rows shown.`, "ok");
  } catch (e) { setStatus("window-status", e.message, "bad"); }
}

async function nameGroupColumn() {
  if (!adminName()) { setStatus("group-status", "Type your name at the top first: it is kept with the column you name.", "warn"); return; }
  const column = $("grp-col").value;
  if (!column) { setStatus("group-status", "Choose the column first: nothing is chosen for you.", "warn"); return; }
  try {
    const r = await api("POST", `${BASE}/group-column`, { column, admin: adminName(), why: $("grp-why").value });
    STATE.error.same_value_columns = r.same_value_columns;
    showChoices(STATE.error);
    setStatus("group-status", `“${column}” is now offered in “Which rows to show”.`, "ok");
  } catch (e) { setStatus("group-status", e.message, "bad"); }
}

async function isolateDefect() {
  if (!adminName()) { setStatus("isolate-status", "Type your name at the top first: it is kept with the isolation.", "warn"); return; }
  const c = STATE.window || windowChoice();
  if (!c) { setStatus("isolate-status", "Show the rows around the error in section 3 first: the isolation reads exactly those rows.", "warn"); return; }
  setStatus("isolate-status", "Asking for the isolation of the defect from the rows of section 3 and the dictionary…");
  try {
    const body = { admin: adminName(), n: c.n || null, m: c.m || null, same: c.same || null };
    if (USE_STANDIN) body.standin = true;
    const iso = await api("POST", `${BASE}/isolate`, body);
    $("isolate-out").innerHTML = answerHtml(iso);
    setStatus("isolate-status", iso.standin ? "No model answered: the stand-in filled in what the code can state." : "The model answered; every row it cites is among the rows of section 3.", iso.standin ? "warn" : "ok");
    const h = await api("GET", `${BASE}/isolations`);
    showHistory(h.isolations || []);
  } catch (e) { setStatus("isolate-status", e.message, "bad"); }
}

$("btn-window").addEventListener("click", loadWindow);
$("btn-group").addEventListener("click", nameGroupColumn);
$("btn-isolate").addEventListener("click", isolateDefect);
loadError();
