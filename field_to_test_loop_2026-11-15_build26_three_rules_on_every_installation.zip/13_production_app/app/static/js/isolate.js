// One error's page (owner, 2026-11-11): 1 the error -> 2 the commands around it (a tree, like the hierarchy page) -> 3 the isolation of the
// defect (the model; you name the defect) -> 4 the procedural graph (is the defect stored? its causes; you name the cause) -> 5 the solution
// (stored ones ranked by your judgements, or the first one) -> 6 the test case. Each part opens when the one before it is done.
import { $, esc } from "./api.js";

// ---- the order of the flow (owner, 2026-11-15: "you should not go directly wherever you want"). An error's page is worked on only after the
// admin approved, on page 3 of the analysis, the result of the pattern that found the error. Until then the server refuses with HTTP 409, one
// plain sentence in "error" and the field "waits_for". The same call as api.js makes, but a refusal keeps its HTTP status and that mark, so the
// sentence can be shown where the result would have appeared (refusedHere) and the first request can stop the page (showWaits).
async function api(method, url, body) {
  const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error || (j.result && j.result.error) || r.statusText); e.status = r.status; e.waits = isWait(r.status, j); e.answer = j; throw e; }
  return j;
}
function isWait(code, answer) { return code === 409 && !!answer && typeof answer.error === "string" && !!answer.waits_for; }
// The address of page 3 of the analysis. The refusal's "waits_for" is a sentence, not an address, so it cannot give one; the page is built
// from the analysis's number when the answer carries it ("project"), else from the address this page was opened with by the analysis's errors
// page (back=/#/p/<number>/errors). Nothing else is guessed: without either, the message points to the list of analyses.
function page3Href(back, answer) {
  const n = answer && Number.isInteger(answer.project) && answer.project > 0 ? answer.project : (/^\/#\/p\/(\d{1,12})(\/|$)/.exec(String(back || "")) || [])[1];
  return n ? `/#/p/${n}/rules` : null;
}
function waitsHtml(sentence, href, more) {
  return `<h2>This error cannot be opened yet</h2>
    <p class="waits-why" style="font-size:15px;max-width:95ch"><b>${esc(sentence)}</b></p>${more ? `
    <p class="waits-more" style="max-width:95ch">${esc(more)}</p>` : ""}
    <p>${href ? `<a class="waits-link" href="${esc(href)}"><b>Go to page 3 of the analysis</b></a> (the rules and their results), and approve the result there.` : `Open the analysis from <a href="/">the list of your analyses</a> and go to its page 3 (the rules and their results).`}</p>
    <p class="hint">Nothing of this error was read or changed. After you approve the result there, open this page again from the errors page of the analysis.</p>`;
}
const waitLine = sentence => `<p class="status bad waits" style="margin:8px 0;font-size:14px"><b>Not yet.</b> ${esc(sentence)}</p>`;
// a refused request: its sentence goes into the status line beside the button and, when it is the flow's refusal, also where the result would have appeared
function refusedHere(e, statusId, boxId) {
  if (statusId) status(statusId, e.message, "bad");
  const box = e && e.waits && boxId ? $(boxId) : null;
  if (box) box.innerHTML = waitLine(e.message);
}
// the first request was refused: the sentence becomes the page's message, the parts of the page are put away, and nothing else is loaded
function showWaits(answer) {
  const box = $("s-waits") || $("load-error");
  document.querySelectorAll("main > section.card").forEach(s => { if (s !== box) s.hidden = true; });
  document.querySelectorAll("aside button.nav").forEach(b => { b.disabled = true; });
  box.hidden = false; box.className = "card waits";
  // "project" (the number of the one analysis that waits) gives the link to its page 3 without "back="; with two or more waiting analyses the
  // server sends no number but a sentence ("analyses_words"), shown under the refusal, and the link goes to the list of analyses
  box.innerHTML = waitsHtml(answer.error, page3Href(Q.get("back"), answer), typeof answer.analyses_words === "string" ? answer.analyses_words : "");
  ["foot-upload", "foot-model", "name-box"].forEach(id => { const e = $(id); if (e) e.hidden = true; });      // nothing of the error was read: these parts of the header have nothing to show
  $("page-title").textContent = "This error waits for the approval of its pattern's result";
  document.title = "This error cannot be opened yet";
}
// a finding filed by a rule of the admin's own (2026-11-15): the rule is shown in the words kept with the finding, never as its key
function ruleWords(f) { const a = ((f || {}).detail || {}).admin_rule || (f || {}).admin_rule || {}; return a.words || (f || {}).rule_words || ""; }
function ruleShort(f, slotRule) { const a = (f || {}).admin_rule || ((f || {}).detail || {}).admin_rule; return a && a.short ? a.short : a && a.name ? `your own rule “${a.name}”` : (f || {}).rule_short || ruleNamed(slotRule || (f || {}).rule); }
function nameFrom(f) { const a = (f || {}).admin_rule; return a && a.kind_from ? a.kind_from : ""; }
// ---- no internal key on the screen (2026-11-15: a tester saw a rule key in the test table and "(unknown_cause)" in parts 3 and 4). A rule is
// named in words: the server's short words for this error's rule (finding.rule_short) and for the detector's rules (rule_names of the first
// answer), else the words of the key's own parts. A cause is named by the dictionary's plain name. plain() is the last guard for a sentence
// that was stored or written before this (a kept isolation, a progress line, a model's own words): a key inside it becomes the same words.
const KEY_LEVEL = { cmd: "NVMe command", ntx: "NVMe transaction", spl: "split transaction", lnk: "link transaction", pkt: "packet" };
const RULE_KEY = /\b(?:admin\.[a-z0-9_]+\.[a-z0-9_]+\.[a-z0-9_.]+?\.v\d+|(?:cmd|ntx|spl|lnk|pkt)\.[a-z][a-z0-9_]*)\b/gi;
const NO_CAUSE = "no cause could be named from the evidence";
function ruleKeyWords(key) {
  const k = String(key || ""), known = ((S.H || {}).rule_names || {})[k];
  if (typeof known === "string" && known) return known;
  const own = /^admin\.[^.]+\.[^.]+\.(.+)\.v\d+$/i.exec(k), det = /^(?:cmd|ntx|spl|lnk|pkt)\.(.+)$/i.exec(k);
  return (own ? own[1] : det ? det[1] : "").replace(/[._]+/g, " ").trim();
}
function ruleNamed(key) {
  const k = String(key || ""), w = ruleKeyWords(k);
  if (/^admin\./i.test(k)) return w ? `the rule “${w}” of the rules library` : "a rule of the rules library";
  return w ? `the detector's rule “${w}”` : "the detector's rule for this row";
}
// the plain name of a cause: the dictionary's own words, sent with the isolation (cause.name) and with the list of causes; never its keyword
function causeName(c, key) {
  const k = (c || {}).key || key || "";
  if (!k || k === "unknown_cause") return NO_CAUSE;
  return (c || {}).name || ((S.causes || []).find(x => x.key === k) || {}).name || "a cause that is not in the dictionary any more";
}
function plain(t) {
  const f = (S.H || {}).finding || {};
  let s = String(t ?? "").replace(RULE_KEY, k => (k === f.rule ? ruleShort(f, k) : ruleNamed(k))).replace(/\bunknown_cause\b/g, NO_CAUSE);
  (S.causes || []).forEach(c => { if (c && c.key && c.name && s.includes(c.key)) s = s.split(c.key).join(`“${c.name}”`); });
  return s;
}
// a command's recorded parameters in words, as the tree page says them (the number of blocks is stored as one less than it is); a parameter
// without words here is shown by its name with spaces
function paramWords(p) {
  const o = p || {}, has = k => o[k] !== null && o[k] !== undefined && o[k] !== "", out = [];
  if (has("nsid")) out.push(`namespace ${o.nsid}`);
  if (has("slba")) out.push(`first block ${o.slba}`);
  if (has("nlb") && !isNaN(Number(o.nlb))) out.push(`${nf(Number(o.nlb) + 1)} block${Number(o.nlb) === 0 ? "" : "s"}`);
  if (has("nbytes")) out.push(`${nf(o.nbytes)} bytes`);
  if (has("fua") && Number(o.fua)) out.push("written to the drive's storage before it is answered (Force Unit Access)");
  Object.keys(o).filter(k => !["nsid", "slba", "nlb", "nbytes", "fua"].includes(k) && has(k)).forEach(k => out.push(`${k.replace(/_/g, " ")} ${typeof o[k] === "object" ? JSON.stringify(o[k]) : o[k]}`));
  return out.join(", ");
}
// how errors of the same kind are recognised, in words: the stored key itself ("v1|dev:…|err:<rule key>|…") is not for the screen
const KIND_PART = { entry: "the submission queue entry", prp: "the list of data pages", data: "the data", cqe: "the completion entry", irq: "the interrupt", dbl: "the doorbell", reg: "a register access" };
function kindWords(f, device) {
  const x = ((f || {}).signature || {}).fields; if (!x) return "";
  const cmd = /^(io|admin)\.(.+)$/.exec(x.cmd || ""), st = /^sct(\d+)\.sc([0-9a-f]+)$/i.exec(x.st || ""), known = v => v && v !== "UNKNOWN";
  const parts = [`found by ${ruleShort(f, x.err)}`, `at the ${KEY_LEVEL[x.lvl] || "same"} level`,
    cmd ? `on the command ${cmd[2]}${cmd[1] === "admin" ? " (an admin command)" : ""}` : "outside any command",
    KIND_PART[x.part] ? `at ${KIND_PART[x.part]} of the command` : "",
    x.cause && x.cause !== "self" ? `with an error of a lower level under it (${ruleKeyWords(x.cause) || "not named"})` : "",
    st ? `with status code type ${Number(st[1])}, status code ${st[2].toUpperCase()}h` : "",
    x.dnr === "1" ? "marked “do not retry” by the drive" : "",
    known(x.dev) ? `on the drive ${device || x.dev}${known(x.fw) ? `, firmware ${x.fw}` : ""}` : ""].filter(Boolean);
  return `Errors of the same kind are recognised by: ${parts.join("; ")}. Times, measured values and row numbers are not part of it.`;
}
// a part of the header is shown only when it has something to show
function badge(boxId, id, text) { const e = $(id), box = $(boxId); if (e) e.textContent = text || ""; if (box) box.hidden = !text; }
// a sentence of the server may still name a test file as the place of a measurement; a test file is not for the screen: the page names the
// document a reader can open instead
const SEARCH_RECORD = "(how often the search found a hidden trigger with this many runs; the measurement is recorded in the change record docs/CHANGES_2026-11-15.md, section 5)";
const noTestFile = (t, instead) => String(t ?? "").replace(/\s*\(?(?:[\w.-]+\/)*test_\w+\.py\)?/g, instead ? " " + instead : "");
// who wrote what is in the box of the optimized sequence (2026-11-15: the form said "the model proposed it" over an empty box when no model had
// answered). -> { byModel: a model's lines are in the box, words: the sentence beside the heading }
function proposalWords(prop, failed) {
  const lines = ((prop || {}).lines || []).filter(l => String(l || "").trim());
  if (failed) return { byModel: false, words: `no proposal could be made (${failed}): write it yourself` };
  if (!prop || prop.standin) return { byModel: false, words: "no model answered, so no proposal was made: write it yourself" };
  if (!lines.length) return { byModel: false, words: "the model answered without a proposal: write it yourself" };
  return { byModel: true, words: "the model proposed the lines in the box: edit them before you store them" };
}

const Q = new URLSearchParams(location.search);
const UID = Q.get("upload"), FID = Number(Q.get("finding"));
const BASE = `/api/isolate/${encodeURIComponent(UID)}/${encodeURIComponent(FID)}`;
const STANDIN = Q.get("standin") === "1";
const LABEL = { nvme_command: "NVMe command", nvme_transaction: "NVMe transaction", split: "split transaction", link: "link transaction", packets: "packet" };
const FILE = { nvme_command: "nvme_command.csv", nvme_transaction: "NVME_Transactions.csv", split: "split.csv", link: "link.csv", packets: "packets.csv" };
const POS = { above: "before the error", fault: "THE ERROR", below: "after the error" };
const S = { H: null, W: null, iso: null, defect: null, occ: null, cause: null, sol: null, testSeq: null, expect: null, file: null };

const name = () => ($("name").value || "").trim();
const status = (id, text, cls = "") => { const e = $(id); if (e) { e.textContent = text; e.className = "status " + cls; } };
const who = p => !p ? "" : /^stand-in/.test(p) ? "no model answered: built by the code from the rule's own facts" : "answered by the model";
const UNITS = [[1e12, "s"], [1e9, "ms"], [1e6, "µs"]];
const fmtT = ps => { if (ps == null || isNaN(ps)) return ""; const [div, u] = S.tunit || [1e6, "µs"], sg = ps < 0 ? "−" : ps > 0 ? "+" : "";
  return `${sg}${(Math.abs(ps) / div).toLocaleString("en-US", { maximumFractionDigits: 3 })} ${u}`; };
const nf = x => Number(x).toLocaleString("en-US");
// ---- the rows around this error kept in the knowledge base (2026-11-14): the server answers in words whether they were kept (trace.words); the
// page shows that sentence where it shows the result of the action, and sends the window on the screen (commands above, below, all queues) with
// every such action, so the kept rows are the ones the admin looked at
const windowSent = () => { const w = S.shownWindow || {}; return Number.isInteger(w.n) && Number.isInteger(w.m) ? { n: w.n, m: w.m, queue: "all" } : {}; };
const traceLine = t => t && t.words ? `<p class="status ${t.archived ? "ok" : "warn"} kept-rows" style="margin:8px 0 0">${esc(t.words)}</p>` : "";
// ---- long steps: progress while the server works, and a sound when it is done (owner, 2026-11-11)
function unlockAudio() { try { S.audio = S.audio || new (window.AudioContext || window.webkitAudioContext)(); if (S.audio.state === "suspended") S.audio.resume(); } catch (e) { /* no sound */ } }
function ding(ok) {
  const a = S.audio; if (!a) return;
  try { (ok ? [660, 880] : [440, 330]).forEach((f, i) => { const o = a.createOscillator(), g = a.createGain(), t = a.currentTime + i * 0.2;
    o.frequency.value = f; o.connect(g); g.connect(a.destination); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.2, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18); o.start(t); o.stop(t + 0.2); }); } catch (e) { /* no sound */ }
}
async function runJob(url, body, statusId) {
  unlockAudio();
  const box = $(statusId), base = document.title;
  box.className = "status"; box.innerHTML = `<div class="prog"><div class="bar"><span style="width:1%"></span></div><div class="ptext">starting…</div><details class="plog"><summary>what happened so far</summary><ol></ol></details></div>`;
  let job;
  try { ({ job } = await api("POST", url + (url.includes("?") ? "&" : "?") + "job=1", body)); }
  catch (e) { box.innerHTML = ""; throw e; }                      // refused before it started: no progress bar is left behind
  let shown = 0;
  try {
    for (;;) {
      await new Promise(r => setTimeout(r, 700));
      const j = await api("GET", `/api/isolate/jobs/${job}`);
      box.querySelector(".bar span").style.width = `${Math.max(1, j.pct)}%`;
      box.querySelector(".ptext").innerHTML = `<b>${j.pct}%</b> · ${esc(plain(j.text || ""))} · ${j.seconds} s`;
      const ol = box.querySelector("ol");
      while (shown < (j.log || []).length) { const l = j.log[shown++]; ol.insertAdjacentHTML("beforeend", `<li>${l.s} s · ${l.pct}% · ${esc(plain(l.text))}</li>`); }
      document.title = `${j.pct}% · ${base}`;
      if (j.state === "done") { document.title = base; ding(true); box.querySelector(".ptext").innerHTML = `<b>done</b> in ${j.seconds} s`; return j.result; }
      if (j.state === "error") { document.title = base; ding(false); throw new Error(j.error || "it failed"); }
    }
  } catch (e) { document.title = base; throw e; }
}

function needName() { if (name()) return true; $("name").focus(); alertBox("Write your name at the top first: every decision here is kept with it."); return false; }
function alertBox(text) { const e = $("load-error"); e.hidden = false; e.textContent = text; setTimeout(() => { e.hidden = true; }, 6000); }

// ------------------------------------------------------------------ 1 the error
async function loadError() {
  const H = S.H = await api("GET", BASE);
  const f = H.finding, cmd = f.command || {};
  const where = `row ${nf(f.rowid)} of ${FILE[f.level] || f.level}`;
  S.where = where;
  badge("foot-upload", "upload-badge", H.trace_name || "");      // the recording by the name it was given; its internal number is not for the screen
  badge("foot-model", "model-badge", H.model.available && !STANDIN ? H.model.name : "no model (the code's own answers)");
  $("page-title").textContent = `Error at ${where}`;
  document.title = `Error at ${where}`;
  $("error-kv").innerHTML = [
    ["What the pattern found", esc(f.name || ruleWords(f))],
    ["The pattern (rule)", esc(ruleWords(f))],
    ...(nameFrom(f) ? [["Where the defect's name comes from", esc(nameFrom(f))]] : []),
    ["Where in the files", `${esc(where)} <a href="/hier?upload=${encodeURIComponent(UID)}" target="_blank">open the tree ↗</a>`],
    ["Its NVMe command", cmd.summary ? `${esc(cmd.summary)}${cmd.duration ? `, took ${esc(cmd.duration)}` : ""}${cmd.status ? `, status ${esc(cmd.status)}` : ""}` : "outside any command"],
    ["Measured against the limit", f.value_ps_text ? `${esc(f.value_ps_text)} measured; the limit is ${esc(f.limit_ps_text || "-")} (${esc(f.limit_source || "no source recorded")})` : "this rule fires on a status or an event, not on a time"],
    ["The drive", esc(H.device || "not named")],
  ].map(([k, v]) => `<b>${esc(k)}</b><span>${v}</span>`).join("");
  const chain = (f.chain || []).map(c => `${esc(c.label)} ${esc(c.n)}: ${esc(c.summary)}`).join(" → ");
  const c = f.catalogue;
  $("error-more").innerHTML = `<p><b>From the row up to its command:</b> ${chain || "-"}</p>
    <p><b>Catalogue text:</b> ${c ? `${esc(c.error || "")} ${esc(c.meaning || "")}${c.spec ? ` (specification ${esc(c.spec)})` : ""}` : "none for this rule"}</p>
    <p class="hint">${esc(kindWords(f, H.device))}</p>`;
}

// ------------------------------------------------------------------ 2 the commands around it: a tree, opened level by level
function rowCells(r, d, errT) {
  const f = (r.findings || []).map(x => x.name).join("; ");
  const exp = r.level !== "packets" && (r.level === "nvme_command" || r.has_children) ? `<button class="exp" data-lvl="${r.level}" data-rid="${r.rowid}" data-d="${d}">expand</button>` : "";
  return `<td>${exp}</td><td class="num">${esc(r.rowid)}</td><td class="what">${d ? `<span class="hint">${esc(LABEL[r.level])}</span> ` : ""}${esc(r.summary || "")}</td>
    <td>${r.status ? esc(r.status) : ""}${r.status && f ? "; " : ""}${f ? `<span class="fnd">${esc(f)}</span>` : ""}</td>
    <td class="num">${esc(r.gap || "")}</td><td class="num">${esc(r.dur || "")}</td><td class="t">${r.t_ps != null && errT != null ? esc(fmtT(r.t_ps - errT)) : ""}</td>`;
}
async function showWindow() {
  const n = Number($("n-above").value), m = Number($("m-below").value);
  if (!Number.isInteger(n) || !Number.isInteger(m) || n < 0 || m < 0 || n > 100 || m > 100) { status("win-status", "above and below: whole numbers from 0 to 100", "bad"); return; }
  status("win-status", "reading the commands…");
  try { S.W = await api("GET", `${BASE}/window?n=${n}&m=${m}&levels=`); }
  catch (e) { status("win-status", e.message, "bad"); if (e.waits) $("win").querySelector("tbody").innerHTML = `<tr class="note"><td colspan="7">${waitLine(e.message)}</td></tr>`; return; }
  const cmds = S.W.commands || [], fault = cmds.find(c => c.position === "fault") || {}, errT = fault.t_ps;
  S.errT = errT;
  const widest = Math.max(0, ...cmds.map(c => Math.abs((c.t_ps ?? errT) - errT)));
  S.tunit = UNITS.find(([d]) => widest >= d) || [1e6, "µs"];          // one unit for the whole column (research: trace viewers keep one time base)
  $("win").querySelector("thead th:last-child").textContent = `time from the error (${S.tunit[1]})`;
  S.shownWindow = { n, m };
  const above = cmds.filter(c => c.position === "above"), below = cmds.filter(c => c.position === "below");
  const tr = c => `<tr class="${c.position === "fault" ? "err" : ""}${(c.findings || []).length ? " has-f" : ""}" data-key="nvme_command:${c.rowid}">${rowCells(c, 0, errT)}</tr>`;
  $("win").querySelector("tbody").innerHTML =
    `<tr class="sep"><td colspan="7">${above.length} command${above.length === 1 ? "" : "s"} before the error</td></tr>${above.map(tr).join("")}` +
    `<tr class="sep"><td colspan="7">the error's command</td></tr>${tr(fault)}` +
    `<tr class="sep"><td colspan="7">${below.length} command${below.length === 1 ? "" : "s"} after the error</td></tr>${below.map(tr).join("")}`;
  status("win-status", `${above.length} above, the error's command, ${below.length} below. The isolation in part 3 reads these, with everything under them.`, "ok");
  const wrap = $("win").closest(".treewrap"), er = $("win").querySelector("tr.err");
  if (wrap && er) wrap.scrollTop = Math.max(0, er.offsetTop - wrap.clientHeight / 2);
}
async function expand(b) {
  const lvl = b.dataset.lvl, rid = Number(b.dataset.rid), d = Number(b.dataset.d), key = `${lvl}:${rid}`, row = b.closest("tr");
  const tbody = row.parentElement;
  if (b.textContent === "collapse") { tbody.querySelectorAll("tr").forEach(x => { if ((x.dataset.anc || "").split(" ").includes(key)) x.remove(); }); b.textContent = "expand"; return; }
  b.textContent = "…";
  let r;
  try { r = await api("GET", `${BASE}/children?level=${lvl}&rowid=${rid}&limit=200`); } catch (e) { b.textContent = "expand"; status("win-status", e.message, "bad"); return; }
  const anc = ((row.dataset.anc || "") + " " + key).trim();
  const html = [];
  for (const p of r.parts) {
    for (const x of p.rows) html.push(`<tr class="kid l-${x.level}${(x.findings || []).length ? " has-f" : ""}" style="--d:${d + 1}" data-key="${x.level}:${x.rowid}" data-anc="${anc}">${rowCells(x, d + 1, S.errT)}</tr>`);
    if (p.count > p.rows.length) html.push(`<tr class="kid note" style="--d:${d + 1}" data-anc="${anc}"><td></td><td></td><td class="what" colspan="5">and ${nf(p.count - p.rows.length)} more ${esc(p.label)}s under this ${esc(LABEL[lvl])} (the first ${p.rows.length} are shown; the tree page shows them all)</td></tr>`);
  }
  if (!html.length) html.push(`<tr class="kid note" style="--d:${d + 1}" data-anc="${anc}"><td></td><td></td><td class="what" colspan="5">nothing under this ${esc(LABEL[lvl])}</td></tr>`);
  row.insertAdjacentHTML("afterend", html.join(""));
  b.textContent = "collapse";
}

// ------------------------------------------------------------------ 3 the isolation of the defect
async function isolate(rewrite) {
  if (!needName()) return;
  const { n, m } = S.shownWindow || { n: Number($("n-above").value), m: Number($("m-below").value) };      // the window on the screen
  $("btn-isolate").disabled = true;
  // the names of the causes, before the first progress line: a line of the server may still hold a cause's keyword, and plain() says it in words
  if (!S.causes) { try { S.causes = (await api("GET", "/api/dg/terms")).causes || []; } catch (e) { /* not read now: part 4 reads the list again */ } }
  try {
    S.iso = await runJob(`${BASE}/isolate${STANDIN ? "?standin=1" : ""}`, { n, m, levels: ["nvme_transaction", "split", "link", "packets"], history: true, anyway: true,
                                                                         isolation: true, rewrite: rewrite === true, name: name(), standin: STANDIN }, "iso-prog");
  } catch (e) { refusedHere(e, "iso-status", "iso-out"); $("btn-isolate").disabled = false; return; }
  $("btn-isolate").disabled = false; $("btn-isolate").textContent = "Isolate again";
  const i = S.iso.isolation || {}, L = i.labels || {};
  status("iso-status", i.kept_at ? `the same isolation as before (kept ${new Date(i.kept_at * 1000).toLocaleString()}): this error's evidence has not changed, so its isolation does not change, whatever the window`
    : `${who(i.producer)}; ${(i.problems || []).length ? "the code's checks found: " + plain(i.problems.join("; ")) : "the code checked every row it cites"}`, (i.problems || []).length && !i.kept_at ? "warn" : "ok");
  const t = i.term || {}, st = i.stored, sl = t.slots || {};
  $("iso-out").innerHTML = `<div class="answer"><div class="q">${["what", "why", "when", "where", "who", "which", "how"].map(k => `<b>${esc(L[k] || k)}</b><span>${esc(plain(i[k] || ""))}</span>`).join("")}</div>
      ${(i.cited_rows || []).length ? `<p class="hint" style="margin:8px 0 0">The rows it rests on: ${i.cited_rows.map(c => `${esc(LABEL[c.level] || c.level)} row ${esc(c.rowid)}`).join(", ")}.</p>` : ""}
      <p style="margin:10px 0 0"><b>How the cause was decided:</b> ${esc(causeName(i.cause, i.cause_key))}${i.cause_header ? `, because ${esc(plain(i.cause_header))}` : ""}.
        <span class="hint">Decided by ${esc(i.decided_by || "the fixed rules")}, from this error's own command, not by the model and not by the window: the same error always gets the same cause.
        What, when, where, which row and who are stated by the code too; the model writes only why and how.</span></p>
      ${cardHtml(i.card)}
      <div class="row" style="margin-top:8px"><button class="small" id="btn-rewrite">Write the words again</button><span class="hint">the facts and the cause stay; only why and how are written again</span></div>${traceLine(S.iso.trace)}</div>
    <div class="choice"><h3>The defect, as the dictionary names it</h3>
      <p style="font-size:16px;margin:4px 0"><b>${esc(t.name || "")}</b></p>
      <p class="hint">Named by the code from what the recording shows, never typed: ${esc(ruleShort((S.H || {}).finding, sl.rule))}, the command ${esc(sl.command || "")}, what happened (${esc(sl.what || "")})${sl.qualifier ? `, ${esc(sl.qualifier)}` : ""}. The same kind of error always gets this name, whoever looks at it and whenever. (Dictionary version ${esc(t.version)}.)${nameFrom((S.H || {}).finding) ? ` ${esc(nameFrom((S.H || {}).finding))}` : ""}</p>
      <p>${st ? `<b>Already in the procedural graph:</b> seen ${st.seen} time${st.seen === 1 ? "" : "s"}${(st.devices || []).length ? ` on ${esc(st.devices.join(", "))}` : ""}; ${(st.causes || []).length} cause${(st.causes || []).length === 1 ? "" : "s"} stored.`
        : `<b>Not in the procedural graph yet:</b> this is its first finding; it is stored under this name.`}</p>
      <div class="row" style="margin-top:8px"><button class="primary" id="btn-name">Continue with this defect</button><span id="name-status" class="status"></span></div><div id="name-trace"></div>
      <details class="node" style="margin-top:10px"><summary>Not the same kind of defect?</summary><div class="in">
        <p class="hint">Say why. The note goes to the dictionary's keeper; the name stays as the code made it until the dictionary changes, so it stays the same for everyone.</p>
        <textarea id="term-note" style="width:100%;min-height:60px"></textarea><div class="row" style="margin-top:6px"><button id="btn-term-note">Send the note</button><span id="term-status" class="status"></span></div></div></details></div>`;
  $("btn-name").onclick = nameDefect;
  $("btn-rewrite").onclick = () => isolate(true);
  $("btn-term-note").onclick = async () => {
    const note = ($("term-note").value || "").trim(); if (!note || !needName()) return;
    try { await api("POST", "/api/dg/term_requests", { term_key: t.key, term_name: t.name, note, upload_id: UID, finding_id: FID, admin: name() }); status("term-status", "sent", "ok"); }
    catch (e) { status("term-status", e.message, "bad"); }
  };
}
const fmtAny = ps => { if (ps == null || isNaN(ps)) return "-"; const a = Math.abs(ps); return a >= 1e12 ? `${(ps / 1e12).toFixed(3)} s` : a >= 1e9 ? `${(ps / 1e9).toFixed(3)} ms` : a >= 1e6 ? `${(ps / 1e6).toFixed(3)} µs` : `${Math.round(ps / 1e3)} ns`; };
function cardHtml(c) {
  if (!c || !c.command) return "";
  const fmtT = fmtAny;            // each card value in its own unit
  const st = (c.stages || []).map(s => `<tr><td>${esc(s.row)}</td><td>${esc(s.what)}</td><td class="num">${s.after_doorbell_ps != null ? esc(fmtT(s.after_doorbell_ps)) : ""}</td><td class="num">${s.gap_ps != null ? esc(fmtT(s.gap_ps)) : ""}</td></tr>`).join("");
  const lw = c.longest_wait, ab = c.abort, du = c.during || {};
  // (card version 3) abort_unreadable: an Abort sent while the command was outstanding whose own parameters cannot be read, so the code cannot
  // tell which command it names; names: when this command is itself an Abort, the command its parameters name; read_from_tree: what the card
  // read from the tree because the error's own record did not hold it
  const au = c.abort_unreadable ? (typeof c.abort_unreadable === "object" ? c.abort_unreadable : {}) : null, nm = c.names && typeof c.names === "object" ? c.names : null;
  const read = Array.isArray(c.read_from_tree) ? c.read_from_tree.filter(x => typeof x === "string" && x.trim()) : [];
  return `<details class="node" style="margin-top:8px"><summary>The evidence card <span class="hint">· computed by the code from this error's own command; the same for every window</span></summary><div class="in">
    <div class="xscroll"><table class="steps"><tr><th>row</th><th>step of the command</th><th>after the doorbell</th><th>wait before it</th></tr>${st}</table></div>
    <p class="hint">${lw ? `The longest wait: ${esc(fmtT(lw.ps))}, from row ${esc(lw.from_row)} (${esc(lw.from_what)}) to row ${esc(lw.to_row)} (${esc(lw.to_what)}). ` : ""}
      ${ab ? `The host's Abort: row ${esc(ab.row)}, ${esc(fmtT(ab.after_doorbell_ps))} after the doorbell. ` : au ? `An Abort was sent while it was outstanding${au.row != null ? ` (NVMe command row ${esc(au.row)})` : ""}, but what it names cannot be read. ` : "No Abort that names it while it was outstanding. "}
      Its own packets: ${esc(c.packets ?? "-")}, refused (Nak) ${esc(c.nak)}, unacknowledged ${esc(c.unacked)}.
      During its time: ${esc(du.commands ?? 0)} other commands (${esc(du.completed ?? 0)} completed, ${esc(du.same_queue ?? 0)} on the same queue)${(c.link_events || []).length ? `; link events: ${esc([...new Set(c.link_events.map(e => ruleKeyWords(e.rule) || "an event without a name"))].join(", "))}` : "; no link event"}.
      ${c.median_ps ? `This command type usually takes ${esc(fmtT(c.median_ps))} here${c.host_limit_ps != null ? `; the host's driver limit is ${esc(fmtT(c.host_limit_ps))}` : ""}.` : ""}
      ${nm ? `This command is itself an Abort. The command it names: ${nm.unreadable ? `cannot be read (${esc(nm.unreadable)})` : `queue ${esc(nm.queue)}, command identifier ${esc(nm.id)}: ${nm.row == null ? "no command with that queue and identifier was sent before it" : `NVMe command row ${esc(nm.row)}, sent ${esc(fmtT(nm.sent_before_ps))} before this Abort; the drive ${nm.completed ? "completed it" : "never completed it"}`}`}.` : ""}</p>
    ${read.length ? `<p class="hint">Read from the tree for this card, because the error's own record did not hold it: ${esc(read.join("; "))}.</p>` : ""}${afterHtml(c.after)}</div></details>`;
}
// what followed a command that never completed (card.after, computed in nvme_hier/evidence.py): every value with its meaning and its unit
function afterHtml(a) {
  if (!a) return "";
  const head = `<h4 style="margin:12px 0 4px">What followed this command, which the drive never completed</h4>`;
  if (a.unreadable) return `${head}<p class="hint">This could not be worked out: ${esc(a.unreadable)}.</p>`;
  const t = fmtAny, ab = a.abort, rs = a.reset, fs = a.first_stopped, o = a.others || {}, ep = a.episode_from, nm = a.names, many = (n, w) => `${nf(n || 0)} ${w}${n === 1 ? "" : "s"}`;
  const since = ep ? `the previous controller reset (NVMe transaction row ${nf(ep.row)}${ep.unreadable ? ", a register write whose value cannot be read and is therefore taken as a possible reset" : ""})` : "the start of the recording";
  const end = a.wait_end === "controller reset" ? "the controller reset" : "the end of the recording";
  const rows = [
    ["How long this command was left without an answer", esc(t(a.outstanding_ps)), `From the moment the host sent it (its doorbell) until ${end}. The drive never completed it.`],
    ["The wait after its last step", esc(t(a.wait_ps)), `From the last row the recording shows for this command until ${end}: the time in which nothing more happened for it.`],
    ["The host's Abort for this command", ab ? `NVMe command row ${nf(ab.row)}, sent ${esc(t(ab.after_doorbell_ps))} after this command was sent` : "none was sent during the wait",
      `An Abort is the admin command with which the host asks the drive to give one command up. It is matched by identity, never by time: its own parameters name this command's queue${ab && ab.names ? ` (queue ${esc(ab.names[0])})` : ""} and command identifier${ab && ab.names ? ` (${esc(ab.names[1])})` : ""}.${a.aborts_for_others ? ` ${many(a.aborts_for_others, "other Abort")} sent during the wait named other commands.` : ""}`]];
  if (ab) rows.push(["Did the drive answer that Abort", ab.answered ? `yes, ${esc(t(ab.answer_after_ps))} after the Abort was sent${ab.status ? `; the drive's status for it: status code type ${esc(ab.status[0])}, status code ${esc(ab.status[1])}${Number(ab.status[0]) === 0 && Number(ab.status[1]) === 0 ? " (the Abort command itself completed without an error)" : ""}` : ""}` : "no: the drive never answered it",
    "Whether the drive completed the Abort command itself before the wait ended, and how long that took."]);
  rows.push(["The controller reset", rs ? `NVMe transaction row ${nf(rs.row)}${rs.packet_row != null ? ` (packet row ${nf(rs.packet_row)})` : ""}, ${esc(t(rs.after_doorbell_ps))} after this command was sent${rs.after_abort_ps != null ? ` and ${esc(t(rs.after_abort_ps))} after the Abort` : ""}` : "none after this command's last step",
    `The host switched the controller off by writing 0 to the enable bit of its controller configuration register. Every command still without an answer is lost at that moment.${rs ? "" : " With no reset, the wait is counted to the end of the recording."}`]);
  rows.push(["First to stop, or only outstanding", fs ? `only outstanding: the command at NVMe command row ${nf(fs.row)} (queue ${esc(fs.queue)}, command identifier ${esc(fs.id)}) was sent ${esc(t(fs.before_this_ps))} before this one and also never completed` : `the first to stop since ${since}`,
    `Whether an earlier command, sent since ${since}, was also left without an answer. If one was, this command may only have been waiting when the host recovered from that earlier one.`]);
  rows.push(["Other commands also left without an answer", many(a.outstanding_others, "command"), `Commands other than this one, sent between ${since} and the end of this wait (${end}), that the drive never completed.`]);
  rows.push(["Other commands the drive answered during the wait", `${nf(o.answered || 0)} of the ${many(o.sent, "command")} sent in that time; ${nf(o.answered_same_queue || 0)} of them on this command's own queue and ${nf(o.answered_admin || 0)} on the admin queue; answers came on ${many(o.queues_answered, "queue")}${(o.rows || []).length ? `; the first of them: NVMe command row${o.rows.length === 1 ? "" : "s"} ${o.rows.map(nf).join(", ")}` : ""}`,
    "Commands sent after this command's last step and completed before the wait ended. Above 0, the drive was still answering other commands while this one waited; 0 means it answered nothing at all in that time."]);
  const bad = [...(a.aborts_unreadable || []).map(x => `the Abort at NVMe command row ${nf(x.row)}, sent ${esc(t(x.after_doorbell_ps))} after this command: ${esc(x.why || "its parameters cannot be read")}`),
    ...(a.register_writes_unreadable || []).map(x => `the access to the controller configuration register at NVMe transaction row ${nf(x.row)}: ${x.capped ? "more accesses followed than the code examines, so a later reset cannot be ruled out" : "the value written cannot be read"}`)];
  rows.push(["Rows that could not be read", bad.length ? bad.join("; ") : "none", "An Abort whose parameters cannot be read may name this command, and a register write whose value cannot be read may be a reset. With such a row the cause is given as unknown, never guessed."]);
  if (nm) rows.push(["The command this Abort itself names", nm.unreadable ? `cannot be read: ${esc(nm.unreadable)}` : `queue ${esc(nm.queue)}, command identifier ${esc(nm.id)}: ${nm.row == null ? "no command with that queue and identifier was sent before it" : `NVMe command row ${nf(nm.row)}, sent ${esc(t(nm.sent_before_ps))} before this Abort; the drive ${nm.completed ? "completed it" : "never completed it"}`}`,
    "This error's command is itself an Abort. Its own parameters name the command the host wanted given up: the latest command with that queue and command identifier sent before it."]);
  return `${head}<div class="xscroll"><table class="steps after-table"><tr><th>what the code looked for</th><th>what the recording shows</th><th>what it means</th></tr>${rows.map(([k, v, w]) => `<tr><td><b>${esc(k)}</b></td><td>${v}</td><td class="hint">${w}</td></tr>`).join("")}</table></div>
    <p class="hint">Each time is written in the unit that fits it: seconds (s), milliseconds (ms), microseconds (µs) or nanoseconds (ns). Row numbers are rows of nvme_command.csv (NVMe command), NVME_Transactions.csv (NVMe transaction) and packets.csv (packet).</p>`;
}
async function nameDefect() {
  if (!needName()) return;
  const i = S.iso.isolation || {}, t = i.term || {};
  try {
    const did = (await api("POST", "/api/dg/defects", { name: t.name, term_key: t.key, rule: i.rule, level: i.level, what: i.what, admin: name() })).id;
    const o = await api("POST", "/api/dg/occurrences", { defect_id: did, cause_id: null, upload_id: UID, finding_id: FID, device: i.device, firmware: i.firmware,
                                                         isolation: isolationRecord(), admin: name(), ...windowSent() });
    S.occ = o.id;
    S.defect = did;
    status("name-status", "kept under this defect; part 4 shows what the procedural graph holds for it", "ok");
    if ($("name-trace")) $("name-trace").innerHTML = traceLine(o.trace);
    await showGraph();
    $("s-graph").scrollIntoView({ behavior: "smooth" });
  } catch (e) { refusedHere(e, "name-status", "name-trace"); }
}
const isolationRecord = () => { const i = S.iso.isolation || {}; const o = {}; ["what", "why", "when", "where", "who", "which", "how", "cause_key", "cause_header", "cited_rows"].forEach(k => o[k] = i[k]); o.term = (i.term || {}).key; return o; };

// ------------------------------------------------------------------ 4 the procedural graph: the defect, its causes, their solutions
function seqTable(seq, tick) {
  return `<div class="xscroll"><table class="steps"><tr><th>step</th><th>command</th><th>where</th><th>wait before it</th>${tick ? "<th></th>" : ""}</tr>${(seq || []).map(x =>
    `<tr class="${x.position === "fault" ? "err" : ""}" ${tick ? `data-tick="${tick}" data-step="${x.step}"` : ""}>
     <td>${esc(x.step)}</td><td><b>${esc(x.command || "")}</b>${x.parameters && Object.keys(x.parameters).length ? ` <span class="hint">${esc(paramWords(x.parameters))}</span>` : ""}</td>
     <td>${esc(POS[x.position] || x.position || "")}</td><td>${x.gap_us != null ? nf(Math.round(x.gap_us)) + " µs" : ""}</td>
     ${tick ? `<td>${x.position === "fault" ? '<span class="hint">stays</span>' : '<button class="small drop" type="button">drop</button>'}</td>` : ""}</tr>`).join("")}</table></div>`;
}
document.addEventListener("click", e => { const b = e.target.closest("button.drop"); if (!b) return; const tr = b.closest("tr"); tr.classList.toggle("dropped"); b.textContent = tr.classList.contains("dropped") ? "put back" : "drop"; });
function solutionBody(x) {
  const devs = (x.devices || []).map(d => `${esc(d.device)}: ${esc(d.words)}`).join("; ");
  return `<p class="hint">Stored ${esc(x.created)} by ${esc(x.created_by || "")}${x.last_judged ? `; last judged ${esc(x.last_judged)}` : ""}${devs ? `; on drives: ${devs}` : ""}.</p>
    <h4 style="margin:8px 0 4px">Error sequence <span class="hint">· makes the error happen again; the test is written from it</span></h4>${seqTable(x.error_seq)}
    <h4 style="margin:10px 0 4px">Optimized sequence <span class="hint">· solves the problem for this cause</span></h4>
    ${(x.optimized || []).length ? `<ol>${x.optimized.map(l => `<li>${esc(l)}</li>`).join("")}</ol>` : `<p class="hint">none written yet</p>`}
    <p class="hint">Versions: ${(x.versions || []).map(v => `${esc(v.version)} (${esc(v.at)}, ${esc(v.by || "")}${v.test_path ? ", test approved" : ""})`).join("; ")}.
      ${(x.verdicts || []).length ? `Judgements: ${x.verdicts.map(v => `${esc(v.signal)} by ${esc(v.by)} on ${esc(v.at)}${v.counted === false ? " (replaced by a later judgement of the same error)" : ""}`).join("; ")}.` : "Not judged yet."}</p>`;
}
async function showGraph() {
  const v = S.view = await api("GET", `/api/dg/defects/${S.defect}`), i = S.iso.isolation || {};
  const outline = !(v.causes || []).length ? `<p><b>First finding of this defect:</b> nothing is stored for it yet. Name its cause below; it is stored under the defect.</p>`
    : `<p><b>Already in the procedural graph:</b> ${v.causes.length} cause${v.causes.length === 1 ? "" : "s"}; the defect was seen ${v.seen} time${v.seen === 1 ? "" : "s"} on ${esc((v.devices || []).join(", ") || "no named drive")}. Open a cause to see its solutions.</p>` +
      v.causes.map(c => `<details class="node"><summary><b>${esc(c.header)}</b> <span class="hint">· ${esc(c.side_words)} · ${esc(c.chosen_words)} · ${c.solutions.length} solution${c.solutions.length === 1 ? "" : "s"}</span></summary>
        <div class="in">${c.solutions.length ? c.solutions.map(x => `<details class="node"><summary>Solution ${x.rank}: ${esc(((x.optimized || [])[0] || "no optimized sequence yet").slice(0, 120))} <span class="hint">· ${esc(x.judged_words)}</span></summary><div class="in">${solutionBody(x)}</div></details>`).join("")
          : `<p class="hint">no solution stored under this cause yet</p>`}</div></details>`).join("") + `<p class="hint">${esc(v.order || "")}</p>`;
  if (!S.causes) { try { S.causes = (await api("GET", "/api/dg/terms")).causes || []; } catch (e) { S.causes = []; } }
  const mc = i.cause || {}, stored = new Set((v.causes || []).map(c => c.key));
  const mcKey = mc.key || i.cause_key || "", noCause = causeName(mc, i.cause_key) === NO_CAUSE;
  const causeNote = [noCause ? "" : mc.side_words, stored.has("kw:" + mcKey) ? "already stored for this defect" : ""].filter(Boolean).join("; ");
  const bySide = {}; S.causes.forEach(c => (bySide[c.side_words] = bySide[c.side_words] || []).push(c));
  $("graph-out").innerHTML = `<h3 style="margin:0 0 6px">The defect: ${esc(v.name)}</h3>${outline}
    <div class="choice"><h3>The cause of this error</h3>
      <p class="hint">A cause is one keyword of the dictionary, the same words for everyone; nothing is typed.</p>
      <p>The fixed rules decided: <b>${esc(causeName(mc, i.cause_key))}</b>${causeNote ? ` <span class="hint">(${esc(causeNote)})</span>` : ""}${i.cause_header ? `<br><span class="hint">Because ${esc(plain(i.cause_header))}.</span>` : ""}</p>
      <div class="row"><button class="primary" id="btn-cause-model">${noCause ? "Continue without a named cause" : "Use this cause"}</button></div>
      <label style="display:block;margin-top:10px">Or, if you know better, another keyword of the dictionary <select id="cause-choice"><option value="">choose…</option>${Object.entries(bySide).map(([side, cs]) => `<optgroup label="${esc(side)}">${cs.map(c => `<option value="${esc(c.key)}">${esc(c.name)}${stored.has("kw:" + c.key) ? " (stored for this defect)" : ""}</option>`).join("")}</optgroup>`).join("")}</select></label>
      <p class="hint" id="cause-evidence"></p>
      <div class="row"><button id="btn-cause">Use the chosen keyword</button><span id="cause-status" class="status"></span></div><div id="cause-trace"></div></div>`;
  $("cause-choice").onchange = () => { const c = S.causes.find(x => x.key === $("cause-choice").value); $("cause-evidence").textContent = c ? `${c.side_words}; points at it: ${c.evidence}` : ""; };
  $("btn-cause-model").onclick = () => useCause(mcKey);
  $("btn-cause").onclick = () => useCause($("cause-choice").value);
}
async function useCause(kw) {
  if (!needName()) return;
  if (!kw) { status("cause-status", "choose a keyword first", "bad"); return; }
  const i = S.iso.isolation || {};
  try {
    const cid = (await api("POST", "/api/dg/causes", { defect_id: S.defect, keyword: kw, admin: name(), upload_id: UID, finding_id: FID })).id;   // the error is named, so the order of the flow is checked here too
    const o = await api("POST", "/api/dg/occurrences", { defect_id: S.defect, cause_id: cid, upload_id: UID, finding_id: FID, device: i.device, firmware: i.firmware, isolation: isolationRecord(), admin: name(), ...windowSent() });
    S.cause = cid;
    status("cause-status", "this error is kept under that cause (one count for it, with this drive)", "ok");
    if ($("cause-trace")) $("cause-trace").innerHTML = traceLine(o.trace);
    await showSolutions();
    $("s-solution").scrollIntoView({ behavior: "smooth" });
  } catch (e) { refusedHere(e, "cause-status", "cause-trace"); }
}

// ------------------------------------------------------------------ 5 the solution
async function showSolutions(did, trace) {
  const v = S.view = await api("GET", `/api/dg/defects/${S.defect}`), c = (v.causes || []).find(x => x.id === S.cause);
  if (!c) { $("sol-out").innerHTML = `<p class="bad">the cause is not under this defect</p>`; return; }
  const head = `<div id="sol-prog"></div><p>Defect <b>${esc(v.name)}</b> · cause <b>${esc(c.header)}</b> (${esc(c.side_words)}).</p>${did ? `<div class="did"><b>What your judgement did:</b> ${did.map(esc).join("; ")}.</div>` : ""}${traceLine(trace)}`;
  if (!c.solutions.length) {
    // the progress box (sol-prog, in the head) must be on the page before the proposal is asked for: until 2026-11-15 it was not, the request
    // failed inside the page before it was sent, and the form then said "the model proposed it" over an empty box
    $("sol-out").innerHTML = head + `<p><b>No solution is stored for this cause yet.</b> Store the first one:</p>`;
    $("sol-out").insertAdjacentHTML("beforeend", await firstSolutionForm()); wireFirst(); return;
  }
  // (owner, 2026-11-11: "where are positive, negative, positive with feedback, negative with feedback?") the four judgements sit at the
  // top of every stored solution, named in the owner's words; the best-ranked solution is open, so they are seen without a click
  $("sol-out").innerHTML = head + `<p>Stored solutions for this cause, best judged first (${c.solutions.length}). Judge each one with the four buttons at its top: <b>positive</b>, <b>positive with feedback</b> (your changes), <b>negative</b>, <b>negative with feedback</b>. Your judgement only changes the order the solutions are shown in next time.</p>` +
    c.solutions.map((x, k) => `<details class="node" data-sid="${x.id}"${k === 0 ? " open" : ""}><summary>Solution ${x.rank}: ${esc(((x.optimized || [])[0] || "no optimized sequence yet").slice(0, 120))} <span class="hint">· ${esc(x.judged_words)}</span></summary>
      <div class="in">
        <div class="judge"><h4>Your judgement of this solution <span class="hint">· it only changes the order the solutions are shown in next time</span></h4>
          <div class="verdicts"><button class="plus" data-sig="correct" data-sid="${x.id}"><b>Correct</b><small>positive</small></button>
            <button class="plus" data-sig="correct_with_edits" data-sid="${x.id}"><b>Correct with my edits</b><small>positive with feedback</small></button>
            <button class="minus" data-sig="wrong" data-sid="${x.id}"><b>Wrong</b><small>negative</small></button>
            <button class="minus" data-sig="wrong_with_edits" data-sid="${x.id}"><b>Wrong, keep my edits</b><small>negative with feedback</small></button></div>
          <span class="status" data-st="${x.id}"></span>
          <div class="choice" data-edit="${x.id}" hidden><h3>Your edits <span class="hint">· then press the button again to save them with your judgement</span></h3><p class="hint">Drop the error-sequence steps it does not need; change the optimized sequence, one action per line.</p>${seqTable(x.error_seq, "s" + x.id)}
            <textarea class="seqbox" data-opt="${x.id}">${esc((x.optimized || []).join("\n"))}</textarea>
            <div class="row" style="margin-top:8px"><button class="primary" data-save="${x.id}">Save my edits with my judgement</button></div></div></div>
        ${labLines(x)}${solutionBody(x)}</div></details>`).join("") +
    `<details class="node" id="none-fits"><summary>None fits: store this recording's sequence as a new solution</summary><div class="in"><p class="hint">opening…</p></div></details>`;
  $("none-fits").addEventListener("toggle", async ev => { const d = ev.target; if (!d.open || d.dataset.ready) return; d.dataset.ready = "1"; d.querySelector(".in").innerHTML = await firstSolutionForm(); wireFirst(); });
  $("sol-out").querySelectorAll(".verdicts button").forEach(b => b.onclick = () => judge(b, c));
  // the same save at the bottom of the edits, so the admin need not scroll back up after editing a long sequence
  $("sol-out").querySelectorAll("button[data-save]").forEach(b => b.onclick = () => {
    const box = document.querySelector(`[data-edit="${b.dataset.save}"]`), armed = document.querySelector(`.verdicts button[data-sid="${b.dataset.save}"][data-sig="${box.dataset.sig}"]`);
    if (armed) judge(armed, c);
  });
}
// Two ledgers of a stored solution, kept apart (2026-11-15): what admins judged (the four buttons; it alone decides the order shown) and what
// lab runs counted (replays on a bench; never a judgement). One line per bench, so a simulated drive and a real drive are never added together.
function labLines(x) {
  const lab = x.lab || {}, lines = [];
  ["simulated", "real"].forEach(k => { if (lab[k]) lines.push(`${esc(lab[k].words)} <span class="hint">· ${nf(lab[k].results)} result${lab[k].results === 1 ? "" : "s"}; drives: ${esc((lab[k].drives || []).join("; "))}</span>`); });
  if (!lines.length) lines.push("lab runs: none yet");
  return `<div class="ledgers" style="margin:8px 0;padding:6px 10px;border-left:3px solid #8aa">
    <div><b>judged by admins:</b> ${x.judged ? `correct ${nf(x.correct)} of ${nf(x.judged)}${x.edits ? ` (${nf(x.edits)} with edits)` : ""}` : "not judged yet"} <span class="hint">· counted from the four buttons above; this alone decides the order the solutions are shown in</span></div>
    ${lines.map(l => `<div>${l}</div>`).join("")}
    <div class="hint">A lab run is one replay of this solution's sequence on a bench, counted by the search on this page or brought back from a validation suite. It never changes a judgement or the order, and a run without the failure counts against this solution, not against the cause.${lab.not_counted ? " " + esc(lab.not_counted) + "." : ""}</div></div>`;
}
async function firstSolutionForm() {
  const i = S.iso.isolation || {}, c = (S.view.causes || []).find(x => x.id === S.cause) || {};
  let prop = null, failed = "";
  try { prop = await runJob("/api/dg/optimized", { upload_id: UID, finding_id: FID, isolation: isolationRecord(), cause: { side: c.side, header: c.header }, error_seq: S.iso.sequence || [], standin: STANDIN }, "sol-prog"); }
  catch (e) { if (e.waits) return waitLine(e.message); failed = e.message || "the request failed"; /* any other failure: written by hand, and the form says so */ }
  const said = proposalWords(prop, failed), boxText = said.byModel ? prop.lines.join("\n") : "";
  S.proposed = said.byModel ? boxText : null;                     // what the model put into the box, or null: the stored record says who wrote the solution
  return `<h4 style="margin:8px 0 4px">Error sequence <span class="hint">· this recording's commands that make the error happen again; drop what it does not need (the error's own step stays)</span></h4>${seqTable(S.iso.sequence, "new")}
    <h4 style="margin:10px 0 4px">Optimized sequence <span class="hint">· the solution for this cause, one action per line; ${esc(said.words)}</span></h4>
    ${said.byModel && prop.note ? `<p class="hint">${esc(plain(prop.note))}</p>` : ""}<textarea class="seqbox" id="opt-new">${esc(boxText)}</textarea>
    <div class="row" style="margin-top:8px"><button class="primary" id="btn-store">Store this solution</button><span id="store-status" class="status"></span></div>`;
}
const kept = (seq, tick) => { const drop = new Set([...document.querySelectorAll(`tr[data-tick="${tick}"].dropped`)].map(x => Number(x.dataset.step)));
  return (seq || []).filter(s => !drop.has(s.step) || s.position === "fault").map((s, i) => Object.assign({}, s, { step: i + 1 })); };
// a sequence box shows all its steps: it grows to its text (up to three quarters of the screen, then it scrolls) and again as the admin types
function growBox(t) { if (!t || t.offsetParent === null) return; t.style.height = "auto"; t.style.height = (t.scrollHeight + 4) + "px"; }
document.addEventListener("input", ev => { if (ev.target.classList && ev.target.classList.contains("seqbox")) growBox(ev.target); });
window.addEventListener("resize", () => document.querySelectorAll("textarea.seqbox").forEach(growBox));
function wireFirst() {
  growBox($("opt-new"));
  const b = $("btn-store"); if (!b) return;
  b.onclick = async () => {
    if (!needName()) return;
    const lines = ($("opt-new").value || "").split("\n").map(x => x.trim()).filter(Boolean);
    if (!lines.length) { status("store-status", "write the optimized sequence, one action per line", "bad"); return; }
    try {
      const r = await api("POST", "/api/dg/solutions", { cause_id: S.cause, error_seq: kept(S.iso.sequence, "new"), optimized: lines, admin: name(), ...(typeof S.proposed === "string" ? { producer: lines.join("\n") === S.proposed.split("\n").map(x => x.trim()).filter(Boolean).join("\n") ? `model, stored unchanged by ${name()}` : `model, edited by ${name()}` } : {}), upload_id: UID, finding_id: FID, ...windowSent() });
      chooseForTest(r.solution, r.revision_id);          // written or edited by you: it starts "not yet judged" (no judgement is invented for it)
      await showSolutions([`stored as a new solution under this cause; it is not judged yet. Judge it with the four buttons below once you have checked it, or the next time this defect and cause come back`], r.trace);
    } catch (e) { refusedHere(e, "store-status", "sol-prog"); }
  };
}
async function judge(b, c) {
  if (!needName()) return;
  const sid = Number(b.dataset.sid), sig = b.dataset.sig, x = c.solutions.find(s => s.id === sid), box = document.querySelector(`[data-edit="${sid}"]`);
  if (sig.endsWith("_with_edits") && box.hidden) { box.hidden = false; box.dataset.sig = sig; growBox(box.querySelector("textarea.seqbox")); const t = b.querySelector("b"); t.textContent = `Save: ${t.textContent}`; box.scrollIntoView({ behavior: "smooth", block: "start" }); return; }   // first click opens the edits
  const body = { signal: sig, admin: name(), occurrence_id: S.occ, device: (S.iso.isolation || {}).device, firmware: (S.iso.isolation || {}).firmware, ...windowSent() };
  if (sig.endsWith("_with_edits")) { body.error_seq = kept(x.error_seq, "s" + sid); body.optimized = (document.querySelector(`[data-opt="${sid}"]`).value || "").split("\n").map(l => l.trim()).filter(Boolean); }
  try {
    const r = await api("POST", `/api/dg/solutions/${sid}/verdict`, body);
    if (sig !== "wrong") chooseForTest(r.new_solution_id ? Object.assign({}, r.solution, { id: r.new_solution_id, error_seq: body.error_seq || x.error_seq, origin_upload: x.origin_upload }) : r.solution, r.new_revision_id || r.solution.revision_id);
    await showSolutions(r.did, r.trace);
  } catch (e) { const st = document.querySelector(`[data-st="${sid}"]`); if (st) { st.textContent = e.message; st.className = "status bad"; } }
}
function chooseForTest(sol, rev) {
  const fromHere = !sol.origin_upload || sol.origin_upload === UID;
  S.sol = { id: sol.id, revision_id: rev, from_here: fromHere };
  S.testSeq = fromHere ? sol.error_seq : S.iso.sequence;          // a solution stored from another recording: the test uses this recording's rows of the same error
  showTest();
}

// ------------------------------------------------------------------ 6 the test case
function showTest() {
  $("test-out").innerHTML = `<p>The test replays the error sequence (${S.testSeq.length} command${S.testSeq.length === 1 ? "" : "s"}${S.sol.from_here ? "" : ", taken from this recording because the chosen solution was stored from another one"}) and then checks what a correct drive must answer.</p>
    <div class="row"><button class="primary" id="btn-expect">Propose what a correct drive must answer</button><span id="test-status" class="status"></span></div><div id="test-prog"></div><div id="expect-out"></div><div id="file-out"></div>`;
  $("btn-expect").onclick = proposeExpected;
  showSearch();                                                   // the optional search part (its own block below) opens with the test part
  $("s-test").scrollIntoView({ behavior: "smooth" });
}
async function proposeExpected() {
  if (!needName()) return;
  try { S.expect = await runJob(`${BASE}/testcase${STANDIN ? "?standin=1" : ""}`, { sequence: S.testSeq, expected_after: 3, name: name(), standin: STANDIN, ...searchChoice() }, "test-prog"); }
  catch (e) { refusedHere(e, "test-status", "expect-out"); return; }
  const E = S.expect;
  status("test-status", `${who(E.producer)}; the time limit used: ${E.limit.text} (${E.limit.source})`, E.standin ? "warn" : "ok");
  const nAfter = E.expected_outcomes.filter(o => o.step > E.fault_step).length;
  $("expect-out").innerHTML = `<p style="margin-top:10px"><b>What the test does:</b> it sends the ${E.sequence.length} commands of the error sequence in order, then checks what the drive answered to the error's command${nAfter ? ` and the ${nAfter} after it` : ""}. A correct drive must answer as in the table.</p>
    <p><b>Check each line.</b> Change what is wrong, tick it, then write the file.</p>
    <div class="xscroll"><table class="steps wide"><tr><th>step</th><th>command</th><th>a correct drive answers</th><th>within</th><th>how the test checks it</th><th>why</th><th>checked</th></tr>
    ${E.expected_outcomes.map((o, k) => `<tr class="${o.step === E.fault_step ? "err" : ""}" data-k="${k}"><td>${esc(o.step)}${o.step === E.fault_step ? " · the error" : ""}</td><td>${esc(o.command)}</td>
      <td><input class="st" value="${esc(o.status)}"></td><td><input class="tm" type="number" min="1" value="${esc(o.timing_us)}" style="width:110px"> µs<div class="hint">= ${esc((o.timing_us / 1e6).toLocaleString("en-US", { maximumFractionDigits: 6 }))} s</div></td><td><input class="ck" value="${esc(o.check)}"></td>
      <td class="hint">${esc(plain(o.basis))}</td><td><input type="checkbox" class="ver"></td></tr>`).join("")}</table></div>
    <div class="row" style="margin-top:8px"><button class="primary" id="btn-write">Write the test file</button><span id="write-status" class="status"></span></div><div id="write-prog"></div>`;
  $("btn-write").onclick = writeFile;
}
async function writeFile() {
  const E = S.expect, rows = [...$("expect-out").querySelectorAll("tr[data-k]")];
  const outs = rows.map(tr => { const o = E.expected_outcomes[Number(tr.dataset.k)]; return Object.assign({}, o, { status: tr.querySelector(".st").value, timing_us: Number(tr.querySelector(".tm").value || o.timing_us), check: tr.querySelector(".ck").value, verified: tr.querySelector(".ver").checked }); });
  if (outs.some(o => !o.verified)) { status("write-status", "tick every line you checked first", "bad"); return; }
  try { S.file = await runJob(`${BASE}/testcase${STANDIN ? "?standin=1" : ""}`, { sequence: E.sequence, expected_outcomes: outs, verified: true, name: name(), scenario_name: (S.view || {}).name || "", standin: STANDIN, author: "model" }, "write-prog"); }
  catch (e) { refusedHere(e, "write-status", "file-out"); return; }
  const F = S.file, two = F.two_sided || {};
  const runs = (two.runs || []).map(x => `<li>a simulated <b>${esc(x.drive)}</b> drive, the test looking for ${x.expect === "fault" ? "the error" : "the fix"}: it should <b>${esc(x.wanted)}</b>, it did <b>${esc(x.got)}</b>${x.wanted === x.got ? "" : " ✘"}</li>`).join("");
  status("write-status", "written", "ok");
  $("file-out").innerHTML = `<div class="answer"><p><b>${esc(F.name)}</b> (version ${esc(F.version)}) is written.</p>
      <p>Tried on the simulated drive: ${two.ok ? "<b>every run gave what was wanted</b>" : two.runs ? "<b class='bad'>a run did not give what was wanted</b>" : esc(two.words || "not tried")}.</p>${runs ? `<ul>${runs}</ul>` : ""}
      <details class="node"><summary>The whole test file</summary><div class="in"><p class="hint">Saved at ${esc(F.path)}</p><pre class="file">${esc(F.text || "")}</pre></div></details>
      <div class="row" style="margin-top:8px"><button class="primary" id="btn-approve">Approve this test</button><span id="approve-status" class="status"></span></div></div>`;
  $("btn-approve").onclick = approve;
  if (!two.ok) { $("btn-approve").disabled = true; status("approve-status", "the simulated trial did not give what was wanted: write it again before approving", "bad"); }
}
async function approve() {
  if (!needName()) return;
  try {
    const r = await api("POST", `${BASE}/testcase/approve`, { path: S.file.path, name: name(), revision_id: (S.sol || {}).revision_id, two_sided: (S.file.two_sided || {}).ok });
    status("approve-status", `approved by ${name()}; this error is done`, "ok");
    $("btn-approve").disabled = true;
    $("file-out").insertAdjacentHTML("beforeend", `<div class="did"><b>This error is done.</b> <a href="${esc($("back-link").href)}">Back to the errors</a>${traceLine(r.trace)}</div>`);
    showHandover().catch(() => {});                              // the approved test can now be handed over (the part after this one)
  } catch (e) { status("approve-status", e.message, "bad"); }
}

// ------------------------------------------------------------------ hand over to the validation suite (2026-11-14): this error's own test only
// A block of its own: showHandover() is called when the page opens and again after the test is approved. It reads /api/handover/tests, keeps this
// error's test files, and builds a package only from what the admin ticks, with the name the admin types (nothing is ticked or typed for them).
const HO = { tests: [], zipUrl: null, sync: () => {} };
const HO_STATE = { "approved": "Approved", "not approved": "Not approved", "changed after approval": "Changed after approval: approve it again", "approval record unreadable": "Approval record cannot be read" };
const hoMine = t => String(t.name || "").startsWith(`${UID}_f${FID}_`) || (t.finding === FID && (t.recording || {}).upload === UID);
async function showHandover() {
  const box = $("handover-out"); if (!box) return;
  let list;
  try { list = await api("GET", "/api/handover/tests"); if (!list || !Array.isArray(list.tests)) throw new Error("no answer"); }
  catch (e) { box.innerHTML = `<p class="locked">The hand-over is not available on this server at the moment (${esc(e.message)}). Nothing else on this page depends on it.</p>`; return; }
  HO.tests = list.tests.filter(hoMine);
  if (!HO.tests.length) { box.innerHTML = `<p class="locked">No test file is written for this error yet. Write and approve its test in part 6; after that it can be handed over here.</p>`; return; }
  const typed = ($("ho-name") || {}).value || "";                 // what the admin already typed stays when the list is read again
  box.innerHTML = `<label class="f">This error's test to hand over</label>
    <div class="why">Tick the test yourself: nothing is chosen for you. Only an approved test whose file is unchanged since its approval can be ticked; the State column says why another one cannot.</div>
    <div class="xscroll"><table class="steps wide"><tr><th>hand over</th><th>test</th><th>defect it reproduces</th><th>approved by</th><th>approved on</th><th>state</th><th>run so far</th></tr>
    ${HO.tests.map(t => { const a = t.approval || {}; return `<tr><td><input type="checkbox" class="ho-pick" value="${esc(t.name)}" aria-label="hand over the test ${esc(t.name)}"${a.can_hand_over ? "" : " disabled"}></td>
      <td>${esc(t.name)}${t.version != null ? `<div class="hint">version ${esc(t.version)}</div>` : ""}</td><td>${esc(t.defect || "")}</td><td>${esc(a.approved_by || "nobody yet")}</td><td>${esc(a.approved_at || "not approved yet")}</td>
      <td><b>${esc(HO_STATE[a.state] || a.state || "Not approved")}</b>${a.why_not ? `<div class="hint">${esc(a.why_not)}</div>` : ""}</td>
      <td>${(t.run_history || {}).only_simulated_drive === false ? "A result from a real drive was brought in" : "Only on a simulated drive"}<div class="hint">${esc((t.run_history || {}).words || "")}</div></td></tr>`; }).join("")}</table></div>
    <p class="hint">hand over: your tick puts the test into the package · test: the test file written in part 6, with the version of its solution · defect it reproduces: the test file's own words · approved by, approved on: who approved it in part 6 and when (UTC is the time zone) · state: whether it can be handed over, and why not · run so far: whether any result from a real drive has been brought in for it.</p>
    ${HO.tests.map(t => [(t.library || {}).words, (t.two_way_result_at_approval || {}).words].filter(Boolean).length ? `<p class="hint">About ${esc(t.name)}: ${esc([(t.library || {}).words, (t.two_way_result_at_approval || {}).words].filter(Boolean).join(" "))}</p>` : "").join("")}
    <label class="f" for="ho-name">Your name <input id="ho-name" type="text" placeholder="who builds the package or brings the result in" style="width:340px"></label>
    <div class="why">Required. The package, and every result brought in, is recorded with the name of the person who did it, so the validation suite's team knows whom to ask. It is not filled in for you.</div>
    <div class="row"><button class="primary" id="btn-ho-build" disabled>Build the package for the validation suite</button><span id="ho-status" class="status"></span></div>
    <div id="ho-package"></div>
    <h3 style="margin:16px 0 4px">Bring a result file in</h3>
    <label class="f" for="ho-file">The JUnit XML file your suite wrote when it ran a package <input id="ho-file" type="file" accept=".xml,text/xml,application/xml"></label>
    <div class="why">JUnit XML is the result file a test runner writes (the package's README gives the command that writes it). Every test case in it is recorded with the name you gave above. At most 5 megabytes; a file for a test that is in no package is refused whole. A result is also counted as lab runs of the stored solution this test was approved for (part 5 shows them) when the file itself says which bench it ran on (a real drive or the simulated drive), that the run looked for the error, and in how many runs the failure came back; any other result is kept, and the line beside the button says why it was not counted. One run is counted once.</div>
    <div class="row"><button id="btn-ho-bring" disabled>Bring in</button><span id="ho-bring-status" class="status"></span></div>
    <h3 style="margin:16px 0 4px">What came back</h3><div id="ho-results"></div>`;
  $("ho-name").value = typed;
  HO.sync = () => { const picked = box.querySelectorAll(".ho-pick:checked").length, nm = ($("ho-name").value || "").trim();
    $("btn-ho-build").disabled = !(picked && nm); $("btn-ho-bring").disabled = !(($("ho-file").files || []).length && nm); };
  box.querySelectorAll(".ho-pick").forEach(x => { x.onchange = HO.sync; });
  $("ho-name").oninput = HO.sync; $("ho-file").onchange = HO.sync;
  $("btn-ho-build").onclick = hoBuild; $("btn-ho-bring").onclick = hoBring;
  HO.sync();
  await hoResults();
}
async function hoBuild() {
  const tests = [...document.querySelectorAll("#handover-out .ho-pick:checked")].map(x => x.value), nm = ($("ho-name").value || "").trim();
  if (!tests.length || !nm) return;
  $("btn-ho-build").disabled = true; status("ho-status", "building the package…");
  try {
    const r = await fetch("/api/handover/package", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tests, name: nm }) });
    if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.error || r.statusText); }
    const blob = await r.blob(), id = r.headers.get("X-Handover-Package") || "handover-package", sha = r.headers.get("X-Handover-Sha256") || "";
    if (HO.zipUrl) URL.revokeObjectURL(HO.zipUrl);
    HO.zipUrl = URL.createObjectURL(blob);
    status("ho-status", "built", "ok");
    $("ho-package").innerHTML = `<div class="did"><b>Package ${esc(id)} built with ${nf(tests.length)} test${tests.length === 1 ? "" : "s"}.</b> Its README gives the exact command and the safety switches a person must set.
      <a id="ho-download" href="${esc(HO.zipUrl)}" download="${esc(id)}.zip">Download the package (${esc(id)}.zip, ${nf(blob.size)} bytes)</a>
      ${sha ? `<div class="hint">Fingerprint of the zip file (SHA-256), to check that the copy the suite receives is the same file: ${esc(sha)}</div>` : ""}</div>`;
  } catch (e) { status("ho-status", e.message, "bad"); }
  HO.sync();
}
async function hoBring() {
  const f = ($("ho-file").files || [])[0], nm = ($("ho-name").value || "").trim();
  if (!f || !nm) return;
  $("btn-ho-bring").disabled = true; status("ho-bring-status", "reading the result file…");
  try {
    const form = new FormData(); form.append("file", f); form.append("name", nm);
    const r = await fetch("/api/handover/results", { method: "POST", body: form }), j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || r.statusText);
    status("ho-bring-status", [j.words || "recorded", j.graph_words].filter(Boolean).join(" "), "ok");   // graph_words: whether each result was counted as lab runs of its stored solution, and why not
    await hoResults();
  } catch (e) { status("ho-bring-status", e.message, "bad"); }
  HO.sync();
}
async function hoResults() {
  const box = $("ho-results"); if (!box) return;
  const all = [];
  try { for (const t of HO.tests) { const r = await api("GET", `/api/handover/results?test=${encodeURIComponent(t.name)}`); (r.tests || []).forEach(x => (x.results || []).forEach(y => all.push(y))); } }
  catch (e) { box.innerHTML = `<p class="status bad">The recorded results could not be read: ${esc(e.message)}</p>`; return; }
  if (!all.length) { box.innerHTML = `<p class="hint">No result has been brought in for this error's test yet.</p>`; return; }
  const looked = { fault: "the error", fixed: "the fix" };
  box.innerHTML = `<div class="xscroll"><table class="steps wide"><tr><th>test</th><th>result</th><th>what the run looked for</th><th>reason</th><th>drive (real or simulated)</th><th>run on</th><th>brought in on</th><th>brought in by</th><th>package</th></tr>
    ${all.map(y => `<tr class="${y.outcome === "failed" ? "err" : ""}"><td>${esc(y.test)}<div class="hint">${esc(y.case_name || "")}</div></td><td><b>${esc(y.outcome)}</b></td><td>${esc(looked[y.expect] || "not said in the result file")}</td><td>${esc(y.reason || "")}</td>
      <td>${esc(y.drive_kind || "not said in the result file")}${y.drive_model ? `<div class="hint">${esc(y.drive_model)}${y.drive_firmware ? `, firmware ${esc(y.drive_firmware)}` : ""}</div>` : ""}</td><td>${esc(y.run_at || "not said in the result file")}</td><td>${esc(y.brought_in_at || "")}</td><td>${esc(y.brought_in_by || "")}</td><td>${esc(y.package_id || "")}</td></tr>`).join("")}</table></div>
    <p class="hint">test: the test file, and under it the test case inside it · result: passed, failed or skipped, as the suite's runner wrote it; it is recorded here, not judged · what the run looked for: the error or the fix; "failed" means opposite things in the two, so read both columns together · reason: the runner's own text for a failed or skipped test · drive: whether the result file says the run was on a real drive or on a simulated one, with the drive's model and firmware when it says them · run on: the run's own time stamp from the result file · brought in on, brought in by: when (UTC) and by whom the file was given to this application · package: the number of the hand-over package the run was made from.</p>`;
}

// ------------------------------------------------------------------ optional: search for the conditions that bring the failure back (2026-11-14)
// A block of its own: showSearch() is called by showTest(); searchChoice() adds the admin's choice to the request that proposes the test.
// Nothing here runs unless the admin presses the button; with no choice made the test is written from the first sequence, as before.
const SR = { defaults: null, result: null };
function searchChoice() { const c = document.querySelector('input[name="sr-use"]:checked'); return c && c.value !== "first" ? { use_search: c.value } : {}; }
async function showSearch() {
  const box = $("search-out"); if (!box) return;
  let info;
  try { info = await api("GET", `${BASE}/search`); if (!info || !info.defaults) throw new Error("no answer"); }
  catch (e) { box.innerHTML = `<p class="locked">The search is not available on this server at the moment (${esc(e.message)}). Part 6 works without it: the test is written from the first sequence.</p>`; return; }
  SR.defaults = info.defaults; SR.result = info.result;
  const d = info.defaults, pool = Number($("n-above").value || 15);
  box.innerHTML = `<p>The search starts from the error sequence chosen in part 5 (${S.testSeq.length} command${S.testSeq.length === 1 ? "" : "s"}) and may also use the ${nf(pool)} commands recorded before the error (the number in "Commands above" of part 2).</p>
    <label class="f" for="sr-bench">Where the changed sequences are replayed
      <select id="sr-bench"><option value="">choose one…</option><option value="simulated">the simulated drive with a hidden trigger (a demonstration, no real device)</option><option value="real">the real bench (the bench connection of this application)</option></select></label>
    <div class="why">The search needs something that answers "did the failure come back?". Nothing is chosen for you. A result from the simulated drive shows that the search works; it never shows that a real drive fails.</div>
    <label class="f" for="sr-budget">Budget: how many bench runs the search may use
      <input id="sr-budget" type="number" min="${esc(d.budget_min)}" max="${esc(d.budget_max)}" value="${esc(d.budget)}" style="width:120px"></label>
    <div class="why">${esc(noTestFile(d.budget_why, SEARCH_RECORD))} Allowed: ${nf(d.budget_min)} to ${nf(d.budget_max)} bench runs.</div>
    <div class="row"><button class="primary" id="btn-search">Search for the conditions that bring the failure back</button><button id="btn-search-stop" hidden>Stop the search</button><span id="search-status" class="status"></span></div>
    <div id="search-prog"></div><div id="search-result"></div>
    <label class="f" for="btn-sr-store">Keep the searched sequence in the procedural graph</label>
    <div class="why">Nothing is stored by itself. Your press stores the sequence the search found (or the most stressful one, when you chose that one for the test), with its gaps in microseconds and its queue depth, as a new solution of this error's cause. It is not judged: no judgement is written for it, and its lab runs are shown apart from the judgements. It needs your name at the top and a named cause (part 4).</div>
    <div class="row"><button id="btn-sr-store" disabled>Store this sequence as a solution of the cause</button><span id="sr-store-status" class="status">off until a search has finished</span></div>`;
  $("btn-sr-store").onclick = storeSearched;
  $("btn-search").onclick = runSearch;
  $("btn-search-stop").onclick = async () => { try { const r = await api("POST", `${BASE}/search/stop`, {}); status("search-status", r.note, "warn"); } catch (e) { status("search-status", e.message, "bad"); } };
  if (SR.result) renderSearch(true);
}
async function runSearch() {
  if (!needName()) return;
  const bench = $("sr-bench").value, budget = Number($("sr-budget").value);
  if (!bench) { status("search-status", "choose where the changed sequences are replayed first", "bad"); $("sr-bench").focus(); return; }
  if (!Number.isInteger(budget)) { status("search-status", "the budget must be a whole number of bench runs", "bad"); $("sr-budget").focus(); return; }
  $("btn-search").disabled = true; $("btn-search-stop").hidden = false; status("search-status", "");
  try {
    const r = await runJob(`${BASE}/search`, { sequence: S.testSeq, budget, bench, pool_n: Number($("n-above").value || 15), name: name() }, "search-prog");
    if (r.stopped) status("search-status", r.note, "warn");
    else { SR.result = r.result; status("search-status", "the search ended and its result is stored", "ok"); renderSearch(false); }
  } catch (e) { refusedHere(e, "search-status", "search-result"); }
  $("btn-search").disabled = false; $("btn-search-stop").hidden = true;
}
// What the search read from the procedural graph before it started and what it wrote back (2026-11-15); every number is a count of bench runs
// or a gap in microseconds taken from the stored rows.
function srGraphHtml(R) {
  const G = R.graph_start; if (!G) return "";
  const F = (R.started_from || []).map(f => `<li>${esc(f.how)}: the failure came back in ${nf(f.reproduced)} of ${nf(f.runs)} runs on the ${esc(R.label)}</li>`).join("");
  const L = G.lead;
  return `<div class="did"><b>What the search started from:</b> ${esc(G.words || "")}
    ${L ? `<br><span class="hint">Solution ${nf(L.id)} is shown as solution ${nf(L.rank)} of its cause (that order comes from the admins' judgements; which solution is tried first comes from the lab runs alone). Rule of the draw: ${esc(G.formula || "")}.</span>` : ""}
    ${(G.said || []).length ? `<ul>${G.said.map(w => `<li>${esc(w)}</li>`).join("")}</ul>` : ""}${F ? `<ul>${F}</ul>` : ""}
    ${(G.brackets || []).length ? `<details class="node"><summary>The timing values the graph held before this search (${nf(G.brackets.length)})</summary><div class="in"><ul>${G.brackets.map(b => `<li>${esc(b.words)}</li>`).join("")}</ul><p class="hint">Each line is counted from earlier bench runs of this kind of defect on the same kind of bench: the largest gap (microseconds) at which the failure still came back and the smallest at which it did not. Nothing is trained.</p></div></details>` : ""}
    ${(G.written || []).length ? `<br><b>What this search wrote back:</b> ${G.written.map(esc).join("; ")}. No judgement and no solution was stored by the search.` : ""}
    ${G.gaps ? `<br><span class="hint">${esc(G.gaps)}.</span>` : ""}</div>`;
}
async function storeSearched() {
  if (!needName()) return;
  const c = document.querySelector('input[name="sr-use"]:checked'), which = c && c.value === "stressed" ? "stressed" : "best";
  $("btn-sr-store").disabled = true;
  try {
    const r = await api("POST", `${BASE}/search/store`, { name: name(), which });
    SR.result.stored_as = Object.assign({}, SR.result.stored_as, { [which]: r.stored });
    status("sr-store-status", `${r.words}. Open part 5 again to see it in the list of stored solutions.`, "ok");
  } catch (e) { status("sr-store-status", e.message, "bad"); $("btn-sr-store").disabled = false; }
}
function srSeqTable(part) {
  return `<div class="xscroll"><table class="steps"><tr><th>step</th><th>command</th><th>row of the recording</th><th>gap before it</th><th>why it is in the sequence</th></tr>
    ${part.steps.map(x => `<tr class="${x.position === "fault" ? "err" : ""}"><td>${esc(x.step)}${x.position === "fault" ? " · the error" : ""}</td><td>${esc(x.command)}</td><td>${nf(x.source_row)}</td><td>${nf(x.gap_us)} µs</td><td class="hint">${esc((x.why || []).join("; "))}</td></tr>`).join("")}</table></div>
    <p class="hint">step: the place in the replay · command: the NVMe command, with its recorded parameters · row of the recording: its row in nvme_command.csv · gap before it: microseconds (µs) the bench waits before sending it, as the search left it · commands kept open at once: ${nf(part.queue_depth)}</p>`;
}
function renderSearch(stored) {
  const R = SR.result, B = R.budget, sim = (R.bench || {}).simulated, best = R.best, st = R.stress, D = SR.defaults;
  const pct = x => `${(100 * x).toLocaleString("en-US", { maximumFractionDigits: 1 })} %`;
  const banner = sim ? `<div class="simnote"><b>Simulated drive.</b> ${esc((R.simulated_drive || {}).note || "This ran on a simulated drive, not on a real one.")}</div>`
    : `<div class="simnote real"><b>Real bench.</b> These runs were made through the bench connection of this application.</div>`;
  const when = R.at ? new Date(R.at * 1000).toLocaleString() : "";
  let h = `${banner}<p class="hint">${stored ? "Stored result" : "Result"} of the search${when ? ` of ${esc(when)}` : ""}${R.by ? `, started by ${esc(R.by)}` : ""}. The failure looked for: ${esc(R.failure || "")}.</p>
    <p><b>${best ? `The failure came back in ${nf(best.reproduced)} of ${nf(best.runs)} runs` : esc(R.verdict)}</b>${best ? ` on the ${esc(R.label)}. From these ${nf(best.runs)} runs alone, the true rate is at least ${pct(best.lower_bound)} (exact one-sided lower bound, 95 % confidence).` : "."}</p>
    <p>Bench runs used by the search: <b>${nf(B.search + B.confirm + B.smaller)}</b> of the ${nf(B.asked)} you allowed (searching ${nf(B.search)}, confirming ${nf(B.confirm)}, leaving out what is not needed ${nf(B.smaller)}). The stress step used ${nf(B.stress)} of its own allowance of ${nf(B.stress_allowance)} runs. One run replays one sequence once.</p>
    <p class="hint">The first sequence by itself: the failure came back in ${nf(R.seed.reproduced)} of ${nf(R.seed.runs)} runs${R.seed.runs ? "" : " (it was not run: a sequence from the graph was confirmed first)"}.</p>${srGraphHtml(R)}`;
  if (best) {
    h += `<h4>The sequence the search found</h4>${srSeqTable(best)}<p>Compared with the first sequence:</p><ul>${best.changes.map(c => `<li>${esc(c)}</li>`).join("")}</ul>
      ${best.queue_depth > 1 ? `<p class="warn">The written test sends one command at a time. The ${nf(best.queue_depth)} commands kept open at once are reported here, but the test file cannot replay them yet.</p>` : ""}
      <h4>The most stressful conditions found</h4>
      ${st && st.conditions.length ? `<ul>${st.conditions.map(c => `<li>${esc(c.words)}</li>`).join("")}</ul>` : `<p>The stress step could not push any value further: at the next step the failure no longer came back in ${nf(D.stress_need)} of ${nf(D.stress_runs)} runs, or the value was already at its end.</p>`}
      ${st && st.steps.length ? `<details class="node"><summary>Every stress step tried (${nf(st.steps.length)})</summary><div class="in"><div class="xscroll"><table class="steps"><tr><th>value pushed</th><th>from</th><th>to</th><th>failure came back</th><th>kept</th></tr>
        ${st.steps.map(x => `<tr><td>${esc(x.value)}</td><td>${nf(x.from)} ${esc(x.unit)}</td><td>${nf(x.to)} ${esc(x.unit)}</td><td>${nf(x.reproduced)} of ${nf(x.runs)} runs</td><td>${x.kept ? "yes" : "no: the step before it is the furthest"}</td></tr>`).join("")}</table></div>
        <p class="hint">${esc(st.need)}. A gap step halves the gap; a queue step keeps one more command open, never more than the recording showed.</p></div></details>` : ""}
      ${R.most_stressful ? `<details class="node"><summary>The most stressful sequence (failure back in ${nf(R.most_stressful.reproduced)} of ${nf(R.most_stressful.runs)} runs)</summary><div class="in">${srSeqTable(R.most_stressful)}</div></details>` : ""}`;
  }
  h += `<details class="node"><summary>Everything that was tried (${nf(R.candidates.length)} sequences, ${nf(B.used)} bench runs): nothing is left out</summary><div class="in"><div class="xscroll"><table class="steps wide">
      <tr><th>number</th><th>part of the work</th><th>what was changed</th><th>rows of the recording replayed, in order</th><th>gaps before them (µs)</th><th>kept open at once</th><th>failure came back</th><th>mean time of the failing command</th></tr>
      ${R.candidates.map(c => `<tr class="${c.reproduced ? "err" : ""}"><td>${nf(c.no)}</td><td>${esc({ search: "search", confirm: "confirmation", smaller: "leaving out", stress: "stress step" }[c.phase] || c.phase)}</td><td>${esc(c.how)}</td><td>${esc(c.rows.join(", "))}</td><td>${esc(c.gaps_us.join(", "))}</td><td>${nf(c.queue_depth)}</td><td>${nf(c.reproduced)} of ${nf(c.runs)} runs</td><td>${c.mean_time_us == null ? "not measured" : nf(c.mean_time_us) + " µs"}</td></tr>`).join("")}</table></div>
      <p class="hint">The last row number of each line is the failing command. The recorded failure took ${R.recorded_time_us == null ? "an unknown time" : nf(R.recorded_time_us) + " µs"}; the search prefers, first, sequences where the failure comes back more often and, second, sequences whose measured time is closer to that. Order rule: ${esc(R.order_rule || "")}.</p></div></details>`;
  if (sim && R.simulated_drive) h += `<details class="node"><summary>What the simulated drive was hiding from the search</summary><div class="in"><p>The failure of the simulated drive appears only when all of this holds:</p><ul>${R.simulated_drive.hidden_trigger_words.map(w => `<li>${esc(w)}</li>`).join("")}</ul><p class="hint">Shown only after the search, so that you can compare it with what the search found. It is made up for the demonstration and says nothing about a real drive.</p></div></details>`;
  h += `<label class="f">Which sequence the test in part 6 is written from</label>
    <div class="why">Nothing is chosen for you. With no choice, part 6 writes the test from the first sequence, exactly as it does without the search.${sim ? " A test written from a sequence found on the simulated drive says so in the reason of each step." : ""}</div>
    <div class="sr-choice"><label><input type="radio" name="sr-use" value="first"> the first sequence of part 5, as before</label>
      ${best ? `<label><input type="radio" name="sr-use" value="best"> the sequence the search found (failure back in ${nf(best.reproduced)} of ${nf(best.runs)} runs${sim ? ", simulated drive" : ""})</label>` : ""}
      ${R.most_stressful ? `<label><input type="radio" name="sr-use" value="stressed"> the most stressful sequence (failure back in ${nf(R.most_stressful.reproduced)} of ${nf(R.most_stressful.runs)} runs${sim ? ", simulated drive" : ""})</label>` : ""}</div>
    <span id="sr-use-status" class="status"></span>`;
  $("search-result").innerHTML = h;
  const sb = $("btn-sr-store"), done = (R.stored_as || {}).best;
  if (sb) { sb.disabled = !best || !!done; status("sr-store-status", !best ? "off: the search did not bring the failure back, so there is no sequence to store" : done ? `already stored as solution ${done.solution_id} by ${done.by}` : "the search has finished: your press stores its sequence; nothing is stored without it", done ? "ok" : ""); }
  $("search-result").querySelectorAll('input[name="sr-use"]').forEach(r => r.onchange = () => {
    ["expect-out", "file-out"].forEach(id => { if ($(id)) $(id).innerHTML = ""; });
    status("sr-use-status", r.value === "first" ? "part 6 writes the test from the first sequence" : "part 6 writes the test from this sequence: press \"Propose what a correct drive must answer\" there", "ok");
  });
}

// ------------------------------------------------------------------ ask the model (optional)
async function ask() {
  const msg = ($("chat-msg").value || "").trim(); if (!msg) return;
  if (!needName()) return;
  $("btn-send").disabled = true;
  try {
    const r = await api("POST", `${BASE}/chat${STANDIN ? "?standin=1" : ""}`, { message: msg, name: name(), standin: STANDIN,
      context: { rows: ((S.W || {}).commands || []).map(c => ({ level: c.level, rowid: c.rowid })), include_memory: false } });
    $("chat").innerHTML = (r.history || []).filter(h => h.text && h.role !== "loop" && !(h.data || {}).kind).slice(-20).map(h => { const me = String(h.role || h.who || "").startsWith("admin");
      return `<div class="msg ${me ? "me" : ""}">${esc(me ? h.text : plain(h.text))}</div>`; }).join("")
      || `<div class="msg">${esc(plain((r.answer || {}).answer || ""))}</div>`;
    $("chat-msg").value = "";
  } catch (e) { $("chat").insertAdjacentHTML("beforeend", `<div class="msg bad">${esc(e.message)}</div>`); }
  $("btn-send").disabled = false;
}

// ------------------------------------------------------------------ wiring
(async () => {
  document.querySelectorAll("button.nav").forEach(b => b.addEventListener("click", () => $(b.dataset.go).scrollIntoView({ behavior: "smooth" })));
  try { $("name").value = localStorage.getItem("agents.admin") || ""; } catch (e) { /* private window */ }
  $("name").addEventListener("change", () => { try { localStorage.setItem("agents.admin", name()); } catch (e) { /* private window */ } });
  const back = Q.get("back"); if (back && back.startsWith("/")) $("back-link").href = back;
  $("btn-show").onclick = showWindow;
  $("win").addEventListener("click", e => { const b = e.target.closest("button.exp"); if (b) expand(b); });
  $("btn-isolate").onclick = isolate;
  $("btn-send").onclick = ask;
  if (!UID || !Number.isInteger(FID)) { $("load-error").hidden = false; $("load-error").textContent = "open this page from the errors page: the address needs ?upload=…&finding=…"; return; }
  try { await loadError(); }
  catch (e) {
    if (e.waits) { showWaits(e.answer); return; }                 // the order of the flow: the message is the page; no other part is loaded
    $("load-error").hidden = false; $("load-error").textContent = "could not load the error: " + e.message; return;
  }
  showHandover().catch(() => {});                                 // this error's test and its hand-over state; the page does not wait for it
  await showWindow();
})();
