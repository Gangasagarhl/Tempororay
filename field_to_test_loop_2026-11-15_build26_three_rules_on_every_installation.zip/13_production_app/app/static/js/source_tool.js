// The tool that exported the recording, as each analysis keeps it (project.source_tool, shown by its name: source_tool_name).
// (owner, 2026-11-15: "are these things really needed? ... if it is looking at the column names ... if that is going to help, then
// it's good ... Otherwise it is no need") The start page no longer asks which tool exported the recording: the start route recognises
// it from the files' own column names, and "Check" on the start card says per file what was recognised (agents.js, checkFolder).
// This file only shows that one line with every analysis: in the list of analyses and under the name of an open one.
// A file of its own, loaded after agents.js; with a server from before the change the same fields are there, so it works with both.
"use strict";
(function () {
  const main = document.getElementById("main");
  if (!main) return;
  const NOT_KNOWN = "another_tool";       // the stored value for files that match no column list of the application (source_tools.ANOTHER)
  const h = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  // the one plain line for an analysis (bold: the tool's name)
  function toolLine(p, bold) {
    if (p.source_tool === NOT_KNOWN) return "recognised from the files: no tool the application has a column list for (the agents learn the columns from the files themselves)";
    if (p.source_tool && p.source_tool_name) return "recognised from the files: an export of " + (bold ? `<b>${h(p.source_tool_name)}</b>` : h(p.source_tool_name));
    return "the tool was not recorded for this analysis: each file's own column names say it";
  }
  function names() {
    const projects = typeof S !== "undefined" && S && S.state && Array.isArray(S.state.projects) ? S.state.projects : null;
    if (!projects) return;
    main.querySelectorAll(".proj").forEach(row => {
      const a = row.querySelector("a[data-open]"), meta = row.querySelector(".meta");
      const p = a && projects.find(x => String(x.id) === String(a.dataset.open));
      if (!meta || !p || !p.source_tool || meta.querySelector(".st-of")) return;
      meta.insertAdjacentHTML("beforeend", `<span class="st-of"> · ${toolLine(p, false)}</span>`);
    });
    const m = /^#\/p\/(\d+)(?:\/(?!errors)[^/]*)?\/?$/.exec(location.hash);
    const meta = m && main.querySelector(".phead .meta"), p = m && projects.find(x => String(x.id) === m[1]);
    if (!meta || !p || meta.querySelector(".st-of")) return;
    meta.insertAdjacentHTML("beforeend", `<span class="st-of"> · ${toolLine(p, true)}</span>`);
  }
  new MutationObserver(names).observe(main, { childList: true, subtree: true });
  names();
})();
