/* The terminal agent, on every page of the application.

   (owner, 2026-11-14: "each and every page should have communication with the terminal agent because the agent families
   that has been implemented are limited or not having such capacity as like full harness like opencode")

   The agent families answer one question from what the program hands them. The terminal agent (the opencode program in a
   terminal at the backend) can open files, search folders, run small Python programs and write a CSV. This script puts
   one button on the page and one panel: the question goes to the backend's held terminal session, the panel shows what
   the agent is doing while it works, and the conversation is there again the next time.

   Which session: the analysis the page shows; else the analysis the recording on the page belongs to; else the session of
   the application (start page, Settings, rules library, ...). The backend decides (agentic/investigate.place_for).

   A review card of a family agent (owner, 2026-11-15: "make a connection between your terminal code and ... that open
   code one"): a button on the card ([data-terminal-card="<review number>"], drawn by the flow page) opens this panel for
   the card's analysis with the card attached. Only the card's number is sent with the question (page.review): the backend
   reads the card from its own records and gives it to the agent as a file. Nothing is asked by itself and no question is
   written for the admin. An answer about a card can be put into the card's own comment box; nothing is sent by that.

   A folder before an analysis exists (owner, 2026-11-15: "the status must say there is no CSV; then there should be an agent
   communication between the terminal agent and here ... The folder might contain not only ETL files but XML files"):
   openFolder(path) opens this panel for one folder given on the start page. Its session is kept per folder by the backend
   (agentic/investigate.folder_place). The agent's CSV files can be put into that folder, one press per file.

   It uses no helper of any page, so the same file is loaded by every page. */
(function () {
  if (window.F2TTerminal) return;
  const T = { open: false, timer: null, draft: "", pid: null, data: null, card: null, note: "", folder: null };      // folder: the path given on the start page, when the panel is open for it      // card: { review, label, project } attached to the next question
  const esc = v => String(v == null ? "" : v).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const el = id => document.getElementById(id);
  const ago = s => s < 60 ? `${s} s` : `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, "0")} s`;
  const num = n => n == null ? "-" : Number(n).toLocaleString("en-US");
  // (2026-11-15) a text that comes from somewhere else (the server's reason, the terminal program's message) and is followed by a sentence
  // of the panel, or ends a line of it: sentence() gives it its full stop when it has none, so two texts never run together
  // ("...choose another in Settings The terminal agent works..."); inner() takes the full stop off a text the panel closes itself
  // (inside brackets, or before its own full stop), so none is written twice.
  const sentence = t => { const s = String(t == null ? "" : t).trim(); return !s || /[.!?…][)"'”’\]]*$/.test(s) ? s : s + "."; };
  const inner = t => String(t == null ? "" : t).trim().replace(/[.\s]+$/, "");

  // ---- where the admin is
  function pagePid() {
    if (T.pid) return T.pid;
    try { if (typeof sidePid === "function") return sidePid() || null; } catch (e) { /* not the flow page */ }
    return null;
  }
  function pageUpload() {
    try { const q = new URLSearchParams(location.search).get("upload"); if (q) return q; } catch (e) { /* old browser */ }
    const m = /up-\d{8}-\d{6}-[0-9a-f]{4}/.exec(location.href);
    return m ? m[0] : null;
  }
  function pageContext() {
    let heading = "", item = "";
    for (const h of document.querySelectorAll("h1, h2")) {
      if (h.closest("#ta-panel") || !h.offsetParent) continue;
      heading = (h.innerText || "").trim(); if (heading) break;
    }
    try { if (typeof sidePage === "function") { const p = sidePage() || {}; item = [p.title, p.item].filter(Boolean).join(" · "); } } catch (e) { /* not the flow page */ }
    let finding = "";
    try { finding = new URLSearchParams(location.search).get("finding") || ""; } catch (e) { /* old browser */ }
    return { path: location.pathname, address: location.pathname + location.search + location.hash, title: document.title, heading, upload: pageUpload() || "", finding, item };
  }
  const placeQuery = () => { const q = new URLSearchParams(); if (T.folder) { q.set("folder", T.folder); return q.toString(); } const pid = pagePid(), up = pageUpload(); if (pid) q.set("pid", pid); else if (up) q.set("upload", up); return q.toString(); };
  const placeBody = more => { const b = Object.assign({}, more || {}); if (T.folder) { b.folder = T.folder; return b; } const pid = pagePid(), up = pageUpload(); if (pid) b.pid = pid; else if (up) b.upload = up; return b; };
  function adminName() { try { return localStorage.getItem("agents.admin") || ""; } catch (e) { return ""; } }

  async function call(method, url, body) {
    const r = await fetch(url, { method, headers: body ? { "Content-Type": "application/json" } : {}, body: body ? JSON.stringify(body) : undefined });
    let d = null;
    try { d = await r.json(); } catch (e) { d = null; }
    if (!r.ok) throw new Error((d && d.error) || `the application answered ${r.status}`);
    return d;
  }

  // ---- the look: its own colours, light or dark by the page it sits on
  function css() {
    if (el("ta-style")) return;
    const s = document.createElement("style"); s.id = "ta-style";
    s.textContent = `
.ta-root{--ta-bg:#ffffff;--ta-fg:#1a2028;--ta-muted:#5a6572;--ta-line:#d3d9e0;--ta-soft:#f3f5f8;--ta-accent:#1f5fbf;--ta-on:#ffffff;--ta-err:#b3261e;font:14px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--ta-fg)}
.ta-root.ta-dark{--ta-bg:#161b22;--ta-fg:#e6eaf0;--ta-muted:#9aa5b1;--ta-line:#343c47;--ta-soft:#1f2630;--ta-accent:#6ea8ff;--ta-on:#0d1117;--ta-err:#ff8a80}
#ta-btn{position:fixed;right:max(16px,env(safe-area-inset-right,0px));bottom:max(16px,env(safe-area-inset-bottom,0px));z-index:70;display:flex;gap:8px;align-items:center;padding:10px 14px;border-radius:999px;border:1px solid var(--ta-line);background:var(--ta-bg);color:var(--ta-fg);font:inherit;font-weight:600;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.18)}
#ta-btn:hover{border-color:var(--ta-accent)}
#ta-btn .dot{width:8px;height:8px;border-radius:50%;background:var(--ta-muted)}
#ta-btn.busy .dot{background:var(--ta-accent);animation:ta-pulse 1.2s infinite}
@keyframes ta-pulse{50%{opacity:.25}}
@media (prefers-reduced-motion: reduce){#ta-btn.busy .dot{animation:none}}
#ta-scrim{position:fixed;inset:0;background:rgba(8,14,20,.45);z-index:80}
#ta-panel{position:fixed;top:0;right:0;bottom:0;width:min(640px,100vw);z-index:81;background:var(--ta-bg);border-left:1px solid var(--ta-line);display:flex;flex-direction:column;box-shadow:-8px 0 24px rgba(0,0,0,.2)}
#ta-panel .ta-head{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:14px 16px;border-bottom:1px solid var(--ta-line)}
#ta-panel h2{margin:0;font-size:17px;color:var(--ta-fg)}
#ta-panel h3{margin:16px 0 4px;font-size:14px;color:var(--ta-fg)}
#ta-body{padding:12px 16px 20px;overflow:auto;flex:1;min-height:0}
#ta-panel p{margin:0 0 8px}
#ta-panel .ta-small{font-size:12.5px}
#ta-panel .ta-muted{color:var(--ta-muted)}
#ta-panel .ta-err{color:var(--ta-err)}
#ta-panel .ta-why{font-size:12.5px;color:var(--ta-muted);margin:2px 0 6px}
#ta-panel label{display:block;font-weight:600;margin-top:12px}
#ta-panel textarea{width:100%;box-sizing:border-box;margin-top:4px;padding:8px 10px;border:1px solid var(--ta-line);border-radius:8px;background:var(--ta-bg);color:var(--ta-fg);font:inherit;resize:vertical}
#ta-panel .ta-b{padding:7px 12px;border-radius:8px;border:1px solid var(--ta-line);background:var(--ta-soft);color:var(--ta-fg);font:inherit;cursor:pointer;text-decoration:none;display:inline-block}
#ta-panel .ta-b.pri{background:var(--ta-accent);border-color:var(--ta-accent);color:var(--ta-on);font-weight:600}
#ta-panel .ta-b:disabled{opacity:.5;cursor:default}
#ta-panel .ta-b.sm{padding:4px 9px;font-size:12.5px}
#ta-panel .ta-acts{display:flex;gap:8px;justify-content:flex-end;align-items:center;flex-wrap:wrap;margin-top:8px}
#ta-panel .ta-card{margin:12px 0 0;padding:8px 10px;border:1px solid var(--ta-accent);border-radius:8px;display:flex;gap:8px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;overflow-wrap:anywhere}
#ta-panel .ta-turn{margin:12px 0;padding:10px 12px;border:1px solid var(--ta-line);border-radius:10px}
#ta-panel .ta-q{white-space:pre-wrap;font-weight:600;margin:4px 0 8px;overflow-wrap:anywhere}
#ta-panel .ta-a{white-space:pre-wrap;overflow-wrap:anywhere}
#ta-panel .ta-work{margin:12px 0;padding:10px 12px;border:1px solid var(--ta-accent);border-radius:10px}
#ta-panel ol{margin:4px 0 0 18px;padding:0;max-height:180px;overflow:auto}
#ta-panel .ta-tbl{overflow-x:auto}
#ta-panel table{border-collapse:collapse;width:100%}
#ta-panel th,#ta-panel td{text-align:left;padding:5px 8px;border-bottom:1px solid var(--ta-line);vertical-align:top}
#ta-panel code{background:var(--ta-soft);padding:1px 4px;border-radius:4px;overflow-wrap:anywhere}`;
    document.head.appendChild(s);
  }
  function isDark() {
    const m = /rgba?\(([^)]+)\)/.exec(getComputedStyle(document.body).backgroundColor || "");
    if (m) {
      const p = m[1].split(",").map(Number);
      if (p.length < 4 || p[3] > 0.1) return (0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]) < 110;
    }
    return !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  }
  const paint = node => node.classList.toggle("ta-dark", isDark());

  // ---- the panel
  // the comment box of a review card, when that card is on the screen now (the flow page draws it as textarea #cm<review number>)
  function cardBox(review) {
    const c = document.getElementById("cm" + review);
    return c && c.tagName === "TEXTAREA" && !c.disabled && !c.closest("#ta-panel") && c.closest(`[data-review="${review}"]`) ? c : null;
  }
  function turnHtml(t) {
    const put = t.ok && t.card && cardBox(t.card.review)
      ? `<div class="ta-acts" style="justify-content:flex-start"><button type="button" class="ta-b sm" data-ta-put="${esc(t.n)}" title="writes this answer's text into the comment box of the card on this page, after what is already there; you can change it there; nothing is sent and nothing is approved by this">Put this answer into my comment on the card</button><span class="ta-small" id="ta-put-${esc(t.n)}"></span></div>` : "";
    return `<div class="ta-turn">
      <div class="ta-small ta-muted">Question ${esc(t.n)} · ${esc(t.at || "")}${t.seconds != null ? " · answered in " + esc(ago(Math.round(t.seconds))) : ""}${t.page ? " · asked from: " + esc(t.page.replace(/^Page: /, "").replace(/\.$/, "")) : ""}</div>
      ${t.card ? `<div class="ta-small ta-muted">About the card: ${esc(t.card.label)} (review number ${esc(t.card.review)})</div>` : ""}
      <div class="ta-q">${esc(t.asked)}</div>
      ${t.ok ? `<div class="ta-a">${esc(t.answered)}</div>${put}` : `<div class="ta-err">Not answered: ${esc(sentence(t.problem || "no reason was given"))}</div>`}</div>`;
  }
  // the answer of question n goes into the card's own comment box, for the admin to read and change; nothing is sent
  function putAnswer(n) {
    const t = ((T.data || {}).conversation || []).find(x => String(x.n) === String(n)), msg = el("ta-put-" + n);
    const box = t && t.card ? cardBox(t.card.review) : null;
    if (!box) { if (msg) { msg.className = "ta-small ta-err"; msg.textContent = "The card is not on the screen any more: open the page that shows it, then press again."; } return; }
    box.value = (box.value.trim() ? box.value.replace(/\s+$/, "") + "\n\n" : "") + String(t.answered || "");
    box.dispatchEvent(new Event("input", { bubbles: true }));
    try { box.scrollIntoView({ block: "center" }); } catch (e) { /* old browser */ }
    if (msg) { msg.className = "ta-small"; msg.textContent = "Written into the comment box of the card. Nothing was sent and nothing was approved: close this panel, read it there, change it as you wish, then use the card's own buttons."; }
  }
  function view(d) {
    const s = d.session, run = d.running, an = d.place === "analysis", fo = d.place === "folder";
    const stale = !!T.folder && !fo;        // the server still runs the code from before the folder place: it answered for another place
    const place = stale
      ? `<p class="ta-err">The application has not been started again since the terminal agent for a folder was added, so it cannot answer about the folder ${esc(T.folder)} yet. Asking is switched off here, so that no question goes to another session.</p>`
      : fo
      ? `<p class="ta-small ta-muted">This page asks about the folder <code>${esc(d.folder_path || T.folder)}</code>, before an analysis exists. Your questions go to this folder's own terminal session: when the same folder is given again, the conversation is here again. The agent may open every file of the folder to tell you what each file is and how it can become a CSV table (the agent families read CSV tables only). It writes only in a working folder of its own; it is told never to change the folder's files, and the opencode program does not let its own tools write there, but a Python program it starts is not held back by those permissions. A table it writes reaches the folder only when you press “Put this CSV file into the folder”.</p>`
      : an
      ? `<p class="ta-small ta-muted">This page belongs to analysis ${esc(d.project)}${d.analysis_name ? " (" + esc(d.analysis_name) + ")" : ""}. Your questions go to that analysis's own terminal session, the same one from every page of the analysis. The agent reads the data dictionaries and the CSV files of the analysis and, when the tree was built, the tree; it runs small Python programs to count and compare, and it can write a new CSV file. It cannot change the data files.</p>`
      : `<p class="ta-small ta-muted">This page shows no single analysis, so your questions go to the application's terminal session. The agent there reads the rules library, the stored data dictionaries, the joining strategies and the documents of the application. For a question about the data of one analysis, open that analysis and ask from there.</p>`;
    const head = !d.ready
      ? `<p class="ta-err">${esc(sentence(d.problem || "The terminal program is not ready."))} The terminal agent works through the opencode program at the backend; its model is chosen in Settings, under “opencode in a terminal”.</p>`
      : `<p class="ta-small ta-muted">Session “${esc(d.name)}” · model ${esc(d.model || "")}${s ? ` · ${esc(num(s.turns))} question${s.turns === 1 ? "" : "s"} so far · it holds ${esc(num(s.holds_tokens))} tokens of what the model can read (a token is about 2 to 4 characters) · opencode's number for it: ${esc(s.terminal_id || "")}` : " · no question asked yet: the first one starts the session"}. Every question continues this same session, also after the application was started again.</p>`;
    const earlier = (d.earlier_sessions || []).length ? `<p class="ta-small ta-muted">Earlier parts of this conversation, kept to read: ${d.earlier_sessions.map(x => `${esc(x.name)} (${esc(num(x.turns))} question${x.turns === 1 ? "" : "s"}; closed: ${esc(inner(x.why_closed) || "no reason was kept")})`).join("; ")}.</p>` : "";
    const status = run ? `<div class="ta-work">
        <div><b>Working</b> for ${esc(ago(run.seconds))} on: <span style="white-space:pre-wrap">${esc(run.question)}</span></div>
        ${run.card ? `<div class="ta-small ta-muted">About the card: ${esc(run.card.label)} (review number ${esc(run.card.review)})</div>` : ""}
        <div class="ta-small ta-muted" style="margin-top:6px">What it is doing in the terminal, newest last:</div>
        <ol class="ta-small" id="ta-lines">${(run.lines || []).map(l => `<li>${esc(l.text)}</li>`).join("") || "<li>starting the terminal program…</li>"}</ol>
        <div style="margin-top:8px"><button type="button" class="ta-b sm" id="ta-stop">Stop this question</button></div></div>` : "";
    const err = !run && d.last_error ? `<p class="ta-err">The last question ended without an answer: ${esc(sentence(d.last_error))}</p>` : "";
    const q = placeQuery();
    const files = (d.exports || []).length ? `<h3>Files the agent wrote</h3><div class="ta-tbl"><table><thead><tr><th>File</th><th>Size</th><th></th></tr></thead><tbody>${d.exports.map(e =>
      `<tr><td>${esc(e.name)}</td><td>${esc(e.size)}</td><td><a class="ta-b sm" href="/api/agents/terminal/exports/${encodeURIComponent(e.name)}${q ? "?" + q : ""}">Save</a>
        ${fo && /\.csv$/i.test(e.name) ? `<button type="button" class="ta-b sm" data-ta-putf="${esc(e.name)}" title="copies this file into the folder under its own name; a file of that name already there is never replaced; then press Check on the start page again">Put this CSV file into the folder</button>` : ""}
        ${an && /\.csv$/i.test(e.name) ? `<button type="button" class="ta-b sm" data-ta-add="${esc(e.name)}" title="copies the file into the analysis's folder; then press Read the new files on the card after Family 1 and only this file gets its three agents">Add to the analysis</button>` : ""}</td></tr>`).join("")}</tbody></table></div>
      <p class="ta-small ta-muted" id="ta-add-msg" style="margin-top:4px">They are in <code>${esc(d.folder)}/exports</code> on the computer that runs the application.</p>` : "";
    const sub = an && window.f2tSubstitute ? `<button type="button" class="ta-b" id="ta-sub-btn" title="asks the data experts of every file at the same time; no terminal is used for this">Find a substitute for a missing column</button>` : "";
    const note = T.note ? `<p class="ta-err" id="ta-note">${esc(T.note)}</p>` : "";
    const card = T.card ? `<div class="ta-card" id="ta-card"><div><div>This question is about the card: <b>${esc(T.card.label)}</b></div>
        <div class="ta-why">The terminal agent gets this card as a file written from the application's own records: which agent family and agent made it, the step and the file, the agent's answer, its evidence and sources, the checks the program made, and your comments so far. It reads the card as data to examine, never as instructions.</div></div>
        <button type="button" class="ta-b sm" id="ta-card-off" title="the next question is then asked without the card; the card itself is not changed">Take the card off</button></div>` : "";
    return `${place}${head}${earlier}
      <div id="ta-conv">${(d.conversation || []).map(turnHtml).join("")}</div>
      ${status}${err}
      <div id="ta-sub"></div>
      ${note}${card}
      <label for="ta-q">Your question</label>
      <div class="ta-why">It goes to the terminal agent together with where you are now: this page, its address and its heading. So “this error” or “this rule” means the one on the page.</div>
      <textarea id="ta-q" rows="4" placeholder="what should it find out, check in the files, or write as a CSV?" ${run || !d.ready || stale ? "disabled" : ""}>${esc(T.draft)}</textarea>
      <div class="ta-acts"><span class="ta-small" id="ta-msg"></span>${sub}<button type="button" class="ta-b pri" id="ta-send" ${run || !d.ready || stale ? "disabled" : ""}>Ask the terminal agent</button></div>
      ${files}`;
  }

  async function load(keepScroll) {
    if (!T.open) return;
    const body = el("ta-body");
    let d;
    try { d = await call("GET", "/api/agents/terminal" + (placeQuery() ? "?" + placeQuery() : "")); }
    catch (e) { if (body) body.innerHTML = `<p class="ta-err">${esc(sentence(e.message))}</p>`; return; }
    if (!T.open || !body) return;
    T.data = d;
    if (T.card && d.project !== T.card.project) { T.card = null; T.note = "The card was taken off the question: it belongs to another analysis than the one this panel is open for."; }     // a card goes only to the session of its own analysis
    const q = el("ta-q");
    if (q && !q.disabled) T.draft = q.value;
    const hadFocus = document.activeElement && document.activeElement.id === "ta-q", caret = hadFocus ? q.selectionStart : null;
    const linesEl = el("ta-lines"), atEnd = !linesEl || linesEl.scrollTop + linesEl.clientHeight >= linesEl.scrollHeight - 8, top = body.scrollTop;
    const sub = el("ta-sub"), subKeep = sub && sub.childNodes.length ? sub : null;
    body.innerHTML = view(d);
    if (subKeep) el("ta-sub").replaceWith(subKeep);
    if (keepScroll) body.scrollTop = top;
    const l2 = el("ta-lines"); if (l2 && atEnd) l2.scrollTop = l2.scrollHeight;
    const q2 = el("ta-q");
    if (q2) {
      q2.addEventListener("keydown", e => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); send(); } });
      if (hadFocus && !q2.disabled) { q2.focus(); try { q2.setSelectionRange(caret, caret); } catch (e) { /* not a text field */ } }
    }
    if (el("ta-send")) el("ta-send").onclick = send;
    if (el("ta-card-off")) el("ta-card-off").onclick = () => { T.card = null; load(true); };
    body.querySelectorAll("[data-ta-put]").forEach(b => b.onclick = () => putAnswer(b.dataset.taPut));
    if (el("ta-stop")) el("ta-stop").onclick = async () => { const m = el("ta-msg"); try { await call("POST", "/api/agents/terminal/stop", placeBody()); if (m) m.textContent = "stopping…"; } catch (e) { if (m) m.innerHTML = `<span class="ta-err">${esc(sentence(e.message))}</span>`; } };
    if (el("ta-sub-btn")) el("ta-sub-btn").onclick = () => { const m = el("ta-sub"); if (!m.childNodes.length) window.f2tSubstitute(d.project, m); m.scrollIntoView({ block: "nearest" }); };
    body.querySelectorAll("[data-ta-putf]").forEach(b => b.onclick = async () => {
      const msg = el("ta-add-msg");
      try { const r = await call("POST", `/api/agents/terminal/exports/${encodeURIComponent(b.dataset.taPutf)}/put`, placeBody()); msg.className = "ta-small"; msg.textContent = `Copied to ${r.to}. Next: ${sentence(r.next)}`; }
      catch (e) { msg.className = "ta-small ta-err"; msg.textContent = sentence(e.message); }
    });
    document.querySelectorAll("[data-ta-add]").forEach(b => b.onclick = async () => {
      const msg = el("ta-add-msg");
      try { const r = await call("POST", `/api/agents/terminal/exports/${encodeURIComponent(b.dataset.taAdd)}/add`, placeBody()); msg.className = "ta-small"; msg.textContent = `Copied to ${r.to}. Next: ${sentence(r.next)}`; }
      catch (e) { msg.className = "ta-small ta-err"; msg.textContent = sentence(e.message); }
    });
    busy(!!d.running);
    clearTimeout(T.timer);
    if (d.running) T.timer = setTimeout(() => load(true), 2000);
  }

  async function send() {
    const q = el("ta-q").value.trim(), msg = el("ta-msg");
    if (!q) { msg.innerHTML = `<span class="ta-err">write the question first</span>`; return; }
    el("ta-send").disabled = true; msg.textContent = "starting…";
    try {
      const page = pageContext();
      if (T.card) page.review = T.card.review;          // the number only: the backend reads the card from its own records
      await call("POST", "/api/agents/terminal", placeBody({ question: q, admin: adminName(), page }));
      T.draft = ""; T.note = ""; el("ta-q").value = "";
      await load(false);
      const b = el("ta-body"); if (b) b.scrollTop = b.scrollHeight;
    } catch (e) { msg.innerHTML = `<span class="ta-err">${esc(sentence(e.message))}</span>`; el("ta-send").disabled = false; }
  }

  function busy(on) { const b = el("ta-btn"); if (b) b.classList.toggle("busy", on); }

  function close() {
    const q = el("ta-q"); if (q && !q.disabled) T.draft = q.value;
    T.open = false; clearTimeout(T.timer);
    for (const id of ["ta-panel", "ta-scrim"]) { const n = el(id); if (n) n.remove(); }
    const b = el("ta-btn") || el("inv-btn"); if (b) b.focus();
  }

  function open(pid) {
    const want = pid ? Number(pid) || null : null;
    if (want !== T.pid || T.folder) { T.draft = ""; T.pid = want; T.folder = null; }
    T.note = "";
    return show();
  }
  // the panel for the analysis a review card belongs to, with that card attached to the next question. Nothing is asked
  // and no question is written: the admin writes it. pid may be left out: the backend knows the card's analysis.
  async function openCard(pid, review) {
    T.note = "";
    try {
      const q = new URLSearchParams({ review: String(review == null ? "" : review) }); if (pid) q.set("pid", pid);
      const c = await call("GET", "/api/agents/terminal/card?" + q.toString());
      T.card = { review: c.review, label: c.label, project: c.project };
      pid = c.project;
    } catch (e) { T.card = null; T.note = `The card could not be attached: ${sentence(e.message)}`; }
    const want = pid ? Number(pid) || null : null;
    if (want !== T.pid || T.folder) { T.draft = ""; T.pid = want; T.folder = null; }
    show();
  }
  // the panel for one folder given on the start page, before an analysis exists: empty question box, nothing asked
  function openFolder(folderPath) {
    const f = String(folderPath == null ? "" : folderPath).trim();
    if (!f) return;
    if (f !== T.folder) { T.draft = ""; T.folder = f; }
    T.pid = null; T.card = null; T.note = "";
    show();
  }
  function show() {
    if (T.open) { load(false); return; }
    css();
    T.open = true;
    const scrim = document.createElement("div"); scrim.id = "ta-scrim"; scrim.onclick = close;
    const panel = document.createElement("aside"); panel.id = "ta-panel"; panel.className = "ta-root";
    panel.setAttribute("role", "dialog"); panel.setAttribute("aria-label", "Terminal agent");
    panel.innerHTML = `<div class="ta-head"><h2>Terminal agent</h2><button type="button" class="ta-b sm" id="ta-close">Close</button></div><div id="ta-body"><p class="ta-muted">reading…</p></div>`;
    paint(panel);
    document.body.appendChild(scrim); document.body.appendChild(panel);
    el("ta-close").onclick = close;
    load(false);
  }
  document.addEventListener("keydown", e => { if (e.key === "Escape" && T.open) close(); });

  // ---- the button: the flow page has one in its top bar (#inv-btn); every other page gets one at the lower right corner
  function button() {
    css();
    const top = el("inv-btn");
    if (top) {
      top.hidden = false;
      top.title = "the terminal agent: it can open the files, run small programs and write a CSV; on a page of an analysis it works on that analysis";
      top.addEventListener("click", () => open(null));
      return;
    }
    if (el("ta-btn")) return;
    const b = document.createElement("button"); b.type = "button"; b.id = "ta-btn"; b.className = "ta-root";
    b.title = "ask the terminal agent at the backend: it can open the files, run small programs and write a CSV";
    b.innerHTML = `<span class="dot" aria-hidden="true"></span>Terminal agent`;
    paint(b);
    b.addEventListener("click", () => open(null));
    document.body.appendChild(b);
  }
  // a button of the flow page that names its analysis ("Investigate first" on the card after Family 1)
  document.addEventListener("click", e => { const b = e.target.closest && e.target.closest("[data-investigate]"); if (b) open(Number(b.dataset.investigate) || null); });

  // a button on a review card of the flow page: "Ask the terminal agent about this card"
  document.addEventListener("click", e => { const b = e.target.closest && e.target.closest("[data-terminal-card]"); if (b) { e.preventDefault(); openCard(null, b.dataset.terminalCard); } });

  window.F2TTerminal = { open, close, context: pageContext, openCard, openFolder };
  window.openInvestigation = pid => open(pid);          // the name the flow page used before
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", button); else button();
})();
