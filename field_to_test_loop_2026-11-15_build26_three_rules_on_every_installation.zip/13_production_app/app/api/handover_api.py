"""Hand over to the validation suite (statement S8, item B7; 2026-11-14): the approved tests as one package, and their results back.

  GET  /api/handover/tests            every test of the application's test folders with its approval state (nothing is chosen in advance)
  POST /api/handover/package          {"tests": [names as the list shows them], "name": who builds it} -> the zip package
                                      (only approved tests whose file is unchanged since the approval; never "all")
  GET  /api/handover/packages         the packages built so far
  POST /api/handover/results          a JUnit XML result file made from a package: a form with the file in "file" and who brings it in "name",
                                      or the file as the request's body with ?name=<who>
  GET  /api/handover/results          what came back, per test (?test=<name> for one test)

Every wrong input is answered with HTTP 400 and one plain sentence in "error". The work is in nvme_hier/handover.py.
"""
import io
import sqlite3

from flask import Blueprint, jsonify, request, send_file

from . import svc
from nvme_hier import handover as HO

bp = Blueprint("handover", __name__)

BUSY = "The application's database is busy or cannot be written just now. Nothing was recorded: try again in a moment."


def _no(words, code=400):
    return jsonify({"error": words}), code


def _body():
    """The request's JSON as named fields, or None when it is not that."""
    try:
        b = request.get_json(force=True, silent=True)
    except Exception:
        b = None
    return b if isinstance(b, dict) else None


@bp.get("/api/handover/tests")
def handover_tests():
    try:
        return jsonify(HO.list_tests(svc().root))
    except HO.HandoverError as e:
        return _no(str(e))
    except OSError:
        return _no("The application's test folder cannot be read just now.", 503)


@bp.post("/api/handover/package")
def handover_package():
    body = _body()
    if body is None:
        return _no("Send the selection as named fields: \"tests\" (the list of test names) and \"name\" (who builds the package).")
    try:
        made = HO.build_package(svc().root, body.get("tests"), body.get("name"))
    except HO.HandoverError as e:
        return _no(str(e))
    except sqlite3.Error:
        return _no(BUSY, 503)
    except OSError:
        return _no("A test file could not be read while the package was being built. No package was built.", 503)
    resp = send_file(io.BytesIO(made["zip"]), mimetype="application/zip", as_attachment=True, download_name=made["file_name"])
    resp.headers["X-Handover-Package"] = made["package_id"]
    resp.headers["X-Handover-Sha256"] = made["zip_sha256"]
    resp.headers["Cache-Control"] = "no-store"
    return resp


@bp.get("/api/handover/packages")
def handover_packages():
    try:
        return jsonify(HO.packages(svc().root))
    except sqlite3.Error:
        return _no(BUSY, 503)


def _limited(stream, limit):
    """At most limit + 1 bytes of an upload: enough to know it is too large without holding it."""
    out, left = [], limit + 1
    while left > 0:
        part = stream.read(min(left, 1 << 16))
        if not part:
            break
        out.append(part)
        left -= len(part)
    return b"".join(out)


@bp.post("/api/handover/results")
def handover_results_in():
    too_large = "The result file is larger than %d megabytes: a JUnit result file of a package is far smaller, so it is refused." % (HO.MAX_RESULT_BYTES >> 20)
    if request.content_length is not None and request.content_length > HO.MAX_RESULT_BYTES + (1 << 16):
        return _no(too_large)
    try:
        if (request.mimetype or "").startswith("multipart/"):
            f = request.files.get("file")
            if f is None:
                return _no("Give the JUnit XML result file in the form field \"file\".")
            data, who = _limited(f.stream, HO.MAX_RESULT_BYTES), request.form.get("name")
        else:
            data, who = _limited(request.stream, HO.MAX_RESULT_BYTES), request.args.get("name")
    except Exception:
        return _no("The result file could not be read from the request. Send it again.")
    if len(data) > HO.MAX_RESULT_BYTES:
        return _no(too_large)
    try:
        return jsonify(HO.read_results(svc().root, data, who))
    except HO.HandoverError as e:
        return _no(str(e))
    except sqlite3.Error:
        return _no(BUSY, 503)


@bp.get("/api/handover/results")
def handover_results():
    try:
        return jsonify(HO.results(svc().root, request.args.get("test")))
    except HO.HandoverError as e:
        return _no(str(e))
    except sqlite3.Error:
        return _no(BUSY, 503)
