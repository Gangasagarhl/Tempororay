"""NVMe-level hierarchy API: uploads of the five per-level exports, the load job, row browsing with filters.

An upload = one folder uploads/<upload id>/ holding meta.json (who, which trace, which device, when) and
hier.sqlite (the staged rows, one table per level, plus the tree links the builder fills in).
Only file paths are sent to the server (the files stay where they are), as for the stage-1 runs.
"""
import csv
import json
import os
import shutil
import subprocess
import pathlib
import re
import sqlite3
import threading
import time
import uuid

from flask import Blueprint, Response, jsonify, request, send_file

from . import svc, whole, NM, as_text, a_dict, dicts, wholes

import sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)
from nvme_hier import columns as C, loader as L, parse as P   # noqa: E402
from nvme_hier import names as NM_X   # noqa: E402  (command names for the exports)

bp = Blueprint("hier", __name__)
LEVELS = C.LEVEL_ORDER
TABLE = L.TABLE
FILTER_OPS = {"eq", "ne", "in", "contains", "gt", "lt", "ge", "le", "between", "blank", "notblank"}


def uploads_dir(s):
    d = os.path.join(s.root, "uploads")
    os.makedirs(d, exist_ok=True)
    return d


def upload_dir(s, uid):
    base = pathlib.Path(uploads_dir(s)).resolve()
    d = pathlib.Path(base, uid).resolve()
    if not d.is_relative_to(base) or d == base or not d.is_dir():
        return None
    return str(d)


def read_meta(d):
    p = os.path.join(d, "meta.json")
    if not os.path.exists(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            m = json.load(f)
        if isinstance(m, dict):
            return m
    except (OSError, ValueError):
        pass
    return {"upload_id": os.path.basename(d), "status": "failed", "error": "its record of the load (meta.json) cannot be read: load the recording again", "files": {}, "thresholds": {}}


def write_meta(d, meta):
    L.write_json_atomic(os.path.join(d, "meta.json"), meta, indent=1)


def db_of(d):
    return os.path.join(d, "hier.sqlite")


# Indexes the browsing endpoints need beyond what the loader creates (the loader, builder and rules modules are not
# touched here). Each statement is a no-op when the index exists; they run when an upload is opened and after the
# rules re-run (rules.apply recreates the finding table, which drops its indexes).
BROWSE_INDEXES = [
    # the rows of one parent. The tree build makes this index once the parents are written (2026-11-12, before: the
    # loader made it on the empty table); it stands here too so that a database the build did not finish still gets it
    "CREATE INDEX IF NOT EXISTS ix_%(t)s_parent ON %(t)s (parent_level, parent)",
    # relation alone (the "outside any command" list, the context packets of a parent)
    "CREATE INDEX IF NOT EXISTS ix_%(t)s_rel ON %(t)s (relation, parent_level, parent)",
    # findings by command and by severity+level (the per-level error check boxes, the defects list counts)
    "CREATE INDEX IF NOT EXISTS ix_finding_sev ON finding (severity, level, cmd_rowid)",
    "CREATE INDEX IF NOT EXISTS ix_finding_row ON finding (level, rowid, severity)",
]


def ensure_indexes(con, progress=None):
    """CREATE INDEX IF NOT EXISTS for the browsing queries, one index at a time with a progress line for each (an index
    on 8 million packets takes minutes: the page must never look frozen, 2026-11-03). The sort files go next to the
    database, never to /tmp (a RAM disk on some machines), and a large page cache is used while the indexes are built.
    Every index that exists already is skipped, so a load started again continues here from where it stopped."""
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    have = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='index'")}
    main_db = next((r[2] for r in con.execute("PRAGMA database_list") if r[1] == "main"), "")
    if main_db and main_db != ":memory:":
        con.execute("PRAGMA temp_store=FILE")
        con.execute("PRAGMA temp_store_directory='%s'" % os.path.dirname(main_db).replace("'", "''"))
    con.execute("PRAGMA cache_size=-%d" % L.CACHE_KB)
    todo = []
    for stmt in BROWSE_INDEXES:
        if "%(t)s" in stmt:
            todo += [stmt % {"t": t} for t in TABLE.values() if t in tables]
        elif "finding" in tables:
            todo.append(stmt)
    todo = [x for x in todo if re.search(r"EXISTS (\w+)", x).group(1) not in have]
    for i, stmt in enumerate(todo):
        name = re.search(r"EXISTS (\w+) ON (\w+)", stmt)
        if progress:
            progress("index for browsing", "index %d of %d: %s on the %s table" % (i + 1, len(todo), name.group(1), name.group(2)), i, len(todo))
        t0 = time.time()
        con.execute(stmt)
        con.commit()
        if progress:
            progress("index for browsing", "index %d of %d built in %.0f s" % (i + 1, len(todo), time.time() - t0), i + 1, len(todo))
    con.commit()


# ---------------------------------------------------------------------------------------------- the load job
def _db_bytes(d):
    p = db_of(d)
    return os.path.getsize(p) if os.path.exists(p) else 0


def run_hier_load(jid, params, mgr):
    """The load job, inside a guard that watches the memory and the disk: when one runs out the load stops by itself with the reason, instead of the application being killed."""
    d = params["upload_dir"]
    def _stopped(text):
        meta = read_meta(d) or {}
        meta["status"], meta["error"] = "interrupted", text
        write_meta(d, meta)
        return text
    sizes = sum(os.path.getsize(p) for p in params["files"].values() if p and os.path.isfile(p))
    with L.ROOM_LOCK:
        problem = L.room_problem(sizes, d, already=_db_bytes(d))
        if problem:
            raise RuntimeError(_stopped(problem))
        release = L.reserve(sizes, already=_db_bytes(d))
    guard = L.RoomGuard(d).start()
    guard.on_pause = lambda words: mgr.progress(jid, "waiting for room", words)
    L.give_way()
    try:
        return _run_hier_load(jid, params, mgr, guard)
    except L.BadFile as e:
        raise RuntimeError(_stopped(str(e))) from e
    except Exception as e:      # noqa: BLE001 - what the machine or the files caused is said in plain words; everything else goes up as it is
        text = None
        if guard.why or isinstance(e, L.NoRoom):
            text = (guard.why or str(e)) + " What was finished is kept: press Load again once there is room."
        elif isinstance(e, sqlite3.OperationalError) and any(w in str(e).lower() for w in ("full", "disk i/o")):
            text = "the disk filled up (%s). What was finished is kept: press Load again once there is room." % e
        elif isinstance(e, sqlite3.DatabaseError):
            text = "the database of this recording is damaged (%s). Load these files again as a new recording." % e
        elif isinstance(e, OSError):
            text = "a file could not be read: %s. Check the files, then press Load again." % e
        if text:
            raise RuntimeError(_stopped(text)) from e
        raise
    finally:
        guard.stop()
        release()


def _run_hier_load(jid, params, mgr, guard):
    d = params["upload_dir"]
    files = params["files"]
    done = {}

    sizes = {k: os.path.getsize(files[k]) for k in LEVELS if k in files and files[k] and os.path.exists(files[k])}
    total_bytes = max(1, sum(sizes.values()))
    bytes_before = {"n": 0}
    LOAD_SHARE = 82.0          # the load is most of the time; build 82-95, rules 95-99, browsing indexes 99-100

    class Cancelled(Exception):
        pass

    def progress(key, n, nbytes=None, note=None):
        guard.check()
        if mgr.cancelled(jid):
            raise Cancelled()
        b = bytes_before["n"] + min(nbytes or 0, sizes.get(key, 0))
        pct = round(LOAD_SHARE * b / total_bytes, 1)
        if note:                     # a pass that reads no new rows: the bar stays, the words say what it is doing
            mgr.progress(jid, "loading", "%s: %s" % (C.LEVEL_LABEL[key], note), pct)
            return
        mgr.progress(jid, "loading", "%s: %s rows read · %s of %s MB read" % (C.LEVEL_LABEL[key], "{:,}".format(n), "{:,}".format(b // 1000000), "{:,}".format(total_bytes // 1000000)),
                     pct, stats={"rows_" + key: n, "bytes_done": b, "bytes_total": total_bytes})
    reports = {}
    # ---- supervisor (owner's request 2026-11-03): a thread looks at the progress record every 30 s; when the row
    # counter has not moved for STALL_AFTER seconds the record says so, with the step and the time, and the page shows
    # "load again", which continues from the last finished file or stage. A long pass that is still moving is left alone.
    stall = {"stop": False}
    try:
        return _load_stages(jid, params, mgr, guard, stall, progress, reports, done, sizes, total_bytes, bytes_before, LOAD_SHARE, Cancelled, d, files)
    finally:
        stall["stop"] = True


def _load_stages(jid, params, mgr, guard, stall, progress, reports, done, sizes, total_bytes, bytes_before, LOAD_SHARE, Cancelled, d, files):
    STALL_AFTER = 600

    def supervisor():
        last_text, last_change = None, time.time()
        while not stall["stop"]:
            time.sleep(30)
            if stall["stop"]:
                break
            j = mgr.get(jid) or {}
            pr = j.get("progress") or {}
            text = "%s|%s|%s" % (pr.get("step"), pr.get("detail"), pr.get("pct"))
            if text != last_text:
                last_text, last_change = text, time.time()
                continue
            idle = int(time.time() - last_change)
            if idle >= STALL_AFTER and not str(pr.get("detail", "")).startswith("NO PROGRESS"):
                mgr.progress(jid, pr.get("step") or "loading", "NO PROGRESS for %d min at: %s. The step may be very long, or stuck; press \"load again\" to continue from the last finished stage." % (idle // 60, pr.get("detail") or ""), pr.get("pct"))
                last_text = None
    threading.Thread(target=supervisor, name=jid + "-supervisor", daemon=True).start()
    # ---- resume (2026-11-03): a load that was stopped (the server closed, the machine suspended) continues from the
    # last finished file or stage instead of starting over. meta["done_files"] records every file loaded completely
    # (its size, its change time, its rows); meta["stage_done"] records the build and the rules. A file whose record
    # matches and whose table holds that many rows is kept as it is.
    meta0 = read_meta(d) or {}
    done_files = dict(meta0.get("done_files") or {})
    stage_done = dict(meta0.get("stage_done") or {})
    with mgr.span(jid, "load the files", {"files": list(files)}):
        con = L.open_db(db_of(d))
        old_reports = {}
        try:
            row = con.execute("SELECT v FROM meta WHERE k='load_reports'").fetchone()
            old_reports = json.loads(row[0]) if row else {}
        except sqlite3.Error:
            old_reports = {}
        for key in LEVELS:
            if key in files and files[key]:
                rec = done_files.get(key) or {}
                try:
                    st_ = os.stat(files[key])
                    same = (rec.get("path") == files[key] and rec.get("size") == st_.st_size and abs((rec.get("mtime") or 0) - st_.st_mtime) < 1
                            and key in old_reports and con.execute("SELECT COUNT(*) FROM %s" % L.TABLE[key]).fetchone()[0] == rec.get("rows"))
                except (OSError, sqlite3.Error):
                    same = False
                if same:
                    reports[key] = old_reports[key]
                    bytes_before["n"] += sizes.get(key, 0)
                    done[key] = reports[key]["rows"]
                    mgr.progress(jid, "loading", "%s: already loaded before the interruption (%s rows), kept" % (C.LEVEL_LABEL[key], "{:,}".format(reports[key]["rows"])),
                                 round(LOAD_SHARE * bytes_before["n"] / total_bytes, 1))
                    mgr.event(jid, "%s: kept from the earlier load (%s rows)" % (C.LEVEL_LABEL[key], "{:,}".format(reports[key]["rows"])))
                    continue
                with mgr.span(jid, "load " + C.LEVEL_LABEL[key] + " file", {"path": files[key]}):
                    mgr.progress(jid, "loading", "%s: starting" % C.LEVEL_LABEL[key], round(LOAD_SHARE * bytes_before["n"] / total_bytes, 1))
                    try:
                        w = params.get("workers") or 0
                        L.WORKERS = None if not w else int(w)     # 0 = automatic (cores minus one, at most 8)
                        reports[key] = L.load_file(con, key, files[key], progress=progress)
                    except Cancelled:
                        con.close()
                        meta = read_meta(d) or {}
                        meta["status"] = "cancelled"
                        write_meta(d, meta)
                        raise RuntimeError("cancelled by the admin")
                    bytes_before["n"] += sizes.get(key, 0)
                    done[key] = reports[key]["rows"]
                    if reports[key].get("error"):
                        mgr.event(jid, "%s: not used: %s" % (C.LEVEL_LABEL[key], reports[key]["error"]))
                    else:
                        mgr.event(jid, "%s: %s rows, %d of %d named columns found, %d separator columns dropped" % (
                            C.LEVEL_LABEL[key], "{:,}".format(reports[key]["rows"]), reports[key]["found_named_columns"],
                            reports[key]["expected_named_columns"], reports[key]["separator_columns_dropped"]))
                    # checkpoint: this file is complete
                    L.set_meta(con, "load_reports", reports)
                    st_ = os.stat(files[key])
                    done_files[key] = {"path": files[key], "size": st_.st_size, "mtime": st_.st_mtime, "rows": reports[key]["rows"]}
                    stage_done = {}                  # a newly loaded file invalidates an earlier build and rules run
                    meta = read_meta(d) or {}
                    meta["done_files"] = done_files
                    meta["stage_done"] = stage_done
                    write_meta(d, meta)
        L.set_meta(con, "load_reports", reports)
        usable = [k for k in LEVELS if k in reports and not reports[k].get("error")]
        if not usable:
            con.close()
            raise L.BadFile("none of the files could be read as an analyzer's CSV export: %s" % "; ".join("%s: %s" % (C.LEVEL_LABEL[k], reports[k].get("error")) for k in reports))
        L.set_meta(con, "levels_present", usable)
        L.set_meta(con, "upload", {k: v for k, v in params.items() if k != "files"})
        con.close()
    row_counts = {k: v for k, v in done.items()}
    result = {"reports": reports, "levels_present": [k for k in LEVELS if k in reports and not reports[k].get("error")]}
    # the hierarchy build and the rules run here once those modules exist (builder.build, rules.apply)
    try:
        from nvme_hier import builder
    except ImportError:
        builder = None
    TOTAL_OF = {"packets": row_counts.get("packets", 0), "link": row_counts.get("link", 0), "split": row_counts.get("split", 0),
                "transactions": row_counts.get("nvme_transaction", 0), "nvme transactions": row_counts.get("nvme_transaction", 0),
                "NVMe transactions": row_counts.get("nvme_transaction", 0), "commands": row_counts.get("nvme_command", 0)}

    def frac_of(step, detail):
        """How far a pass is, from the row count in its detail text and the rows of the table it walks (0..0.99)."""
        m = re.search(r"([\d,]+)", detail or "") if not (detail or "").startswith("still working") else None
        if not m:
            return 0.0
        n = int(m.group(1).replace(",", ""))
        total = 0
        for word, tot in TOTAL_OF.items():
            if word in step or word in (detail or ""):
                total = max(total, tot)
        return min(0.99, n / total) if total else 0.0

    rate = {"t": time.time(), "n": 0}

    def with_rate(detail):
        m = re.search(r"([\d,]+)", detail or "") if not (detail or "").startswith("still working") else None
        if not m:
            return detail
        n = int(m.group(1).replace(",", "")); now = time.time()
        dt, dn = now - rate["t"], n - rate["n"]
        rate["t"], rate["n"] = now, n
        return "%s · %s rows/s · still working" % (detail, "{:,}".format(int(dn / dt))) if dt > 0 and dn > 0 else detail

    if builder is not None and not stage_done.get("build"):
        with mgr.span(jid, "build the hierarchy"):
            seen = []

            def bprog(step, detail, pct):
                guard.check()
                if step not in seen:
                    seen.append(step)
                    rate["t"], rate["n"] = time.time(), 0
                mgr.progress(jid, step, "%d%% of the tree · %s" % (pct, with_rate(detail)), round(82 + 13 * pct / 100.0, 1))
            mgr.progress(jid, "build the hierarchy", "starting", 82)
            result["build"] = builder.build(db_of(d), progress=bprog, settings=params.get("join_settings"))
            stage_done["build"] = True
            meta = read_meta(d) or {}; meta["stage_done"] = stage_done; meta.setdefault("result", {})["build"] = result["build"]; write_meta(d, meta)
    elif builder is not None:
        result["build"] = ((read_meta(d) or {}).get("result") or {}).get("build")
        mgr.progress(jid, "build the hierarchy", "already built before the interruption, kept", 95)
    try:
        from nvme_hier import rules
    except ImportError:
        rules = None
    if rules is not None and not stage_done.get("rules"):
        with mgr.span(jid, "apply the rules"):
            seen_r = []

            def rprog(step, detail):
                guard.check()
                if step not in seen_r:
                    seen_r.append(step)
                    rate["t"], rate["n"] = time.time(), 0
                mgr.progress(jid, step, with_rate(detail), round(95 + 4 * min(len(seen_r) - 1 + frac_of(step, detail), 8) / 8.0, 1))
            mgr.progress(jid, "apply the rules", "starting", 95)
            result["rules"] = rules.apply(db_of(d), params.get("thresholds") or {}, progress=rprog)
            stage_done["rules"] = True
            meta = read_meta(d) or {}; meta["stage_done"] = stage_done; meta.setdefault("result", {})["rules"] = result["rules"]; write_meta(d, meta)
    elif rules is not None:
        result["rules"] = ((read_meta(d) or {}).get("result") or {}).get("rules")
        mgr.progress(jid, "apply the rules", "already applied before the interruption, kept", 99)
    if not stage_done.get("index"):
        with mgr.span(jid, "index for browsing"):
            mgr.progress(jid, "index for browsing", "creating the browsing indexes (each one is reported as it is built)", 99)
            con = L.open_db(db_of(d))
            end_beat = L.heartbeat(con, lambda secs: None)
            try:
                ensure_indexes(con, progress=lambda step, detail, i, n: (guard.check(), mgr.progress(jid, step, detail, round(99 + (i / n if n else 1), 1))))
            finally:
                end_beat()
            con.close()
            stage_done["index"] = True
            meta = read_meta(d) or {}; meta["stage_done"] = stage_done; write_meta(d, meta)
    else:
        mgr.progress(jid, "index for browsing", "already built before the interruption, kept", 99.9)
    stall["stop"] = True
    mgr.progress(jid, "done", "loaded, built, rules applied", 100)
    meta = read_meta(d) or {}
    meta["status"] = "loaded"
    meta["result"] = result
    meta["loaded_at"] = time.time()
    write_meta(d, meta)
    return result


# ---------------------------------------------------------------------------------------------- endpoints
import model_env as _ME   # noqa: E402
ENV_FILE = _ME.ENV_FILE      # the Settings page's key file (tests point it at their own folder)


def _model_state(s):
    l = s.cfg.get("llm") or {}
    var = l.get("api_key_env") or "ANTHROPIC_API_KEY"
    ks = _ME.source(s.cfg, ENV_FILE)
    return {"backend": l.get("backend"), "model": l.get("model"), "base_url": l.get("base_url") or "", "api_key_env": var,
            "key_present": ks["present"], "key_end": ks["end"], "key_source": ks["source"], "env_file": ENV_FILE,
            "agents_model": ((s.cfg.get("agentic") or {}).get("model") or "") or l.get("model"),
            "api_calls": ((s.cfg.get("server") or {}).get("api_calls", True) is not False),
            "active": getattr(s.s2.llm, "name", "stand-in"), "locked": bool((s.cfg.get("server") or {}).get("lock_endpoint")),
            "retries": {"tries": 4, "first_pause_s": 2.0, "note": "transient failures are retried 4 times with pauses of 2, 4 and 8 seconds; a wrong key is reported at once"}}


@bp.get("/api/hier/model")
def model_get():
    """The model connection as the settings page shows it: where the calls go, which model, which environment
    variable holds the key (never the key itself), and whether a key is present."""
    return jsonify(_model_state(svc()))


@bp.put("/api/hier/model")
def model_put():
    """body: {base_url?, model?, api_key_env?, key?}. The key is written to the private environment file (mode 600,
    outside the project) and put into this process's environment; it is never stored in the config file."""
    s = svc()
    body = request.get_json(force=True) or {}
    from agentic import policy as _policy
    if not _policy.api_allowed(s.cfg):          # nothing of the Model connection is used: its URL, model and key are not taken
        return jsonify({"error": _policy.NOT_ALLOWED + ". The model is chosen in Settings, under opencode in a terminal."}), 403
    if (s.cfg.get("server") or {}).get("lock_endpoint") and any(k in body for k in ("base_url", "api_key_env", "key")):
        return jsonify({"error": "the model endpoint and key are locked by server.lock_endpoint: stop the service, edit the config and the environment file, start it again"}), 403
    for k in ("base_url", "model", "api_key_env", "key"):          # a control character in any of these cannot be stored or put in the environment
        if isinstance(body.get(k), str) and any(ord(c) < 32 for c in body[k].strip()):
            return jsonify({"error": "%s has a control character in it" % k}), 400
    if isinstance(body.get("api_key_env"), str) and body["api_key_env"].strip() and not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", body["api_key_env"].strip()):
        return jsonify({"error": "api_key_env must be the name of an environment variable"}), 400
    l = s.cfg.setdefault("llm", {})
    for k in ("base_url", "model", "api_key_env"):
        if k in body and body[k] is not None:
            l[k] = str(body[k]).strip()
    if "base_url" in body:
        l["base_url"] = _ME.normal_url(l.get("base_url"))
    if l.get("backend") in (None, "", "auto", "sdk", "cli"):
        l["backend"] = "http"
    key = as_text(body.get("key"), "key").strip()
    written = False
    if key:
        var = l.get("api_key_env") or "ANTHROPIC_API_KEY"
        os.environ[var] = key
        if var != "ANTHROPIC_API_KEY":
            os.environ["ANTHROPIC_API_KEY"] = key
        try:
            os.makedirs(os.path.dirname(ENV_FILE), exist_ok=True)
            lines = []
            if os.path.exists(ENV_FILE):
                lines = [ln for ln in open(ENV_FILE, encoding="utf-8").read().splitlines() if ln and not ln.startswith(var + "=")]
            lines.append("%s=%s" % (var, key))
            L.write_text_atomic(ENV_FILE, "\n".join(lines) + "\n", mode=0o600)        # all of it or none of it: a crash here must not lose the key
            written = True
        except OSError as e:
            return jsonify({"error": "the key could not be written to %s: %s" % (ENV_FILE, e)}), 500
    if l.get("base_url"):
        os.environ["ANTHROPIC_BASE_URL"] = l["base_url"]
    elif "base_url" in body:
        os.environ.pop("ANTHROPIC_BASE_URL", None)
    _ME.apply(s.cfg)
    from .config_api import save_config
    save_config(s.cfg)
    s.s2.reload_llm()
    eng = getattr(s, "agentic_engine", None)          # the agents follow the same connection at once (no restart)
    if eng is not None:
        eng.runner.http_model = l.get("model")
        eng.runner.model = ((s.cfg.get("agentic") or {}).get("model") or "") or l.get("model") or None
    st = _model_state(s)
    st["key_written_to_env_file"] = written
    return jsonify(st)


@bp.post("/api/hier/model/test")
def model_test():
    """The Settings page's "Save and test the connection" (owner, 2026-11-11: "a test in the settings itself, applicable to
    everything"): one small call through the model connection (stage 1 and 2, the error pages) and one through what runs the
    agents (Claude Code or the same connection), each reported in words: who answered, how long it took, or the error."""
    s = svc()
    out = _test_main(s)
    try:
        out["agents"] = _test_agents(s)
    except Exception as e:      # noqa: BLE001
        out["agents"] = {"ok": False, "words": "the agents could not be tested: %s" % str(e)[:200]}
    out["address"] = _address()
    if (s.cfg.get("llm") or {}).get("backend") == "opencode":
        out["address"] = "the opencode program in a terminal on this computer (the application itself calls no model address)"
    for part in (out, out["agents"]):
        if not part.get("ok"):
            part["hint"] = _hint(part.get("error") or part.get("words") or "")
    return jsonify(out)


def _address():
    return (os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com").rstrip("/") + "/v1/messages"


def _hint(err):
    """What an error of the connection test means, in words (owner, 2026-11-11: "it sent 402")."""
    e = str(err)
    for pat, words in ((r"HTTP 402", "payment required: the account behind this key has no credit left or its budget is used up; add credit or ask for a key with budget"),
                       (r"HTTP 401", "the key was refused: check that it is the whole key, for this address"),
                       (r"HTTP 403", "this key may not use this model or this address"),
                       (r"HTTP 404", "not found: give the base address only (for example https://gateway.company.com, without /v1) and the model name as your service calls it"),
                       (r"HTTP 400", "the service did not accept the request: often the model name, or a feature this address does not offer"),
                       (r"usage limit", "the model's service says its free use is used up for now: choose another model in the list, or try again later"),
                       (r"opencode program was not found", "install opencode on this computer (https://opencode.ai), then open Settings again"),
                       (r"does not offer the model|no model is chosen", "choose one of the models in the list and save"),
                       (r"HTTP 429|rate limit", "too many calls for this key at the moment: try again in a minute"),
                       (r"HTTP 5\d\d|HTTP 529|overloaded", "the service had a problem or is overloaded: try again later"),
                       (r"CERTIFICATE_VERIFY_FAILED|certificate", "this computer does not trust the address's certificate (often a company network): your IT team can give the certificate to install"),
                       (r"refused|timed out|timeout|getaddrinfo|Name or service not known|No route|unreachable|within \d+ s",
                        "the address cannot be reached from this computer: check the URL, the proxy or the firewall"),
                       (r"no key|no API key", "no key is saved: paste the key and press Save and test")):
        if re.search(pat, e, re.I):
            return words
    return ""


def _test_agents(s):
    import copy as _copy
    import tempfile as _tf
    from .agentic_api import engine as _engine
    from agentic import core as _core
    eng = _engine()
    r = eng.runner
    model = r.model or r.http_model or "its own default"
    prompt = 'Answer with only this JSON object: {"ok": "yes"}'
    t0 = time.time()
    if r.runtime == "standin":
        return {"ok": False, "runtime": "stand-in", "words": "the agents run on the stand-in (no model): choose Claude Code or Model connection above"}
    if r.runtime == "opencode":
        from agentic import terminal as _term
        _exe, facts, problem = r.opencode_ready()
        if problem:
            return {"ok": False, "runtime": "opencode", "words": problem}
        try:
            got = _term.app_turn(s.root, s.cfg, prompt, purpose="connection test", timeout=150)
        except Exception as e:      # noqa: BLE001
            return {"ok": False, "runtime": "opencode", "model": facts["name"], "seconds": round(time.time() - t0, 1),
                    "words": "opencode did not answer: %s" % str(e)[:240]}
        return {"ok": isinstance(got.get("answer"), dict), "runtime": "opencode", "model": facts["name"], "seconds": round(time.time() - t0, 1),
                "words": "opencode answered in a terminal with model %s; the session \"%s\" is kept with its question and answer" % (facts["name"], got["session"]["name"])}
    company = r.runtime == "claude-code" and _core.custom_url()
    if r.runtime == "claude-code" and not company:
        if not _core.AgentRunner.find_claude(r.claude_path):
            return {"ok": False, "runtime": "Claude Code", "words": "Claude Code is not installed on this computer: the agents use the model connection instead"}
        r2 = _copy.copy(r)
        r2.timeout = 90
        box = _tf.mkdtemp(prefix="f2t_test_")
        try:
            ans = r2._claude_code(prompt, box)
        except subprocess.TimeoutExpired:
            return {"ok": False, "runtime": "Claude Code", "model": model, "seconds": round(time.time() - t0, 1),
                    "words": "Claude Code did not answer within %d s: check the URL and the key above" % r2.timeout}
        except Exception as e:      # noqa: BLE001
            # Claude Code prints warnings first (lines with ⚠); the reason is in the other lines
            why = " ".join(ln.strip() for ln in str(e).splitlines() if ln.strip() and not ln.strip().startswith(("⚠", "\u26a0"))) or str(e)
            return {"ok": False, "runtime": "Claude Code", "model": model, "words": "Claude Code did not answer: %s" % why[-240:], "seconds": round(time.time() - t0, 1)}
        finally:
            shutil.rmtree(box, ignore_errors=True)
        return {"ok": isinstance(ans, dict), "runtime": "Claude Code", "model": model, "seconds": round(time.time() - t0, 1),
                "words": "Claude Code answered with model %s (it uses the key and URL above)" % model}
    how = ("with your URL the agents use the Model connection (not Claude Code), so every call goes to %s" % _address()) if company else ""
    try:
        ans = r._http(prompt)
    except Exception as e:      # noqa: BLE001
        return {"ok": False, "runtime": "model connection", "model": r.http_model, "words": "no answer: %s%s" % (str(e)[:200], ("; " + how) if how else ""),
                "seconds": round(time.time() - t0, 1)}
    ans = ans[0] if isinstance(ans, tuple) else ans
    return {"ok": isinstance(ans, dict), "runtime": "model connection", "model": r.http_model, "seconds": round(time.time() - t0, 1),
            "words": ("the agents answered with model %s: %s" % (r.http_model, how)) if how else "the agents' connection answered with model %s" % r.http_model}


def _test_main(s):
    llm = s.s2.llm
    name = getattr(llm, "name", "stand-in")
    if name in ("standin", "stand-in"):
        return dict({"ok": False, "producer": name, "error": "no model is configured: " + ("no key is present" if not _model_state(s)["key_present"] else "the backend is the stand-in")})
    if name.startswith("opencode:") and not getattr(llm, "available", lambda: True)():
        return dict({"ok": False, "producer": name, "error": "no model is chosen for opencode: choose one in Settings"})
    before = dict(getattr(llm, "usage", {}) or {})
    t0 = time.time()
    try:
        # a one-time marker: a test always reaches the configured address with the configured key and model, never the answer cache
        out = llm.generate_json("Answer with a JSON object whose field ok is the text yes. (connection test %s)" % os.urandom(6).hex(),
                                {"type": "object", "properties": {"ok": {"type": "string"}}, "required": ["ok"]})
    except Exception as e:      # noqa: BLE001
        return dict({"ok": False, "producer": name, "error": str(e)[:300], "seconds": round(time.time() - t0, 1)})
    if isinstance(out, tuple):
        out = out[0]
    after = dict(getattr(llm, "usage", {}) or {})
    tries = 1 + (after.get("retries", 0) - before.get("retries", 0))
    if isinstance(out, dict) and out.get("_error"):
        return dict({"ok": False, "producer": name, "error": out["_error"], "tries": tries, "seconds": round(time.time() - t0, 1)})
    return dict({"ok": True, "producer": name, "answer": out, "tries": tries, "seconds": round(time.time() - t0, 1)})


def machine_roots():
    """The file picker's starting points besides the home folder: /, /mnt, /media and /tmp, or on Windows the drives that exist (C:\\, D:\\ ...)."""
    if os.name != "nt":
        return ["/", "/mnt", "/media", "/tmp"]
    try:
        return [d for d in os.listdrives() if os.path.isdir(d)]          # Python 3.12 and later
    except (AttributeError, OSError):
        return [d for d in ("%s:\\" % c for c in "CDEFGHIJKLMNOPQRSTUVWXYZ") if os.path.isdir(d)]


@bp.get("/api/hier/browse")
def browse():
    """Folders and CSV files on this machine for the upload page's file picker. Any folder can be opened: nothing is
    refused on the ground of where it lies (owner's rule, 2026-11-03). ?path=<folder>; empty = the starting points
    (shortcuts: home, /, /mnt, /media, /tmp and the configured folders). Each CSV gets the level its header looks like."""
    s = svc()
    starts = []
    for x in [os.path.expanduser("~")] + machine_roots() + [str(r) for r in s.roots]:
        if os.path.isdir(x) and x not in starts:
            starts.append(x)
    raw = (request.args.get("path") or "").strip().strip('"').strip("'")
    if not raw:
        return jsonify({"path": "", "parent": None, "roots": starts, "dirs": [{"name": r, "path": r} for r in starts], "files": []})
    try:
        rp = os.path.realpath(os.path.expanduser(raw))
    except (OSError, ValueError):            # a NUL byte in the path
        return jsonify({"error": "not a usable path", "roots": starts}), 400
    if os.path.isfile(rp):
        rp = os.path.dirname(rp)
    if not os.path.isdir(rp):
        return jsonify({"error": "not a folder: %s" % rp, "roots": starts}), 400
    dirs, files = [], []
    try:
        names = sorted(os.listdir(rp), key=str.lower)
    except OSError as e:
        return jsonify({"error": "cannot read the folder: %s" % e, "roots": starts}), 400
    for n in names:
        if n.startswith("."):
            continue
        fp = os.path.join(rp, n)
        try:
            if os.path.isdir(fp):
                dirs.append({"name": n, "path": fp})
            elif n.lower().endswith((".csv", ".txt")):
                st = os.stat(fp)
                level = None
                try:
                    with open(fp, newline="", encoding="utf-8", errors="replace") as fh:
                        header = next(L.read_csv(fh, fp), [])
                    level = L.guess_level(header)
                except Exception:          # noqa: BLE001 - a file we cannot read is listed without a level
                    level = None
                files.append({"name": n, "path": fp, "bytes": st.st_size, "modified": time.strftime("%Y-%m-%d %H:%M", time.localtime(st.st_mtime)),
                              "level": level, "level_label": C.LEVEL_LABEL.get(level) if level else None})
        except OSError:
            continue
    parent = os.path.dirname(rp)
    if parent == rp:                     # the top: "/", or a drive such as C:\\ on Windows
        parent = None
    return jsonify({"path": rp, "parent": parent, "roots": starts, "dirs": dirs, "files": files})


def build_stamp():
    """The build this server runs (BUILD.txt, written by deploy/build_code_zip.py; 'development copy' when absent)."""
    try:
        with open(os.path.join(svc().root, "BUILD.txt"), encoding="utf-8") as fh:
            return fh.read().strip() or "development copy"
    except OSError:
        return "development copy"


@bp.get("/api/hier/version")
def version():
    return jsonify({"build": build_stamp(), "stored_headers": sorted(C.real_headers().keys())})


@bp.post("/api/hier/sniff")
def sniff():
    """Header + first rows of one file and the level it looks like, for the upload page."""
    s = svc()
    body = request.get_json(force=True) or {}
    path, err = s.safe_path(body.get("path"))
    if err:
        return jsonify({"error": err}), 400
    header, rows = L.sniff(path, 3)
    level = L.guess_level(header)
    rep = None
    if level:
        al = L.align_header(level, header, L.prescan_values(path, L.ambiguous_columns(level, header), max_rows=20000))
        rep = al.report(level)
    return jsonify({"path": path, "bytes": os.path.getsize(path), "columns_in_file": len(header), "level": level,
                    "level_label": C.LEVEL_LABEL.get(level), "header_check": rep, "build": build_stamp(),
                    "first_rows": [[c[:40] for c in r[:12]] for r in rows]})


@bp.post("/api/hier/uploads")
def create_upload():
    s = svc()
    body = request.get_json(force=True) or {}
    files = {}
    if not isinstance(body.get("files") or {}, dict):
        return jsonify({"error": "files must name a path for each level"}), 400
    for key in LEVELS:
        p = (body.get("files") or {}).get(key)
        if p and not isinstance(p, str):
            return jsonify({"error": "the path of %s must be text" % key}), 400
        if p:
            path, err = s.safe_path(p)
            if err:
                return jsonify({"error": "%s: %s" % (C.LEVEL_LABEL[key], err)}), 400
            files[key] = path
    if not files:
        return jsonify({"error": "give at least one of the five files"}), 400
    device = as_text(body.get("device"), "device").strip()
    if not device:
        return jsonify({"error": "the drive under test is required (its name is stored with the upload, with every decision and with every stored signature)"}), 400
    operator = as_text(body.get("operator"), "operator").strip() or "admin"      # the owner's rule of 2026-11-03: no admin name at the start; "admin" is the default
    problem = L.room_problem(sum(os.path.getsize(p) for p in files.values() if os.path.exists(p)), uploads_dir(s))
    if problem:
        return jsonify({"error": problem}), 507
    uid = time.strftime("up-%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]
    d = os.path.join(uploads_dir(s), uid)
    os.makedirs(d, exist_ok=True)
    meta = {"upload_id": uid, "created": time.time(), "operator": operator, "device": device,
            "trace_name": as_text(body.get("trace_name"), "trace_name").strip(), "recording_date": as_text(body.get("recording_date"), "recording_date").strip(),
            "notes": as_text(body.get("notes"), "notes").strip(), "files": files, "status": "loading",
            "thresholds": body.get("thresholds") or {}}
    write_meta(d, meta)
    params = {"upload_id": uid, "upload_dir": d, "files": files, "operator": operator, "device": meta["device"],
              "trace_name": meta["trace_name"], "recording_date": meta["recording_date"], "thresholds": meta["thresholds"]}
    params["workers"] = ((s.cfg.get("pipeline") or {}).get("workers") or 0)     # CSV parsing on several cores (0 = automatic)
    jid = s.jobs.submit("hier_load", params, run_hier_load)
    meta["job"] = jid
    write_meta(d, meta)
    return jsonify({"upload_id": uid, "job": jid})


@bp.post("/api/hier/uploads/<uid>/resume")
def resume_upload(uid):
    """'load again' on the same upload (2026-11-03): the load job is submitted again for this upload folder, so the
    files, the build and the rules already completed before the interruption are kept and only the rest is done.
    Any state is accepted (interrupted, cancelled, failed, loaded); a running load is left alone."""
    with _RESUME_LOCK:         # two presses at the same moment must start one load
        return _resume_upload(uid)


_RESUME_LOCK = threading.Lock()


def _resume_upload(uid):
    s = svc()
    d = upload_dir(s, uid)
    m = read_meta(d) if d and os.path.isdir(d) else None
    if not m:
        return jsonify({"error": "no such upload"}), 404
    m = settle_status(s, d, m)
    if m.get("status") == "loading":
        return jsonify({"error": "this upload is loading right now", "job": m.get("job")}), 409
    files = {k: v for k, v in (m.get("files") or {}).items() if v}
    missing = [k for k, v in files.items() if not os.path.isfile(v)]
    if not files or missing:
        return jsonify({"error": "the files are no longer where they were: %s" % ", ".join(files.get(k, k) for k in missing)}), 400
    problem = L.room_problem(sum(os.path.getsize(p) for p in files.values()), d, already=_db_bytes(d))
    if problem:
        return jsonify({"error": problem}), 507
    m["status"] = "loading"
    m.pop("error", None)
    params = {"upload_id": uid, "upload_dir": d, "files": files, "operator": m.get("operator") or "admin", "device": m.get("device") or "",
              "trace_name": m.get("trace_name") or "", "recording_date": m.get("recording_date") or "", "thresholds": m.get("thresholds") or {}}
    params["workers"] = ((s.cfg.get("pipeline") or {}).get("workers") or 0)
    jid = s.jobs.submit("hier_load", params, run_hier_load)
    m["job"] = jid
    write_meta(d, m)
    return jsonify({"upload_id": uid, "job": jid, "resumed": True})


def settle_status(s, d, m):
    """A load that was cut off (the server stopped while loading) must not stay 'loading' forever: the job manager marks
    such jobs failed at start-up; here the upload gets status 'interrupted' with the reason, so the page can offer 'load again'."""
    if m.get("status") == "loading" and m.get("job"):
        job = s.jobs.get(m["job"])
        if job is None or job["status"] in ("failed", "cancelled"):
            m["status"] = "interrupted"
            m["error"] = (job or {}).get("error") or "the load job no longer exists (the server was stopped while loading)"
            write_meta(d, m)
    return m


@bp.get("/api/hier/uploads")
def list_uploads():
    s = svc()
    out = []
    for name in sorted(os.listdir(uploads_dir(s)), reverse=True):
        d = upload_dir(s, name)
        if not d:
            continue
        m = read_meta(d)
        if m:
            m = settle_status(s, d, m)
            row = {k: m.get(k) for k in ("upload_id", "created", "operator", "device", "trace_name", "recording_date",
                                          "status", "job", "loaded_at", "error", "notes")}
            row.update({"files": list((m.get("files") or {}).keys()), "file_paths": m.get("files") or {}})
            if m.get("status") == "loading" and m.get("job"):
                job = s.jobs.get(m["job"])
                row["progress"] = (job or {}).get("progress")
            out.append(row)
    return jsonify(out)


@bp.get("/api/hier/uploads/<uid>")
def get_upload(uid):
    s = svc()
    d = upload_dir(s, uid)
    if not d:
        return jsonify({"error": "no such upload"}), 404
    m = settle_status(s, d, read_meta(d) or {})
    job = s.jobs.get(m.get("job")) if m.get("job") else None
    m["job_status"] = job["status"] if job else None
    m["job_progress"] = job["progress"] if job else None
    m["job_error"] = job["error"] if job else None
    m["job_spans"] = job["spans"] if job else None
    if os.path.exists(db_of(d)):
        con = sqlite3.connect(db_of(d))
        try:
            if m.get("status") == "loaded":
                ensure_indexes(con)          # upload-open time: the browsing indexes, if an older load lacks them
            m["levels_present"] = L.get_meta(con, "levels_present", [])
            m["load_reports"] = L.get_meta(con, "load_reports", {})
            m["build"] = L.get_meta(con, "build", None)
            m["rules"] = L.get_meta(con, "rules", None)
            counts = {}
            for key in m["levels_present"]:
                counts[key] = con.execute("SELECT COUNT(*) FROM %s" % TABLE[key]).fetchone()[0]
            m["row_counts"] = counts
        except sqlite3.Error:
            pass
        con.close()
    return jsonify(m)


@bp.delete("/api/hier/uploads/<uid>")
def delete_upload(uid):
    s = svc()
    d = upload_dir(s, uid)
    if not d:
        return jsonify({"error": "no such upload"}), 404
    import shutil
    m = read_meta(d) or {}
    if m.get("status") == "loading" and m.get("job"):
        s.jobs.cancel(m["job"])          # the load thread stops at its next progress report and then the folder goes
        for _ in range(300):
            j = s.jobs.get(m["job"])
            if not j or j["status"] != "running":
                break
            time.sleep(0.2)
    from nvme_hier import osfile
    if not osfile.remove_tree(d):        # Windows keeps a file that another reader still has open: say so, never report a delete that did not happen
        return jsonify({"error": "the upload could not be deleted completely: one of its files is still in use by another program or page. Close what shows this upload and delete it again."}), 409
    return jsonify({"deleted": uid})


@bp.get("/api/hier/uploads/<uid>/columns")
def columns_of(uid):
    """Columns of one level for the filter bar: the typed key columns (with their SQL type) and every named
    column of the file (filterable through the raw JSON)."""
    s = svc()
    d = upload_dir(s, uid)
    level = request.args.get("level")
    if not d or level not in LEVELS:
        return jsonify({"error": "no such upload or level"}), 404
    typed = {}
    for cname, sql, fn in L.KEYS[level]:
        typed.setdefault(sql, {"sql": sql, "names": [], "kind": "text" if sql in L.TEXT_COLS else "number"})
        typed[sql]["names"].append(cname)
        if sql in ("t_ps", "delta_ps", "dur_ps"):
            typed[sql]["kind"] = "time"
    out = {"level": level, "label": C.LEVEL_LABEL[level], "typed": list(typed.values()),
           "all_columns": C.canonical_names(level), "plain": C.PLAIN}
    return jsonify(out)


def _bindable(v):
    """A filter value the database can take: a nested value or a number beyond 64 bits is compared as text and matches nothing, instead of failing."""
    if v is None or isinstance(v, (str, float, bool)):
        return v
    if isinstance(v, int) and abs(v) < 2 ** 63:
        return v
    return json.dumps(v)


def _where(level, filters):
    """filters: [{column, op, value}] -> (sql, args). column = canonical name or a typed sql column."""
    typed = {}
    for cname, sql, fn in L.KEYS[level]:
        typed[cname] = sql
        typed[sql] = sql
    clauses, args = [], []
    for f in filters or []:
        col = f.get("column")
        op = f.get("op")
        val = f.get("value")
        if not isinstance(col, str) or not isinstance(op, str) or not col or op not in FILTER_OPS:
            continue
        if not isinstance(val, list):
            val = _bindable(val)
        else:
            val = [_bindable(v) for v in val]
        if col in typed:
            expr = typed[col]
            numeric = expr not in L.TEXT_COLS
        else:
            if col not in C.canonical_names(level):
                continue
            expr = "json_extract(raw, ?)"
            args.append('$."%s"' % col.replace('"', ""))      # names hold spaces and dots: quote the key
            numeric = False
            if op in ("gt", "lt", "ge", "le", "between"):
                expr = "CAST(%s AS REAL)" % expr
                numeric = True
        if op == "blank":
            clauses.append("(%s IS NULL OR %s = '')" % (expr, expr))
        elif op == "notblank":
            clauses.append("(%s IS NOT NULL AND %s != '')" % (expr, expr))
        elif op == "eq":
            clauses.append("%s = ?" % expr)
            args.append(val)
        elif op == "ne":
            clauses.append("%s != ?" % expr)
            args.append(val)
        elif op == "in":
            vals = val if isinstance(val, list) else [v.strip() for v in str(val).split(",") if v.strip()]
            if vals:
                clauses.append("%s IN (%s)" % (expr, ",".join("?" * len(vals))))
                args.extend(vals)
        elif op == "contains":
            clauses.append("%s LIKE ?" % expr)
            args.append("%" + str(val) + "%")
        elif op in ("gt", "lt", "ge", "le"):
            clauses.append("%s %s ?" % (expr, {"gt": ">", "lt": "<", "ge": ">=", "le": "<="}[op]))
            args.append(val)
        elif op == "between":
            lo, hi = ((val if isinstance(val, list) else []) + [None, None])[:2]
            if lo is not None:
                clauses.append("%s >= ?" % expr)
                args.append(lo)
            if hi is not None:
                clauses.append("%s <= ?" % expr)
                args.append(hi)
    return (" AND ".join(clauses) if clauses else "1=1"), args


def _scope(level, args):
    """The WHERE of one browsing request: column filters + tree position (parent / top / relation) + the five
    per-level error check boxes (finding_at). Returns (where, args) or raises ValueError."""
    try:
        filters = json.loads(args.get("filters") or "[]")
    except ValueError:
        raise ValueError("filters must be a JSON list")
    filters = dicts(filters, "filters")
    where, a = _where(level, filters)
    if args.get("parent"):
        where += " AND parent_level = ? AND parent = ?"
        a += [args.get("parent_level"), whole(args.get("parent"), "parent")]
    elif args.get("top") == "1":
        # both columns are NULL for a row without a parent, so the (parent_level, parent) index serves this
        where += " AND parent IS NULL"      # command rows have no parent; orphans keep their parent_level but no parent
    if args.get("relation"):
        where += " AND relation = ?"
        a.append(args.get("relation"))
    # the five level filters: commands whose subtree holds an error finding at the given level(s)
    fa = [x for x in (args.get("finding_at") or "").split(",") if x in LEVELS]
    if fa and level == "nvme_command":
        where += " AND rowid_file IN (SELECT cmd_rowid FROM finding WHERE severity='error' AND level IN (%s))" % ",".join("?" * len(fa))
        a += fa
    elif fa:
        where += " AND rowid_file IN (SELECT rowid FROM finding WHERE severity='error' AND level=? AND level IN (%s))" % ",".join("?" * len(fa))
        a += [level] + fa
    return where, a


def _page(args, default_limit=200, max_limit=2000):
    """Paging parameters. Keyset (after / before = a rowid_file) walks the rows in file order without an OFFSET
    scan, which is what the scrolling lists use; offset stays for sorted or random access. count=0 skips the
    COUNT(*) on follow-up pages (the browser keeps the total of the first page)."""
    offset = max(0, whole(args.get("offset") or 0, "offset"))
    limit = max(1, min(whole(args.get("limit") or default_limit, "limit"), max_limit))
    after = whole(args["after"], "after") if args.get("after") not in (None, "") else None
    before = whole(args["before"], "before") if args.get("before") not in (None, "") else None
    want_count = args.get("count", "1") != "0"
    return offset, limit, after, before, want_count


def _rows_out(cur):
    """Only the rows of this page are turned into dicts and only their raw JSON is parsed."""
    out = []
    for r in cur:
        row = dict(r)
        row["raw"] = json.loads(row["raw"]) if row.get("raw") else {}
        for k in ("t_ps", "delta_ps", "dur_ps"):
            if row.get(k) is not None:
                row[k + "_text"] = P.fmt_ps(row[k])
        out.append(row)
    return out


@bp.get("/api/hier/uploads/<uid>/rows")
def rows(uid):
    """Rows of one level, one page at a time (the browser scrolls through them; nothing is held server side).
    parent_level + parent select the children of one row (the tree); top=1 selects the rows with no parent (the
    top of the tree, or the rows outside any command when level is not the command level).
    filters = JSON list; after / before = keyset paging by rowid_file (file order); offset/limit = positional
    paging; sort = sql column (offset paging only); count=0 skips the total."""
    s = svc()
    d = upload_dir(s, uid)
    level = request.args.get("level")
    if not d or level not in LEVELS or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload or level"}), 404
    t = TABLE[level]
    try:
        where, args = _scope(level, request.args)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    offset, limit, after, before, want_count = _page(request.args, default_limit=100)
    sort = request.args.get("sort") or "rowid_file"
    if sort not in ("rowid_file", "t_ps", "delta_ps", "dur_ps", "n") and sort not in {s2 for _, s2, _ in L.KEYS[level]}:
        sort = "rowid_file"
    desc = " DESC" if request.args.get("desc") == "1" else ""
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    try:
        total = con.execute("SELECT COUNT(*) FROM %s WHERE %s" % (t, where), args).fetchone()[0] if want_count else None
        if after is not None and sort == "rowid_file" and not desc:
            cur = con.execute("SELECT * FROM %s WHERE %s AND rowid_file > ? ORDER BY rowid_file LIMIT ?" % (t, where), args + [after, limit])
            out = _rows_out(cur)
        elif before is not None and sort == "rowid_file" and not desc:
            cur = con.execute("SELECT * FROM %s WHERE %s AND rowid_file < ? ORDER BY rowid_file DESC LIMIT ?" % (t, where), args + [before, limit])
            out = _rows_out(cur)[::-1]
        else:
            cur = con.execute("SELECT * FROM %s WHERE %s ORDER BY %s%s LIMIT ? OFFSET ?" % (t, where, sort, desc), args + [limit, offset])
            out = _rows_out(cur)
    except sqlite3.Error as e:
        con.close()
        return jsonify({"error": "query failed: %s" % e}), 400
    con.close()
    return jsonify({"level": level, "label": C.LEVEL_LABEL[level], "total": total, "offset": offset, "limit": limit, "rows": out,
                    "first_key": out[0]["rowid_file"] if out else None, "last_key": out[-1]["rowid_file"] if out else None,
                    "has_more": len(out) == limit})


# ---------------------------------------------------------------------------------------------- exports (2026-11-08)
# The tree page's table as a file: the same columns as on the screen (hier.js SHOW), every row (not only the 200 on
# the screen), with the rules that fired on each row. Streamed from the database, so a huge recording exports too.
def _x_opc(opc, sqid):
    if opc is None:
        return "-"
    m = NM_X.ADMIN_OPC if sqid == 0 else NM_X.IO_OPC
    return (m.get(opc) or "opcode %s" % opc) + (" (admin)" if sqid == 0 else "")


def _x(v, d="-"):
    return d if v is None or v == "" else v


def _x_status(r):
    if r.get("sct") is None:
        return "-"
    if r.get("sct") == 0 and r.get("sc") == 0:
        return "success"
    t = (r["raw"].get("ST") or r["raw"].get("Cpl Status") or "")
    t = re.sub(r"\)$", "", re.sub(r"^0x[0-9A-Fa-f]+\s*\(?", "", t)).strip()
    return t or "type %s code %s" % (r.get("sct"), r.get("sc"))


def _x_ts(r):
    t = r["raw"].get("Time Stamp")
    if not t:
        return "-"
    m = re.match(r"^0*(\d+)\.(\d+)s$", t)
    return "%s.%s s" % (m.group(1), m.group(2).rstrip("0") or "0") if m else t


def _x_ps(r, k):
    return P.fmt_ps(r[k]) if r.get(k) is not None else "-"


def _x_rt(r):
    return "%s / %s" % (r.get("rid") or "-", _x(r.get("tag")))


EXPORT_COLS = {
    "nvme_command": [("NVMe Cmd", lambda r: r.get("n")), ("command", lambda r: _x_opc(r.get("opc"), r.get("sqid"))),
                     ("queue / id", lambda r: "%s / %s" % (_x(r.get("sqid")), _x(r.get("cid")))), ("namespace", lambda r: _x(r.get("nsid"))),
                     ("start LBA", lambda r: _x(r.get("slba"))), ("blocks", lambda r: "-" if r.get("nlb") is None else r["nlb"] + 1),
                     ("bytes", lambda r: _x(r.get("nbytes"))), ("status", _x_status), ("NVMe transactions", lambda r: _x(r.get("n_ntx"))),
                     ("duration", lambda r: _x_ps(r, "dur_ps")), ("Time Delta", lambda r: _x_ps(r, "delta_ps")), ("Time Stamp", _x_ts),
                     ("errors", lambda r: r.get("errors") or ""), ("warnings", lambda r: r.get("warnings") or "")],
    "nvme_transaction": [("NVMe", lambda r: r.get("n")), ("type", lambda r: _x(r.get("type"))),
                         ("queue / id", lambda r: "%s / %s" % (_x(r.get("sqid") if r.get("sqid") is not None else r.get("qid")), _x(r.get("cid")))),
                         ("address", lambda r: _x(r["raw"].get("Address"))), ("bytes", lambda r: _x(r.get("nbytes"))), ("status", _x_status),
                         ("link+split", lambda r: _x(r.get("n_links_splits"))), ("duration", lambda r: _x_ps(r, "dur_ps")),
                         ("Time Delta", lambda r: _x_ps(r, "delta_ps")), ("Time Stamp", _x_ts), ("errors", lambda r: r.get("errors") or ""),
                         ("warnings", lambda r: r.get("warnings") or "")],
    "split": [("Split Tra", lambda r: r.get("n")), ("request", lambda r: _x(r.get("tlp_type"))), ("direction", lambda r: _x(r.get("dir"))),
              ("requester / tag", _x_rt), ("address", lambda r: _x(r["raw"].get("Address"))), ("completion status", lambda r: _x(r.get("cpl_status"))),
              ("bytes", lambda r: _x(r.get("nbytes"))), ("link transactions", lambda r: _x(r.get("n_links"))), ("duration", lambda r: _x_ps(r, "dur_ps")),
              ("Time Delta", lambda r: _x_ps(r, "delta_ps")), ("Time Stamp", _x_ts)],
    "link": [("Link Tra", lambda r: r.get("n")), ("TLP", lambda r: _x(r.get("tlp_type"))), ("direction", lambda r: _x(r.get("dir"))),
             ("PSN", lambda r: _x(r.get("psn"))), ("requester / tag", _x_rt), ("address", lambda r: _x(r["raw"].get("Address"))),
             ("completion status", lambda r: r.get("cpl_status") or ""), ("packets", lambda r: _x(r.get("n_packets"))),
             ("ack", lambda r: r.get("explicit_ack") or ""), ("duration", lambda r: _x_ps(r, "dur_ps")), ("Time Delta", lambda r: _x_ps(r, "delta_ps")),
             ("Time Stamp", _x_ts), ("errors", lambda r: r.get("errors") or "")],
    "packets": [("Packet", lambda r: r.get("n") if r.get("n") is not None else "(no number)"), ("direction", lambda r: _x(r.get("dir"))),
                ("what", lambda r: r.get("tlp_type") or r.get("dllp_type") or r.get("os_type") or r.get("link_event") or "-"),
                ("PSN", lambda r: _x(r.get("psn"), "")), ("Ack/Nak seq", lambda r: _x(r.get("acknak"), "")),
                ("requester / tag", lambda r: _x_rt(r) if r.get("rid") else ""), ("address", lambda r: r["raw"].get("Address") or ""),
                ("length", lambda r: _x(r.get("length"), "")), ("completion status", lambda r: r.get("cpl_status") or ""),
                ("LCRC", lambda r: r.get("lcrc") or ""), ("Time Delta", lambda r: _x_ps(r, "delta_ps")), ("Time Stamp", _x_ts),
                ("errors", lambda r: r.get("errors") or "")],
}
RELATION_WORDS = {"member": "part of it", "context": "only in its time window", "orphan": "belongs to no command"}


def _export_rows(con, level, where, args, tree=False):
    """(header, row generator) for one level: the screen's columns, the file row, the rules that fired on the row (and
    below it, for a command); with tree=True also which row it belongs to."""
    t = TABLE[level]
    has_f = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='finding'").fetchone() is not None
    cols = EXPORT_COLS[level]
    head = [c for c, _ in cols] + ["file row"]
    if tree:
        head += ["belongs to (level)", "belongs to (file row)", "how it belongs"]
    head += ["rules that fired on this row"] + (["rules that fired below it"] if level == "nvme_command" else [])
    fired = ", (SELECT GROUP_CONCAT(f.name, ' | ') FROM finding f WHERE f.level = '%s' AND f.rowid = t.rowid_file) AS _fired" % level if has_f else ", NULL AS _fired"
    cur = con.execute("SELECT t.*%s FROM %s t WHERE %s ORDER BY t.rowid_file" % (fired, t, where), args)
    names = [d[0] for d in cur.description]

    def gen():
        for row in cur:
            r = dict(zip(names, row))
            r["raw"] = json.loads(r["raw"]) if r.get("raw") else {}
            out = [fn(r) for _c, fn in cols] + [r.get("rowid_file")]
            if tree:
                out += [C.LEVEL_LABEL.get(r.get("parent_level"), "") if r.get("parent") is not None else "",
                        _x(r.get("parent"), ""), RELATION_WORDS.get(r.get("relation"), r.get("relation") or "")]
            out += [r.get("_fired") or ""] + ([r.get("n_sub_findings") or 0] if level == "nvme_command" else [])
            yield out
    return head, gen()


@bp.get("/api/hier/uploads/<uid>/export.csv")
def export_table(uid):
    """The table of the tree page as a CSV file: the same level, the same filters and check boxes as on the screen,
    every row. Opens in Excel (UTF-8 with a byte order mark)."""
    import io
    s = svc()
    d = upload_dir(s, uid)
    level = request.args.get("level") or "nvme_command"
    if not d or level not in LEVELS or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload or level"}), 404
    try:
        where, args = _scope(level, request.args)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    con = sqlite3.connect("file:%s?mode=ro" % db_of(d), uri=True)
    head, rows_ = _export_rows(con, level, where, args)

    def stream():
        buf = io.StringIO()
        w = L.CsvOut(buf)
        buf.write("\ufeff")
        w.writerow(head)
        n = 0
        for row in rows_:
            w.writerow(row)
            n += 1
            if n % 2000 == 0:
                yield buf.getvalue()
                buf.seek(0)
                buf.truncate(0)
        yield buf.getvalue()
        con.close()
    what = "outside_any_command" if request.args.get("relation") == "orphan" else C.LEVEL_LABEL[level].replace(" ", "_") + "s"
    return Response(stream(), mimetype="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="%s_%s.csv"' % (uid, what)})


@bp.get("/api/hier/uploads/<uid>/export_tree.zip")
def export_tree(uid):
    """The whole tree as a ZIP: one CSV per level (every row, the screen's columns), each row saying which row of the
    level above it belongs to, so the hierarchy can be rebuilt in a spreadsheet; plus README.txt."""
    import io
    import zipfile
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    con = sqlite3.connect("file:%s?mode=ro" % db_of(d), uri=True)
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    out_dir = os.path.join(d, "exports")
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "%s_tree_%s.zip" % (uid, time.strftime("%Y%m%d-%H%M%S")))
    order = ["nvme_command", "nvme_transaction", "split", "link", "packets"]
    counts = {}
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for i, level in enumerate(order):
            if TABLE[level] not in tables:
                continue
            head, rows_ = _export_rows(con, level, "1", [], tree=True)
            name = "%d_%ss.csv" % (i + 1, C.LEVEL_LABEL[level].replace(" ", "_"))
            n = 0
            with z.open(name, "w") as raw:
                tw = io.TextIOWrapper(raw, encoding="utf-8-sig", newline="")
                w = L.CsvOut(tw)
                w.writerow(head)
                for row in rows_:
                    w.writerow(row)
                    n += 1
                tw.flush()
                tw.detach()
            counts[name] = n
        z.writestr("README.txt", "The tree of upload %s, exported %s.\n\n" % (uid, time.strftime("%Y-%m-%d %H:%M")) +
                   "One file per level, top to bottom: %s.\n" % ", ".join("%s (%s rows)" % (k, "{:,}".format(v)) for k, v in counts.items()) +
                   "Every file has the same columns as the table on the tree page, then:\n"
                   "  file row                      the row's number in its own analyzer file\n"
                   "  belongs to (level / file row) the row of the level above that holds it (empty = a top row)\n"
                   "  how it belongs                part of it, only in its time window (context), or belongs to no command\n"
                   "  rules that fired on this row  the errors and checks found on this row (Time Delta over a limit, ...)\n"
                   "  rules that fired below it     (NVMe commands only) how many fired anywhere inside the command\n")
    con.close()
    return send_file(path, as_attachment=True, download_name=os.path.basename(path), mimetype="application/zip")


# the summary table (page 2): one aggregate row per NVMe command, computed in SQL, paged like the tree
SUMMARY_COLS = ["rowid_file", "n", "opc", "sqid", "cqid", "cid", "nsid", "slba", "nlb", "nbytes", "fua", "sct", "sc", "n_ntx",
                "delta_ps", "t_ps", "dur_ps", "errors", "warnings", "errors2", "cns", "fid", "lid", "ad", "nr", "relation",
                "n_findings", "n_sub_findings", "cause_level", "cause_rule", "role"]


@bp.get("/api/hier/uploads/<uid>/summary")
def summary(uid):
    """One line per NVMe command for the summary table (c1 command, c2 parameters, c3 time, c4 errors, lower levels),
    as a SQL projection + aggregate (the error findings per level inside the command's subtree), never the raw JSON.
    Same filters, finding_at and paging (after / before / offset, count=0) as the rows endpoint; totals for the
    whole selection come with the first page."""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "cmd" not in tables:
        con.close()
        return jsonify({"error": "the summary needs the NVMe command file"}), 400
    have = {r[1] for r in con.execute("PRAGMA table_info(cmd)")}
    cols = [c for c in SUMMARY_COLS if c in have]
    sel = ", ".join("c.%s" % c for c in cols)
    if "finding" in tables:
        sel += (", (SELECT GROUP_CONCAT(level || ':' || k, ',') FROM (SELECT level, COUNT(*) AS k FROM finding f "
                "WHERE f.cmd_rowid = c.rowid_file AND f.severity = 'error' GROUP BY level)) AS findings_by_level")
    args_in = request.args.to_dict()
    args_in.setdefault("top", "1")
    try:
        where, args = _scope("nvme_command", args_in)
    except ValueError as e:
        con.close()
        return jsonify({"error": str(e)}), 400
    offset, limit, after, before, want_count = _page(request.args, default_limit=200)
    try:
        totals = None
        if want_count:
            err_expr = " OR ".join(x for x in [
                "(c.errors IS NOT NULL AND c.errors != '')", "(c.sc IS NOT NULL AND c.sc != 0)",
                "c.n_findings > 0" if "n_findings" in have else "", "c.n_sub_findings > 0" if "n_sub_findings" in have else ""] if x)
            r = con.execute("SELECT COUNT(*), SUM(CASE WHEN %s THEN 1 ELSE 0 END), SUM(c.n_ntx), MAX(c.dur_ps), AVG(c.dur_ps) FROM cmd c WHERE %s"
                            % (err_expr, where), args).fetchone()
            totals = {"commands": r[0], "commands_with_errors": r[1] or 0, "nvme_transactions": r[2] or 0,
                      "longest_ps": r[3], "longest_text": P.fmt_ps(r[3]) if r[3] is not None else None,
                      "mean_ps": int(r[4]) if r[4] is not None else None, "mean_text": P.fmt_ps(int(r[4])) if r[4] is not None else None}
        if after is not None:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s AND c.rowid_file > ? ORDER BY c.rowid_file LIMIT ?" % (sel, where), args + [after, limit])
            out = [dict(r) for r in cur]
        elif before is not None:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s AND c.rowid_file < ? ORDER BY c.rowid_file DESC LIMIT ?" % (sel, where), args + [before, limit])
            out = [dict(r) for r in cur][::-1]
        else:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s ORDER BY c.rowid_file LIMIT ? OFFSET ?" % (sel, where), args + [limit, offset])
            out = [dict(r) for r in cur]
    except sqlite3.Error as e:
        con.close()
        return jsonify({"error": "query failed: %s" % e}), 400
    con.close()
    for row in out:
        for k in ("t_ps", "delta_ps", "dur_ps"):
            if row.get(k) is not None:
                row[k + "_text"] = P.fmt_ps(row[k])
        fb = {}
        for part in (row.pop("findings_by_level", None) or "").split(","):
            if ":" in part:
                lv, k = part.rsplit(":", 1)
                fb[lv] = int(k)
        row["findings_by_level"] = fb
    return jsonify({"total": totals["commands"] if totals else None, "totals": totals, "offset": offset, "limit": limit, "rows": out,
                    "first_key": out[0]["rowid_file"] if out else None, "last_key": out[-1]["rowid_file"] if out else None,
                    "has_more": len(out) == limit, "level_labels": C.LEVEL_LABEL})


def _sum_params(c):
    """c2 of the summary card, word for word (hier.js summaryRow)."""
    p = ["namespace %s" % c["nsid"] if c.get("nsid") is not None else "",
         "start LBA %s" % c["slba"] if c.get("slba") is not None else "",
         "%s blocks" % (c["nlb"] + 1) if c.get("nlb") is not None else "",
         "{:,} bytes".format(c["nbytes"]) if c.get("nbytes") else "", "FUA" if c.get("fua") else "",
         "CNS %s" % c["cns"] if c.get("cns") else "", "feature %s" % c["fid"] if c.get("fid") else "",
         "log %s" % c["lid"] if c.get("lid") else "", "deallocate" if c.get("ad") else "",
         "%s ranges" % (int(c["nr"]) + 1) if c.get("nr") else ""]
    return " · ".join(x for x in p if x) or "-"


def _sum_errors(c, by_level):
    """c4 of the summary card, word for word (hier.js summaryRow)."""
    lab = C.LEVEL_LABEL
    # in the screen's order: the card receives the levels from GROUP BY level, so alphabetical by level key
    below = ", ".join("%s at the %s level" % (k, lab.get(lv, lv)) for lv, k in sorted(by_level.items()) if lv != "nvme_command")
    nf, ns = c.get("n_findings") or 0, c.get("n_sub_findings") or 0
    e = ["analyzer: %s" % c["errors"] if c.get("errors") else "", "warning: %s" % c["warnings"] if c.get("warnings") else "",
         "status type %s code %s" % (c.get("sct"), c.get("sc")) if (c.get("sct") or c.get("sc")) else "",
         "%s rule hit%s at this level" % (nf, "" if nf == 1 else "s") if nf else "",
         "%s below (%s)" % (ns, below or ("%s level" % lab.get(c["cause_level"], c["cause_level"]) if c.get("cause_level") else "lower level")) if ns else "",
         c.get("role") or ""]
    return " · ".join(x for x in e if x) or "none"


@bp.get("/api/hier/uploads/<uid>/summary.csv")
def export_summary(uid):
    """The summary card as a CSV file: one line per NVMe command, every command of the selection (the same filters,
    finding_at and outside-a-command switch as the card), the card's words in its columns, plus what the rules found
    inside the command: for each level and kind of finding, how many and the largest one. Opens in Excel."""
    import io
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    con = sqlite3.connect("file:%s?mode=ro" % db_of(d), uri=True)
    con.row_factory = sqlite3.Row
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "cmd" not in tables:
        con.close()
        return jsonify({"error": "the summary needs the NVMe command file"}), 400
    have = {r[1] for r in con.execute("PRAGMA table_info(cmd)")}
    sel = ", ".join("c.%s" % c for c in SUMMARY_COLS if c in have)
    args_in = request.args.to_dict()
    args_in.setdefault("top", "1")
    try:
        where, args = _scope("nvme_command", args_in)
    except ValueError as e:
        con.close()
        return jsonify({"error": str(e)}), 400
    has_f = "finding" in tables
    order = {lv: i for i, lv in enumerate(["nvme_command", "nvme_transaction", "split", "link", "packets"])}
    head = ["c1 · NVMe command", "command number", "queue", "id", "c2 · parameters", "c3 · Time Delta", "c3 · duration",
            "c4 · errors at this level", "lower levels: NVMe transactions", "what the rules found inside the command", "file row"]
    try:
        cur = con.execute("SELECT %s FROM cmd c WHERE %s ORDER BY c.rowid_file" % (sel, where), args)
    except sqlite3.Error as e:
        con.close()
        return jsonify({"error": "query failed: %s" % e}), 400

    def found(rowid):
        """[(level, how many, the largest one's words)] for the error findings inside one command; the bare `name`
        next to MAX() is the name of the row with the largest value (SQLite)."""
        if not has_f:
            return []
        rows_ = con.execute("SELECT level, COUNT(*) AS k, name, MAX(value_ps) AS v FROM finding WHERE cmd_rowid = ? AND severity = 'error' "
                            "GROUP BY level, rule", (rowid,)).fetchall()
        return sorted(((r["level"], r["k"], r["name"]) for r in rows_), key=lambda x: (order.get(x[0], 9), -x[1]))

    def line(c):
        f = found(c["rowid_file"])
        by_level = {}
        for lv, k, _n in f:
            by_level[lv] = by_level.get(lv, 0) + k
        words = " | ".join("%s level: %s finding%s, the largest: %s" % (C.LEVEL_LABEL.get(lv, lv), k, "" if k == 1 else "s", n) if k > 1
                           else "%s level: %s" % (C.LEVEL_LABEL.get(lv, lv), n) for lv, k, n in f)
        return [_x_opc(c.get("opc"), c.get("sqid")), c.get("n"), _x(c.get("sqid")), _x(c.get("cid")), _sum_params(c),
                _x_ps(c, "delta_ps"), P.fmt_ps(c["dur_ps"]) if c.get("dur_ps") is not None else "not built yet",
                _sum_errors(c, by_level), _x(c.get("n_ntx")), words or "none", c.get("rowid_file")]

    def stream():
        buf = io.StringIO()
        w = L.CsvOut(buf)
        buf.write("﻿")
        w.writerow(head)
        n = 0
        for batch in iter(lambda: cur.fetchmany(500), []):
            for row in batch:
                w.writerow(line(dict(row)))
                n += 1
            yield buf.getvalue()
            buf.seek(0)
            buf.truncate(0)
        yield buf.getvalue()
        con.close()
    what = "summary_outside_any_command" if request.args.get("relation") == "orphan" else "summary_NVMe_commands"
    return Response(stream(), mimetype="text/csv",
                    headers={"Content-Disposition": 'attachment; filename="%s_%s.csv"' % (uid, what)})


@bp.get("/api/hier/uploads/<uid>/thresholds")
def get_thresholds(uid):
    s = svc()
    d = upload_dir(s, uid)
    if not d:
        return jsonify({"error": "no such upload"}), 404
    return jsonify((read_meta(d) or {}).get("thresholds") or {})


@bp.put("/api/hier/uploads/<uid>/thresholds")
def set_thresholds(uid):
    """thresholds: {level: {"value": number, "unit": "ns|us|ms|s", "source": text}}; stored in picoseconds too."""
    s = svc()
    d = upload_dir(s, uid)
    if not d:
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    th = {}
    for level, v in body.items():
        if level in TIMING_LEVELS and v is None:
            th[level] = None              # page 3's "timing at this level is not considered" stays as it is
            continue
        if level not in LEVELS or not isinstance(v, dict):
            continue
        unit = v.get("unit", "ms")
        if not isinstance(unit, str) or unit not in P.UNIT_PS or v.get("value") in (None, ""):
            continue
        try:
            value = float(v["value"])
            ps = int(value * P.UNIT_PS[unit])
        except (TypeError, ValueError, OverflowError):
            return jsonify({"error": "%s: the limit must be a number" % LEVEL_LABEL[level]}), 400
        if value <= 0:
            return jsonify({"error": "%s: the limit must be above zero" % LEVEL_LABEL[level]}), 400
        th[level] = {"value": value, "unit": unit, "ps": ps, "source": as_text(v.get("source"), "source").strip() or "set by the admin"}
    meta = read_meta(d) or {}
    if meta.get("status") == "loading" and body.get("rerun", True):
        return jsonify({"error": "this upload is still loading; change the limits when the load report is shown"}), 409
    meta["thresholds"] = th
    write_meta(d, meta)
    out = {"thresholds": th}
    if os.path.exists(db_of(d)) and body.get("rerun", True):
        from nvme_hier import rules
        went = {}
        out["rules"] = rules.apply(db_of(d), th, out=went)
        con = sqlite3.connect(db_of(d))
        ensure_indexes(con)
        con.close()
        # (2026-11-15) every rule ran anew, so every error got its number anew: the stores and the analyses that keep numbers follow, each
        # error found again by its rule, its level and its row. The errors a rule of the rules library had filed are gone until that rule
        # runs again: the analyses that list them say so
        moved = went.get("renumbered") or {}
        follow_in_stores(s, uid, moved)
        out["renumbered"] = len(moved) if "_count" not in moved else moved["_count"]
        out.update(follow_in_analyses(s, uid, moved, went.get("no_longer_found"), db_of(d)))
    return jsonify(out)


# ---------------------------------------------------------------------------------------------- page 3: the defect table and the two timing limits
from nvme_hier import rules as _RL   # noqa: E402

DT_COLS = ["rowid_file", "n", "opc", "sqid", "cqid", "cid", "nsid", "slba", "nlb", "nbytes", "fua", "sct", "sc", "st", "n_ntx", "delta_ps", "t_ps", "dur_ps",
           "errors", "warnings", "cns", "fid", "lid", "ad", "nr", "qid", "qsize", "relation", "n_findings", "n_sub_findings", "cause_level", "cause_rule", "role"]
# a command has an error on page 3 when a rule of severity error fired at the NVMe transaction level or the NVMe command level
# inside it (the NVMe-transaction timing rule is one of them), or a link transaction under it is at or over the link limit
DT_DEFECT = "((f.level IN ('nvme_transaction', 'nvme_command') AND f.severity = 'error') OR f.rule = 'lnk.response_over_limit')"
DT_SEV_ORDER = "CASE f.severity WHEN 'error' THEN 0 WHEN 'check' THEN 1 ELSE 2 END"
LINK_RULE = "lnk.response_over_limit"
NTX_RULE = "ntx.over_limit"
TIMING_LEVELS = ("link", "nvme_transaction")
LIMIT_UNITS = ("ns", "us", "ms", "s")
DT_FILTERS = ("all", "error", "no_error")
# the rule in words, for the evidence line of column 4 (the finding's name carries the measured facts)
RULE_WORDS = {
    "cmd.status_error": "the drive answered the command with an error status", "cmd.analyzer_error": "the analyzer's error cell of the command is not empty",
    "cmd.analyzer_warning": "the analyzer's warning cell of the command is not empty", "cmd.incomplete": "the command never completed",
    "cmd.not_fetched": "the submission entry was never fetched", "cmd.doorbell_missing": "no submission doorbell write was seen for the command",
    "cmd.no_interrupt": "the command completed without an interrupt write", "cmd.latency_over_limit": "the command's Time Delta is at or above the command limit",
    "cmd.bytes_short": "fewer data bytes moved than the command asked for", "cmd.write_zeroes_readback": "a read of a range cleared by Write Zeroes",
    "cmd.deallocate_readback": "a read of a range deallocated earlier",
    "cmd.timeout": "NVMe command timeout", "cmd.read_failure": "Read failed (the most common NVMe failure)", "ntx.analyzer_error": "the analyzer's error cell of the transaction is not empty",
    "ntx.analyzer_warning": "the analyzer's warning cell of the transaction is not empty", "ntx.status_error": "the completion entry carries an error status",
    "ntx.over_limit": "an NVMe transaction's Time Delta is at or above the NVMe-transaction limit", "ntx.phase_wrong": "the completion entry carries the wrong phase bit",
    "ntx.interrupt_before_completion": "the interrupt was written before the completion entry it announces",
    "ntx.completion_unknown_command": "a completion entry for a command id that is not open", "lnk.response_over_limit": "a link transaction under this command has a Time Delta at or above the link limit",
}
MEASURED = {"link": "from the TLP to the Ack or Nak that answered it", "nvme_transaction": "from the transaction's first packet to its last"}


def _value_unit(ps):
    """50000000 -> (50, 'us'): the largest unit in which the limit is a round number (for the number + unit boxes)."""
    for u in ("s", "ms", "us", "ns"):
        size = P.UNIT_PS[u]
        if ps % size == 0:
            return ps // size, u
    return ps / P.UNIT_PS["ns"], "ns"


def _timing_limits_of(meta, con):
    """The two page-3 limits in force (link, nvme_transaction): the admin's (thresholds[level]), None = not considered,
    or the specification default; plus the limit the stored findings were computed with (the 'rules' report), so the
    page can say when the two differ."""
    th_all = meta.get("thresholds") or {}
    try:
        used_all = (L.get_meta(con, "rules", {}) or {}).get("limits", {})
    except sqlite3.Error:
        used_all = {}
    out = {}
    for level in TIMING_LEVELS:
        rule = _RL.TIMING_RULES[level][0]
        dflt = _RL.DEFAULT_LIMITS[level]
        o = {"level": level, "label": LEVEL_LABEL[level], "rule": rule, "measured": MEASURED[level],
             "default": {"ps": dflt["ps"], "text": P.fmt_ps(dflt["ps"]), "value": _value_unit(dflt["ps"])[0], "unit": _value_unit(dflt["ps"])[1], "source": dflt["source"], "short": dflt["short"]}}
        if level in th_all and th_all[level] is None:
            o.update({"considered": False, "ps": None, "text": "not considered", "value": "", "unit": o["default"]["unit"],
                      "source": "the field is empty: timing errors at this level are not considered", "short": "not considered", "set_by_admin": True})
        elif (th_all.get(level) or {}).get("ps"):
            th = th_all[level]
            v, u = (th.get("value"), th.get("unit")) if th.get("unit") in LIMIT_UNITS and th.get("value") not in (None, "") else _value_unit(int(th["ps"]))
            o.update({"considered": True, "ps": int(th["ps"]), "text": P.fmt_ps(int(th["ps"])), "value": v, "unit": u,
                      "source": th.get("source") or "set by the admin", "short": "set by the admin", "set_by_admin": True})
        else:
            o.update({"considered": True, "ps": dflt["ps"], "text": o["default"]["text"], "value": o["default"]["value"], "unit": o["default"]["unit"],
                      "source": dflt["source"], "short": dflt["short"], "set_by_admin": False})
        used = used_all.get(level)
        o["in_force"] = used                                   # the limit of the last rules run at this level (None before the rules ran, or when never set)
        used_ps = (used or {}).get("ps") if used else (None if used_all else "unknown")
        o["findings_match"] = (used_ps == o["ps"]) if used_ps != "unknown" else True
        out[level] = o
    return out


def _cat_entry(cat, ref):
    if not ref:
        return None
    e = cat.by_id.get(ref) or cat.by_name.get(str(ref).lower()) or cat.silent.get(str(ref).lower())
    if e is None:
        for x in cat.by_status.values():
            if x.get("error") == ref:
                return x
    return e


def _evidence(f, cat):
    """The evidence that makes a finding an error, in plain words (the owner's addition of 2026-11-03 to column 4): the rule
    in words; the cell or value that made it fire; the row it was seen on; the catalogue's one-line meaning when there is one."""
    d = f.get("detail") or {}
    rule = f.get("rule") or ""
    facts = []
    if rule in ("cmd.status_error", "ntx.status_error") and (d.get("SCT") is not None or d.get("SC") is not None):
        sct, sc = int(d.get("SCT") or 0), int(d.get("SC") or 0)
        e = _cat_entry(cat, f.get("cat_ref"))
        facts.append("status 0x%04x: type %d, code %d, %s%s" % ((sct << 8) | sc, sct, sc, (e or {}).get("error") or "unknown status name", ", do not retry" if d.get("DNR") else ""))
    elif "cell" in d:
        facts.append("the analyzer's %s cell reads \"%s\"" % ("warning" if "warning" in rule else "error", d["cell"]))
    if rule in ("cmd.timeout", "cmd.read_failure") and (d.get("cycle") or {}).get("words"):
        facts.append("cycle: " + d["cycle"]["words"])
    if rule == "cmd.timeout":
        # its value is the command's own time (Time Stamp to completion entry), or how long the recording went on after it
        # was sent when it never completed: not a Time Delta
        kind = d.get("kind")
        if kind == "never completed":
            facts.append("no status in its row; the recording went on %s after it was sent; the host's limit is %s" % (P.fmt_ps(f.get("value_ps") or 0), P.fmt_ps(f.get("limit_ps") or 0)))
        elif f.get("value_ps") is not None:
            facts.append("took %s from its Time Stamp to its completion entry (%s); limit %s: %s" % (P.fmt_ps(f["value_ps"]), kind, P.fmt_ps(f.get("limit_ps") or 0), f.get("limit_source") or ""))
    elif f.get("value_ps") is not None and f.get("limit_ps") is not None:
        facts.append("Time Delta %s, limit %s, %s" % (P.fmt_ps(f["value_ps"]), P.fmt_ps(f["limit_ps"]), f.get("limit_source") or "limit source not recorded"))
    if rule == "cmd.incomplete":
        facts.append("no completion entry was written; parts seen: %s" % ", ".join(d.get("parts_seen") or []) or "none")
    elif rule == "cmd.not_fetched":
        facts.append("no fetch of the submission entry; parts seen: %s" % ", ".join(d.get("parts_seen") or []))
    elif rule == "cmd.doorbell_missing":
        facts.append("no submission doorbell write of its own (a coalesced doorbell is possible)")
    elif rule == "cmd.no_interrupt":
        facts.append("completion entry written, no interrupt write seen")
    elif rule == "ntx.phase_wrong":
        facts.append("phase bit found %s, expected %s, at slot %s of completion queue %s" % (d.get("phase"), d.get("expected"), d.get("slot"), d.get("queue")))
    elif rule == "ntx.interrupt_before_completion" and d.get("interrupt_t") is not None and d.get("completion_t") is not None:
        facts.append("interrupt at %s, completion entry at %s" % (P.fmt_ps(d["interrupt_t"]), P.fmt_ps(d["completion_t"])))
    elif rule == "ntx.completion_unknown_command":
        facts.append("queue %s, command id %s is not open" % (d.get("sqid"), d.get("cid")))
    elif rule == "cmd.bytes_short":
        facts.append("%s bytes requested, %s moved" % (d.get("requested"), d.get("moved")))
    elif rule in ("cmd.deallocate_readback", "cmd.write_zeroes_readback"):
        facts.append("%s bytes checked, pattern %s" % (d.get("bytes_checked", 0), d.get("pattern") or "not exported"))
    elif not facts and d:
        facts.append("; ".join("%s: %s" % (k, v) for k, v in d.items() if k != "opcode"))
    if f.get("level") == "nvme_command":
        seen = "seen on the command itself"
    elif f.get("level") == "link":
        seen = "seen on link transaction %s" % (f.get("row_n") if f.get("row_n") is not None else f.get("rowid"))
    else:
        seen = "seen on %s %s" % (LEVEL_LABEL.get(f.get("level"), f.get("level")), f.get("row_n") if f.get("row_n") is not None else "file row %s" % f.get("rowid"))
    b = RL.basis(rule)
    facts.append("basis: %s (%s; %s)" % (b["text"], "firm: " + b["kind"] if b["firm"] else "a suspect: " + b["kind"], b["ref"]) if b["ref"] else "basis: %s" % b["text"])
    facts.append(b["words"][0].lower() + b["words"][1:].rstrip("."))      # "specification: NVMe Base 2.1 section …" / "source: …"
    e = _cat_entry(cat, f.get("cat_ref")) or {}
    meaning = (e.get("meaning") or e.get("description") or "").strip()
    if not meaning and e.get("defects"):
        d0 = e["defects"][0]
        meaning = "usual cause: %s (%s)" % (d0.get("cause", ""), d0.get("domain", "")) if isinstance(d0, dict) else str(d0)
    if not meaning and isinstance(e.get("rule"), dict) and e["rule"].get("description"):
        meaning = str(e["rule"]["description"]).strip()
    if meaning:
        meaning = meaning.split(". ")[0].rstrip(".") + "."
    return {"rule_words": RULE_WORDS.get(rule, rule), "facts": facts, "seen_on": seen, "meaning": meaning or None,
            "text": "%s · %s · %s" % (RULE_WORDS.get(rule, rule), "; ".join(facts) or f.get("name", ""), seen)}



def _status_words(row, cat):
    """The command's completion status in words: 'success', 'Invalid Command Opcode (type 0, code 1)', or 'no completion recorded'."""
    sct, sc = row.get("sct"), row.get("sc")
    if sct is None and sc is None:
        return "no completion recorded", False
    if not sct and not sc:
        return "success", True
    e = cat.by_status.get((int(sct or 0), int(sc or 0))) or {}
    name = e.get("error")
    if not name:
        m = re.search(r"\(([^)]+)\)", str(row.get("st") or ""))
        name = m.group(1) if m else None
    return "%s (type %s, code %s)" % (name or "an error status", sct or 0, sc or 0), False


IO_RW = {1: "Write", 2: "Read", 4: "Write Uncorrectable", 5: "Compare", 8: "Write Zeroes", 12: "Verify", 25: "Copy"}


def _did_text(row):
    """What the command did, in one clause: 'Read of 16 blocks at block 2,097,152 on namespace 1'."""
    name = NAMES.opcode_name(row.get("opc"), row.get("sqid"))
    sqid, opc = row.get("sqid"), row.get("opc")
    ns = (" on namespace %s" % row["nsid"]) if row.get("nsid") is not None else ""
    if sqid != 0 and opc in IO_RW and row.get("nlb") is not None and row.get("slba") is not None:
        return "%s of %s block%s at block %s%s%s" % (IO_RW[opc], "{:,}".format(row["nlb"] + 1), "" if row["nlb"] == 0 else "s", "{:,}".format(row["slba"]), ns, " with FUA" if row.get("fua") else "")
    if sqid != 0 and opc == 0:
        return "Flush%s" % ns
    if sqid != 0 and opc == 9:
        return "Dataset Management of %s range%s%s%s" % ((row.get("nr") or 0) + 1, "" if not row.get("nr") else "s", " (deallocate)" if row.get("ad") else "", ns)
    if sqid == 0:
        extra = ""
        if opc == 6 and row.get("cns") is not None:
            extra = " with CNS %s" % row["cns"]
        elif opc in (9, 10) and row.get("fid") is not None:
            extra = ", feature %s" % row["fid"]
        elif opc == 2 and row.get("lid") is not None:
            extra = ", log %s" % row["lid"]
        elif opc in (0, 1, 4, 5) and row.get("qid") is not None:
            extra = ", queue %s%s" % (row["qid"], (" of %s entries" % row["qsize"]) if row.get("qsize") else "")
        return "%s%s%s" % (name, extra, ns if row.get("nsid") else "")
    return "%s%s" % (name, ns)


def _short_source(level, limit_source):
    d = _RL.DEFAULT_LIMITS[level]
    return d["short"] if limit_source == d["source"] else ("set by the admin" if limit_source else "limit source not recorded")


def _statement(row, tx_by_rowid, findings, link_findings, limits):
    """ONE plain-English statement for the whole row, written by code: what the command did and how it ended; 'No error.'
    when nothing fired; otherwise every error at the NVMe transaction and command level with its evidence, the timing
    errors named by level with the transaction (or link transaction) number, the measured time and the limit; then the
    checks and the context; then the levels whose timing is not considered."""
    did = _did_text(row)
    status, ok = _status_words(row, _statement.cat)
    dur = row.get("dur_ps_text")
    if status == "no completion recorded":
        ended = ", no completion recorded" + (" (%s so far)" % dur if dur else "")
    else:
        ended = (", completed with %s" % ("success" if ok else "status " + status)) + ((" in %s" % dur) if dur else " (duration not built)")
    parts = [did + ended + "."]
    errors = [f for f in findings if f.get("severity") == "error" and f.get("rule") != NTX_RULE]
    ntx_t = [f for f in findings if f.get("rule") == NTX_RULE]
    checks = [f for f in findings if f.get("severity") == "check"]
    warns = [f for f in findings if f.get("severity") == "warning"]
    if not errors and not ntx_t and not link_findings:
        parts.append("No error.")
    for f in errors:
        e = f.get("evidence") or {}
        facts = [x for x in (e.get("facts") or [f.get("name") or ""]) if not str(x).startswith(("specification:", "source:"))]
        parts.append("%s: %s; %s." % (_cap(e.get("rule_words") or f.get("rule")), "; ".join(facts), e.get("seen_on") or ""))
        parts.append(_RL.basis(f.get("rule"))["words"])
    if ntx_t:
        items = []
        for f in ntx_t[:8]:
            t = tx_by_rowid.get(f.get("rowid")) or {}
            items.append("transaction %s (%s) Time Delta %s, limit %s (%s)" % (f.get("row_n") if f.get("row_n") is not None else f.get("rowid"), t.get("type") or "type not in the tree",
                                                                           f.get("value_ps_text") or "-", f.get("limit_ps_text") or "-", _short_source("nvme_transaction", f.get("limit_source"))))
        if len(ntx_t) > 8:
            items.append("and %d more" % (len(ntx_t) - 8))
        b = _RL.basis(NTX_RULE)
        parts.append("An NVMe transaction's Time Delta is at or above the NVMe-transaction limit: %s. Basis: %s (%s)." % ("; ".join(items), b["text"], b["ref"]))
        parts.append(b["words"])
    if link_findings:
        items = []
        for f in link_findings[:8]:
            under = ("under NVMe transaction %s (%s)" % (f["ntx_n"], f.get("ntx_type") or "-")) if f.get("ntx_n") is not None else "under no NVMe transaction in the tree"
            items.append("link transaction %s %s Time Delta %s, limit %s (%s)" % (f.get("row_n") if f.get("row_n") is not None else f.get("rowid"), under, f.get("value_ps_text") or "-",
                                                                          f.get("limit_ps_text") or "-", _short_source("link", f.get("limit_source"))))
        if len(link_findings) > 8:
            items.append("and %d more" % (len(link_findings) - 8))
        b = _RL.basis(LINK_RULE)
        parts.append("A link transaction under this command has a Time Delta at or above the link limit: %s. Basis: %s (%s)." % ("; ".join(items), b["text"], b["ref"]))
        parts.append(b["words"])
    if checks:
        parts.append("To check by hand: %s." % "; ".join("%s (%s)" % (f.get("name"), (f.get("evidence") or {}).get("seen_on") or "") for f in checks))
    if warns:
        parts.append("Context: %s." % "; ".join(f.get("name") or "" for f in warns))
    for level in TIMING_LEVELS:
        if limits.get(level) and not limits[level]["considered"]:
            parts.append("Timing at the %s level: not considered." % ("link" if level == "link" else "NVMe transaction"))
    return " ".join(parts)


def _cap(t):
    return (t[:1].upper() + t[1:]) if t else t


@bp.get("/api/hier/uploads/<uid>/defect_table")
def defect_table(uid):
    """Page 3. One page of NVMe commands (error or not) with their NVMe transactions, their findings and ONE statement per
    row written by code, in one query set (no query per command): the transactions and the findings come as JSON arrays
    aggregated by the database, keyed by the command's rowid_file. filter=all (default) | error (at least one error:
    a rule of severity error at the NVMe transaction or command level, or a slow link transaction) | no_error, applied
    in SQL; the legacy all=1 / all=0 mean all / error. filters / finding_at / relation as `rows`; keyset paging (after /
    before) by rowid_file, offset for positional access, count=0 skips the total."""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    meta = read_meta(d) or {}
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "cmd" not in tables:
        con.close()
        return jsonify({"error": "the defect table needs the NVMe command file"}), 400
    have = {r[1] for r in con.execute("PRAGMA table_info(cmd)")}
    have_f, have_ntx, have_lnk, have_spl = "finding" in tables, "ntx" in tables, "lnk" in tables, "spl" in tables
    limits = _timing_limits_of(meta, con)
    flt = request.args.get("filter") or ({"1": "all", "0": "error"}.get(request.args.get("all")) if request.args.get("all") is not None else "all")
    if flt not in DT_FILTERS:
        con.close()
        return jsonify({"error": "filter must be one of all, error, no_error"}), 400
    sel = ", ".join("c.%s" % c for c in DT_COLS if c in have)
    # columns 2 and 3: the NVMe transactions of the command, one JSON object each, in file order
    if have_ntx:
        have_x = {r[1] for r in con.execute("PRAGMA table_info(ntx)")}
        sel += (", (SELECT json_group_array(json_object('rowid', x.rowid_file, 'n', x.n, 'type', x.type, 'delta_ps', x.delta_ps, 'dur_ps', x.dur_ps, "
                "'t_ps', x.t_ps, 'nbytes', x.nbytes, 'sct', x.sct, 'sc', x.sc, 'errors', x.errors, 'warnings', x.warnings, 'relation', x.relation, 'n_findings', %s)) "
                "FROM (SELECT * FROM ntx WHERE parent_level = 'nvme_command' AND parent = c.rowid_file ORDER BY rowid_file) x) AS ntx_json"
                % ("x.n_findings" if "n_findings" in have_x else "NULL"))
    else:
        sel += ", NULL AS ntx_json"
    # column 4: the findings at the NVMe transaction and command level, and the link-level timing errors with the link row's
    # identity and its parent chain (link -> split or NVMe transaction -> command), read through primary-key joins
    if have_f:
        if have_lnk:
            ntx_of = ("CASE l.parent_level WHEN 'nvme_transaction' THEN l.parent WHEN 'split' THEN (SELECT p.parent FROM spl p WHERE p.rowid_file = l.parent) END" if have_spl
                      else "CASE l.parent_level WHEN 'nvme_transaction' THEN l.parent END")
            spl_n = "(SELECT p.n FROM spl p WHERE l.parent_level = 'split' AND p.rowid_file = l.parent)" if have_spl else "NULL"
            lnk_join = " LEFT JOIN lnk l ON f.level = 'link' AND l.rowid_file = f.rowid"
            lnk_cols = "'tlp_type', l.tlp_type, 'dir', l.dir, 'psn', l.psn, 'ntx_rowid', %s, 'split_n', %s" % (ntx_of, spl_n)
        else:
            lnk_join, lnk_cols = "", "'tlp_type', NULL, 'dir', NULL, 'psn', NULL, 'ntx_rowid', NULL, 'split_n', NULL"
        sel += (", (SELECT json_group_array(json_object('id', f.id, 'level', f.level, 'rule', f.rule, 'name', f.name, 'severity', f.severity, 'rowid', f.rowid, "
                "'row_n', f.row_n, 'value_ps', f.value_ps, 'limit_ps', f.limit_ps, 'limit_source', f.limit_source, 't_ps', f.t_ps, 'part', f.part, 'detail', f.detail, "
                "'cat_ref', f.cat_ref, %s)) "
                "FROM (SELECT f.* FROM finding f WHERE f.cmd_rowid = c.rowid_file AND (f.level IN ('nvme_transaction', 'nvme_command') OR f.rule = '%s') "
                "ORDER BY %s, COALESCE(f.t_ps, 0), f.id) f%s) AS findings_json" % (lnk_cols, LINK_RULE, DT_SEV_ORDER, lnk_join))
    else:
        sel += ", NULL AS findings_json"
    args_in = request.args.to_dict()
    args_in.setdefault("top", "1")
    try:
        where, args = _scope("nvme_command", args_in)
    except ValueError as e:
        con.close()
        return jsonify({"error": str(e)}), 400
    err_set = "(SELECT f.cmd_rowid FROM finding f WHERE f.cmd_rowid IS NOT NULL AND %s)" % DT_DEFECT
    if flt == "error":
        where += (" AND c.rowid_file IN %s" % err_set) if have_f else " AND 0"
    elif flt == "no_error" and have_f:
        where += " AND c.rowid_file NOT IN %s" % err_set
    offset, limit, after, before, want_count = _page(request.args, default_limit=200, max_limit=1000)
    try:
        total = con.execute("SELECT COUNT(*) FROM cmd c WHERE %s" % where, args).fetchone()[0] if want_count else None
        if after is not None:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s AND c.rowid_file > ? ORDER BY c.rowid_file LIMIT ?" % (sel, where), args + [after, limit])
            out = [dict(r) for r in cur]
        elif before is not None:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s AND c.rowid_file < ? ORDER BY c.rowid_file DESC LIMIT ?" % (sel, where), args + [before, limit])
            out = [dict(r) for r in cur][::-1]
        else:
            cur = con.execute("SELECT %s FROM cmd c WHERE %s ORDER BY c.rowid_file LIMIT ? OFFSET ?" % (sel, where), args + [limit, offset])
            out = [dict(r) for r in cur]
    except sqlite3.Error as e:
        con.close()
        return jsonify({"error": "query failed: %s" % e}), 400
    con.close()
    cat = RL.Catalogue()
    _statement.cat = cat
    for row in out:
        for k in ("t_ps", "delta_ps", "dur_ps"):
            if row.get(k) is not None:
                row[k + "_text"] = P.fmt_ps(row[k])
        row["command"] = NAMES.opcode_name(row.get("opc"), row.get("sqid"))
        row["status_text"], row["status_ok"] = _status_words(row, cat)
        row["did"] = _did_text(row)
        tx = json.loads(row.pop("ntx_json", None) or "[]")
        by_rowid = {}
        for t in tx:
            for k in ("t_ps", "delta_ps", "dur_ps"):
                if t.get(k) is not None:
                    t[k + "_text"] = P.fmt_ps(t[k])
            t["part"] = NAMES.part_key(t.get("type"))
            by_rowid[t["rowid"]] = t
        row["transactions"] = tx
        fs = json.loads(row.pop("findings_json", None) or "[]")
        for f in fs:
            try:
                f["detail"] = json.loads(f["detail"]) if isinstance(f.get("detail"), str) else (f.get("detail") or {})
            except ValueError:
                f["detail"] = {}
            for k in ("t_ps", "value_ps", "limit_ps"):
                if f.get(k) is not None:
                    f[k + "_text"] = P.fmt_ps(f[k])
            f["level_label"] = LEVEL_LABEL.get(f.get("level"), f.get("level"))
            f["evidence"] = _evidence(f, cat)
            if f["level"] == "link":
                t = by_rowid.get(f.get("ntx_rowid"))
                f["ntx_n"], f["ntx_type"] = (t.get("n"), t.get("type")) if t else (None, None)
                f["under"] = "%s, queue %s, id %s (command %s) > %s > link transaction %s" % (
                    row["command"], row.get("sqid"), row.get("cid"), row.get("n"),
                    ("NVMe transaction %s (%s)%s" % (t["n"], t.get("type") or "-", (" > split transaction %s" % f["split_n"]) if f.get("split_n") is not None else "")) if t else "NVMe transaction not in the tree",
                    f.get("row_n") if f.get("row_n") is not None else f.get("rowid"))
        row["findings"] = [f for f in fs if f["level"] != "link"]            # the NVMe transaction and command level (timing included)
        row["link_findings"] = [f for f in fs if f["level"] == "link"]       # the slow link transactions
        row["has_error"] = any(f["severity"] == "error" for f in fs)
        row["statement"] = _statement(row, by_rowid, row["findings"], row["link_findings"], limits)
        first = next((f for f in fs if f["severity"] == "error"), fs[0] if fs else None)
        row["first_finding"] = first["id"] if first else None                # the isolate tab a click on the row opens
    return jsonify({"total": total, "offset": offset, "limit": limit, "rows": out, "filter": flt,
                    "first_key": out[0]["rowid_file"] if out else None, "last_key": out[-1]["rowid_file"] if out else None,
                    "has_more": len(out) == limit, "timing_limits": limits, "level_labels": LEVEL_LABEL})


@bp.get("/api/hier/uploads/<uid>/timing_limits")
def get_timing_limits(uid):
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    con = sqlite3.connect(db_of(d))
    out = _timing_limits_of(read_meta(d) or {}, con)
    con.close()
    return jsonify(out)


def _limit_entry(level, v):
    """One limit from the request: {value, unit} -> the stored entry; None -> None (not considered); "default" -> absent."""
    if v is None:
        return None
    if v == "default":
        return "default"
    if not isinstance(v, dict):
        raise ValueError("%s: give {value, unit}, null (not considered) or \"default\"" % LEVEL_LABEL[level])
    if v.get("value") in (None, ""):
        return None
    unit = v.get("unit") or "ms"
    if not isinstance(unit, str) or unit not in LIMIT_UNITS:
        raise ValueError("%s: the unit must be one of ns, us, ms, s" % LEVEL_LABEL[level])
    try:
        fv = float(v["value"])
    except (TypeError, ValueError, OverflowError):
        raise ValueError("%s: the limit must be a number" % LEVEL_LABEL[level])
    if fv != fv or fv in (float("inf"), float("-inf")):
        raise ValueError("%s: the limit must be a number" % LEVEL_LABEL[level])
    if fv <= 0:
        raise ValueError("%s: the limit must be above zero" % LEVEL_LABEL[level])
    return {"value": fv, "unit": unit, "ps": int(round(fv * P.UNIT_PS[unit])),
            "source": as_text(v.get("source"), "source").strip() or ("set by the admin on page 3, %s" % time.strftime("%Y-%m-%d %H:%M"))}


@bp.put("/api/hier/uploads/<uid>/timing_limits")
def set_timing_limits(uid):
    """body: {link: {value, unit, source?} | null | "default", nvme_transaction: ...}; a level that is absent stays as it is.
    null (or an empty value) = timing at that level is not considered: the limit is stored as none and that rule's
    findings are deleted. "default" = back to the specification default. Each level given is stored under the upload's
    thresholds and ONLY the levels whose limit changed have their timing rule re-run (rules.apply_link_limit /
    apply_ntx_limit) with the roll-up; returns the counts per level re-run."""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    meta = read_meta(d) or {}
    if meta.get("status") == "loading":
        return jsonify({"error": "this upload is still loading; set the limits when the load report is shown"}), 409
    th = dict(meta.get("thresholds") or {})
    con = sqlite3.connect(db_of(d))
    before = _timing_limits_of(meta, con)
    con.close()
    changed = []
    for level in TIMING_LEVELS:
        if level not in body:
            continue
        try:
            e = _limit_entry(level, body[level])
        except ValueError as ex:
            return jsonify({"error": str(ex)}), 400
        if e == "default":
            th.pop(level, None)
        else:
            th[level] = e
        new_ps = None if e in (None, "default") else e["ps"]
        if e == "default":
            new_ps = _RL.DEFAULT_LIMITS[level]["ps"]
        if new_ps != before[level]["ps"] or not before[level]["findings_match"] or body.get("force"):
            changed.append(level)
    meta["thresholds"] = th
    write_meta(d, meta)
    counts = {}
    renumbered = {}
    followed = {}               # per level applied again: what became of the numbers the analyses of this recording keep
    try:
        for level in changed:
            out = {}
            counts[level] = (_RL.apply_link_limit if level == "link" else _RL.apply_ntx_limit)(db_of(d), th, out=out)
            moved = out.get("renumbered") or {}
            if moved and "_count" not in moved:
                follow_in_stores(s, uid, moved)        # the knowledge store and (since 2026-11-15) the procedural graph, which was not followed here
                renumbered[level] = len(moved)
            elif moved:
                renumbered[level] = moved["_count"]
            followed[level] = follow_in_analyses(s, uid, moved, out.get("no_longer_found"), db_of(d))
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 409
    con = sqlite3.connect(db_of(d))
    ensure_indexes(con)
    limits = _timing_limits_of(meta, con)
    n_cmds = con.execute("SELECT COUNT(DISTINCT f.cmd_rowid) FROM finding f WHERE f.cmd_rowid IS NOT NULL AND %s" % DT_DEFECT).fetchone()[0] if changed or True else None
    con.close()
    return jsonify({"timing_limits": limits, "counts": counts, "changed": changed, "commands_with_errors": n_cmds, "thresholds": th,
                    "renumbered": renumbered, "analyses": followed,
                    "analyses_not_followed": [x["analyses_not_followed"] for x in followed.values() if x.get("analyses_not_followed")]})


@bp.post("/api/hier/uploads/<uid>/rules/commands")
def rerun_command_rules(uid):
    """Run the two NVMe command rules the owner keeps (cmd.timeout, cmd.read_failure; 2026-11-09) on an upload already
    loaded, without loading the recording again: their findings are filed anew, then the roll-up; the defect numbers that
    move are followed in the knowledge store. Returns the counts and how 'usual' was measured for each command type."""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    meta = read_meta(d) or {}
    if meta.get("status") == "loading":
        return jsonify({"error": "this upload is still loading"}), 409
    out = {}
    try:
        res = _RL.rerun_command_rules(db_of(d), dict(meta.get("thresholds") or {}), out=out)
    except RuntimeError as e:
        return jsonify({"error": str(e)}), 409
    moved = out.get("renumbered") or {}
    follow_in_stores(s, uid, moved)             # the knowledge store and (since 2026-11-15) the procedural graph, which was not followed here
    con = sqlite3.connect(db_of(d))
    ensure_indexes(con)
    con.close()
    return jsonify(dict(res, renumbered=len(moved) if "_count" not in moved else moved["_count"],
                        **follow_in_analyses(s, uid, moved, out.get("no_longer_found"), db_of(d))))


# ---------------------------------------------------------------------------------------------- findings
from nvme_hier import names as NAMES, rules as RL, signature as SG, store as ST   # noqa: E402
from nvme_hier import chat as CH, optimise as OPT, testcase as TC   # noqa: E402

LEVEL_LABEL = C.LEVEL_LABEL


def knowledge(s):
    if not hasattr(s, "hier_store"):
        s.hier_store = ST.Store(os.path.join(s.root, "db", "hier_knowledge.sqlite"))
    return s.hier_store


def follow_in_stores(s, uid, moved):
    """The error numbers of a recording that moved ({old: new}) are followed in the two stores that keep them: the knowledge store and the
    procedural graph. Nothing is done when there were too many to name ({"_count": n}). -> how many stored rows were moved."""
    if not moved or "_count" in moved:
        return 0
    from .dg_api import graph as _dg
    return knowledge(s).remap_findings(uid, moved) + _dg(s).remap_findings(uid, moved)


def follow_in_analyses(s, uid, moved, gone, db):
    """The same numbers followed in the records of every analysis (flow) of this recording, right where the stores are followed
    (agentic/pipeline.follow_renumbering: one transaction; a listed error that is no longer found is taken out and counted).
    -> what the caller adds to its answer: "analyses" (the counts) and "analyses_words" (the end of the status sentence); when the records
    could not follow, "analyses_not_followed" says why in one sentence and "analyses_words" says it too. Never silent."""
    from agentic import pipeline
    try:
        r = pipeline.follow_renumbering(s, uid, moved, gone=gone or (), db=db)
    except pipeline.NumbersNotFollowed as e:
        return {"analyses_not_followed": str(e),
                "analyses_words": "the error lists of the analyses of this recording could NOT be followed (each analysis's errors page checks its numbers against "
                                  "the recording when it is opened and corrects them)"}
    return {"analyses": {k: r[k] for k in ("analyses", "lists", "entries", "moved", "elsewhere", "no_longer_found", "found_again", "not_certain", "by_rule")}, "analyses_words": r["words"]}


def _row(con, level, rowid):
    r = con.execute("SELECT * FROM %s WHERE rowid_file=?" % TABLE[level], (rowid,)).fetchone()
    if r is None:
        return None
    row = dict(r)
    row["raw"] = json.loads(row["raw"]) if row.get("raw") else {}
    row["level"] = level
    for k in ("t_ps", "delta_ps", "dur_ps"):
        if row.get(k) is not None:
            row[k + "_text"] = P.fmt_ps(row[k])
    return row


def _summary(level, row):
    """One line that names a row in plain words."""
    if not row:
        return ""
    if level == "nvme_command":
        return "%s, queue %s, command id %s" % (NAMES.opcode_name(row.get("opc"), row.get("sqid")), row.get("sqid"), row.get("cid"))
    if level == "nvme_transaction":
        return "%s%s" % (row.get("type") or "NVMe transaction", (" (queue %s, id %s)" % (row.get("sqid"), row.get("cid"))) if row.get("cid") is not None else "")
    if level == "split":
        return "%s request, tag %s, completion status %s" % (row.get("tlp_type") or "", row.get("tag"), row.get("cpl_status") or "-")
    if level == "link":
        return "%s %s, sequence number %s" % (row.get("dir") or "", row.get("tlp_type") or "", row.get("psn"))
    return "%s %s" % (row.get("dir") or "", row.get("tlp_type") or row.get("dllp_type") or row.get("os_type") or row.get("link_event") or "packet")


def _chain(con, level, rowid):
    """Rows from the finding's row up to its command: [(level, row)]."""
    out = []
    lv, rid = level, rowid
    while rid is not None and lv is not None:
        row = _row(con, lv, rid)
        if row is None:
            break
        out.append({"level": lv, "label": LEVEL_LABEL[lv], "rowid": rid, "n": row.get("n"), "summary": _summary(lv, row),
                    "t": row.get("raw", {}).get("Time Stamp"), "dur": row.get("dur_ps_text"), "errors": row.get("errors"), "row": row})
        lv, rid = row.get("parent_level"), row.get("parent")
        if lv == "nvme_command" and rid is not None and level != "nvme_command":
            row = _row(con, lv, rid)
            if row:
                out.append({"level": lv, "label": LEVEL_LABEL[lv], "rowid": rid, "n": row.get("n"), "summary": _summary(lv, row),
                            "t": row.get("raw", {}).get("Time Stamp"), "dur": row.get("dur_ps_text"), "errors": row.get("errors"), "row": row})
            break
    return out


CHILD_LEVELS = {"nvme_command": ["nvme_transaction"], "nvme_transaction": ["split", "link"], "split": ["link"], "link": ["packets"], "packets": []}


def _children(con, level, rowid, limit=20):
    """The rows one level down whose parent is this row (member rows first), at most `limit` per child level."""
    out = []
    for cl in CHILD_LEVELS.get(level, []):
        t = TABLE[cl]
        for r in con.execute("SELECT * FROM %s WHERE parent_level=? AND parent=? ORDER BY (relation='context'), rowid_file LIMIT ?" % t, (level, rowid, limit)):
            row = dict(r)
            row["raw"] = json.loads(row["raw"]) if isinstance(row.get("raw"), str) else (row.get("raw") or {})
            for k in ("t_ps", "delta_ps", "dur_ps"):
                if row.get(k) is not None:
                    row[k + "_text"] = P.fmt_ps(row[k])
            out.append({"level": cl, "label": LEVEL_LABEL[cl], "rowid": row["rowid_file"], "n": row.get("n"), "summary": _summary(cl, row),
                        "t": row.get("raw", {}).get("Time Stamp"), "dur": row.get("dur_ps_text"), "errors": row.get("errors"), "relation": row.get("relation"), "row": row})
    return out


def _below(con, level, rowid, per_level=12):
    """Everything under a row, level by level down to the packets: the first rows of each level (member rows first)."""
    levels, lv, rid = [], level, rowid
    while True:
        kids = _children(con, lv, rid, per_level)
        if not kids:
            break
        counts = {cl: con.execute("SELECT COUNT(*) FROM %s WHERE parent_level=? AND parent=?" % TABLE[cl], (lv, rid)).fetchone()[0] for cl in CHILD_LEVELS.get(lv, [])}
        levels.append({"under": lv, "under_label": LEVEL_LABEL[lv], "rows": kids, "counts": counts})
        first = next((k for k in kids if k["relation"] != "context"), kids[0])
        lv, rid = first["level"], first["rowid"]
    return levels


def _finding(con, fid):
    r = con.execute("SELECT * FROM finding WHERE id=?", (fid,)).fetchone()
    if r is None:
        return None
    f = dict(r)
    f["detail"] = json.loads(f["detail"]) if f.get("detail") else {}
    for k in ("t_ps", "value_ps", "limit_ps"):
        if f.get(k) is not None:
            f[k + "_text"] = P.fmt_ps(f[k])
    return f


def _device(con, meta):
    r = con.execute("SELECT mn FROM cmd WHERE mn IS NOT NULL LIMIT 1").fetchone() if "nvme_command" in L.get_meta(con, "levels_present", []) else None
    dev = (r[0] if r else None) or meta.get("device") or None
    fw = None
    r2 = con.execute("SELECT raw FROM cmd WHERE opc=6 AND sqid=0 LIMIT 50").fetchall() if dev else []
    for x in r2:
        raw = json.loads(x[0]) if x[0] else {}
        if raw.get("Controller Capabilities.FR"):
            fw = raw["Controller Capabilities.FR"]
            break
    return dev, fw or meta.get("firmware")


def _signature_of(con, meta, f, cmd_row):
    dev, fw = _device(con, meta)
    cause = "self"
    if f.get("cause_rule"):
        cause = f["cause_rule"]
    sig = SG.compute({"dev": dev, "fw": fw, "lvl": f["level"], "err": f["rule"],
                      "cmd": SG.cmd_key(NAMES.opcode_name(cmd_row.get("opc"), cmd_row.get("sqid")), cmd_row.get("sqid")) if cmd_row else "none",
                      "part": f.get("part") or "none", "cause": cause,
                      "st": SG.status_key(cmd_row.get("sct"), cmd_row.get("sc")) if cmd_row and (cmd_row.get("sct") is not None) else "none",
                      "dnr": (f.get("detail") or {}).get("DNR")})
    sig["device"], sig["firmware"] = dev, fw
    return sig


@bp.get("/api/hier/uploads/<uid>/findings")
def findings(uid):
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    try:
        con.execute("SELECT 1 FROM finding LIMIT 1")
    except sqlite3.Error:
        con.close()
        return jsonify({"findings": [], "total": 0, "by_level": {}, "by_rule": {}, "message": "the rules have not run yet"})
    where, args = ["1=1"], []
    for k in ("level", "rule", "severity"):
        v = request.args.get(k) or (request.args.get("kind") if k == "severity" else None)   # "kind" is the screen's word
        if v:
            where.append("%s=?" % k)
            args.append(v)
    if request.args.get("cmd"):
        where.append("cmd_rowid=?")
        args.append(whole(request.args.get("cmd"), "cmd"))
    w = " AND ".join(where)
    offset, limit, _after, _before, want_count = _page(request.args, default_limit=100, max_limit=1000)
    # count=0 (follow-up pages of the scrolling list): no COUNT and no GROUP BY over the whole table again
    total = con.execute("SELECT COUNT(*) FROM finding WHERE " + w, args).fetchone()[0] if want_count else None
    out = []
    # the roll-up column appears at the end of the rules run: the list can be asked for while the rules are still running
    role = "c.role" if any(x[1] == "role" for x in con.execute("PRAGMA table_info(cmd)")) else "NULL AS role"
    for r in con.execute("SELECT f.*, c.opc, c.sqid AS c_sqid, c.cid AS c_cid, c.n AS c_n, " + role + " FROM finding f LEFT JOIN cmd c ON c.rowid_file=f.cmd_rowid "
                         "WHERE " + w + " ORDER BY CASE severity WHEN 'error' THEN 0 WHEN 'check' THEN 1 ELSE 2 END, t_ps LIMIT ? OFFSET ?", args + [limit, offset]):
        f = dict(r)
        f["detail"] = json.loads(f["detail"]) if f.get("detail") else {}
        f["command"] = ("%s, queue %s, id %s (command %s)" % (NAMES.opcode_name(f["opc"], f["c_sqid"]), f["c_sqid"], f["c_cid"], f["c_n"])) if f.get("cmd_rowid") else "outside any command"
        for k in ("t_ps", "value_ps", "limit_ps"):
            if f.get(k) is not None:
                f[k + "_text"] = P.fmt_ps(f[k])
        f["level_label"] = LEVEL_LABEL[f["level"]]
        out.append(f)
    by_level = by_rule = by_sev = None
    rules_meta = {}
    if want_count:
        by_level = {r[0]: r[1] for r in con.execute("SELECT level, COUNT(*) FROM finding WHERE severity='error' GROUP BY level")}
        by_rule = {r[0]: r[1] for r in con.execute("SELECT rule, COUNT(*) FROM finding GROUP BY rule")}
        by_sev = {r[0]: r[1] for r in con.execute("SELECT severity, COUNT(*) FROM finding GROUP BY severity")}
        rules_meta = L.get_meta(con, "rules", {})
    con.close()
    return jsonify({"findings": out, "total": total, "offset": offset, "limit": limit, "has_more": len(out) == limit,
                    "by_level": by_level, "by_rule": by_rule, "by_severity": by_sev,
                    "limits": rules_meta.get("limits"), "level_labels": LEVEL_LABEL})


@bp.get("/api/hier/uploads/<uid>/findings/<int:fid>")
def finding_detail(uid, fid):
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    meta = read_meta(d) or {}
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    f = _finding(con, fid)
    if f is None:
        con.close()
        return jsonify({"error": "no such finding"}), 404
    f["level_label"] = LEVEL_LABEL[f["level"]]
    cat = RL.Catalogue()
    entry = None
    if f.get("cat_ref"):
        entry = cat.by_id.get(f["cat_ref"]) or cat.by_name.get(str(f["cat_ref"]).lower()) or cat.silent.get(str(f["cat_ref"]).lower())
        if entry is None:
            for e in cat.by_status.values():
                if e.get("error") == f["cat_ref"]:
                    entry = e
                    break
    f["catalogue"] = RL.brief(entry)
    f["basis"] = RL.basis(f.get("rule"))
    f["source_row"] = _row(con, f["level"], f["rowid"])
    f["chain"] = _chain(con, f["level"], f["rowid"])
    f["below"] = _below(con, f["level"], f["rowid"])
    f["observed_outcome"] = CH.observed_outcome(f)                 # what the recording shows at the fault
    f["expected_outcome_default"] = CH.expected_outcome_default(f) # first guess of what a correct device must do
    cmd_row = _row(con, "nvme_command", f["cmd_rowid"]) if f.get("cmd_rowid") else None
    f["command"] = {"rowid": f["cmd_rowid"], "summary": _summary("nvme_command", cmd_row), "row": cmd_row} if cmd_row else None
    f["other_findings_in_command"] = [dict(r) for r in con.execute(
        "SELECT id, level, rule, name, severity, row_n, t_ps FROM finding WHERE cmd_rowid=? AND id!=? ORDER BY t_ps", (f["cmd_rowid"], fid))] if f.get("cmd_rowid") else []
    f["cause"] = _finding(con, f["cause_finding"]) if f.get("cause_finding") else None
    sig = _signature_of(con, meta, f, cmd_row)
    f["signature"] = sig
    st = knowledge(s)
    st.touch_signature(sig, sig.get("device"), upload_id=uid, finding_id=fid)   # counted once per upload and finding, not per view
    f["knowledge"] = st.lookup(sig)
    f["chat"] = st.chat_history(uid, fid)
    f["levels_present"] = L.get_meta(con, "levels_present", [])
    con.close()
    return jsonify(f)


@bp.get("/api/hier/uploads/<uid>/findings/<int:fid>/window")
def finding_window(uid, fid):
    """n rows above and m rows below the fault at the chosen level (default: the command level, same queue)."""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    f = _finding(con, fid)
    if f is None:
        con.close()
        return jsonify({"error": "no such finding"}), 404
    con.close()
    level = request.args.get("level") or "nvme_command"
    if level not in LEVELS:
        level = "nvme_command"
    n_above, m_below = whole(request.args.get("n") or 5, message=NM), whole(request.args.get("m") or 5, message=NM)
    same_queue = request.args.get("queue", "same") == "same"
    w = _window(s, uid, fid, level, n_above, m_below, same_queue)     # one implementation for the page and the optimiser
    if w is None:
        return jsonify({"error": "no row at the %s level can be placed around this finding" % LEVEL_LABEL[level]}), 400
    return jsonify(w)


@bp.post("/api/hier/uploads/<uid>/findings/<int:fid>/signal")
def finding_signal(uid, fid):
    """body: {signal, procedure_id|null, admin, edited_steps?, edited_text?, proposal_steps?, proposal_text?, scenario_name?}"""
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    if body.get("signal") not in ST.SIGNALS:
        return jsonify({"error": "signal must be one of: " + ", ".join(ST.SIGNALS)}), 400
    admin = as_text(body.get("admin"), "admin").strip() or "admin"
    meta = read_meta(d) or {}
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    f = _finding(con, fid)
    if f is None:
        con.close()
        return jsonify({"error": "no such finding"}), 404
    cmd_row = _row(con, "nvme_command", f["cmd_rowid"]) if f.get("cmd_rowid") else None
    sig = _signature_of(con, meta, f, cmd_row)
    con.close()
    st = knowledge(s)
    try:
        r = st.signal(sig["fine"], body.get("procedure_id"), body["signal"], admin, edited_steps=body.get("edited_steps"),
                      edited_text=body.get("edited_text"), upload_id=uid, finding_id=fid, proposal_steps=body.get("proposal_steps"),
                      proposal_text=as_text(body.get("proposal_text"), "proposal_text") or None, scenario_name=as_text(body.get("scenario_name"), "scenario_name") or None, test_path=as_text(body.get("test_path"), "test_path") or None,
                      outcome=a_dict(body.get("outcome"), "outcome") or None)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    if body.get("scenario_name"):
        st.set_scenario_name(sig["fine"], body["scenario_name"], "admin:" + admin)
    return jsonify({"result": r, "knowledge": st.lookup(sig)})


@bp.post("/api/hier/uploads/<uid>/findings/<int:fid>/reorder")
def finding_reorder(uid, fid):
    s = svc()
    d = upload_dir(s, uid)
    if not d or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload"}), 404
    body = request.get_json(force=True) or {}
    meta = read_meta(d) or {}
    con = sqlite3.connect(db_of(d))
    con.row_factory = sqlite3.Row
    f = _finding(con, fid)
    cmd_row = _row(con, "nvme_command", f["cmd_rowid"]) if f and f.get("cmd_rowid") else None
    sig = _signature_of(con, meta, f, cmd_row) if f else None
    con.close()
    if not sig:
        return jsonify({"error": "no such finding"}), 404
    st = knowledge(s)
    st.reorder(sig["fine"], wholes(body.get("order"), "order"), as_text(body.get("admin"), "admin").strip() or "admin")
    return jsonify({"knowledge": st.lookup(sig)})


# ---------------------------------------------------------------------------------------------- chat, optimise, test case


def _detail_for_model(s, uid, fid):
    """The finding detail and the knowledge lookup, as the detail endpoint builds them (shared by chat and test case)."""
    with current_app_ctx(s, uid) as (d, meta, con):
        f = _finding(con, fid)
        if f is None:
            return None, None, None, None
        f["level_label"] = LEVEL_LABEL[f["level"]]
        cat = RL.Catalogue()
        entry = cat.by_id.get(f.get("cat_ref")) or cat.by_name.get(str(f.get("cat_ref")).lower()) or cat.silent.get(str(f.get("cat_ref")).lower())
        if entry is None and f.get("cat_ref"):
            for e in cat.by_status.values():
                if e.get("error") == f["cat_ref"]:
                    entry = e
                    break
        f["catalogue"] = RL.brief(entry)
        f["basis"] = RL.basis(f.get("rule"))
        f["chain"] = _chain(con, f["level"], f["rowid"])
        cmd_row = _row(con, "nvme_command", f["cmd_rowid"]) if f.get("cmd_rowid") else None
        f["command"] = {"rowid": f["cmd_rowid"], "summary": _summary("nvme_command", cmd_row), "row": cmd_row} if cmd_row else None
        f["cause"] = _finding(con, f["cause_finding"]) if f.get("cause_finding") else None
        sig = _signature_of(con, meta, f, cmd_row)
        f["signature"] = sig
        return f, sig, cmd_row, meta


class current_app_ctx:
    def __init__(self, s, uid):
        self.s, self.uid = s, uid

    def __enter__(self):
        d = upload_dir(self.s, self.uid)
        if not d or not os.path.exists(db_of(d)):
            raise FileNotFoundError("no such upload")
        self.con = sqlite3.connect(db_of(d))
        self.con.row_factory = sqlite3.Row
        return d, (read_meta(d) or {}), self.con

    def __exit__(self, *a):
        self.con.close()
        return False


def _window(s, uid, fid, level, n, m, same_queue):
    with current_app_ctx(s, uid) as (d, meta, con):
        f = _finding(con, fid)
        if f is None:
            return None
        chain = _chain(con, f["level"], f["rowid"])
        anchor = next((c["row"] for c in chain if c["level"] == level), None)
        note = ""
        if anchor is None and f.get("cmd_rowid") and level == "nvme_command":
            anchor = _row(con, "nvme_command", f["cmd_rowid"])
        if anchor is None and LEVELS.index(level) > LEVELS.index(f["level"]):
            # a level BELOW the finding's row: the first member row under it, level by level (split -> its request link -> its packet)
            lv, rid = f["level"], f["rowid"]
            while lv != level:
                kids = [k for k in _children(con, lv, rid, 5) if k["relation"] != "context"] or _children(con, lv, rid, 1)
                if not kids:
                    break
                lv, rid = kids[0]["level"], kids[0]["rowid"]
            if lv == level:
                anchor = _row(con, level, rid)
                note = "the window is around the first %s inside the %s that fired" % (LEVEL_LABEL[level], LEVEL_LABEL[f["level"]])
        if anchor is None and f.get("t_ps") is not None:
            # a level ABOVE a row that belongs to no parent: the nearest row at that level in time, said so
            r = con.execute("SELECT * FROM %s WHERE t_ps<=? ORDER BY t_ps DESC, rowid_file DESC LIMIT 1" % TABLE[level], (f["t_ps"],)).fetchone()
            if r is None:
                r = con.execute("SELECT * FROM %s ORDER BY t_ps, rowid_file LIMIT 1" % TABLE[level]).fetchone()
            if r is not None:
                anchor = dict(r)
                anchor["raw"] = json.loads(anchor["raw"]) if isinstance(anchor.get("raw"), str) else (anchor.get("raw") or {})
                note = "this %s belongs to no %s (outside any command), so the window is placed by time only: the %s nearest before it" % (LEVEL_LABEL[f["level"]], LEVEL_LABEL[level], LEVEL_LABEL[level])
        if anchor is None:
            return None
        t = TABLE[level]
        cond, args = "", []
        if level == "nvme_command" and same_queue and anchor.get("sqid") is not None:
            cond, args = " AND sqid=?", [anchor["sqid"]]
        above = [dict(r) for r in con.execute("SELECT * FROM %s WHERE rowid_file<?%s ORDER BY rowid_file DESC LIMIT ?" % (t, cond), [anchor["rowid_file"]] + args + [n])][::-1]
        below = [dict(r) for r in con.execute("SELECT * FROM %s WHERE rowid_file>?%s ORDER BY rowid_file LIMIT ?" % (t, cond), [anchor["rowid_file"]] + args + [m])]
        rows = []
        for pos, lst in (("above", above), ("fault", [anchor]), ("below", below)):
            for r in lst:
                r = dict(r)
                r["raw"] = json.loads(r["raw"]) if isinstance(r.get("raw"), str) else (r.get("raw") or {})
                for k in ("t_ps", "delta_ps", "dur_ps"):
                    if r.get(k) is not None:
                        r[k + "_text"] = P.fmt_ps(r[k])
                r["position"] = pos
                r["summary"] = _summary(level, r)
                r["findings"] = [dict(x) for x in con.execute("SELECT id, rule, name, severity FROM finding WHERE level=? AND rowid=?", (level, r["rowid_file"]))]
                if level != "nvme_command":
                    # which command this row belongs to (up the parent columns), so a window at a low level still shows the commands
                    top = _chain(con, level, r["rowid_file"])
                    cmd = next((c for c in top if c["level"] == "nvme_command"), None)
                    r["command"] = cmd["summary"] if cmd else "outside any command"
                    r["command_rowid"] = cmd["rowid"] if cmd else None
                    r["below_count"] = {cl: con.execute("SELECT COUNT(*) FROM %s WHERE parent_level=? AND parent=?" % TABLE[cl], (level, r["rowid_file"])).fetchone()[0] for cl in CHILD_LEVELS.get(level, [])}
                rows.append(r)
        for i in range(1, len(rows)):
            a, b = rows[i - 1].get("t_ps"), rows[i].get("t_ps")
            rows[i]["gap_text"] = P.fmt_ps(b - a) if a is not None and b is not None else ""
        return {"level": level, "label": LEVEL_LABEL[level], "n": n, "m": m, "same_queue": same_queue, "rows": rows, "anchor_rowid": anchor["rowid_file"], "note": note}


@bp.post("/api/hier/uploads/<uid>/findings/<int:fid>/optimise")
def finding_optimise(uid, fid):
    """body: {level, n, m, same_queue} -> the window with keep/why per row and the minimal sequence."""
    s = svc()
    body = request.get_json(force=True) or {}
    try:
        w = _window(s, uid, fid, body.get("level") or "nvme_command", whole(body.get("n") or 5, message=NM), whole(body.get("m") or 5, message=NM), body.get("same_queue", True))
    except (TypeError, ValueError, OverflowError):
        return jsonify({"error": "n and m must be whole numbers"}), 400
    except FileNotFoundError:
        return jsonify({"error": "no such upload"}), 404
    if w is None:
        return jsonify({"error": "no row at that level"}), 400
    if w["level"] != "nvme_command":
        return jsonify({"error": "the sequence optimisation works on the command level; extract the window at the command level"}), 400
    out = OPT.optimise(w["rows"])
    out["window"] = {k: v for k, v in w.items() if k != "rows"}
    return jsonify(out)


@bp.post("/api/hier/uploads/<uid>/findings/<int:fid>/chat")
def finding_chat(uid, fid):
    """body: {message, admin, level, n, m, same_queue}. The model gets the finding, the window and the stored procedures."""
    s = svc()
    body = request.get_json(force=True) or {}
    admin = as_text(body.get("admin"), "admin").strip() or "admin"
    try:
        f, sig, cmd_row, meta = _detail_for_model(s, uid, fid)
        w = _window(s, uid, fid, body.get("level") or "nvme_command", whole(body.get("n") or 5, message=NM), whole(body.get("m") or 5, message=NM), body.get("same_queue", True))
    except (TypeError, ValueError, OverflowError):
        return jsonify({"error": "n and m must be whole numbers"}), 400
    except FileNotFoundError:
        return jsonify({"error": "no such upload"}), 404
    if f is None:
        return jsonify({"error": "no such finding"}), 404
    if w is None:
        w = {"level": "nvme_command", "label": "NVMe command", "n": 0, "m": 0, "rows": [], "same_queue": True}
    st = knowledge(s)
    know = st.lookup(sig)
    if know.get("exact") and not body.get("anyway"):
        # the owner's rule: a signature that already has a stored procedure is not sent to the model again,
        # unless the admin explicitly asks for a new proposal ("a new proposal anyway")
        return jsonify({"error": "this fault is already stored (%d procedure%s for this signature); use a stored procedure, or tick \"a new proposal anyway\""
                        % (len(know["exact"]), "" if len(know["exact"]) == 1 else "s"), "stored": len(know["exact"])}), 409
    llm = getattr(getattr(s, "s2", None), "llm", None)
    message = as_text(body.get("message"), "message")
    st.chat_append(uid, fid, sig["fine"], "admin:" + admin, message, {"window": {k: v for k, v in w.items() if k != "rows"}})
    ans = CH.ask(llm, f, w, know, message)
    st.chat_append(uid, fid, sig["fine"], ans.get("producer", "model"), ans.get("summary", ""), ans)
    if ans.get("scenario_name") and not know.get("scenario_name"):
        st.set_scenario_name(sig["fine"], ans["scenario_name"], ans.get("producer", "model"))
    return jsonify({"answer": ans, "history": st.chat_history(uid, fid)})


@bp.post("/api/hier/uploads/<uid>/findings/<int:fid>/testcase")
def finding_testcase(uid, fid):
    """body: {steps (the agreed sequence), scenario_name, admin, procedure_id?}. Writes suite/hier/<upload>_<finding>_v<n>.py."""
    s = svc()
    body = request.get_json(force=True) or {}
    try:
        f, sig, cmd_row, meta = _detail_for_model(s, uid, fid)
    except FileNotFoundError:
        return jsonify({"error": "no such upload"}), 404
    if f is None:
        return jsonify({"error": "no such finding"}), 404
    steps = dicts(body.get("steps"), "steps")
    if not steps:
        w = _window(s, uid, fid, "nvme_command", whole(body.get("n") or 5, message=NM), whole(body.get("m") or 5, message=NM), body.get("same_queue", True))
        steps = OPT.optimise(w["rows"])["steps"] if w else []
    if not steps:
        return jsonify({"error": "no sequence to turn into a test"}), 400
    if not any(st_.get("position") == "fault" for st_ in steps):
        steps[-1]["position"] = "fault"
    for i, st_ in enumerate(steps):
        st_["step"] = i + 1
    suite = os.path.join(s.root, "suite", "hier")
    os.makedirs(suite, exist_ok=True)
    version = 1 + len([x for x in os.listdir(suite) if x.startswith("%s_f%d_" % (uid, fid))])
    name = "%s_f%d_v%d.py" % (uid, fid, version)
    nsid = (cmd_row or {}).get("nsid") or 1
    text = TC.generate(f, steps, sig, as_text(body.get("scenario_name"), "scenario_name") or (knowledge(s).lookup(sig).get("scenario_name")), uid, version=version,
                       device=sig.get("device"), firmware=sig.get("firmware"), nsid=nsid, name=name, outcome=a_dict(body.get("outcome"), "outcome") or None)
    path = os.path.join(suite, name)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    if body.get("procedure_id"):
        knowledge(s).set_test_path(whole(body.get("procedure_id"), "procedure_id"), path)
    return jsonify({"path": path, "name": name, "version": version, "text": text, "steps": steps})


# ---------------------------------------------------------------------------------------------- one row of a file, with its meanings (owner, 2026-11-10:
# "when someone clicks on that number, it has to show by opening the particular file: this is the place, this is the meaning of the error")
@bp.get("/api/hier/uploads/<uid>/rowcard")
def rowcard(uid):
    """level, rowid -> the file (full path), the row (and its spreadsheet line), every non-empty cell with Family 1's approved meaning, and the
    defects found on that row with the rule's reason and source. Read only."""
    from agentic import rule_evidence as RE
    s = svc()
    d = upload_dir(s, uid)
    level = request.args.get("level")
    if not d or level not in LEVELS or not os.path.exists(db_of(d)):
        return jsonify({"error": "no such upload or level"}), 404
    try:
        rowid = whole(request.args.get("rowid"), message="the row must be a whole number")
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    meta = read_meta(d) or {}
    con = sqlite3.connect("file:%s?mode=ro" % db_of(d), uri=True)
    con.row_factory = sqlite3.Row
    try:
        r = con.execute("SELECT * FROM %s WHERE rowid_file=?" % TABLE[level], (rowid,)).fetchone()
        if r is None:
            return jsonify({"error": "row %s is not in this file" % rowid}), 404
        r = dict(r)
        raw = json.loads(r["raw"]) if isinstance(r.get("raw"), str) else (r.get("raw") or {})
        found = [dict(x) for x in con.execute("SELECT id, rule, name, severity, value_ps, limit_ps FROM finding WHERE level=? AND rowid=? ORDER BY id", (level, rowid))]
        cmd = _row(con, "nvme_command", r["parent"]) if level == "nvme_transaction" and r.get("parent_level") == "nvme_command" else None
    finally:
        con.close()
    meanings = RE._meanings(level)
    cells = [{"column": k, "value": v, "meaning": (meanings.get(k) or ("",))[0], "source": (meanings.get(k) or ("", ""))[1]} for k, v in raw.items() if v not in ("", None)]
    for f in found:
        b = _RL.basis(f["rule"])
        f["rule_words"] = RULE_WORDS.get(f["rule"]) or f["rule"]
        f["why"] = b.get("text") or ""
        f["source"] = b.get("words") or ""
    path = (meta.get("files") or {}).get(level) or ""
    return jsonify({"level": level, "level_label": LEVEL_LABEL[level], "file": os.path.basename(path) or level, "path": path, "row": rowid,
                    "spreadsheet_line": rowid + 1, "analyzer_number": r.get("n"), "cells": cells, "defects": found,
                    "meanings_from": "Family 1's approved dictionary" if meanings else "no approved dictionary for this file yet",
                    "parent": {"level": r.get("parent_level"), "rowid": r.get("parent")} if r.get("parent") else None, "command": (cmd or {}).get("rowid_file")})
