"""Configuration: LLM endpoint / model / effort, stage-2 budgets, picker starting folders. Keys never leave the environment."""
import json

from flask import Blueprint, jsonify, request

from nvme_hier import loader as L

from . import ACTION_HELP, svc

bp = Blueprint("config", __name__)


def save_config(cfg):
    out = {k: v for k, v in cfg.items() if not k.startswith("_")}
    L.write_json_atomic(cfg["_path"], out, indent=2)


# The three switches the Settings of the flow pages show (2026-11-15). Exactly these values are taken; anything else is refused in plain
# words before anything of the request is saved. (section, key) -> (the allowed values, the switch in words, its values in words)
SWITCHES = {
    ("stage2", "search_memory"): ((True, False), "“start each search from what earlier searches learned” (stage 2)", "on (true) or off (false)"),
    ("tree", "round_rule"): ((True, False), "“a packet whose number comes round again is its own link transaction” (the tree)", "on (true) or off (false)"),
    ("agentic", "f4_recheck"): (("always", "ask", "never"), "“the recheck of the finished code by the terminal agent” (Family 4)",
                                "always (when the terminal agent is ready), ask (only when the admin asks on the card) or never"),
}
OWN_SECTIONS = ("tree", "agentic")       # of these two sections this address saves the switch above and nothing else


def switch_problem(body):
    """-> one plain sentence when the request cannot be taken for the three switches, else None. The value that was sent is never repeated
    in the sentence: it may be huge or not printable."""
    if not isinstance(body, dict):
        return "The settings must be sent as named settings in groups (a JSON object). What was sent is not, so nothing was saved."
    for sec in OWN_SECTIONS:
        if sec in body and not isinstance(body[sec], dict):
            return "The group “%s” must hold named settings. What was sent is not, so nothing was saved." % sec
    for (sec, key), (allowed, words, values) in SWITCHES.items():
        part = body.get(sec)
        if not isinstance(part, dict) or key not in part:
            continue
        v = part[key]
        ok = isinstance(v, bool) if allowed == (True, False) else (isinstance(v, str) and v in allowed)
        if not ok:
            return "The switch %s takes only %s. What was sent is not one of these, so nothing was saved." % (words, values)
    return None


@bp.get("/api/config")
def get_config():
    s = svc()
    c = {k: v for k, v in s.cfg.items() if not k.startswith("_")}
    return jsonify({"config": c, "llm_active": getattr(s.s2.llm, "name", "stand-in"), "actions": ACTION_HELP, "root": s.root})


@bp.put("/api/config")
def put_config():
    s = svc()
    body = request.get_json(force=True) or {}
    problem = switch_problem(body)             # the three switches: a value that is not allowed is refused before anything is saved
    if problem:
        return jsonify({"error": problem}), 400
    if (s.cfg.get("server") or {}).get("lock_endpoint"):
        # production: where the API key is sent is fixed in the config file;
        # the Settings page may still change the model, effort and stage-2 limits
        locked = {"llm": ("base_url", "api_key_env", "backend", "tools")}
        for sec, keys in locked.items():
            for k in keys:
                if k in (body.get(sec) or {}) and body[sec][k] != (s.cfg.get(sec) or {}).get(k):
                    return jsonify({"error": "%s.%s is locked by server.lock_endpoint: stop the service, edit the config file, start it again" % (sec, k)}), 403
    from agentic import policy as _policy
    if not _policy.api_allowed(s.cfg):          # with API calls off the packets page cannot choose a backend that calls a model address
        b = (body.get("llm") or {}).get("backend") if isinstance(body.get("llm"), dict) else None
        if b is not None and b not in ("opencode", "standin") and b != (s.cfg.get("llm") or {}).get("backend"):
            return jsonify({"error": _policy.NOT_ALLOWED}), 403
    for sec in ("llm", "stage1", "stage2", "paths"):
        if sec in body and isinstance(body[sec], dict):
            s.cfg[sec].update({k: v for k, v in body[sec].items() if not k.startswith("_")})
    for sec, key in SWITCHES:                   # the tree's and the agents' switch: that one key only (the agents' other settings have their own address)
        if sec in OWN_SECTIONS and key in (body.get(sec) or {}):
            s.cfg.setdefault(sec, {})[key] = body[sec][key]
    save_config(s.cfg)
    s.s2.reload_llm()
    return jsonify({"ok": True, "llm_active": getattr(s.s2.llm, "name", "stand-in")})
