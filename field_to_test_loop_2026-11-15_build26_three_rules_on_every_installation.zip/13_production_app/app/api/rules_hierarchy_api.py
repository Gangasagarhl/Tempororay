"""The hierarchy of the rules library: Section -> Kind of recording -> Level -> items (agentic/rule_hierarchy.py).

    GET    /api/agents/rule-hierarchy                       the whole hierarchy, with the label of every kind and level in its section
    POST   /api/agents/rule-hierarchy/kinds                 add a kind of recording        {label, about, admin}
    PUT    /api/agents/rule-hierarchy/kinds/<kid>           edit one the admin added       {label, about, admin}
    DELETE /api/agents/rule-hierarchy/kinds/<kid>           delete one that holds no level {admin}
    POST   /api/agents/rule-hierarchy/kinds/<kid>/levels    add a level under a kind       {label, file, about, admin}
    PUT    /api/agents/rule-hierarchy/levels/<lid>          edit one the admin added       {label, file, about, admin}
    DELETE /api/agents/rule-hierarchy/levels/<lid>          delete one that holds no item  {admin}
    POST   /api/agents/rule-hierarchy/levels/<lid>/groups   add a group inside an analyzer level {name, about, admin, section?}
    DELETE /api/agents/rule-hierarchy/levels/<lid>/groups/<gid>  delete a group the admin added that holds no item {admin}
    PUT    /api/agents/rule-hierarchy/sections/<sid>        edit a section the admin added {label, about, admin}
    DELETE /api/agents/rule-hierarchy/sections/<sid>        delete one that holds no item  {admin}
    POST   /api/agents/rule-hierarchy/items                 add an item at a place         {section, level, group, name, description, admin, project}

In the answer of GET, a level gives the items that are in no group under "items" and the others under "groups" (each
group: name, about, more, stated, items). In the body of POST .../items, "group" is the name of one of the groups inside
a built-in level, or absent / empty for no group; it is not the admin's level (that one is given as "level").

Every refusal is HTTP 400 (or 404 for a thing that does not exist) with one plain sentence under "error". The item key
section/level/id is not changed by anything here. The blueprint is registered in app/server.py by the coordinator.
"""
import os
import sys

from flask import Blueprint, jsonify, request

from . import whole

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
from agentic import rule_hierarchy as RH   # noqa: E402

bp = Blueprint("rules_hierarchy", __name__)


def _body():
    b = request.get_json(force=True, silent=True)
    return b if isinstance(b, dict) else {}


def _admin(body):
    a = body.get("admin")
    if a is None or a == "":
        return "admin"
    if not isinstance(a, str) or "\x00" in a or len(a) > 200:
        raise ValueError("the admin's name must be a short text")
    return a.strip() or "admin"


def _answer(fn):
    """Runs one change; a refusal is a sentence with 400, a missing thing 404."""
    try:
        return jsonify(dict(fn(), hierarchy=RH.hierarchy()))
    except LookupError as e:
        return jsonify({"error": str(e.args[0]) if e.args else "no such thing"}), 404
    except ValueError as e:
        return jsonify({"error": str(e)}), 400


@bp.get("/api/agents/rule-hierarchy")
def rule_hierarchy():
    return jsonify(RH.hierarchy())


@bp.post("/api/agents/rule-hierarchy/kinds")
def add_kind():
    b = _body()
    return _answer(lambda: {"kind": RH.add_kind(b.get("label"), b.get("about"), _admin(b))})


@bp.put("/api/agents/rule-hierarchy/kinds/<kid>")
def edit_kind(kid):
    b = _body()
    return _answer(lambda: {"kind": RH.edit_kind(kid, b.get("label"), b.get("about"), _admin(b))})


@bp.delete("/api/agents/rule-hierarchy/kinds/<kid>")
def delete_kind(kid):
    b = _body()
    return _answer(lambda: RH.delete_kind(kid, _admin(b)))


@bp.post("/api/agents/rule-hierarchy/kinds/<kid>/levels")
def add_level(kid):
    b = _body()
    return _answer(lambda: {"level": RH.add_level(kid, b.get("label"), b.get("file"), b.get("about"), _admin(b))})


@bp.put("/api/agents/rule-hierarchy/levels/<lid>")
def edit_level(lid):
    b = _body()
    return _answer(lambda: {"level": RH.edit_level(lid, b.get("label"), b.get("file"), b.get("about"), _admin(b))})


@bp.delete("/api/agents/rule-hierarchy/levels/<lid>")
def delete_level(lid):
    b = _body()
    return _answer(lambda: RH.delete_level(lid, _admin(b)))


@bp.post("/api/agents/rule-hierarchy/levels/<lid>/groups")
def add_group(lid):
    """A group inside one of the analyzer's five levels: {name, about, admin, section (optional: one section's id; left out = every section)}."""
    b = _body()
    return _answer(lambda: {"group": RH.add_group(lid, b.get("name"), b.get("about"), _admin(b), section=b.get("section"))})


@bp.delete("/api/agents/rule-hierarchy/levels/<lid>/groups/<gid>")
def delete_group(lid, gid):
    """A group the admin added that holds no item (by its id, as hierarchy() gives it, or by its name)."""
    b = _body()
    return _answer(lambda: RH.delete_group(lid, gid, _admin(b)))


@bp.put("/api/agents/rule-hierarchy/sections/<sid>")
def edit_section(sid):
    b = _body()
    return _answer(lambda: {"section": RH.edit_section(sid, b.get("label"), b.get("about"), _admin(b))})


@bp.delete("/api/agents/rule-hierarchy/sections/<sid>")
def delete_section(sid):
    b = _body()
    return _answer(lambda: RH.delete_section(sid, _admin(b)))


@bp.post("/api/agents/rule-hierarchy/items")
def add_item():
    """An item at a place of the hierarchy: {section, level (a built-in level or a level the admin added), group (the
    name of one of the level's groups, or nothing), name, description, admin, project}. With a project (the Rules library), the Rule writer starts on it at once, as the
    older route /api/agents/rules does."""
    b = _body()

    def go():
        project = b.get("project")
        pid = whole(project, "project") if project not in (None, "", False) else None
        r = RH.add_item(b.get("section"), b.get("level"), b.get("name"), b.get("description"), _admin(b), group=b.get("group"))
        out = {"rule": r, "key": "%s/%s/%s" % (r["section"], r["level"], r["id"])}
        if pid is not None:
            from . import agentic_api
            out["run"] = agentic_api.engine().start(pid, "rule_draft", r["name"], {"_kind": "rule_draft", "section": r["section"], "level": r["level"], "id": r["id"],
                                                                                 "message": (r.get("description") or r["name"])})
        return out
    return _answer(go)
