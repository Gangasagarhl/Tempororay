"""The procedural graph of defects, causes and solutions (nvme_hier/defect_graph.py), for the flow's stage 2 and the page.

  GET  /api/dg/defects?rule=            the stored defects (those of this rule first)
  GET  /api/dg/defects/<id>             one defect with its causes and their solutions, ranked
  POST /api/dg/defects                  store a defect under its standard name (an existing name is returned, never copied)
  POST /api/dg/causes                   store a cause under a defect
  POST /api/dg/occurrences              one occurrence of a defect with the cause the admin named (device and firmware kept with it)
  POST /api/dg/solutions                store a solution: the error sequence and the optimized sequence
  POST /api/dg/solutions/<id>/verdict   one of the four signals on a stored solution
  POST /api/dg/optimized                the model proposes the optimized sequence (the admin edits it before it is stored)

What proved a result is kept in the knowledge base (nvme_hier/archive.py, 2026-11-14):
  POST /api/dg/trace                    keep the rows of the window around one error now (the admin's own request)
  GET  /api/dg/trace?upload=&finding=   the archived rows of one error; works after the upload is deleted (level= one level, rows=0 the record only)
  GET  /api/dg/occurrences/<id>/trace   the same, for one occurrence of a defect
  GET  /api/dg/defects/<id>/traces      which occurrences of a defect have their rows kept
  POST /api/dg/workloads                store an external workload with its result, as given (never validated here)
  GET  /api/dg/workloads                the stored workload records (defect_id=, occurrence_id=)
  GET  /api/dg/workloads/<id>           one record with its definition and its result
  POST /api/dg/workloads/<id>/validate  the admin's own action: validated (who, when), or the validation taken back
  GET  /api/dg/across?defect=           one defect in both knowledge bases (the main flow's and the earlier packet workflow's)
The rows are also kept, without a request of their own, when an occurrence is recorded and when a solution is stored or judged
(archive_trace below; the routes of the error page call it too).
"""
import os
import sys

from flask import Blueprint, jsonify, request

from . import svc, as_text, a_dict

APP = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if APP not in sys.path:
    sys.path.insert(0, APP)
from nvme_hier import defect_graph as DG   # noqa: E402
from nvme_hier import isolate as ISO       # noqa: E402
from nvme_hier import archive as AR        # noqa: E402

bp = Blueprint("dg", __name__)


def graph(s):
    if not hasattr(s, "defect_graph"):
        s.defect_graph = DG.DefectGraph(os.path.join(s.root, "db", "hier_knowledge.sqlite"))
    return s.defect_graph


def _admin(body):
    a = as_text(body.get("admin"), "admin").strip()
    if not a:
        raise ValueError("say who you are (your name) first")
    return a


def _int(v, what):
    try:
        x = int(v)
    except (TypeError, ValueError, OverflowError):
        raise ValueError("%s must be a whole number" % what)
    if not -(1 << 63) <= x < (1 << 63):          # SQLite holds 64-bit numbers (parameter fuzz, 2026-11-11)
        raise ValueError("%s is too large" % what)
    return x


@bp.errorhandler(ValueError)
def _bad(e):
    return jsonify({"error": str(e)}), 400


def _body():
    """The request's named fields; anything else (a list, a number, text that is not JSON) is refused in words."""
    b = request.get_json(force=True, silent=True)
    if not isinstance(b, dict):
        raise ValueError("the request must be a set of named fields (a JSON object)")
    return b


def _kb(s):
    return graph(s).path


def _flow_wait(b):
    """The order of the flow (owner, 2026-11-15: "you should not go directly wherever you want"): stage 2 work on one error (its occurrence,
    its cause, its solution, the proposed optimized sequence) starts only after the admin approved the result of the pattern that found
    the error. -> None when the request may go on, else the refusal (HTTP 409, one plain sentence), the same answer the routes of the
    page of one error give (app/api/isolate_api.py _flow_refusal; the rule itself is agentic/pipeline.error_page_refusal).
    A request that names no error (no upload_id or no finding_id) is not about one error's page and behaves as before; a value of another
    kind than the route expects is left to the route's own check."""
    if not isinstance(b, dict):
        return None
    up, fid = b.get("upload_id"), b.get("finding_id")
    if not isinstance(up, str) or not up or isinstance(fid, bool) or not isinstance(fid, (int, str)) or fid == "":
        return None
    try:
        fid = int(fid)
        from .hier_api import upload_dir, db_of
        d = upload_dir(svc(), up)
    except (TypeError, ValueError, OverflowError, OSError):
        return None
    if not d or not os.path.exists(db_of(d)) or not -(1 << 62) < fid < (1 << 62):
        return None
    from agentic import pipeline
    why = pipeline.error_page_refusal(svc(), up, db_of(d), fid)
    return (jsonify({"error": why, "waits_for": "the approval of the pattern's result on page 3"}), 409) if why else None


def archive_trace(s, upload_id, finding_id, by, reason, n=None, m=None, same_queue=None):
    """Keep the rows of the window around one error in the knowledge base, so they stay when the upload is deleted. For every route that
    validates something about an error (the isolation kept, the occurrence recorded, a solution stored or judged, the test approved).
    n, m: the numbers of commands above and below the admin's window used (none given: the window archived before, else 15 and 15).
    It never fails the action it follows: -> {"archived": yes or no, "words": what happened, in plain words, "record": the archive's record}."""
    try:
        from .hier_api import upload_dir, db_of, read_meta, _device
        uid = AR.upload_name(upload_id)
        d = upload_dir(s, uid)
        tree_db = db_of(d) if d and os.path.exists(db_of(d)) else None
        meta = (read_meta(d) or {}) if d else {}
        device = firmware = None
        if tree_db:
            import sqlite3
            from pathlib import Path
            try:                             # the recording's own device and firmware texts, when the tree has them (read-only)
                con = sqlite3.connect(Path(tree_db).as_uri() + "?mode=ro", uri=True)
                try:
                    device, firmware = _device(con, meta)
                finally:
                    con.close()
            except Exception:                # noqa: BLE001  the texts are optional; the occurrence's own texts are used instead
                device = firmware = None
        files = meta.get("files") if isinstance(meta.get("files"), dict) else {}
        names = {lv: os.path.basename(str(p)) for lv, p in files.items() if p and lv in AR.T.LEVELS}
        r = graph(s).archive_trace(tree_db, uid, finding_id, by, reason, n=n, m=m, same_queue=same_queue, files=names,
                                   device=device or None, firmware=firmware or None, trace_name=meta.get("trace_name") or None)
        words = "The rows around this error are kept in the knowledge base (%s; %s): they stay when the upload is deleted." % (r["window_words"], r["size_words"])
        if not r["complete"]:
            words += " " + r["left_out"].get("words", "")
        return {"archived": True, "words": words, "did": r["did"], "record": {k: v for k, v in r.items() if k != "log"}}
    except ValueError as e:
        return {"archived": False, "words": "The rows around this error were not kept in the knowledge base: %s." % e, "record": None}
    except Exception as e:                   # noqa: BLE001  archiving follows an action that is already stored: it must not undo or fail it
        return {"archived": False, "words": "The rows around this error were not kept in the knowledge base (%s: %s)." % (type(e).__name__, e), "record": None}


def _window_arg(b):
    """The admin's window when the request carries it: (n, m, same queue only) or nothing."""
    n = AR.whole(b["n"], "the number of commands above", most=AR.MAX_NEIGHBOURS) if b.get("n") not in (None, "") else None
    m = AR.whole(b["m"], "the number of commands below", most=AR.MAX_NEIGHBOURS) if b.get("m") not in (None, "") else None
    q = b.get("queue")
    return n, m, (q == "same") if q in ("same", "all") else None


@bp.get("/api/dg/defects")
def defects():
    term = request.args.get("term")
    if term:                         # one defect by its fixed term: is it in the procedural graph?
        d = graph(svc()).find_defect(term_key=term)
        return jsonify({"defect": graph(svc()).view(d["id"]) if d else None})
    return jsonify({"defects": graph(svc()).defects(request.args.get("rule"))})


@bp.get("/api/dg/terms")
def term_list():
    """The fixed cause keywords (the dictionary), for the page."""
    from nvme_hier import terms as TM
    return jsonify({"version": TM.VERSION, "causes": TM.cause_choices()})


@bp.get("/api/dg/defects/<int:did>")
def defect(did):
    v = graph(svc()).view(did)
    if v is None:
        return jsonify({"error": "no such defect"}), 404
    return jsonify(v)


@bp.post("/api/dg/defects")
def add_defect():
    b = request.get_json(force=True) or {}
    did, created = graph(svc()).add_defect(as_text(b.get("name"), "name"), b.get("rule"), b.get("level"), as_text(b.get("what"), "what"), _admin(b),
                                           term_key=as_text(b.get("term_key"), "term_key") or None)
    return jsonify({"id": did, "created": created})


@bp.post("/api/dg/causes")
def add_cause():
    b = request.get_json(force=True) or {}
    _wait = _flow_wait(b)                # the order of the flow: the pattern's result is approved first (only when the request names an error)
    if _wait:
        return _wait
    g = graph(svc())
    did = _int(b.get("defect_id"), "defect_id")
    if g.defect(did) is None:
        return jsonify({"error": "no such defect"}), 404
    kw = as_text(b.get("keyword"), "keyword")
    if kw:                           # a fixed keyword of the dictionary: its side and words come from it, never typed
        from nvme_hier import terms as TM
        c = TM.cause_of(kw)
        if c is None:
            return jsonify({"error": "not a keyword of the dictionary: %s" % kw}), 400
        cid, created = g.add_cause(did, c["side"], c["name"], _admin(b), keyword=kw)
    else:
        cid, created = g.add_cause(did, as_text(b.get("side"), "side"), as_text(b.get("header"), "header"), _admin(b))
    return jsonify({"id": cid, "created": created})


@bp.post("/api/dg/occurrences")
def add_occurrence():
    b = request.get_json(force=True) or {}
    _wait = _flow_wait(b)                # the order of the flow: the pattern's result is approved first
    if _wait:
        return _wait
    g = graph(svc())
    did = _int(b.get("defect_id"), "defect_id")
    cid = _int(b.get("cause_id"), "cause_id") if b.get("cause_id") not in (None, "") else None
    if g.defect(did) is None or (cid and (g.cause(cid) or {}).get("defect_id") != did):
        return jsonify({"error": "no such defect, or the cause is not one of its causes"}), 404
    n, m, same = _window_arg(b)
    oid = g.record_occurrence(did, cid, as_text(b.get("upload_id"), "upload_id"), _int(b.get("finding_id"), "finding_id"), b.get("device"), b.get("firmware"),
                              a_dict(b.get("isolation"), "isolation"), _admin(b))
    # the admin named this error's defect: the rows that show it are kept with it
    kept = archive_trace(svc(), b.get("upload_id"), b.get("finding_id"), _admin(b), "the admin recorded this error as an occurrence of a defect", n, m, same)
    return jsonify({"id": oid, "trace": kept})


@bp.post("/api/dg/solutions")
def add_solution():
    b = request.get_json(force=True) or {}
    _wait = _flow_wait(b)                # the order of the flow: the pattern's result is approved first (only when the request names an error)
    if _wait:
        return _wait
    g = graph(svc())
    cid = _int(b.get("cause_id"), "cause_id")
    if g.cause(cid) is None:
        return jsonify({"error": "no such cause"}), 404
    admin = _admin(b)
    n, m, same = _window_arg(b)
    sid, rid = g.add_solution(cid, b.get("error_seq"), b.get("optimized"), as_text(b.get("note"), "note"), b.get("producer") or "admin:%s" % admin, admin,
                              b.get("upload_id"), b.get("finding_id"))
    out = {"id": sid, "revision_id": rid, "solution": g.solution(sid)}
    if b.get("upload_id") not in (None, "") and b.get("finding_id") not in (None, ""):
        out["trace"] = archive_trace(svc(), b.get("upload_id"), b.get("finding_id"), admin, "a solution was stored for this error", n, m, same)
    return jsonify(out)


@bp.post("/api/dg/solutions/<int:sid>/verdict")
def verdict(sid):
    b = request.get_json(force=True) or {}
    n, m, same = _window_arg(b)
    r = graph(svc()).verdict(sid, as_text(b.get("signal"), "signal"), _admin(b), b.get("occurrence_id"), b.get("device"), b.get("firmware"),
                             b.get("error_seq"), b.get("optimized"), b.get("note"))
    if b.get("occurrence_id") is not None:
        o = graph(svc()).occurrence(b.get("occurrence_id"))
        if o is not None:
            r["trace"] = archive_trace(svc(), o["upload_id"], o["finding_id"], _admin(b), "a solution was judged on this error", n, m, same)
    return jsonify(r)


@bp.post("/api/dg/optimized")
def optimized():
    """The model's proposal of the optimized sequence; nothing is stored here."""
    from .isolate_api import _llm, _load, _ok_upload
    from .isolate_api import _as_job, _progress
    s = svc()
    b = request.get_json(force=True) or {}
    _wait = _flow_wait(b)                # the order of the flow: the pattern's result is approved first; refused before a background job is started
    if _wait:
        return _wait
    if request.args.get("job") == "1":
        return _as_job(b)
    uid, fid = as_text(b.get("upload_id"), "upload_id"), _int(b.get("finding_id"), "finding_id")
    if not _ok_upload(s, uid):
        return jsonify({"error": "no such upload"}), 404
    ctx = _load(s, uid, fid)
    if ctx is None:
        return jsonify({"error": "no such finding"}), 404
    prompt = ISO.optimized_prompt(ctx["f"], ctx["device"], a_dict(b.get("isolation"), "isolation"), a_dict(b.get("cause"), "cause"), b.get("error_seq") or [])
    _progress(b, 20, "the model proposes the optimized sequence for this cause")
    ans, producer = ISO.call_model(_llm(s, b), prompt, ISO.OPTIMIZED_SCHEMA, "lines")
    if ans is None:
        return jsonify({"lines": [], "note": "No model answered: write the optimized sequence yourself, one action per line.", "producer": producer, "standin": True})
    return jsonify({"lines": DG.clean_lines(ans.get("lines")), "note": " ".join(str(ans.get("note") or "").split()), "producer": producer, "standin": False})


@bp.post("/api/dg/revisions/<int:rid>/test")
def revision_test(rid):
    """The approved test file of one version of a solution (stage 3)."""
    b = request.get_json(force=True) or {}
    path = as_text(b.get("path"), "path")
    if not path or not os.path.exists(path):
        return jsonify({"error": "no such test file"}), 400
    graph(svc()).set_test_path(rid, path)
    return jsonify({"ok": True})


@bp.get("/api/dg/status")
def status():
    """Where each error of one recording stands in the procedural graph (the errors page shows it)."""
    up = request.args.get("upload") or ""
    try:
        ids = [_int(x, "findings") for x in (request.args.get("findings") or "").split(",") if x.strip()][:500]
    except ValueError:
        return jsonify({"error": "findings must be whole numbers, separated by commas"}), 400
    return jsonify({"status": graph(svc()).status(up, ids)})


@bp.post("/api/dg/term_requests")
def term_request():
    """A note to the dictionary's keeper: "this is not the same kind of defect" (the name stays as the code made it until the dictionary changes)."""
    import json as _json
    import time as _time
    b = request.get_json(force=True) or {}
    note = as_text(b.get("note"), "note").strip()
    if not note:
        return jsonify({"error": "write the note"}), 400
    rec = {"at": _time.time(), "admin": _admin(b), "term_key": as_text(b.get("term_key"), "term_key"), "term_name": as_text(b.get("term_name"), "term_name"),
           "note": note[:2000], "upload_id": as_text(b.get("upload_id"), "upload_id"), "finding_id": b.get("finding_id")}
    d = os.path.join(svc().root, "knowledge", "dictionary")
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "term_requests.jsonl"), "a", encoding="utf-8") as fh:
        fh.write(_json.dumps(rec) + "\n")
    return jsonify({"ok": True})


# ---------------------------------------------------------------------------------------------- what proved a result is kept
def _number(v, what, least=1):
    """A whole number written in the address or the query, or a refusal in words."""
    if isinstance(v, str) and v.strip().lstrip("-").isdigit() and len(v.strip()) <= 20:
        v = int(v.strip())
    elif isinstance(v, str):
        raise ValueError("%s must be a whole number" % what)
    return AR.whole(v, what, least=least)


def _levels(v):
    if v in (None, ""):
        return None
    want = [x.strip() for x in str(v).split(",") if x.strip()]
    bad = [x for x in want if x not in AR.T.LEVELS]
    if bad:
        raise ValueError("no such level. The levels are: %s" % ", ".join(AR.T.LEVELS))
    return want


@bp.post("/api/dg/trace")
def keep_trace():
    """The admin asks to keep the rows of the window around one error now."""
    b = _body()
    admin = _admin(b)
    uid = AR.upload_name(b.get("upload_id"))
    fid = AR.whole(b.get("finding_id"), "the error's number")
    n, m, same = _window_arg(b)
    out = archive_trace(svc(), uid, fid, admin, AR.name_text(b.get("reason"), "the reason", most=300, needed=False) or "the admin asked to keep these rows", n, m, same)
    if not out["archived"]:
        return jsonify({"error": out["words"]}), 400
    return jsonify(out)


@bp.get("/api/dg/trace")
def read_trace():
    """The archived rows of one error, from the knowledge base alone."""
    uid = AR.upload_name(request.args.get("upload"))
    fid = _number(request.args.get("finding") or "", "the error's number", least=0)
    w = graph(svc()).archived_trace(uid, fid, levels=_levels(request.args.get("level")), rows=request.args.get("rows") != "0")
    if w is None:
        return jsonify({"error": "no rows are archived for this error of this upload"}), 404
    return jsonify(w)


@bp.get("/api/dg/occurrences/<oid>/trace")
def occurrence_trace(oid):
    w = graph(svc()).archived_trace(occurrence_id=_number(oid, "the occurrence's number"), levels=_levels(request.args.get("level")),
                                    rows=request.args.get("rows") != "0")
    if w is None:
        return jsonify({"error": "no rows are archived for this occurrence, or there is no such occurrence"}), 404
    return jsonify(w)


@bp.get("/api/dg/defects/<did>/traces")
def defect_traces(did):
    g = graph(svc())
    did = _number(did, "the defect's number")
    if g.defect(did) is None:
        return jsonify({"error": "no such defect"}), 404
    return jsonify(g.archived_traces(did))


@bp.post("/api/dg/workloads")
def add_workload():
    """An external workload with its result, kept as given. It is not validated here: that is the admin's own action on the stored record."""
    b = _body()
    if "validated" in b or "validated_by" in b or "validated_at" in b:
        raise ValueError("a workload record is stored first and validated afterwards, by the admin's own action on the stored record")
    wid = AR.add_workload(_kb(svc()), b.get("tool"), b.get("definition"), b.get("result"), _admin(b),
                          defect_id=b.get("defect_id") if b.get("defect_id") not in (None, "") else None,
                          occurrence_id=b.get("occurrence_id") if b.get("occurrence_id") not in (None, "") else None, note=b.get("note"))
    return jsonify({"id": wid, "workload": AR.workload(_kb(svc()), wid)})


@bp.get("/api/dg/workloads")
def list_workloads():
    a = request.args
    return jsonify({"workloads": AR.workloads(_kb(svc()), defect_id=_number(a.get("defect_id"), "the defect's number") if a.get("defect_id") else None,
                                              occurrence_id=_number(a.get("occurrence_id"), "the occurrence's number") if a.get("occurrence_id") else None),
                    "limits": {"definition": AR.megabytes(AR.DEFINITION_LIMIT_BYTES), "result": AR.megabytes(AR.RESULT_LIMIT_BYTES)}})


@bp.get("/api/dg/workloads/<wid>")
def one_workload(wid):
    w = AR.workload(_kb(svc()), _number(wid, "the workload record's number"))
    if w is None:
        return jsonify({"error": "no such workload record"}), 404
    return jsonify(w)


@bp.post("/api/dg/workloads/<wid>/validate")
def validate_workload(wid):
    b = _body()
    w = AR.validate_workload(_kb(svc()), _number(wid, "the workload record's number"), _admin(b), b.get("confirm"), withdraw=b.get("withdraw") is True)
    if w is None:
        return jsonify({"error": "no such workload record"}), 404
    return jsonify(w)


@bp.get("/api/dg/across")
def across():
    """One defect in both knowledge bases; a link is reported only when the data holds one."""
    s = svc()
    a = request.args
    if a.get("defect_id"):
        key = _number(a.get("defect_id"), "the defect's number")
    else:
        key = AR.name_text(a.get("defect"), "the defect's key or name", most=400)
    r = AR.across_stores(_kb(s), os.path.join(s.root, "db", "knowledge.sqlite"), key)
    if r is None:
        return jsonify({"error": "no such defect in the main flow's knowledge base"}), 404
    return jsonify(r)


# ---------------------------------------------------------------------------------------------- lab evidence and timing (2026-11-15)
# Kept apart from the judgements (nvme_hier/graph_learning.py): no route here writes a verdict or changes the order by judgements.
#   GET  /api/dg/solutions/<id>/lab          the lab rows of a stored solution and its lab lines per bench
#   POST /api/dg/solutions/<id>/lab          one lab result brought in: {admin, bench: "simulated"|"real", source, runs, reproduced, timing?, ...}
#   GET  /api/dg/defects/<id>/lab            every lab row of a kind of defect
#   GET  /api/dg/defects/<id>/timing         the timing brackets: ?cause_id=&bench=simulated|real&model=&firmware=
def _sid(v, what="the solution"):
    x = _int(v, what)
    if not 0 < x < (1 << 62):
        raise ValueError("%s must be the number of a stored item" % what)
    return x


@bp.get("/api/dg/solutions/<sid>/lab")
def solution_lab(sid):
    g = graph(svc())
    sol = g.solution(_sid(sid))
    if sol is None:
        return jsonify({"error": "no such stored solution"}), 404
    return jsonify({"solution_id": sol["id"], "judged_words": sol["judged_words"], "lab": sol["lab"], "rows": g.lab_rows(solution_id=sol["id"]), "timing": g.seq_timing(sol["id"]),
                    "note": "Lab runs and judgements are kept apart: a lab run never changes 'judged correct s of n' or the order the solutions are shown in."})


@bp.post("/api/dg/solutions/<sid>/lab")
def add_solution_lab(sid):
    b = _body()
    g = graph(svc())
    solution_id = _sid(sid)
    if g.solution(solution_id) is None:
        return jsonify({"error": "no such stored solution"}), 404
    fid = b.get("finding_id")
    rid = g.add_lab(solution_id, as_text(b.get("bench"), "bench"), as_text(b.get("source"), "source"), b.get("runs"), b.get("reproduced"), _admin(b),
                    revision_id=b.get("revision_id"), timing=b.get("timing"), fault_time_us=b.get("fault_time_us"), model=b.get("model"), firmware=b.get("firmware"),
                    upload_id=b.get("upload_id"), finding_id=fid, note=b.get("note"))
    return jsonify({"id": rid, "lab": g.solution(solution_id)["lab"], "did": ["one lab row was added to this solution", "no judgement and no order changed"]})


@bp.get("/api/dg/defects/<did>/lab")
def defect_lab(did):
    g = graph(svc())
    d = g.defect(_sid(did, "the defect"))
    if d is None:
        return jsonify({"error": "no such defect"}), 404
    return jsonify({"defect_id": d["id"], "rows": g.lab_rows(defect_id=d["id"])})


@bp.get("/api/dg/defects/<did>/timing")
def defect_timing(did):
    g = graph(svc())
    d = g.defect(_sid(did, "the defect"))
    if d is None:
        return jsonify({"error": "no such defect"}), 404
    a = request.args
    cause = _sid(a.get("cause_id"), "the cause") if a.get("cause_id") not in (None, "") else None
    for k in ("model", "firmware"):
        if len(a.get(k) or "") > 200:
            raise ValueError("the %s text is too long (more than 200 characters)" % k)
    br = g.timing_brackets(d["id"], cause, a.get("bench") or "simulated", a.get("model") or None, a.get("firmware") or None)
    return jsonify({"defect_id": d["id"], "cause_id": cause, "brackets": br,
                    "words": "nothing is stored yet for this kind of defect on this bench" if br is None else "%s, %s" % (br["basis_words"], br["level_words"]),
                    "what": "A bracket is computed from counts at a value (table dg_timing): the largest value at which the failure still came back and the smallest "
                            "at which it did not. Nothing is trained and nothing is decayed."})
