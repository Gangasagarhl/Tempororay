"""The errors a rule found in a CSV file that is not part of the tree, and the page of one such error (agentic/other_errors.py).

  GET  /other-error                                      the page (?run=<analysis run>&error=<error number>)
  GET  /api/other-errors/<run>                           the errors of other files of one run: per rule, how many, the first ones (offset, limit)
  GET  /api/other-errors/<run>/<error>                   one error: its row, every column with its value and Family 1's meaning with its source,
                                                         the columns for which "only rows with the same value" may be offered, what the page cannot do
  GET  /api/other-errors/<run>/<error>/window            the rows around it (?n=&m=&same=<column>)
  POST /api/other-errors/<run>/<error>/group-column      the admin names a column as an identifier or a group {column, admin, why}
  POST /api/other-errors/<run>/<error>/isolate           isolate the defect {n, m, same, admin, standin}
  GET  /api/other-errors/<run>/<error>/isolations        the isolations kept for the error
  GET  /api/other-errors/<run>/mapping?file=<name>       what the NVMe command path would need of the file, by the dictionary (a report only)

Every refusal is a plain sentence with HTTP 400 (bad input) or 404 (nothing of that number): never a failure inside a route.
"""
import copy
import os
import re

from flask import Blueprint, current_app, jsonify, request, send_from_directory

from . import svc
from .agentic_api import engine
from agentic import other_errors as OE   # noqa: E402

bp = Blueprint("other_error", __name__)


class _Bad(Exception):
    def __init__(self, words, code=400):
        Exception.__init__(self, words)
        self.words, self.code = words, code


@bp.errorhandler(_Bad)
def _bad(e):
    return jsonify({"error": e.words}), e.code


@bp.errorhandler(OE.Refused)
def _refused(e):
    return jsonify({"error": str(e)}), 400


def _number(text, what):
    """A number in the address: a whole number of 1 or more, written in digits."""
    if not isinstance(text, str) or not re.fullmatch(r"[0-9]{1,15}", text) or int(text) < 1:
        raise _Bad("%s must be a whole number of 1 or more, written in digits" % what)
    return int(text)


def _text(value, what, most=300):
    if value is None:
        return ""
    if not isinstance(value, str):
        raise _Bad("%s must be text" % what)
    if "\x00" in value:
        raise _Bad("%s holds a character that cannot be part of a name (the NUL character)" % what)
    if len(value) > most:
        raise _Bad("%s is longer than %d characters" % (what, most))
    return value


def _body():
    b = request.get_json(force=True, silent=True)
    if b is None:
        if request.get_data(cache=True).strip():
            raise _Bad("the request must be a set of named fields, written as JSON")
        return {}
    if not isinstance(b, dict):
        raise _Bad("the request must be a set of named fields")
    return b


def _around(value, name):
    """n or m exactly as OE.around takes it; a query string gives text, a JSON body a number or nothing."""
    if value is not None and not isinstance(value, (int, str)) or isinstance(value, bool):
        raise _Bad("the number of rows %s must be a whole number from 0 to %d" % (name, OE.MAX_AROUND))
    if isinstance(value, str) and "\x00" in value:
        raise _Bad("the number of rows %s must be a whole number from 0 to %d" % (name, OE.MAX_AROUND))
    return value


def _run(run):
    rid = _number(run, "the number of the analysis run")
    eng = engine()
    row = eng.store.one("SELECT * FROM run WHERE id=?", (rid,))
    if not row:
        raise _Bad("there is no analysis run number %d" % rid, 404)
    project = eng.store.one("SELECT * FROM project WHERE id=?", (row["project"],)) or {}
    return eng, rid, project, OE.store_path(eng.runner.sandbox_root, rid)


def _error(run, error):
    eng, rid, project, db = _run(run)
    eid = _number(error, "the number of the error")
    err = OE.get_error(db, eid)
    if err is None:
        raise _Bad("run %d has no error number %d in a CSV file outside the tree" % (rid, eid), 404)
    return eng, rid, project, db, err


def _rule_words(err):
    """The rule in the admin's own words: the item's description and the steps of its procedure (nothing is reworded)."""
    from agentic import family3, procedures as PR
    try:
        sec, lvl, rid = err["item"].split("/")
        r = family3.load_rule(sec, lvl, rid.split("#")[0]) or {}
    except ValueError:
        r = {}
    proc = PR.procedure_of(r) if r else None
    return {"name": err["rule"], "admin_words": r.get("description") or "", "steps": list((proc or {}).get("steps") or []),
            "section": (family3.SECTION_INFO.get(r.get("section")) or {}).get("label") or ""}


def _llm(body):
    """The configured model, or None for the stand-in (also when the request asks for the stand-in)."""
    from nvme_hier import isolate as ISO
    if body.get("standin") is True or request.args.get("standin") == "1":
        return None
    llm = getattr(getattr(svc(), "s2", None), "llm", None)
    if not ISO.is_model(llm):
        return None
    if hasattr(llm, "system"):
        llm = copy.copy(llm)
        llm.system = OE.SYSTEM
    return llm


@bp.get("/other-error")
def other_error_page():
    return send_from_directory(current_app.static_folder, "other_error.html")


@bp.get("/api/other-errors/<run>")
def other_errors_list(run):
    _eng, rid, project, db = _run(run)
    offset = request.args.get("offset", "0")
    limit = request.args.get("limit", str(OE.HEAD))
    if not re.fullmatch(r"[0-9]{1,12}", offset) or not re.fullmatch(r"[0-9]{1,4}", limit) or not 1 <= int(limit) <= 1000:
        raise _Bad("offset must be a whole number of 0 or more and limit a whole number from 1 to 1,000")
    item = _text(request.args.get("item"), "the item") or None
    rules = OE.listings(db)
    return jsonify({"run": rid, "kind": OE.KIND, "analysis": project.get("name") or "", "rules": rules,
                    "total": sum(x["total"] for x in rules if not item or x["item"] == item),
                    "errors": [dict(e, link="/other-error?run=%d&error=%d" % (rid, e["error"])) for e in OE.list_errors(db, item, int(offset), int(limit))],
                    "offset": int(offset), "limit": int(limit),
                    "texts": {"title": "Errors in CSV files that are not part of the tree",
                              "about": "Rows that a rule of a section that finds defects found in a CSV file outside the tree. Each row has a page of its own: the row "
                                       "with the meaning of every column, the rows around it in the file, and the isolation of the defect.",
                              "cannot": OE.CANNOT_DO, "open": "Open this error's page", "where": "Where in the file", "rule": "Found by the rule",
                              "none": "No rule has listed an error in a CSV file outside the tree in this analysis."}})


@bp.get("/api/other-errors/<run>/<error>")
def other_error_one(run, error):
    _eng, rid, project, db, err = _error(run, error)
    d = OE.dictionary_of(project.get("folder"), err["file"])
    cols = OE.column_meanings(d, err["header"])
    cells = err["cells"]
    for i, c in enumerate(cols):
        c["value"] = cells[i] if i < len(cells) else ""
        c["value_meaning"] = c["values"].get(str(c["value"]).strip(), "")
    extra = [{"position": i + 1, "value": v} for i, v in enumerate(cells) if i >= len(cols)]
    return jsonify({"run": rid, "kind": OE.KIND, "error": err["error"], "item": err["item"], "rule": _rule_words(err), "file": err["file"], "row": err["row"],
                    "file_rows": err["file_rows"], "analysis": project.get("name") or "", "folder": project.get("folder") or "",
                    "where": "Row %s of %s rows of %s. Row 1 is the first row under the line of column names." % (
                        "{:,}".format(err["row"]), "{:,}".format(err["file_rows"]), err["file"]),
                    "dictionary": {"approved": bool(d), "version": (d or {}).get("version"), "approved_by": (d or {}).get("approved_by"),
                                   "words": ("Meanings come from Family 1's approved dictionary of %s." % err["file"]) if d else
                                            ("Family 1's dictionary of %s is not approved, so no column of this row has a meaning yet." % err["file"])},
                    "columns": cols, "cells_beyond_the_header": extra,
                    "window_default": {"n": OE.DEFAULT_ABOVE, "m": OE.DEFAULT_BELOW, "most": OE.MAX_AROUND, "why": OE.DEFAULT_AROUND_REASON},
                    "same_value_columns": OE.group_columns(db, d, err["header"], err["file"]),
                    "same_value_rule": "The choice 'only rows with the same value' is offered only for a column that the approved dictionary or the admin names as an "
                                       "identifier or a group. The code never guesses such a column from its name or its contents.",
                    "all_columns": list(err["header"]),
                    "isolations": OE.isolations(db, err["error"]),
                    "cannot": {"words": OE.CANNOT_DO, "would_need": OE.WOULD_NEED, "mapping": OE.nvme_command_mapping(d)}})


@bp.get("/api/other-errors/<run>/<error>/window")
def other_error_window(run, error):
    _eng, _rid, _project, db, err = _error(run, error)
    same = _text(request.args.get("same"), "the column") or None
    w = OE.window(db, err["error"], _around(request.args.get("n"), "above"), _around(request.args.get("m"), "below"), same)
    return jsonify(w)


@bp.post("/api/other-errors/<run>/<error>/group-column")
def other_error_group_column(run, error):
    _eng, _rid, project, db, err = _error(run, error)
    b = _body()
    column = b.get("column")
    if not isinstance(column, str) or not column:
        raise _Bad("name the column: its exact name in the file's line of column names")
    admin = _text(b.get("admin"), "the admin's name", 80).strip()
    if not admin:
        raise _Bad("say who names the column: the admin's name is kept with it")
    OE.name_group_column(db, err["file"], err["header"], _text(column, "the column"), admin, _text(b.get("why"), "the reason", 300))
    d = OE.dictionary_of(project.get("folder"), err["file"])
    return jsonify({"same_value_columns": OE.group_columns(db, d, err["header"], err["file"])})


@bp.post("/api/other-errors/<run>/<error>/isolate")
def other_error_isolate(run, error):
    from nvme_hier import isolate as ISO
    _eng, _rid, project, db, err = _error(run, error)
    b = _body()
    admin = _text(b.get("admin"), "the admin's name", 80).strip()
    if not admin:
        raise _Bad("say who asks for the isolation: the admin's name is kept with it")
    if b.get("standin") not in (None, True, False):
        raise _Bad("standin must be true or false")
    same = b.get("same")
    if same is not None and not isinstance(same, str):
        raise _Bad("the column for 'only rows with the same value' must be a column's name")
    same = _text(same, "the column") or None
    d = OE.dictionary_of(project.get("folder"), err["file"])
    if same is not None and same not in [c["column"] for c in OE.group_columns(db, d, err["header"], err["file"])]:
        raise _Bad("%r is not a column that the dictionary or the admin named as an identifier or a group; name it first" % same[:80])
    rw = _rule_words(err)
    words = rw["admin_words"] or " ".join(rw["steps"])
    out = OE.isolate(db, err["error"], OE.column_meanings(d, err["header"]), words[:1200], admin, _around(b.get("n"), "above"), _around(b.get("m"), "below"), same,
                     llm=_llm(b), call_model=ISO.call_model)
    return jsonify(out)


@bp.get("/api/other-errors/<run>/<error>/isolations")
def other_error_isolations(run, error):
    _eng, _rid, _project, db, err = _error(run, error)
    return jsonify({"isolations": OE.isolations(db, err["error"])})


@bp.get("/api/other-errors/<run>/mapping")
def other_error_mapping(run):
    from agentic import procedures as PR
    _eng, rid, project, _db = _run(run)
    name = _text(request.args.get("file"), "the file's name")
    if not name or not PR.other_csv_ok(name) or os.path.basename(name) != name:
        raise _Bad("give the file by its name alone (for example trace.csv): a path is not accepted")
    from agentic import family1
    folder = project.get("folder")
    if not folder or not any(f["name"] == name for f in family1.inventory(folder)):
        raise _Bad("the analysis of run %d has no CSV file named %s" % (rid, name), 404)
    d = OE.dictionary_of(folder, name)
    return jsonify(dict(OE.nvme_command_mapping(d), file=name, cannot=OE.CANNOT_DO, would_need=OE.WOULD_NEED))
