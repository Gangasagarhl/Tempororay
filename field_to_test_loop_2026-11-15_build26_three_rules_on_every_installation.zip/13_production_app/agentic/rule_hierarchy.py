"""The hierarchy of the rules library as the screens show it (owner, 2026-11-15: "you need to put everything in a proper
hierarchy ... he must not be confused what to add, when to add, how to add, where to add"):

    Section  ->  Kind of recording  ->  Level  ->  items

Nothing about the stored item changes: an item is still knowledge/rules/<section>/<level>/<id>.json and its key is still
"section/level/id" (routes, the flow's step keys "f3:<section>/<level>/<id>:<step>", the tests).

  * A KIND OF RECORDING is a grouping of levels, for the screens only. Two are built in (BUILTIN_KINDS): the analyzer's
    five-file export with its five levels in the owner's order from the top, and "Other CSV files (any tool)" with the
    level "other". The admin's own kinds are kept in knowledge/rules/kinds.json, which this module writes only when the
    admin adds, edits or deletes something (a library of the previous version has no such file and is shown with the
    two built-in kinds; nothing is written to open it).
  * A LEVEL the admin adds is a NAMED GROUP OF "OTHER CSV FILES" ITEMS with the file it reads (a file name of the
    folder, or a pattern such as  bench_*.csv ). Its items are stored at the level "other" with the field "group" = the
    level's id, so the key stays  <section>/other/<id>  and every route, step key and test goes on working; the screens
    show the group as a level of its own under its kind. Its rules run exactly like "Other CSV files" items: the
    procedure names its file and never reads the tree; the Rule writer is told the file of the level (files_of_level).
  * The label of a built-in kind and level depends on the section: a table in this module (BUILTIN_KINDS, LEVEL_WORDS)
    holds two names, one for a section that gives results only ("NVMe command level") and one for a section whose
    items find defects ("NVMe command level errors", under the heading "NVMe errors"). A kind or level the admin added
    has the one name the admin gave it, shown as given in every section.
  * A GROUP OF ITEMS INSIDE A LEVEL (2026-11-15: about forty rule families under one level are unusable as one flat
    list). An item stored at one of the analyzer's five levels may carry the field "group": the NAME of the group it is
    listed in, inside its level. hierarchy() returns such items under their group ("groups" of the level) and the
    others directly under the level ("items"). The order of the groups and the meaning of each come from the module
    that seeds the level's items (GROUP_SOURCES); a group no such module states is shown by its name alone, after the
    stated ones. A group exists because a module states it, because an item names it, or because the admin added it
    (add_group, 2026-11-15: kept in kinds.json under "groups", shown after the stated groups, deletable while empty).

THE FIELD "group" IS USED FOR TWO THINGS, TOLD APART BY THE ITEM'S STORED LEVEL (never by the text of the field):
    stored level "other"                   -> "group" is the id of a level the admin added      (level_of_item / group_of)
    stored level one of the five analyzer  -> "group" is the name of a group inside that level  (item_group_of)
An item of an analyzer level is therefore never moved to an admin's level, whatever its "group" says, and a group name
is never read from an "other" item. add_item() writes the field the same way and refuses a group for an "other" item.

No Unix-only module; every text file is opened with encoding="utf-8".
"""
import fnmatch
import importlib
import json
import os
import re
import time

from . import family3 as F3

LECROY, OTHER_KIND = "lecroy_nvme_pcie", "other_csv"
ANALYTICS = "analytics"             # the section Data analytics: its kinds say that each rule reads one CSV file on its own
BUILTIN_KINDS = [
    {"id": LECROY, "label": "NVMe and PCIe recording (Teledyne LeCroy five-file export)", "errors_label": "NVMe errors", "builtin": True,
     "about": "The five files the Teledyne LeCroy analyzer exports from one recording. Their rules can read the tree that joins the five files.",
     # under Data analytics (owner, 2026-11-15): each rule reads one CSV file on its own, never the tree
     "analytics_about": "The five files the Teledyne LeCroy analyzer exports from one recording. Each rule reads one CSV file of the recording "
                        "on its own; the tree is not used here.",
     "levels": ["nvme_command", "nvme_transaction", "split", "link", "packets"]},          # the owner's order, from the top
    {"id": OTHER_KIND, "label": "Other CSV files (any tool)", "errors_label": "Errors in other CSV files (any tool)", "builtin": True,
     "about": "Any CSV file of the folder that is not one of the analyzer's five exports. A rule here names its file in its procedure and never reads the tree.",
     "levels": ["other"]},
]
# built-in level -> (its name in a section that gives results only, its name in a section whose items find defects)
LEVEL_WORDS = {
    "nvme_command": ("NVMe command level", "NVMe command level errors"),
    "nvme_transaction": ("NVMe transaction level", "NVMe transaction level errors"),
    "split": ("Split transaction level", "Split transaction level errors"),
    "link": ("Link transaction level", "Link transaction level errors"),
    "packets": ("PCIe packet level", "PCIe packet level errors"),
    "other": ("Other CSV files", "Errors in other CSV files"),
}
NAME_MAX, ABOUT_MAX, FILE_MAX, ITEM_NAME_MAX, WORDS_MAX = 60, 400, 120, 120, 20000
# the groups of items inside a level: (section, level) -> (the module that seeds that level's items, its list of (name, meaning)).
# The order of the list is the order on the screens; the meaning is that module's own text, never written here.
GROUP_SOURCES = {("errors", "nvme_command"): ("nvme_hier.command_error_rules", "GROUPS")}
GROUP_NAME_MAX = 80
FIVE_ONLY = ("the five levels of this kind are the five files the analyzer exports, and the application reads them with its own code: a level "
             "cannot be added here. Add it under 'Other CSV files (any tool)' or under a kind of recording you added")


def kinds_file():
    return os.path.join(F3.rules_root(), "kinds.json")


def _load():
    """The admin's kinds and levels; an absent or damaged file reads as none. Never writes."""
    d = F3._read_json(kinds_file(), None)
    if not isinstance(d, dict):
        d = {}
    return {"kinds": [k for k in d.get("kinds") or [] if isinstance(k, dict) and isinstance(k.get("id"), str) and isinstance(k.get("label"), str)],
            "levels": [l for l in d.get("levels") or [] if isinstance(l, dict) and isinstance(l.get("id"), str) and isinstance(l.get("label"), str)],
            # the groups the admin added inside one of the analyzer's five levels (add_group): {id, level, section ("" = every section), name, about}
            "groups": [g for g in d.get("groups") or [] if isinstance(g, dict) and isinstance(g.get("id"), str) and isinstance(g.get("name"), str)
                       and g.get("level") in F3.ANALYZER_LEVELS]}


def _save(data):
    p = kinds_file()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump({"kinds": data["kinds"], "levels": data["levels"], "groups": data.get("groups") or []}, fh, indent=1)
    F3.OSF.replace(tmp, p)


# ------------------------------------------------------------------------------------------------ what a request may say
def clean_name(value, what, limit=NAME_MAX, path_free=True):
    """A name typed by the admin: text, one line, not empty, short, and (for a section, kind or level) not a path."""
    if not isinstance(value, str):
        raise ValueError("the name of %s must be text" % what)
    if "\x00" in value:
        raise ValueError("the name of %s holds a character that cannot be stored (a NUL character): type the name again" % what)
    name = " ".join(value.split())
    if not name:
        raise ValueError("give %s a name" % what)
    if len(name) > limit:
        raise ValueError("keep the name of %s under %d characters (this one has %d)" % (what, limit, len(name)))
    if path_free and ("/" in name or "\\" in name or ".." in name):
        raise ValueError("the name of %s cannot be a path: leave out '/', '\\' and '..'" % what)
    if any(ord(c) < 32 for c in name):
        raise ValueError("the name of %s holds a control character: type the name again" % what)
    return name


def clean_words(value, what, limit=ABOUT_MAX):
    if value is None:
        return ""
    if not isinstance(value, str):
        raise ValueError("%s must be text" % what)
    if "\x00" in value:
        raise ValueError("%s holds a character that cannot be stored (a NUL character): type it again" % what)
    text = value.strip()
    if len(text) > limit:
        raise ValueError("keep %s under %d characters (this one has %d)" % (what, limit, len(text)))
    return text


def clean_file(value):
    """The file a level reads: a file name of the folder, or a pattern with * and ?. Never a path."""
    if not isinstance(value, str):
        raise ValueError("the file of a level must be text: a file name, or a pattern such as bench_*.csv")
    if "\x00" in value:
        raise ValueError("the file of a level holds a character that cannot be stored (a NUL character): type it again")
    name = value.strip()
    if not name:
        raise ValueError("say which file the level reads: a file name of the folder, or a pattern such as bench_*.csv")
    if len(name) > FILE_MAX:
        raise ValueError("keep the file name or pattern under %d characters (this one has %d)" % (FILE_MAX, len(name)))
    if "/" in name or "\\" in name or ".." in name or ":" in name:
        raise ValueError("the file of a level is a file name or a pattern, not a path: the file is looked for in the folder of the analysis")
    if not re.match(r"^[A-Za-z0-9 _.\-*?()\[\]+,=#@&']+$", name):
        raise ValueError("the file name or pattern holds a character a file name cannot have: use letters, digits, spaces, . _ - and the pattern signs * and ?")
    return name


def _slug(label, taken, prefix=""):
    sid = prefix + (re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")[:40] or "x")
    base, n = sid, 2
    while sid in taken:
        sid, n = "%s_%d" % (base, n), n + 1
    return sid


def _same(a, b):
    return " ".join(str(a).split()).lower() == " ".join(str(b).split()).lower()


# ------------------------------------------------------------------------------------------------ reading
def _builtin_level(level):
    from . import rule_evidence
    return {"id": level, "level": level, "group": None, "label": LEVEL_WORDS[level][0], "errors_label": LEVEL_WORDS[level][1], "builtin": True,
            "file": "", "about": rule_evidence.LEVEL_ABOUT.get(level, "")}


def _admin_level(l):
    return {"id": l["id"], "level": "other", "group": l["id"], "label": l["label"], "errors_label": l["label"], "builtin": False,
            "file": l.get("file", ""), "about": l.get("about", ""), "created_by": l.get("created_by"), "created": l.get("created")}


def kinds(data=None):
    """Every kind of recording with its levels, in the order the screens show them: the two built-in kinds, then the admin's."""
    data = data or _load()
    out = []
    for b in BUILTIN_KINDS:
        k = {"id": b["id"], "label": b["label"], "errors_label": b["errors_label"], "about": b["about"], "builtin": True,
             "analytics_about": b.get("analytics_about") or b["about"],          # its line under Data analytics
             "levels": [_builtin_level(l) for l in b["levels"]]}
        k["levels"] += [_admin_level(l) for l in data["levels"] if l.get("kind") == b["id"]]
        out.append(k)
    builtin = {b["id"] for b in BUILTIN_KINDS}
    for a in data["kinds"]:
        if a["id"] in builtin:
            continue
        out.append({"id": a["id"], "label": a["label"], "errors_label": a["label"], "about": a.get("about", ""), "builtin": False,
                    "created_by": a.get("created_by"), "created": a.get("created"),
                    "levels": [_admin_level(l) for l in data["levels"] if l.get("kind") == a["id"]]})
    return out


def group_of(r, data=None):
    """The admin's level an item belongs to (its id), or None: an item of a built-in level, or one whose level is gone.
    Only an item stored at the level "other" can belong to an admin's level (see the top of this module)."""
    g = (r or {}).get("group")
    if not isinstance(g, str) or (r or {}).get("level") != "other":
        return None
    return g if any(l["id"] == g for l in (data or _load())["levels"]) else None


def item_group_of(r):
    """The group inside its level an item is listed in (the group's name), or None. Only an item stored at one of the
    analyzer's five levels can be in such a group: at the level "other" the same field names an admin's level."""
    g = (r or {}).get("group")
    if not isinstance(g, str) or (r or {}).get("level") not in F3.ANALYZER_LEVELS:
        return None
    return " ".join(g.split())[:GROUP_NAME_MAX] or None


def _sentences(text):
    """(the first sentence, the rest) of a meaning as its module wrote it. Nothing is reworded."""
    text = " ".join(str(text or "").split())
    m = re.match(r"^(.*?[.!?])\s+(?=[A-Z\"'(])(.*)$", text)
    return (m.group(1), m.group(2)) if m else (text, "")


def stated_groups(section, level):
    """The groups the module that seeds this level's items states, in its order: [(name, meaning)]. [] when no module does."""
    src = GROUP_SOURCES.get((section, level))
    if not src:
        return []
    try:
        return [(" ".join(str(n).split()), str(a or "")) for n, a in getattr(importlib.import_module(src[0]), src[1]) if str(n).strip()]
    except Exception as e:      # noqa: BLE001 - without the module the groups are shown by their names alone
        print("rule_hierarchy.stated_groups: %s" % e, flush=True)
        return []


def _rules_of(section, level, items):
    """The stored rule of every listed item of one level: {id: rule or None}. Reads only."""
    out = {}
    for it in items:
        try:
            r = F3.load_rule(section, level, it["id"])
        except ValueError:
            r = None
        out[it["id"]] = r if isinstance(r, dict) else None
    return out


def _grouped(section, level, items, rules):
    """The items of one built-in level as the screens list them: (the items in no group, [group]) where a group is
    {name, about (one sentence), more (the rest of the module's text), stated, items}. The groups a module states come
    first, in its order, also when they hold nothing yet (they are places to add to); then the groups only items name,
    by name. Inside a group, and among the items in no group, the order is the one the items have in the list."""
    stated = stated_groups(section, level) if level in F3.ANALYZER_LEVELS else []
    by_low, groups = {}, []
    for name, text in stated:
        if name.lower() in by_low:
            continue
        first, rest = _sentences(text)
        by_low[name.lower()] = g = {"name": name, "about": first, "more": rest, "stated": True, "items": []}
        groups.append(g)
    # then the groups the admin added at this level (add_group), in the order they were added, also when they hold nothing yet
    for a in (admin_groups(section, level) if level in F3.ANALYZER_LEVELS else []):
        if a["name"].lower() in by_low:
            continue
        by_low[a["name"].lower()] = g = {"name": a["name"], "about": a.get("about", ""), "more": "", "stated": False, "added": True, "id": a["id"],
                                         "created_by": a.get("created_by"), "items": []}
        groups.append(g)
    loose, found = [], {}
    for it in items:
        name = item_group_of(rules.get(it["id"]))
        if name is None:
            loose.append(it)
        elif name.lower() in by_low:
            by_low[name.lower()]["items"].append(it)
        else:
            found.setdefault(name.lower(), {"name": name, "about": "", "more": "", "stated": False, "items": []})["items"].append(it)
    return loose, groups + [found[k] for k in sorted(found)]


def groups_of_level(section, level):
    """The names of the groups of one built-in level of one section, in the order of the screens (for the add form)."""
    F3.sync_sections()
    if section not in F3.SECTIONS or level not in F3.ANALYZER_LEVELS:
        return []
    items = []
    d = os.path.join(F3.rules_root(), section, level)
    if os.path.isdir(d):
        items = [{"id": fn[:-5]} for fn in sorted(os.listdir(d)) if fn.endswith(".json")]
    return [g["name"] for g in _grouped(section, level, items, _rules_of(section, level, items))[1]]


def hierarchy():
    """Section -> kind of recording -> level -> (groups ->) items, with the label each has in its section, and how many
    items every section, kind and level holds (one that still holds items cannot be deleted). A level gives the items
    in no group under "items" and the others under "groups" (each group: name, about, more, stated, items); "count" is
    all of them. Reads only; writes nothing of its own."""
    tree, data = F3.tree(), _load()
    every = kinds(data)
    holds_kind, holds_level = {}, {}
    sections = []
    for s in tree:
        by_level = {l["level"]: l["items"] for l in s["levels"]}
        rules = {lv: _rules_of(s["section"], lv, its) for lv, its in by_level.items()}
        others = {}           # the items of the level "other", by the admin's level they belong to (None: plain "Other CSV files")
        for it in by_level.get("other", []):
            others.setdefault(group_of(rules["other"].get(it["id"]), data), []).append(it)
        shown, n_sec = [], 0
        for k in every:
            klabel = k["errors_label"] if s["defects"] else k["label"]
            levels = []
            for l in k["levels"]:
                items = others.get(l["group"], []) if l["level"] == "other" else by_level.get(l["level"], [])
                llabel = l["errors_label"] if s["defects"] else l["label"]
                known = rules.get(l["level"], {})

                def one(it, group_name=None, s=s, l=l, klabel=klabel, llabel=llabel, known=known):
                    """An item as the screens need it: its key, the admin's level it belongs to ("group": an id or None),
                    the group inside its level ("in_group": a name or None), its meaning and its place."""
                    place = [s["name"], klabel, llabel] + ([group_name] if group_name else []) + [it["name"]]
                    return dict(it, key="%s/%s/%s" % (s["section"], l["level"], it["id"]), group=l["group"], in_group=group_name,
                                about=str((known.get(it["id"]) or {}).get("description") or ""), place=place)
                loose, groups = _grouped(s["section"], l["level"], items, known) if l["level"] != "other" else (items, [])
                levels.append({"id": l["id"], "level": l["level"], "group": l["group"], "label": llabel, "about": l["about"], "file": l["file"], "builtin": l["builtin"],
                               "count": len(items), "items": [one(it) for it in loose],
                               "groups": [{"name": g["name"], "about": g["about"], "more": g["more"], "stated": g["stated"],
                                           # added: a group the admin added (it can be deleted while it holds no item, by its id)
                                           "added": bool(g.get("added")), "id": g.get("id"),
                                           "items": [one(it, g["name"]) for it in g["items"]]} for g in groups]})
                holds_level[l["id"]] = holds_level.get(l["id"], 0) + len(items)
                holds_kind[k["id"]] = holds_kind.get(k["id"], 0) + len(items)
                n_sec += len(items)
            kabout = k.get("analytics_about") or k["about"] if s["section"] == ANALYTICS else k["about"]
            shown.append({"kind": k["id"], "label": klabel, "about": kabout, "builtin": k["builtin"], "levels": levels})
        sections.append({"section": s["section"], "name": s["name"], "title": s["label"], "about": s["about"], "defects": s["defects"], "builtin": s["builtin"],
                         "number": s["number"], "holds": n_sec, "kinds": shown})
    for k in every:
        k["holds"] = holds_kind.get(k["id"], 0)
        for l in k["levels"]:
            l["holds"] = holds_level.get(l["id"], 0)
    return {"sections": sections, "kinds": every}


def items_of(level_entry):
    """Every item of one level of hierarchy(): the ones in no group first, then group by group, in the screens' order."""
    return list(level_entry["items"]) + [it for g in level_entry.get("groups") or [] for it in g["items"]]


def place_of(section, level, rid):
    """Where an item is, as the screens say it: [section, kind of recording, level, item], with the group before the
    item when the item is in one: [section, kind of recording, level, group, item]. None when there is no such item."""
    for s in hierarchy()["sections"]:
        if s["section"] != section:
            continue
        for k in s["kinds"]:
            for l in k["levels"]:
                if l["level"] != level:
                    continue
                for it in items_of(l):
                    if it["id"] == rid:
                        return it["place"]
    return None


def files_of_level(r, files):
    """For the Rule writer (family3._write): an item of a level the admin added is written on that level's file. When
    files of the analysis match the level's file name or pattern, only those are offered, each said to be the level's
    file; otherwise the list is left as it is (the item is then written like any "Other CSV files" item)."""
    try:
        data = _load()
        g = group_of(r, data)
        if not g:
            return files
        lvl = next(l for l in data["levels"] if l["id"] == g)
        pat = str(lvl.get("file") or "").lower()
        hit = [f for f in files if pat and fnmatch.fnmatchcase(str(f.get("file", "")).lower(), pat)]
        if not hit:
            return files
        return [dict(f, level="the file of the level '%s', which this item belongs to" % lvl["label"]) for f in hit]
    except Exception as e:      # noqa: BLE001 - the hierarchy is a grouping for the screens: it never stops a rule from being written
        print("rule_hierarchy.files_of_level: %s" % e, flush=True)
        return files


# ------------------------------------------------------------------------------------------------ kinds of recording
def _kind_names(every, but=None):
    names = []
    for k in every:
        if k["id"] != but:
            names += [k["label"], k["errors_label"]]
    return names


def add_kind(label, about, admin):
    """A kind of recording made by the admin: a name and one line on the files it covers. It starts with no level."""
    label, about = clean_name(label, "a kind of recording"), clean_words(about, "the line on what files it covers")
    data = _load()
    every = kinds(data)
    if any(_same(n, label) for n in _kind_names(every)):
        raise ValueError("a kind of recording named '%s' exists already" % label)
    kid = _slug(label, {k["id"] for k in every})
    data["kinds"].append({"id": kid, "label": label, "about": about, "created_by": admin, "created": time.time()})
    _save(data)
    return next(k for k in kinds(data) if k["id"] == kid)


def _admin_kind(data, kid):
    if any(b["id"] == kid for b in BUILTIN_KINDS):
        raise ValueError("this kind of recording is part of the application: it cannot be changed or deleted")
    k = next((k for k in data["kinds"] if k["id"] == kid), None)
    if k is None:
        raise LookupError("no such kind of recording")
    return k


def edit_kind(kid, label, about, admin):
    data = _load()
    k = _admin_kind(data, kid)
    label, about = clean_name(label, "a kind of recording"), clean_words(about, "the line on what files it covers")
    if any(_same(n, label) for n in _kind_names(kinds(data), but=kid)):
        raise ValueError("a kind of recording named '%s' exists already" % label)
    k.update(label=label, about=about, edited_by=admin, edited=time.time())
    _save(data)
    return next(x for x in kinds(data) if x["id"] == kid)


def delete_kind(kid, admin):
    data = _load()
    k = _admin_kind(data, kid)
    mine = [l for l in data["levels"] if l.get("kind") == kid]
    if mine:
        n = len(mine)
        raise ValueError("'%s' still holds %d level%s (%s): delete %s first, then the kind of recording" % (
            k["label"], n, "" if n == 1 else "s", ", ".join(l["label"] for l in mine[:5]), "it" if n == 1 else "them"))
    data["kinds"] = [x for x in data["kinds"] if x["id"] != kid]
    _save(data)
    return {"deleted": k["label"], "by": admin}


# ------------------------------------------------------------------------------------------------ levels
def add_level(kid, label, file, about, admin):
    """A level under a kind of recording, made by the admin: a name and the file it reads. It is a named group of
    "Other CSV files" items (see the top of this module)."""
    data = _load()
    every = kinds(data)
    k = next((k for k in every if k["id"] == kid), None)
    if k is None:
        raise LookupError("no such kind of recording")
    if kid == LECROY:
        raise ValueError(FIVE_ONLY)
    label, file, about = clean_name(label, "a level"), clean_file(file), clean_words(about, "the line on what the level is")
    if any(_same(n, label) for l in k["levels"] for n in (l["label"], l["errors_label"])):
        raise ValueError("'%s' has a level named '%s' already" % (k["label"], label))
    taken = set(F3.LEVELS) | {l["id"] for l in data["levels"]}
    lid = _slug(label, taken, prefix="g_")
    data["levels"].append({"id": lid, "kind": kid, "label": label, "file": file, "about": about, "created_by": admin, "created": time.time()})
    _save(data)
    return next(l for x in kinds(data) for l in x["levels"] if l["id"] == lid)


def _admin_level_of(data, lid):
    if lid in F3.LEVELS:
        raise ValueError("this level is part of the application: it cannot be changed or deleted")
    l = next((l for l in data["levels"] if l["id"] == lid), None)
    if l is None:
        raise LookupError("no such level")
    return l


def edit_level(lid, label, file, about, admin):
    data = _load()
    l = _admin_level_of(data, lid)
    label, file, about = clean_name(label, "a level"), clean_file(file), clean_words(about, "the line on what the level is")
    k = next((k for k in kinds(data) if k["id"] == l.get("kind")), None)
    if k and any(_same(n, label) for x in k["levels"] if x["id"] != lid for n in (x["label"], x["errors_label"])):
        raise ValueError("'%s' has a level named '%s' already" % (k["label"], label))
    l.update(label=label, file=file, about=about, edited_by=admin, edited=time.time())
    _save(data)
    return next(x for kk in kinds(data) for x in kk["levels"] if x["id"] == lid)


def items_of_level(lid):
    """The items that belong to an admin's level, in every section: [(section, id, name)]."""
    out = []
    F3.sync_sections()
    for sec in list(F3.SECTIONS):
        d = os.path.join(F3.rules_root(), sec, "other")
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            if fn.endswith(".json"):
                r = F3._read_json(os.path.join(d, fn), None)
                if isinstance(r, dict) and r.get("group") == lid:
                    out.append((sec, r.get("id"), r.get("name")))
    return out


def delete_level(lid, admin):
    data = _load()
    l = _admin_level_of(data, lid)
    held = items_of_level(lid)
    if held:
        n = len(held)
        raise ValueError("'%s' still holds %d item%s (%s): delete %s first (Deleted items can restore an item later), then the level" % (
            l["label"], n, "" if n == 1 else "s", ", ".join(str(x[2]) for x in held[:5]), "it" if n == 1 else "them"))
    data["levels"] = [x for x in data["levels"] if x["id"] != lid]
    _save(data)
    return {"deleted": l["label"], "by": admin}


# ------------------------------------------------------------------------------------------------ groups inside a level (the admin's own)
# (owner, 2026-11-15: "an option to add at the first, second, third hierarchy"): a group inside one of the analyzer's five levels, added by
# the admin. It is kept in kinds.json with the admin's kinds and levels (this module's own file and writer: everything the admin adds to the
# hierarchy for the screens is in one place, and a library without it reads as before). A group is a name and a line on what it holds; it
# may belong to one section or to every section. An item is put in it with add_item(..., group=its name), as in a stated group: the item's
# stored field "group" is the name, as for the seeded items. Shown by hierarchy() after the groups a module states.
def admin_groups(section, level, data=None):
    """The groups the admin added at one analyzer level that show in this section, in the order they were added."""
    return [g for g in (data or _load())["groups"] if g.get("level") == level and (not g.get("section") or g.get("section") == section)]


def _analyzer_level(lid):
    if not isinstance(lid, str) or not lid:
        raise LookupError("no such level")
    if lid in F3.ANALYZER_LEVELS:
        return lid
    if lid == "other" or any(l["id"] == lid for l in _load()["levels"]):
        raise ValueError("a group can be added inside one of the analyzer's five levels only: the items of this level are listed directly under it")
    raise LookupError("no such level")


def add_group(lid, name, about, admin, section=None):
    """A group inside one of the analyzer's five levels: a name (not empty, not one the level shows already) and a line on what it holds.
    section: one section's id, or None / "" for every section (the level is the same in every section)."""
    level = _analyzer_level(lid)
    name = clean_name(name, "a group", GROUP_NAME_MAX, path_free=False)
    about = clean_words(about, "the line on what the group holds")
    F3.sync_sections()
    if section not in (None, ""):
        if not isinstance(section, str) or section not in F3.SECTIONS:
            raise ValueError("say which section the group belongs to, or leave it out for every section")
    secs = [section] if section else list(F3.SECTIONS)
    for s in secs:
        if any(_same(n, name) for n in groups_of_level(s, level)):
            raise ValueError("'%s' has a group named '%s' already" % (LEVEL_WORDS[level][1 if F3.goes_to_stages(s) else 0], name))
    data = _load()
    gid = _slug(name, {g["id"] for g in data["groups"]}, prefix="grp_")
    data["groups"].append({"id": gid, "level": level, "section": section or "", "name": name, "about": about, "created_by": admin, "created": time.time()})
    _save(data)
    return {"id": gid, "level": level, "section": section or "", "name": name, "about": about, "created_by": admin}


def delete_group(lid, gid, admin):
    """Deletes a group the admin added that holds no item (in any section where it shows). A group a module states cannot be deleted."""
    level = _analyzer_level(lid)
    data = _load()
    g = next((x for x in data["groups"] if x["level"] == level and (x["id"] == gid or _same(x["name"], gid))), None)
    if g is None:
        F3.sync_sections()
        if any(_same(n, gid) for s in F3.SECTIONS for n, _a in stated_groups(s, level)):
            raise ValueError("this group is part of the application: it cannot be deleted")
        raise LookupError("no such group")
    held = []
    for s in ([g["section"]] if g.get("section") else list(F3.SECTIONS)):
        d = os.path.join(F3.rules_root(), s, level)
        if os.path.isdir(d):
            for fn in sorted(os.listdir(d)):
                if fn.endswith(".json"):
                    r = F3._read_json(os.path.join(d, fn), None)
                    if isinstance(r, dict) and item_group_of(r) and _same(item_group_of(r), g["name"]):
                        held.append(str(r.get("name")))
    if held:
        n = len(held)
        raise ValueError("'%s' still holds %d item%s (%s): delete %s first (Deleted items can restore an item later), then the group" % (
            g["name"], n, "" if n == 1 else "s", ", ".join(held[:5]), "it" if n == 1 else "them"))
    data["groups"] = [x for x in data["groups"] if x is not g]
    _save(data)
    return {"deleted": g["name"], "by": admin}


# ------------------------------------------------------------------------------------------------ sections (the admin's own)
def _admin_section(sid):
    F3.sync_sections()
    if any(b["id"] == sid for b in F3.BUILTIN_SECTIONS):
        raise ValueError("this section is part of the application: it cannot be changed or deleted")
    extra = F3._read_json(F3.sections_file(), [])
    extra = extra if isinstance(extra, list) else []
    s = next((x for x in extra if isinstance(x, dict) and x.get("id") == sid), None)
    if s is None:
        raise LookupError("no such section")
    return extra, s


def _save_sections(extra):
    p = F3.sections_file()
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(extra, fh, indent=1)
    F3.OSF.replace(tmp, p)
    F3._SECTIONS_SEEN[0] = None
    F3.sync_sections()


def edit_section(sid, label, about, admin):
    """The name and the description of a section the admin added. What happens to its items (results only, or defects
    that go on to stage 1 and stage 2) is not changed here: items already made rest on it."""
    extra, s = _admin_section(sid)
    label, about = clean_name(label, "a section"), clean_words(about, "the description of the section")
    if any(_same(x["label"], label) for k, x in F3.SECTION_INFO.items() if k != sid):
        raise ValueError("a section named '%s' exists already" % label)
    s.update(label=label, about=about, edited_by=admin, edited=time.time())
    _save_sections(extra)
    return F3.SECTION_INFO[sid]


def delete_section(sid, admin):
    extra, s = _admin_section(sid)
    live = []
    root = os.path.join(F3.rules_root(), sid)
    for level in F3.LEVELS:
        d = os.path.join(root, level)
        if os.path.isdir(d):
            live += [fn for fn in sorted(os.listdir(d)) if fn.endswith(".json")]
    if live:
        n = len(live)
        raise ValueError("'%s' still holds %d item%s: delete %s first, then the section" % (s["label"], n, "" if n == 1 else "s", "it" if n == 1 else "them"))
    gone = [x for x in F3.deleted_items() if x.get("section") == sid]
    if gone:
        n = len(gone)
        raise ValueError("'%s' has %d deleted item%s that can still be restored (%s): restore and move on, or keep the section" % (
            s["label"], n, "" if n == 1 else "s", ", ".join(str(x.get("name")) for x in gone[:5])))
    _save_sections([x for x in extra if not (isinstance(x, dict) and x.get("id") == sid)])
    return {"deleted": s["label"], "by": admin}


# ------------------------------------------------------------------------------------------------ an item at its place
def add_item(section, level, name, description, admin, group=None):
    """A new item at a place of the hierarchy. `level` is a built-in level or the id of a level the admin added: the
    item of an admin's level is stored at the level "other" with "group" = that level, so its key is section/other/id.
    `group` (optional) is the name of one of the groups inside a built-in analyzer level: the item is then stored at
    that level with "group" = the group's name, as the seeded items of the group are. None or "" means no group. A
    group that the level does not have is refused, and so is any group for an "other" item or an admin's level, where
    the stored field has its other meaning."""
    F3.sync_sections()
    if not isinstance(section, str) or section not in F3.SECTIONS:
        raise ValueError("say which section the item belongs to")
    if not isinstance(level, str):
        raise ValueError("say which level the item belongs to")
    name = clean_name(name, "an item", ITEM_NAME_MAX, path_free=False)
    description = clean_words(description, "the description of the item", WORDS_MAX)
    if group is not None and not isinstance(group, str):
        raise ValueError("the group of an item must be text: the name of one of the groups of its level, or nothing for no group")
    if group and "\x00" in group:
        raise ValueError("the group of an item holds a character that cannot be stored (a NUL character): choose the group again")
    group = " ".join(group.split()) if group else ""
    if level in F3.LEVELS:
        if not group:
            return F3.add_item(section, level, name, description, admin)
        have = groups_of_level(section, level)
        match = next((g for g in have if _same(g, group)), None)
        if match is None:
            where = LEVEL_WORDS[level][1 if F3.goes_to_stages(section) else 0]
            if not have:
                raise ValueError("'%s' has no groups: leave the group out, and the item is listed directly under the level" % where)
            raise ValueError("'%s' is not a group of '%s': choose one of its groups (%s), or no group" % (group[:GROUP_NAME_MAX], where, "; ".join(have)))
        r = F3.add_item(section, level, name, description, admin)
        r["group"] = match
        F3.save_rule(r)
        return r
    data = _load()
    lvl = next((l for l in data["levels"] if l["id"] == level), None)
    if lvl is None:
        raise ValueError("say which level the item belongs to")
    if group:
        raise ValueError("'%s' has no groups: leave the group out, and the item is listed directly under the level" % lvl["label"])
    r = F3.add_item(section, "other", name, description, admin)
    r["group"] = lvl["id"]
    F3.save_rule(r)
    return r
