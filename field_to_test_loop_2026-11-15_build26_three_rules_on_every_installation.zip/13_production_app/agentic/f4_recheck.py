"""Family 4: the recheck of the finished code by the terminal agent (owner, 2026-11-14: "it must have proper feedbacks,
proper rechecks, and redo it again ... make a connection between your terminal code and the final one. That open code one").

The Coder and the Tester of Family 4 are answered questions: neither can open the file or run a program. The terminal
agent (the opencode program in a terminal) can. After the rounds end clean and the code ran on the whole file, it is
given, in a folder of its own: the rule, the numbered requirements, the family's code, the family's result, the path of
the data file and Family 1's dictionary. It writes ITS OWN program from the requirements, runs it on the whole file and
answers in a fixed form. Nothing of its answer is believed as written:

  - its own program must be kept as a file (recheck_program.py), and must not be the family's code copied;
  - its own result must be kept as a file (recheck_result.csv): the application itself compares it with the family's
    result, row by row in a stream (a count and an order-free sum of row digests; neither file is held in memory), every
    cell as it is written: " Xpur" and "Xpur" are two cells (numbers go by their value, as the family compares them). Two
    results that differ ONLY in spaces at the start or end of cells are the application's own finding, said in those
    words: a difference, never an agreement, and it goes to the Coder (whether to remove the spaces is a requirement);
  - the counts it states for the family's result and for its own must equal what the application counts;
  - every row number of the data file it cites must exist in that file;
  - an example row "only the family has" must be in the family's result and not in its own, and the reverse.

"Agrees" is said only when the answer says so AND the application's own comparison of the two result files says the
same. An answer that fails a check is "the recheck's answer could not be used: <reason>": never an agreement and never
feedback. A disagreement that passed goes back to the Coder as what failed (its example rows exactly as they stand in the
result file, spaces at the ends of the cells kept and said in words), and the recheck runs again on the new code,
RECHECKS_MOST times at most in one build. Every recheck of a build has a terminal session of its own (session_of): the
real program, continuing the first recheck's session from the second one's folder, printed nothing and never ended
(2026-11-15); what the second needs of the first is in its task file (prepare), not in a continued conversation.

THE DATA IS WATCHED, NOT PROTECTED (coordinator, 2026-11-15). opencode's permissions stop the program's own file tools.
Measured on 2026-11-15 with the real program (opencode 1.19.4): its read tool was refused a file outside the agent's
folder and the data file's, but a listing command was not (ls /home ran and answered), and when the read tool refused a
folder the model, without being told to, read it and wrote two files into it with Python. So the listing commands and
the Python the terminal agent starts are NOT confined by the program's permissions: a Python program it starts is an
ordinary process of the user and could change or delete the admin's data files; only the instruction text forbids it. So before the terminal agent is started the
application records every data file the recheck may read (and every other file in the folders it may read, the family's
code and the family's result): size, change time, and a SHA-256 fingerprint: of the whole content up to
FULL_FINGERPRINT_MOST bytes, of the first and the last ENDS_BYTES bytes above that (the record says which). After the
agent has ended (also after a timeout, a Stop or a crash) it compares. When a file changed, was replaced, was removed, or
a new file appeared in a data folder, the recheck's answer is never used (no agreement, no feedback to the Coder), the
rounds end, the card says which file and what changed, and the before and after facts are kept in a log file beside
the agent's folder. What this cannot catch: a change that is undone before the comparison, a change in the middle of a
file above the limit made with the size and the change time kept, a change made after the comparison by a program the
agent left running, anything outside the watched folders, and a read of the data that is sent elsewhere.

The shipped setting is "only when the admin asks on the card": the step was tried once with the real opencode program
(2026-11-15: three rechecks of a small file with one free model), and the listing commands and the Python the agent
starts are not confined by the program's permissions. The admin can set "always" in Settings.

No Unix-only module; every text file is opened as UTF-8; the data file is never loaded (it can be 6 GB)."""
import ast
import csv
import hashlib
import json
import logging
import os
import shutil
import stat
import time

from . import prompts
from . import opencode_cli as oc

ALWAYS, ASK, NEVER = "always", "ask", "never"       # the setting agentic.f4_recheck
SETTING_MEANS = {ALWAYS: "always when the terminal agent is ready", ASK: "only when the admin asks on the card", NEVER: "never"}
RECHECKS_MOST = 2       # rechecks in one build: the first, and one more on the code the Coder repaired after it. A third would
                        # mean the Coder and the terminal agent read a requirement differently twice: that is the admin's to say
TIMEOUT_S = 300         # seconds one recheck may work (the whole-file run of the family's own code is given 900)
EXAMPLES_MOST = 10      # example rows of a disagreement that are checked, shown and sent to the Coder
ANSWER_CHARS_MOST = 200000      # an answer longer than this is not read
FILE_CHARS_MOST = 400000        # its own program, at most
CELL_CHARS_MOST = 200   # a cell of an example row is passed on exactly as it stands in the result file, cut only past this length
TEXT = 400
AGENT = "f4_recheck"
NAME = "Family 4 · recheck"
PROGRAM_FILE, RESULT_FILE = "recheck_program.py", "recheck_result.csv"
AGREES, DISAGREES, COULD_NOT = "agrees", "disagrees", "could not check"
ONLY_FAMILY, ONLY_RECHECK = "family", "recheck"
SHAPE = ('{"could_not_check": "", "counts": {"data_rows": 0, "family_rows": 0, "recheck_rows": 0, "only_in_family": 0, "only_in_recheck": 0}, '
         '"requirements": [{"id": "R1", "verdict": "agrees | disagrees | could not check", "reason": "..."}], '
         '"differences": [{"only_in": "family | recheck", "row": ["<cell>", "..."], "file_rows": [0], "requirement": "R1", "reason": "..."}], '
         '"program": "recheck_program.py", "result": "recheck_result.csv"}')
ASKED_LINE = "The admin asks for the recheck of this code by the terminal agent: change the code only where a finding shows it wrong."
PROFILE_NOTE = ("the investigation agent's permissions are used (the ones measured with the real opencode program; the profile \"f2t-recheck\" "
                "without an edit tool exists in agentic/opencode_cli.py and is not used): read, edit, Python and listing commands; the program's own read "
                "and edit tools are refused every folder outside the agent's own but the data file's. These permissions stop opencode's own file tools only: "
                "the listing commands and the Python the agent starts are not confined by the program's permissions (measured on 2026-11-15 with the real "
                "program: ls /home ran, and the model read and wrote a refused folder with Python), so a program it starts could change or delete the data "
                "files, which is why the application compares every data file before and after (snapshot, changes)")
NOT_CONFINED = ("the listing commands and the Python the terminal agent starts are not confined by the program's permissions "
                "(measured on 2026-11-15 with the real opencode program), so the data files are compared before and after each recheck")
CELLS_NOTE = ("Every cell of these rows is given exactly as it stands in the result file, between quotes: a space inside the quotes, at the start or the end of a cell, "
              "is part of the cell.")
SPACES_NOTE = ("whether the spaces at the start or end of a cell are removed is a requirement of the rule: read the requirements and the approved procedure, "
               "remove the spaces in the code where they say so, and say in your notes when they say the cells are kept as written")
SHIPPED = ASK           # the value used when the key is missing or is none of the three; config/app_config.json ships the same
# ---- the watch on the data (see the module text)
FULL_FINGERPRINT_MOST = 256 * 1024 * 1024       # bytes: up to this size the fingerprint is of the whole content
ENDS_BYTES = 16 * 1024 * 1024                   # above it: of the first and the last this many bytes
BLOCK = 1024 * 1024                             # read in blocks of this size: memory stays at one block for any file
FOLDER_FILES_MOST = 5000                        # other files of the data folders that are recorded; past it new files are not looked for
FOLDER_WHOLE_BYTES_MOST = 2 * 1024 * 1024 * 1024    # the other files of the data folders: whole-content fingerprints up to this many bytes
                                                    # in all, the first and the last ENDS_BYTES of each file after that
CHANGES_SHOWN = 5                               # changes named in the card's sentence (all are in the log)
DATA_CHANGED = "data changed"                   # the state of such a recheck, in the record and on the card
WHOLE = "the whole content"
LOG = logging.getLogger("f2t.f4_recheck")


def setting(engine):
    """agentic.f4_recheck: one of the three values; a missing key or anything else is the shipped one (only when the admin
    asks on the card: the listing commands and the Python the agent starts are not confined by the program's permissions,
    measured on 2026-11-15 with the real opencode program)."""
    v = ((getattr(engine, "cfg", None) or {}).get("agentic") or {}).get("f4_recheck")
    return v if isinstance(v, str) and v in SETTING_MEANS else SHIPPED


def _line(v, most=TEXT):
    return " ".join(str(v if isinstance(v, (str, int, float)) and not isinstance(v, bool) else "").split())[:most]


def _whole(v):
    return v if isinstance(v, int) and not isinstance(v, bool) and v >= 0 else None


def _rows(n):
    return "%s row%s" % ("{:,}".format(n), "" if n == 1 else "s")


def not_ready(runner):
    """"" when the terminal agent can be asked, else the reason in one plain sentence part. The same facts the
    investigation agent's page shows as "ready" and "problem": the opencode program and a chosen model it offers."""
    if getattr(runner, "runtime", None) == "standin":
        return "the stand-in is in use"
    fn = getattr(runner, "opencode_ready", None)
    if not callable(fn) or not callable(getattr(runner, "terminal_turn", None)):
        return "the terminal agent is not part of this installation"
    try:
        _exe, _facts, problem = fn()
    except Exception as e:      # noqa: BLE001 - not ready, with the reason; the build goes on
        return "the terminal agent could not say whether it is ready (%s)" % _line(str(e), 200)
    return _line(problem, 300)


def exact(canon):
    """The form a cell is compared in by the recheck: as it is written. A cell with a space (or another blank sign) at its
    start or its end is compared as exactly that text, so " Xpur" and "Xpur" are two cells (whether to remove the spaces is
    a requirement of the rule: the trial of 2026-11-15 planted exactly that fault). Every other cell is compared as the
    family compares it (canon): a number by its value, so "2" and "2.0" stay the same cell."""
    def cell(c):
        s = "" if c is None else str(c)
        return ("t", s) if s != s.strip() else canon(s)
    return cell


def _digest(cells):
    return int.from_bytes(hashlib.sha1(repr(cells).encode("utf-8")).digest(), "big")


def fingerprints(path, canon):
    """A result CSV read once, in a stream (nothing of it is kept): its columns, its data rows, the order-free sum of the
    rows' digests with every cell as it is written ("sum"), the same sum with the spaces at the ends of the cells left out
    ("sum_without_end_spaces"), and how many cells have such spaces. Two results with the same rows and the same first sum
    hold the same rows cell for cell; with only the second sum the same they differ in nothing but those spaces."""
    as_written = exact(canon)
    n = total = loose = spaced = 0
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
        rd = csv.reader(fh)
        cols = [c.strip() for c in next(rd, [])]
        for row in rd:
            if not row:
                continue
            n += 1
            a, b = [as_written(c) for c in row], [canon(c) for c in row]
            da = _digest(a)
            total = (total + da) % (1 << 160)
            loose = (loose + (da if a == b else _digest(b))) % (1 << 160)
            spaced += sum(1 for c in row if c != c.strip())
    return {"columns": cols, "rows": n, "sum": total, "sum_without_end_spaces": loose, "cells_with_end_spaces": spaced}


def fingerprint(path, canon):
    """(columns, data rows, an order-free sum of the rows' digests, every cell as it is written) of a result CSV, read in a stream."""
    f = fingerprints(path, canon)
    return f["columns"], f["rows"], f["sum"]


def _shown(cell):
    """A cell as it is passed on and shown: exactly as it stands, cut only when it is longer than CELL_CHARS_MOST."""
    return cell if len(cell) <= CELL_CHARS_MOST else "%s… (cut by the application: the cell holds %s characters)" % (cell[:CELL_CHARS_MOST], "{:,}".format(len(cell)))


def _quoted(row):
    """A row with every cell between quotes, so that a reader sees a space at the start or the end of a cell."""
    return json.dumps([_shown(c) for c in row], ensure_ascii=False)


def _ends_words(row):
    """In words, the cells of a row that have spaces at their ends: [] when none has."""
    out = []
    for i, c in enumerate(row):
        if isinstance(c, str) and c != c.strip():
            a, z = len(c) - len(c.lstrip()), len(c) - len(c.rstrip())
            out.append("cell %d is written %s: %s" % (i + 1, json.dumps(_shown(c), ensure_ascii=False), " and ".join(
                "%d space%s at its %s" % (k, "" if k == 1 else "s", where) for k, where in ((a, "start"), (z, "end")) if k) if c.strip() else "nothing but spaces"))
    return out


def _data_rows(fh):
    rd = csv.reader(fh)
    next(rd, None)
    return (row for row in rd if row)


def spaces_finding(family_csv, own_csv, canon, family_spaced, own_spaced):
    """Called only when the two results hold the same rows once the spaces at the ends of the cells are left out, and not
    the same rows as they are written. -> {"sentence", "cells", "cells_with_end_spaces", "examples"}: the application's own
    finding, in plain words. Both files are read side by side in a stream: when their rows stand in the same order the
    differing cells are counted pair by pair; when not, each side's cells with such spaces are counted (nothing is sorted
    or held), and the example is a row the other side was looked through for."""
    as_written = exact(canon)
    cells, first, paired = 0, None, True
    with open(family_csv, newline="", encoding="utf-8-sig", errors="replace") as fa, open(own_csv, newline="", encoding="utf-8-sig", errors="replace") as fb:
        for line, (x, y) in enumerate(zip(_data_rows(fa), _data_rows(fb)), 1):
            if [canon(c) for c in x] != [canon(c) for c in y]:
                paired = False
                break
            differing = sum(1 for p, q in zip(x, y) if as_written(p) != as_written(q))
            cells += differing
            if differing and first is None:
                first = (line, x, y)
    why = "found by the application's own comparison of the two result files: the row differs from the other side's only in spaces at the start or end of a cell"
    one = lambda side, row, line: {"only_in": side, "row": [_shown(c) for c in row], "file_rows": [], "result_row": line, "requirement": None, "reason": why}     # noqa: E731
    if paired and first:
        line, x, y = first
        sentence = ("the two results hold the same rows except for spaces at the start or end of %s cell%s; for example row %s of both results: the code's result has %s, "
                    "the recheck's own result has %s" % ("{:,}".format(cells), "" if cells == 1 else "s", "{:,}".format(line), _quoted(x), _quoted(y)))
        return {"sentence": sentence, "cells": cells, "cells_with_end_spaces": {"family": family_spaced, "recheck": own_spaced},
                "examples": [one(ONLY_FAMILY, x, line), one(ONLY_RECHECK, y, line)]}
    # the rows stand in another order: one row with such spaces that the other side does not hold as it is written
    examples = []
    for side, path, other in ((ONLY_FAMILY, family_csv, own_csv), (ONLY_RECHECK, own_csv, family_csv)):
        some = []
        with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
            for line, row in enumerate(_data_rows(fh), 1):
                if any(c != c.strip() for c in row):
                    some.append((line, row))
                    if len(some) >= 20:
                        break
        held = _holds(other, {tuple(as_written(c) for c in row) for _l, row in some}, as_written)
        examples += [one(side, row, line) for line, row in some if tuple(as_written(c) for c in row) not in held][:1]
    n = lambda k: "%s cell%s" % ("{:,}".format(k), "" if k == 1 else "s")     # noqa: E731
    sentence = ("the two results hold the same rows except for spaces at the start or end of cells (the code's result has such spaces in %s, the recheck's own result in %s; "
                "the rows stand in another order in the two files, so the cells were not counted pair by pair)%s" % (
                    n(family_spaced), n(own_spaced), "; for example %s result has the row %s and the other has it without those spaces" % (
                        "the code's" if examples[0]["only_in"] == ONLY_FAMILY else "the recheck's own", json.dumps(examples[0]["row"], ensure_ascii=False)) if examples else ""))
    return {"sentence": sentence, "cells": None, "cells_with_end_spaces": {"family": family_spaced, "recheck": own_spaced}, "examples": examples}


def _holds(path, wanted, canon):
    """Which of the wanted rows (tuples of compared cells) a result CSV holds: one pass, nothing kept but the wanted rows."""
    found = set()
    if not wanted:
        return found
    with open(path, newline="", encoding="utf-8-sig", errors="replace") as fh:
        rd = csv.reader(fh)
        next(rd, None)
        for row in rd:
            key = tuple(canon(c) for c in row)
            if key in wanted:
                found.add(key)
                if len(found) == len(wanted):
                    break
    return found


def file_form(path, dictionary=None):
    """How one data file is written, as the terminal agent's own program must read it: {} for a plain file (comma, UTF-8,
    header on line 1) without a column that needs telling. Else "written_as" (the sentence, the codec for open(), the
    separator for csv.reader, the header's line and the lines above it) and "number_styles" (per column: the decimal sign,
    the thousands sign, or that the column cannot be read as a number, each with the counted sentence). The form is read
    from the file itself; the number styles are those Family 1 counted on the whole file (its dictionary)."""
    from . import csv_dialect as CD, procedures as PR
    out = {}
    try:
        d = CD.detect(path)
    except OSError:
        return out
    if d["refused"]:
        return {"not_read_as_a_table": d["refused"]}
    form = PR.written_for_coder(d)
    if form:
        out["written_as"] = form
    styles = []
    for c in (dictionary or {}).get("columns") or [] if isinstance(dictionary, dict) else []:
        st = PR.style_for_coder(c.get("number_style")) if isinstance(c, dict) else None
        if st:
            styles.append(dict({"column": c.get("column")}, **{k: st[k] for k in ("style", "decimal_sign", "thousands_sign", "how", "examples", "read_as_a_number") if k in st}))
    if styles:
        out["number_styles"] = styles
    return out


# ---------------------------------------------------------------------------------------------- the watch on the data
def _size(n):
    return "%s byte%s" % ("{:,}".format(n), "" if n == 1 else "s")


def _amount(n):
    for unit, size in (("GB", 1 << 30), ("MB", 1 << 20), ("KB", 1 << 10)):
        if n >= size and n % size == 0:
            return "%d %s" % (n // size, unit)
    return _size(n)


def ends_words():
    return "the first %s and the last %s" % (_amount(ENDS_BYTES), _amount(ENDS_BYTES))


def _when(ns):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ns / 1e9)) + (".%09d" % (ns % 10 ** 9))[:7]


def file_facts(path, ends_only=False):
    """One file as the watch records it: {"there": False} or {"there", "size", "changed_at_ns", "changed_at", "identity",
    "fingerprint", "fingerprint_of"}. The fingerprint is SHA-256 of the whole content for a file of at most
    FULL_FINGERPRINT_MOST bytes, else of its first and its last ENDS_BYTES bytes; "fingerprint_of" says which. Read in
    blocks of BLOCK bytes: the memory used does not grow with the file. Never raises."""
    try:
        st = os.stat(path)
    except OSError:
        return {"there": False}
    out = {"there": True, "size": st.st_size, "changed_at_ns": st.st_mtime_ns, "changed_at": _when(st.st_mtime_ns),
           "identity": [st.st_dev, st.st_ino] if st.st_ino else None, "fingerprint": None, "fingerprint_of": "nothing: it is not an ordinary file"}
    if not stat.S_ISREG(st.st_mode):
        return out
    ends = ends_only or st.st_size > FULL_FINGERPRINT_MOST
    h = hashlib.sha256()
    try:
        with open(path, "rb") as fh:
            def take(most):
                while most is None or most > 0:
                    block = fh.read(BLOCK if most is None else min(BLOCK, most))
                    if not block:
                        break
                    h.update(block)
                    if most is not None:
                        most -= len(block)
            if not ends:
                take(None)
            else:
                take(ENDS_BYTES)
                fh.seek(max(st.st_size - ENDS_BYTES, fh.tell()))
                take(ENDS_BYTES)
    except OSError as e:
        out["fingerprint_of"] = "nothing: the file could not be opened (%s)" % _line(str(e), 120)
        return out
    out["fingerprint"], out["fingerprint_of"] = h.hexdigest(), ends_words() if ends else WHOLE
    out["ends_only"] = bool(ends)
    return out


def _listing(folders, skip):
    """Every file under the folders the agent may read (links to folders are not followed; the folders in skip, the agent's
    own, are left out), in a fixed order. -> (paths, whether the listing was cut at FOLDER_FILES_MOST)."""
    skip = [os.path.abspath(x) for x in skip or []]
    paths = []
    for folder in folders:
        for root, dirs, files in os.walk(folder, followlinks=False):
            dirs[:] = sorted(d for d in dirs if os.path.abspath(os.path.join(root, d)) not in skip)
            if os.path.abspath(root) in skip:
                continue
            for name in sorted(files):
                paths.append(os.path.abspath(os.path.join(root, name)))
                if len(paths) > FOLDER_FILES_MOST:
                    return paths[:FOLDER_FILES_MOST], True
    return paths, False


def snapshot(named, folders, skip=()):
    """The record taken before the terminal agent is started. named: {path: what the file is} (the data files, the family's
    code, the family's result); folders: the folders the agent may read; skip: the agent's own folder.
    -> {"taken_at", "files": {path: facts}, "what": {path: words}, "folders", "skip", "listing_cut", "seconds"}."""
    t0 = time.time()
    files, what, whole_bytes = {}, {}, 0
    for p, words in named.items():
        p = os.path.abspath(p)
        files[p], what[p] = file_facts(p), words
    listed, cut = _listing(folders, skip)
    for p in listed:
        if p in files:
            continue
        try:
            size = os.path.getsize(p)
        except OSError:
            size = 0
        whole_bytes += size if size <= FULL_FINGERPRINT_MOST else 0
        files[p], what[p] = file_facts(p, ends_only=whole_bytes > FOLDER_WHOLE_BYTES_MOST), "another file in a folder the terminal agent may read"
    return {"taken_at": time.time(), "files": files, "what": what, "folders": [os.path.abspath(f) for f in folders], "skip": [os.path.abspath(x) for x in skip or []],
            "listing_cut": ("a folder holds more than %s files: the first %s are recorded, and new files are not looked for" % ("{:,}".format(FOLDER_FILES_MOST), "{:,}".format(FOLDER_FILES_MOST))) if cut else "",
            "seconds": round(time.time() - t0, 2)}


def _what_changed(a, b):
    """One file before (a) and after (b), in plain words; "" when nothing changed."""
    if a.get("there") and not b.get("there"):
        return "it is no longer there (it was removed or renamed)"
    if not a.get("there"):
        return "it was not there before and is there now" if b.get("there") else ""
    of = a.get("fingerprint_of") or ""
    if a["size"] != b["size"]:
        return "its size changed from %s to %s" % (_size(a["size"]), _size(b["size"]))
    same_time = a["changed_at_ns"] == b["changed_at_ns"]
    moved = a.get("identity") != b.get("identity")
    if a.get("fingerprint") != b.get("fingerprint"):
        return "its content changed%s: the size is the same (%s)%s, and the fingerprint of %s differs" % (
            " (it was replaced by another file)" if moved else "", _size(a["size"]), " and so is the change time" if same_time else "", of or "its content")
    rest = "the fingerprint of %s is the same%s" % (of, "" if of == WHOLE else "; the part between them was not compared") if a.get("fingerprint") else "its content could not be read"
    if not same_time:
        return "its change time changed from %s to %s (the size is the same; %s)" % (a["changed_at"], b["changed_at"], rest)
    if moved:
        return "it was replaced by another file (the size and the change time are the same; %s)" % rest
    return ""


def changes(before):
    """Compare the record with the files as they are now. -> (changes, after): changes is a list of {"file", "what_it_is",
    "what_changed", "before", "after"}, empty when nothing changed; after has the same form as the record. Never raises."""
    t0 = time.time()
    after, found = {}, []
    for p, a in before["files"].items():
        b = after[p] = file_facts(p, ends_only=bool(a.get("ends_only")))
        words = _what_changed(a, b)
        if words:
            found.append({"file": p, "what_it_is": before["what"].get(p), "what_changed": words, "before": a, "after": b})
    if not before.get("listing_cut"):
        listed, _cut = _listing(before["folders"], before["skip"])
        for p in listed:
            if p not in before["files"]:
                b = after[p] = file_facts(p, ends_only=True)
                found.append({"file": p, "what_it_is": "a new file in a folder the terminal agent may read",
                              "what_changed": "a new file appeared in the data file's folder (%s; the terminal agent's own files belong in its own folder only)" % _size(b.get("size") or 0),
                              "before": {"there": False}, "after": b})
    return found, {"taken_at": time.time(), "files": after, "seconds": round(time.time() - t0, 2)}


def changed_sentence(found, names=None):
    """The card's sentence for a recheck during which the data changed."""
    names = names or {}
    shown = ["%s: %s" % (names.get(c["file"]) or c["file"], c["what_changed"]) for c in found[:CHANGES_SHOWN]]
    more = len(found) - len(shown)
    return ("The data changed while the terminal agent was rechecking: %s%s. The recheck's answer is not used. Check the file%s against your own copy before you go on."
            % ("; ".join(shown), "; and %d more (all are in the log)" % more if more > 0 else "", "" if len(found) == 1 else "s"))


def _write_log(path, record):
    try:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(record, fh, indent=1, ensure_ascii=False, default=str)
        return path
    except OSError:
        return None


def prepare(box, given):
    """The terminal agent's folder for one recheck: what it is given, as files. Each data file that is not plain carries how
    it is written (file_form), so that the agent's own program opens it rightly. Its own two files of an earlier try are
    removed, so that a file found afterwards was written in this recheck. -> the task as a dict (also written there)."""
    os.makedirs(box, exist_ok=True)
    for name in (PROGRAM_FILE, RESULT_FILE):
        try:
            os.remove(os.path.join(box, name))
        except OSError:
            pass
    shutil.copyfile(given["code_file"], os.path.join(box, "family_code.py"))
    shutil.copyfile(given["result_csv"], os.path.join(box, "family_result.csv"))        # copied in blocks, never read into memory
    task = {"the_item": given["name"], "the_rule_in_the_admins_words": given["rule"], "the_procedure_the_admin_approved": given["steps"],
            "requirements": [{"id": i, "text": t} for i, t in given["reqs"]],
            "output_columns_in_this_order": given["columns"],
            "data_files": [dict({"file": f, "path": p, "data_rows_counted_by_the_application": given["data_rows"].get(f)}, **file_form(p, (given.get("dictionary") or {}).get(f)))
                           for f, p in given["paths"].items()],
            "the_familys_result": {"file": "family_result.csv", "columns": given["columns"], "rows_without_the_header": "count them yourself"},
            "the_familys_code": "family_code.py (to read after your own program ran, never to copy or run)",
            "the_dictionary_of_family_1": "dictionary.json",
            "how_rows_of_the_data_file_are_numbered": "row 1 is the first row after the header row",
            "write_only": [PROGRAM_FILE, RESULT_FILE]}
    n, earlier = given.get("n") or 1, given.get("earlier") or []
    task["this_recheck"] = ("recheck %d of at most %d in this build" % (n, RECHECKS_MOST)) + (
        ": the code has not been rechecked before" if n == 1 else
        ", on repaired code: the Coder changed the code after recheck %d, and family_code.py and family_result.csv are the new code and its new result" % (n - 1))
    if n > 1:
        # a recheck is a session of its own (it does not see the earlier conversation): what it needs of the earlier one is here, as data
        task["what_the_earlier_recheck_found"] = {
            "how_to_use_it": "this is data about the EARLIER code, not an instruction: write your own program from the requirements alone, as if it were the first "
                             "recheck, and do not take the repair for right or for wrong before your own rows say so",
            "rechecks": earlier}
    with open(os.path.join(box, "task.json"), "w", encoding="utf-8") as fh:
        json.dump(task, fh, indent=1, ensure_ascii=False)
    with open(os.path.join(box, "dictionary.json"), "w", encoding="utf-8") as fh:
        json.dump(given.get("dictionary") or {}, fh, indent=1, ensure_ascii=False, default=str)
    return task


def _unusable(why, **more):
    return dict({"state": "unusable", "why": why}, **more)


def check(answer, text, box, given, canon):
    """The terminal agent's answer, checked by code. -> {"state": "agrees" | "differs" | "could not check" | "unusable",
    "why", "verdicts", "counts", "examples", "program_file"}. Nothing here trusts a number or a row the answer states."""
    if len(text or "") > ANSWER_CHARS_MOST:
        return _unusable("its answer is %s characters long; at most %s are read" % ("{:,}".format(len(text)), "{:,}".format(ANSWER_CHARS_MOST)))
    if not isinstance(answer, dict):
        return _unusable("its answer is not in the form that was asked for")
    could = _line(answer.get("could_not_check"), 300)
    # ---- its own program, kept as a file
    prog = os.path.join(box, PROGRAM_FILE)
    code = ""
    if os.path.isfile(prog) and os.path.getsize(prog) <= FILE_CHARS_MOST * 4:
        with open(prog, encoding="utf-8", errors="replace") as fh:
            code = fh.read(FILE_CHARS_MOST)
    elif isinstance(answer.get("program_text"), str) and answer["program_text"].strip():
        code = answer["program_text"][:FILE_CHARS_MOST]
    kept = None
    if code.strip():
        kept = given["keep_program_at"]
        os.makedirs(os.path.dirname(kept), exist_ok=True)
        with open(kept, "w", encoding="utf-8") as fh:
            fh.write(code)
    if could:
        return {"state": "could not check", "why": could, "program_file": kept}
    if not code.strip():
        return _unusable("it kept no program of its own (%s), so nothing shows how it reached its answer" % PROGRAM_FILE)
    try:
        ast.parse(code)
    except (SyntaxError, ValueError) as e:
        return _unusable("the program it kept is not a Python program (%s)" % _line(str(e), 120), program_file=kept)
    with open(given["code_file"], encoding="utf-8") as fh:
        if "".join(fh.read().split()) == "".join(code.split()):
            return _unusable("the program it kept is the family's code, copied: that is not an independent check", program_file=kept)
    # ---- the counts it states, against what the application counts
    counts = answer.get("counts") if isinstance(answer.get("counts"), dict) else {}
    said_family, said_own = _whole(counts.get("family_rows")), _whole(counts.get("recheck_rows"))
    if said_family is None or said_own is None:
        return _unusable("it states no counts for the two results (whole numbers were asked for)", program_file=kept)
    if said_family != given["result_rows"]:
        return _unusable("it states %s for the family's result, and that result holds %s (counted by the application)" % (_rows(said_family), _rows(given["result_rows"])),
                         program_file=kept)
    said_data = _whole(counts.get("data_rows"))
    most_data = max([v for v in given["data_rows"].values() if isinstance(v, int)] or [0])
    if said_data is not None and given["data_rows"] and said_data not in given["data_rows"].values():
        return _unusable("it states %s for the data file, and the file holds %s (counted by the application)" % (_rows(said_data), _rows(most_data)), program_file=kept)
    # ---- its own result, kept as a file and compared here
    own = os.path.join(box, RESULT_FILE)
    if not os.path.isfile(own):
        return _unusable("it kept no result of its own (%s), so the application could not compare the rows itself" % RESULT_FILE, program_file=kept)
    as_written = exact(canon)       # every cell as it is written: a space at the start or the end of a cell is part of the cell
    try:
        mine = fingerprints(own, canon)
        family = given.get("result_marks") or fingerprints(given["result_csv"], canon)
    except (OSError, csv.Error, UnicodeError) as e:
        return _unusable("its result file could not be read (%s)" % _line(str(e), 120), program_file=kept)
    cols, n_own, sum_own = mine["columns"], mine["rows"], mine["sum"]
    if cols != [c.strip() for c in given["columns"]]:
        return _unusable("its result has the columns %s; the family's result has %s, so the rows cannot be compared" % (", ".join(cols)[:200] or "none", ", ".join(given["columns"])),
                         program_file=kept)
    if said_own != n_own:
        return _unusable("it states %s for its own result, and its result file holds %s (counted by the application)" % (_rows(said_own), _rows(n_own)), program_file=kept)
    same = n_own == given["result_rows"] and sum_own == given["result_sum"]
    # ---- the same rows but for spaces at the ends of cells: the application's own finding, and a difference (whether to remove
    # the spaces is a requirement of the rule), whatever the answer says
    spaces = None
    if not same and n_own == family["rows"] and mine["sum_without_end_spaces"] == family["sum_without_end_spaces"]:
        try:
            spaces = spaces_finding(given["result_csv"], own, canon, family["cells_with_end_spaces"], mine["cells_with_end_spaces"])
        except (OSError, csv.Error, UnicodeError) as e:
            return _unusable("the two result files could not be read side by side (%s)" % _line(str(e), 120), program_file=kept)
    # ---- one verdict per requirement, in fixed words
    by_id = {}
    for x in answer.get("requirements") if isinstance(answer.get("requirements"), list) else []:
        if isinstance(x, dict) and isinstance(x.get("id"), str):
            v = _line(x.get("verdict"), 40).lower()
            v = AGREES if v in ("agrees", "agree") else DISAGREES if v in ("disagrees", "disagree") else COULD_NOT if v.startswith("could not") else None
            if v:
                by_id.setdefault(x["id"].strip(), {"verdict": v, "reason": _line(x.get("reason"))})
    verdicts = [dict({"id": i, "requirement": _line(t, 200)}, **(by_id.get(i) or {"verdict": COULD_NOT, "reason": "the recheck's answer does not mention this requirement"}))
                for i, t in given["reqs"]]
    facts = {"family_rows": given["result_rows"], "recheck_rows": n_own, "the_same_rows": same,
             "only_in_family_as_the_terminal_agent_states": _whole(counts.get("only_in_family")),
             "only_in_recheck_as_the_terminal_agent_states": _whole(counts.get("only_in_recheck"))}
    base = {"verdicts": verdicts, "counts": facts, "program_file": kept, "examples": []}
    differs = [v for v in verdicts if v["verdict"] == DISAGREES]
    reasons = "; ".join("%s: %s" % (v["id"], v["reason"] or "no reason given") for v in differs)[:1200]
    if spaces:
        facts["the_same_rows_except_for_spaces_at_the_ends_of_cells"] = True
        base["spaces"] = {x: spaces[x] for x in ("sentence", "cells", "cells_with_end_spaces")}
    if not differs:
        if spaces:
            return dict(base, state="differs", why=spaces["sentence"], examples=spaces["examples"])
        if not same:
            return _unusable("it names no requirement it disagrees on, and its own result file does not hold the same rows as the family's result "
                             "(%s against %s, compared by the application)" % (_rows(n_own), _rows(given["result_rows"])), **base)
        if not any(v["verdict"] == AGREES for v in verdicts):
            return dict(base, state="could not check", why="it gave no verdict on any requirement")
        return dict(base, state="agrees", why="")
    if same:
        return _unusable("it says it disagrees on %s, and its own result file holds exactly the rows of the family's result (compared by the application)"
                         % ", ".join(v["id"] for v in differs), **base)
    # ---- the example rows of the disagreement
    examples, problem = _examples(answer, given, own, as_written, most_data)
    if problem and spaces:
        # the difference in spaces is the application's own finding and stands without the answer's examples
        return dict(base, state="differs", why=reasons, examples=spaces["examples"], the_answers_examples_were_not_used=problem)
    if problem:
        return _unusable(problem, **base)
    return dict(base, state="differs", why=reasons, examples=examples)


def _examples(answer, given, own, as_written, most_data):
    """The example rows of a disagreement, checked. -> (examples, "") or ([], why they cannot be used). A row is kept exactly
    as the answer gives it (a space at the start or the end of a cell is part of the cell, and is what the Coder must see);
    it is looked up in both result files cell for cell as written."""
    ids = {i for i, _t in given["reqs"]}
    width, examples, keys = len(given["columns"]), [], []
    for d in (answer.get("differences") if isinstance(answer.get("differences"), list) else [])[:EXAMPLES_MOST]:
        if not isinstance(d, dict) or d.get("only_in") not in (ONLY_FAMILY, ONLY_RECHECK):
            return [], "an example of the difference does not say which side has the row"
        row = d.get("row")
        if not isinstance(row, list) or len(row) != width or any(isinstance(c, (dict, list)) for c in row):
            return [], "an example row does not have the %d column%s of the result" % (width, "" if width == 1 else "s")
        nums = d.get("file_rows") if isinstance(d.get("file_rows"), list) else []
        if not nums or any(_whole(x) is None for x in nums[:50]):
            return [], "an example row comes without the numbers of the rows of the data file it rests on"
        for x in nums[:50]:
            if not 1 <= x <= most_data:
                return [], "it cites row %s of the data file, and the file has %s (row 1 is the first row after the header)" % ("{:,}".format(x), _rows(most_data))
        cells = [c if isinstance(c, str) else str(c) if isinstance(c, (int, float)) and not isinstance(c, bool) else "" for c in row]
        keys.append(tuple(as_written(c) for c in cells))
        examples.append({"only_in": d["only_in"], "row": [_shown(c) for c in cells], "file_rows": nums[:50],
                         "requirement": d.get("requirement") if d.get("requirement") in ids else None, "reason": _line(d.get("reason"))})
    if not examples:
        return [], "it says it disagrees and shows no row that only one side has"
    in_family, in_own = _holds(given["result_csv"], set(keys), as_written), _holds(own, set(keys), as_written)
    for e, key in zip(examples, keys):
        fam, mine = key in in_family, key in in_own
        if (e["only_in"] == ONLY_FAMILY and not (fam and not mine)) or (e["only_in"] == ONLY_RECHECK and not (mine and not fam)):
            return [], ("the example row %s is said to be only in %s result; the application looked: it is %s the family's result and %s the recheck's"
                        % (json.dumps(e["row"], ensure_ascii=False), "the family's" if e["only_in"] == ONLY_FAMILY else "the recheck's", "in" if fam else "not in", "in" if mine else "not in"))
    return examples, ""


def feedback(rec, n):
    """A checked disagreement as the Coder's next round takes what failed: the same fields a Tester's finding has."""
    c = rec["counts"]
    who = "the recheck by the terminal agent (recheck %d of at most %d in this build)" % (n, RECHECKS_MOST)
    sp = rec.get("spaces")
    rows = []
    for e in rec["examples"]:
        one = {"which_side_has_it": "only the code's result" if e["only_in"] == ONLY_FAMILY else "only the recheck's result", "row": e["row"],
               "rows_of_the_data_file_it_rests_on": e["file_rows"], "requirement": e["requirement"], "the_recheck_says": e["reason"]}
        ends = _ends_words(e["row"])
        if ends:
            one["spaces_at_the_ends_of_its_cells"] = ends       # said in words too: a space inside quotes is easily overlooked
        if e.get("result_row"):
            one["row_of_the_result_file"] = e["result_row"]
        rows.append(one)
    out = {"found_by": who, "requirements_it_tests": [v["id"] for v in rec["verdicts"] if v["verdict"] == DISAGREES],
           "why_it_was_made": "the terminal agent wrote its own program from the requirements alone and ran it on the whole file; the application compared the two results",
           "what": "the code's result on the whole file holds %s; the recheck's own program gives %s, and the two do not hold the same rows" % (_rows(c["family_rows"]), _rows(c["recheck_rows"])),
           "its_reasons": [{"requirement": v["id"], "reason": v["reason"]} for v in rec["verdicts"] if v["verdict"] == DISAGREES],
           "rows_only_one_side_has": rows,
           "note": "the application checked that these rows are where the recheck says and that the row numbers exist; which side is right is not proven: "
                   "correct the code where the requirements are on the recheck's side, and say in your notes where they are not. " + CELLS_NOTE}
    if sp:
        out["what"] = ("the code's result on the whole file holds %s and the recheck's own program gives %s: %s. This is a difference, not an agreement: the application compares "
                       "every cell as it is written" % (_rows(c["family_rows"]), _rows(c["recheck_rows"]), sp["sentence"]))
        out["found_by_the_applications_own_comparison"] = SPACES_NOTE
    return [out]


def _given(b, code_path):
    """What one recheck is given, from the build as it stands."""
    r, proc = b.r, b.proc
    paths = {s["file"]: b.facts["paths"][s["file"]] for s in proc["source_data"]}
    d = os.path.join(os.path.dirname(code_path))
    stem = os.path.basename(code_path)[:-3]
    return {"name": r.get("name"), "rule": r.get("description") or r.get("name") or "", "steps": list(proc["steps"]), "reqs": list(b.reqs),
            "columns": list(proc["output"]["columns"]), "paths": paths, "data_rows": dict(b.whole.get("rows") or {}), "code_file": code_path,
            "result_csv": b.whole["out_csv"], "dictionary": {f: b.facts["dicts"].get(f) for f in paths if (b.facts.get("dicts") or {}).get(f)},
            "keep_program_at": os.path.join(d, "%s.recheck%d.py" % (stem, len(b.recheck["runs"]) + 1)),
            "n": len(b.recheck["runs"]) + 1, "earlier": [_earlier(x, len(b.reqs)) for x in b.recheck["runs"]]}


def _earlier(x, n_reqs):
    """One earlier recheck of this build as the next one's task file tells it: what it was made on, what it found, and the
    rows that differed, each cell exactly as it stands in the result file."""
    out = {"recheck": x.get("n"), "made_on_the_code_of_round": x.get("round"), "what_it_found": _words_of(x, n_reqs)}
    if x.get("state") == "differs":
        out["requirements_it_differed_on"] = [{"requirement": v["id"], "reason": v["reason"]} for v in x.get("verdicts") or [] if v["verdict"] == DISAGREES]
        if x.get("spaces"):
            out["found_by_the_applications_own_comparison"] = x["spaces"]["sentence"]
        out["rows_that_differed"] = [{"which_side_had_it": "only the earlier code's result" if e["only_in"] == ONLY_FAMILY else "only the earlier recheck's result", "row": e["row"],
                                      "rows_of_the_data_file_it_rests_on": e["file_rows"], "requirement": e["requirement"], "the_earlier_recheck_said": e["reason"]}
                                     for e in x.get("examples") or []]
    return out


def session_of(item, n, name):
    """(the agent key, the session's name) of recheck n of a build. Every recheck has a session of its own: the runner
    continues a session by scope and agent key (core.terminal_turn), each recheck starts in a folder of its own, and the
    real opencode program, continuing a session from another folder, printed nothing and never ended (measured twice on
    2026-11-15). The first recheck's key and name are as they always were."""
    if n <= 1:
        return "%s_%s" % (AGENT, item), "%s · %s" % (NAME, name)
    return "%s%d_%s" % (AGENT, n, item), "%s %d · %s" % (NAME, n, name)


def step(b, k, code_path, canon):
    """The recheck of one clean round's code. -> what goes back to the Coder (a list like the Tester's findings) or None.
    b: the Build (its ctx, facts, requirements, whole-file run and the record b.recheck are used). Never raises, except
    for Stop."""
    st = b.recheck
    mode = st["setting"]
    if mode == NEVER:
        return None

    def skip(why):
        st["skipped"] = why
        return None
    if mode == ASK and not st["asked"]:
        return skip("the setting says the recheck by the terminal agent is made only when you ask for it on this card: " + NOT_CONFINED)
    if len(st["runs"]) >= RECHECKS_MOST:
        return skip("the limit of %d rechecks in one build was reached" % RECHECKS_MOST)
    if "stand-in" in str(b.by).lower():
        return skip("the stand-in is in use")
    if b.on_tree:
        return skip("this rule reads the tree of the analysis; the recheck by the terminal agent is made for rules that read files")
    w = b.whole or {}
    if not w.get("out_csv") or w.get("not_finished") or w.get("error") or not os.path.isfile(w.get("out_csv") or ""):
        return skip("the code has no result on the whole file to compare with")
    runner = b.ctx.engine.runner
    problem = not_ready(runner)
    if problem:
        return skip(problem)
    n = len(st["runs"]) + 1
    rid = b.ctx.run["id"]
    rec = {"n": n, "round": k, "code_file": code_path, "at": time.time(), "state": "unusable", "why": ""}
    st["skipped"] = ""
    t0 = time.time()
    before = got = failed = given = box = log_file = None
    try:
        given = _given(b, code_path)
        marks = given["result_marks"] = fingerprints(given["result_csv"], canon)
        given["result_rows"], given["result_sum"] = marks["rows"], marks["sum"]
        box = os.path.join(runner.sandbox(rid, "family4_recheck_%s" % b.r["id"]), "recheck%d" % n)
        prepare(box, given)
        rec["folder"] = box
        folders = sorted({os.path.dirname(os.path.abspath(p)) for p in given["paths"].values()})
        prompt = prompts.load("f4_recheck", examples_most=EXAMPLES_MOST, program_file=PROGRAM_FILE, result_file=RESULT_FILE, rechecks_most=RECHECKS_MOST, shape=SHAPE) + (
            "\n\nYOUR FOLDER: %s\nTHE DATA FILE%s (read only): %s\nTHIS RECHECK: recheck %d of at most %d in this build%s.\nRead task.json in your folder first." % (
                box, "" if len(given["paths"]) == 1 else "S", "; ".join(given["paths"].values()), n, RECHECKS_MOST,
                "" if n == 1 else ", on repaired code (task.json says what recheck %d found on the earlier code)" % (n - 1)))
        agent_key, session_name = session_of(b.r["id"], n, b.r.get("name") or b.r["id"])
        rec["session"] = session_name

        def on_line(line):
            words = oc.event_words(line)
            if words.startswith("the agent: {"):
                words = "it writes its answer"         # the answer itself is checked first; the page shows it on the card
            if words:
                b.say(k, 0.97, "the recheck by the terminal agent (%d of at most %d, at most %d s): %s" % (n, RECHECKS_MOST, TIMEOUT_S, words[:200]))
        b.say(k, 0.96, "the recheck by the terminal agent (%d of at most %d): it writes its own program from the requirements and runs it on the whole file (at most %d s)"
              % (n, RECHECKS_MOST, TIMEOUT_S))
        runner._local.run = rid                 # so that Stop ends this call at once (AgentRunner.cancel ends the program)
        runner._stopped()
        # the watch on the data: the Python the agent runs is not confined, so every file it may read is recorded before it
        # is started and compared after it has ended, however it ended. Without the record the agent is not started
        b.say(k, 0.96, "the recheck by the terminal agent (%d of at most %d): the data files are recorded (size, change time, fingerprint) before it starts" % (n, RECHECKS_MOST))
        named = {p: "the data file %s" % f for f, p in given["paths"].items()}
        named.update({given["code_file"]: "the family's code", given["result_csv"]: "the family's result on the whole file"})
        before = snapshot(named, folders, skip=[box])
        log_file = _write_log(os.path.join(os.path.dirname(box), "recheck%d.data_watch.json" % n),
                              {"what_this_is": "the data files as they were before the terminal agent was started; the comparison after it ended is added below",
                               "recheck": n, "round": k, "before": before, "after": None, "changes": None})
        runner.slots.take(runner._stopped)
        try:
            # a session of its own for every recheck of the build (session_of): never the earlier recheck's session from another folder
            got = runner.terminal_turn(prompt, box, "run:%s" % rid, agent_key, session_name, want_json=True, timeout=TIMEOUT_S, oc_agent=oc.AGENT_INVESTIGATE, read_dirs=folders, on_line=on_line)
        finally:
            runner.slots.give()
    except Exception as e:      # noqa: BLE001 - a recheck that cannot be made is said on the card; the build goes on
        failed = e
    stopped = failed is not None and str(failed) == "the run was stopped"
    # ---- the comparison: after a clean end, a timeout, a Stop or a failure alike, and before anything of the answer is read
    found = []
    if before is not None:
        try:
            found, after = changes(before)
        except Exception as e:      # noqa: BLE001 - a comparison that could not be made is a recheck that is not used
            found, after = [{"file": "the data files", "what_it_is": "", "what_changed": "they could not be compared with the record taken before (%s)" % _line(str(e), 200),
                             "before": None, "after": None}], None
        names = {os.path.abspath(p): f for f, p in given["paths"].items()}
        sentence = changed_sentence(found, names) if found else ""
        ended = "it was stopped" if stopped else "it failed or did not answer in time (%s)" % _line(str(failed), 200) if failed is not None else "it answered"
        log_file = _write_log(os.path.join(os.path.dirname(box), "recheck%d.data_watch.json" % n),
                              {"what_this_is": "the data files before the terminal agent was started and after it had ended, compared by the application",
                               "recheck": n, "round": k, "how_the_terminal_agent_ended": ended, "the_data_changed": bool(found), "sentence": sentence,
                               "changes": found, "before": before, "after": after}) or log_file
        rec["data_watch"] = {"files_recorded": len(before["files"]), "changed": bool(found), "log_file": log_file, "seconds_before": before["seconds"],
                             "seconds_after": (after or {}).get("seconds"), "listing_cut": before["listing_cut"],
                             "fingerprints_of": {names.get(p) or p: f.get("fingerprint_of") for p, f in before["files"].items() if p in names}}
        if found:
            # the answer is never read: no agreement, no feedback to the Coder, and the rounds end here (None goes back)
            rec.update(state=DATA_CHANGED, why=sentence, how_the_terminal_agent_ended=ended)
            rec["data_watch"]["changes"] = found
            LOG.warning("run %s, recheck %d: %s Before and after: %s", rid, n, sentence,
                        json.dumps([{x: c[x] for x in ("file", "before", "after")} for c in found], ensure_ascii=False, default=str)[:4000])
            try:
                b.say(k, 0.98, sentence[:600])
            except Exception:       # noqa: BLE001 - the record and the log are written; the status line is only a convenience
                pass
    if found:
        rec["seconds"] = round(time.time() - t0, 1)
        st["runs"].append(rec)
        if stopped:
            raise failed
        b._alive()
        return None
    if failed is not None:
        if stopped:
            raise failed
        b._alive()
        words = _line(str(failed), 300)
        rec.update(state="not made", why=("it did not answer within %d s and was ended" % TIMEOUT_S) if "no answer within" in words else
                   "its answer was not in the form that was asked for" if "holds no JSON object" in words else words or type(failed).__name__)
    else:
        try:
            rec["by"] = got.get("producer")
            rec.update(check(got.get("answer"), got.get("text"), box, given, canon))
        except Exception as e:      # noqa: BLE001 - an answer that cannot be checked is not an agreement; the build goes on
            rec.update(state="not made", why=_line(str(e), 300) or type(e).__name__)
    rec["seconds"] = round(time.time() - t0, 1)
    st["runs"].append(rec)
    b._alive()
    return feedback(rec, n) if rec["state"] == "differs" else None


def new_state(engine, asked=False):
    return {"setting": setting(engine), "asked": bool(asked), "runs": [], "skipped": "", "most": RECHECKS_MOST, "seconds_most": TIMEOUT_S,
            "standin": getattr(getattr(engine, "runner", None), "runtime", None) == "standin"}


def summary(st, offered_code, n_reqs, clean, by=""):
    """What the card says, decided from the record alone. -> None (setting "never") or {"state", "sentence", "lines"}.
    state: "agrees" only when the last recheck was made on the code shown and passed every check."""
    if st["setting"] == NEVER:
        return None
    runs = st["runs"]
    made = "%d recheck%s made of at most %d" % (len(runs), "" if len(runs) == 1 else "s", st["most"])
    last = runs[-1] if runs else None
    lines = []
    bad = next((x for x in runs if x["state"] == DATA_CHANGED), None)
    if bad:
        # its own state, said before anything else: the answer of this recheck is not used and none is made after it in this build
        for c in ((bad.get("data_watch") or {}).get("changes") or [])[:20]:
            lines.append("%s (%s): before: %s; after: %s" % (c["file"], c.get("what_it_is") or "a file", _facts_words(c.get("before")), _facts_words(c.get("after"))))
        log_file = (bad.get("data_watch") or {}).get("log_file")
        lines.append("How the terminal agent ended: %s. Files it writes are expected in its own folder only. %s%s"
                     % (bad.get("how_the_terminal_agent_ended") or "it answered", "The record of every file before and after is kept in %s. " % log_file if log_file else "",
                        made[0].upper() + made[1:] + "; no further recheck is made in this build."))
        return {"state": DATA_CHANGED, "sentence": bad["why"], "lines": lines, "rechecks": len(runs)}
    if not last:
        why = st["skipped"] or ("the stand-in is in use" if st.get("standin") or "stand-in" in str(by).lower() else
                                "the rounds of Coder and Tester did not end clean, and only code that passed them is rechecked" if not clean else "it was not started")
        return {"state": "not rechecked", "sentence": "Not rechecked by the terminal agent: %s." % why, "lines": [], "rechecks": 0}
    on_shown = last["code_file"] == offered_code
    for x in runs[:-1] if on_shown else runs:
        lines.append("recheck %d (on the code of round %s): %s" % (x["n"], x["round"], _words_of(x, n_reqs)))
    if not on_shown:
        why = st["skipped"] or "the rounds after it did not end clean, and only code that passed them is rechecked"
        return {"state": "not rechecked", "sentence": "Not rechecked by the terminal agent: the code shown was written after recheck %d and was not rechecked itself (%s); %s."
                % (last["n"], why, made), "lines": lines, "rechecks": len(runs)}
    state = {"agrees": "agrees", "differs": "differs", "could not check": "could not check", "unusable": "could not be used"}.get(last["state"], "not rechecked")
    sentence = _words_of(last, n_reqs)
    sentence = sentence[0].upper() + sentence[1:] + "; " + made + "."
    if last["state"] == "differs":
        for e in last.get("examples") or []:
            where = ("rows %s of the data file" % ", ".join("{:,}".format(x) for x in e["file_rows"][:12]) if e["file_rows"] else
                     "row %s of that result file" % "{:,}".format(e["result_row"]) if e.get("result_row") else "found by the application")
            lines.append("only in %s result: %s (%s)%s" % ("the code's" if e["only_in"] == ONLY_FAMILY else "the recheck's", json.dumps(e["row"], ensure_ascii=False),
                                                         where, ": " + e["reason"] if e["reason"] else ""))
        if last.get("examples"):
            lines.append(CELLS_NOTE)
    for v in last.get("verdicts") or []:
        if v["verdict"] != AGREES:
            lines.append("%s %s: %s" % (v["id"], v["verdict"], v["reason"] or "no reason given"))
    return {"state": state, "sentence": sentence, "lines": lines, "rechecks": len(runs)}


def _facts_words(f):
    if not isinstance(f, dict) or not f.get("there"):
        return "not there"
    return "%s, changed at %s, fingerprint of %s %s" % (_size(f.get("size") or 0), f.get("changed_at"), f.get("fingerprint_of"),
                                                          (f.get("fingerprint") or "")[:16] + "…" if f.get("fingerprint") else "(none)")


def _words_of(x, n_reqs):
    c = x.get("counts") or {}
    both = "the code's result: %s; the recheck's own program: %s" % (_rows(c.get("family_rows") or 0), _rows(c.get("recheck_rows") or 0)) if c else ""
    if x["state"] == "agrees":
        ok = sum(1 for v in x["verdicts"] if v["verdict"] == AGREES)
        if ok == n_reqs:
            return "rechecked by the terminal agent: agrees on all %d requirement%s (%s; the same rows, compared by the application)" % (n_reqs, "" if n_reqs == 1 else "s", both)
        return ("rechecked by the terminal agent: agrees on %d of %d requirements and could not check %d (%s; the same rows, compared by the application)"
                % (ok, n_reqs, n_reqs - ok, both))
    if x["state"] == "differs" and x.get("spaces"):
        ids = ", ".join(v["id"] for v in x["verdicts"] if v["verdict"] == DISAGREES)
        return ("rechecked by the terminal agent: it differs in spaces (%s): the application compared the two results cell for cell as written, and %s. "
                "This is a difference: whether the spaces are removed is a requirement of the rule. %s" % (
                    both, x["spaces"]["sentence"], "The terminal agent differs on %s: %s" % (ids, x["why"]) if ids else "The terminal agent named no requirement it differs on"))
    if x["state"] == "differs":
        return "rechecked by the terminal agent: it differs on %s (%s; not the same rows). Its reason: %s" % (
            ", ".join(v["id"] for v in x["verdicts"] if v["verdict"] == DISAGREES), both, x["why"])
    if x["state"] == "could not check":
        return "not rechecked: the terminal agent could not check (%s)" % x["why"]
    if x["state"] == "unusable":
        return "the recheck's answer could not be used: %s. This is not an agreement" % x["why"]
    if x["state"] == DATA_CHANGED:
        return x["why"]
    return "not rechecked: %s" % (x.get("why") or "the terminal agent gave no answer")
