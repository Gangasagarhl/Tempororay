"""How a table file is written, worked out from the file itself: its first bytes and its first lines.

The people who own a measuring tool turn its recording into a CSV, and tools do not agree on what "a CSV" is. Before a
file is read, detect(path) decides four things, each stored with HOW it was decided (nothing is guessed silently):

  the encoding     UTF-8 with or without a byte order mark; UTF-16 little or big endian by its byte order mark, and without
                   one only when the pattern of zero bytes is unmistakable; else UTF-8 with unreadable bytes replaced, as before
  the separator    comma, semicolon, tab or vertical bar: the one that gives the same number of cells on nearly every one of
                   the first lines (quoted cells counted properly). A tie, or no clear answer: "could not tell", and the comma
                   is used, as before. Among several that do, the one whose table starts on the earliest line is taken (a decimal
                   comma in a semicolon file gives "the same number of cells" only below the header)
  the header line  the first line from which on nearly all following lines have the same number of cells. The lines above it
                   are kept as "lines before the header" and shown; they are never thrown away silently
  refused          a file that cannot be read as a table (not text, one cell on every line, the lines do not agree on a number
                   of cells), with one plain sentence that says what was seen

number_style(counts) decides, per column and from the column's own counted values, how its numbers are written (decimal
point or decimal comma, a thousands sign), with the counts; "ambiguous" when the values do not decide it ("1,234" alone can
be 1.234 or 1234).

Nothing here says what a column MEANS: a unit in a header ("IO Time (µs)") is kept in the header text exactly as written,
for the Data Grounder to read. Only the standard library is used (the worker processes import this module on every system).
"""
import csv
import functools
import io
import os
import re
from collections import Counter

SAMPLE_BYTES = 1024 * 1024      # how much of the start of a file is looked at
SAMPLE_LINES = 200              # how many of its first lines are looked at
NEARLY = 0.9                    # "nearly every line": at least this share of the lines looked at
REFUSE_ABOVE = 0.5              # more than this share of the lines differing in their number of cells: not a table
MAX_BEFORE = 50                 # a header is looked for within this many lines from the top
KEPT_BEFORE = 50                # lines before the header that are stored (each cut at KEPT_CHARS characters)
KEPT_CHARS = 500
NUMERIC_SHARE = 0.9             # a column "looks numeric" when at least this share of its counted values are written as numbers
SEPARATORS = ((",", "comma"), (";", "semicolon"), ("\t", "tab"), ("|", "vertical bar"))
SEP_NAME = dict(SEPARATORS)
ENCODING_NAME = {"utf-8-sig": "UTF-8", "utf-16-le": "UTF-16, little endian", "utf-16-be": "UTF-16, big endian"}
MAX_LINE_CHARS = 64 * 1024 * 1024       # as nvme_hier.loader.MAX_LINE_CHARS: a line is never read past this


class NotATable(ValueError):
    """The file cannot be read as a table; the message is one plain sentence that says what was seen."""


def _n(x):
    return "{:,}".format(x)


def _lines_word(n):
    return "%s line%s" % (_n(n), "" if n == 1 else "s")


# ---------------------------------------------------------------------------------------------- the encoding
def _encoding(raw):
    """-> (codec, bytes of the byte order mark, how it was decided, refused or None) from the first bytes of the file."""
    if raw.startswith(b"\xef\xbb\xbf"):
        return "utf-8-sig", 3, "the file starts with the three bytes EF BB BF, the byte order mark of UTF-8", None
    if raw.startswith(b"\xff\xfe\x00\x00") or raw.startswith(b"\x00\x00\xfe\xff"):
        return "utf-8-sig", 0, "", "it starts with the byte order mark of UTF-32 text, which this application does not read: save it as UTF-8 or UTF-16"
    if raw.startswith(b"\xff\xfe"):
        return "utf-16-le", 2, "the file starts with the two bytes FF FE, the byte order mark of UTF-16 little endian", None
    if raw.startswith(b"\xfe\xff"):
        return "utf-16-be", 2, "the file starts with the two bytes FE FF, the byte order mark of UTF-16 big endian", None
    zeros = raw.count(0)
    if not zeros:
        return "utf-8-sig", 0, "no byte order mark and no zero byte in the first %s bytes: read as UTF-8, as before" % _n(len(raw)), None
    pairs = len(raw) // 2
    even, odd = raw[0:2 * pairs:2].count(0), raw[1:2 * pairs:2].count(0)
    said = "no byte order mark; of the first %s pairs of bytes, %s have a zero as second byte and %s as first byte" % (_n(pairs), _n(odd), _n(even))
    if pairs >= 8 and odd >= NEARLY * pairs and even * 50 <= pairs:
        return "utf-16-le", 0, said + ": the pattern of UTF-16 little endian text", None
    if pairs >= 8 and even >= NEARLY * pairs and odd * 50 <= pairs:
        return "utf-16-be", 0, said + ": the pattern of UTF-16 big endian text", None
    return "utf-8-sig", 0, "", ("%s of its first %s bytes are zero bytes, which text does not hold, and they do not follow the pattern of UTF-16 text: "
                                "this is not a text file" % (_n(zeros), _n(len(raw))))


# ---------------------------------------------------------------------------------------------- the first lines
_LINE_END = re.compile(rb"\r\n|\r|\n")


def _first_lines(raw, codec, bom, whole):
    """The first physical lines of the file, with their line ends, as text: -> (lines, the byte where each line starts or None).
    Lines end at \\n, \\r or \\r\\n, as the reading itself takes them. A last line cut by the end of the sample is left out."""
    if codec.startswith("utf-16"):
        body = raw[bom:]
        text = body[:len(body) - len(body) % 2].decode(codec, errors="replace")
        lines, fh = [], io.StringIO(text, newline="")
        while len(lines) <= SAMPLE_LINES + MAX_BEFORE:
            ln = fh.readline()
            if not ln:
                break
            lines.append(ln)
        if not whole and lines and fh.tell() >= len(text):
            lines.pop()
        return lines, None
    lines, starts, pos = [], [], bom
    for m in _LINE_END.finditer(raw, bom):
        lines.append(raw[pos:m.end()].decode("utf-8", errors="replace"))
        starts.append(pos)
        pos = m.end()
        if len(lines) > SAMPLE_LINES + MAX_BEFORE:
            break
    else:
        if whole and pos < len(raw):
            lines.append(raw[pos:].decode("utf-8", errors="replace"))
            starts.append(pos)
        elif not whole and lines and pos == len(raw) and raw.endswith(b"\r"):
            lines.pop()             # a \r at the very end of the sample may be half of a \r\n
            starts.pop()
    return lines, starts


def _records(lines, sep, start=0):
    """The rows csv.reader gives for the lines from `start` on, with this separator: -> [(the line the row starts at, its cells)].
    A row the reader refuses ends the list."""
    out, at = [], start
    rd = csv.reader(iter(lines[start:]), delimiter=sep)
    try:
        for row in rd:
            out.append((at, row))
            at = start + rd.line_num
    except csv.Error:
        pass
    return out


def _blank(row):
    return not row or (len(row) == 1 and not row[0].strip())


def _table(recs):
    """Where a table starts in these rows: the first row from which on nearly all rows have the same number of cells (2 or more).
    -> {"at": index of that row among the rows that are not blank, "line": the line it starts at, "cells", "agree", "of"} or None."""
    rows = [(ln, len(r)) for ln, r in recs if not _blank(r)]
    if len(rows) < 2:
        return None
    best = None
    for width, _k in Counter(k for _ln, k in rows).most_common(4):
        if width < 2:
            continue
        agree, found = 0, None
        for i in range(len(rows) - 1, -1, -1):          # from the last row up: how many rows from row i on have this many cells
            agree += rows[i][1] == width
            if rows[i][1] == width and agree >= NEARLY * (len(rows) - i) and len(rows) - i >= 2:
                found = (i, agree)
        # the table must be at least as long as what stands above it (three lines above are always allowed): two lines that happen
        # to agree at the end of a file of uneven lines are not a table
        if found and found[0] <= MAX_BEFORE and found[0] <= max(3, len(rows) - found[0]):
            i, agree = found
            cand = {"at": i, "line": rows[i][0], "cells": width, "agree": agree, "of": len(rows) - i}
            if best is None or (cand["of"], cand["agree"]) > (best["of"], best["agree"]):
                best = cand
    return best


def _try(lines, sep, cut):
    """The table this separator gives. First with the lines read as rows from the top; when that gives none (a quotation mark in a
    title line can swallow the lines after it), from each of the first lines in turn."""
    recs = _records(lines, sep)
    if cut and len(recs) > 5:
        recs = recs[:-1]            # the sample ends somewhere: its last row may be half a row
    t = _table(recs)
    if t or not any('"' in ln for ln in lines[:MAX_BEFORE]):
        return t, recs
    for start in range(1, min(len(lines), MAX_BEFORE)):
        r2 = _records(lines, sep, start)
        if cut and len(r2) > 5:
            r2 = r2[:-1]
        t = _table(r2)
        if t and t["at"] == 0:
            return t, r2
    return None, recs


def _seen(name, t):
    return "the %s gives %d cells on %s of the %s from line %d on" % (name, t["cells"], _n(t["agree"]), _lines_word(t["of"]), t["line"] + 1)


# ---------------------------------------------------------------------------------------------- the whole decision
def detect(path):
    """How the file is written. -> a dict (do not change it: it is kept for the next call while the file stays the same):

    codec, bom_bytes        what the file is opened with ("utf-8-sig" also reads UTF-8 without a byte order mark), and the mark's length
    encoding, encoding_how  the encoding in words, and how it was decided
    separator, separator_name, separator_decided, separator_how
    header_line             1 = the first line of the file; lines_before = the text of the lines above it (lines_before_count of them)
    header_how, header_byte the byte at which the header line starts (None for UTF-16)
    lines_looked_at
    refused                 None, or one plain sentence: why this file cannot be read as a table
    as_before               True when the file is read exactly as before this module existed: UTF-8, comma (decided), header on line 1"""
    st = os.stat(path)
    return _detect(path, st.st_size, st.st_mtime_ns)


@functools.lru_cache(maxsize=256)
def _detect(path, size, _mtime):
    with open(path, "rb") as fb:
        raw = fb.read(SAMPLE_BYTES)
    whole = len(raw) >= size
    name = os.path.basename(path)
    codec, bom, enc_how, refused = _encoding(raw)
    d = {"codec": codec, "bom_bytes": bom, "encoding": ENCODING_NAME[codec] + (" with a byte order mark" if bom else ""), "encoding_how": enc_how,
         "separator": ",", "separator_name": "comma", "separator_decided": False, "separator_how": "", "header_line": 1, "lines_before": [],
         "lines_before_count": 0, "header_how": "", "header_byte": bom if codec == "utf-8-sig" else None, "lines_looked_at": 0,
         "refused": None, "as_before": False}
    if refused:
        d["refused"] = "%s cannot be read as a table: %s." % (name, refused)
        return d
    lines, starts = _first_lines(raw, codec, bom, whole)
    d["lines_looked_at"] = len(lines)
    text = "".join(lines)
    if text:
        odd = sum(1 for ch in text if ch < " " and ch not in "\t\r\n\f\x1a")
        bad = text.count("�")
        # text holds next to no control characters; a file in an older encoding (Latin-1) has a few bytes that are not UTF-8, not three in ten
        if odd * 10 > len(text) or bad * 10 > 3 * len(text):
            d["refused"] = ("%s cannot be read as a table: of its first %s characters, %s are control characters and %s are bytes that are "
                            "not UTF-8 text: this is not a text file." % (name, _n(len(text)), _n(odd), _n(bad)))
            return d
        if bad and codec == "utf-8-sig":
            d["encoding_how"] += "; %s byte sequence%s in the first %s are not UTF-8 and are shown as the replacement sign" % (
                _n(bad), "" if bad == 1 else "s", _lines_word(len(lines)))
    if not lines:
        d["separator_how"] = "could not tell: %s; the comma is used, as before" % (
            "the file is empty (0 bytes)" if not size else "the first %s bytes of the file hold no complete line" % _n(len(raw)))
        d["header_how"] = "no line to look at: the first line is taken as the header, as before"
        d["as_before"] = codec == "utf-8-sig"            # nothing to decide from: read exactly as before
        return d
    found, widest, shares = {}, {}, {}
    for sep, sep_name in SEPARATORS:
        t, recs = _try(lines, sep, not whole)
        rows = [r for _ln, r in recs if not _blank(r)]
        widest[sep] = max([len(r) for r in rows] or [0])
        if rows:
            k, many = Counter(len(r) for r in rows).most_common(1)[0]
            shares[sep] = (k, many, len(rows))
        if t:
            found[sep] = t
    n_rows = max([s[2] for s in shares.values()] or [0])
    if n_rows <= 1:
        # one line only: nothing to compare it with
        can = [s for s, _nm in SEPARATORS if widest.get(s, 0) >= 2]
        if len(can) == 1:
            d.update(separator=can[0], separator_name=SEP_NAME[can[0]], separator_decided=True,
                     separator_how="the file holds one line, and of comma, semicolon, tab and vertical bar only the %s is in it (%d cells)" % (
                         SEP_NAME[can[0]], widest[can[0]]))
        else:
            d["separator_how"] = "could not tell: the file holds %s, %s; the comma is used, as before" % (
                "one line" if n_rows else "blank lines only", "and none of comma, semicolon, tab and vertical bar is in it" if not can else
                "and %s are all in it" % ", ".join(SEP_NAME[s] for s in can))
        d["header_how"] = "the file holds %s: the first line is taken as the header, as before" % ("one line" if n_rows else "blank lines only")
        d["as_before"] = codec == "utf-8-sig" and d["separator"] == ","
        return d
    if not any(w >= 2 for w in widest.values()):
        d["refused"] = ("%s cannot be read as a table: every one of its first %s is one cell only (no comma, semicolon, tab or vertical bar "
                        "separates cells)." % (name, _lines_word(n_rows)))
        return d
    table = None
    if found:
        # the separator whose table starts on the earliest line: a sign that only stands inside cells (a decimal comma in a semicolon
        # file) gives its "same number of cells" only below the header. Two that start on the same line: no clear answer
        order = sorted(found, key=lambda s: (found[s]["line"], [x for x, _nm in SEPARATORS].index(s)))
        top = [s for s in order if found[s]["line"] == found[order[0]]["line"]]
        said = "; ".join(_seen(SEP_NAME[s], found[s]) for s in order)
        none = [nm for s, nm in SEPARATORS if s not in found]
        if none:
            said += "; %s: no such run of lines" % ", ".join(none)
        if len(top) == 1:
            sep = top[0]
            table = found[sep]
            d.update(separator=sep, separator_name=SEP_NAME[sep], separator_decided=True,
                     separator_how="the %s gives the same number of cells on nearly every line from the earliest line on: %s" % (SEP_NAME[sep], said))
        else:
            d["separator_how"] = "could not tell: %s fit equally well, from the same line on (%s); the comma is used, as before" % (" and ".join(SEP_NAME[s] for s in top), said)
            table = found.get(",")
    else:
        parts = ["%s: most often %d cell%s, on %s of %s" % (SEP_NAME[s], k, "" if k == 1 else "s", _n(many), _lines_word(of))
                 for s, (k, many, of) in shares.items() if widest[s] >= 2]
        best = max(many / float(of) for s, (k, many, of) in shares.items() if widest[s] >= 2)
        if best < 1.0 - REFUSE_ABOVE:
            d["refused"] = ("%s cannot be read as a table: with every separator tried, more than %d%% of its first lines have another number of "
                            "cells than the most common one (%s)." % (name, round(REFUSE_ABOVE * 100), "; ".join(parts)))
            return d
        d["separator_how"] = "could not tell: with no separator do %d%% of the first lines have the same number of cells (%s); the comma is used, as before" % (
            round(NEARLY * 100), "; ".join(parts))
    if table:
        at = table["line"]
        d["header_line"] = at + 1
        d["lines_before_count"] = at
        d["lines_before"] = [ln.rstrip("\r\n")[:KEPT_CHARS] for ln in lines[:min(at, KEPT_BEFORE)]]
        d["header_byte"] = starts[at] if starts is not None else None
        d["header_how"] = ("line %d is the first line from which on nearly all lines have the same number of cells (%d cells on %s of %s)" % (
            at + 1, table["cells"], _n(table["agree"]), _lines_word(table["of"]))) + (
            "; the %s above it %s kept as lines before the header" % (_lines_word(at), "is" if at == 1 else "are") if at else "")
    else:
        d["header_how"] = "the separator could not be told, so the first line is taken as the header, as before"
    d["as_before"] = codec == "utf-8-sig" and d["separator"] == "," and d["separator_decided"] and d["header_line"] == 1
    return d


def record(d):
    """What is stored about a file with its profile and its dictionary: every decision with how it was made, in plain words."""
    before = d["lines_before_count"]
    text = "Written as %s, cells separated by a %s%s, header on line %d%s." % (
        d["encoding"], d["separator_name"], "" if d["separator_decided"] else " (the separator could not be told from the file; the comma is used)",
        d["header_line"], " (%s above it %s not part of the table)" % (_lines_word(before), "is" if before == 1 else "are") if before else "")
    return {"encoding": {"value": d["encoding"], "codec": d["codec"], "how": d["encoding_how"]},
            "separator": {"value": d["separator"], "name": d["separator_name"], "decided": d["separator_decided"], "how": d["separator_how"]},
            "header": {"line": d["header_line"], "lines_before": list(d["lines_before"]), "lines_before_count": before, "how": d["header_how"]},
            "lines_looked_at": d["lines_looked_at"], "text": text}


# ---------------------------------------------------------------------------------------------- reading with what was decided
def open_text(path, d):
    """The file opened as text, as the reading has always opened it (unreadable bytes replaced, line ends untouched), in its encoding."""
    return open(path, "r", encoding=d["codec"], errors="replace", newline="")


def _lines(fh, name, first, bad):
    """The lines of an open text file for csv.reader, as nvme_hier.loader.csv_lines gives them (a line stops at MAX_LINE_CHARS)."""
    n = 0
    while True:
        line = fh.readline(MAX_LINE_CHARS)
        if not line:
            return
        n += 1
        if len(line) >= MAX_LINE_CHARS and line[-1] not in "\r\n":
            raise bad("line %d of %s is longer than %d MB: this is not an analyzer's CSV export" % (n, os.path.basename(name) or "the file", MAX_LINE_CHARS // 1024 ** 2))
        if first and n == 1 and line.startswith("﻿"):
            line = line[1:]
        yield line


class Rows:
    """The rows of an open file from its header line on (the header is the first row given), read as csv.reader reads them with the
    file's separator. Used like csv.reader, line_num included. For a file written as before (comma, header on line 1) this is the
    reading the application has always done. A cell that never ends (a stray quotation mark) stops with a plain message."""

    def __init__(self, fh, path, d, bad=NotATable):
        self.name, self.bad = path, bad
        for _ in range(d["header_line"] - 1):           # the lines before the header: kept in the record, not rows of the table
            fh.readline(MAX_LINE_CHARS)
        self.lines_before = d["header_line"] - 1
        strip_mark = d["codec"].startswith("utf-16")     # the utf-16-le and -be codecs leave the byte order mark in the text
        self.rd = csv.reader(_lines(fh, path, strip_mark and d["header_line"] == 1, bad), delimiter=d["separator"])

    def __iter__(self):
        return self

    def __next__(self):
        try:
            return next(self.rd)
        except csv.Error as e:
            raise self.bad("%s, near line %d, cannot be read as CSV: %s (a stray quote can do this)" % (
                os.path.basename(self.name) or "the file", self.rd.line_num, e)) from e

    @property
    def line_num(self):
        return self.rd.line_num


def sniff(path, n=3):
    """-> (header, the first n rows, how the file is written). NotATable for a file that is refused."""
    d = detect(path)
    if d["refused"]:
        raise NotATable(d["refused"])
    with open_text(path, d) as fh:
        rd = Rows(fh, path, d)
        header = next(rd, [])
        rows = []
        for row in rd:
            if len(rows) >= n:
                break
            rows.append(row)
    return header, rows, d


# ---------------------------------------------------------------------------------------------- how a column writes its numbers
_NUMBER = re.compile(r"^[+-]?\d[\d.,]*$")
_GROUPS = re.compile(r"^\d{1,3}$")


def _grouped(whole, sign):
    """Is `whole` digits in groups of three with this sign between them (1.234.567)? A group of thousands never starts the number with 0."""
    parts = whole.split(sign)
    return len(parts) >= 2 and bool(_GROUPS.match(parts[0])) and not parts[0].startswith("0") and all(len(p) == 3 and p.isdigit() for p in parts[1:])


def _form(v):
    """What one value says about the number style: 'whole' (digits only), 'comma' / 'point' (that sign is the decimal sign for sure),
    'either,' / 'either.' (one sign followed by exactly three digits: decimal sign or thousands sign), or None (not written as a number)."""
    if not _NUMBER.match(v):
        return None
    v = v.lstrip("+-")
    commas, points = v.count(","), v.count(".")
    if not commas and not points:
        return "whole"
    if commas and points:
        dec = "," if v.rfind(",") > v.rfind(".") else "."
        tho = "." if dec == "," else ","
        whole, _s, frac = v.rpartition(dec)
        if v.count(dec) == 1 and frac.isdigit() and _grouped(whole, tho):
            return "comma" if dec == "," else "point"
        return None
    sign = "," if commas else "."
    if v.count(sign) >= 2:              # 1.234.567: the sign stands between thousands, so the other one is the decimal sign
        return ("point" if sign == "," else "comma") if _grouped(v, sign) else None
    whole, _s, frac = v.partition(sign)
    if not whole.isdigit() or not frac.isdigit():
        return None
    if len(frac) == 3 and len(whole) <= 3 and not whole.startswith("0"):
        return "either" + sign
    return "comma" if sign == "," else "point"


def _value(v, dec, tho):
    try:
        return float(v.replace(tho, "").replace(dec, "."))
    except ValueError:
        return None


def number_style(counts):
    """How the numbers of one column are written, decided from its own counted values. counts = {value as written: rows holding it}.

    -> None for a column that needs no telling: no value written as a number with a comma or a point, or the column does not look
       numeric (fewer than NUMERIC_SHARE of its values are written as numbers), or every such value is a plain decimal-point number
       that can only be read one way (0.5, 12.25: what every program reads as it stands);
    -> else {"style": "decimal comma" | "decimal point" | "ambiguous" | "mixed", "decimal_sign", "thousands_sign", "values_looked_at",
             "counts": {...}, "how": one plain sentence with the counts, "examples": [...], and for a decided style "min", "max" (as
             numbers) with "min_as_written", "max_as_written"}.
    "ambiguous": the values do not decide it ("1,234" can be 1.234 or 1234) and no number is given. "mixed": some values need the
    comma as decimal sign and others the point; no number is given either."""
    tally, example = Counter(), {}
    for v, k in counts.items():
        f = _form(v)
        tally[f] += 1
        example.setdefault(f, v)
    n = sum(tally.values())
    numbers = n - tally[None]
    signed = tally["comma"] + tally["point"] + tally["either,"] + tally["either."]
    if not n or not signed or numbers < NUMERIC_SHARE * n:
        return None
    if not tally["comma"] and not tally["either,"] and not tally["either."] and not any("," in v for v in counts if _form(v) == "point"):
        return None                         # plain decimal-point numbers only: read as they stand, as before
    c = {"values_with_a_decimal_comma": tally["comma"], "values_with_a_decimal_point": tally["point"],
         "values_with_one_comma_and_three_digits_after": tally["either,"], "values_with_one_point_and_three_digits_after": tally["either."],
         "whole_numbers": tally["whole"], "not_numbers": tally[None]}
    out = {"style": "", "decimal_sign": None, "thousands_sign": None, "values_looked_at": n, "counts": c,
           "examples": [example[f][:40] for f in ("comma", "point", "either,", "either.") if f in example]}
    of = "of the %s different values counted" % _n(n)
    if tally["comma"] and tally["point"]:
        out["style"] = "mixed"
        out["how"] = ("could not tell: %s, %s can only be read with a decimal comma (such as %s) and %s only with a decimal point (such as %s); "
                      "no value of this column is read as a number" % (of, _n(tally["comma"]), example["comma"], _n(tally["point"]), example["point"]))
        return out
    if not tally["comma"] and not tally["point"]:
        both = tally["either,"] and tally["either."]
        sign, ex = ("comma", example.get("either,")) if tally["either,"] else ("point", example.get("either."))
        out["style"] = "ambiguous"
        out["how"] = ("ambiguous: %s, %s are written with one %s followed by exactly three digits (such as %s), which can be a decimal sign or a "
                      "thousands sign (%s is %s or %s); no other value decides it, so no value of this column is read as a number" % (
                          of, _n(tally["either,"] + tally["either."]), "comma or one point" if both else sign, ex, ex,
                          ex.replace(",", "."), ex.replace(",", "").replace(".", "") if sign == "comma" else ex.replace(".", "")))
        return out
    dec, tho, name, key = (",", ".", "decimal comma", "comma") if tally["comma"] else (".", ",", "decimal point", "point")
    uses_tho = any(tho in v for v in counts if _form(v) in (key, "either" + tho))
    out.update(style=name, decimal_sign=dec, thousands_sign=tho if uses_tho else None)
    nums = [(x, v) for x, v in ((_value(v, dec, tho), v) for v in counts if _form(v) is not None) if x is not None]
    if nums:
        lo, hi = min(nums), max(nums)
        out.update(min=lo[0], max=hi[0], min_as_written=lo[1][:40], max_as_written=hi[1][:40])
    out["how"] = "%s: %s, %s can only be read with a %s (such as %s)%s%s" % (
        name, of, _n(tally[key]), name, example[key],
        "; the %s stands between thousands" % ("point" if tho == "." else "comma") if uses_tho else "",
        "; the %s with one %s and three digits after it are read the same way (%s as a %s)" % (
            _n(tally["either" + dec] + tally["either" + tho]), "comma or point" if tally["either" + dec] and tally["either" + tho] else
            ("comma" if (dec == "," and tally["either,"]) or (dec == "." and not tally["either."]) else "point"),
            "the %s" % ("comma" if dec == "," else "point") if tally["either" + dec] and not tally["either" + tho] else
            "the %s" % ("point" if tho == "." else "comma") if tally["either" + tho] and not tally["either" + dec] else "each sign",
            "decimal sign" if tally["either" + dec] and not tally["either" + tho] else
            "thousands sign" if tally["either" + tho] and not tally["either" + dec] else "decided above")
        if tally["either" + dec] + tally["either" + tho] else "")
    return out
