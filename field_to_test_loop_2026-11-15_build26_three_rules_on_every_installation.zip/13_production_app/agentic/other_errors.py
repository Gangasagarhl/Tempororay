"""Errors that a rule found in a CSV file that is not part of the tree (owner, 2026-11-14: the second half for ANY CSV).

An item of a section that finds defects, in the group "Other CSV files" (family3 level "other"), runs code written by
Family 4 on a file of the analysis's folder. Its result is a CSV. The rows it found become ERRORS of the analysis here:
one record per found row with the file's name, the row's number in the file, the rule and the row's cells.

What is known comes from the file and from Family 1's approved dictionary. Nothing about NVMe is assumed for the file:
no column is taken for a time, a queue or a status unless the dictionary's own words say so, and then it is reported
with those words (nvme_command_mapping), never used.

THE REQUIREMENT ON THE RESULT (checked by code, result_problem and ingest): the result names its source rows.
  - a column named exactly "row number in the file" (ROW_COLUMN): the number of the row in the source file as Python's
    csv reader counts the rows, the first row under the header being row 1 (a blank line counts as a row; lines above
    the header, such as a title line, are not rows and are not counted: with the header on line H of the file, row 1
    starts on line H + 1, and the line of every row is kept and shown beside its row number);
  - when the procedure reads more than one file, also a column named exactly "file" with the file's name;
  - a result column that has the name of a column of the file must hold that row's own cell (this is how a row number
    that is one off is found out).
A result that does not meet this is refused in plain words; nothing is listed for it.

WHERE THE ERRORS ARE KEPT: one SQLite file per analysis run, in the run's own folder
(<runs>/agentic/run_<n>/other_errors/errors.sqlite), not in the engine's store. Why: the engine's store is one file for
every analysis and is written by the engine's thread; a rule may find millions of rows. A file of the run's own is
written in batches while the result is read line by line, is removed with the run, and is read by the page without
touching the engine's store. It also holds a marker every 1,000 rows of the source file (the byte where that row
starts), so the rows around an error are read by seeking, never by loading the file (a file can be 6 GB).

HOW THE SOURCE FILE IS READ (2026-11-15): in its own form, as agentic/csv_dialect.py decides it from the file (file_form): its
encoding (UTF-8 with or without a byte order mark, UTF-16), its separator, and its header on its own line with the lines
above it skipped. The file is opened in binary and its lines are cut here (at \n, \r or \r\n, as the text reading of
csv_dialect cuts them), so the byte where each row starts is counted in the bytes of the file itself in every form: a
marker is a byte of the file at the start of a row, and a window is read by seeking to it in every form.
"""
import codecs
import csv
import json
import os
import re
import sqlite3
import time

from . import csv_dialect

KIND = "other_csv"                       # the kind of these errors: never mistaken for a finding of the tree
ROW_COLUMN = "row number in the file"
FILE_COLUMN = "file"
CHECKPOINT_ROWS = 1000                   # a marker (row number -> byte offset) every this many rows of the source file
HEAD = 200                               # errors kept in a step's output for the screen; all of them stay in the store
MAX_AROUND = 500                         # the most rows above, and below, that one window shows
DEFAULT_ABOVE = 15
DEFAULT_BELOW = 15
DEFAULT_AROUND_REASON = ("15 rows above and 15 below is the application's starting value: the same as the window of the page of one error of the tree "
                         "(the owner's choice of 2026-11-11). It is not a property of this file; type your own numbers to change it.")
SCAN_LIMIT_ROWS = 2000000                # with "only rows with the same value": the most rows read in one direction before the search stops and says so
CELL_SHOWN = 400                         # characters of one cell put into a prompt
PROMPT_ROWS = 400                        # window rows put into one prompt; the prompt says how many were left out
RECORD_BYTES = 16 * 1024 * 1024          # one row larger than this is refused: a quoted cell that never closes would otherwise take the whole file
CHUNK_BYTES = 64 * 1024                  # a UTF-16 file is read this many bytes at a time
# the plain form (UTF-8, comma, header on line 1): what a store written before 2026-11-15 was read with
PLAIN_FORM = {"codec": "utf-8-sig", "bom_bytes": 0, "separator": ",", "header_line": 1, "written_as": "", "as_before": True}


class Refused(ValueError):
    """A plain sentence for the admin: why something was not done."""


def store_path(sandbox_root, run_id):
    return os.path.join(sandbox_root, "run_%s" % int(run_id), "other_errors", "errors.sqlite")


def requirement_words(files=None):
    """The requirement the Coder's code must meet, in words (given to the Rule writer, shown with a refusal)."""
    many = files is not None and len(files) > 1
    return ("the result must say which rows of the file it found: a column named exactly \"%s\" holding the number of the row in the source file, "
            "counted as Python's csv reader counts the rows with the first row under the header as row 1 (lines above the header, such as a title line, "
            "are not rows and are not counted)%s. A result column that has the name of a column "
            "of the file must hold that row's own cell, unchanged" % (ROW_COLUMN, (", and a column named exactly \"%s\" holding the file's name, because the "
                                                                                "procedure reads more than one file" % FILE_COLUMN) if many else ""))


def result_problem(columns, files, rule=""):
    """Why a result cannot give errors, in plain words, or "": checked on the result's header alone (the rows are checked by ingest)."""
    files = list(files or [])
    cols = [str(c) for c in columns or []]
    name = ("'%s'" % rule) if rule else "this rule"
    if not files:
        return "The result of %s names no CSV file of the analysis, so its rows cannot be found again and no error is listed." % name
    if ROW_COLUMN not in cols:
        return ("The result of %s does not say which rows of %s it found: it has no column named \"%s\". No error is listed for it. "
                "Change the rule so that %s; then code it and run it again." % (name, " or ".join(files), ROW_COLUMN, requirement_words(files)))
    if cols.count(ROW_COLUMN) > 1:
        return "The result of %s has more than one column named \"%s\", so the row of a found line is not certain. No error is listed for it." % (name, ROW_COLUMN)
    if len(files) > 1 and FILE_COLUMN not in cols:
        return ("The result of %s reads %d files (%s) and does not say in which of them each row is: it has no column named \"%s\". No error is listed for it."
                % (name, len(files), ", ".join(files), FILE_COLUMN))
    return ""


# ---------------------------------------------------------------------------------------------- reading a file row by row, with byte offsets
_PIECES = re.compile(rb"[^\r\n]*(?:\r\n|\r|\n)|[^\r\n]+")
_TEXT_END = re.compile(r"\r\n|\r|\n")


def file_form(path, rule=""):
    """How a source file is written, as csv_dialect decides it from the file: {"codec", "bom_bytes", "separator", "header_line",
    "written_as" (one plain sentence), "as_before"}. A file that is not a table is refused in a plain sentence, never read."""
    name = os.path.basename(path)
    who = ("The rule '%s'" % rule) if rule else "This rule"
    try:
        d = csv_dialect.detect(path)
    except OSError as e:
        raise Refused("%s reads the file %s, which cannot be opened (%s). No error is listed for this rule." % (who, name, e.strerror or e))
    if d["refused"]:
        raise Refused("%s reads a file that is not a table: %s No error is listed for this rule." % (who, d["refused"]))
    return {"codec": d["codec"], "bom_bytes": d["bom_bytes"], "separator": d["separator"], "header_line": d["header_line"],
            "written_as": csv_dialect.record(d)["text"], "as_before": bool(d["as_before"])}


class _Lines:
    """The lines of a file opened in binary, as text for the csv reader, counting the bytes handed out: the csv reader takes exactly the
    lines of one row at a time, so the count before a row is the byte of the file where that row starts, in every encoding. A line ends
    at \n, \r or \r\n, as the text reading of csv_dialect ends it. `lines` counts the lines handed out (the line of the file of a row).
    UTF-8: the file's own lines. UTF-16: the file is read CHUNK_BYTES at a time, decoded, and cut into lines here; the bytes of a line
    are counted from its text (two per code unit), so a byte 0A that is half of another character never ends a line."""

    def __init__(self, fh, codec="utf-8-sig"):
        self.fh, self.pos, self.taken, self.lines = fh, fh.tell(), 0, 0
        self.codec, self.wide, self.more = codec, codec.startswith("utf-16"), []
        if self.wide:
            self.dec, self.buf, self.at, self.end = codecs.getincrementaldecoder(codec)(errors="replace"), "", 0, False

    def __iter__(self):
        return self

    def _wide_line(self):
        while True:
            m = _TEXT_END.search(self.buf, self.at)
            if m is not None and not (m.end() == len(self.buf) and not self.end and m.group() == "\r"):     # a \r at the end of what was read may be half of \r\n
                line, self.at = self.buf[self.at:m.end()], m.end()
                return line
            if self.end:
                line, self.at = self.buf[self.at:], len(self.buf)
                return line
            if 2 * (len(self.buf) - self.at) > RECORD_BYTES:
                self._too_long()
            raw = self.fh.read(CHUNK_BYTES)
            self.end = not raw
            self.buf, self.at = self.buf[self.at:] + self.dec.decode(raw, final=self.end), 0

    def _too_long(self):
        raise Refused("one row of the file is larger than %d MB (a quoted cell that never closes?): the file cannot be read row by row" % (RECORD_BYTES // 1024 ** 2))

    def __next__(self):
        if self.wide:
            text = self._wide_line()
            if not text:
                raise StopIteration
            size = len(text.encode(self.codec, "surrogatepass"))
        else:
            if self.more:
                line = self.more.pop()
            else:
                line = self.fh.readline(RECORD_BYTES + 1)
                if not line:
                    raise StopIteration
                i = line.find(b"\r")
                if i != -1 and line[i:] not in (b"\r\n", b"\r"):        # a line end written as \r alone: the pieces are handed out one by one
                    self.more = _PIECES.findall(line)[::-1]
                    line = self.more.pop()
            size = len(line)
            text = line.decode("utf-8", "replace")
        self.pos += size
        self.taken += size
        self.lines += 1
        if self.taken > RECORD_BYTES:
            self._too_long()
        return text


def _head(path, form):
    """(the header's cells, the byte where row 1 starts, the line of the file on which row 1 starts) of a file written in `form`."""
    name = os.path.basename(path)
    with open(path, "rb") as fh:
        fh.seek(form["bom_bytes"])
        lines = _Lines(fh, form["codec"])
        for _ in range(form["header_line"] - 1):            # the lines above the header: not rows of the table
            if next(lines, None) is None:
                break
            lines.taken = 0
        try:
            head = next(csv.reader(lines, delimiter=form["separator"]), None)
        except csv.Error as e:
            raise Refused("the line of column names of %s (line %d) cannot be read as a row of cells: %s" % (name, form["header_line"], e))
        if head is None:
            raise Refused("%s is empty: it has no line of column names" % name)
        return head, lines.pos, lines.lines + 1


def read_header(path, form=None):
    """(the header's cells, the byte where row 1 starts), the file read in its own form."""
    head, pos, _line = _head(path, form or file_form(path))
    return head, pos


def _rows(path, offset, row, form, line=None):
    """Yields (row number, byte offset of the row, its cells, the line of the file it starts on) from the byte `offset`, where row
    number `row` starts on line `line` (None: not known, then None is given). Streamed: one row in memory."""
    with open(path, "rb") as fh:
        fh.seek(offset)
        lines = _Lines(fh, form["codec"])
        rd = csv.reader(lines, delimiter=form["separator"])
        while True:
            start, at, lines.taken = lines.pos, lines.lines, 0
            try:
                cells = next(rd)
            except StopIteration:
                return
            except csv.Error as e:
                raise Refused("row %s of %s cannot be read as a row of cells: %s" % ("{:,}".format(row), os.path.basename(path), e))
            yield row, start, cells, (line + at if line is not None else None)
            row += 1


def rows_from(path, offset, row, form=None):
    """Yields (row number, byte offset of the row, its cells) from the byte `offset`, where row number `row` starts. Streamed."""
    for k, start, cells, _line in _rows(path, offset, row, form or file_form(path)):
        yield k, start, cells


# ---------------------------------------------------------------------------------------------- the store
SCHEMA = """
CREATE TABLE IF NOT EXISTS error (id INTEGER PRIMARY KEY AUTOINCREMENT, item TEXT NOT NULL, rule TEXT NOT NULL, file TEXT NOT NULL, row INTEGER NOT NULL,
                                  cells TEXT NOT NULL, result_line INTEGER, line INTEGER, UNIQUE (item, file, row));
CREATE TABLE IF NOT EXISTS source (file TEXT PRIMARY KEY, path TEXT NOT NULL, size INTEGER, mtime REAL, rows INTEGER, header TEXT NOT NULL, read_at REAL, form TEXT);
CREATE TABLE IF NOT EXISTS checkpoint (file TEXT NOT NULL, row INTEGER NOT NULL, offset INTEGER NOT NULL, line INTEGER, PRIMARY KEY (file, row));
CREATE TABLE IF NOT EXISTS listing (item TEXT PRIMARY KEY, rule TEXT, total INTEGER, repeated INTEGER, files TEXT, at REAL, refused TEXT);
CREATE TABLE IF NOT EXISTS incoming (file TEXT, row INTEGER, line INTEGER, same TEXT);
CREATE TABLE IF NOT EXISTS isolation (id INTEGER PRIMARY KEY AUTOINCREMENT, item TEXT NOT NULL, file TEXT NOT NULL, row INTEGER NOT NULL, asked_by TEXT, asked_at REAL,
                                      n INTEGER, m INTEGER, same_column TEXT, producer TEXT, standin INTEGER, answer TEXT, problems TEXT, refused TEXT);
CREATE TABLE IF NOT EXISTS group_column (file TEXT NOT NULL, col TEXT NOT NULL, named_by TEXT, named_at REAL, why TEXT, PRIMARY KEY (file, col));
"""
# columns added on 2026-11-15 (the line of the file of a row, the form the file is written in): a store made before gets them here
ADDED = (("error", "line", "INTEGER"), ("checkpoint", "line", "INTEGER"), ("source", "form", "TEXT"))


def _has(x, key, default=None):
    """A column of a store row that a store written before 2026-11-15 may not have."""
    return x[key] if key in x.keys() else default


def connect(db_path, create=True):
    if not create and not os.path.exists(db_path):
        return None
    if create:
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
    con = sqlite3.connect(db_path, timeout=30)
    con.row_factory = sqlite3.Row
    if create:
        try:
            con.execute("PRAGMA journal_mode=WAL")       # the page reads while a rule's rows are being listed: a reader never waits for the writer
        except sqlite3.Error:
            pass                                         # a folder that cannot hold a write-ahead log: the default journal is used
        con.executescript(SCHEMA)
        for table, col, kind in ADDED:
            if col not in [x[1] for x in con.execute("PRAGMA table_info(%s)" % table)]:
                con.execute("ALTER TABLE %s ADD COLUMN %s %s" % (table, col, kind))
    return con


def _whole_row(text):
    """A row number written in a result cell: a whole number of 1 or more ("17", "17.0" and " 17 " are 17), else None."""
    t = str(text if text is not None else "").strip()
    if re.fullmatch(r"\d{1,18}(\.0+)?", t):
        v = int(t.split(".")[0])
        return v if v >= 1 else None
    return None


def ingest(db_path, item, rule, result_csv, sources, progress=None):
    """The rows a rule found become errors. item: 'section/other/id'; rule: its name; result_csv: the rule's streamed result; sources:
    {file name: full path} of the files its procedure names. One pass over the result (its row numbers go to a table on disk), then one
    pass over each source file, read in its own form (file_form: encoding, separator, header line; the found rows' cells are taken, a
    marker is kept every 1,000 rows). Nothing is held in memory but one row. -> {"total", "repeated", "files": {name: rows in the file}}. Raises Refused in plain words; then nothing of this item is listed."""
    files = list(sources)
    with open(result_csv, newline="", encoding="utf-8") as fh:
        cols = next(csv.reader(fh), [])
    prob = result_problem(cols, files, rule)
    con = connect(db_path)
    try:
        if prob:
            raise Refused(prob)
        ir = cols.index(ROW_COLUMN)
        jf = cols.index(FILE_COLUMN) if len(files) > 1 else None
        forms = {f: file_form(p, rule) for f, p in sources.items()}
        heads = {f: _head(p, forms[f]) for f, p in sources.items()}
        # the result columns that carry a cell of the file under the file's own column name: compared with the file, cell by cell
        common = {f: [(j, h[0].index(c)) for j, c in enumerate(cols) if c in h[0] and c not in (ROW_COLUMN, FILE_COLUMN) and cols.count(c) == 1]
                  for f, h in heads.items()}
        con.execute("BEGIN IMMEDIATE")
        con.execute("DELETE FROM incoming")
        con.execute("DELETE FROM error WHERE item=?", (item,))
        con.execute("DELETE FROM listing WHERE item=?", (item,))

        def lines():
            with open(result_csv, newline="", encoding="utf-8") as fh2:
                rd = csv.reader(fh2)
                next(rd, None)
                for k, row in enumerate(rd, 2):
                    if not row:
                        continue
                    v = _whole_row(row[ir]) if ir < len(row) else None
                    if v is None:
                        raise Refused("Line %s of the result of '%s' does not name a row of the file: its \"%s\" cell holds %r, which is not a whole number of 1 "
                                      "or more. No error is listed for this rule." % ("{:,}".format(k), rule, ROW_COLUMN, row[ir] if ir < len(row) else ""))
                    f = files[0]
                    if jf is not None:
                        f = row[jf].strip() if jf < len(row) else ""
                        if f not in sources:
                            raise Refused("Line %s of the result of '%s' names the file %r, which is not one of the files the rule reads (%s). No error is "
                                          "listed for this rule." % ("{:,}".format(k), rule, f, ", ".join(files)))
                    yield f, v, k, json.dumps([row[j] if j < len(row) else "" for j, _i in common[f]])
        con.executemany("INSERT INTO incoming (file, row, line, same) VALUES (?,?,?,?)", lines())
        con.execute("CREATE INDEX IF NOT EXISTS incoming_by_row ON incoming (file, row, line)")
        total = repeated = 0
        rows_of = {}
        for f, path in sources.items():
            head, start, line1 = heads[f]
            st = os.stat(path)
            con.execute("DELETE FROM checkpoint WHERE file=?", (f,))
            want = con.execute("SELECT row, line, same FROM incoming WHERE file=? ORDER BY row, line", (f,))
            nxt = want.fetchone()
            n, t0, batch, marks = 0, time.time(), [], []
            for n, offset, cells, ln in _rows(path, start, 1, forms[f], line1):
                if n % CHECKPOINT_ROWS == 1:
                    marks.append((f, n, offset, ln))
                    if len(marks) >= 500:
                        con.executemany("INSERT OR REPLACE INTO checkpoint (file, row, offset, line) VALUES (?,?,?,?)", marks)
                        marks = []
                    if progress and n % (50 * CHECKPOINT_ROWS) == 1 and st.st_size:
                        progress(100.0 * offset / st.st_size, t0, "%s rows of %s read, %s errors listed" % ("{:,}".format(n - 1), f, "{:,}".format(total)))
                first = True
                while nxt is not None and nxt[0] == n:
                    if first:
                        got = json.loads(nxt[2])
                        for (j, i), v in zip(common[f], got):
                            cell = cells[i] if i < len(cells) else ""
                            if str(v).strip() != cell.strip():
                                raise Refused("Line %s of the result of '%s' says it is row %s of %s, but its \"%s\" cell holds %r and that row of the file holds %r. "
                                              "Either the row number is not the file's (the first row under the header is row 1), or the result changed the cell: "
                                              "a changed value needs a column name of its own. No error is listed for this rule."
                                              % ("{:,}".format(nxt[1]), rule, "{:,}".format(n), f, cols[j], v, cell))
                        batch.append((item, rule, f, n, json.dumps(cells, ensure_ascii=False), nxt[1], ln))
                        total += 1
                        first = False
                    else:
                        repeated += 1
                    nxt = want.fetchone()
                if len(batch) >= 2000:
                    con.executemany("INSERT INTO error (item, rule, file, row, cells, result_line, line) VALUES (?,?,?,?,?,?,?)", batch)
                    batch = []
            if nxt is not None:
                raise Refused("Line %s of the result of '%s' names row %s of %s, and that file has %s rows under its header. No error is listed for this rule."
                              % ("{:,}".format(nxt[1]), rule, "{:,}".format(nxt[0]), f, "{:,}".format(n)))
            if batch:
                con.executemany("INSERT INTO error (item, rule, file, row, cells, result_line, line) VALUES (?,?,?,?,?,?,?)", batch)
            if marks:
                con.executemany("INSERT OR REPLACE INTO checkpoint (file, row, offset, line) VALUES (?,?,?,?)", marks)
            con.execute("INSERT OR REPLACE INTO source (file, path, size, mtime, rows, header, read_at, form) VALUES (?,?,?,?,?,?,?,?)",
                        (f, path, st.st_size, st.st_mtime, n, json.dumps(head, ensure_ascii=False), time.time(), json.dumps(forms[f], ensure_ascii=False)))
            rows_of[f] = n
        con.execute("DELETE FROM incoming")
        con.execute("INSERT OR REPLACE INTO listing (item, rule, total, repeated, files, at, refused) VALUES (?,?,?,?,?,?,NULL)",
                    (item, rule, total, repeated, json.dumps(rows_of), time.time()))
        con.commit()
        return {"total": total, "repeated": repeated, "files": rows_of}
    except Refused as e:
        con.rollback()
        con.execute("DELETE FROM error WHERE item=?", (item,))
        con.execute("DELETE FROM incoming")
        con.execute("INSERT OR REPLACE INTO listing (item, rule, total, repeated, files, at, refused) VALUES (?,?,0,0,?,?,?)", (item, rule, json.dumps({}), time.time(), str(e)))
        con.commit()
        raise
    except BaseException:
        con.rollback()
        raise
    finally:
        con.close()


def line_words(line):
    """The real line of the file of a row, in words, or "" when the store does not hold it (a store written before 2026-11-15)."""
    return ("line %s of the file" % "{:,}".format(line)) if line else ""


def _error_dict(x):
    line = _has(x, "line")
    return {"error": x["id"], "kind": KIND, "item": x["item"], "rule": x["rule"], "file": x["file"], "row": x["row"], "line": line, "cells": json.loads(x["cells"]),
            "where": "row %s of %s%s" % ("{:,}".format(x["row"]), x["file"], (" (%s)" % line_words(line)) if line else "")}


def list_errors(db_path, item=None, offset=0, limit=HEAD):
    """The errors of other files, in the order of the file (file name, then row), a page at a time."""
    con = connect(db_path, create=False)
    if con is None:
        return []
    try:
        q, a = "SELECT * FROM error", []
        if item:
            q, a = q + " WHERE item=?", [item]
        return [_error_dict(x) for x in con.execute(q + " ORDER BY item, file, row LIMIT ? OFFSET ?", a + [int(limit), int(offset)])]
    finally:
        con.close()


def listings(db_path):
    """One line per rule that listed (or was refused): {item, rule, total, repeated, files, at, refused, isolated}."""
    con = connect(db_path, create=False)
    if con is None:
        return []
    try:
        out = []
        for x in con.execute("SELECT * FROM listing ORDER BY item"):
            iso = con.execute("SELECT COUNT(*) FROM (SELECT DISTINCT file, row FROM isolation WHERE item=?)", (x["item"],)).fetchone()[0]
            out.append({"item": x["item"], "rule": x["rule"], "total": x["total"], "repeated": x["repeated"], "files": json.loads(x["files"] or "{}"),
                        "at": x["at"], "refused": x["refused"], "isolated": iso, "kind": KIND})
        return out
    finally:
        con.close()


def get_error(db_path, error_id):
    con = connect(db_path, create=False)
    if con is None:
        return None
    try:
        x = con.execute("SELECT * FROM error WHERE id=?", (int(error_id),)).fetchone()
        if x is None:
            return None
        s = con.execute("SELECT * FROM source WHERE file=?", (x["file"],)).fetchone()
        form = dict(PLAIN_FORM, **json.loads(_has(s, "form") or "{}"))
        return dict(_error_dict(x), header=json.loads(s["header"]), file_rows=s["rows"], path=s["path"], file_size=s["size"], file_mtime=s["mtime"],
                    form=form, header_line=form["header_line"], written_as=form["written_as"])
    finally:
        con.close()


# ---------------------------------------------------------------------------------------------- the rows around an error
def around(value, name, default):
    """n or m as the admin typed it: nothing typed -> (the default, 'default'); a whole number 0..MAX_AROUND -> (it, 'admin'); else Refused."""
    if value is None or (isinstance(value, str) and not value.strip()):
        return default, "default"
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise Refused("the number of rows %s must be a whole number from 0 to %d" % (name, MAX_AROUND))
    t = str(value).strip()
    if not re.fullmatch(r"\d{1,6}", t):
        raise Refused("the number of rows %s must be a whole number from 0 to %d, and %r is not" % (name, MAX_AROUND, value if isinstance(value, int) else t[:40]))
    v = int(t)
    if v > MAX_AROUND:
        raise Refused("the number of rows %s can be at most %d in one window, and %s is more" % (name, MAX_AROUND, "{:,}".format(v)))
    return v, "admin"


def _mark(con, f, row):
    """The marker at or before a row: (row number, the byte of the file where it starts, the line of the file it starts on or None)."""
    x = con.execute("SELECT * FROM checkpoint WHERE file=? AND row<=? ORDER BY row DESC LIMIT 1", (f, max(1, int(row)))).fetchone()
    if x is None:
        raise Refused("the markers of %s are missing: run the rule again" % f)
    return x["row"], x["offset"], _has(x, "line")


def window(db_path, error_id, n=None, m=None, same=None):
    """The rows around an error in its own file: n above and m below in the file's order; with same=<column>, only rows whose cell in that
    column equals the error row's. Read by seeking to the nearest marker, in the file's own form (the marker is a byte of the file at the
    start of a row, whatever the encoding): never the whole file. -> {rows: [{row, line, cells, position}], ...}."""
    err = get_error(db_path, error_id)
    if err is None:
        raise Refused("there is no such error in this analysis")
    n, n_by = around(n, "above", DEFAULT_ABOVE)
    m, m_by = around(m, "below", DEFAULT_BELOW)
    head, row, f, path, form = err["header"], err["row"], err["file"], err["path"], err["form"]
    try:
        st = os.stat(path)
    except OSError:
        raise Refused("the file %s is no longer where it was when the rule ran (%s): put it back, or run the rule again" % (f, path))
    if st.st_size != err["file_size"] or abs(st.st_mtime - (err["file_mtime"] or 0)) > 1e-6:
        raise Refused("the file %s changed after the rule ran, so its row numbers may no longer be the same: run the rule again" % f)
    col = None
    if same not in (None, ""):
        if not isinstance(same, str) or same not in head:
            raise Refused("%r is not a column of %s" % (str(same)[:80], f))
        col = head.index(same)
    value = (err["cells"][col] if col is not None and col < len(err["cells"]) else "")
    con = connect(db_path, create=False)
    t0, read = time.time(), 0
    note = ""
    try:
        if col is None:
            a, b = max(1, row - n), min(err["file_rows"], row + m)
            r0, off, l0 = _mark(con, f, a)
            rows = []
            for k, _o, cells, ln in _rows(path, off, r0, form, l0):
                read += 1
                if k >= a:
                    rows.append((k, cells, ln))
                if k >= b:
                    break
        else:
            keep = lambda cells: (cells[col] if col < len(cells) else "") == value      # noqa: E731
            above, hi = [], row - 1                              # walk back marker by marker until n rows with the same value are found
            while len(above) < n and hi >= 1:
                r0, off, l0 = _mark(con, f, hi)
                chunk = []
                for k, _o, cells, ln in _rows(path, off, r0, form, l0):
                    if k > hi:
                        break
                    read += 1
                    if keep(cells):
                        chunk.append((k, cells, ln))
                above = chunk[-(n - len(above)):] + above if n - len(above) > 0 else above
                hi = r0 - 1
                if read > SCAN_LIMIT_ROWS and len(above) < n:
                    note = "The search above stopped after %s rows were read; %d rows with the same value were found." % ("{:,}".format(read), len(above))
                    break
            above = above[-n:] if n else []
            r0, off, l0 = _mark(con, f, row)
            below, mine, seen = [], None, 0
            for k, _o, cells, ln in _rows(path, off, r0, form, l0):
                if k < row:
                    continue
                read += 1
                if k == row:
                    mine = (k, cells, ln)
                    if m == 0:
                        break
                    continue
                seen += 1
                if keep(cells):
                    below.append((k, cells, ln))
                    if len(below) >= m:
                        break
                if seen > SCAN_LIMIT_ROWS:
                    note += " The search below stopped after %s rows were read; %d rows with the same value were found." % ("{:,}".format(seen), len(below))
                    break
            rows = above + ([mine] if mine else []) + below
        nums = [k for k, _c, _l in rows]
        also = set()
        for i in range(0, len(nums), 400):
            part = nums[i:i + 400]
            also |= {x[0] for x in con.execute("SELECT row FROM error WHERE item=? AND file=? AND row IN (%s)" % ",".join("?" * len(part)), [err["item"], f] + part)}
    finally:
        con.close()
    out = [{"row": k, "line": ln, "cells": cells, "position": "above" if k < row else "the error" if k == row else "below", "also_found": k in also and k != row}
           for k, cells, ln in rows]
    hl = err["header_line"]
    return {"kind": KIND, "error": err["error"], "file": f, "row": row, "line": err["line"], "header_line": hl, "written_as": err["written_as"],
            "header": head, "rows": out, "file_rows": err["file_rows"],
            "n": n, "m": m, "n_set_by": n_by, "m_set_by": m_by, "default_reason": DEFAULT_AROUND_REASON if "default" in (n_by, m_by) else "",
            "same": {"column": same, "value": value} if col is not None else None,
            "above": sum(1 for x in out if x["position"] == "above"), "below": sum(1 for x in out if x["position"] == "below"),
            "rows_read": read, "seconds": round(time.time() - t0, 4), "note": note.strip(),
            "order": "the file's own order (row 1 is the first row under the line of column names%s)" % (
                "" if hl == 1 else "; the line of column names is line %d of the file, the %s above it %s not counted, so row 1 is on line %d" % (
                    hl, "line" if hl == 2 else "%d lines" % (hl - 1), "is" if hl == 2 else "are", hl + 1))}


# ---------------------------------------------------------------------------------------------- Family 1's dictionary of the file
NO_DICTIONARY = "Family 1's dictionary of this file is not approved, so no meaning is known for this column."
NO_MEANING = "The approved dictionary gives no meaning for this column."
NOT_SOURCED = "meaning not sourced"
SOURCE_KIND_WORDS = {"data": "the file's own data", "document": "a document", "web": "a web page", "admin": "the admin", "project": "the project's notes",
                     "rea": "the reference assistant", "ticket": "a ticket", "model": "the model's own knowledge"}


def dictionary_of(folder, file_name):
    """Family 1's approved dictionary of a file of the analysis's folder, or None."""
    from . import family1
    try:
        f = next((x for x in family1.inventory(folder) if x["name"] == file_name), None) if folder else None
        return family1.approved_dictionary(f["format_key"], f["name"]) if f else None
    except Exception:       # noqa: BLE001 - no dictionary is not a fault: the page says that no meaning is known
        return None


def column_meanings(dictionary, header):
    """For every column of the file's header: the meaning and where it comes from, as the approved dictionary has them. No meaning is ever
    written here: a column the dictionary does not explain is said to be unexplained."""
    known = {}
    for c in (dictionary or {}).get("columns") or []:
        if isinstance(c, dict) and c.get("column") is not None and str(c["column"]) not in known:
            known[str(c["column"])] = c
    out = []
    for name in header:
        c = known.get(str(name))
        meaning = " ".join(str((c or {}).get("meaning") or "").split())
        src = (c or {}).get("source") if isinstance((c or {}).get("source"), dict) else {}
        kind = str(src.get("kind") or "")
        sourced = bool(meaning) and kind in SOURCE_KIND_WORDS and kind != "model"
        if not dictionary:
            words = NO_DICTIONARY
        elif not meaning:
            words = NO_MEANING
        else:
            status = " ".join(str(c.get("status") or "").split())
            ref = " ".join(str(src.get("ref") or "").split())
            quote = " ".join(str(src.get("quote") or "").split())
            if sourced:
                words = "Source: %s%s%s%s" % (SOURCE_KIND_WORDS[kind], (" (%s)" % ref) if ref and kind != "data" else "", (", where it says \"%s\"" % quote[:200]) if quote else "",
                                              ("; the dictionary marks it: %s" % status) if status else "")
            else:
                words = "%s: %s" % (NOT_SOURCED, status or "the dictionary names no source for it")
        out.append({"column": str(name), "meaning": meaning, "sourced": sourced, "source_words": words,
                    "values": {str(k.get("value")): " ".join(str(k.get("meaning") or "").split()) for k in (c or {}).get("keywords") or []
                               if isinstance(k, dict) and k.get("value") not in (None, "") and str(k.get("meaning") or "").strip()}})
    return out


# the phrases by which a dictionary's meaning NAMES a column as an identifier or a group ("queue ID", "command identifier", "identifier of the
# channel"). Only the dictionary's own sentence is read (never the column's name, never its contents); the sentence is shown as the reason, and the
# admin chooses. Nothing is chosen in advance. A meaning that only mentions a queue in passing ("submitted to the device queue") names nothing: a
# first list of single words offered such columns on the disguised file of the real-model run, and was replaced by these phrases (2026-11-14).
GROUP_PHRASES = (r"\b(queue|channel|group|transaction|command|session|stream) (id|identifier|tag)\b|\btransaction number\b|"
                 r"\b(identifier|id) of the (\w+ ){0,2}(queue|channel|group|transaction|command|session|stream)\b")


def group_columns(db_path, dictionary, header, file_name):
    """The columns for which the page may offer "only rows with the same value of <column>": those the approved dictionary names as an
    identifier or a group (its own sentence is the reason), the column the dictionary says names the kind of each row, and those the admin
    named. -> [{column, named_by, why}]. Never a guess from a column's name or contents."""
    out, seen = [], set()
    kinds = [str(c) for c in ((dictionary or {}).get("kind_of_row") or {}).get("columns") or [] if isinstance(c, str)]
    for c in column_meanings(dictionary, header) if dictionary else []:
        low = c["meaning"].lower()
        found = re.search(GROUP_PHRASES, low)
        word = found.group(0) if found else None
        if c["column"] in kinds and c["column"] not in seen:
            out.append({"column": c["column"], "named_by": "the dictionary",
                        "why": "Family 1's approved dictionary says the kind of each row is named by this column." + ((" Its meaning there: \"%s\"" % c["meaning"]) if c["meaning"] else "")})
            seen.add(c["column"])
        elif word and c["column"] not in seen:
            out.append({"column": c["column"], "named_by": "the dictionary",
                        "why": "Family 1's approved dictionary uses the words \"%s\" for this column: \"%s\" (%s)" % (word, c["meaning"], c["source_words"])})
            seen.add(c["column"])
    con = connect(db_path, create=False)
    if con is not None:
        try:
            for x in con.execute("SELECT * FROM group_column WHERE file=? ORDER BY named_at", (file_name,)):
                if x["col"] in header and x["col"] not in seen:
                    out.append({"column": x["col"], "named_by": x["named_by"], "named_at": x["named_at"],
                                "why": "Named as an identifier or a group by the admin %s%s" % (x["named_by"], (": \"%s\"" % x["why"]) if x["why"] else ".")})
                    seen.add(x["col"])
        finally:
            con.close()
    return out


def name_group_column(db_path, file_name, header, column, admin, why=""):
    """The admin names a column of the file as an identifier or a group: from then on the page offers the same-value choice for it."""
    if not isinstance(column, str) or column not in header:
        raise Refused("%r is not a column of %s" % (str(column)[:80], file_name))
    con = connect(db_path)
    try:
        con.execute("INSERT OR REPLACE INTO group_column (file, col, named_by, named_at, why) VALUES (?,?,?,?,?)",
                    (file_name, column, admin, time.time(), " ".join(str(why or "").split())[:300]))
        con.commit()
    finally:
        con.close()


# ---------------------------------------------------------------------------------------------- the isolation of one error
ISOLATION_KEYS = ("what", "why", "when", "where", "who", "which", "how")
ISOLATION_LABEL = {"what": "What happened", "why": "Why", "when": "When", "where": "Where", "who": "Who caused it", "which": "Which row started it",
                   "how": "How it came about"}
CODE_KEYS = ("where",)                    # stated by the code from the file itself; the model writes the others around the stated facts
ISOLATION_SCHEMA = {"type": "object", "properties": dict({k: {"type": "string"} for k in ISOLATION_KEYS if k not in CODE_KEYS},
                                                         cited_rows={"type": "array", "items": {"type": "integer"}}),
                    "required": [k for k in ISOLATION_KEYS if k not in CODE_KEYS] + ["cited_rows"]}
SYSTEM = (
    "You help a test engineer isolate ONE defect that a rule written by the admin found in a file exported by a measuring tool. The rule decided "
    "that the row is an error; you never judge that. Nothing is known about the tool except the file itself and the data dictionary below: do not "
    "assume what kind of device or protocol it is unless the dictionary says so. You explain in plain words, say what the rows show, and propose. "
    "Use only the rows you are given: every number you mention must come from them, with its unit as the dictionary gives it; cite rows by their "
    "row number. Say 'not known from these rows' rather than guess. Short sentences, no abbreviations without their meaning.")


def _cell(v):
    v = " ".join(str(v).split())
    return v if len(v) <= CELL_SHOWN else v[:CELL_SHOWN] + " ... (%d characters)" % len(v)


def row_line(header, r):
    cells = r["cells"]
    return "row %d%s: %s" % (r["row"], " (THE ERROR)" if r["position"] == "the error" else "",
                             "; ".join("%s = %s" % (h, _cell(cells[i])) for i, h in enumerate(header) if i < len(cells) and str(cells[i]).strip() != ""))


def facts(err, win, rule_words):
    """What the code states about the error, from the file alone."""
    line, hl = err.get("line"), err.get("header_line") or 1
    return {"where": "Row %s of %s rows of the file %s (the first row under the line of column names is row 1)%s." % (
                "{:,}".format(err["row"]), "{:,}".format(err["file_rows"]), err["file"],
                ("; it is %s, whose line of column names is line %d" % (line_words(line), hl)) if line else ""),
            "found_by": "The rule '%s' found this row%s" % (err["rule"], (": %s" % rule_words.rstrip(".")) if rule_words else "") + ".",
            "window": "The window holds %d rows above and %d below in the file's order%s." % (
                win["above"], win["below"], (", only rows whose %s is %r" % (win["same"]["column"], win["same"]["value"])) if win.get("same") else "")}


def isolation_prompt(err, win, meanings, rule_words):
    fx = facts(err, win, rule_words)
    rows = win["rows"]
    left = 0
    if len(rows) > PROMPT_ROWS:                     # the rows nearest the error are kept
        i = next(k for k, r in enumerate(rows) if r["position"] == "the error")
        a = max(0, i - PROMPT_ROWS // 2)
        left, rows = len(rows) - PROMPT_ROWS, rows[a:a + PROMPT_ROWS]
    lines = [SYSTEM, "", "THE DATA DICTIONARY OF %s (approved in the application; a column marked 'meaning not sourced' has a meaning nobody could check):" % err["file"]]
    lines += ["  %s: %s [%s]" % (c["column"], c["meaning"] or "no meaning known", c["source_words"]) for c in meanings]
    lines += ["", "THE WINDOW (%d rows of the file in its own order%s):" % (len(rows), ("; %d rows farther from the error were left out" % left) if left else "")]
    lines += ["  " + row_line(win["header"], r) for r in rows]
    lines += ["", "FACTS STATED BY THE CODE (do not change them): " + fx["found_by"], "  " + fx["where"], "  " + fx["window"],
              "ISOLATE THE DEFECT behind this row, one plain sentence each, every number with its unit and from the rows above:",
              "  what: what happened;  why: the reason, as far as the rows show it;  when: when it happened, from a column the dictionary says is a time, or "
              "'not known from these rows';",
              "  who: which side caused it, or 'not known from these rows';  which: the row number where it started;  how: how it came about, step by step in one sentence.",
              "  cited_rows: the row numbers your answer rests on. Only rows of the window may be cited."]
    return "\n".join(lines)


def standin_isolation(err, win, rule_words):
    """The isolation without a model: only what the code can state; every other field says that no model answered."""
    none = "Not known: no model answered, and the code does not judge the rows of a file of an unknown tool."
    return {"what": "The rule '%s' found row %s of %s%s." % (err["rule"], "{:,}".format(err["row"]), err["file"], (" (%s)" % rule_words.rstrip(".")) if rule_words else ""),
            "why": none, "when": "Not known: the code does not decide which column of this file is a time. It is row %s of %s in the file's order." % (
                "{:,}".format(err["row"]), "{:,}".format(err["file_rows"])),
            "who": none, "which": "Row %s of %s, the row the rule found." % ("{:,}".format(err["row"]), err["file"]), "how": none, "cited_rows": [err["row"]]}


def check_isolation(ans, win):
    """(the clean answer, problems, refusal). Every row the model cites must be a row of the window: an answer citing a row outside it is
    refused whole (refusal is the plain sentence). A field left empty is a problem that is shown with the answer."""
    inside = {r["row"] for r in win["rows"]}
    cited, bad = [], []
    raw = ans.get("cited_rows")
    if not isinstance(raw, list):
        return None, [], "The model's answer did not list the rows it rests on, so it cannot be checked against the window. It was not kept."
    for c in raw:
        v = c.get("row") if isinstance(c, dict) else c
        if isinstance(v, bool) or not isinstance(v, int):
            bad.append(str(v)[:30])
        elif v not in inside:
            bad.append("row %s" % "{:,}".format(v))
        elif v not in cited:
            cited.append(v)
    if bad:
        return None, [], ("The model's answer rests on %s, which %s not in the window it was given (rows %s to %s). An answer that cites a row outside the "
                          "window is refused: it was not kept." % (", ".join(bad[:8]), "is" if len(bad) == 1 else "are",
                                                                  "{:,}".format(min(inside)) if inside else "?", "{:,}".format(max(inside)) if inside else "?"))
    out = {k: " ".join(str(ans.get(k) or "").split()) for k in ISOLATION_KEYS if k not in CODE_KEYS}
    problems = ["'%s' was left empty" % ISOLATION_LABEL[k] for k, v in out.items() if not v]
    if not cited:
        problems.append("no row was cited: the answer rests on no row of the window")
    out["cited_rows"] = cited
    return out, problems, ""


def isolate(db_path, error_id, meanings, rule_words, admin, n=None, m=None, same=None, llm=None, call_model=None):
    """Isolate the defect behind one error: the window and the dictionary go to the model; what the code can state is stated by the code;
    every cited row is checked to be in the window. The stand-in answers when no model does, clearly marked. Kept per error with who
    asked and when. call_model(llm, prompt, schema, must_have) -> (answer or None, producer text)."""
    err = get_error(db_path, error_id)
    if err is None:
        raise Refused("there is no such error in this analysis")
    win = window(db_path, error_id, n, m, same)
    fx = facts(err, win, rule_words)
    prompt = isolation_prompt(err, win, meanings, rule_words)
    ans, producer = (call_model(llm, prompt, ISOLATION_SCHEMA, "what") if call_model else (None, "stand-in"))
    refused, problems, clean = "", [], None
    if ans is not None:
        clean, problems, refused = check_isolation(ans, win)
    standin = clean is None
    if standin:
        clean, problems2, _r = check_isolation(standin_isolation(err, win, rule_words), win)
        problems = problems2
        producer = ("stand-in (the model's answer was refused)" if refused else producer if str(producer).startswith("stand-in") else "stand-in")
    clean["where"] = fx["where"]
    written_by = {k: ("the code, from the file" if k in CODE_KEYS else "the stand-in (no model answered)" if standin else "the model (%s)" % producer) for k in ISOLATION_KEYS}
    rec = {"item": err["item"], "file": err["file"], "row": err["row"], "asked_by": admin, "asked_at": time.time(), "n": win["n"], "m": win["m"],
           "same_column": (win.get("same") or {}).get("column"), "producer": producer, "standin": standin, "answer": clean, "problems": problems, "refused": refused}
    con = connect(db_path)
    try:
        cur = con.execute("INSERT INTO isolation (item, file, row, asked_by, asked_at, n, m, same_column, producer, standin, answer, problems, refused) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                          (rec["item"], rec["file"], rec["row"], admin, rec["asked_at"], win["n"], win["m"], rec["same_column"], producer, int(standin),
                           json.dumps(clean, ensure_ascii=False), json.dumps(problems), refused))
        con.commit()
        rec["id"] = cur.lastrowid
    finally:
        con.close()
    return dict(rec, labels=ISOLATION_LABEL, written_by=written_by, facts=fx, window={k: win[k] for k in ("n", "m", "n_set_by", "m_set_by", "above", "below", "same", "rows_read")},
                marked="STAND-IN: no model answered. Only what the code can state from the file is filled in." if standin else "")


def isolations(db_path, error_id):
    """Every isolation kept for an error, newest first."""
    err = get_error(db_path, error_id)
    if err is None:
        return []
    con = connect(db_path, create=False)
    try:
        return [{"id": x["id"], "asked_by": x["asked_by"], "asked_at": x["asked_at"], "n": x["n"], "m": x["m"], "same_column": x["same_column"],
                 "producer": x["producer"], "standin": bool(x["standin"]), "answer": json.loads(x["answer"] or "{}"), "problems": json.loads(x["problems"] or "[]"),
                 "refused": x["refused"] or "", "labels": ISOLATION_LABEL,
                 "marked": "STAND-IN: no model answered. Only what the code can state from the file is filled in." if x["standin"] else ""}
                for x in con.execute("SELECT * FROM isolation WHERE item=? AND file=? AND row=? ORDER BY id DESC", (err["item"], err["file"], err["row"]))]
    finally:
        con.close()


# ---------------------------------------------------------------------------------------------- what the NVMe command path would need
CANNOT_DO = ("For a file of a tool the application does not know, this page stops here. Three things exist today only for NVMe commands of a Teledyne LeCroy "
             "five-file export that was joined into the tree: the cause found by fixed rules, the graph from defect to cause to solution, and the replay test. "
             "They read fixed tables of that tree (the command, the queue it was sent on, its identifier, its times and its status), and this file is not in them.")
WOULD_NEED = ("To use them for this file, the approved dictionary would have to identify, each by one column: the command (its name or its operation code), the queue "
              "it was sent on, the command's identifier, the time it was sent, the time it completed or how long it took, and its status. The table below says "
              "which of these the dictionary's own words identify today. It is a report only: nothing is changed and nothing is fed to the later stages.")
# Each need of the NVMe command path, and the phrases by which a dictionary's MEANING identifies it. Only the meaning's words are read, never the
# column's name or contents; the sentence found is given as the evidence. A column whose meaning is a length of time is never taken for a point in time.
_LATENCY = r"\blatency\b|\bservice time\b|\bresponse time\b|\bduration\b|\bdifference between\b.{0,80}\btime|\belapsed time\b|\btime taken\b|\bhow long\b"
NEEDS = [
    ("command", "the command: its name or its operation code (opcode)", [
        ("the command's name", r"\bname of the\b.{0,40}\bcommand\b|\bcommand name\b|\bopcode name\b|\bname of the operation\b|\bkind of command\b|\bcommand type\b", None),
        ("the command's operation code (opcode)", r"\bopcode\b(?! name)|\boperation code\b", None)]),
    ("queue", "the queue the command was sent on", [
        ("the queue", r"\bqueue (id|identifier|number)\b|\b(id|identifier|number) of the\b.{0,30}\bqueue\b|\bwhich queue\b", None)]),
    ("identifier", "the command's identifier", [
        ("the command's identifier", r"\bcommand (identifier|id|tag)\b|\bidentifier of the command\b", None)]),
    ("submit_time", "the time the command was sent (submitted)", [
        ("the time it was sent", r"\btime (at which|when)\b.{0,60}\b(submitted|sent|issued)\b|\bsubmi(t|ssion) time\b|\btime of submission\b|\bstart time\b", _LATENCY)]),
    ("completion", "the time the command completed, or how long it took", [
        ("the time it completed", r"\btime (at which|when)\b.{0,60}\bcomplet|\bcompletion time\b|\btime of completion\b|\bend time\b", _LATENCY),
        ("how long it took", _LATENCY, None)]),
    ("status", "the command's status", [
        ("the status", r"\bstatus\b|\bcompletion outcome\b|\boutcome of the command\b|\bresult of the command\b|\bcompletion result\b", None)]),
]


def nvme_command_mapping(dictionary):
    """Does the file hold what the NVMe command path needs, by Family 1's approved dictionary alone? For each need: which column the
    dictionary's own words identify (the sentence is the evidence), or that it is missing, or that more than one column fits and the admin
    must say which. It only reports: it changes nothing and feeds nothing."""
    cols = column_meanings(dictionary, [str(c["column"]) for c in (dictionary or {}).get("columns") or [] if isinstance(c, dict) and c.get("column") is not None])
    needs, missing, unsure = [], [], []
    for key, words, roles in NEEDS:
        found = []
        for role, pattern, never in roles:
            hits = []
            for c in cols:
                low = c["meaning"].lower()
                mt = re.search(pattern, low) if low else None
                if mt and not (never and re.search(never, low)):
                    hits.append({"column": c["column"], "evidence": c["meaning"], "words_found": mt.group(0), "sourced": c["sourced"], "source_words": c["source_words"]})
            if hits:
                found.append({"role": role, "columns": hits, "one": len(hits) == 1})
        state = "missing" if not found else "identified" if any(f["one"] for f in found) else "more than one column fits"
        if state == "missing":
            missing.append(words)
            say = "Missing: no column's meaning in the approved dictionary identifies %s." % words
        elif state == "identified":
            say = "Identified: " + "; ".join("%s is the column \"%s\", by the dictionary's words \"%s\"" % (f["role"], f["columns"][0]["column"], f["columns"][0]["evidence"])
                                             for f in found if f["one"]) + "."
        else:
            unsure.append(words)
            say = "Not decided: more than one column's meaning fits %s (%s). The code does not choose: the admin must say which." % (
                words, ", ".join("\"%s\"" % h["column"] for f in found for h in f["columns"]))
        needs.append({"need": key, "words": words, "state": state, "found": found, "sentence": say})
    ok = bool(dictionary) and not missing and not unsure
    if not dictionary:
        verdict = "No dictionary of this file is approved, so nothing can be said about what it holds."
    elif ok:
        verdict = ("By the approved dictionary's own words this file holds every column the NVMe command path needs. This is a report: the file is not fed to "
                   "that path, which today reads only the tree of a Teledyne LeCroy five-file export.")
    else:
        verdict = "By the approved dictionary this file does not hold everything the NVMe command path needs: %s." % "; ".join(
            (["missing: " + ", ".join(missing)] if missing else []) + (["not decided: " + ", ".join(unsure)] if unsure else []))
    return {"holds_what_is_needed": ok, "needs": needs, "missing": missing, "not_decided": unsure, "verdict": verdict,
            "basis": "Family 1's approved dictionary of the file: only the meanings' own words are read, never a column's name or its contents.",
            "changes_nothing": True}
