"""The flow: ONE run from the input folder to the test case. Family 1, then Family 2, then Family 3, in that order.

Steps of a run (kind "flow"):

  Family 1 · Data experts
    director                    the CSVs of the folder and what each one is
    f1_last                     REVIEW when dictionaries were approved before for these same files (same headers):
                                "used last time; proceed?" - approve reuses them and skips their Explorer, Grounder and Manager
    explore:/ground:/manager:<csv>   one sub-family per CSV; the Manager's dictionary is a REVIEW (see family1)
    f1_gate                     REVIEW (see admin_ask): the admin asks whether a kind of data is present (the Admin Agent
                                puts the question to every file's Manager); "read the new files" gives the CSVs added to
                                the folder their sub-family, placed before this step, and asks again; approve = go to
                                stage 2. The flow does not reach Family 2 until the admin approves here
  Family 2 · Hierarchy
    last_strategy, collect, coder, build_ask, build, slice_test, breaker, independent   (see family2; REA is not a step
                                since 14 November 2026: the REA agent is on the start page, agentic/rea_agent.py)
  Family 3 · Rules
    f3_plan                     REVIEW: the items to use on this data, Section 1 (analytics) and Section 2 (errors).
                                Approved rules proceed as they are; drafts, new items and items to edit go to the
                                Rule writer first. Approving it adds the steps below, for each chosen item
                                (f3:<section>/<level>/<id>[#round]:<step>):
      write                     the Rule writer drafts the rule from the admin's words - REVIEW (approve = new version)
      code, run, test, export   the code generated from the approved rule, run on the tree, checked, exported
      result                    REVIEW. Change = say what to change in the rule: a new round (write ... result) is added
      for a Section 2 item, stage 1 and stage 2 on one defect the rule found (the admin picks it in the result review):
      isolate                   stage 1, the isolation tab's own evidence loop: the reason, the rows cited, the shortest
                                command sequence that leads to the defect - REVIEW with the four signals:
                                correct (+1) / correct with your edits (+1) / wrong (-1, runs again with your comment as
                                a hint) / wrong with your edits (-1 for the proposal, your edited sequence is kept)
      outcomes                  stage 2: what a correct drive must answer from the defect onward - REVIEW (approve = verified)
      testcase                  the test file from the verified outcomes; compiled and run once with pytest (on a machine
                                without the drive it must skip cleanly)
      summary                   the summary (who, what, when, where, why, how; at most 100 words), stored with the defect's signature
  report                        the Admin Agent's report of the whole flow (HTML and JSON), with links

Stage 1 and stage 2 call the same endpoints as the isolation tab (/api/isolate/...), through the application itself,
so the flow and the tab can never disagree.
"""
import hashlib
import html
import json
import os
import py_compile
import subprocess
import sys
import time
from collections import Counter

from . import admin_ask, core, family1, family2, family3, family4, other_errors, source_tools
from nvme_hier.defect_graph import SIDES  # noqa: E402  (the sides a cause can be on)

KIND = "flow"
FAMILY_LABEL = {"1": "Family 1 · Data experts", "2": "Family 2 · Hierarchy", "3": "Family 3 · Rules", "4": "Family 4 · Coding research", "R": "Report"}
LOWER = ["nvme_transaction", "split", "link", "packets"]
SIGNAL_WORDS = {"correct": "Correct (+1)", "correct_with_edits": "Correct with the admin's edits (+1)",
                "wrong": "Wrong (-1)", "wrong_with_edits": "Wrong, replaced by the admin's edited sequence (-1 for the proposal)"}


# ---------------------------------------------------------------------------------------------- the plan of a run
def steps(params, project):
    f1 = family1.steps(params, project)
    out = [f1[0], {"key": "f1_last", "title": "Director: data dictionaries approved before for these same files", "family": "1",
                   "agent": "Director", "review": True}] + f1[1:]
    out.append(admin_ask.gate_step())      # the admin's questions to all the Managers; Family 2 starts only on the admin's word
    out += family2.steps(params, project)
    out.append({"key": "f3_plan", "title": "Family 3 Manager: the rules to use on this data (from every section of the rules library)", "family": "3",
                "agent": "Manager", "review": True})
    out.append({"key": "report", "title": "Admin Agent: the report of the whole flow", "family": "R", "agent": "Admin Agent"})
    return out


def item_key(sec, lvl, rid, rnd=1):
    return "%s/%s/%s%s" % (sec, lvl, rid, "" if rnd <= 1 else "#%d" % rnd)


def split_item(item):
    """'errors/nvme_command/cmd_incomplete#2' -> (section, level, id, round). An error's own steps carry '@<finding>' after the item."""
    base, _, rnd = item.split("@")[0].partition("#")
    sec, lvl, rid = base.split("/")
    return sec, lvl, rid, int(rnd) if rnd else 1


def base_item(item):
    """The pattern's item of an error's own steps ('errors/nvme_command/cmd_timeout@10' -> 'errors/nvme_command/cmd_timeout')."""
    return item.split("@")[0]


def error_of(item):
    """The error (the detector's finding) an item's steps are about, or None for the pattern's own steps."""
    e = item.partition("@")[2]
    return int(e) if e.isdigit() else None


def parse_key(key):
    """'f3:<item>:<step>' -> (item, step)."""
    body = key[3:]
    item, _, sub = body.rpartition(":")
    return item, sub


def item_steps(sec, lvl, rid, name, write, message="", rnd=1):
    item = item_key(sec, lvl, rid, rnd)
    k = lambda s: "f3:%s:%s" % (item, s)       # noqa: E731
    tag = "%s%s · " % (name, "" if rnd <= 1 else " (round %d)" % rnd)
    out = []
    if write:
        out.append({"key": k("write"), "title": tag + "Rule writer: the rule from your words", "family": "3", "agent": "Rule writer",
                    "review": True, "input": {"message": message}})
    # Family 4 · Coding (owner, 2026-11-12) makes the item's code: the requirements with the admin, then the rounds of Coder and Tester,
    # then the admin's review of the final code (the step keeps the name "code": Run and the result read its output as before)
    out += family4.flow_steps(k, tag)
    out += [{"key": k("run"), "title": tag + ("run on its own CSV file" if sec == "analytics" else "run on the tree"), "family": "3", "agent": "Runner"},
            {"key": k("test"), "title": tag + "Tester: the result checked independently", "family": "3", "agent": "Tester"},
            {"key": k("export"), "title": tag + "export (CSV and HTML)", "family": "3", "agent": "Runner"},
            {"key": k("result"), "title": tag + "the result, for your review", "family": "3", "agent": "Manager", "review": True}]
    if family3.goes_to_stages(sec):
        # (owner, 2026-11-11) the errors a pattern finds are listed on their own page; each error is taken through the stages on its own page
        out.append({"key": k("errors"), "title": tag + "the errors this pattern found (each is taken through stage 1 and stage 2 on its own page)", "family": "3", "agent": "Manager"})
    return out


ERRORS_DONE = {"key": "errors_done", "title": "Stage 1 and stage 2 of the errors: on the errors page; then the report", "family": "3", "agent": "Manager", "review": True}


def graph_steps(k, tag):
    """Stage 2 (owner, 2026-11-11): the procedural graph after the isolation: defect -> cause -> solution."""
    return [{"key": k("cause"), "title": tag + "stage 2: the procedural graph: what is stored for this defect, and its cause this time", "family": "3",
             "agent": "Procedural graph", "review": True},
            {"key": k("solution"), "title": tag + "stage 2: the solution: the stored ones ranked by your judgements, or the first one", "family": "3",
             "agent": "Procedural graph", "review": True}]


class ItemCtx:
    """A step context for one Family 3 item inside the flow: the family3 functions see the item's section, level and id
    as their run parameters, and their own step names ("code", "run", ...) in output_of."""

    def __init__(self, ctx, item, sub):
        sec, lvl, rid, rnd = split_item(item)
        self._c = ctx
        self.engine, self.run = ctx.engine, ctx.run
        self.step = dict(ctx.step, key=sub)
        self.input = ctx.input
        self.item, self.round = item, rnd
        self.params = dict(ctx.params, _kind="rule_run", section=sec, level=lvl, id=rid,
                           message=ctx.input.get("message") or "", upload_id=None)
        self.prefix = "f3:%s:" % item

    @property
    def project(self):
        return self._c.project

    def progress(self, text):
        self._c.progress(text)

    def evidence(self, claims):
        self._c.evidence(claims)

    def admin_comments(self):
        return self._c.admin_comments()

    def output_of(self, key):
        if "@" in self.item and key in ("write", "code", "run", "test", "export", "result", "errors"):
            return self._c.output_of("f3:%s:%s" % (base_item(self.item), key))      # an error's steps read their pattern's results
        return self._c.output_of(self.prefix + key)


def _admin(project):
    return (project or {}).get("admin") or "admin"


def _standin(engine):
    return engine.runner.runtime == "standin"


def needs_hierarchy(project):
    """Does this analysis join the exports of its recording into one hierarchy (Family 2)? It depends on the tool that exported
    the recording, asked on the start page (project.source_tool) and on what the reference library says of that tool
    ("hierarchy" in reference_library/index.json): Teledyne LeCroy's five exports of one recording are joined; a tool whose
    export is one table has nothing to join. True when no tool was asked or the library says nothing: the flow as it was.
    Not used by run_step yet: Family 3's rules read the hierarchy, so for a tool without one they have nothing to read; when
    such a tool becomes ready, the Family 2 steps are skipped with source_tools.no_hierarchy_reason(project)."""
    return source_tools.needs_hierarchy(project)


def call_app(engine, method, path, body=None):
    """One request to the application's own endpoints (the isolation tab's), from the engine's thread."""
    app = getattr(engine.services, "app", None)
    if app is None:
        raise RuntimeError("the application object is not available to the flow (services.app)")
    with app.test_client() as c:
        r = c.open(path, method=method, json=body)
    j = r.get_json(silent=True)
    if r.status_code >= 400:
        raise RuntimeError("%s %s answered %s: %s" % (method, path, r.status_code, (j or {}).get("error") if isinstance(j, dict) else r.data[:200]))
    return j or {}


# ---------------------------------------------------------------------------------------------- the steps
def ahead_chains(steps):
    """What may work before its turn: each file's Data Explorer and then its Data Grounder. They read only their own file and need no decision; only the Manager's
    dictionary does. Nothing works ahead until everything before the files is finished, because "use the dictionaries approved last time?" can skip the reading."""
    first = next((i for i, s in enumerate(steps) if s["key"].startswith(("explore:", "ground:", "manager:"))), None)
    if first is None or any(s["state"] not in ("done", "approved", "skipped") for s in steps[:first]):
        return []
    by_file = {}
    for s in steps[first:]:
        if s["key"].startswith(("explore:", "ground:")):
            by_file.setdefault(s["key"].split(":", 1)[1], []).append(s)
    chains = []
    for ss in by_file.values():
        todo = [s["id"] for s in ss if s["state"] == "waiting"]
        if todo and all(s["state"] in ("waiting", "done", "skipped") for s in ss):
            chains.append(todo)
    return chains


def run_step(ctx):
    key = ctx.step["key"]
    if key == "f1_last":
        return _f1_last(ctx)
    if key == admin_ask.GATE:
        return admin_ask.run_gate(ctx)
    if key == "f3_plan":
        return _f3_plan(ctx)
    if key == "report":
        return _report(ctx)
    if key == "errors_done":
        return _errors_done(ctx)
    if key.startswith("f3:"):
        item, sub = parse_key(key)
        ic = ItemCtx(ctx, item, sub)
        if sub in ("research", "req", "code"):   # Family 4 · Coding research: the data research, the requirements, the rounds of code and test
            return family4.run_step(ic)
        if sub in ("write", "run", "test", "export"):
            return getattr(family3, "_" + sub)(ic)
        return {"result": _result, "errors": _errors, "isolate": _isolate, "cause": _cause, "solution": _solution, "outcomes": _outcomes, "testcase": _testcase,
                "summary": _summary}[sub](ic)
    fam = ctx.step.get("family")
    if fam == "1":
        return family1.run_step(ctx)
    if fam == "2":
        return family2.run_step(ctx)
    raise RuntimeError("unknown step %s" % key)


# ---- Family 1: dictionaries approved before
def _f1_last(ctx):
    files = family1.inventory(ctx.project.get("folder"))      # every CSV: a file that is not of the five levels has a dictionary too
    if ctx.input.get("comments"):
        return core.Result({}, skip="the admin asked for the files to be read again (%s)" % ctx.input["comments"][-1])
    known = []
    for f in files:
        d = family1.approved_dictionary(f["format_key"], f["name"])
        if d:
            known.append({"file": f["name"], "level": f["level_label"], "version": d.get("version"), "approved_by": d.get("approved_by"),
                          "approved_at": d.get("approved_at"), "columns": len(d.get("columns") or []), "rows": d.get("rows"),
                          "columns_in_file": f.get("columns"), "format_key": f["format_key"],
                          "with_meaning": sum(1 for c in d.get("columns") or [] if c.get("meaning"))})
    if not known:
        return core.Result({"files": len(files)}, skip="no data dictionary was approved before for these files (same name and same headers)")
    body = ["**Admin %s, need review.** Data dictionaries were approved before for %d of the %d files, with these same headers:" % (
        _admin(ctx.project), len(known), len(files)), "",
        "| file | level | rows | columns in the file | columns holding a value | with a meaning | version | approved by | on |", "|---|---|---|---|---|---|---|---|---|"]
    body += ["| %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (k["file"], k["level"], "{:,}".format(k["rows"]) if isinstance(k.get("rows"), int) else "not recorded",
                                                                 "{:,}".format(k["columns_in_file"]) if isinstance(k.get("columns_in_file"), int) else "?", k["columns"], k["with_meaning"],
                                                                 k["version"], k["approved_by"], time.strftime("%Y-%m-%d %H:%M", time.localtime(k["approved_at"] or 0))) for k in known]
    unread = [f["name"] for f in files if f["name"] not in {k["file"] for k in known}]
    if unread:
        body += ["", "**No dictionary was approved before for %s: %s.** %s read now by the three agents (Data Explorer, Data Grounder, Manager), whatever you decide here." % (
            "this file" if len(unread) == 1 else "these %d files" % len(unread), ", ".join(unread), "It is" if len(unread) == 1 else "They are")]
    body += ["", "A dictionary describes the columns that hold a value in this recording. The analyzer also exports columns that are always empty (listed apart as empty) and blank spacer columns between groups (no header, never a value).",
             "Approve to use them as they are: the Explorer, the Grounder and the Manager of these files are skipped.",
             "Ask for changes to have the files read again."]
    return core.Result({"known": known}, review={"title": "Proceed with the dictionaries used last time?", "body": "\n".join(body),
                                                 "data": {"reuse": [k["file"] for k in known]}})


# ---- Family 3: the plan
def tree_of(engine, run, project):
    """The upload whose tree this flow reads, or None: none when the admin went on without stage 2 at the step after
    Family 1, or when no tree is linked to the analysis."""
    gate = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], admin_ask.GATE)) or {}).get("output"), {}) or {}
    if gate.get("stage2") == "skipped":
        return None
    from . import procedures as PR
    up = (project or {}).get("upload_id")
    return up if up and PR.TREE in PR.source_paths(up) else None


NO_TREE_ITEM = "reads the tree, and this analysis has none (stage 2 was not built): open the analysis again at stage 2 to use it"
ANALYTICS_ON_TREE_ITEM = ("reads the tree, and every rule of Data analytics reads one CSV file of the recording on its own: write a change for it, "
                          "and the Rule writer writes it on its file")


def cannot_run_here(r, has_tree, paths):
    """Why an item cannot run on this analysis, in words, or "": it reads the tree and there is none, or its procedure
    names a file that the analysis does not have. An item without a procedure yet can always be written for what is there."""
    from . import procedures as PR
    if not r:
        return ""
    if not PR.application_code(r) and PR.analytics_tree_problem(r, PR.procedure_of(r)):
        # an item of Data analytics whose procedure was written on the tree before 2026-11-15: it reads one CSV file now (write a change for it)
        return ANALYTICS_ON_TREE_ITEM
    if family3.needs_tree(r):
        return "" if has_tree else NO_TREE_ITEM
    missing = [s["file"] for s in (PR.procedure_of(r) or {}).get("source_data") or [] if s["file"] != PR.TREE and s["file"] not in paths]
    if missing:
        return "reads %s, which this analysis does not have: put that file into the folder and read it at stage 1, or write a change for the item" % ", ".join(missing)
    return ""


def _f3_plan(ctx):
    up = tree_of(ctx.engine, ctx.run, ctx.project)
    from . import procedures as PR
    paths = PR.recording_paths(up, ctx.project.get("folder"))
    if paths.get(PR.TREE):
        try:        # the header of every level's file is stored with the tree, once: tree.columns(level) then gives the header to every reader
            from nvme_hier import tree_api
            tree_api.store_headers(paths[PR.TREE])
        except Exception:      # noqa: BLE001 - without it Tree.columns reads the file's header itself, and says where its columns came from
            pass
    items = []
    for sec in family3.tree():
        for lv in sec["levels"]:
            for it in lv["items"]:
                r = family3.load_rule(sec["section"], lv["level"], it["id"]) or {}
                approved = it["status"] == "approved"
                # approved items, the owner's default choice (family3.DEFAULT_CHOSEN) and the demo error are ticked
                selected = approved or bool(it.get("default")) or (sec["section"] != "analytics" and bool(it.get("demo")))
                blocked = cannot_run_here(r, bool(up), paths)
                items.append({"key": item_key(sec["section"], lv["level"], it["id"]), "section": sec["section"], "section_label": sec["label"],
                              "level": lv["level"], "level_label": lv["label"], "name": it["name"], "status": it["status"],
                              "version": it.get("version", 0), "demo": it.get("demo", False), "selected": selected and not blocked,
                              "blocked": blocked, "last_run": (r.get("last_run") or {}).get("at")})
    tick_added_items(items, ctx.input)      # an item the admin added from page 3 ("Use it in this analysis") is ticked; see add_item_to_analysis
    chosen = [i for i in items if i["selected"]]
    from . import rule_evidence
    rec = rule_evidence.recording(up) or {}
    rows = rec.get("rows") or {}
    body = ["**Admin %s, need review.** Choose what to look for in the recording **%s**%s. Every item you tick runs on it." % (
        _admin(ctx.project), rec.get("name") or ctx.project.get("name") or "of this analysis",
        " (%s NVMe commands)" % "{:,}".format(rows["nvme_command"]) if rows.get("nvme_command") is not None else ""), ""]
    for sec, label in family3.SECTIONS.items():
        rows = [i for i in chosen if i["section"] == sec]
        body += ["**%s** (%d chosen of %d)" % (label, len(rows), sum(1 for i in items if i["section"] == sec)), ""]
        if rows:
            body += ["| item | level | rules | what happens |", "|---|---|---|---|"]
            body += ["| %s | %s | %s | %s |" % (i["name"], i["level_label"], ("version %d, approved" % i["version"]) if i["status"] == "approved" else "draft",
                                               "proceeds with the current rules" if i["status"] == "approved" else "the Rule writer drafts it and asks you first")
                     for i in rows]
        body.append("")
    blocked = [i for i in items if i.get("blocked") == NO_TREE_ITEM]
    if blocked:
        body += ["**This analysis has no tree** (you went on without stage 2, or none was built). %d item%s the tree and cannot run here: %s. "
                 "Items that read one file run as they are. To use the others, open the analysis again at stage 2 and build the tree." % (
                     len(blocked), " reads" if len(blocked) == 1 else "s read", ", ".join(i["name"] for i in blocked)), ""]
    on_tree = [i for i in items if i.get("blocked") == ANALYTICS_ON_TREE_ITEM]
    if on_tree:
        body += ["**%d item%s of Data analytics still read%s the tree**, and every rule of Data analytics reads one CSV file of the recording on its own: %s. "
                 "Write a change for it, and the Rule writer writes it on its file." % (
                     len(on_tree), "" if len(on_tree) == 1 else "s", "s" if len(on_tree) == 1 else "", ", ".join(i["name"] for i in on_tree)), ""]
    nofile = [i for i in items if i.get("blocked") and i["blocked"] not in (NO_TREE_ITEM, ANALYTICS_ON_TREE_ITEM)]
    if nofile:
        body += ["**%d item%s a file this analysis does not have** and cannot run here: %s." % (
            len(nofile), " reads" if len(nofile) == 1 else "s read", "; ".join("%s (%s)" % (i["name"], i["blocked"].split(",")[0].split(": put")[0]) for i in nofile)), ""]
    had = _items_in_run(ctx.engine, ctx.run["id"])
    if had:
        body += ["**This analysis was opened again.** %d item%s already ran in it. An item you tick again is not computed again while its rule, its code and "
                 "the data are the same: its result is kept. It runs again only when you write a change for it, or when its rule or the data changed since." % (
                     len(had), "" if len(had) == 1 else "s"), ""]
    body += ["Tick or untick items in the list below, add a new item if you need one, then approve.",
             "Every item of a section that finds defects (%s) goes on to stage 1 (isolation of one defect) and stage 2 (the test case)." % ", ".join(
                 family3.SECTION_INFO[x]["label"] for x in family3.SECTIONS if family3.goes_to_stages(x))]
    body += command_rules_cost_lines(items)
    return core.Result({"upload_id": up, "proposed": [i["key"] for i in chosen]},
                       review={"title": "What to look for in this recording", "body": "\n".join(body),
                               "data": {"items": items, "sections": dict(family3.SECTIONS), "levels": family3.LEVEL_LABEL, "upload_id": up, "recording": rec}})


def command_rules_cost_lines(items):
    """What choosing a rule of the application's rule set for the NVMe command level costs, said on the card where they are chosen (owner,
    2026-11-15): which case holds now (a model connected or not: agentic/procedures.MODEL_CONNECTED) and the counts of the rule set's own
    sentence (nvme_hier/command_error_rules.COST_WORDS, also shown in the rules library under each group). [] when the library has none."""
    from . import procedures as PR
    from nvme_hier import command_error_rules as CE
    mine = [i for i in items or [] if i.get("section") == "errors" and i.get("level") == "nvme_command" and str(i.get("key") or "").split("/")[-1].startswith(CE.ITEM_PREFIX)]
    if not mine:
        return []
    now = ("A model is connected now: each of them you tick is coded by Family 4 and its rows are compared with the application's reference implementation."
           if PR.model_writes_the_code({"kind": CE.KIND}) else
           "No model is connected now: each of them you tick runs the application's reference implementation, with no call to a model.")
    return ["", "**The %d rules of the NVMe command level** (Errors, NVMe commands; none is chosen in advance). %s %s" % (len(mine), now, CE.COST_WORDS)]


def _items_in_run(engine, rid):
    """{item without its round: {"round": the latest round, "steps": that round's steps}} for the items this run already holds."""
    out = {}
    for s in engine.store.all("SELECT key, state, output FROM step WHERE run=? AND key LIKE 'f3:%' ORDER BY idx", (rid,)):
        item, sub = parse_key(s["key"])
        if "@" in item:
            continue                    # an error's own steps: on that error's page
        sec, lvl, rid_, rnd = split_item(item)
        e = out.setdefault(item_key(sec, lvl, rid_), {"round": 0, "steps": {}})
        if rnd > e["round"]:
            e["round"], e["steps"] = rnd, {}
        if rnd == e["round"]:
            e["steps"][sub] = s
    return out


def _kept_reason(engine, run, project, r, had):
    """Why an item that already ran in this run need not run again, in words; "" when it must run (again)."""
    from . import procedures as PR
    st = had["steps"]
    res, ran = st.get("result"), st.get("run")
    if not res or res["state"] != "approved" or not ran or ran["state"] != "done":
        return ""                       # its last round did not finish with an approved result
    out = core.jload(ran["output"], {}) or {}
    if (out.get("upload_id") or None) != (tree_of(engine, run, project) or None):
        return ""                       # the data it ran on is not the data of the analysis now
    if out.get("kind") == "python":
        proc, code = PR.procedure_of(r), PR.code_state(r)
        if not proc or out.get("procedure_version") != proc.get("version") or not code.get("verified") or out.get("code_file") != code.get("path"):
            return ""                   # its rule or its verified code changed since
        if not out.get("upload_id"):    # it read the folder's files: they must be the files it read then
            paths = PR.folder_paths((project or {}).get("folder"))
            t = ran_at(engine, ran)
            for s in proc["source_data"]:
                p = paths.get(s["file"])
                try:
                    if not p or os.stat(p).st_mtime > t:
                        return ""
                except OSError:
                    return ""
    return "kept: its rule, its code and the data are the same as when it ran (round %d), so it was not computed again" % had["round"]


def ran_at(engine, step_row):
    s = engine.store.one("SELECT started FROM step WHERE run=? AND key=?", (step_row.get("run"), step_row["key"])) if step_row.get("run") else None
    return (s or {}).get("started") or step_row.get("started") or 0


def _plan_steps(engine, data, admin, run=None):
    edits = data.get("edits") or {}
    family3.sync_sections()
    sel = edits.get("selected")
    if sel is None:
        sel = [i["key"] for i in data.get("items") or [] if i.get("selected")]
    sel = list(dict.fromkeys(sel))
    messages = dict(edits.get("edit") or {})
    for n in edits.get("new") or []:
        sec, lvl, name = n.get("section"), n.get("level"), (n.get("name") or "").strip()
        if not name:
            continue
        if sec not in family3.SECTIONS or lvl not in family3.LEVELS:
            raise ValueError("a new item needs a section and one of the five levels")
        r = family3.add_item(sec, lvl, name, n.get("description") or "", admin)
        k = item_key(sec, lvl, r["id"])
        sel.append(k)
        messages[k] = (n.get("description") or name).strip()
    if not sel:
        raise ValueError("choose at least one item (or add one)")
    gone = {item_key(x["section"], x["level"], x["id"]) for x in family3.deleted_items()}
    sel = [k for k in sel if k not in gone]           # deleted while the plan waited: not run
    if run is not None and gone:
        try:                                          # the errors a deleted rule of the admin's own filed leave this analysis's tree
            remove_deleted_items_errors(_tree_db(tree_of(engine, run, engine.store.one("SELECT * FROM project WHERE id=?", (run["project"],)) or {})))
        except Exception:      # noqa: BLE001 - the plan is approved all the same; the errors gate sweeps again
            pass
    if not sel:
        raise ValueError("every chosen item was deleted: choose at least one item (or add one)")
    order = {s: i for i, s in enumerate(family3.SECTIONS)}
    project = (engine.store.one("SELECT * FROM project WHERE id=?", (run["project"],)) or {}) if run else {}
    has_tree = tree_of(engine, run, project) is not None if run else True
    from . import procedures as PR
    paths = PR.recording_paths(tree_of(engine, run, project), project.get("folder")) if run else {}
    had_all = _items_in_run(engine, run["id"]) if run else {}
    plan, kept = [], {}
    for k in sorted(sel, key=lambda x: order.get(x.split("/")[0], 9)):
        sec, lvl, rid, _ = split_item(k)
        r = family3.load_rule(sec, lvl, rid)
        if r is None:
            raise ValueError("no such item: %s" % k)
        why_not = cannot_run_here(r, has_tree, paths) if run else ""
        if why_not and k not in messages:
            raise ValueError("“%s” %s. Untick it, or write a change for it" % (r["name"], why_not))
        # the Rule writer drafts the procedure only when the item has none, or the admin asked for a change in words
        write = family3.procedures_of(r) is None or k in messages
        had = had_all.get(k)
        if had and not write:
            why = _kept_reason(engine, run, project, r, dict(had, steps={sub: dict(s, run=run["id"]) for sub, s in had["steps"].items()}))
            if why:                      # (owner, 2026-11-12) an analysis opened again: what was computed is not computed again
                kept[k] = why
                continue
        plan += item_steps(sec, lvl, rid, r["name"], write, messages.get(k) or r.get("description") or r["name"], (had["round"] + 1) if had else 1)
    if any(family3.goes_to_stages(k.split("/")[0]) for k in sel):
        old = engine.store.one("SELECT id FROM step WHERE run=? AND key=?", (run["id"], ERRORS_DONE["key"])) if run else None
        if old:                          # the analysis was opened again: the same step asks again, after the new rounds
            engine.store.exec("UPDATE step SET state='waiting', note=NULL, error=NULL, idx=(SELECT MAX(idx) FROM step WHERE run=? AND family='3') + 1 WHERE id=?", (run["id"], old["id"]))
            engine.store.exec("UPDATE step SET idx = idx + 1 WHERE run=? AND family='R'", (run["id"],))
        else:
            plan.append(dict(ERRORS_DONE))     # (owner, 2026-11-11) after every pattern ran: the errors, then the report
    if run is not None:
        data["kept"] = kept
    return plan, sel


# ---- Family 3: the result of one item
def _result(ic):
    if ic.input.get("superseded"):
        return core.Result({}, skip="the admin asked to change the rule: a new round follows")
    res = family3._result(ic)
    r = family3._rule(ic)
    body = res.review["body"].replace("Approve to accept the result. To change what is computed, edit the rule (the code follows the rule).", "")
    if family3.errors_of_a_file(r):
        n = (ic.output_of("run") or {}).get("rows") or 0
        # no defect is picked on this card (the picker is for findings of the tree): the rows are listed by the errors step, each with its own page
        res.review["data"].update(errors_page=True, other_errors={"kind": other_errors.KIND, "list": "/api/other-errors/%d" % ic.run["id"],
                                                                  "page": "/other-error?run=%d" % ic.run["id"]})
        body += ("\n\nApprove to accept it%s. **Change**: say what to change in the rule; the Rule writer drafts a new version for you, and the code runs again."
                 % ((" and list the %s row%s it found as errors of this file: each gets a page of its own (the row, the rows around it, the isolation of the "
                     "defect). %s" % ("{:,}".format(n), "" if n == 1 else "s", other_errors.CANNOT_DO)) if n else " (the rule found no row in this file, so there is no error to list)"))
    elif family3.errors_of_the_tree(r) and (ic.output_of("run") or {}).get("kind") == "python":
        from . import procedures as PR
        from nvme_hier import coded_findings as CF
        run_out = ic.output_of("run") or {}
        n = run_out.get("rows") or 0
        res.review["data"]["errors_page"] = True
        lacks = family3.tree_rows_problem(r, PR.procedure_of(r), has_tree=bool(run_out.get("upload_id"))) or (
            CF.result_problem(run_out.get("columns"), r["level"], r["name"]) if run_out.get("upload_id") else "")
        if not run_out.get("upload_id"):
            body += "\n\n**No error can be listed from this result:** " + NO_TREE_ERRORS % r["name"]
        elif lacks:
            body += "\n\n**No error can be listed from this result:** " + lacks
        elif n:
            origin = family3.rule_origin(r)          # whose rule it is, from the rule file's stored facts: the admin's own (None), or one of the application's rule set
            body += ("\n\nApprove to accept it and file the %s row%s it found as %s of this recording (%s): each is then listed on the errors page and goes "
                     "through stage 1, the isolation of the defect, stage 2, its cause and its solution, and its test, on its own page, as an error of the "
                     "built-in checks does. Nothing is listed before you approve. %s%s" % (
                         "{:,}".format(n), "" if n == 1 else "s", "an error" if n == 1 else "errors", family3.LEVEL_FILE.get(r["level"], r["level"]),
                         (origin or {}).get("sentence") or CF.kind_sentence(r["id"], r["name"]), (" " + CF.CANNOT_DO) if r["level"] != "nvme_command" else ""))
            twice = already_listed_words(ic, r, run_out)
            if twice:
                body += "\n\n" + twice
            differs = next((c for c in (ic.output_of("test") or {}).get("checks") or [] if not c.get("ok") and "reference implementation" in str(c.get("check"))), None)
            if differs:
                body += ("\n\n**The code and the application's reference implementation of this rule do not find the same rows:** %s. Approving files the rows of "
                         "the code as they are. To have the code corrected first, choose Change and say which rows are missing or too many." % differs.get("detail"))
        else:
            words = nothing_found_words(r, run_out, ic.output_of("test"))
            body += "\n\n" + (words if words.startswith(CODE_LISTED_NOTHING_BUT) else "Approve to accept it. " + words)
        body += " **Change**: say what to change in the rule; the Rule writer drafts a new version for you, and the code runs again."
    elif family3.goes_to_stages(r["section"]):
        n = (ic.output_of("run") or {}).get("rows") or 0
        page = ic.engine.store.one("SELECT id FROM step WHERE run=? AND key=?", (ic.run["id"], ic.prefix + "errors"))
        if page:
            res.review["data"]["errors_page"] = True
        body += ("\n\nApprove to accept it%s. **Change**: say what to change in the rule; the Rule writer drafts a new version for you, "
                 "and the code runs again." % ((" and open its errors: each error goes through stage 1 and stage 2 on its own page" if page else
                                                " and take the error you pick below to stage 1 and stage 2") if n else
                                               " (the rule found no error in this data, so stage 1 and stage 2 have nothing to isolate)"))
    else:
        body += "\n\nApprove to accept it. **Change**: say what to change in the rule; the Rule writer drafts a new version for you, and the code runs again."
    res.review["body"] = body
    return res


# ---- stage 1 and stage 2
def _defect(ic):
    """The defect the admin chose. Nothing is chosen for the admin (owner, 2026-11-11: "you are showing the defect number by default.
    Who gave you that ... Don't do that"): no choice, no stage 1."""
    res = ic.output_of("run")
    if error_of(ic.item) is not None:
        return res.get("upload_id"), error_of(ic.item)          # an error's own steps: the error is in the step's name
    fid = ic.input.get("defect")
    return res.get("upload_id"), (None if fid in (None, "", "none") else int(fid))


def defect_choices(res):
    """[[finding id, "where · what"], ...] for the defects a rule found, in the words of the result table (no defect number)."""
    head = res.get("head") or []
    plain = family3.plain_defects(res.get("columns"), head) or {"rows": []}
    return [[x[0], "%s · %s" % (p[1], p[0])] for x, p in zip(head, plain["rows"])]


def defect_words(res, fid):
    return next((w for i, w in defect_choices(res) if str(i) == str(fid)), "the defect the rule filed in this recording")


def _item_level(ic):
    """The level of the step's item ("nvme_command", ..., "other"): from the step's parameters, else from the item's own name
    (section/level/id). An item of the tree is decided without reading its rule from disk."""
    p = getattr(ic, "params", None) or {}
    if p.get("level"):
        return str(p["level"])
    parts = str(getattr(ic, "item", "") or "").split("/")
    return parts[1] if len(parts) >= 2 else ""


def _isolate(ic):
    """Stage 1, the isolation of the defect (owner, 2026-11-11): the window of 15 NVMe commands above the error's command and 15 below,
    with every lower level, goes to the model; the error found by the admin's pattern is written at the end of the prompt; the model
    answers what, why, when, where, who, which and how, and proposes a standard name and the cause in one line. The admin confirms the
    name. Nothing is judged here: the procedural graph comes after the isolation (stage 2)."""
    if _item_level(ic) == "other" and family3.errors_of_a_file(family3._rule(ic)):
        return core.Result({}, skip="this rule found rows of a CSV file that is not part of the tree: each has a page of its own (the row, the rows around it, "
                                    "the isolation); stage 1 and stage 2 of the tree do not apply to it")
    up, fid = _defect(ic)
    if fid is None:
        if not (ic.output_of("run").get("head") or []):
            return core.Result({}, skip="the rule found no defect in this data: stage 1 and stage 2 need one")
        return core.Result({}, skip="you chose no defect to take to stage 1" if ic.input.get("defect") == "none" else
                           "no defect was chosen on the result card: stage 1 and stage 2 take only the defect you choose")
    if (family3._rule(ic).get("kind") or "detection_rule") != "detection_rule" and not _filed_by_a_coded_rule(up, fid):
        # stage 1 isolates an error that is filed in the tree (a finding): the detector's, or since 2026-11-15 a row an approved rule of the
        # admin's own found (nvme_hier/coded_findings.py). A rule whose rows were not filed gives row numbers only
        return core.Result({}, skip="the rows of this rule are not filed as errors of the tree: stage 1 takes an error the built-in checks filed, or a "
                                    "row found by a rule of your own on a level of the tree after you approved its result")
    hint = "; ".join(c for c in ic.input.get("comments") or [] if c and not c.startswith(LOOK_AGAIN))     # "look again: n above, m below" is a window, not a hint
    ic.progress("stage 1: the isolation of the defect from the window (15 commands above, 15 below, every level under them)")
    r = call_app(ic.engine, "POST", "/api/isolate/%s/%d/isolate" % (up, int(fid)),
                 {"n": ic.input.get("n"), "m": ic.input.get("m"), "remember": bool(ic.input.get("window_set")), "history": True,
                  "levels": LOWER, "hint": hint, "anyway": True, "name": _admin(ic.project), "standin": _standin(ic.engine), "isolation": True})
    iso = r.get("isolation") or {}
    rule = family3._rule(ic)
    words = defect_words(ic.output_of("run"), fid)
    labels = iso.get("labels") or {}
    body = ["**Admin %s, need review.** Stage 1, the isolation of the defect you chose: **%s**, found by the rule *%s*." % (_admin(ic.project), words, rule["name"]), ""]
    if hint:
        body += ["**Your hint for this round:** " + hint, ""]
    body += _window_lines(r.get("window") or {})
    body += ["**The isolation** (the model read the window first and the error last, as you set it; %s):" % (
        "answered by the model" if not str(iso.get("producer") or "").startswith("stand-in") else "no model answered: built from the rule's own facts"), "",
        "| | |", "|---|---|"]
    body += ["| **%s** | %s |" % (labels.get(k, k), (iso.get(k) or "").replace("|", "/")) for k in ("what", "why", "when", "where", "who", "which", "how")]
    body += ["", "**Proposed standard name:** %s" % (iso.get("standard_name") or "none"),
             "", "**Proposed cause (one line):** %s: %s" % (iso.get("cause_side") or "other", iso.get("cause_header") or "not named"), ""]
    if iso.get("cited_rows"):
        body += ["**The rows it rests on:** " + ", ".join("%s row %s" % (c.get("level"), c.get("rowid")) for c in iso["cited_rows"][:30]), ""]
    probs = list(iso.get("problems") or [])
    body += ["**Checks by the code:** " + ("every cited row is in the window; every question is answered" if not probs else "; ".join(probs)), "",
             "Choose the defect's standard name below (an existing one when it is the same defect, or a new one), then approve. "
             "**Nothing is judged here:** stage 2 then shows what the procedural graph already holds for this defect, its causes and their solutions."]
    out = {"upload_id": up, "finding": int(fid), "sequence": r.get("sequence") or [], "reason": r.get("reason"), "scenario_name": iso.get("standard_name") or r.get("scenario_name"),
           "isolation": iso, "checks": r.get("checks"), "rounds": len(r.get("rounds") or []), "cited": len(iso.get("cited_rows") or []),
           "expected_outcome": r.get("expected_outcome"), "observed_outcome": r.get("observed_outcome"), "window": r.get("window"),
           "rule": iso.get("rule"), "rule_name": rule.get("name"), "level": iso.get("level")}
    known = iso.get("known") or []
    return core.Result(out, producer=iso.get("producer") or r.get("producer"),
                       review={"title": "Stage 1 · isolation of the defect: " + words.split(" · ")[0], "body": "\n".join(body),
                               "data": {"isolation": iso, "upload_id": up, "finding": int(fid), "proposed_name": iso.get("standard_name") or "",
                                        "known_defects": [{"id": d["id"], "name": d["name"], "seen": d["seen"], "causes": d["causes"]} for d in known[:100]],
                                        "defects": [] if error_of(ic.item) is not None else defect_choices(ic.output_of("run"))[:200], "chosen_by_admin": True,
                                        "window": {k: (r.get("window") or {}).get(k) for k in ("n", "m", "source", "counts")}}})


def _errors(ic):
    """The errors a pattern found, for the errors page (owner, 2026-11-11: each error is taken through stage 1 and stage 2 on its own page,
    then back to the list; page 3 shows only where each stands)."""
    res = ic.output_of("run")
    head = res.get("head") or []
    if family3.errors_of_a_file(family3._rule(ic)):
        return _errors_of_a_file(ic, res)           # rows of a CSV file that is not part of the tree: their own kind, their own page
    if res.get("kind") == "python" and family3.errors_of_the_tree(family3._rule(ic)):
        return _errors_of_a_coded_rule(ic, res)     # rows a rule of the admin's own found on the tree: filed as findings of the tree first
    if not head:
        return core.Result({"errors": []}, skip="the pattern found no error in this recording")
    r = family3._rule(ic)
    plain = family3.plain_defects(res.get("columns"), head) or {"rows": [[x[3], "row %s" % x[5], "", ""] for x in head]}
    errors = [{"finding": x[0], "what": p_[0], "where": p_[1], "when": p_[2], "serious": p_[3], "level": x[1],
               "row": (x[8] if len(x) > 8 and x[8] is not None else x[5])} for x, p_ in zip(head, plain["rows"])]
    with_identity(_tree_db(res.get("upload_id")), errors)      # each entry also keeps what its error is, so that its number can be checked and followed later
    return core.Result({"errors": errors, "item": base_item(ic.item), "upload_id": res.get("upload_id"), "total": res.get("rows") or len(head), "pattern": r["name"]},
                       producer="the code")


CODED_KIND = "admins_rule"                # the kind of an errors list whose errors a rule of the admin's own filed (the detector's lists carry no kind)
NO_TREE_ERRORS = ("The rule '%s' ran on the files of the folder, without the tree (stage 2 of the analysis was not built), so the rows it found cannot be filed "
                  "as errors of the tree and cannot go on to the isolation of the defect. No error is listed for it.")
RESULT_WAITS = "The result of %s waits for your decision on page 3: its errors are listed here after you approve it."
RESULT_NOT_YET = "%s has not reached its result yet (page 3 shows where it stands): its errors are listed here after you approve its result."
ERROR_PAGE_WAITS = ("The result of %s waits for your decision on page 3 of the analysis “%s”: this error can be opened and worked on (stage 1, stage 2 and "
                    "its test) after you approve that result.")
ERROR_PAGE_NOT_YET = ("%s has not reached its result yet in the analysis “%s” (page 3 shows where it stands): this error can be opened and worked on after "
                      "you approve that result.")


def _tree_db(upload_id):
    from . import procedures as PR
    return (PR.source_paths(upload_id) or {}).get(PR.TREE) if upload_id else None


def _filed_by_a_coded_rule(upload_id, fid):
    """Is this finding one that a rule of the admin's own filed in the tree (nvme_hier/coded_findings.py)?"""
    from nvme_hier import coded_findings as CF
    db = _tree_db(upload_id)
    try:
        return bool(db) and CF.is_coded(CF.rule_of(db, fid))
    except Exception:      # noqa: BLE001 - a tree that cannot be read has no such finding
        return False


def _errors_of_a_coded_rule(ic, res):
    """The rows a rule of the admin's own found on a level of the tree (written with the Rule writer, coded by Family 4, the code verified,
    run on the tree, checked by the Tester, the result approved by the admin) are filed as findings of the tree and listed as its errors
    (owner, 2026-11-15): from here on each is an error like the detector's, with the same page, stage 1, stage 2 and test. A result that
    does not name its rows, or that is not approved, files nothing and says why in one plain sentence ("refused")."""
    from . import procedures as PR
    from nvme_hier import coded_findings as CF
    r = family3._rule(ic)
    sec, lvl, rid, _rnd = split_item(ic.item)
    # whose rule it is (the admin's own: None; a rule of the application's rule set for the NVMe command level: its own truthful words), and
    # whether the application's reference implementation or Family 4's code found the rows: both from stored facts, never guessed
    origin = family3.rule_origin(r, by_application=bool(PR.code_state(r).get("application")))
    base = {"errors": [], "kind": CODED_KIND, "item": base_item(ic.item), "upload_id": res.get("upload_id"), "total": 0, "pattern": r["name"],
            "kind_words": (origin or {}).get("kind") or CF.kind_words(rid), "kind_from": (origin or {}).get("sentence") or CF.kind_sentence(rid, r["name"]),
            "found_by": (origin or {}).get("is") or "admin"}
    if lvl != "nvme_command":
        base["cannot"] = CF.CANNOT_DO
    store = getattr(ic.engine, "store", None)
    result = store.one("SELECT state FROM step WHERE run=? AND key=?", (ic.run["id"], ic.prefix + "result")) if store else None
    if result and result["state"] == "skipped":
        return core.Result(dict(base, superseded=True), skip="this round's result was set aside (the rule was changed): the next round lists the errors", producer="the code")
    if not result or result["state"] != "approved":
        return core.Result(dict(base, refused=RESULT_WAITS % ("the rule '%s'" % r["name"])), producer="the code")
    db = _tree_db(res.get("upload_id"))
    if not db:
        return core.Result(dict(base, refused=NO_TREE_ERRORS % r["name"]), producer="the code")
    st = PR.code_state(r)
    if st.get("kind") != "python" or res.get("procedure_version") is None:
        return core.Result(dict(base, refused="The rule '%s' has no code of its own that ran on this recording, so no row can be filed as an error for it." % r["name"]), producer="the code")
    lacks = family3.tree_rows_problem(r, PR.procedure_of(r)) if res.get("procedure_version") == (PR.procedure_of(r) or {}).get("version") else ""
    try:
        if lacks:
            raise CF.Refused(lacks)
        by = (store.one("SELECT decided_by FROM review WHERE run=? AND step=(SELECT id FROM step WHERE run=? AND key=?) ORDER BY id DESC LIMIT 1",
                        (ic.run["id"], ic.run["id"], ic.prefix + "result")) or {}).get("decided_by") or ""
        # the tree is written here: it waits until no code run reads the tree (two analyses of one recording share it), see procedures.TreeLock
        got = PR.write_tree(db, lambda: CF.file_findings(db, sec, lvl, rid, res.get("procedure_version"), r["name"], res.get("output_csv") or "", approved_by=by,
                                                         progress=lambda what: ic.progress("filing the rows as errors of the tree · %s" % what), origin=origin),
                            waiting=lambda: ic.progress(PR.WAITS_FOR_READERS))
    except CF.Refused as e:
        return core.Result(dict(base, refused=str(e)), producer="the code")
    head, total = CF.listed(db, got["rule"], family3.HEAD_ROWS)
    plain = family3.plain_defects(list(family3.PR_DETECTOR_OUTPUT), head)
    facts = CF.facts_of(db, [x[0] for x in head])
    errors = []
    for x, p_ in zip(head, plain["rows"]):
        f_ = facts.get(x[0]) or {}
        # "what": the reason the rule's result gives for this very row when it gives one (its column "what was found"), else the rule's name;
        # "linked": the sentence that names the rows that belong together (one episode), carried from the result's column "linked findings"
        e = {"finding": x[0], "what": f_.get("reason") or p_[0], "where": p_[1], "when": p_[2], "serious": p_[3], "level": x[1],
             "row": (x[8] if x[8] is not None else x[5]), "rule_words": p_[0]}
        if f_.get("linked"):
            e["linked"] = f_["linked"]
        errors.append(e)
    with_identity(db, errors)           # each entry also keeps what its error is (rule, level, row), so that its number can be checked and followed later
    out = dict(base, errors=errors, total=total, rule=got["rule"], filed={k: got[k] for k in ("kept", "added", "removed", "without_a_command")})
    if not total:
        try:
            tested = ic.output_of("test")
        except Exception:      # noqa: BLE001 - the errors step called by hand has no Tester's output: the result's own words are used
            tested = None
        return core.Result(dict(out, nothing=nothing_found_words(r, res, tested)), skip="the pattern found no error in this recording", producer="the code")
    return core.Result(out, producer="the code")


CODE_LISTED_NOTHING_BUT = "The code of the rule"


def nothing_found_words(r, run_out, test_out=None):
    """One sentence for a rule of the tree whose result holds no row: it cannot be checked on this recording (with the reason its own result
    gives, or the reason the Tester's comparison with the reference implementation gives), or it found nothing. Never a failure."""
    name = r.get("name") or "this rule"
    summary = run_out.get("summary") if isinstance(run_out.get("summary"), dict) else {}
    for c in (test_out or {}).get("checks") or []:
        if not c.get("ok") and "reference implementation" in str(c.get("check")):
            # code a model wrote listed nothing, and the reference implementation finds rows: never said as "the rule found nothing"
            return "%s '%s' listed no row in this recording, and the application's reference implementation of the rule does not agree: %s. No error is listed for it; " \
                   "the code needs to be corrected first (choose Change on its result card)." % (CODE_LISTED_NOTHING_BUT, name, str(c.get("detail") or "").rstrip("."))
    why = str(summary.get("why_not") or "") if summary.get("can_be_checked") is False else ""
    if not why:
        for c in (test_out or {}).get("checks") or []:
            d = str(c.get("detail") or "")
            if d.startswith("the reference says: ") and "the code's result has" in d:      # command_error_rules.compare_with_reference, for code a model wrote
                why = d[len("the reference says: "):].rsplit("; the code's result has", 1)[0]
    if why:
        for lead in ("cannot be checked on this recording: ", "cannot be checked on this recording"):
            if why.startswith(lead):
                why = why[len(lead):]
                break
        return ("The rule '%s' cannot be checked on this recording: %s. No error is listed for it; that is what this recording allows, not a failure of the rule."
                % (name, why.strip().rstrip(".") or "its result does not say why"))
    read = summary.get("rows_read") if summary.get("is_an_error_rule") else None
    return ("The rule '%s' found no row in this recording%s: there is no error to list and nothing to isolate. An empty list is a result, not a failure."
            % (name, (" (%s row%s read)" % ("{:,}".format(read), "" if read == 1 else "s")) if isinstance(read, int) else ""))


def latest_error_lists(steps):
    """The errors steps that count on the errors page, as its script takes them: of each item the latest finished round, never a list of a CSV
    file that is not part of the tree, never one set aside by a later round. steps: the run's steps as dicts (key, state, output)."""
    latest = {}
    for s_ in steps or []:
        key, o = s_.get("key") or "", s_.get("output") if isinstance(s_.get("output"), dict) else None
        if not key.startswith("f3:") or not key.endswith(":errors") or "@" in key or o is None:
            continue
        if o.get("kind") == other_errors.KIND or o.get("superseded") or s_.get("state") not in ("done", "skipped", "approved"):
            continue
        try:
            sec, lvl, rid, rnd = split_item(key[3:-len(":errors")])
        except ValueError:
            continue
        k = item_key(sec, lvl, rid)
        if k not in latest or rnd >= latest[k][0]:
            latest[k] = (rnd, s_)
    return {k: v[1] for k, v in latest.items()}


def same_command(steps):
    """The rows that more than one pattern of this analysis lists as an error: the same command (or the same row of a lower level) found by
    two rules. Joined by identity, the level and the row's number in the level's file, never by a time stamp.
    -> [{"level", "row", "where", "listed": [{"item", "pattern", "finding"}]}] in file order."""
    seen = {}
    for item, s_ in latest_error_lists(steps).items():
        o = s_["output"]
        for e in o.get("errors") or []:
            if e.get("level") and e.get("row") is not None:
                seen.setdefault((e["level"], e["row"]), []).append({"item": item, "pattern": o.get("pattern") or item, "finding": e.get("finding"),
                                                                    "where": str(e.get("where") or "").split(" (")[0]})
    out = []
    for (level, row), xs in sorted(seen.items(), key=lambda kv: (str(kv[0][0]), int(kv[0][1]) if str(kv[0][1]).isdigit() else 0)):
        if len({x["item"] for x in xs}) > 1:
            out.append({"level": level, "row": row, "where": xs[0]["where"] or "row %s" % row, "listed": [{k: x[k] for k in ("item", "pattern", "finding")} for x in xs]})
    return out


def _quoted(names):
    names = ["'%s'" % n for n in dict.fromkeys(names)]
    return names[0] if len(names) == 1 else ", ".join(names[:-1]) + " and " + names[-1]


def same_command_lines(groups, most=12):
    """The lines of the errors gate for same_command(): which rows are listed under more than one rule, and what to do about it."""
    if not groups:
        return []
    out = ["", "**The same command under more than one rule:** %d row%s listed as an error by more than one of the rules you chose. It is one command, found by "
               "each of them for its own reason: the errors page says so on each of these errors and links the others, so that you do not isolate the same "
               "command twice without knowing." % (len(groups), " is" if len(groups) == 1 else "s are")]
    out += ["- %s: %s" % (g["where"], _quoted(x["pattern"] for x in g["listed"])) for g in groups[:most]]
    if len(groups) > most:
        out.append("- and %s more (the errors page marks every one)" % "{:,}".format(len(groups) - most))
    return out


def already_listed_words(ic, r, run_out):
    """For the result card of a rule of the tree, before its rows are filed: how many of its rows are commands that this analysis already
    lists as an error under another rule, in one sentence, or "". By the row's identity (level and row number in its file)."""
    from nvme_hier import coded_findings as CF
    try:
        steps = ic.engine.view(ic.run["id"])["steps"]
        mine = item_key(*split_item(ic.item)[:3])
        listed = {}
        for item, s_ in latest_error_lists(steps).items():
            if item == mine:
                continue
            for e in s_["output"].get("errors") or []:
                if e.get("level") == r["level"] and e.get("row") is not None:
                    listed.setdefault(int(e["row"]), []).append(s_["output"].get("pattern") or item)
        cols = list(run_out.get("columns") or [])
        if not listed or CF.ROW_COLUMN not in cols or not run_out.get("output_csv"):
            return ""
        i, rows, names = cols.index(CF.ROW_COLUMN), [], []
        for x in family3._output_rows(run_out):
            cell = (x[i] if i < len(x) else "").strip()
            if cell.isdigit() and int(cell) in listed:
                rows.append(int(cell))
                names += listed[int(cell)]
    except Exception:      # noqa: BLE001 - the card is shown all the same; the errors page and the errors gate say it again
        return ""
    if not rows:
        return ""
    return ("**The same command, found twice:** %s of these rows %s a command that this analysis already lists as an error under %s (row%s %s of %s%s). After "
            "your approval it is listed under this rule as well, as an error of its own with its own page; the errors page says on each of the two that it "
            "is the same command and links the other, so that you do not isolate it twice without knowing." % (
                "{:,}".format(len(rows)), "is" if len(rows) == 1 else "are", _quoted(names), "" if len(rows) == 1 else "s",
                ", ".join(str(x) for x in rows[:12]), family3.LEVEL_FILE.get(r["level"], r["level"]),
                " and %d more" % (len(rows) - 12) if len(rows) > 12 else ""))


def waiting_patterns(steps):
    """The patterns of sections that find defects whose errors are not listed yet because their result is not approved: [{"item",
    "pattern", "state": "waits" (the result card is open) or "not yet" (the run has not reached its result), "sentence"}]. Only the
    latest round of an item counts; an item with an approved earlier round and a later round under way is listed too (its earlier
    errors stay listed). steps: the run's steps as dicts with key, state, title."""
    latest = {}
    for s_ in steps:
        key = s_.get("key") or ""
        if not key.startswith("f3:") or not key.endswith(":result") or "@" in key:
            continue
        item = key[3:-len(":result")]
        try:
            sec, lvl, rid, rnd = split_item(item)
        except ValueError:
            continue
        if not family3.goes_to_stages(sec):
            continue
        k = item_key(sec, lvl, rid)
        if k not in latest or rnd >= latest[k][0]:
            latest[k] = (rnd, s_)
    out = []
    for k, (_rnd, s_) in latest.items():
        if s_.get("state") in ("approved", "skipped"):
            continue
        name = (s_.get("title") or k).split(" · ")[0]
        waits = s_.get("state") in ("needs_review", "rejected")
        out.append({"item": k, "pattern": name, "state": "waits" if waits else "not yet",
                    "sentence": (RESULT_WAITS % ("'%s'" % name)) if waits else (RESULT_NOT_YET % ("The rule '%s'" % name))})
    return out


class _ReadOnlyStore:
    """The flows' records read without the engine (it is made on the first use of the agents' pages): nothing is created or written."""

    def __init__(self, path):
        self.path = path

    def all(self, sql, args=()):
        import sqlite3
        con = sqlite3.connect("file:%s?mode=ro" % self.path, uri=True, timeout=30)
        con.row_factory = sqlite3.Row
        try:
            return [dict(r) for r in con.execute(sql, args)]
        except sqlite3.OperationalError:
            return []                   # a records file without these tables holds no analysis
        finally:
            con.close()


def error_page_refusal(services, upload_id, db, finding):
    """Why the page of one error may not be worked on yet, in one plain sentence, or "" when it may (owner, 2026-11-15: "you should not
    go directly wherever you want"). An error is worked on only after the admin approved the result of the pattern that found it:
    when an analysis (a flow) on this recording holds that pattern and no round of it has an approved result, the page waits. A
    pattern that no analysis of this recording holds is not under a flow's order (the recording's own findings page, as before);
    an analysis whose result step is approved behaves as before."""
    from nvme_hier import coded_findings as CF
    from . import procedures as PR
    try:
        rule = CF.rule_of(db, finding)
    except Exception:      # noqa: BLE001 - the route itself answers for an upload or a finding that is not there
        return ""
    if not rule:
        return ""
    eng = getattr(services, "agentic_engine", None)
    store = getattr(eng, "store", None)
    if store is None:
        path = os.path.join(getattr(services, "root", "") or "", "db", "agentic.sqlite")
        if not os.path.exists(path):
            return ""                   # no analysis was ever started in this application
        store = _ReadOnlyStore(path)
    runs = store.all("SELECT r.id, p.name FROM run r JOIN project p ON p.id = r.project WHERE r.kind = ? AND p.upload_id = ? ORDER BY r.id", (KIND, str(upload_id)))
    coded = CF.item_of(rule)
    waiting = None
    for run in runs:
        rounds = {}
        for s_ in store.all("SELECT key, state, title FROM step WHERE run=? AND key LIKE 'f3:%:result' ORDER BY idx", (run["id"],)):
            item = s_["key"][3:-len(":result")]
            if "@" in item:
                continue
            try:
                sec, lvl, rid, _rnd = split_item(item)
            except ValueError:
                continue
            if coded:
                mine = (sec, lvl, rid) == coded[:3]
            else:
                r = family3.load_rule(sec, lvl, rid)
                mine = bool(r) and PR.detector_rule(r) == rule
            if mine:
                rounds.setdefault((sec, lvl, rid), []).append(s_)
        for _k, ss in rounds.items():
            if any(x["state"] == "approved" for x in ss):
                return ""               # the admin approved a result of this pattern in an analysis of this recording
            last = ss[-1]
            name = (last.get("title") or "").split(" · ")[0] or "the pattern"
            waits = last["state"] in ("needs_review", "rejected")
            waiting = (ERROR_PAGE_WAITS if waits else ERROR_PAGE_NOT_YET) % ("'%s'" % name if waits else "The rule '%s'" % name, run.get("name") or "of this recording")
    return waiting or ""


def remove_deleted_items_errors(db):
    """A rule's errors leave the tree when its item is deleted from the rules library (Deleted items): -> how many findings were removed.
    Called when a plan is approved and at the errors gate, for the analysis's own tree."""
    from nvme_hier import coded_findings as CF
    if not db or not os.path.exists(db):
        return 0
    gone = {(x["section"], x["level"], x["id"]) for x in family3.deleted_items()}
    n = 0
    from . import procedures as PR
    for sec, lvl, rid, _v, _n in CF.filed_items(db):
        if (sec, lvl, rid) in gone or family3.load_rule(sec, lvl, rid) is None:
            n += PR.write_tree(db, lambda sec=sec, lvl=lvl, rid=rid: CF.remove(db, sec, lvl, rid))      # a write of the tree: never under a code run that reads it
    return n


# ---------------------------------------------------------------------------------------------- the error numbers follow a new numbering
# (2026-11-15) The number of an error is its place in the recording's findings by time. When the detector's rules run again on a recording
# (the button "Check this recording again", a timing limit applied again, every rule run anew) the findings are numbered anew, and every
# record that keeps a number has to follow, or it names another error. The stores followed; an analysis's own records did not: its errors
# page went on linking the old numbers. Two things are done about it here:
#   * follow_renumbering() takes every number an analysis of that recording keeps to its new number, in one transaction: the errors lists,
#     the result lines of the built-in checks, the commands listed under more than one rule, and the records of an older analysis that took
#     one error through the stages on page 3. An error that is no longer found is taken out of its list and counted, and the list says so.
#   * each listed error also keeps WHAT IT IS, apart from its number: "identity" = its rule, its level, its row in the level's file and
#     which one of several on that row (never a time stamp). With it a number can be checked against the recording at any time, and found
#     again: error_numbers_check() does that for one analysis, and the errors page asks it before it draws a link, so that a check that
#     moved the numbers and then failed to follow them cannot leave the page linking other errors without a word.
NO_LONGER_FOUND = "**No longer found after the recording was checked again:**"
CODED_RUN_AGAIN = (" The rows this rule finds are errors of the recording only while they are filed for it: if the rule should still find them, run it again in "
                   "this analysis (open the analysis again at stage 3 and choose the rule).")


BEING_NUMBERED = ("The errors of this recording are being numbered anew right now (a check of the recording started at %s and has not finished, or it was "
                  "stopped half-way): the numbers of the errors listed in the analyses cannot be compared with the recording until a check has finished. If "
                  "no check is running, check the recording again on the page of the NVMe command rules.")


class NumbersNotFollowed(RuntimeError):
    """The numbers kept by the analyses could not follow: the message is one plain sentence, and nothing was changed."""


def no_longer_found_words(pattern, n, coded=False):
    """The one sentence of an errors list that lost errors to a new check of its recording."""
    return ("After the recording was checked again, %s error%s of the rule '%s' %s no longer found in it and %s taken out of this list.%s"
            % ("{:,}".format(n), "" if n == 1 else "s", pattern, "is" if n == 1 else "are", "was" if n == 1 else "were", CODED_RUN_AGAIN if coded else ""))


def no_longer_found_lines(steps, skip=()):
    """The sentences of the lists that lost errors, for the errors gate: of each rule the latest list."""
    return [s_["output"]["no_longer_found"]["sentence"] for k_, s_ in latest_error_lists(steps).items()
            if k_ not in skip and isinstance(s_["output"].get("no_longer_found"), dict) and s_["output"]["no_longer_found"].get("sentence")]


def _whole(x):
    return isinstance(x, int) and not isinstance(x, bool)


class _Numbers:
    """The error numbers of one tree, asked by what an error is: its rule, its level, its row in the level's file, and which one of several
    the rule filed on that row (in the order of their numbers). Read only."""

    def __init__(self, db):
        import sqlite3
        from nvme_hier import rules as RL
        self.con = sqlite3.connect("file:%s?mode=ro" % db, uri=True, timeout=30)
        self.has = bool(self.con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='finding'").fetchone())
        # since when the findings are being taken out and filed anew (None: they are not): their numbers are passing ones meanwhile
        self.busy_since = RL.numbering_since(self.con)

    def close(self):
        self.con.close()

    def on_row(self, rule, level, row):
        """The numbers of the errors one rule filed on one row, lowest first."""
        if not self.has or rule is None or level is None:
            return []
        if row is None:
            return [r[0] for r in self.con.execute("SELECT id FROM finding WHERE level = ? AND rowid IS NULL AND +rule = ? ORDER BY id", (level, rule))]
        return [r[0] for r in self.con.execute("SELECT id FROM finding WHERE level = ? AND rowid = ? AND +rule = ? ORDER BY id", (level, row, rule))]

    def on_number(self, rule, level, n):
        """The same by the row's own number in its file (an errors list made before the row of the file was kept names that number)."""
        if not self.has:
            return []
        return [r[0] for r in self.con.execute("SELECT id FROM finding WHERE level = ? AND rule = ? AND row_n = ? ORDER BY id", (level, rule, n))]

    def identity(self, number):
        """(what the error with this number is, its row's own number in the file), or (None, None) when the tree has no such number."""
        r = self.con.execute("SELECT rule, level, rowid, row_n FROM finding WHERE id = ?", (int(number),)).fetchone() if self.has else None
        if not r:
            return None, None
        return {"rule": r[0], "level": r[1], "row": r[2], "nth": self.on_row(r[0], r[1], r[2]).index(int(number))}, r[3]

    def number(self, ident):
        """The number the error with this identity has now, or None when the recording no longer holds it."""
        ids = self.on_row(ident.get("rule"), ident.get("level"), ident.get("row"))
        k = ident.get("nth") or 0
        return ids[k] if _whole(k) and 0 <= k < len(ids) else None


def _is_identity(x):
    return isinstance(x, dict) and isinstance(x.get("rule"), str) and isinstance(x.get("level"), str) and (x.get("row") is None or _whole(x.get("row")))


def with_identity(db, errors):
    """Each listed error also keeps what it is (see the words above): e["identity"] = {"rule", "level", "row", "nth"}, read from the tree
    by the error's number at the moment the list is made. A tree that cannot be read leaves the list as it is (its numbers then cannot be
    checked later, and the check says so)."""
    try:
        tree = _Numbers(db) if db and os.path.exists(db) else None
    except Exception:      # noqa: BLE001
        tree = None
    if tree is None:
        return errors
    try:
        for e in errors:
            ident, _n = tree.identity(e["finding"])
            if ident:
                e["identity"] = ident
    except Exception:      # noqa: BLE001 - the list is listed all the same
        pass
    finally:
        tree.close()
    return errors


def _records_path(where):
    """The file of the flows' records: from the application's services (the engine may not exist yet), from a store, or the path itself."""
    if isinstance(where, str):
        return where
    if not hasattr(where, "root") and getattr(where, "path", None):
        return where.path                                   # a store
    store = getattr(getattr(where, "agentic_engine", None), "store", None)
    return getattr(store, "path", None) or os.path.join(getattr(where, "root", "") or "", "db", "agentic.sqlite")


_NUMBER_WORDS = ('"finding"', '"head"', '"defect"', '"defects"', '"no_longer_found"')      # a record without any of these names keeps no error number


class _Follow:
    """One pass over the records of the analyses of one recording (see follow_renumbering)."""

    def __init__(self, upload_id, moved, gone, known, tree):
        self.uid, self.moved, self.gone, self.known, self.tree = str(upload_id), moved, gone, known, tree
        self.out = {"analyses": 0, "lists": 0, "entries": 0, "moved": 0, "elsewhere": 0, "no_longer_found": 0, "found_again": 0, "not_certain": 0, "by_rule": [],
                    "records_changed": 0}
        self.seen = {}              # of the analysis at hand: old number -> new number (None: no longer found), as its lists were followed
        self.item_rule = {}         # of the analysis at hand: item -> the detector's rule its built-in check filed under
        self.analysis = ""

    # ---- one number
    def _fits(self, got, row_n, e, rule):
        """Is the error with this number the one a list entry names? By the entry's level, its list's rule and its row."""
        if rule and got["rule"] != rule:
            return False
        if e.get("level") and got["level"] != e["level"]:
            return False
        return e.get("row") is None or e["row"] == got["row"] or e["row"] == row_n

    def entry(self, e, rule):
        """(the number a list entry has now, its identity, "ok" | "gone" | "unsure")."""
        old, t = int(e["finding"]), self.tree
        ident = e.get("identity") if _is_identity(e.get("identity")) else None
        if t is None:                                   # no tree to ask: the map alone
            return (None, ident, "gone") if old in self.gone else (self.moved.get(old, old), ident, "ok")
        if ident:                                       # what the error is decides, whatever the map says
            n = t.number(ident)
            return (n, ident, "ok") if n is not None else (None, ident, "gone")
        # a list made before the identity was kept: the map first, checked against what the entry itself says (its list's rule, its level, its row)
        if self.known and old in self.gone:
            return None, None, "gone"
        n = self.moved.get(old, old)
        got, row_n = t.identity(n)
        if got and self._fits(got, row_n, e, rule):
            return n, got, "ok"
        if rule and e.get("level") and e.get("row") is not None:
            ids = t.on_row(rule, e["level"], e["row"]) or t.on_number(rule, e["level"], e["row"])
            if len(ids) == 1:
                return ids[0], t.identity(ids[0])[0], "ok"
        return old, None, "unsure"

    def one(self, old):
        """(the new number of a number kept outside a list, "ok" | "gone" | "unsure")."""
        old = int(old)
        if old in self.seen:
            return (self.seen[old], "ok") if self.seen[old] is not None else (None, "gone")
        if not self.known:
            return old, "unsure"
        return (None, "gone") if old in self.gone else (self.moved.get(old, old), "ok")

    # ---- the records
    def errors_list(self, x, rule):
        """One errors list. An error that is no longer found is taken out and KEPT beside the list (no_longer_found.entries, with its place in
        the list), so that a later check that finds it again (by what it is) puts it back where it stood."""
        errs, kept, n_gone = x["errors"], [], 0
        was = x.get("no_longer_found") if isinstance(x.get("no_longer_found"), dict) else {}
        lost, back = [], []
        for e in was.get("entries") or []:
            n = self.tree.number(e["identity"]) if self.tree is not None and isinstance(e, dict) and _is_identity(e.get("identity")) else None
            if n is None:
                lost.append(e)
            else:
                e = dict(e)
                back.append((e.pop("stood_at", len(errs)), dict(e, finding=n)))
        self.out["lists"] += 1
        for at, e in enumerate(errs):
            old = int(e["finding"])
            new, ident, state = self.entry(e, rule)
            if state == "gone":
                self.seen[old] = None
                n_gone += 1
                lost.append(dict(e, stood_at=at))
                continue
            if state == "unsure":
                e["number_not_certain"] = True
                self.out["not_certain"] += 1
            else:
                e.pop("number_not_certain", None)
                self.seen[old] = new
                if ident:
                    e["identity"] = ident
            if new != old:
                e["finding"] = new
                self.out["moved"] += 1
            kept.append(e)
        for at, e in sorted(back, key=lambda b: b[0]):          # found again: back where it stood
            kept.insert(max(0, min(int(at) if _whole(at) else len(kept), len(kept))), e)
        x["errors"] = kept
        self.out["entries"] += len(kept)
        self.out["found_again"] += len(back)
        if n_gone or back:
            pattern = x.get("pattern") or x.get("item") or "of this list"
            if lost:
                x["no_longer_found"] = {"count": len(lost), "at": time.time(), "entries": lost,
                                        "sentence": no_longer_found_words(pattern, len(lost), coded=x.get("kind") == CODED_KIND)}
            else:
                x.pop("no_longer_found", None)
            if _whole(x.get("total")):
                x["total"] = max(len(kept), x["total"] - n_gone + len(back))
            self.out["no_longer_found"] += n_gone
            if n_gone:
                self.out["by_rule"].append({"analysis": self.analysis, "rule": pattern, "errors": n_gone})

    def head(self, x):
        """The result lines of a built-in check: [number, level, rule, ..., the row of the file]."""
        kept = []
        for row in x["head"]:
            if not (isinstance(row, list) and row and _whole(row[0])):
                kept.append(row)
                continue
            e = {"finding": row[0], "level": row[1] if len(row) > 1 else None, "row": row[8] if len(row) > 8 and row[8] is not None else (row[5] if len(row) > 5 else None)}
            new, _ident, state = self.entry(e, row[2] if len(row) > 2 and isinstance(row[2], str) else None)
            if state == "gone":
                self.seen.setdefault(int(row[0]), None)
                continue
            if state == "ok":
                self.seen.setdefault(int(row[0]), new)
            if new != row[0]:
                row[0] = new
                self.out["elsewhere"] += 1
            kept.append(row)
        x["head"] = kept

    def walk(self, x, ours):
        if isinstance(x, list):
            for y in x:
                self.walk(y, ours)
            return
        if not isinstance(x, dict):
            return
        if "upload_id" in x:
            ours = str(x["upload_id"]) == self.uid
        done = set()
        if ours:
            errs = x.get("errors")
            if isinstance(errs, list) and (errs or isinstance(x.get("no_longer_found"), dict)) and all(isinstance(e, dict) and _whole(e.get("finding")) for e in errs):
                rule = x.get("rule") if isinstance(x.get("rule"), str) else self.item_rule.get(str(x.get("item") or "").split("#")[0])
                self.errors_list(x, rule)
                done.update(("errors", "no_longer_found"))
            cols = x.get("columns")
            if isinstance(x.get("head"), list) and isinstance(cols, list) and cols[:3] == ["defect", "level", "rule"]:
                self.head(x)
                done.add("head")
            for k in ("finding", "defect"):
                if _whole(x.get(k)) and (k == "finding" or x.get("_is_step_input")):
                    new, state = self.one(x[k])
                    if state == "gone":
                        x[k + "_no_longer_found"], x[k] = x[k], None
                        self.out["elsewhere"] += 1
                    elif new != x[k]:
                        x[k] = new
                        self.out["elsewhere"] += 1
            if isinstance(x.get("defects"), list) and all(isinstance(d, list) and len(d) == 2 and _whole(d[0]) for d in x["defects"]):
                kept = []
                for d in x["defects"]:
                    new, state = self.one(d[0])
                    if state == "gone":
                        continue
                    if new != d[0]:
                        d[0] = new
                        self.out["elsewhere"] += 1
                    kept.append(d)
                x["defects"] = kept
                done.add("defects")
            if isinstance(x.get("same_command"), list):
                groups = []
                for g in x["same_command"]:
                    if isinstance(g, dict) and isinstance(g.get("listed"), list):
                        self.walk(g["listed"], ours)
                        g["listed"] = [i for i in g["listed"] if not (isinstance(i, dict) and "finding_no_longer_found" in i)]
                        if len({i.get("item") for i in g["listed"] if isinstance(i, dict)}) < 2:
                            continue                # one of the two errors is no longer found: the row is not listed twice any more
                    groups.append(g)
                x["same_command"] = groups
                done.add("same_command")
        for k, v in x.items():
            if k not in done and isinstance(v, (dict, list)):
                self.walk(v, ours)

    def run(self, con, run):
        """Every record of one analysis. -> True when one of its errors lists is of this recording."""
        self.seen, self.item_rule, self.analysis = {}, {}, run["name"] or ""
        lists_before = self.out["lists"]
        mine = str(run["up"] or "") == self.uid
        steps = [dict(r) for r in con.execute("SELECT id, key, input, output FROM step WHERE run = ? ORDER BY idx", (run["id"],))]
        for s_ in steps:
            # only a record whose text can hold an error number is read into memory (a data dictionary or a tree report cannot)
            s_["o"] = core.jload(s_["output"], None) if any(w in (s_["output"] or "") for w in _NUMBER_WORDS) else None
            s_["i"] = core.jload(s_["input"], None) if any(w in (s_["input"] or "") for w in _NUMBER_WORDS) else None
            o = s_["o"]
            if isinstance(o, dict) and o.get("kind") == "detector" and (o.get("head") or []) and isinstance(o["head"][0], list) and len(o["head"][0]) > 2 \
                    and (s_["key"] or "").startswith("f3:"):
                self.item_rule[base_item(parse_key(s_["key"])[0]).split("#")[0]] = o["head"][0][2]
        order = sorted(steps, key=lambda s_: 0 if (s_["key"] or "").endswith(":errors") else 1 if (s_["key"] or "").endswith("run") else 2)
        for s_ in order:                                # the lists first: what they find decides for the numbers kept beside them
            was = (json.dumps(s_["o"], sort_keys=True, default=str), json.dumps(s_["i"], sort_keys=True, default=str))
            old_fid = s_["o"].get("finding") if isinstance(s_["o"], dict) and _whole(s_["o"].get("finding")) else None
            self.walk(s_["o"], mine)
            if isinstance(s_["i"], dict):
                s_["i"]["_is_step_input"] = True
                self.walk(s_["i"], mine)
                s_["i"].pop("_is_step_input", None)
            key = s_["key"] or ""
            item = parse_key(key)[0] if key.startswith("f3:") else ""
            if "@" in item and error_of(item) is not None and mine:      # an older analysis: the error is in the names of its own steps
                new, state = self.one(error_of(item))
                if state == "ok" and new != error_of(item):
                    key = "f3:%s@%d:%s" % (base_item(item), new, parse_key(key)[1])
            now = (json.dumps(s_["o"], sort_keys=True, default=str), json.dumps(s_["i"], sort_keys=True, default=str))
            if now != was or key != s_["key"]:
                con.execute("UPDATE step SET output = ?, input = ?, key = ? WHERE id = ?", (
                    json.dumps(s_["o"], default=str) if now[0] != was[0] else s_["output"], json.dumps(s_["i"], default=str) if now[1] != was[1] else s_["input"], key, s_["id"]))
                self.out["records_changed"] += 1
            new_fid = s_["o"].get("finding") if isinstance(s_["o"], dict) else None
            if old_fid is not None and _whole(new_fid) and new_fid != old_fid:       # a card's title that names the error by its number
                for rv in con.execute("SELECT id, title FROM review WHERE step = ?", (s_["id"],)).fetchall():
                    if (rv["title"] or "").endswith("for defect %d" % old_fid):
                        con.execute("UPDATE review SET title = ? WHERE id = ?", (rv["title"][:-len(str(old_fid))] + str(new_fid), rv["id"]))
        ours_of = {s_["id"]: (str(s_["o"].get("upload_id")) == self.uid if isinstance(s_["o"], dict) and "upload_id" in s_["o"] else mine) for s_ in steps}
        said = no_longer_found_lines([{"key": s_["key"], "state": "done", "output": s_["o"]} for s_ in steps])
        for rv in con.execute("SELECT id, step, body, data, state FROM review WHERE run = ?", (run["id"],)).fetchall():
            data = core.jload(rv["data"], None) if any(w in (rv["data"] or "") for w in _NUMBER_WORDS) else None
            was = json.dumps(data, sort_keys=True, default=str)
            self.walk(data, ours_of.get(rv["step"], mine))
            body = rv["body"] or ""
            if rv["state"] == "open" and isinstance(data, dict) and data.get("errors_overview"):     # the errors gate, open now: it says what left the lists
                body = body.split("\n\n" + NO_LONGER_FOUND)[0] + ("\n\n" + "\n".join([NO_LONGER_FOUND] + ["- " + x for x in said]) if said else "")
            now = json.dumps(data, sort_keys=True, default=str)
            if now != was or body != (rv["body"] or ""):
                con.execute("UPDATE review SET data = ?, body = ? WHERE id = ?", (json.dumps(data, default=str) if now != was else rv["data"], body, rv["id"]))
                self.out["records_changed"] += 1
        return self.out["lists"] > lists_before


def followed_words(r):
    """What became of the analyses' error lists, as the end of the status sentence of the page that started the check: real counts only."""
    if not r.get("lists"):
        return "no analysis lists an error of this recording, so no error list had to follow"
    e = lambda n, one, many: "%s %s" % ("{:,}".format(n), one if n == 1 else many)      # noqa: E731
    out = "the error lists of %s of this recording were followed too: %s of their %s got a new number" % (
        e(r["analyses"], "analysis", "analyses"), "{:,}".format(r["moved"]), e(r["entries"] + r["no_longer_found"] - r.get("found_again", 0), "entry", "entries"))
    if r.get("no_longer_found"):
        out += "; %s no longer found and %s taken out of %s" % (e(r["no_longer_found"], "listed error is", "listed errors are"), "was" if r["no_longer_found"] == 1 else "were",
                                                               "its list" if r["no_longer_found"] == 1 else "their lists")
    if r.get("found_again"):
        out += "; %s found again and %s back in %s" % (e(r["found_again"], "error that had been taken out is", "errors that had been taken out are"),
                                                      "is" if r["found_again"] == 1 else "are", "its list" if r["found_again"] == 1 else "their lists")
    if r.get("not_certain"):
        out += "; for %s the number could not be checked against the recording" % e(r["not_certain"], "entry", "entries")
    return out


def follow_renumbering(services, upload_id, old_to_new, gone=(), db=None, dry=False):
    """The error numbers of one recording were given anew: every number the analyses (flows) of that recording keep follows, in ONE
    transaction on the flows' records (all of them follow, or none does and NumbersNotFollowed says why in one sentence).

    services: the application's services (the engine need not exist: the records file is opened by itself), a store, or the path of the
              records file.
    old_to_new: {old number: new number} for the errors whose number changed (an error that is not named kept its number). None, or
              {"_count": n} when there were too many to name: the numbers are then found again by what each error is, which needs `db`.
    gone:     the old numbers of the errors that are no longer found: each is taken out of the list it stood in, and the list says how
              many it lost (no_longer_found_words).
    db:       the recording's tree. With it every list entry is checked against the recording by what the error is (its rule, its level, its
              row in the level's file: never a time stamp), and an entry that kept no identity yet gets one.
    dry:      look only (nothing is written): what would change.
    -> {"analyses", "lists", "entries", "moved", "elsewhere", "no_longer_found", "found_again", "not_certain", "by_rule", "records_changed", "words"}:
       how many analyses list errors of this recording, in how many lists, how many entries they hold now, how many of them got a new
       number, how many numbers kept beside the lists were changed, how many listed errors are no longer found (by_rule says of which
       rule in which analysis), how many that had been taken out earlier are found again and back in their list (only with `db`), for how
       many entries the number could not be checked, and the words for the status sentence."""
    import sqlite3
    known = isinstance(old_to_new, dict) and "_count" not in old_to_new
    try:
        moved = {int(a): int(b) for a, b in old_to_new.items()} if known else {}
        gone = {int(x) for x in (gone or ())}
    except (TypeError, ValueError):
        raise NumbersNotFollowed("The error lists of the analyses were not followed: the list of the numbers that moved is not a list of whole numbers.") from None
    path = _records_path(services)
    tree = None
    try:
        if db and os.path.exists(db):
            tree = _Numbers(db)
            if tree.busy_since is not None:
                raise NumbersNotFollowed(BEING_NUMBERED % time.strftime("%Y-%m-%d %H:%M", time.localtime(tree.busy_since)))
        work = _Follow(upload_id, moved, gone, known, tree)
        if not path or not os.path.exists(path):
            return dict(work.out, words=followed_words(work.out))          # no analysis was ever started in this application
        if not known and tree is None:
            raise NumbersNotFollowed("The error lists of the analyses were not followed: too many error numbers moved to name each one, and the recording's "
                                     "tree could not be opened to find each listed error again by its rule and its row.")
        con = sqlite3.connect(path, timeout=60, isolation_level=None)
        con.row_factory = sqlite3.Row
        try:
            con.execute("PRAGMA busy_timeout=60000")
            if not {"run", "step", "review", "project"} <= {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}:
                return dict(work.out, words=followed_words(work.out))      # a records file without these tables holds no analysis
            con.execute("BEGIN" if dry else "BEGIN IMMEDIATE")
            try:
                runs = con.execute("SELECT r.id, p.upload_id AS up, p.name FROM run r LEFT JOIN project p ON p.id = r.project WHERE p.upload_id = ? "
                                   "OR r.id IN (SELECT DISTINCT run FROM step WHERE output LIKE ?) ORDER BY r.id", (str(upload_id), '%%"%s"%%' % upload_id)).fetchall()
                for run in runs:
                    if work.run(con, run):
                        work.out["analyses"] += 1
                con.execute("ROLLBACK" if dry else "COMMIT")
            except BaseException:
                try:
                    con.execute("ROLLBACK")
                except sqlite3.Error:
                    pass                # the transaction was already ended by the failure itself: nothing of it is kept
                raise
        finally:
            con.close()
    except NumbersNotFollowed:
        raise
    except Exception as e:      # noqa: BLE001 - said in words to the caller, with nothing changed (the transaction was rolled back)
        raise NumbersNotFollowed("The error lists of the analyses of this recording were not followed (%s: %s). Nothing was changed in them: the errors page of "
                                 "each analysis checks every number against the recording when it is opened and corrects it." % (type(e).__name__, e)) from e
    finally:
        if tree is not None:
            tree.close()
    return dict(work.out, words=followed_words(work.out))


def error_numbers_check(services, run_id):
    """The protection against a half-done numbering (the recording's errors were numbered anew and the analysis's lists did not follow, for
    any reason): every listed error of one analysis is compared with the recording by what it is (its rule, its level, its row in the
    level's file); a number that is not that error any more is replaced by the number the error has now, an error that is no longer
    found is taken out and counted. Nothing is written when every number is right.
    An error that had been taken out and is found again is put back. While a check of the recording is under way (the tree says so itself,
    nvme_hier/rules.numbering_begins) nothing is compared and nothing is changed: "waits" and the sentence say it.
    -> {"checked": entries looked at, "corrected", "no_longer_found", "found_again", "not_certain", "sentence": "" when nothing was wrong, "waits"}."""
    import sqlite3
    path = _records_path(services)
    out = {"checked": 0, "corrected": 0, "no_longer_found": 0, "found_again": 0, "not_certain": 0, "sentence": "", "waits": ""}
    if not path or not os.path.exists(path):
        return out
    con = sqlite3.connect("file:%s?mode=ro" % path, uri=True, timeout=30)
    try:
        ups = {r[0] for r in con.execute("SELECT p.upload_id FROM run r JOIN project p ON p.id = r.project WHERE r.id = ?", (int(run_id),)) if r[0]}
        for (o,) in con.execute("SELECT output FROM step WHERE run = ? AND key LIKE 'f3:%:errors'", (int(run_id),)):
            o = core.jload(o, None)
            if isinstance(o, dict) and o.get("upload_id") and o.get("errors"):
                ups.add(str(o["upload_id"]))
    except sqlite3.OperationalError:
        return out
    finally:
        con.close()
    for up in sorted(ups):
        db = _tree_db(up)
        if not db:
            continue                    # no tree to compare with (the recording is not loaded now): nothing can be said
        try:
            look = follow_renumbering(services, up, None, db=db, dry=True)
        except NumbersNotFollowed as e:
            if not str(e).startswith(BEING_NUMBERED.split("%s")[0]):
                raise
            out["waits"] = out["sentence"] = str(e)     # a check of the recording is under way: nothing is compared, nothing is changed, and it is said
            return out
        out["checked"] += look["entries"] + look["no_longer_found"] - look["found_again"]
        out["not_certain"] += look["not_certain"]
        if look["moved"] or look["no_longer_found"] or look["elsewhere"] or look["found_again"]:
            done = follow_renumbering(services, up, None, db=db)
            out["corrected"] += done["moved"]
            out["no_longer_found"] += done["no_longer_found"]
            out["found_again"] += done["found_again"]
    e = lambda n, one, many: "%s %s" % ("{:,}".format(n), one if n == 1 else many)      # noqa: E731
    if out["corrected"] or out["no_longer_found"] or out["found_again"]:
        parts = []
        if out["found_again"]:
            parts.append("%s found in the recording again and %s back in the list" % (
                e(out["found_again"], "error that had been taken out is", "errors that had been taken out are"), "is" if out["found_again"] == 1 else "are"))
        if out["corrected"]:
            parts.append("%s corrected: each listed error was found again by its rule, its file and its row, and its link opens that error"
                         % e(out["corrected"], "error number of these lists was", "error numbers of these lists were"))
        if out["no_longer_found"]:
            parts.append("%s no longer found in the recording and %s taken out" % (e(out["no_longer_found"], "listed error is", "listed errors are"),
                                                                                   "was" if out["no_longer_found"] == 1 else "were"))
        out["sentence"] = "The errors of this recording were numbered anew after these lists were made, and the lists had not followed. Now " + "; ".join(parts) + "."
    if out["not_certain"]:
        out["sentence"] = (out["sentence"] + " " if out["sentence"] else "") + (
            "For %s the number could not be checked against the recording (the list was made before each error's rule and row were kept with it): "
            "open such an error from the recording's own findings to be sure it is the one meant." % e(out["not_certain"], "listed error", "listed errors"))
    return out


def other_errors_store(engine, run_id):
    """The file that keeps the errors of the CSV files that are not part of the tree, for one run (agentic/other_errors.py says why a file of its own)."""
    return other_errors.store_path(engine.runner.sandbox_root, run_id)


def _errors_of_a_file(ic, res):
    """The rows a rule found in a CSV file that is not part of the tree become errors of the analysis (owner, 2026-11-14), kept by
    agentic/other_errors.py with their own kind. The step's "errors" list stays empty on purpose: that list is the tree's (a finding and an
    upload), and every later step and page that reads it would take a row of another file for a finding of the tree. These are under
    "other_errors". A result that does not say which rows of the file it found is refused in plain words: nothing is listed."""
    from . import procedures as PR
    r = family3._rule(ic)
    # kept under the item without its round: a later round of the same rule replaces its errors instead of listing the rows a second time
    item = "%s/%s/%s" % split_item(ic.item)[:3]
    base = {"errors": [], "kind": other_errors.KIND, "other_errors": [], "item": item, "upload_id": None, "pattern": r["name"], "total": 0,
            "page": "/other-error?run=%d" % ic.run["id"], "cannot": other_errors.CANNOT_DO}
    if not (res.get("rows") or 0):
        return core.Result(base, skip="the pattern found no error in this file")
    proc = PR.procedure_of(r) or {}
    _db, _up, paths = family3.recording(ic)
    files = [x["file"] for x in proc.get("source_data") or [] if x["file"] != PR.TREE]
    db = other_errors_store(ic.engine, ic.run["id"])
    try:
        if any(f not in paths for f in files):
            raise other_errors.Refused("The analysis no longer has %s, so the rows the rule '%s' found cannot be read again. No error is listed for it."
                                       % (", ".join(f for f in files if f not in paths), r["name"]))
        got = other_errors.ingest(db, item, r["name"], res["output_csv"], {f: paths[f] for f in files},
                                  progress=lambda pct, t0, what: ic.progress(core.progress_text(pct, t0, what=what)))
    except other_errors.Refused as e:
        return core.Result(dict(base, refused=str(e)), producer="the code")
    return core.Result(dict(base, other_errors=other_errors.list_errors(db, item, limit=other_errors.HEAD), total=got["total"], repeated=got["repeated"],
                            files=got["files"], store=db), producer="the code")


def _errors_done(ctx):
    """The gate before the report: the admin works through the errors on the errors page and says when it is done."""
    v = ctx.engine.view(ctx.run["id"])
    if getattr(ctx.engine, "store", None) is not None:
        try:
            remove_deleted_items_errors(_tree_db(tree_of(ctx.engine, ctx.run, ctx.project)))
        except Exception:      # noqa: BLE001 - the gate is shown all the same
            pass
    gone = {item_key(x["section"], x["level"], x["id"]) for x in family3.deleted_items()} if getattr(ctx.engine, "store", None) is not None else set()
    lists = [s_ for s_ in v["steps"] if s_["key"].endswith(":errors") and (s_.get("output") or {}).get("errors")
             and not ((s_["output"].get("kind") == CODED_KIND) and item_key(*split_item(s_["key"][3:-len(":errors")])[:3]) in gone)]
    n = sum(len(s_["output"]["errors"]) for s_ in lists)
    body = ["**Admin %s, the errors.** %d pattern%s found %d error%s in this recording. Each error is taken through **stage 1** (the isolation of the defect), "
            "**stage 2** (the procedural graph: its cause and its solution) and its **test case** on its own page: open the errors page." % (
                _admin(ctx.project), len(lists), "" if len(lists) == 1 else "s", n, "" if n == 1 else "s"), "",
            "Page 3 shows where each error stands. Press **Done: write the report** when you have finished the ones you want; the report says which are done."]
    # the errors of CSV files that are not part of the tree are counted apart: they never add to the tree's patterns or errors
    others = [s_ for s_ in v["steps"] if s_["key"].endswith(":errors") and (s_.get("output") or {}).get("kind") == other_errors.KIND
              and ((s_["output"].get("total") or 0) or s_["output"].get("refused"))]
    n2 = sum(s_["output"].get("total") or 0 for s_ in others)
    if others:
        body += ["", "**Errors in CSV files that are not part of the tree:** %d rule%s found %s row%s. Each has a page of its own with the row, the rows around it and "
                     "the isolation of the defect. %s" % (len(others), "" if len(others) == 1 else "s", "{:,}".format(n2), "" if n2 == 1 else "s", other_errors.CANNOT_DO)]
        body += ["- *%s*: %s" % (s_["output"].get("pattern"), s_["output"].get("refused") or "%s error%s" % (
            "{:,}".format(s_["output"].get("total") or 0), "" if s_["output"].get("total") == 1 else "s")) for s_ in others]
    refused = [s_ for s_ in v["steps"] if s_["key"].endswith(":errors") and (s_.get("output") or {}).get("kind") == CODED_KIND and s_["output"].get("refused")]
    if refused:
        own = all((s_["output"].get("found_by") or "admin") == "admin" for s_ in refused)      # a rule of the application's rule set is not "your own"
        body += ["", "**Rules of your own whose rows could not be listed as errors:**" if own else "**Rules whose rows could not be listed as errors:**"] + [
            "- *%s*: %s" % (s_["output"].get("pattern"), s_["output"]["refused"]) for s_ in refused]
    waiting = waiting_patterns(v["steps"])
    if waiting:
        body += ["", "**Not listed yet:**"] + ["- " + w["sentence"] for w in waiting]
    # (2026-11-15) a rule that listed nothing says so in a sentence (it found no row, or it cannot be checked on this recording); and a command
    # that more than one rule lists is named, so that it is not isolated twice without the admin knowing. Only when there is something to say.
    nothing = [s_["output"]["nothing"] for k_, s_ in latest_error_lists(v["steps"]).items() if s_["output"].get("nothing") and k_ not in gone]
    if nothing:
        body += ["", "**Rules that listed no error:**"] + ["- " + x for x in nothing]
    twice = same_command([s_ for s_ in v["steps"] if not (s_["key"].endswith(":errors") and (s_.get("output") or {}).get("kind") == CODED_KIND
                                                           and item_key(*split_item(s_["key"][3:-len(":errors")])[:3]) in gone)])
    body += same_command_lines(twice)
    # (2026-11-15) the errors a new check of the recording no longer finds were taken out of their lists (follow_renumbering): said here, one
    # sentence a rule. This block stays the LAST of the card: follow_renumbering writes it anew on a gate that is open while a check runs
    lost = no_longer_found_lines(v["steps"], skip=gone)
    if lost:
        body += ["", NO_LONGER_FOUND] + ["- " + x for x in lost]
    return core.Result({"patterns": len(lists), "errors": n, "other_patterns": len(others), "other_errors": n2, "listed_nothing": len(nothing), "same_command": len(twice)},
                       review={"title": "The errors: stage 1 and stage 2 on the errors page", "body": "\n".join(body),
                               "data": {"errors_overview": True, "other_errors": {"rules": len(others), "errors": n2, "page": "/other-error?run=%d" % ctx.run["id"]},
                                        "listed_nothing": nothing, "same_command": twice[:200]}})


def _graph_view_lines(view):
    """What the procedural graph holds for a defect, in words (the card draws it as an outline you can open)."""
    if not view or not view.get("causes"):
        return ["**First finding of this defect in the procedural graph:** nothing is stored for it yet.", ""]
    cs = view["causes"]
    nsol = sum(len(c["solutions"]) for c in cs)
    return ["**Already in the procedural graph for this defect:** %d cause%s, %d solution%s; seen %d time%s (first %s, last %s) on %s." % (
        len(cs), "" if len(cs) == 1 else "s", nsol, "" if nsol == 1 else "s", view.get("seen", 0), "" if view.get("seen") == 1 else "s",
        view.get("first_seen") or "-", view.get("last_seen") or "-", ", ".join(view.get("devices") or []) or "no device named"), "",
        "Open a cause below to see its solutions: the error sequence (it becomes the test), the optimized sequence (it solves the problem), "
        "their versions, test files and your earlier judgements. " + (view.get("order") or ""), ""]


def _cause(ic):
    """Stage 2, the procedural graph: is this defect stored, with which causes? The admin names the cause of this occurrence."""
    iso = ic.output_of("isolate")
    did = ic.input.get("defect_id")
    if not iso.get("isolation") or did is None:
        return core.Result({}, skip="no isolated defect with a confirmed name (stage 1 was skipped or made before 2026-11-11)")
    view = call_app(ic.engine, "GET", "/api/dg/defects/%d" % int(did))
    i = iso["isolation"]
    body = ["**Admin %s, need review.** Stage 2, the procedural graph. The defect: **%s**%s." % (
        _admin(ic.project), view["name"], " (new: stored just now under the name you confirmed)" if not view.get("causes") and not view.get("seen") else ""), ""]
    body += _graph_view_lines(view)
    body += ["**The isolation proposes this cause:** %s: %s" % (i.get("cause_side") or "other", i.get("cause_header") or "not named"), "",
             "Choose the cause of this occurrence below: one of the stored causes, or a new one (its side and its one line). Nothing is chosen for you. "
             "Approving stores this occurrence under that cause (one count for it, with this device and firmware); then the cause's solutions follow."]
    return core.Result({"defect_id": int(did), "defect_name": view["name"], "causes": len(view.get("causes") or [])}, producer="the procedural graph",
                       review={"title": "Stage 2 · procedural graph: " + view["name"], "body": "\n".join(body),
                               "data": {"graph": view, "proposed_cause": {"side": i.get("cause_side") or "other", "header": i.get("cause_header") or ""},
                                        "sides": SIDES}})


def _solution(ic):
    """Stage 2, the solution of the cause: the stored ones ranked by the admin's judgements (the signals change only this ranking), or,
    for a cause with none, the first one: the error sequence from this recording and the optimized sequence (the model proposes it, the
    admin edits it)."""
    iso = ic.output_of("isolate")
    cid, did = ic.input.get("cause_id"), ic.input.get("defect_id")
    if cid is None or did is None:
        return core.Result({}, skip="no cause was named (stage 2 was skipped)")
    view = call_app(ic.engine, "GET", "/api/dg/defects/%d" % int(did))
    cause = next((c for c in view.get("causes") or [] if c["id"] == int(cid)), None)
    if cause is None:
        raise RuntimeError("the cause %s is not under the defect %s" % (cid, did))
    own = iso.get("sequence") or []
    did_lines = ic.input.get("did") or []
    body = ["**Admin %s, need review.** Stage 2, the solution. Defect **%s** · cause **%s** (%s), %s." % (
        _admin(ic.project), view["name"], cause["header"], cause["side_words"], cause["chosen_words"]), ""]
    if did_lines:
        body += ["**What your last signal did:** " + "; ".join(did_lines) + ".", ""]
    data = {"cause": {k: cause[k] for k in ("id", "side", "side_words", "header", "chosen_words")}, "defect": {"id": view["id"], "name": view["name"]},
            "sequence": own, "upload_id": iso.get("upload_id"), "finding": iso.get("finding")}
    if cause["solutions"]:
        body += ["**Stored solutions for this cause, best judged first** (%d). Open one to see its error sequence, its optimized sequence, its versions, "
                 "test file and earlier judgements. Choose the one you judge and give your signal: it changes only how the solutions are ranked "
                 "the next time this defect and cause come back. Or store this recording's sequence as a new solution." % len(cause["solutions"]), ""]
        data.update(solutions=cause["solutions"], judge=True)
    else:
        ic.progress("stage 2: the model proposes the optimized sequence for this cause")
        prop = call_app(ic.engine, "POST", "/api/dg/optimized", {"upload_id": iso.get("upload_id"), "finding_id": iso.get("finding"), "isolation": iso.get("isolation"),
                                                                   "cause": {"side": cause["side"], "header": cause["header"]}, "error_seq": own,
                                                                   "standin": _standin(ic.engine)})
        body += ["**First solution for this cause.** It is stored as you leave it below:", "",
                 "- **the error sequence**: the commands of this recording that recreate the error (untick a step it does not need; the error's own step stays). It becomes the test case.",
                 "- **the optimized sequence**: the solution to the problem for this cause. %s Edit it; one action per line." % (
                     "The model proposed it (%s): %s" % (prop.get("producer"), prop.get("note")) if not prop.get("standin") else prop.get("note")), ""]
        data.update(first=True, optimized=prop.get("lines") or [], optimized_note=prop.get("note"), optimized_by=prop.get("producer"))
    return core.Result({"cause_id": int(cid), "defect_id": int(did), "solutions": len(cause["solutions"])}, producer="the procedural graph",
                       review={"title": "Stage 2 · the solution for: " + cause["header"], "body": "\n".join(body), "data": data})


LOOK_AGAIN = "look again:"
LEVEL_WORDS = {"nvme_transaction": "NVMe transactions", "split": "split transactions", "link": "link transactions", "packets": "packets"}


def _window_lines(w):
    """The isolation window in words: the numbers and where they come from, what it holds per level, and the commands from earlier in
    the recording that the failing command depends on (with their reasons)."""
    if not w:
        return []
    c = w.get("counts") or {}
    out = ["**The window:** %d command%s above the defect and %d below (%s). It holds %s command%s%s." % (
        w.get("n", 0), "" if w.get("n") == 1 else "s", w.get("m", 0), w.get("source") or "", "{:,}".format(c.get("commands", 0)), "" if c.get("commands") == 1 else "s",
        "".join(", %s %s under them" % ("{:,}".format(c[lv]), LEVEL_WORDS[lv]) for lv in LEVEL_WORDS if c.get(lv))), ""]
    h = w.get("history") or {}
    rows = h.get("rows") or []
    if rows:
        out += ["**From earlier in the recording** (%d command%s the failing command depends on, found by shared blocks, features and queues, not by time):" % (len(rows), "" if len(rows) == 1 else "s"), "",
                "| row | command | why it is kept |", "|---|---|---|"]
        out += ["| %s | %s | %s |" % (x.get("n") or x.get("rowid"), (x.get("summary") or "").replace("|", "/")[:120], "; ".join(x.get("why") or []).replace("|", "/")[:300]) for x in rows[:40]]
        out.append("")
    elif h.get("note"):
        out += ["**From earlier in the recording:** %s." % h["note"], ""]
    else:
        out += ["**From earlier in the recording:** nothing the failing command depends on was found before the window.", ""]
    if h.get("uncovered"):
        out += ["Blocks of the failing command's range with no earlier write in the recording (their content at the time is unknown; the test writes a known pattern there): %s." % (
            "; ".join("namespace %s blocks %s to %s" % (u["nsid"], u["first"], u["last"]) for u in h["uncovered"][:6])), ""]
    if h.get("cutoff"):
        out += ["The latest %s (row %s) is where the data history starts: blocks written before it cannot matter." % (h["cutoff"]["command"], h["cutoff"]["rowid"]), ""]
    return out


def _graph_lines(r, choice, fresh, rejected, change, came_from=lambda st: ""):
    """What the procedural graph says about this failure, for the admin's review. Every weight is shown as the judgements behind it
    ("not yet judged", "judged correct 3 of 4 times"), never as a bare number (owner, 2026-11-10: "do not start with a default value of 67")."""
    paths = (r.get("graph") or {}).get("paths") or []
    out = []
    if change:
        out += ["**Your last signal changed the graph:** " + "; ".join(change) + ".", ""]
    if choice and choice.get("from_family"):
        out += ["**Procedural graph: known from %s.** The graph proposes that failure's procedure version %s (%s). Regression test: %s. A signal here stores it for this failure too." % (
            choice["from_family"], choice["version"], choice["weight_text"], os.path.basename(choice["test_path"]) if choice.get("test_path") else "none yet"), ""]
    elif choice:
        out += ["**Procedural graph: this failure is known.** The graph chose stored procedure version %s (%s; %s). "
                "This recording's own new proposal has %d steps and is used only if you reject the stored ones." % (
                    choice["version"], choice["weight_text"], choice["ordered_by"], len(fresh)), ""]
    elif paths:
        out += ["**Procedural graph: this failure is known, but no stored procedure is left to try** (%s). This is a new proposal from this recording." % (
            "you rejected the best-weighted ones" if rejected else "each one is judged wrong more often than right"), ""]
    else:
        out += ["**Procedural graph: first time for this failure.** Nothing is stored for it yet; this is a new proposal from this recording.", ""]
    if paths:
        out += ["| procedure | where it came from | your judgements | regression test on file |", "|---|---|---|---|"]
        for p in paths:
            out.append("| version %s%s | %s | %s | %s |" % (
                p["version"], " (chosen)" if choice and p["procedure_id"] == choice["procedure_id"] else "", (came_from(p.get("stored")) or "").replace("|", "/"),
                p["weight_text"], ("%s (%s)" % (os.path.basename(p["test_path"]), p.get("test_state"))) if p.get("test_path") else "not yet"))
        out.append("")
    return out


def _outcomes(ic):
    iso = ic.output_of("isolate")
    seq = ic.input.get("sequence") or iso.get("sequence")
    up, fid = iso.get("upload_id"), iso.get("finding")
    if not seq or fid is None:
        return core.Result({}, skip="no isolated sequence (stage 1 was skipped)")
    ic.progress("stage 2: the expected outcomes from the defect onward")
    r = call_app(ic.engine, "POST", "/api/isolate/%s/%d/testcase" % (up, int(fid)), {"sequence": seq, "name": _admin(ic.project), "standin": _standin(ic.engine)})
    outs = r.get("expected_outcomes") or []
    lim = r.get("limit") or {}
    change = ic.input.get("graph_change")
    body = ([("**Your signal changed the graph:** " + "; ".join(change) + "."), ""] if change else []) + [
            "**Admin %s, need review.** Stage 2: what a correct drive must answer, from the defect (step %s) onward. "
            "Check every line; approving means you verified them, and the test file is written from them." % (_admin(ic.project), r.get("fault_step")), "",
            "| step | command | expected status | time limit | the check | basis |", "|---|---|---|---|---|---|"]
    body += ["| %s | %s | %s | %s | %s | %s |" % (o["step"], o["command"], o.get("status"), o.get("timing_text"), (o.get("check") or "").replace("|", "/"),
                                                 (o.get("basis") or "").replace("|", "/")[:160]) for o in outs]
    body += ["", "Time limit used: %s (%s)." % (lim.get("text"), lim.get("source"))]
    return core.Result({"outcomes": outs, "sequence": r.get("sequence"), "fault_step": r.get("fault_step"), "upload_id": up, "finding": fid,
                        "procedure_id": ic.input.get("procedure_id"), "signal": ic.input.get("signal")},
                       producer=r.get("producer"),
                       review={"title": "Stage 2: expected outcomes of defect %s" % fid, "body": "\n".join(body),
                               "data": {"outcomes": outs, "fault_step": r.get("fault_step")}})


def _testcase(ic):
    """Stage 2's test file (owner, 2026-11-10): the model writes the plan from the multi-level window of the defect, the code checks it (every
    step against the recording, the plan's checks, the four runs on the simulated drive), renders it beside the fixed replay library, and the
    admin approves it. Compiled and run once here, where there is no drive: it must skip cleanly."""
    oc = ic.output_of("outcomes")
    outs = ic.input.get("outcomes")
    if not outs:
        return core.Result({}, skip="no verified outcomes (stage 2 was skipped)")
    iso = ic.output_of("isolate")
    hint = "; ".join(c for c in ic.input.get("comments") or [] if c)
    ic.progress("the model writes the test plan from the window; the code checks it and runs it on the simulated drive")
    body = {"sequence": oc["sequence"], "expected_outcomes": outs, "verified": True, "procedure_id": oc.get("procedure_id"),
            "scenario_name": iso.get("scenario_name"), "name": ic.input.get("verified_by") or _admin(ic.project), "author": "model", "hint": hint}
    if _standin(ic.engine):
        body["standin"] = True
    for k in ("deallocate_range", "known_rate"):
        if ic.input.get(k):
            body[k] = ic.input[k]
    r = call_app(ic.engine, "POST", "/api/isolate/%s/%d/testcase" % (oc["upload_id"], int(oc["finding"])), body)
    path = r["path"]
    py_compile.compile(path, doraise=True)
    check = {"compiled": True}
    # run once here, where the drive is absent: a correct test file skips cleanly (it never fails or errors without a drive)
    env = {k: v for k, v in os.environ.items() if not k.startswith("NVME_")}
    env["NVME_DEV"] = "/dev/nvme-flow-check-absent"
    env["PYTHONUTF8"] = "1"                  # the test and what it prints are UTF-8 on every system (Windows would use cp1252)
    p = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", path], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180, cwd=os.path.dirname(path), env=env)
    last = [x for x in (p.stdout or "").strip().splitlines() if x.strip()]
    if "No module named pytest" in (p.stderr or ""):
        check["pytest"] = "pytest is not installed for %s: the file was only compiled" % sys.executable
    else:
        check.update({"pytest_exit": p.returncode, "pytest": last[-1] if last else (p.stderr or "")[-200:]})
        if p.returncode not in (0, 5) or not last or "error" in last[-1].lower() or "failed" in last[-1].lower():
            detail = [x for x in last if x.startswith("E ") or "Error" in x][:12]
            raise RuntimeError("the generated test file %s does not run cleanly without the drive: %s\n%s" % (
                path, last[-1] if last else (p.stderr or "")[-300:], "\n".join(detail)))
    out = {"path": path, "name": r.get("name"), "version": r.get("version"), "steps": len(r.get("steps") or []), **check,
           "two_sided": r.get("two_sided"), "model": r.get("model"), "plan_checks": r.get("checks"), "library": r.get("library")}
    plan = r.get("plan") or {}
    return core.Result(out, producer=(r.get("model") or {}).get("producer"),
                       review={"title": "Stage 2: the test file for defect %s" % oc["finding"], "body": "\n".join(_testfile_lines(r, plan, check)),
                               "data": {"testfile": {"path": path, "name": r.get("name"), "version": r.get("version"), "text": r.get("text") or "",
                                                     "two_sided": r.get("two_sided"), "model": r.get("model"), "checks": r.get("checks"),
                                                     "deallocate_range": plan.get("deallocate_range"), "known_rate": (plan.get("repeat") or {}).get("known"),
                                                     "oracle": plan.get("oracle_fault"), "library": r.get("library")}}})


def _testfile_lines(r, plan, check):
    m = r.get("model") or {}
    two = r.get("two_sided") or {}
    lines = ["**Admin, need review.** The test file `%s` (version %s) for this defect." % (r.get("name"), r.get("version")), ""]
    if m.get("used") == "model":
        lines += ["**Written by the model** (%s) from the window of %s commands (%s above, %s below, and the earlier commands the defect depends on), with every lower level under them. "
                  "Every parameter is copied from the recording by the code; the model only chose the rows and said why." % (
                      m.get("producer"), (m.get("window") or {}).get("commands"), (m.get("window") or {}).get("n"), (m.get("window") or {}).get("m")), "",
                  "**The model's analysis:** " + (m.get("analysis") or ""), ""]
        if m.get("setup_note"):
            lines += ["**The drive's state before the replay (the model):** " + m["setup_note"], ""]
        for n in m.get("notes") or []:
            lines.append("- " + n)
        if m.get("notes"):
            lines.append("")
        if len(m.get("rounds") or []) > 1:
            lines += ["The model needed %d tries: %s." % (len(m["rounds"]), "; ".join("try %d: %s" % (x["round"], "; ".join(x.get("problems") or []) or "passed") for x in m["rounds"])), ""]
    else:
        lines += ["**Written by the code from stage 1's sequence:** %s" % (m.get("analysis") or "no model was asked."), ""]
    o = plan.get("oracle_fault") or {}
    lines += ["**What shows the defect again:** %s." % o.get("words", ""), ""]
    lines += ["**The code's checks:** every step matches its own row of the recording; the plan's checks passed; compiled; run here without a drive: %s." % (check.get("pytest") or "compiled only"), ""]
    if two.get("runs"):
        lines += ["**On the simulated drive** (the test's mechanics only, never the real drive): %s" % ("passed" if two.get("ok") else "FAILED"), "",
                  "| simulated drive | EXPECT | wanted | got |", "|---|---|---|---|"] + ["| %s | %s | %s | %s |" % (x["drive"], x["expect"], x["wanted"], x["got"]) for x in two["runs"]] + [""]
    elif two.get("words"):
        lines += ["**On the simulated drive:** %s" % two["words"], ""]
    if plan.get("deallocate_range"):
        d = plan["deallocate_range"]
        lines += ["**Deallocate check:** blocks %s to %s with %s guard blocks on each side (%s)." % (d["slba"], d["slba"] + d["blocks"] - 1, d.get("guard"), d.get("why") or ""), ""]
    known = (plan.get("repeat") or {}).get("known")
    lines += ["**Runs:** %s" % ("EXPECT=fixed needs the clean runs the old firmware's rate requires: it reproduced %s of %s times." % (known["k"], known["n"]) if known else
                                 "the old firmware's reproduction rate is not measured yet."), "",
              "Approving makes this file the regression test of this kind of defect (it is recorded with your name and the file's fingerprint). "
              "**Write it again** sends your comment to the model as a hint."]
    return lines


def _graph_of(engine, iso):
    """The defect's part of the procedural graph as it stands now (for the report)."""
    if iso.get("finding") is None:
        return None
    try:
        g = call_app(engine, "GET", "/api/isolate/%s/%d/graph" % (iso["upload_id"], int(iso["finding"]))).get("graph") or {}
    except RuntimeError:
        return None
    return {"nodes": [{k: n[k] for k in ("kind", "label", "weight_text", "n", "status")} for n in g.get("nodes") or []],
            "edges": [{k: e[k] for k in ("kind", "from", "to", "weight_text", "n", "status")} for e in g.get("edges") or []]}


def _summary(ic):
    iso, oc = ic.output_of("isolate"), ic.output_of("outcomes")
    if iso.get("finding") is None:
        return core.Result({}, skip="no isolated defect")
    tc = ic.engine.store.one("SELECT input FROM step WHERE run=? AND key=?", (ic.run["id"], ic.prefix + "testcase")) or {}
    verified = (core.jload(tc.get("input"), {}) or {}).get("outcomes") or oc.get("outcomes") or []
    fault = next((o for o in verified if o.get("step") == oc.get("fault_step")), None)
    expected = {"status": (fault or {}).get("status"), "description": (iso.get("expected_outcome") or {}).get("description"),
                "check": (fault or {}).get("check")} if fault else iso.get("expected_outcome")
    r = call_app(ic.engine, "POST", "/api/isolate/%s/%d/summary" % (iso["upload_id"], int(iso["finding"])),
                 {"reason": iso.get("reason"), "sequence": oc.get("sequence") or iso.get("sequence"), "expected_outcome": expected,
                  "name": _admin(ic.project), "standin": _standin(ic.engine)})
    return core.Result({"lines": r.get("lines"), "text": r.get("text")}, producer=r.get("producer"))


# ---------------------------------------------------------------------------------------------- the admin's decisions
def on_reject(engine, run, step, data, admin):
    """A rejected review. A data dictionary of Family 1 takes back what its run kept for later runs (family1.on_reject,
    when Family 1 has one); every other review has nothing to take back. Returns what Family 1 returns, else 0."""
    fn = getattr(family1, "on_reject", None)
    if fn and step.get("family") == "1" and step["key"] not in ("f1_last", admin_ask.GATE):
        return fn(engine, run, step, data, admin)
    return 0


def on_approve(engine, run, step, data, admin):
    key = step["key"]
    edits = data.get("edits") or {}
    if key == admin_ask.GATE:
        return admin_ask.before_stage_2(engine, run, step, admin, edits)      # stage 2 or not: the admin's choice; see admin_ask
    if step.get("family") == "1" and key != "f1_last":
        return family1.on_approve(engine, run, step, data, admin)      # a data dictionary is stored
    if step.get("family") == "2":
        return family2.on_approve(engine, run, step, data, admin)      # a strategy is stored, or the one used last time reused
    if key == "f1_last":
        reuse = set(data.get("reuse") or [])
        for name in reuse:
            for k in ("explore", "ground", "manager"):
                engine.store.exec("UPDATE step SET state='skipped', note=? WHERE run=? AND key=?",
                                  ("the dictionary approved before was reused (approved again by %s)" % admin, run["id"], "%s:%s" % (k, name)))
        return
    if key == "f3_plan":
        plan, sel = _plan_steps(engine, data, admin, run=run)
        # new steps go after the items this run already holds (an analysis opened again), else right after the plan
        last = engine.store.one("SELECT MAX(idx) AS i FROM step WHERE run=? AND key LIKE 'f3:%' AND key NOT LIKE '%@%'", (run["id"],))["i"]
        engine.insert_steps(run["id"], max(step["idx"], last or 0), plan)
        engine.store.exec("UPDATE step SET output=? WHERE id=?", (json.dumps(dict(core.jload(step["output"], {}) or {}, chosen=sel, steps_added=len(plan), kept=data.get("kept") or {})), step["id"]))
        forget_added_items(engine, step["id"])      # the items added from page 3 were on this card: the admin's approval decided them
        return
    if key.startswith("f3:"):
        item, sub = parse_key(key)
        sec, lvl, rid, _rnd = split_item(item)
        prefix = "f3:%s:" % item
        if sub in ("write", "code", "req"):
            run2 = dict(run, params=json.dumps({"_kind": "rule_draft" if sub == "write" else "rule_code", "section": sec, "level": lvl, "id": rid}))
            if sub == "write":
                family3.on_approve(engine, run2, dict(step, key=sub), data, admin)
            else:                               # Family 4: the requirements are complete, or the final code becomes the verified code
                family4.on_approve(engine, run2, dict(step, key=sub, full_key=key), data, admin)
        elif sub == "result":
            out = core.jload(step["output"], {}) or {}
            run_out = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], prefix + "run")) or {}).get("output"), {}) or {}
            r = family3.load_rule(sec, lvl, rid)
            if r is not None:
                r["last_run"] = {"run": run["id"], "at": time.time(), "upload_id": run_out.get("upload_id"), "rows": out.get("rows")}
                family3.save_rule(r)
            if family3.goes_to_stages(sec) and not engine.store.one("SELECT id FROM step WHERE run=? AND key=?", (run["id"], prefix + "errors")):
                head = run_out.get("head") or []
                ids = [x[0] for x in head]
                chosen = edits.get("defect") if isinstance(edits, dict) else None
                if ids and chosen in (None, ""):
                    # nothing is chosen for the admin (owner, 2026-11-11)
                    raise ValueError("choose the defect to take to stage 1 and stage 2, or choose “none”: no defect is chosen for you")
                if chosen == "none":
                    engine.set_input(run["id"], prefix + "isolate", defect="none")
                elif chosen not in (None, ""):
                    try:
                        chosen = int(chosen)
                    except (TypeError, ValueError, OverflowError):
                        raise ValueError("the defect must be one of the list")
                    if chosen not in ids:
                        raise ValueError("that defect is not one of the defects this rule found")
                    engine.set_input(run["id"], prefix + "isolate", defect=chosen)
        elif sub == "isolate":
            if (core.jload(step["output"], {}) or {}).get("isolation"):
                _approve_isolation(engine, run, step, edits, admin, prefix)
            else:                               # a stage 1 card made before 2026-11-11 (signals on the sequence)
                _apply_signal(engine, run, step, data, admin, edits.get("signal") or "correct", edits)
        elif sub == "cause":
            _approve_cause(engine, run, step, edits, admin, prefix)
        elif sub == "solution":
            _approve_solution(engine, run, step, edits, admin, prefix)
        elif sub == "outcomes":
            out = core.jload(step["output"], {}) or {}
            outs = [dict(o) for o in out.get("outcomes") or []]
            changed = edits.get("outcomes") or {}
            for o in outs:
                ch = changed.get(str(o["step"])) or changed.get(o["step"]) or {}
                for f in ("status", "check"):
                    if (ch.get(f) or "").strip():
                        o[f] = ch[f].strip()
                o["verified"] = True
            engine.set_input(run["id"], prefix + "testcase", outcomes=outs, verified_by=admin)
            # the test file is a decision too (owner, 2026-11-10: "verified by the admin"), also for runs whose steps were made before it was
            engine.store.exec("UPDATE step SET needs_review=1 WHERE run=? AND key=?", (run["id"], prefix + "testcase"))
        elif sub == "testcase":
            out = core.jload(step["output"], {}) or {}
            if out.get("path") and os.path.exists(out["path"]):
                with open(out["path"], "rb") as fh:
                    sha = hashlib.sha256(fh.read()).hexdigest()
                rec = {"approved_by": admin, "at": time.time(), "test": out.get("name"), "version": out.get("version"), "sha256": sha, "status": "approved",
                       "comment": (data.get("comment") or "").strip(), "two_sided": (out.get("two_sided") or {}).get("ok"), "written_by": (out.get("model") or {}).get("used")}
                family1.L.write_json_atomic(out["path"] + ".approved.json", rec, indent=1)
                rev = (core.jload((engine.store.one("SELECT input FROM step WHERE run=? AND key=?", (run["id"], prefix + "outcomes")) or {}).get("input"), {}) or {}).get("dg_revision")
                if rev:                          # the approved test belongs to that version of the solution in the procedural graph
                    call_app(engine, "POST", "/api/dg/revisions/%d/test" % int(rev), {"path": out["path"], "admin": admin})


def _ensure_graph_steps(engine, run, step, prefix):
    """A run made before 2026-11-11 has no stage 2 graph steps: they are added right after stage 1."""
    have = engine.store.one("SELECT id FROM step WHERE run=? AND key=?", (run["id"], prefix + "cause"))
    if have:
        return
    item = prefix[3:-1]
    sec, lvl, rid, rnd = split_item(item)
    r = family3.load_rule(sec, lvl, rid) or {"name": rid}
    tag = "%s%s · " % (r["name"], "" if rnd <= 1 else " (round %d)" % rnd)
    engine.insert_steps(run["id"], step["idx"], graph_steps(lambda x: prefix + x, tag))


def _approve_isolation(engine, run, step, edits, admin, prefix):
    """The admin confirms the isolation and the defect's standard name: an existing defect of the graph, or a new one stored now."""
    out = core.jload(step["output"], {}) or {}
    iso = out.get("isolation") or {}
    choice = edits.get("defect_name")
    if choice in (None, ""):
        raise ValueError("choose the defect's standard name: one already stored, or a new name (nothing is chosen for you)")
    if str(choice) == "new":
        name = " ".join(str(edits.get("name") or "").split())
        if not name:
            raise ValueError("write the new standard name of the defect")
        r = call_app(engine, "POST", "/api/dg/defects", {"name": name, "rule": iso.get("rule"), "level": iso.get("level"), "what": iso.get("what"), "admin": admin})
        did = r["id"]
    else:
        try:
            did = int(choice)
        except (TypeError, ValueError, OverflowError):
            raise ValueError("the defect must be one of the list, or a new name")
        call_app(engine, "GET", "/api/dg/defects/%d" % did)        # it must exist
    _ensure_graph_steps(engine, run, step, prefix)
    engine.set_input(run["id"], prefix + "cause", defect_id=did)
    engine.set_input(run["id"], prefix + "solution", defect_id=did)


def _approve_cause(engine, run, step, edits, admin, prefix):
    """The admin names the cause of this occurrence: a stored one, or a new one (side and one line). The occurrence is stored under it."""
    out = core.jload(step["output"], {}) or {}
    did = out.get("defect_id")
    iso = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], prefix + "isolate")) or {}).get("output"), {}) or {}
    choice = edits.get("cause")
    if choice in (None, ""):
        raise ValueError("choose the cause of this occurrence: one already stored, or a new one (nothing is chosen for you)")
    if str(choice) == "new":
        side, header = str(edits.get("side") or "").strip(), " ".join(str(edits.get("header") or "").split())
        if side not in SIDES:
            raise ValueError("choose the side of the new cause")
        if not header:
            raise ValueError("write the new cause in one line")
        cid = call_app(engine, "POST", "/api/dg/causes", {"defect_id": did, "side": side, "header": header, "admin": admin})["id"]
    else:
        try:
            cid = int(choice)
        except (TypeError, ValueError, OverflowError):
            raise ValueError("the cause must be one of the list, or a new one")
        view = call_app(engine, "GET", "/api/dg/defects/%d" % int(did))
        if cid not in [c["id"] for c in view.get("causes") or []]:
            raise ValueError("that cause is not one of this defect's causes")
    i = iso.get("isolation") or {}
    oid = call_app(engine, "POST", "/api/dg/occurrences", {"defect_id": did, "cause_id": cid, "upload_id": iso.get("upload_id"), "finding_id": iso.get("finding"),
                                                            "device": i.get("device"), "firmware": i.get("firmware"), "isolation": {k: i.get(k) for k in (
                                                                "what", "why", "when", "where", "who", "which", "how", "standard_name", "cited_rows")},
                                                            "admin": admin})["id"]
    engine.set_input(run["id"], prefix + "solution", defect_id=did, cause_id=cid, occurrence_id=oid, did=[])


def _edited(seq, drop):
    drop = {int(x) for x in drop or []}
    kept = [dict(s_) for s_ in seq if s_.get("step") not in drop or s_.get("position") == "fault"]
    for i, s_ in enumerate(kept):
        s_["step"] = i + 1
    return kept


def _approve_solution(engine, run, step, edits, admin, prefix):
    """Store the first solution of a cause, store this recording's sequence as a new one, or judge a stored one with a signal. The error
    sequence then goes to stage 3, where the test file is written from it."""
    sinp = core.jload(step["input"], {}) or {}
    out = core.jload(step["output"], {}) or {}
    iso = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], prefix + "isolate")) or {}).get("output"), {}) or {}
    own = iso.get("sequence") or []
    i = iso.get("isolation") or {}
    choice = edits.get("solution")
    optimized = edits.get("optimized")
    if choice in (None, ""):
        raise ValueError("choose the stored solution you judge, or store this recording's sequence as a new solution (nothing is chosen for you)")
    if str(choice) == "new":
        seq = _edited(own, edits.get("drop"))
        lines = [x for x in str(optimized or "").splitlines() if x.strip()]
        if not lines:
            raise ValueError("write the optimized sequence (the solution), one action per line")
        r = call_app(engine, "POST", "/api/dg/solutions", {"cause_id": out.get("cause_id"), "error_seq": seq, "optimized": lines, "admin": admin,
                                                            "producer": "model, edited by %s" % admin, "upload_id": iso.get("upload_id"), "finding_id": iso.get("finding")})
        sid, rid, test_seq = r["id"], r["revision_id"], seq
    else:
        sig = edits.get("signal")
        if sig not in SIGNAL_WORDS:
            raise ValueError("give one of the four signals for the solution you chose")
        try:
            sid = int(choice)
        except (TypeError, ValueError, OverflowError):
            raise ValueError("the solution must be one of the list")
        view = call_app(engine, "GET", "/api/dg/defects/%d" % int(out.get("defect_id")))
        sol = next((x for c in view.get("causes") or [] for x in c["solutions"] if x["id"] == sid and c["id"] == out.get("cause_id")), None)
        if sol is None:
            raise ValueError("that solution is not one of this cause's solutions")
        body = {"signal": sig, "admin": admin, "occurrence_id": sinp.get("occurrence_id"), "device": i.get("device"), "firmware": i.get("firmware")}
        if sig.endswith("_with_edits"):
            body["error_seq"] = _edited(sol["error_seq"], edits.get("drop"))
            if optimized is not None:
                body["optimized"] = [x for x in str(optimized).splitlines() if x.strip()]
        r = call_app(engine, "POST", "/api/dg/solutions/%d/verdict" % sid, body)
        sol = r.get("solution") or sol
        if r.get("new_solution_id"):
            sid = r["new_solution_id"]
        rid = r.get("new_revision_id") or sol.get("revision_id")
        test_seq = body.get("error_seq") or sol["error_seq"]
        if (sol.get("origin_upload") and sol["origin_upload"] != iso.get("upload_id")) and not body.get("error_seq"):
            test_seq = own              # a solution stored from another recording: the test is written from this recording's rows of the same error
        engine.set_input(run["id"], step["key"], did=r.get("did") or [])
    engine.set_input(run["id"], prefix + "outcomes", sequence=test_seq, dg_solution=sid, dg_revision=rid)


def _apply_signal(engine, run, step, data, admin, sig, edits):
    if sig not in SIGNAL_WORDS:
        raise ValueError("the signal must be one of: %s" % ", ".join(SIGNAL_WORDS))
    if (core.jload(step["input"], {}) or {}).get("defect") in (None, "", "none"):
        # a stage 1 made on a defect nobody chose (the first one in the list, before 2026-11-11) gives no signal and stores nothing
        raise ValueError("this defect was not chosen by you: choose the defect on this card and press Look again; no signal is stored until then")
    item, _sub = parse_key(step["key"])
    prefix = "f3:%s:" % item
    out = core.jload(step["output"], {}) or {}
    seq = out.get("sequence") or []
    drop = {int(x) for x in (edits.get("drop") or [])}
    edited = [dict(s) for s in seq if s.get("step") not in drop or s.get("position") == "fault"]
    for i, s in enumerate(edited):
        s["step"] = i + 1
    advice = (data.get("comment") or "").strip()
    advice = "" if advice == "the proposal was judged wrong" else advice            # the page's default words are not advice
    if sig.endswith("_with_edits") and len(edited) == len(seq):
        if not advice:
            raise ValueError("untick at least one step or write your advice (or choose the signal without edits)")
        sig = sig[:-len("_with_edits")]          # advice without changed steps: the signal, and the advice stays on the graph
    body = {"advice": advice, "signal": sig, "proposal_steps": seq, "proposal_text": out.get("reason") or "", "scenario_name": out.get("scenario_name"),
            "reason": out.get("reason") or "", "name": admin}
    chosen = out.get("from_procedure")              # the signal is about the stored procedure the graph proposed: its weights change
    if chosen:
        body["procedure_id"] = chosen
    if sig.endswith("_with_edits"):
        body.update(edited_steps=edited, edited_text=out.get("reason") or "")
    r = call_app(engine, "POST", "/api/isolate/%s/%d/signal" % (out["upload_id"], int(out["finding"])), body)
    change = r.get("graph_change") or []
    if sig == "wrong":
        inp = core.jload(step["input"], {}) or {}
        engine.set_input(run["id"], step["key"], graph_change=change,
                         rejected_procedures=(inp.get("rejected_procedures") or []) + ([chosen] if chosen else []))
        return
    res = r.get("result") or {}
    final = edited if sig.endswith("_with_edits") else seq
    engine.set_input(run["id"], prefix + "outcomes", sequence=final, signal=sig, graph_change=change,
                     procedure_id=res.get("new_procedure_id") or res.get("procedure_id"))


def on_change(engine, run, step, data, admin, comment):
    key = step["key"]
    if key == admin_ask.GATE:
        if (data.get("edits") or {}).get("read_new"):
            admin_ask.read_new(engine, run, step, admin)               # the new CSVs of the folder get their three agents; then this step asks again
        return
    if not key.startswith("f3:"):
        return
    item, sub = parse_key(key)
    edits = data.get("edits") or {}
    if sub in ("req", "code"):                  # Family 4: the admin's answers to the Requirements agent are kept with their questions; on the
        # code step, his answer to "which of the two results is meant" (2026-11-14); a plain comment on the final code needs nothing here
        return family4.on_change(engine, run, dict(step, key=sub, full_key=key), data, admin, comment)
    if sub == "isolate" and edits.get("defect") not in (None, ""):
        # the admin chooses (or changes) the defect on the stage 1 card; the weights of the old one are not touched
        run_out = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], "f3:%s:run" % item)) or {}).get("output"), {}) or {}
        ids = [x[0] for x in run_out.get("head") or []]
        try:
            fid = int(edits["defect"])
        except (TypeError, ValueError, OverflowError):
            raise ValueError("the defect must be one of the list")
        if fid not in ids:
            raise ValueError("that defect is not one of the defects this rule found")
        inp = core.jload(step["input"], {}) or {}
        if fid != inp.get("defect"):
            engine.set_input(run["id"], key, defect=fid, rejected_procedures=[], graph_change=None)
    elif sub == "isolate" and error_of(item) is None and core.jload(step["input"], {}).get("defect") in (None, "", "none"):
        raise ValueError("choose the defect first: no defect is chosen for you")
    if sub == "solution" and edits.get("signal") == "wrong":
        out = core.jload(step["output"], {}) or {}
        try:
            sid = int(edits.get("solution"))
        except (TypeError, ValueError, OverflowError):
            raise ValueError("choose the stored solution you judge wrong")
        iso = core.jload((engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (run["id"], "f3:%s:isolate" % item)) or {}).get("output"), {}) or {}
        i = iso.get("isolation") or {}
        view = call_app(engine, "GET", "/api/dg/defects/%d" % int(out.get("defect_id")))
        if sid not in [x["id"] for c in view.get("causes") or [] if c["id"] == out.get("cause_id") for x in c["solutions"]]:
            raise ValueError("that solution is not one of this cause's solutions")
        r = call_app(engine, "POST", "/api/dg/solutions/%d/verdict" % sid, {"signal": "wrong", "admin": admin, "device": i.get("device"), "firmware": i.get("firmware"),
                                                                             "occurrence_id": (core.jload(step["input"], {}) or {}).get("occurrence_id")})
        engine.set_input(run["id"], key, did=r.get("did") or [])
        return
    if sub == "isolate" and isinstance(edits.get("window"), dict):
        # "Look again with these numbers": the same defect with the admin's n above and m below; no signal, the graph is not touched
        win = edits["window"]
        try:
            n, m = int(win.get("n")), int(win.get("m"))
        except (TypeError, ValueError, OverflowError):
            raise ValueError("the numbers above and below must be whole numbers")
        if not (0 <= n <= 100 and 0 <= m <= 100):
            raise ValueError("commands above and below: from 0 to 100 each")
        engine.set_input(run["id"], key, n=n, m=m, window_set=True)
        return
    if sub == "testcase":
        # "write it again": the comment goes to the model as a hint; a deallocate range or a measured rate given on the card goes into the plan
        keep = {}
        if isinstance(edits.get("deallocate_range"), dict):
            keep["deallocate_range"] = edits["deallocate_range"]
        if isinstance(edits.get("known_rate"), dict):
            keep["known_rate"] = edits["known_rate"]
        if keep:
            engine.set_input(run["id"], key, **keep)
        return
    if sub == "isolate" and edits.get("signal") == "wrong":
        _apply_signal(engine, run, step, data, admin, "wrong", edits)
    elif sub == "result":
        # a change of the rule: a new round of the item (the Rule writer with the admin's words, then the code again)
        sec, lvl, rid, rnd = split_item(item)
        r = family3.load_rule(sec, lvl, rid)
        last = engine.store.one("SELECT MAX(idx) AS i FROM step WHERE run=? AND key LIKE ?", (run["id"], "f3:%s:%%" % item))["i"]
        engine.insert_steps(run["id"], last, item_steps(sec, lvl, rid, r["name"], True, comment or "", rnd + 1))
        engine.set_input(run["id"], key, superseded=True)
        for k in ("errors", "isolate", "cause", "solution", "outcomes", "testcase", "summary"):
            engine.store.exec("UPDATE step SET state='skipped', note=? WHERE run=? AND key=? AND state='waiting'",
                              ("the rule is being changed: see round %d" % (rnd + 1), run["id"], "f3:%s:%s" % (item, k)))


# ---------------------------------------------------------------------------------------------- a finished analysis, opened again
STAGE_WORDS = {"data": "stage 1 (the data)", "tree": "stage 2 (the tree)", "rules": "stage 3 (the rules)", "report": "the report"}


def reopen(engine, rid, stage, admin):
    """(owner, 2026-11-12: "for a run built already and completed there should be an option to go for any stage and
    build again, but no recomputing of the computed; only the newly arrived things") Opens a flow that is not working
    again at one stage. The decisions from that stage on are asked again; the work behind them is done again only where
    something it reads is new:
      data    the step after Family 1 asks again (questions to the Managers; "read the new files" reads only the CSVs not
              read yet; stage 2 or not). Family 2 is run again only if the tree it built is no longer the tree of the files
      tree    Family 2 from its first step: the strategy approved for this file format and the tree built from these same
              files are offered again and used again; the tree's tests are kept while the tree is the same
      rules   the choice of items: an item whose rule, code and data are the same keeps its result; others run
      report  the report is written again
    The later stages follow in order. -> the steps put back to waiting. ValueError says why it cannot be opened."""
    run = engine.store.one("SELECT * FROM run WHERE id=?", (rid,))
    if not run or run["kind"] != KIND:
        raise ValueError("only a flow can be opened again at a stage")
    if stage not in STAGE_WORDS:
        raise ValueError("the stage must be one of: data, tree, rules, report")
    if run["state"] == "running":
        raise ValueError("this analysis is still open: it is working or it waits for your decision on a card. Decide that card, or stop the flow, then open it again")
    project = engine.store.one("SELECT * FROM project WHERE id=?", (run["project"],)) or {}
    steps = engine.store.all("SELECT * FROM step WHERE run=? ORDER BY idx", (rid,))
    by_key = {s["key"]: s for s in steps}
    order = ["data", "tree", "rules", "report"]
    fam_stage = {"1": "data", "2": "tree", "3": "rules", "4": "rules", "R": "report"}
    back = []
    gate = by_key.get(admin_ask.GATE)
    if stage == "data":
        if gate is None:                # a flow started before the step existed: it gets one, after its last Family 1 step
            last = max([s["idx"] for s in steps if s["family"] == "1"] or [0])
            engine.insert_steps(rid, last, [admin_ask.gate_step()])
            steps = engine.store.all("SELECT * FROM step WHERE run=? ORDER BY idx", (rid,))
            by_key = {s["key"]: s for s in steps}
            gate = by_key[admin_ask.GATE]
        back.append(gate["id"])
    if stage == "tree":
        facts = admin_ask.stage2_facts(engine, run, project)
        if not facts["fixed_possible"]:
            raise ValueError("stage 2 cannot be opened for this analysis: the fixed joining strategy cannot build these files into a tree: %s" % facts["fixed_problem"].rstrip("."))
        back += [s["id"] for s in steps if s["family"] == "2"]
        if gate is not None:            # the admin's earlier "without stage 2" no longer holds
            out = core.jload(gate["output"], {}) or {}
            engine.store.exec("UPDATE step SET output=? WHERE id=?", (json.dumps(dict(out, stage2="fixed", stage2_by=admin, stage2_at=time.time())), gate["id"]))
    if order.index(stage) <= order.index("rules") and "f3_plan" in by_key:
        back.append(by_key["f3_plan"]["id"])
    if "report" in by_key:
        back.append(by_key["report"]["id"])
    # whatever failed, was stopped or was rejected at that stage or later starts again too
    back += [s["id"] for s in steps if s["state"] in ("failed", "stopped", "rejected", "running") and order.index(fam_stage.get(s["family"], "report")) >= order.index(stage)]
    back = list(dict.fromkeys(back))
    if not back:
        raise ValueError("this flow has no step of %s to open again" % STAGE_WORDS[stage])
    for sid in back:
        engine.store.exec("UPDATE step SET state='waiting', note=NULL, error=NULL WHERE id=?", (sid,))
    engine.store.exec("UPDATE review SET state='rejected', comment=? WHERE run=? AND state='open'", ("closed: the analysis was opened again at %s" % STAGE_WORDS[stage], rid))
    params = core.jload(run["params"], {}) or {}
    params.setdefault("reopened", []).append({"stage": stage, "by": admin, "at": time.time()})
    if admin:
        params["started_by"] = admin       # the reviews that follow are addressed to the person who opened it again
    engine.store.exec("UPDATE run SET state='running', params=?, summary=?, updated=?, heartbeat=? WHERE id=?",
                      (json.dumps(params), "opened again at %s by %s" % (STAGE_WORDS[stage], admin or "the admin"), time.time(), time.time(), rid))
    try:
        engine.runner.resume(rid)
    except Exception:                   # noqa: BLE001 - a runner without that method (a test's stand-in)
        pass
    engine.kick(rid)
    return back


# ---------------------------------------------------------------------------------------------- one item of the library added to an analysis
# (owner, 2026-11-15: page 3 shows every item of every level, the ones of this analysis marked, and "Use it in this analysis" on the others.)
# An item is added only by the admin's request (nothing is chosen for the admin), and it then goes the way of every item:
# rule -> research -> requirements -> code -> run -> test -> export -> result card -> its errors (listed only after its result is approved).
#   the card that asks which rules to use is open      the item is ticked on that card (its review data, where the card's ticks come from)
#   that card is not made yet (or is made again)       the item is ticked on it when it is made (the plan step's input "add_items")
#   the plan is approved and the flow works or waits   the item's steps are put where approving the plan would have put them: after the
#                                                      other items of stage 3, before the errors card and the report; nothing else changes
#   the flow is finished or stopped                    the analysis is opened again at the rules (reopen): the card asks again with this
#                                                      item ticked beside the items the approved plan had chosen; those keep their results
ITEM_IN, ITEM_TICKED, ITEM_OUT = "in the analysis", "chosen, plan not approved yet", "not in the analysis"
PLAN_BEING_MADE = "The card that asks which rules to use is being made right now: try again in a moment."
ERRORS_CARD_BEING_MADE = "The card of the errors is being made right now: try again in a moment."
REPORT_UNDER_WAY = ("The report of this analysis is being written now: add the item when the analysis has finished; it is then opened again at "
                    "the rules with the item ticked.")


class AddRefused(ValueError):
    """Why an item cannot be added to an analysis now, in one plain sentence; status 400 (the request) or 409 (the analysis's state now)."""

    def __init__(self, sentence, status=400):
        super().__init__(sentence)
        self.status = status


def tick_added_items(items, inp):
    """The plan card's ticks for the items added from page 3 (in the plan step's input): "add_items" are ticked; "keep_chosen" (an analysis
    opened again because an item was added to it after it finished) makes the ticks exactly those items and the added ones, so that
    approving the card as it is runs only the added item and keeps the others' results. An item that cannot run here stays unticked."""
    add = set((inp or {}).get("add_items") or [])
    if not add:
        return items
    keep = (inp or {}).get("keep_chosen")
    for i in items:
        want = i["key"] in add or (keep is not None and i["key"] in set(keep))
        if keep is not None or want:
            i["selected"] = bool(want) and not i.get("blocked")
    return items


def forget_added_items(engine, step_id):
    """After the plan card was approved: the items added from page 3 were decided with it; a later opening of the card starts from its own ticks."""
    s = engine.store.one("SELECT input FROM step WHERE id=?", (step_id,))
    inp = core.jload((s or {}).get("input"), {}) or {}
    if "add_items" in inp or "keep_chosen" in inp:
        inp.pop("add_items", None)
        inp.pop("keep_chosen", None)
        engine.store.exec("UPDATE step SET input=? WHERE id=?", (json.dumps(inp), step_id))


def _analysis_facts(engine, rid):
    """What adding an item depends on, read once: the run, its project, its tree, its files, its steps, the plan step, the plan card."""
    run = engine.store.one("SELECT * FROM run WHERE id=?", (rid,))
    if not run:
        raise AddRefused("There is no such analysis.", 404)
    if run["kind"] != KIND:
        raise AddRefused("Only an analysis made by the flow can take an item of the rules library: this run is of another kind.", 400)
    project = engine.store.one("SELECT * FROM project WHERE id=?", (run["project"],)) or {}
    from . import procedures as PR
    up = tree_of(engine, run, project)
    steps = engine.store.all("SELECT * FROM step WHERE run=? ORDER BY idx", (rid,))
    by_key = {s["key"]: s for s in steps}
    plan = by_key.get("f3_plan")
    review = engine.store.one("SELECT * FROM review WHERE run=? AND step=? AND state='open' ORDER BY id DESC LIMIT 1", (rid, plan["id"])) if plan else None
    ticked = set()
    if review is not None:
        ticked = {i["key"] for i in (core.jload(review["data"], {}) or {}).get("items") or [] if i.get("selected")}
    if plan is not None and plan["state"] != "approved":
        ticked |= set((core.jload(plan["input"], {}) or {}).get("add_items") or [])
    return {"run": run, "project": project, "upload": up, "paths": PR.recording_paths(up, project.get("folder")), "steps": steps, "by_key": by_key,
            "plan": plan, "review": review, "ticked": ticked, "had": _items_in_run(engine, rid), "others": None}


def _other_csv_files(f):
    """The CSV files of the analysis's folder that are not one of the analyzer's exports (read once, only when an item of "Other CSV files" asks)."""
    if f["others"] is None:
        folder = f["project"].get("folder")
        try:
            f["others"] = [x["name"] for x in family1.inventory(folder) if not x.get("level")] if folder else []
        except Exception:      # noqa: BLE001 - a folder that cannot be read has no such file
            f["others"] = []
    return f["others"]


def _tree_may_come(f):
    """Before the plan card is made, the tree may still be built (stage 2 comes before the rules): an item that reads the tree is not refused
    then, unless the admin already chose to go on without stage 2. The plan card itself checks again when it is made."""
    plan = f["plan"]
    if plan is None or plan["state"] in ("approved", "needs_review", "rejected"):
        return False
    gate = f["by_key"].get(admin_ask.GATE)
    return (core.jload((gate or {}).get("output"), {}) or {}).get("stage2") != "skipped"


def _cannot_be_used(f, r, level):
    """Why this item cannot run on this analysis, as the plan card says it (cannot_run_here), or because it is an item of "Other CSV files"
    and the folder has no CSV file besides the analyzer's exports; "" when it can."""
    why = cannot_run_here(r, f["upload"] is not None or _tree_may_come(f), f["paths"])
    if not why and level == "other" and not _other_csv_files(f):
        why = "reads a CSV file of the folder that is not one of the analyzer's exports, and this analysis has none"
    return why


def _when_not(f):
    """Can an item be added to this analysis now? -> "" when it can, else the plain sentence (one for every item)."""
    plan, by_key, run = f["plan"], f["by_key"], f["run"]
    if plan is None:
        return "This analysis has no stage of rules: it was made before the rules were part of the flow."
    if plan["state"] == "running":
        return PLAN_BEING_MADE
    if plan["state"] == "approved" and run["state"] == "running":
        gate, rep = by_key.get(ERRORS_DONE["key"]), by_key.get("report")
        if (gate and gate["state"] in ("done", "approved", "skipped")) or (rep and rep["state"] in ("running", "done", "approved", "skipped")):
            return REPORT_UNDER_WAY
        if gate and gate["state"] == "running":
            return ERRORS_CARD_BEING_MADE
    return ""


def items_of_analysis(engine, rid):
    """GET /api/agents/runs/<rid>/items: every item of the rules library with its state in this analysis, and whether an item can be added now.
    -> {"items": [{"section", "level", "id", "state", "words"}], "can_add", "why_not"}. AddRefused for no such analysis or another kind of run."""
    f = _analysis_facts(engine, rid)
    why_not = _when_not(f)
    out = []
    for sec in family3.tree():
        for lv in sec["levels"]:
            for it in lv["items"]:
                k = item_key(sec["section"], lv["level"], it["id"])
                if k in f["had"]:
                    state, words = ITEM_IN, "It is in this analysis: its steps are on page 3."
                elif k in f["ticked"]:
                    state = ITEM_TICKED
                    words = ("It is ticked on the card that asks which rules to use: it runs when you approve that card." if f["review"] is not None else
                             "It will be ticked on the card that asks which rules to use, when the analysis reaches that card.")
                else:
                    state = ITEM_OUT
                    why = _cannot_be_used(f, family3.load_rule(sec["section"], lv["level"], it["id"]) or {}, lv["level"])
                    words = ("It is not in this analysis, and it cannot be used here: it %s." % why.rstrip(".")) if why else \
                        ("It is not in this analysis." if why_not else "It is not in this analysis: “Use it in this analysis” adds it.")
                out.append({"section": sec["section"], "level": lv["level"], "id": it["id"], "state": state, "words": words})
    return {"items": out, "can_add": not why_not, "why_not": why_not}


def add_item_to_analysis(engine, rid, section, level, iid, admin):
    """POST /api/agents/runs/<rid>/items: adds one item of the rules library to this analysis (see the table above this function).
    -> {"ok": True, "how": one plain sentence, "steps": the keys of the steps added now}. AddRefused (400 or 409, 404 for no analysis) says why not."""
    admin = (admin or "").strip() if isinstance(admin, str) else ""
    if not admin:
        raise AddRefused("Say who adds the item: the decisions that follow are stored with that name.", 400)
    f = _analysis_facts(engine, rid)
    if not all(isinstance(x, str) and x.strip() for x in (section, level, iid)):
        raise AddRefused("Say which item of the rules library to add: its section, its level and its name.", 400)
    family3.sync_sections()
    gone = next((x for x in family3.deleted_items() if (x["section"], x["level"], x["id"]) == (section, level, iid)), None)
    if gone is not None:
        raise AddRefused("“%s” is in Deleted items: restore it in the rules library first, then add it." % (gone.get("name") or iid), 400)
    try:
        r = family3.load_rule(section, level, iid)
    except ValueError:
        r = None
    if not isinstance(r, dict):
        raise AddRefused("The rules library has no such item.", 400)
    name, key = r.get("name") or iid, item_key(section, level, iid)
    if key in f["had"]:
        raise AddRefused("“%s” is already in this analysis: its steps are on page 3." % name, 409)
    if key in f["ticked"]:
        raise AddRefused("“%s” is already ticked on the card that asks which rules to use: approve that card to run it." % name, 409)
    why = _cannot_be_used(f, r, level)
    if why:
        raise AddRefused("“%s” cannot be used in this analysis: it %s." % (name, why.rstrip(".")), 400)
    when = _when_not(f)
    if when:
        raise AddRefused(when, 409)
    plan, run = f["plan"], f["run"]
    if plan["state"] == "needs_review" and run["state"] == "running":
        return _add_to_open_card(engine, f, r, key, name)
    if plan["state"] not in ("approved", "rejected", "needs_review"):
        # the card is not made yet (the flow is at stage 1 or 2, or the card is made again): it is ticked when the card is made
        engine.set_input(rid, "f3_plan", add_items=sorted(set((core.jload(plan["input"], {}) or {}).get("add_items") or []) | {key}))
        tail = "" if run["state"] == "running" else "; this analysis is stopped now: the item waits there until the analysis goes on"
        return {"ok": True, "steps": [], "how": "“%s” will be ticked on the card that asks which rules to use, when the analysis reaches that card%s." % (name, tail)}
    if run["state"] == "running" and plan["state"] == "approved":
        return _add_steps_now(engine, f, r, key, name, admin)
    return _add_by_opening_again(engine, f, key, name, admin)


def _add_to_open_card(engine, f, r, key, name):
    """Case a: the plan card waits for the admin. The item is ticked in the card's data (where the card's ticks come from) and in the plan
    step's input (a card made again after "change" keeps it ticked). Nothing else changes."""
    rv = f["review"]
    if rv is None:
        raise AddRefused(PLAN_BEING_MADE, 409)
    data = core.jload(rv["data"], {}) or {}
    items = data.setdefault("items", [])
    have = next((i for i in items if i.get("key") == key), None)
    if have is None:                    # an item made after the card was: its line is added as the card makes its lines
        sec, lvl, _rid, _rnd = split_item(key)
        have = {"key": key, "section": sec, "section_label": family3.SECTIONS.get(sec, sec), "level": lvl, "level_label": family3.LEVEL_LABEL.get(lvl, lvl),
                "name": name, "status": r.get("status"), "version": r.get("version", 0), "demo": r.get("demo", False), "blocked": "",
                "last_run": (r.get("last_run") or {}).get("at")}
        items.append(have)
    have["selected"], have["added_by_admin"] = True, True
    if not engine.store.claim("UPDATE review SET data=? WHERE id=? AND state='open'", (json.dumps(data), rv["id"])):
        raise AddRefused("The card that asks which rules to use was decided just now: look at page 3 again, then add the item.", 409)
    plan = f["plan"]
    engine.set_input(f["run"]["id"], "f3_plan", add_items=sorted(set((core.jload(plan["input"], {}) or {}).get("add_items") or []) | {key}))
    return {"ok": True, "steps": [], "how": "“%s” is now ticked on the card that asks which rules to use: approve that card to run it with the others." % name}


def _add_steps_now(engine, f, r, key, name, admin):
    """Case b: the plan is approved and the flow works or waits on another card. The item's steps, made as approving the plan makes them,
    go after the other items' steps of stage 3 and before the errors card and the report; no other step changes, except the errors card
    when it is open: it is closed and asked again after the new item (its errors must be listed on it)."""
    rid, by_key = f["run"]["id"], f["by_key"]
    sec, lvl, iid, _ = split_item(key)
    write = family3.procedures_of(r) is None
    new = item_steps(sec, lvl, iid, r["name"], write, r.get("description") or r["name"], 1)
    gate = by_key.get(ERRORS_DONE["key"])
    stages = family3.goes_to_stages(sec)
    if stages and gate is None:
        new.append(dict(ERRORS_DONE))   # the analysis had no rule that finds defects: the errors card comes after this one, before the report
    last = engine.store.one("SELECT MAX(idx) AS i FROM step WHERE run=? AND key LIKE 'f3:%' AND key NOT LIKE '%@%'", (rid,))["i"]
    after = max(f["plan"]["idx"], last if last is not None else -1)
    for later in (gate, by_key.get("report")):
        if later is not None:
            after = min(after, later["idx"] - 1)
    reask = ""
    if stages and gate is not None and gate["state"] == "needs_review":
        decided = engine.store.one("SELECT id FROM review WHERE run=? AND step=? AND state='deciding'", (rid, gate["id"]))
        if decided or (engine.store.one("SELECT id FROM review WHERE run=? AND step=? AND state='open'", (rid, gate["id"])) and not engine.store.claim(
                "UPDATE review SET state='rejected', comment=? WHERE run=? AND step=? AND state='open'",
                ("closed: “%s” was added to the analysis by %s; this card is asked again after its result" % (name, admin), rid, gate["id"]))):
            raise AddRefused("The card of the errors was decided just now: look at page 3 again, then add the item.", 409)
        engine.store.exec("UPDATE step SET state='waiting', note=NULL WHERE id=? AND state='needs_review'", (gate["id"],))
        reask = " The card of the errors was closed: it is asked again after the result of “%s”, with its errors listed." % name
    engine.insert_steps(rid, after, new)
    _note_added(engine, f["run"], key, admin, len(new))     # who added it and when: on the run, so that no step's record changes
    engine.kick(rid)
    keys = [s["key"] for s in new]
    n = sum(1 for s in new if s["key"].startswith("f3:"))
    return {"ok": True, "steps": keys,
            "how": "“%s” was added to this analysis: its %d steps are on page 3 after the other rules, and they run when the analysis reaches them; "
                   "its result card comes to you like the others.%s" % (name, n, reask)}


def _note_added(engine, run, key, admin, steps):
    """The run's parameters keep who added which item from page 3, when, and how many steps it got (params "added_items")."""
    params = core.jload(engine.store.one("SELECT params FROM run WHERE id=?", (run["id"],))["params"], {}) or {}
    params.setdefault("added_items", []).append({"item": key, "by": admin, "at": time.time(), "steps": steps})
    engine.store.exec("UPDATE run SET params=? WHERE id=?", (json.dumps(params), run["id"]))


def _add_by_opening_again(engine, f, key, name, admin):
    """Case c: the flow is finished or stopped. It is opened again at the rules (reopen): the card that asks which rules to use is asked
    again with this item ticked beside the items the approved plan had chosen; approved as it is, only this item runs, the others keep
    their results while their rule, their code and the data are the same (_plan_steps)."""
    plan, rid = f["plan"], f["run"]["id"]
    # the items this analysis already used: every item with steps in it (chosen on an approved card, or added from page 3 since)
    chosen = list(f["had"]) or None
    inp = core.jload(plan["input"], {}) or {}
    before = dict(inp)
    inp["add_items"] = sorted(set(inp.get("add_items") or []) | {key})
    if chosen is not None:
        inp["keep_chosen"] = chosen
    engine.store.exec("UPDATE step SET input=? WHERE id=?", (json.dumps(inp), plan["id"]))
    try:
        reopen(engine, rid, "rules", admin)
    except ValueError as e:
        engine.store.exec("UPDATE step SET input=? WHERE id=?", (json.dumps(before), plan["id"]))      # nothing was opened: nothing is kept
        raise AddRefused(str(e)[:1].upper() + str(e)[1:].rstrip(".") + ".", 409)
    kept = len(chosen or [])
    was = "had finished" if f["run"]["state"] == "finished" else "was stopped"
    if chosen:
        how = ("This analysis %s, so it was opened again at the rules: the card that asks which rules to use comes again with “%s” ticked beside "
               "the %d rule%s it already used. Approve it as it is: “%s” runs, and the others keep their results while their rule, their code and the data are the same." % (
                   was, name, kept, "" if kept == 1 else "s", name))
    else:
        how = ("This analysis %s, so it was opened again at the rules: the card that asks which rules to use comes again with “%s” ticked. "
               "Approve it to run it." % (was, name))
    return {"ok": True, "steps": [], "how": how}


def on_finish(engine, rid):
    v = engine.view(rid)
    rep = next((s for s in v["steps"] if s["key"] == "report"), None)
    files = ((rep or {}).get("output") or {}).get("files") or {}
    gate = next((s for s in v["steps"] if s["key"] == admin_ask.GATE), None)
    no_tree = ((gate or {}).get("output") or {}).get("stage2") == "skipped"
    engine.store.exec("UPDATE run SET summary=? WHERE id=?", ("flow finished: %s; report %s" % (
        "Family 1 -> 3, without stage 2 (no tree, by the admin's choice)" if no_tree else "Family 1 -> 2 -> 3", files.get("html") or "not written"), rid))


# ---------------------------------------------------------------------------------------------- the report
def _report(ctx):
    v = ctx.engine.view(ctx.run["id"])
    p = ctx.project
    steps_ = v["steps"]
    files = family1.inventory(p.get("folder"))
    dicts = []
    for f in files:
        if not f["level"]:
            continue
        d = family1.approved_dictionary(f["format_key"], f["name"]) or {}
        cols = d.get("columns") or []
        dicts.append({"file": f["name"], "level": f["level_label"], "rows_estimate": d.get("rows_estimate"), "version": d.get("version"),
                      "approved_by": d.get("approved_by"), "columns": len(cols), "status": dict(Counter(c.get("status") for c in cols))})
    fmt, _ = family2.project_format(p)
    st = family2.last_strategy(fmt) or {}
    out = {s["key"]: s.get("output") or {} for s in steps_}
    slice_, breaker, indep = out.get("slice_test", {}), out.get("breaker", {}), out.get("independent", {})
    items = {}
    for s in steps_:
        if not s["key"].startswith("f3:"):
            continue
        item, sub = parse_key(s["key"])
        it = items.setdefault(item, {"item": item, "steps": {}})
        it["steps"][sub] = {"state": s["state"], "output": s.get("output") or {}, "producer": s.get("producer"), "note": s.get("note")}
    reviews = {r["step"]: r for r in v["reviews"]}
    fam = Counter((s.get("family"), s["state"]) for s in steps_)
    rep = {"run": ctx.run["id"], "made": time.time(), "admin": _admin(p), "project": {k: p.get(k) for k in ("name", "folder", "upload_id")},
           "files": [{k: f[k] for k in ("name", "level_label", "bytes", "columns")} for f in files],
           "family1": dicts, "family2": {"format": fmt, "strategy_version": st.get("version"), "strategy_approved_by": st.get("approved_by"),
                                          "upload_id": p.get("upload_id"), "random_windows": [slice_.get("passed"), slice_.get("of")],
                                          "hard_windows": [breaker.get("passed"), breaker.get("of")], "invariants": indep.get("invariants")},
           "family3": [], "steps": [{"title": s["title"], "family": s.get("family"), "state": s["state"], "producer": s.get("producer"),
                                     "decided_by": (reviews.get(s["id"]) or {}).get("decided_by"),
                                     "seconds": round((s.get("finished") or 0) - (s.get("started") or 0), 1) if s.get("started") and s.get("finished") else None}
                                    for s in steps_ if s["key"] != "report"],
           "state_counts": {"%s %s" % (FAMILY_LABEL.get(k[0], k[0]), k[1]): n for k, n in fam.items()}}
    for item, it in items.items():
        sec, lvl, rid, rnd = split_item(item)
        r = family3.load_rule(sec, lvl, rid) or {}
        S = it["steps"]
        o = lambda k: (S.get(k) or {}).get("output") or {}     # noqa: E731
        rep["family3"].append({"item": item, "name": r.get("name"), "section": family3.SECTIONS.get(sec), "level": family3.LEVEL_LABEL.get(lvl), "round": rnd,
                               "rule_version": o("code").get("procedure_version") or o("code").get("version") or ("built-in detector" if o("code").get("kind") == "detector" else None), "rows": o("run").get("rows"), "tester_passed": o("test").get("passed"),
                               "checks": o("test").get("checks"), "exports": o("export").get("files"),
                               "defect": o("isolate").get("finding"), "reason": o("isolate").get("reason"), "scenario_name": o("isolate").get("scenario_name"),
                               "signal": (S.get("outcomes") or {}).get("output", {}).get("signal"), "test_file": o("testcase").get("path"),
                               "test_run": o("testcase").get("pytest"), "summary": o("summary").get("lines"),
                               "from_version": o("isolate").get("from_version"), "known_failure": o("isolate").get("known_failure"),
                               "graph": _graph_of(ctx.engine, o("isolate")),
                               "error": error_of(item), "defect_name": o("cause").get("defect_name"),
                               "states": {k: x["state"] for k, x in S.items()}})
    # where each error ended (owner, 2026-11-11: stage 1 done, stage 2 done, test files created), from the procedural graph
    rep["errors"] = []
    for s_ in steps_:
        o_ = s_.get("output") or {}
        if not (s_["key"].endswith(":errors") and o_.get("errors")):
            continue
        try:
            st_ = call_app(ctx.engine, "GET", "/api/dg/status?upload=%s&findings=%s" % (o_.get("upload_id"), ",".join(str(x["finding"]) for x in o_["errors"]))).get("status") or {}
        except RuntimeError:
            st_ = {}
        for x in o_["errors"]:
            y = st_.get(str(x["finding"])) or {}
            rep["errors"].append({"pattern": o_.get("pattern"), "where": x["where"], "what": x["what"], "state": y.get("state") or "new",
                                  "status": y.get("words") or "not isolated yet", "test_file": y.get("test_path")})
    # the errors of CSV files that are not part of the tree, apart (their own kind): per rule, how many rows and how many were isolated
    rep["other_errors"] = other_errors.listings(other_errors_store(ctx.engine, ctx.run["id"]))
    d = os.path.join(family1.knowledge_dir(), "exports", "flow", "run_%d" % ctx.run["id"])
    os.makedirs(d, exist_ok=True)
    jp, hp = os.path.join(d, "flow_report.json"), os.path.join(d, "flow_report.html")
    family1.L.write_json_atomic(jp, rep, indent=1, default=str)
    family1.L.write_text_atomic(hp, _report_html(rep))
    return core.Result({"files": {"html": hp, "json": jp}, "items": len(rep["family3"]),
                        "dictionaries": sum(1 for x in dicts if x["version"]), "strategy_version": st.get("version")})


def _report_html(rep):
    e = lambda x: html.escape("" if x is None else str(x))     # noqa: E731

    def table(head, rows):
        return "<table><tr>%s</tr>%s</table>" % ("".join("<th>%s</th>" % e(h) for h in head),
                                                 "".join("<tr>%s</tr>" % "".join("<td>%s</td>" % c for c in r) for r in rows))
    f2 = rep["family2"]
    parts = ["<h1>The flow, run %s</h1>" % e(rep["run"]),
             "<p>Project <b>%s</b> · admin %s · input folder <code>%s</code> · tree: upload %s · made %s</p>" % (
                 e(rep["project"]["name"]), e(rep["admin"]), e(rep["project"]["folder"]), e(rep["project"]["upload_id"]),
                 e(time.strftime("%Y-%m-%d %H:%M", time.localtime(rep["made"])))),
             "<h2>Family 1 · Data experts: one approved data dictionary per file</h2>",
             table(["file", "level", "about how many rows", "dictionary version", "approved by", "columns", "meanings by status"],
                   [[e(x["file"]), e(x["level"]), e("{:,}".format(x["rows_estimate"]) if x["rows_estimate"] else ""), e(x["version"] or "not approved"),
                     e(x["approved_by"]), e(x["columns"]), e(", ".join("%s: %s" % kv for kv in x["status"].items()))] for x in rep["family1"]]),
             "<h2>Family 2 · Hierarchy: the strategy, the tree and its tests</h2>",
             "<p>Strategy version %s (approved by %s) for this file format (%s). Tree: upload %s.</p>" % (
                 e(f2["strategy_version"]), e(f2["strategy_approved_by"]), e(f2["format"]), e(f2["upload_id"])),
             "<p>Code tester: %s of %s random windows rebuilt alone matched the full tree and the analyzer's counts. Breaker: %s of %s hard windows.</p>" % (
                 e(f2["random_windows"][0]), e(f2["random_windows"][1]), e(f2["hard_windows"][0]), e(f2["hard_windows"][1])),
             table(["independent check (column meanings only)", "rows checked", "violations"],
                   [[e(i.get("check")), e("{:,}".format(i.get("rows_checked") or 0)), e(i.get("violations", i.get("error")))] for i in f2["invariants"] or []]),
             "<h2>Family 3 · Rules: every item used on this data</h2>"]
    for it in rep["family3"]:
        checks = "".join("<li>%s %s: %s</li>" % ("✔" if c.get("ok") else "✘", e(c.get("check")), e(c.get("detail"))) for c in it.get("checks") or [])
        ex = " ".join('<a href="/api/agents/file?path=%s">%s</a>' % (html.escape(p, quote=True), e(k.upper())) for k, p in (it.get("exports") or {}).items())
        parts.append("<h3>%s <small>(%s · %s%s)</small></h3>" % (e(it["name"]), e(it["section"]), e(it["level"]), "" if it["round"] <= 1 else " · round %d" % it["round"]))
        parts.append("<p>Rule version %s · %s rows · tester: %s · exports: %s</p><ul>%s</ul>" % (
            e(it["rule_version"]), e(it["rows"]), "all checks passed" if it["tester_passed"] else "NOT all checks passed" if it["tester_passed"] is False else "-", ex or "-", checks))
        if it.get("defect") is not None:
            parts.append("<p><b>Stage 1</b>, defect %s: %s<br>Scenario: %s<br>Signal: %s</p>" % (
                e(it["defect"]), e(it.get("reason")), e(it.get("scenario_name")), e(SIGNAL_WORDS.get(it.get("signal"), it.get("signal")))))
            parts.append("<p><b>Stage 2</b>: test file <code>%s</code> (run here without the drive: %s)</p>" % (e(it.get("test_file")), e(it.get("test_run"))))
            g = it.get("graph") or {}
            if g.get("edges"):
                link = {"CAUSED_BY": "is caused by", "REPRODUCED_BY": "is reproduced by", "TESTED_BY": "is tested by", "SUPERSEDES": "replaces", "LESSON_ABOUT": "is a lesson about"}
                parts.append("<p><b>Procedural graph</b> of this failure: %s. Weights after the admin's signals:</p>" % (
                    "known before this flow, procedure version %s came from the graph" % e(it["from_version"]) if it.get("from_version") else
                    "known before this flow, a new proposal was used" if it.get("known_failure") else "first time"))
                parts.append(table(["from", "link", "to", "weight", "signals", "state"],
                                   [[e(x["from"]), e(link.get(x["kind"], x["kind"])), e(x["to"]), e(x["weight_text"]), e(x["n"]), e(x["status"])] for x in g["edges"]]))
            if it.get("summary"):
                parts.append("<p><b>Summary</b><br>%s</p>" % "<br>".join(e(x) for x in it["summary"]))
        parts.append("<p class=s>steps: %s</p>" % e(", ".join("%s %s" % kv for kv in it["states"].items())))
    if rep.get("errors"):
        done = sum(1 for x in rep["errors"] if x["state"] == "tested")
        parts += ["<h2>The errors: stage 1, stage 2 and their tests</h2>",
                  "<p>%d error%s; %d isolated (stage 1); %d with a cause and a solution (stage 2); %d with an approved test.</p>" % (
                      len(rep["errors"]), "" if len(rep["errors"]) == 1 else "s", sum(1 for x in rep["errors"] if x["state"] != "new"),
                      sum(1 for x in rep["errors"] if x["state"] in ("solved", "tested")), done),
                  table(["pattern", "where", "what was found", "where it stands", "test file"],
                        [[e(x["pattern"]), e(x["where"]), e(x["what"]), e(x["status"]), e(os.path.basename(x["test_file"])) if x["test_file"] else ""] for x in rep["errors"]])]
    if rep.get("other_errors"):
        parts += ["<h2>Errors in CSV files that are not part of the tree</h2>", "<p>%s</p>" % e(other_errors.CANNOT_DO),
                  table(["rule", "file (rows in it)", "rows found as errors", "errors with an isolation kept", "refused"],
                        [[e(x["rule"]), e(", ".join("%s (%s)" % (f, "{:,}".format(k)) for f, k in x["files"].items())), e("{:,}".format(x["total"])),
                          e(x["isolated"]), e(x["refused"] or "")] for x in rep["other_errors"]])]
    parts += ["<h2>Every step, in order</h2>",
              table(["family", "step", "state", "answered by", "decided by", "seconds"],
                    [[e(FAMILY_LABEL.get(s["family"], s["family"])), e(s["title"]), e(s["state"]), e(s["producer"]), e(s["decided_by"]), e(s["seconds"])] for s in rep["steps"]])]
    css = ("body{font-family:system-ui,sans-serif;margin:24px;max-width:1100px;color:#1d2128}table{border-collapse:collapse;margin:8px 0}"
           "td,th{border:1px solid #ccc;padding:3px 8px;font-size:13px;text-align:left;vertical-align:top}th{background:#f2f2f2}"
           "h2{margin-top:28px;border-bottom:1px solid #ddd}code{font-size:12px}.s{color:#666;font-size:12px}")
    return "<!doctype html><meta charset=utf-8><title>Flow report, run %s</title><style>%s</style>%s" % (e(rep["run"]), css, "\n".join(parts))
