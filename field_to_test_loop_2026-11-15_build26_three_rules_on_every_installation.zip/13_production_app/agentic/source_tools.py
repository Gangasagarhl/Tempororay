"""Which tool exported the recording (owner, 2026-11-12: "at the starting page ask whether the analysis is going on for Windows
ADK or Teledyne LeCroy or PCMark 10" and "there might not be need of building the hierarchy by combining many different CSVs
together, only it is needed for LeCroy Teledyne").

The tools are the ones the reference library lists (reference_library/index.json), in its order. The start page asks which one
exported the recording; the answer is kept with the analysis (project.source_tool: the library's key, the reserved value
ANOTHER, or nothing when it was not asked) and every step reads it as ctx.project.get("source_tool").

One more answer is always there (owner, 2026-11-14: "whichever the file format it is, I don't know what are the columns ...
that's why there are research agents and coding agents"): "Another tool, or I do not know". It is stored as ANOTHER
("another_tool"). The value is reserved: a library entry with that key is never listed here, so the value can only mean this
answer. No column list is compared with the folder for it at the start; family1.exported_by sees a value that is no library
tool and lets each file's own header decide, exactly as for an analysis with nothing stored.

  tools()                       every listed tool, in the words the start page shows
  another()                     the answer for a tool that is not listed or not known, in the words the start page shows
  check(value)                  a value from a request -> (key, None), nothing given -> (None, None), refused -> (None, why)
  name_of(key)                  the tool's name for a screen (a screen never shows the key)
  needs_hierarchy(project)      does the flow join the exports of this recording into one hierarchy
  no_hierarchy_reason(project)  the words a hierarchy step shows when it is not needed ("" when it is needed)
  looks_like(key, names)        does a file with these column names look like that tool's export (the library's own counting)
  folder_check(key, files)      the same for every file of a folder, each with one plain sentence
  recognised_from(files)        (2026-11-15) the tool recognised from the files' own headers: what the start route stores
  recognised_line(key)          the one plain line a screen shows for it ("Recognised from the files: ...")

Since 2026-11-15 the start page no longer asks the question (owner: "if it is looking at the column names ... if that is going
to help, then it's good ... Otherwise it is no need"): the start route stores the tool recognised from the files
(recognised_from). A request that still sends source_tool (older pages, tests) is accepted and checked as before.

Only what index.json says is used: "status" ("ready" = its column list is in the application) and "hierarchy" (true: several
exports of one recording are joined into one hierarchy; false: each export is one table, nothing to join)."""
import re

from . import column_knowledge

QUESTION = "Which tool exported the recording you want to analyse?"
WHY = ("Your answer is kept with the analysis. For a tool whose column list and reference document are in the application, the "
       "agents use that tool's reference for the meaning of the columns. For any other tool, or when you do not know the tool, "
       "choose the last answer: the agents then learn the columns from the files themselves. Nothing is chosen for you.")
ANOTHER = "another_tool"                # the stored value of the answer below; reserved: tools() never lists a library entry with this key
ANOTHER_CHOICE = "Another tool, or I do not know (the agents learn the columns from the files themselves)"
ANOTHER_NAME = "another tool, or one that is not known"        # after "recording exported by ..." on a screen
NOTES_ONLY = ("not available yet: only the notes on its export are in the application. Until its column list is in the application, "
              "choose \"Another tool, or I do not know\" for its files")
HIERARCHY_WORDS = {True: "the exports of one recording are joined into one hierarchy",
                   False: "one table per export: no hierarchy is built"}


def _why_not(t, lib):
    """One plain sentence when a tool cannot be chosen, worded from the library's own status; "" when it can."""
    status = re.sub(r"\s+", " ", str(t.get("status") or "")).strip()
    if status.lower() == "ready":
        return "" if t["key"] in lib.tools else "not available: its column list could not be read in this copy of the application"
    if status.lower().startswith("notes only"):
        return NOTES_ONLY
    return "not available yet: %s" % (status or "the reference library has no column list for it")


def tools(root=None):
    """Every tool the reference library lists, in the library's order ->
    [{"key", "name", "exports", "available", "sentence", "hierarchy", "hierarchy_words"}].
    available: it can be chosen on the start page; sentence: why not, when it cannot; hierarchy: True, False, or None when
    the library does not say (the flow then does what it did before the question existed: it builds the hierarchy)."""
    lib = column_knowledge.library(root)
    out = []
    for t in lib.listed:
        if not isinstance(t.get("key"), str) or not t["key"].strip() or t["key"].strip() == ANOTHER:
            continue                    # the reserved value is never a library tool: it always means "another tool, or not known"
        why = _why_not(t, lib)
        h = t.get("hierarchy") if isinstance(t.get("hierarchy"), bool) else None
        words = t.get("hierarchy_words") if isinstance(t.get("hierarchy_words"), str) and t["hierarchy_words"].strip() else ""
        out.append({"key": t["key"], "name": str(t.get("name") or t["key"]), "exports": str(t.get("exports") or ""),
                    "available": not why, "sentence": why, "hierarchy": h,
                    "hierarchy_words": "" if h is None else (words.strip() or HIERARCHY_WORDS[h])})
    return out


def _joined_tools(all_):
    """The names of the listed tools whose exports the fixed strategy joins into one hierarchy (the library's "hierarchy": true)."""
    return " and ".join(t["name"] for t in all_ if t["hierarchy"] is True) or "no tool of this copy of the application"


def another(root=None):
    """The answer for a tool that is not in the list, or that the admin does not know -> {"key", "name", "short", "sentence",
    "available": True}. The sentence says what the code then does: family1 gives every CSV file its three agents; exported_by
    lets each file's own header decide (CK.RECOGNISE_LEAST names and CK.RECOGNISE_SHARE of them, or no reference document);
    needs_hierarchy answers False, so the step after Family 1 does not offer the fixed joining strategy."""
    least, share = column_knowledge.RECOGNISE_LEAST, int(round(column_knowledge.RECOGNISE_SHARE * 100))
    return {"key": ANOTHER, "name": ANOTHER_CHOICE, "short": ANOTHER_NAME, "available": True, "sentence": (
        "The three data agents read every CSV file of the folder and propose what each column means; each meaning says where it "
        "comes from, or says that it has no source to check. The application's reference document of a tool is used only for a file whose own "
        "column names match that tool's column list (at least %d names and at least %d in 100 of them); for every other file "
        "none is used. The files are not joined into one hierarchy by the fixed strategy: it joins only the exports of %s. "
        "Rules can be written on each file." % (least, share, _joined_tools(tools(root))))}


def _shown(text):
    """A refused value as a message may show it: at most 80 characters, and none that cannot be printed."""
    return "".join(ch if ch.isprintable() else "?" for ch in text[:80])


def check(value, root=None):
    """The tool a request names. Nothing named (absent, null or empty) -> (None, None): the analysis keeps no tool and the Data
    Grounder recognises it from the column names. A listed tool that is ready -> (key, None). The reserved value ANOTHER
    (another tool, or not known) -> (ANOTHER, None). Anything else -> (None, why)."""
    if value is None or value == "":
        return None, None
    all_ = tools(root)
    can = ", ".join([t["name"] for t in all_ if t["available"]] + ["\"Another tool, or I do not know\""])
    if not isinstance(value, str):
        return None, "the tool that exported the recording must be given as text. The answers that can be chosen: %s" % can
    key = value.strip()
    if key == ANOTHER:
        return ANOTHER, None
    t = next((t for t in all_ if t["key"] == key), None)
    if t is None:
        return None, "\"%s\" is not a tool the application knows. The answers that can be chosen: %s" % (_shown(key), can)
    if not t["available"]:
        return None, "%s is %s. The answers that can be chosen: %s" % (t["name"], t["sentence"], can)
    return t["key"], None


def name_of(key, root=None):
    """The name a screen shows for a stored key; "" when nothing is stored or the library no longer lists the tool."""
    if not key:
        return ""
    if key == ANOTHER:
        return ANOTHER_NAME
    return next((t["name"] for t in tools(root) if t["key"] == key), "")


def needs_hierarchy(project, root=None):
    """Does the flow join the exports of this recording into one hierarchy? False only when the analysis names a tool and the
    library says that tool's export is one table ("hierarchy": false), or when the answer was "another tool, or not known"
    (ANOTHER: the fixed joining strategy is written for the exports of the tools the library marks "hierarchy": true). True when
    no tool was asked, when the library does not list it, or when the library says nothing about it: what the flow did before
    the question existed."""
    key = (project or {}).get("source_tool")
    if key == ANOTHER:
        return False
    t = next((t for t in tools(root) if t["key"] == key), None) if key else None
    return not (t is not None and t["hierarchy"] is False)


def no_hierarchy_reason(project, root=None):
    """The words a hierarchy step shows when it is not needed (the step is skipped, never failed); "" when it is needed."""
    if needs_hierarchy(project, root):
        return ""
    if (project or {}).get("source_tool") == ANOTHER:
        # (2026-11-15) the value is recognised from the files at the start; an analysis made before then may hold the answer
        # "Another tool, or I do not know" from the start page's former question
        return ("not done for this analysis: its files were not recognised as exports of %s (or, for an analysis made before "
                "15 November 2026, the answer on the start page was \"Another tool, or I do not know\"), and the fixed joining "
                "strategy joins only those exports. Start the same name on the same folder again from the start page: the "
                "files are looked at again and the tool is recognised from them" % _joined_tools(tools(root)))
    return "not needed for %s: its export is one table" % name_of((project or {}).get("source_tool"), root)


# ---------------------------------------------------------------------------------------------- does a file look like the chosen tool
def looks_like(key, names, root=None):
    """Does a file with these column names (the readers' names of ALL its columns) look like an export of the tool `key`?
    -> {"names", "found", "share", "looks"}, or None when `key` is not a tool with a column list (nothing can be compared).
    The counting is the reference library's own (Library.names_found) and the two limits are the ones it recognises a file
    by without any choice (column_knowledge.RECOGNISE_LEAST names and RECOGNISE_SHARE of them)."""
    lib = column_knowledge.library(root)
    if not key or key not in lib.tools:
        return None
    f = lib.names_found(key, [n for n in names or [] if isinstance(n, str)])
    f["looks"] = bool(f["found"] >= column_knowledge.RECOGNISE_LEAST and f["names"]
                      and f["found"] / float(f["names"]) >= column_knowledge.RECOGNISE_SHARE)
    return f


def folder_check(key, files, root=None):
    """Whether each CSV file of a folder looks like an export of the chosen tool, so that a wrong answer is seen before the flow
    starts. files: [{"name": file name, "columns": its column names, or None when its first line could not be read}].
    -> None when nothing can be compared (no tool chosen, "another tool", or a tool without a column list), else
    {"tool_name", "least", "in_100", "files": [{"name", "names", "found", "looks": True | False | None, "sentence"}],
     "doubt": [the files that do not look like it], "sentence": one sentence on the folder ("" when every file looks like it)}."""
    lib = column_knowledge.library(root)
    if not key or key == ANOTHER or key not in lib.tools:
        return None
    name = name_of(key, root) or lib.tools[key]["name"]
    least, in_100 = column_knowledge.RECOGNISE_LEAST, int(round(column_knowledge.RECOGNISE_SHARE * 100))
    out, doubt = [], []
    for f in files or []:
        fn = str(f.get("name") or "")
        got = looks_like(key, f["columns"], root) if isinstance(f.get("columns"), list) else None
        if got is None:
            out.append({"name": fn, "names": None, "found": None, "looks": None,
                        "sentence": "%s was not compared: its first line could not be read." % fn})
            continue
        n, found = got["names"], got["found"]
        many = "%d column name%s" % (n, "" if n == 1 else "s")
        if got["looks"]:
            words = "%s looks like an export of %s: %d of its %s are in that tool's column list." % (fn, name, found, many)
        elif not found:
            words = ("%s does not look like an export of %s: none of its %s is in that tool's column list. The agents will not "
                     "read it as that tool's export." % (fn, name, many))
        else:
            words = ("%s does not look like an export of %s: only %d of its %s %s in that tool's column list (an export of that "
                     "tool is recognised from at least %d names and at least %d in 100 of them). If you start with this answer "
                     "all the same, the agents read this file as a file of an unknown tool: no meaning is taken from that tool's "
                     "reference document for it."
                     % (fn, name, found, many, "is" if found == 1 else "are", least, in_100))
        if not got["looks"]:
            doubt.append(fn)
        out.append({"name": fn, "names": n, "found": found, "looks": got["looks"], "sentence": words})
    overall = ""
    if doubt:
        overall = ("%d of the %d CSV file%s in this folder %s not look like an export of %s (%s). If the recording comes from "
                   "another tool, choose \"Another tool, or I do not know\". If it does come from %s, tick the box under the "
                   "first question to start with it all the same." % (
                       len(doubt), len(out), "" if len(out) == 1 else "s", "does" if len(doubt) == 1 else "do", name,
                       ", ".join(doubt[:6]) + (" and %d more" % (len(doubt) - 6) if len(doubt) > 6 else ""), name))
    return {"tool_name": name, "least": least, "in_100": in_100, "files": out, "doubt": doubt, "sentence": overall}


# ---------------------------------------------------------------------------------------------- the tool, recognised from the files
# (owner, 2026-11-15: "are these things really needed? ... if it is looking at the column names which has been stored or early
# processed ... Otherwise it is no need". The start page no longer asks which tool exported the recording: the files say it.)
# Each file's header is compared with the reference library by the library's own recognition (Library.recognise: at least
# column_knowledge.RECOGNISE_LEAST names and RECOGNISE_SHARE of them in one tool's list), the same counting family1.exported_by
# uses for every file in a flow. Nothing here is a second definition of what a tool's export is.
UNKNOWN_FILE = "a CSV file of a tool the application has no column list for: the agents learn its columns from the file"


def recognised_from(files, root=None):
    """Which tool exported the CSV tables of a folder, from their own headers.
    files: [{"name": file name, "columns": its column names (the readers' names of all its columns), or None when its first
    line could not be read}].
    -> {"tool": the key of a ready library tool when every recognised file is that tool's export, else ANOTHER (also when no
        file is recognised); "tool_name": that tool's name for a screen; "files": [{"name", "tool", "tool_name", "names",
        "found", "sentence"}]; "sentence": one plain line, "Recognised from the files: ..."}.
    The value is what the start route stores as project.source_tool, so needs_hierarchy, no_hierarchy_reason and
    family1.exported_by read it as before. Two different ready tools in one folder: ANOTHER (each file's own header still
    decides for that file in Family 1, and the fixed joining strategy is not offered for a mixed folder)."""
    lib = column_knowledge.library(root)
    ready = {t["key"]: t["name"] for t in tools(root) if t["available"]}
    out, seen = [], []
    for f in files or []:
        fn = str(f.get("name") or "")
        names = [n for n in f["columns"] if isinstance(n, str)] if isinstance(f.get("columns"), list) else None
        if names is None:
            out.append({"name": fn, "tool": None, "tool_name": "", "names": None, "found": None,
                        "sentence": "%s: its first line could not be read, so the tool that exported it is not known." % fn})
            continue
        key, facts = lib.recognise(names)
        key = key if key in ready else None
        if key:
            seen.append(key)
            many = "%d column name%s" % (facts["names"], "" if facts["names"] == 1 else "s")
            words = "%s looks like an export of %s: %d of its %s are in that tool's column list." % (fn, ready[key], facts["found"], many)
        else:
            words = "%s is %s." % (fn, UNKNOWN_FILE)
        out.append({"name": fn, "tool": key, "tool_name": ready.get(key, ""), "names": facts["names"], "found": facts["found"],
                    "sentence": words})
    kinds = sorted(set(seen))
    tool = kinds[0] if len(kinds) == 1 else ANOTHER
    return {"tool": tool, "tool_name": name_of(tool, root), "files": out, "sentence": recognised_line(tool, len(seen), len(out), root)}


def recognised_line(key, matched=None, of=None, root=None):
    """The one plain line a screen shows for the tool kept with an analysis (key: project.source_tool)."""
    if key and key != ANOTHER and name_of(key, root):
        counted = (" (%d of the %d CSV table%s match that tool's column list)" % (matched, of, "" if of == 1 else "s")
                   if isinstance(matched, int) and isinstance(of, int) and of else "")
        return "Recognised from the files: an export of %s%s." % (name_of(key, root), counted)
    return ("Recognised from the files: no tool the application has a column list for, so the agents learn the columns from the "
            "files themselves, and the fixed joining strategy (written for the exports of %s) is not offered."
            % _joined_tools(tools(root)))
