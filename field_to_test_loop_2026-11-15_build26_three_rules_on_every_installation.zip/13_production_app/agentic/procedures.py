"""Procedures and their verified code (owner, 2026-11-09).

Every Family 3 item is shown as:
    Source data:          the file(s), with the full path in the open recording, and the columns used
    Rules or procedure:   numbered steps that say exactly what is done: which column, how its cell is parsed (format,
                          letter case), which hash map (key and value), which formula, what is output
    Buttons:              Edit rule/procedure (the JSON, edited by the admin) · Code it / Verified code · Run · Export CSV

The procedure is a JSON object kept in the item's rule file ("procedure"), versioned, editable by the admin:
    {"source_data": [{"file": "nvme_command.csv", "columns": ["OPC", "SQID"]}],
     "steps": ["...", "..."],
     "output": {"columns": ["command type", "count", "percent"], "order": "count, largest first"},
     "open_questions": ["..."]}

Code it: the Coder (an agent, Haiku at high effort) writes Python from the procedure, given what Family 1 knows of the
columns (meanings, the real cell formats from the file) -> the program checks it (it compiles, it imports only the
standard library, it runs on the recording, its output has the procedure's columns, the counts and percentages add up,
and where the item had an earlier plan, an independent count from the tree database agrees) -> the admin reviews it
(the chime sounds) -> approved, it is the VERIFIED code of that procedure version. A changed procedure needs new code.
The detector's items (Section 2) run the detector's own code (nvme_hier/rules.py), which is part of the application.
"""
import ast
import csv
import hashlib
import json
import os
import re
import sqlite3
import subprocess
import sys
import time

from . import csv_dialect as CD, family1, rule_evidence as E

APP = family1.APP
FILE_NAME = E.FILE_NAME
LEVEL_OF_FILE = {v: k for k, v in FILE_NAME.items()}
TREE = "the tree"           # the tree Family 2 built (owner, 2026-11-10): a procedure's source like a file; its code gets run(tree, out_csv) and nvme_hier.tree_api


def uses_tree(proc):
    return any(isinstance(s, dict) and s.get("file") == TREE for s in (proc or {}).get("source_data") or [])


def tree_column(c):
    """'link: Link Tra Error' -> ('link', 'Link Tra Error'); a column of the tree is named with its level."""
    lv, _, col = str(c).partition(":")
    return (lv.strip(), col.strip()) if col and lv.strip() in FILE_NAME else (None, str(c).strip())
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__", "getattr", "setattr", "delattr", "globals", "locals", "vars", "breakpoint", "input", "memoryview"}
ALLOWED_IMPORTS = {"csv", "re", "math", "collections", "decimal", "datetime", "statistics", "itertools", "json", "functools", "operator",
                   "nvme_hier", "nvme_hier.names", "nvme_hier.near_limit", "nvme_hier.command_error_rules"}
NVME_HIER_NAMES = ("names", "near_limit", "command_error_rules")        # what code may take from nvme_hier: the name lists, and the built-in item "close to the limit"
# What no Coder's code may reach (a model's, the stand-in's, an admin's): the application's reference implementation of the rule families of
# the NVMe command level, and the detector's code. The Tester compares a Coder's rows with that reference implementation (cross_check): code
# that calls it would be compared with itself. Only the application's own code text of such an item (application_code_file) may import it:
# check_code(..., application=True). The sentences go back to the Coder as they are.
REFERENCE_MODULE = "command_error_rules"
REFERENCE_REFUSAL = ("it calls or reads the application's reference implementation of the NVMe command level rules (nvme_hier/command_error_rules.py): the code "
                     "must find the rows itself from the tree, step by step as the procedure says, because the Tester compares its rows with that reference "
                     "implementation, and a comparison of the reference with itself shows nothing")
DETECTOR_REFUSAL = ("it calls or reads the detector's code (nvme_hier/rules.py): the code must do the procedure's steps itself; what the detector already "
                    "filed for a recording is read with tree.findings(...), and only where the procedure says so")
NO_STANDIN_FOR_FAMILY = ("no model answered, and the stand-in writes no code for a rule of the application's rule set for NVMe command level errors: with a model "
                         "connected its code is written from the rule's text, so that the Tester's comparison with the application's reference implementation shows "
                         "something. Ask again when the model answers; or choose no model in Settings: this rule then runs the application's reference implementation")
RUN_TIMEOUT_S = 4 * 3600         # a full run on a large recording (6 GB files are normal) may take long: it runs in the background
TRY_TIMEOUT_S = 120              # Try on a sample: the first records only, seconds at most
TRY_RECORDS = 1000
# the columns of a detector item's result (the SQL of family3.compile_rule, detection_rule)
DETECTOR_OUTPUT = ("defect", "level", "rule", "what was found", "severity", "number in its file", "time stamp (ps)", "command's file row", "data row in its file")
SAMPLE_ROWS = 20000          # rows read to show the Coder the real formats of a column (distinct values, at most 12 each)

# The procedures of the two analytics items, written from the real export's formats (S17: OPC "0x02 (Read)", SQID "3",
# NSID "1", SLBA "2097152", NLB "15" (0-based), Time Stamp "0000.400098983870s"; the header has 1,727 cells, empty and
# repeated names among them). They are drafts until the admin approves code made from them.
SEED_MARK = "seed"              # edited_by of a seeded procedure nobody has changed (it may be reworded by a later seed)
# Data analytics reads one CSV file on its own (owner, 2026-11-15: "it's okay to work only on the individual CSV ... not for the tree"):
# the first step of both seeds says so, and that the file is read as it is written (agentic/csv_dialect.py finds how).
ONE_FILE_STEP = ("Read nvme_command.csv on its own, row by row, as it is written (separator, character set and lines above the header as the "
                 "application's CSV reader finds them); the tree is not used. Find each column by its exact header name (first match).")
SEEDS = {
    "command_type_share": {
        "source_data": [{"file": "nvme_command.csv", "columns": ["OPC", "SQID"]}],
        "steps": [
            ONE_FILE_STEP,
            "OPC: take the hex number before the space (\"0x02 (Read)\" gives 2). Ignore the text in brackets. Nothing is lower-cased.",
            "SQID: a whole number. 0 is the admin queue; any other number is an I/O queue.",
            "Name the command from the NVMe opcode list: the admin list when SQID is 0, else the I/O list (2 on an I/O queue is \"Read\"). "
            "An unknown opcode is \"opcode 0xNN\"; an empty OPC is \"(blank)\".",
            "Count each name in a hash map: name -> number of rows.",
            "Total = the sum of all counts.",
            "Percent = count / total x 100, rounded to 3 decimals.",
        ],
        "output": {"columns": ["command type", "count", "percent"], "order": "largest count first"},
        "open_questions": [],
    },
    "read_pattern": {
        "source_data": [{"file": "nvme_command.csv", "columns": ["OPC", "SQID", "NSID", "SLBA", "NLB", "Time Stamp"]}],
        "steps": [
            ONE_FILE_STEP,
            "Keep only reads: OPC is 0x02 (the hex number before the space) and SQID is not 0. Skip rows with an empty SLBA or NLB.",
            "NSID, SLBA and NLB are whole numbers. NLB counts from 0, so a read covers NLB + 1 blocks.",
            "Time Stamp \"0000.400098983870s\" becomes picoseconds: seconds x 10^12 + the 12 digits.",
            # the analyzer writes its rows in time order (same time: file order); sorting the reads would mean holding them all in memory
            "Take the reads in the file's order, keeping in a hash map only the previous read of each NSID: NSID -> (Time Stamp, SLBA, NLB). "
            "A read earlier than the previous read of its NSID means the file is not in time order: stop and say so.",
            "In each group: the first read is \"first read of its namespace\"; a read whose SLBA = previous SLBA + previous NLB + 1 is "
            "\"sequential read\"; any other read is \"random read (RndRead)\".",
            "Count each kind. Percent = count / total reads x 100, rounded to 3 decimals.",
        ],
        "output": {"columns": ["kind of read", "count", "percent"], "order": "largest count first"},
        "open_questions": ["Reads on different queues of one namespace count as one stream. Is that right?",
                           "A read must start at exactly the next block to be sequential. Is a small gap allowed?"],
    },
}


def _near_limit():
    """The built-in analytics item "commands that completed but came close to the limit" (nvme_hier/near_limit.py holds its text, procedure and code)."""
    sys.path.insert(0, APP)
    from nvme_hier import near_limit as NL
    return NL


# The seeded procedures that read THE TREE, kept apart from SEEDS: tests/test_procedures.py states of every entry of SEEDS that it reads
# nvme_command.csv cell by cell, which is true of the two above and not of an item on the tree. family3.seed() writes both sets.
# (2026-11-15) "near_limit" needs each command's completion time, which is in the NVMe transaction file and not in the NVMe command file:
# Data analytics reads one CSV file only, so a new installation starts it in Deleted items (family3.seed); Restore brings it back.
TREE_SEEDS = {"near_limit": _near_limit().PROCEDURE}

# ---- Data analytics reads one CSV file on its own, never the tree (owner, 2026-11-15). The Errors section is not concerned: its rules read
# the tree, because their errors go on to the isolation, which needs the tree.
ANALYTICS_SECTION = "analytics"
ANALYTICS_TREE_REFUSAL = ("A rule of Data analytics reads one CSV file of the recording on its own, never the tree: name the level's own file "
                          "(for example nvme_command.csv) as its source data, with the columns as that file names them.")


def analytics_tree_problem(r, proc):
    """ANALYTICS_TREE_REFUSAL for an item of the section Data analytics whose procedure reads the tree, else ""."""
    if isinstance(r, dict) and r.get("section") == ANALYTICS_SECTION and isinstance(proc, dict) and uses_tree(proc):
        return ANALYTICS_TREE_REFUSAL
    return ""


# ------------------------------------------------------------------------------------------------ the procedure
def sha(proc):
    core = {k: proc.get(k) for k in ("source_data", "steps", "output")}
    return hashlib.sha256(json.dumps(core, sort_keys=True).encode()).hexdigest()[:16]


def detector_rule(r):
    """The detector's rule id of an item that still runs the detector's own code (its procedure was not changed)."""
    if r.get("kind") != "detection_rule":
        return None
    p = r.get("procedure")
    if p and not p.get("from_detector"):
        return None
    return (r.get("plan") or {}).get("rule")


# ---- items whose code is part of the application: the detector's rules, and the built-in items of APPLICATION_KINDS. Nothing of such an
# item is researched, asked or written by a Coder; its code is the application's own, tested with it, and is treated as verified for
# that reason. A next built-in item is one more line here (and its own function for the code text in application_code_text).
APPLICATION_KINDS = {"near_limit": "nvme_hier/near_limit.py",            # the item's kind -> the application's file that holds its code
                     "command_error": "nvme_hier/command_error_rules.py"}   # the rule families of the NVMe command level (owner, 2026-11-15)
# The items of kind "command_error" are meant to be coded by Family 4 from the rule's text (owner, 2026-11-15). Without a model that would
# stall a flow, so their code is then the application's reference implementation of the family (nvme_hier/command_error_rules.py).
# MODEL_CONNECTED says which case holds: a callable -> True when a model answers (set where the engine is made, for example
# procedures.MODEL_CONNECTED = lambda: runner.path_now() != "standin"). Not set, or False: the reference implementation, which is safe.
MODEL_CONNECTED = None
COMMAND_ERROR_WORDS = ("Its code is the application's reference implementation of this rule family (nvme_hier/command_error_rules.py), "
                       "used because no model is connected to write the code from the rule's text. With a model connected, Family 4 writes the code, "
                       "and the Tester compares its result with this reference implementation on the whole recording.")


def _command_errors():
    sys.path.insert(0, APP) if APP not in sys.path else None
    from nvme_hier import command_error_rules as CE
    return CE


def model_writes_the_code(r):
    """True for an item of the NVMe command level rule families while a model is connected: Family 4 then writes its code like for any rule
    of the admin's own (and the stand-in Coder, should the model not answer, has the reference implementation as its hand-written code)."""
    if not isinstance(r, dict) or r.get("kind") != "command_error" or not callable(MODEL_CONNECTED):
        return False
    try:
        return MODEL_CONNECTED() is True
    except Exception:       # noqa: BLE001 - not known: the safe case
        return False
APPLICATION_NOTHING = "this item runs code that is part of the application (%s): there is nothing to research, to ask or to code"
APPLICATION_VERIFIED = ("the application: this code is part of it (%s) and is tested with it, as the detector's code is; "
                        "no Coder wrote it and nobody approved it here")


def application_code(r):
    """Is this item's code part of the application? -> None, or {"what": "detector" or the item's kind, "file": the application's file,
    "rule": the detector's rule id (detector only), "skip": {"research", "req", "code": the sentence each step of Family 4 skips with}}.
    The one place the flow asks this question (Family 4's three steps, the Coder's step, the Tester, the result card).
    An item stays one only while its procedure is the application's own: a changed procedure is a rule of its own (store() gives it
    the kind "python"), and its code is then written by the Coder like any other."""
    if not isinstance(r, dict):
        return None
    rule = detector_rule(r)
    if rule:
        own = "this item runs the detector's own code, which is part of the application: there is nothing to "
        return {"what": "detector", "rule": rule, "file": "nvme_hier/rules.py",
                "skip": {"research": own + "research or code", "req": own + "code", "code": own + "code"}}
    f = APPLICATION_KINDS.get(r.get("kind")) if isinstance(r.get("kind"), str) else None
    if f and r.get("kind") == "command_error" and (model_writes_the_code(r) or not _command_errors().family_of_item(r)):
        f = None                                          # a model writes this item's code (Family 4), or the item names no family that can be run
    if f:
        words = APPLICATION_NOTHING % f
        return {"what": r["kind"], "file": f, "skip": {"research": words, "req": words, "code": words}}
    return None


def application_code_text(r):
    """The code text of an item of APPLICATION_KINDS, with what the item's plan states written into it -> (code, what was used).
    near_limit: the share of the host's limit from the plan (share_percent, share_set_by: the admin changes it by editing the item).
    The starting value is said as nobody's choice. A share that is not a share raises ValueError in plain words (near_limit.Refused)."""
    kind = r.get("kind")
    if kind == "command_error":                           # a rule family of the NVMe command level: the reference implementation of the family
        CE = _command_errors()
        fid = CE.family_of_item(r)
        if not fid:
            raise ValueError("this item names no rule family of the NVMe command level that can be run")
        return CE.code_for(fid), {"words": COMMAND_ERROR_WORDS, "family": fid, "is_default": True}
    if kind != "near_limit":
        raise ValueError("this item has no code that is part of the application")
    NL = sys.modules.get("nvme_hier.near_limit") or _near_limit()
    plan = r.get("plan") if isinstance(r.get("plan"), dict) else {}
    share, who = plan.get("share_percent"), plan.get("share_set_by")
    if who is not None and not isinstance(who, str):
        raise ValueError("The name of who set the share must be text. Edit the item and state it again.")
    who = " ".join((who or "").split())[:200]
    if share is None or (isinstance(share, str) and not share.strip()):
        share, who = None, None                                   # nothing stated: the starting value, said as nobody's choice
    elif not who or who == " ".join(NL.SET_BY_DEFAULT.split())[:200]:
        if isinstance(share, (int, float)) and not isinstance(share, bool) and share == NL.DEFAULT_SHARE_PERCENT:
            share, who = None, None                               # the plan still holds the starting value nobody chose
        else:
            who = "the admin who edited this item%s" % ((" (%s)" % " ".join(str(r["approved_by"]).split())[:80]) if r.get("approved_by") else " (no name was kept)")
    s = NL.share_of(share, who)                                   # refuses in plain words what is not a share
    return NL.code_for(share, who), s


def application_code_path(r, code):
    """Where the text of such an item's code is kept for the code runner: beside the Coder's files, named by the text itself (another share is another file)."""
    return os.path.join(family1.knowledge_dir(), "rules_code", str(r.get("section")), str(r.get("level")),
                        "%s.application.%s.py" % (r.get("id"), hashlib.sha256(code.encode("utf-8")).hexdigest()[:12]))


def application_state(r, app):
    """code_state() of an item of APPLICATION_KINDS: Python code that is verified because it is the application's own. A plan that cannot be
    used (a share that is not a share) gives no verified code, with the reason in "refused"."""
    proc = procedure_of(r) or {}
    out = {"kind": "python", "application": app["file"], "procedure_version": proc.get("version", 0), "code_for_version": proc.get("version", 0),
           "for_this_version": True, "by": "the application (%s)" % app["file"]}
    try:
        code, used = application_code_text(r)
    except ValueError as e:
        return dict(out, verified=False, refused=str(e), why="the item's plan cannot be used: %s" % e)
    try:
        at = os.path.getmtime(os.path.join(APP, *app["file"].split("/")))
    except OSError:
        at = None
    return dict(out, verified=True, path=application_code_path(r, code), verified_by=APPLICATION_VERIFIED % app["file"], verified_at=at, share=used)


def application_code_file(r):
    """The code step of an item of APPLICATION_KINDS, with no model and no Coder: the application's own code text is checked like every code
    (check_code) and written where the code runner takes it -> what the run step needs ({"kind": "python", "verified": True, "code_file", ...}).
    Raises ValueError in plain words when the item's plan cannot be used; nothing is written then."""
    app = application_code(r)
    if not app or app["what"] == "detector":
        raise ValueError("this item has no code that is part of the application")
    try:
        code, used = application_code_text(r)
    except ValueError as e:
        raise ValueError("'%s' was not run: what its plan states cannot be used. %s Edit the item, state it again, and run it again."
                         % (r.get("name"), e)) from None
    probs = check_code(code, tree=True, application=True)
    if probs:
        raise ValueError("'%s' was not run: the application's own code of this item did not pass the check every code passes (%s)" % (r.get("name"), "; ".join(probs)))
    path = application_code_path(r, code)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    cur = None
    if os.path.exists(path):
        with open(path, encoding="utf-8") as fh:
            cur = fh.read()
    if cur != code:                                               # written once per text; a file that was changed by hand is put right
        tmp = "%s.%d.part" % (path, os.getpid())
        with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(code)
        os.replace(tmp, path)
    proc = procedure_of(r) or {}
    return {"kind": "python", "verified": True, "application": app["file"], "code_file": path, "procedure_version": proc.get("version", 0),
            "verified_by": APPLICATION_VERIFIED % app["file"], "share": used, "why_skipped": "application code",
            "words": "The code of this item is part of the application (%s) and is tested with it: it is treated as verified for that reason, as the "
                     "detector's code is. No model was asked and no Coder wrote it. %s" % (app["file"], used["words"])}


def application_checks(r, out_csv, result):
    """The Tester's checks of the result of an item of APPLICATION_KINDS, made by the program apart from the run (the result file is read line by
    line). An empty list is a result of such an item, not a failure: the checks say what the summary says instead."""
    if r.get("kind") == "command_error":                  # the rows against the reference implementation, and a second count made another way
        return _command_errors().result_checks(out_csv, result)
    NL = sys.modules.get("nvme_hier.near_limit") or _near_limit()
    return NL.result_checks(out_csv, result)


def application_card(r, result):
    """What the result card of an item of APPLICATION_KINDS says under the Tester's checks -> (lines of the card, data for the page)."""
    if r.get("kind") == "command_error":
        return _command_errors().card_lines(result)
    NL = sys.modules.get("nvme_hier.near_limit") or _near_limit()
    return NL.card_lines(result)


def detector_procedure(r):
    """The procedure of a detector item, written from what the detector does (rule_evidence.READS) and why (BASIS)."""
    from nvme_hier import rules as RL
    rule = (r.get("plan") or {}).get("rule")
    reads, test = E.READS.get(rule, ([], ""))
    kind, text, ref = RL.BASIS.get(rule, ("", "", ""))
    files = {}
    for lv, sql in reads:
        cols = E.file_columns(lv, sql)
        f = files.setdefault(FILE_NAME[lv], [])
        for c in cols:                                   # a column the tree build makes is said in the first step instead
            if c not in f:
                f.append(c)
    own = FILE_NAME.get(r.get("level"), "")
    steps = []
    if any(sql in ("parent", "relation") for _lv, sql in reads):
        steps.append("Join the five files into one tree: each row is linked to its parent by IDs (queue + command ID, requester + tag, PSN), not by time.")
    head, *more = [x.strip() for x in test.split("\n") if x.strip()]     # a test written as lines gives one step per line
    first = head.split(" ", 1)[0]
    lead = head[0].lower() + head[1:] if first in ("The", "A", "An", "One", "For", "Only", "Each", "Every") else head   # column names keep their case
    steps.append("For each row of %s: %s" % (own, lead))
    steps += more
    steps.append("Each match is a defect, saved with its row number and its command.")
    if ref:
        steps.append("Why: %s. Source: %s" % (text.rstrip("."), RL.source_words(kind, ref).split(": ", 1)[-1]))
    return {"source_data": [{"file": f, "columns": c} for f, c in files.items()], "steps": steps,
            "output": {"columns": list(DETECTOR_OUTPUT), "order": "in the order the detector filed them"},
            "open_questions": [], "from_detector": True}


def other_csv_ok(name):
    """May a procedure name this file? "the tree", one of the five analyzer exports under its usual name, or any other CSV
    of the analysis's folder under its own name (owner, 2026-11-12: the input is not tied to the five exports). A plain
    file name only: never a path."""
    if name == TREE or name in LEVEL_OF_FILE:
        return True
    return isinstance(name, str) and bool(re.match(r"^[^\\/:*?\"<>|\x00-\x1f]{1,200}\.csv$", name, re.I)) and name.strip() == name and not name.startswith(".")


def procedure_of(r):
    """The item's procedure: the stored one, else the detector's (for its items), else None (no procedure yet)."""
    if r.get("procedure"):
        return r["procedure"]
    if r.get("kind") == "detection_rule" and (r.get("plan") or {}).get("rule"):
        return detector_procedure(r)
    if r.get("kind") in APPLICATION_KINDS and r.get("kind") in TREE_SEEDS:
        return dict(TREE_SEEDS[r["kind"]], version=1, edited_by=SEED_MARK)      # the application's own item, before seed() stored its procedure
    return None


def validate(proc):
    """The procedure as the admin may write it, checked: -> the clean dict, or ValueError naming every problem."""
    if not isinstance(proc, dict):
        raise ValueError("the procedure must be a JSON object { ... }")
    probs = []
    src = proc.get("source_data")
    if not isinstance(src, list) or not src:
        probs.append('"source_data" must be a list of {"file": ..., "columns": [...]} with at least one file')
        src = []
    clean_src = []
    for i, s in enumerate(src, 1):
        if not isinstance(s, dict) or not other_csv_ok(s.get("file")):
            probs.append('source_data %d: "file" must be "%s", one of %s, or the name of another CSV file of the analysis\'s folder (a plain name that ends in .csv)' % (
                i, TREE, ", ".join(FILE_NAME.values())))
            continue
        cols = s.get("columns") or []
        if not isinstance(cols, list) or not all(isinstance(c, str) and c.strip() for c in cols):
            probs.append('source_data %d: "columns" must be a list of column names' % i)
            continue
        if s["file"] == TREE and any(tree_column(c)[0] is None for c in cols):
            probs.append('source_data %d: a column of the tree is named with its level, for example "link: Link Tra Error" (levels: %s)' % (i, ", ".join(FILE_NAME)))
            continue
        clean_src.append({"file": s["file"], "columns": [c.strip() for c in cols]})
    steps = proc.get("steps")
    if not isinstance(steps, list) or not steps or not all(isinstance(x, str) and x.strip() for x in steps):
        probs.append('"steps" must be a list of sentences, at least one')
        steps = []
    out = proc.get("output") or {}
    ocols = out.get("columns") if isinstance(out, dict) else None
    if not isinstance(ocols, list) or not ocols or not all(isinstance(c, str) and c.strip() for c in ocols):
        probs.append('"output" must be {"columns": ["...", ...], "order": "..."}')
        ocols = []
    oq = proc.get("open_questions") or []
    if not isinstance(oq, list):
        probs.append('"open_questions" must be a list of sentences (it may be empty)')
        oq = []
    extra = set(proc) - {"source_data", "steps", "output", "open_questions", "version", "edited_by", "edited_at", "from_detector", "note"}
    if extra:
        probs.append("unknown field%s: %s" % ("s" if len(extra) > 1 else "", ", ".join(sorted(extra))))
    if probs:
        raise ValueError("; ".join(probs))
    return {"source_data": clean_src, "steps": [x.strip() for x in steps],
            "output": {"columns": [c.strip() for c in ocols], "order": (out.get("order") or "").strip()}, "open_questions": [str(x) for x in oq]}


def store(r, proc, admin, note=""):
    """A new version of the item's procedure (the earlier one goes to the history). A changed procedure needs new code."""
    clean = validate(proc)
    refused = analytics_tree_problem(r, clean)
    if refused:
        raise ValueError(refused)
    old = r.get("procedure") or procedure_of(r)
    if old and sha(old) == sha(clean) and r.get("procedure"):
        return r, False
    if old and sha(old) == sha(clean) and old.get("from_detector"):
        return r, False                                   # the detector's own procedure, saved unchanged: nothing to store
    v = int((r.get("procedure") or {}).get("version") or 0) + 1
    if r.get("procedure"):
        r.setdefault("history", []).append({"procedure": r["procedure"], "code": r.get("code")})
    clean.update(version=v, edited_by=admin, edited_at=time.time(), note=note)
    r["procedure"] = clean
    r["definition"] = " ".join("%d. %s" % (i, s) for i, s in enumerate(clean["steps"], 1))
    # a changed procedure is a rule of its own: its Python code is made from it (the detector's code, or an earlier SQL plan
    # used as the independent cross-check, described the procedure before the change; the plan stays in the history)
    r["kind"] = "python"
    r["status"], r["version"], r["approved_by"], r["approved_at"] = "approved", v, admin, time.time()
    return r, True


def code_state(r):
    """{"kind": detector|python|none, "verified": bool, ...} for the item's current procedure."""
    rule = detector_rule(r)
    if rule:
        c = E.code_of(rule) or {}
        return {"kind": "detector", "verified": True, "rule": rule, "path": c.get("path"),
                "lines": [(s["from"], s["to"]) for s in c.get("snippets", [])], "snippets": c.get("snippets", [])}
    app = application_code(r)
    if app:                                               # a built-in item whose code is part of the application (not the detector's)
        return application_state(r, app)
    proc = procedure_of(r)
    if not proc:
        return {"kind": "none", "verified": False, "why": "no procedure yet"}
    c = r.get("code") or {}
    ok = bool(c.get("verified_by") and c.get("procedure_sha") == sha(proc) and c.get("path") and os.path.exists(c["path"]))
    out = {"kind": "python", "verified": ok, "procedure_version": proc.get("version", 0)}
    if c:
        out.update({k: c.get(k) for k in ("path", "verified_by", "verified_at", "by")})
        out["code_for_version"] = c.get("procedure_version")         # the procedure version the stored code was made for
        out["for_this_version"] = c.get("procedure_sha") == sha(proc)
    return out


# ------------------------------------------------------------------------------------------------ the recording's files
_UPLOADS = [os.path.join(APP, "uploads")]         # the application's own uploads folder (create_app sets it)


def use_uploads_folder(path):
    _UPLOADS[0] = path


def upload_folder(upload_id):
    """The folder of one recording, or None for an id that is not a plain name (an id comes from a request)."""
    if not upload_id or not isinstance(upload_id, str) or not re.match(r"^[A-Za-z0-9_-][A-Za-z0-9_.-]*$", upload_id):
        return None
    return os.path.join(_UPLOADS[0], upload_id)


def source_paths(upload_id):
    """{file name: full path} of the recording's files (the upload's meta)."""
    d = upload_folder(upload_id)
    if not d:
        return {}
    try:
        with open(os.path.join(d, "meta.json"), encoding="utf-8") as fh:
            meta = json.load(fh)
    except (OSError, ValueError):
        return {}
    out = {FILE_NAME[k]: v for k, v in (meta.get("files") or {}).items() if v and k in FILE_NAME}
    db = os.path.join(d, "hier.sqlite")
    if meta.get("status") == "loaded" and os.path.exists(db):
        out[TREE] = db                          # the tree Family 2 built from these files
    return out


def folder_paths(folder):
    """{file name: full path} of the CSV files of an analysis's folder, as they are: every CSV under its own name, and an
    analyzer export of one of the five kinds also under its usual name (FILE_NAME). What a procedure on files reads when
    no tree was built for the analysis (stage 2 not chosen, or files that are not analyzer exports)."""
    out, usual = {}, {}
    for f in family1.inventory(folder) if folder else []:
        out[f["name"]] = f["path"]
        if f.get("level") in FILE_NAME:
            usual[FILE_NAME[f["level"]]] = f["path"]
    out.update(usual)
    return out


def recording_paths(upload_id, folder=None):
    """{file name: full path} for one analysis: the upload's files and its tree when one is linked, and the CSV files of
    the folder under their own names (never replacing a name the upload gave)."""
    out = dict(source_paths(upload_id)) if upload_id else {}
    for name, path in folder_paths(folder).items():
        out.setdefault(name, path)
    return out


FORM_LINES_SHOWN = 5           # lines above the header handed to a Coder, each cut at FORM_LINE_CHARS
FORM_LINE_CHARS = 200
STYLE_VALUES = 2000            # different values of one column counted in the first rows to tell how it writes its numbers


def file_form(path):
    """How this file is written (csv_dialect.detect: encoding, separator, header line). A file that cannot be read as a table:
    family1.L.BadFile with the one plain sentence that says what was seen."""
    d = CD.detect(path)
    if d["refused"]:
        raise family1.L.BadFile(d["refused"])
    return d


def open_rows(path, d=None):
    """-> (the open file, its rows from the header line on, how it is written). The one way a recording's file is read here:
    in its own encoding, with its own separator, the lines above its header skipped. Close the file when done."""
    d = d or file_form(path)
    fh = CD.open_text(path, d)
    try:
        return fh, CD.Rows(fh, path, d, bad=family1.L.BadFile), d
    except Exception:
        fh.close()
        raise


def written_for_coder(d):
    """How a file is written, as a Coder gets it in FILES: the record csv_dialect keeps, with the lines above the header cut
    short. None for a plain file (comma, UTF-8, header on line 1): nothing is added to what a Coder always got."""
    if not d or d.get("refused") or d.get("as_before"):
        return None
    return written_for_coder_record(CD.record(d))


def written_for_coder_record(rec):
    """The stored record of a file's form (csv_dialect.record) as a Coder gets it, the same shape as written_for_coder. None for none."""
    if not isinstance(rec, dict) or not rec.get("text"):
        return None
    enc, sep, head = (rec.get(k) if isinstance(rec.get(k), dict) else {} for k in ("encoding", "separator", "header"))
    out_sep = {"value": sep.get("value", ","), "name": sep.get("name", "comma"), "decided": bool(sep.get("decided", True))}
    if not out_sep["decided"]:
        out_sep["how"] = sep.get("how", "")
    line = int(head.get("line") or 1)
    return {"text": rec["text"], "encoding": {"value": enc.get("value"), "codec": enc.get("codec") or "utf-8-sig"}, "separator": out_sep,
            "header": {"line": line, "first_record_line": line + 1, "lines_before": [str(x)[:FORM_LINE_CHARS] for x in (head.get("lines_before") or [])[:FORM_LINES_SHOWN]],
                       "lines_before_count": int(head.get("lines_before_count") or 0)}}


def style_for_coder(style, basis=""):
    """How one column writes its numbers (csv_dialect.number_style), as a Coder gets it. None when the column has no style."""
    if not isinstance(style, dict) or not style.get("style"):
        return None
    out = {k: style.get(k) for k in ("style", "decimal_sign", "thousands_sign", "how", "examples", "min", "max", "min_as_written", "max_as_written") if k in style}
    out["read_as_a_number"] = style["style"] in ("decimal comma", "decimal point")
    if basis:
        out["counted_on"] = basis
    return out


def columns_info(path, names, rows=SAMPLE_ROWS):
    """For each column name: its first position in the header and up to 12 distinct values seen in the first rows
    (the real cell formats the Coder must parse). The file is read as it is written (its encoding, its separator, its
    header line); "_written_as" is added for a file that is not plain, and "number_style" for a column whose numbers are
    written with a decimal comma, a thousands sign, or in a way the first rows do not decide. A file that cannot be read
    as a table: "_error" holds the plain sentence and no column has a position."""
    out = {n: {"position": None, "samples": [], "rows_with_value": 0} for n in names}
    try:
        fh, rd, d = open_rows(path)
    except (OSError, family1.L.BadFile) as e:
        out["_error"] = str(e)
        return out
    counts = {}
    try:
        with fh:
            head = next(rd, [])
            for n in names:
                if n in head:
                    out[n]["position"] = head.index(n)
                    counts[n] = {}
            out["_header_cells"] = len(head)
            k = 0
            for row in rd:
                k += 1
                for n in names:
                    i = out[n]["position"]
                    if i is not None and i < len(row) and row[i] != "":
                        out[n]["rows_with_value"] += 1
                        v = row[i]
                        if len(out[n]["samples"]) < 12 and v not in out[n]["samples"]:
                            out[n]["samples"].append(v)
                        c, vs = counts[n], v.strip()
                        if vs in c:
                            c[vs] += 1
                        elif vs and len(c) < STYLE_VALUES:
                            c[vs] = 1
                if k >= rows:
                    break
            out["_rows_scanned"] = k
    except OSError as e:
        out["_error"] = str(e)
        return out
    form = written_for_coder(d)
    if form:
        out["_written_as"] = form
    for n, c in counts.items():
        style = style_for_coder(CD.number_style(c), "the first %d rows" % out["_rows_scanned"])
        if style:
            out[n]["number_style"] = style
    return out


SAMPLE_MAX_SHOW = 200          # records shown on the page at once
SAMPLE_MAX_EXPORT = 100000     # records in one sample export


def sample_rows(path, columns=None, from_line=2, count=20):
    """Records of a source file as they are in the file, from a line number on (the file's own numbering: the header is on
    the line the file's form says, line 1 for a plain file, and the first record is on the next line; a record that spans
    lines is counted by the line it starts on). The file is read as it is written (encoding, separator, header line).
    columns: the column names to keep (first match in the header), or None for every column.
    -> {"header": [...], "rows": [[line, cell, ...], ...], "next_line": the line after the last record given, or None at the end;
        and for a file that is not plain "written_as": the sentence that says how it is written}
    A file that cannot be read as a table: family1.L.BadFile (a ValueError) with the plain sentence."""
    fh, rd, d = open_rows(path)
    before = d["header_line"] - 1                # lines above the header: rd counts its lines from the header line on
    first = d["header_line"] + 1
    from_line, count = max(first, int(from_line or first)), max(1, int(count or 1))
    more = {} if d["as_before"] else {"written_as": CD.record(d)["text"], "header_line": d["header_line"]}
    with fh:
        head = next(rd, [])
        if columns:
            missing = [c for c in columns if c not in head]
            if missing:
                raise ValueError("the file has no column %s" % ", ".join(missing))
            pos = [head.index(c) for c in columns]
            out_head = list(columns)
        else:
            pos, out_head = None, list(head)
        rows, start = [], rd.line_num + before + 1
        for row in rd:
            if start >= from_line:
                cells = [row[i] if i < len(row) else "" for i in pos] if pos is not None else row
                rows.append([start] + cells)
                if len(rows) >= count:
                    nxt = rd.line_num + before + 1
                    return dict({"header": ["line"] + out_head, "rows": rows, "next_line": nxt}, **more)
            start = rd.line_num + before + 1
    return dict({"header": ["line"] + out_head, "rows": rows, "next_line": None}, **more)


# ------------------------------------------------------------------------------------------------ the code
def _module_reached(node, aliases):
    """The module object an expression of a code text names, when it is a chain of plain attributes from a name the code imported from
    nvme_hier (names.x, nvme_hier.near_limit.RL, ...), else None. Nothing of the code text is run: the application's own modules are looked at."""
    import types
    if isinstance(node, ast.Name):
        return aliases.get(node.id)
    if isinstance(node, ast.Attribute):
        base = _module_reached(node.value, aliases)
        got = getattr(base, node.attr, None) if base is not None else None
        return got if isinstance(got, types.ModuleType) else None
    return None


def check_code(code, tree=False, application=False, analytics=False):
    """Problems of a code text before it runs: it must compile, import only the allowed modules, and define run(). With tree=True (a procedure on
    the tree): run(tree, out_csv), and no file is opened but the output (the raw CSV files are not there to read).
    application=True only for the application's own code text of a built-in item (application_code_file). Every other text (a model's, the
    stand-in's) is refused when it imports, names or reads the reference implementation of the NVMe command level rules or the detector's
    code, by whatever way: REFERENCE_REFUSAL / DETECTOR_REFUSAL say why in a sentence the Coder gets back.
    analytics=True for an item of the section Data analytics: code on the tree (tree=True) is refused with ANALYTICS_TREE_REFUSAL."""
    probs = [ANALYTICS_TREE_REFUSAL] if analytics and tree else []
    try:
        parsed = ast.parse(code)
    except SyntaxError as e:
        return ["it does not compile: %s (line %s)" % (e.msg, e.lineno)]
    tree_ = parsed.body
    reference = [False, False]          # the text reaches the reference implementation / the detector's code
    aliases = {}                        # a name the text binds to a module of nvme_hier -> that module (for the attribute chains below)

    def bind(name, module):
        import importlib
        try:
            aliases[name] = importlib.import_module(module)
        except Exception:      # noqa: BLE001 - a module that is not there is refused as an import anyway
            pass
    for node in ast.walk(parsed):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name not in ALLOWED_IMPORTS:
                    probs.append("imports %s (allowed: %s)" % (a.name, ", ".join(sorted(ALLOWED_IMPORTS))))
                if a.name.split(".")[0] == "nvme_hier":
                    reference[0] |= a.name.split(".")[-1] == REFERENCE_MODULE
                    reference[1] |= a.name == "nvme_hier.rules"
                    if a.name in ALLOWED_IMPORTS:
                        bind(a.asname or "nvme_hier", a.name if a.asname else "nvme_hier")
        elif isinstance(node, ast.ImportFrom):
            if (node.module or "") not in ALLOWED_IMPORTS:
                probs.append("imports from %s (allowed: %s)" % (node.module, ", ".join(sorted(ALLOWED_IMPORTS))))
            elif node.module == "nvme_hier" and any(a.name not in NVME_HIER_NAMES for a in node.names):
                probs.append("imports from nvme_hier something other than names")
            if (node.module or "").split(".")[0] == "nvme_hier":
                reference[0] |= (node.module or "").split(".")[-1] == REFERENCE_MODULE or (node.module == "nvme_hier" and any(a.name == REFERENCE_MODULE for a in node.names))
                reference[1] |= node.module == "nvme_hier.rules" or (node.module == "nvme_hier" and any(a.name == "rules" for a in node.names))
                if node.module == "nvme_hier":
                    for a in node.names:
                        if a.name in NVME_HIER_NAMES:
                            bind(a.asname or a.name, "nvme_hier." + a.name)
        elif isinstance(node, ast.Constant) and isinstance(node.value, (str, bytes)):
            text = node.value if isinstance(node.value, str) else node.value.decode("utf-8", "replace")
            reference[0] |= REFERENCE_MODULE in text          # a path, or a name handed to something that imports or reads by name
        elif isinstance(node, ast.Name) and node.id == REFERENCE_MODULE:
            reference[0] = True
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALLS:
            probs.append("calls %s()" % node.func.id)
        elif isinstance(node, ast.Attribute) and node.attr.startswith("_"):
            probs.append("reaches the hidden attribute %s" % node.attr)
        elif isinstance(node, ast.Name) and node.id.startswith("__"):
            probs.append("reaches %s" % node.id)
    for node in ast.walk(parsed):       # a second pass, when every imported name is known: one module reached through another
        if isinstance(node, ast.Attribute):
            reference[0] |= node.attr == REFERENCE_MODULE
            got = _module_reached(node, aliases)
            if got is not None:
                name = getattr(got, "__name__", "")
                reference[0] |= name.split(".")[-1] == REFERENCE_MODULE
                reference[1] |= name == "nvme_hier.rules"
                if name not in ALLOWED_IMPORTS or (name.split(".")[-1] == REFERENCE_MODULE and not application):
                    probs.append("reaches the module %s through another module (%s): only what a module itself defines may be used" % (name, ast.unparse(node)[:80]))
    if reference[0] and not application:
        probs.append(REFERENCE_REFUSAL)
    if reference[1]:
        probs.append(DETECTOR_REFUSAL)
    calls = {id(n.func) for n in ast.walk(parsed) if isinstance(n, ast.Call)}
    for node in ast.walk(parsed):
        if isinstance(node, ast.Name) and node.id == "open" and id(node) not in calls:
            probs.append("uses open other than by calling it")
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "open":
            mode = node.args[1] if len(node.args) > 1 else next((k.value for k in node.keywords if k.arg == "mode"), None)
            writing = not (mode is None or (isinstance(mode, ast.Constant) and isinstance(mode.value, str) and not set(mode.value) & set("wax+")))
            target = node.args[0] if node.args else None
            if writing and not (isinstance(target, ast.Name) and target.id == "out_csv"):
                probs.append("opens a file for writing other than out_csv")
            if tree and not (isinstance(target, ast.Name) and target.id == "out_csv"):
                probs.append("opens a file other than out_csv: a procedure on the tree reads the tree only (tree.rows, tree.children ...), never the CSV files")
    runs = [n for n in tree_ if isinstance(n, ast.FunctionDef) and n.name == "run"]
    want = ["tree", "out_csv"] if tree else ["sources", "out_csv"]
    if not runs:
        probs.append("it has no function run(%s)" % ", ".join(want))
    elif len(runs[0].args.args) != 2:
        probs.append("its run() must take two values (%s), not (%s)" % (", ".join(want), ", ".join(a.arg for a in runs[0].args.args)))
    return probs


RUN_MEMORY_BYTES = 8 * 1024 ** 3            # a recording is read line by line: more memory than this means the code loads it whole
RUN_PRINT_BYTES = 20 * 1024 ** 2            # the result goes to the output CSV; this much printing is a mistake
RUN_TAIL_BYTES = 1024 ** 2                  # the end of what it printed, which holds its result line
RUN_MIN_FILE_BYTES = 2 * 1024 ** 3          # the output CSV may be this big, or twice the source files if that is more

RUNNER = r'''
import importlib.util, json, sys, time
try:
    import resource
except ImportError:          # Windows has no resource module: the memory limit is set by hold_memory() below, the size of the output file is watched by the program that started this one
    resource = None
sys.path.insert(0, %(app)r)
with open(sys.argv[1], encoding="utf-8") as _fh:
    args = json.load(_fh)


def hold_memory(limit):
    """Windows only: a job object holds this process to the memory limit, as RLIMIT_AS does on Linux (an allocation past it fails with MemoryError). False where Windows refuses it."""
    try:
        import ctypes
        from ctypes import wintypes
        k = ctypes.WinDLL("kernel32", use_last_error=True)

        class Basic(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64), ("LimitFlags", wintypes.DWORD),
                        ("MinimumWorkingSetSize", ctypes.c_size_t), ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                        ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD)]

        class Extended(ctypes.Structure):
            _fields_ = [("BasicLimitInformation", Basic), ("IoInfo", ctypes.c_uint64 * 6), ("ProcessMemoryLimit", ctypes.c_size_t),
                        ("JobMemoryLimit", ctypes.c_size_t), ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]
        k.CreateJobObjectW.restype = wintypes.HANDLE
        k.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
        k.GetCurrentProcess.restype = wintypes.HANDLE
        k.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
        k.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        job = k.CreateJobObjectW(None, None)
        if not job:
            return False
        info = Extended()
        info.BasicLimitInformation.LimitFlags = 0x100                                          # JOB_OBJECT_LIMIT_PROCESS_MEMORY
        info.ProcessMemoryLimit = int(limit)
        if not k.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)):     # 9 = JobObjectExtendedLimitInformation
            return False
        return bool(k.AssignProcessToJobObject(job, k.GetCurrentProcess()))
    except Exception:
        return False


if resource is not None:
    resource.setrlimit(resource.RLIMIT_AS, (args["memory"], args["memory"]))
    resource.setrlimit(resource.RLIMIT_FSIZE, (args["file_size"], args["file_size"]))
elif sys.platform == "win32":
    hold_memory(args["memory"])


def confine():
    """The operating system itself holds this process to the recording's files, its own folder and the Python it needs, and blocks the network (Linux Landlock). The checks on
    the code's text cannot do this: a chain of ordinary attributes (a module that imports another) reaches anything. Where the kernel has no Landlock, False, and the check on open() below is what is left."""
    import ctypes, os
    if not sys.platform.startswith("linux") or not hasattr(os, "O_PATH"):
        return False                     # Landlock is Linux only: on Windows the check on open() below and the checks on the code's text are what holds the code
    libc = ctypes.CDLL(None, use_errno=True)
    create, add, restrict = 444, 445, 446
    version = libc.syscall(create, None, 0, 1)
    if version < 1:
        return False

    class Attr(ctypes.Structure):
        _fields_ = [("fs", ctypes.c_uint64), ("net", ctypes.c_uint64)]

    class Beneath(ctypes.Structure):
        _pack_ = 1
        _fields_ = [("allowed", ctypes.c_uint64), ("fd", ctypes.c_int32)]
    every_fs = (1 << 13) - 1
    read_tree = 1 | (1 << 2) | (1 << 3)
    read_file = 1 | (1 << 2)
    attr = Attr(every_fs, 3 if version >= 4 else 0)
    rules = libc.syscall(create, ctypes.byref(attr), ctypes.sizeof(Attr) if version >= 4 else 8, 0)
    if rules < 0:
        return False

    def allow(path, rights):
        try:
            fd = os.open(path, os.O_PATH | os.O_CLOEXEC)
        except OSError:
            return
        rule = Beneath(rights, fd)
        libc.syscall(add, rules, 1, ctypes.byref(rule), 0)
        os.close(fd)
    for tree in {sys.prefix, sys.base_prefix, "/usr", "/lib", "/lib64", "/etc", APP_DIR + "/nvme_hier"}:
        allow(tree, read_tree)
    for one in list(args["sources"].values()) + [args["code"]]:
        allow(one, read_file)
        for side in (one + "-wal", one + "-shm"):          # the tree is read in its write-ahead-log mode: its two side files are read too
            if args.get("tree") == one and os.path.exists(side):
                allow(side, read_file)
    for tree in {os.getcwd(), os.path.dirname(os.path.abspath(args["out_csv"]))}:
        allow(tree, every_fs)
    libc.prctl(38, 1, 0, 0, 0)
    done = libc.syscall(restrict, rules, 0) == 0
    os.close(rules)
    return done


APP_DIR = sys.path[0]
confined = confine()


def only_its_own_files():
    """The second line, and the only one on a kernel without Landlock: open() refuses everything but the recording's files and the code's own folders."""
    import builtins, os
    real_open = builtins.open
    may = {os.path.realpath(x) for x in args["sources"].values()} | {os.path.realpath(args["code"])}
    if args.get("tree"):
        may = {os.path.realpath(args["code"])}             # a procedure on the tree opens no file itself: the tree library reads the database
    here = os.path.realpath(".") + os.sep
    out = os.path.dirname(os.path.realpath(args["out_csv"])) + os.sep

    def open_checked(file, *a, **k):
        if isinstance(file, (str, bytes, os.PathLike)):
            path = os.path.realpath(file)
            if isinstance(path, bytes):
                path = path.decode(errors="replace")
            if path not in may and not path.startswith(here) and not path.startswith(out):
                raise PermissionError("this code may open only the recording's files and its own output, not " + path)
        return real_open(file, *a, **k)
    builtins.open = open_checked


only_its_own_files()
if not args.get("application"):
    # a Coder's code (a model's, the stand-in's): the application's reference implementation of the NVMe command level rules cannot be imported
    # by any way (import, importlib, __import__): the Tester compares the code's rows with it, and code that calls it would be compared with itself
    sys.modules["nvme_hier.command_error_rules"] = None
spec = importlib.util.spec_from_file_location("item_code", args["code"])
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
t0 = time.time()
if args.get("tree"):
    from nvme_hier import tree_api
    tree = tree_api.Tree(args["tree"], args.get("meanings") or {}, immutable=bool(args.get("tree_immutable")))
    summary = m.run(tree, args["out_csv"])
    print(json.dumps({"summary": summary, "seconds": round(time.time() - t0, 2), "tree_calls": dict(tree.calls)}, default=str))
else:
    summary = m.run(args["sources"], args["out_csv"])
    print(json.dumps({"summary": summary, "seconds": round(time.time() - t0, 2)}, default=str))
'''


def _tail(path, size=RUN_TAIL_BYTES):
    """The end of a file, however large it grew."""
    with open(path, "rb") as fh:
        fh.seek(0, os.SEEK_END)
        fh.seek(max(0, fh.tell() - size))
        return fh.read().decode("utf-8", errors="replace")


def read_positions(pid, paths):
    """{path: bytes read so far} for the files a process has open, from /proc/<pid>/fdinfo (Linux): how far the code has
    read into each source file, without any change to the code itself."""
    out = {}
    want = {os.path.realpath(x): x for x in paths}
    try:
        fds = os.listdir("/proc/%d/fd" % pid)
    except OSError:
        return out
    for fd in fds:
        try:
            target = os.path.realpath(os.readlink("/proc/%d/fd/%s" % (pid, fd)))
            if target in want:
                with open("/proc/%d/fdinfo/%s" % (pid, fd), encoding="utf-8") as fh:
                    for line in fh:
                        if line.startswith("pos:"):
                            out[want[target]] = max(out.get(want[target], 0), int(line.split()[1]))
        except (OSError, ValueError):
            continue
    return out


from .core import fmt_bytes as _fmt_b, fmt_secs as _fmt_s, progress_text   # noqa: E402  (one progress format for every step)


def _memory_for_code():
    """What one run of an agent's code may use: the usual limit, or less when the machine has less to spare, so that the other programs keep theirs."""
    room = family1.L.memory_available()
    if room is None:
        return RUN_MEMORY_BYTES
    return max(1024 ** 3, min(RUN_MEMORY_BYTES, room - family1.L.keep_for_others()))


class TreeLock:
    """One tree, many readers, one writer (2026-11-15). A code run reads the tree's database file from a process of its own, opened as a file
    that cannot change ("immutable": the confined process may not write the side files SQLite's usual read needs). Since 2026-11-15 the errors
    step of a rule WRITES into the tree (nvme_hier/coded_findings.py files the rows a rule found). Two analyses of one recording can run at
    the same time and share its tree: a write, or the folding of the write-ahead log into the main file, while another run reads that file
    as unchangeable is undefined for the reader. So: any number of code runs read together; filing errors waits until none reads, and no
    new reader starts while a writer waits or works; the log is folded only when nobody reads. One lock per tree file, inside this process
    (the engine's threads): the application is one process."""

    def __init__(self):
        import threading
        self._cv = threading.Condition()
        self._readers, self._writer, self._waiting = 0, False, 0

    def read_begin(self, fold=None):
        """-> what fold() gave when the log could be folded now (nobody else reads), else None."""
        with self._cv:
            while self._writer or self._waiting:
                self._cv.wait(0.5)
            got = fold() if fold is not None and self._readers == 0 else None
            self._readers += 1
            return got

    def read_end(self):
        with self._cv:
            self._readers = max(0, self._readers - 1)
            self._cv.notify_all()

    def write_begin(self, waiting=None):
        with self._cv:
            self._waiting += 1
            try:
                while self._writer or self._readers:
                    if waiting:
                        waiting()
                    self._cv.wait(0.5)
                self._writer = True
            finally:
                self._waiting -= 1

    def write_end(self):
        with self._cv:
            self._writer = False
            self._cv.notify_all()


_TREE_LOCKS = {}
_TREE_LOCKS_GUARD = __import__("threading").Lock()
WAITS_FOR_READERS = "waiting until the code runs that read this recording's tree have finished: the errors are filed then"


def tree_lock(db):
    with _TREE_LOCKS_GUARD:
        return _TREE_LOCKS.setdefault(os.path.realpath(db), TreeLock())


def write_tree(db, work, waiting=None):
    """Run work() while nothing reads the tree as an unchangeable file, then fold what it wrote into the main file -> what work() returned."""
    lock = tree_lock(db)
    lock.write_begin(waiting)
    try:
        return work()
    finally:
        try:
            _fold_wal(db)
        finally:
            lock.write_end()


def run_code(code_path, sources, out_csv, box, timeout=RUN_TIMEOUT_S, progress=None, poll=1.0, application=False):
    """application=True only for the application's own code text of a built-in item: every other code runs in a process in which the
    reference implementation of the NVMe command level rules cannot be imported (see check_code).
    A run on the tree holds the tree as a reader for as long as its process lives (TreeLock).
    Runs the code's run(sources, out_csv) in its own Python process (isolated mode, the sandbox as folder). While it
    runs, progress(info) is called every second with how far it has read into the source files:
    {"percent", "read", "total", "file", "elapsed", "left", "text"}. poll: how often the process is looked at, in seconds
    (Family 4 runs many very small data sets one after the other and looks more often, so each takes a fraction of a second)."""
    db = sources.get(TREE)
    if not db:
        return _run_code(code_path, sources, out_csv, box, timeout, progress, poll, application, False)
    lock = tree_lock(db)
    folded = lock.read_begin(lambda: _fold_wal(db))
    try:
        if folded is None:              # another run reads the file now: the log is not folded under it; it is read as unchangeable only when the log is empty
            wal = db + "-wal"
            folded = not os.path.exists(wal) or os.path.getsize(wal) == 0
        return _run_code(code_path, sources, out_csv, box, timeout, progress, poll, application, bool(folded))
    finally:
        lock.read_end()


def _run_code(code_path, sources, out_csv, box, timeout, progress, poll, application, tree_immutable):
    """run_code without the tree's lock: the process itself, watched until it ends."""
    os.makedirs(box, exist_ok=True)
    runner = os.path.join(box, "runner.py")
    with open(runner, "w", encoding="utf-8") as fh:
        fh.write(RUNNER % {"app": APP})
    args = os.path.join(box, "args.json")
    sizes = {p: os.path.getsize(p) for p in sources.values() if os.path.exists(p)}
    total = sum(sizes.values()) or 1
    file_limit = max(RUN_MIN_FILE_BYTES, 2 * total)
    memory_limit = _memory_for_code()
    with open(args, "w", encoding="utf-8") as fh:
        json.dump({"code": code_path, "sources": sources, "out_csv": out_csv, "memory": memory_limit, "file_size": file_limit, "application": bool(application),
                   "tree": sources.get(TREE), "meanings": tree_meanings() if sources.get(TREE) else None,
                   "tree_immutable": tree_immutable}, fh)
    out_p, err_p = os.path.join(box, "stdout.txt"), os.path.join(box, "stderr.txt")
    t0 = time.time()
    seen = set()                                 # source files the code has opened; one opened before and closed now is read to the end
    with open(out_p, "w", encoding="utf-8") as fo, open(err_p, "w", encoding="utf-8") as fe:
        # -X utf8: files the code opens without an encoding, and what it prints, are UTF-8 on every system (on Windows they would be cp1252)
        proc = subprocess.Popen([sys.executable, "-I", "-X", "utf8", runner, args], cwd=box, stdout=fo, stderr=fe)
        last = -1
        while proc.poll() is None:
            if time.time() - t0 > timeout:
                proc.kill()
                proc.wait()
                return {"ok": False, "error": "it ran longer than %s and was stopped" % _fmt_s(timeout)}
            time.sleep(poll)
            if os.path.getsize(out_p) + os.path.getsize(err_p) > RUN_PRINT_BYTES:
                proc.kill()
                proc.wait()
                return {"ok": False, "error": "it printed more than %d MB and was stopped: the result goes to the output CSV, not to the screen" % (RUN_PRINT_BYTES // 1024 ** 2)}
            try:                                 # Windows has no file-size limit for a process; on Linux the kernel stops the write at the limit, so this never comes true there
                too_big = os.path.getsize(out_csv) > file_limit
            except OSError:
                too_big = False
            if too_big:
                proc.kill()
                proc.wait()
                return {"ok": False, "error": "it wrote more than %d GB to one file and was stopped" % (file_limit // 1024 ** 3)}
            if progress is None:
                continue
            pos = read_positions(proc.pid, list(sizes))
            seen.update(pos)
            read = sum(min(pos[p], sizes[p]) if p in pos else (sizes[p] if p in seen else 0) for p in sizes)
            pct = min(99.9, 100.0 * read / total)
            el = time.time() - t0
            cur = next((p for p in sizes if p in pos), None)
            left = el * (100 - pct) / pct if pct >= 1 else None
            text = progress_text(pct, t0, what=os.path.basename(cur) if cur and len(sizes) > 1 else "", done=read, total=total)
            if int(pct * 10) != last:
                last = int(pct * 10)
                progress({"percent": round(pct, 1), "read": read, "total": total, "file": os.path.basename(cur) if cur else None,
                          "elapsed": round(el), "left": round(left) if left is not None else None, "text": text})
    out, err = _tail(out_p), _tail(err_p)
    if proc.returncode != 0:
        if "MemoryError" in err:
            return {"ok": False, "error": "it needed more than %d GB of memory and was stopped: the code must read the files line by line" % (memory_limit // 1024 ** 3)}
        if "File too large" in err:
            return {"ok": False, "error": "it wrote more than %d GB to one file and was stopped" % (file_limit // 1024 ** 3)}
        return {"ok": False, "error": (err or out or "exit %d" % proc.returncode).strip()[-1500:]}
    try:
        res = json.loads(out.strip().splitlines()[-1])
    except (ValueError, IndexError):
        return {"ok": False, "error": "it printed no result: %s" % (out or err)[-500:]}
    return dict(res, ok=True, seconds_total=round(time.time() - t0, 1))



def open_like(dst, path, d=None):
    """A new file dst, opened for writing a table in the form of the file at path (d: its csv_dialect.detect): the same
    encoding with its byte order mark, and the lines above the header copied first. The caller writes the header row and
    the rows with csv.writer(fo, delimiter=d["separator"]). For a plain file: plain UTF-8, nothing written yet, as always."""
    d = d or file_form(path)
    plain = d["as_before"] or (d["codec"] == "utf-8-sig" and d["separator"] == "," and d["header_line"] == 1)
    fo = open(dst, "w", newline="", encoding="utf-8" if plain or d["codec"] == "utf-8-sig" else d["codec"])
    try:
        if not plain:
            if d["bom_bytes"]:
                fo.write("\ufeff")            # the byte order mark, as the file has it
            if d["header_line"] > 1:         # the lines above the header, as they stand in the file
                with CD.open_text(path, d) as top:
                    for i in range(d["header_line"] - 1):
                        line = top.readline(CD.MAX_LINE_CHARS)
                        fo.write(line[1:] if i == 0 and line.startswith("\ufeff") else line)
    except Exception:
        fo.close()
        raise
    return fo


def sample_sources(sources, box, records=TRY_RECORDS):
    """Copies of the source files with the header and the first records only (for Try on a sample): instant on any size.
    Each copy is written in its file's own form: the same encoding (with its byte order mark), the same separator, and the
    lines above the header copied first, so code that reads the sample rightly reads the real file rightly. A plain file's
    copy is plain, as it always was. A file that cannot be read as a table: family1.L.BadFile with the plain sentence."""
    os.makedirs(box, exist_ok=True)
    out = {TREE: sources[TREE]} if TREE in sources else {}
    for name, path in sources.items():
        if name == TREE:
            continue
        dst = os.path.join(box, "sample_" + name)
        fi, rd, d = open_rows(path)
        with fi, open_like(dst, path, d) as fo:
            w = csv.writer(fo, delimiter=d["separator"])
            for i, row in enumerate(rd):
                w.writerow(row)
                if i >= records:
                    break
        out[name] = dst
    return out


def read_output(path, head=200):
    """(columns, the first rows, the number of rows) of an output CSV."""
    with open(path, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        cols = next(rd, [])
        rows, n = [], 0
        for row in rd:
            n += 1
            if len(rows) < head:
                rows.append(row)
    return cols, rows, n


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError, OverflowError):
        return None


def output_checks(proc, cols, rows, n, summary):
    """What the program checks on any output: the procedure's columns, rows written, counts and percentages that add up."""
    want = proc["output"]["columns"]
    checks = [{"check": "the output has the procedure's columns, in its order", "ok": cols == want, "detail": ", ".join(cols)}]
    checks.append({"check": "the code wrote rows", "ok": n > 0, "detail": "%s rows" % "{:,}".format(n)})
    low = [c.lower() for c in cols]
    if "percent" in low and n <= len(rows):
        pct = sum(_num(r[low.index("percent")]) or 0 for r in rows)
        checks.append({"check": "the percentages add up to 100", "ok": abs(pct - 100) < 0.002 * max(1, n) + 0.01, "detail": "%.3f" % pct})
    if "count" in low and n <= len(rows) and isinstance(summary, dict) and summary.get("total") is not None:
        tot = sum(_num(r[low.index("count")]) or 0 for r in rows)
        checks.append({"check": "the counts add up to the total the code reports", "ok": abs(tot - float(summary["total"])) < 1e-9,
                       "detail": "%s counted, total %s" % ("{:,.0f}".format(tot), summary["total"])})
    return checks


def output_checks_file(proc, path, summary):
    """output_checks on the whole result file, read line by line (any size): the columns, the lines written, and that the
    counts and the percentages add up."""
    want = proc["output"]["columns"]
    with open(path, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        cols = next(rd, [])
        low = [c.lower() for c in cols]
        ip = low.index("percent") if "percent" in low else None
        ic = low.index("count") if "count" in low else None
        n, pct, cnt = 0, 0.0, 0.0
        for row in rd:
            n += 1
            if ip is not None and ip < len(row):
                pct += _num(row[ip]) or 0
            if ic is not None and ic < len(row):
                cnt += _num(row[ic]) or 0
    checks = [{"check": "the output has the procedure's columns, in its order", "ok": cols == want, "detail": ", ".join(cols)},
              {"check": "the code wrote rows", "ok": n > 0, "detail": "%s rows" % "{:,}".format(n)}]
    if ip is not None:
        checks.append({"check": "the percentages add up to 100", "ok": abs(pct - 100) < 0.002 * max(1, n) + 0.01, "detail": "%.3f" % pct})
    if ic is not None and isinstance(summary, dict) and summary.get("total") is not None:
        checks.append({"check": "the counts add up to the total the code reports", "ok": abs(cnt - float(summary["total"])) < 1e-9,
                       "detail": "%s counted, total %s" % ("{:,.0f}".format(cnt), summary["total"])})
    return checks


def cross_check(r, upload_id, cols, rows):
    """An independent count: where the item had an earlier plan (the SQL made by the fixed translator, on the tree
    database), its counts per label must equal the Python code's (two different programs, one answer)."""
    from . import family3
    if r.get("kind") == "command_error" and _command_errors().family_of_item(r):
        if application_code(r):
            return None         # the application's own code ran: application_checks already made this comparison once, and says what it shows
        # a rule family of the NVMe command level whose code a model wrote: never taken as right by itself. Its rows are compared with the
        # application's reference implementation of the family on the whole recording, and the check says which rows only one of them found.
        CE = _command_errors()
        folder = upload_folder(upload_id)
        db = os.path.join(folder, "hier.sqlite") if folder else ""
        if not db or not os.path.exists(db):
            return {"check": "the rows found are the rows the application's reference implementation of this rule finds on the whole recording", "ok": False,
                    "detail": "not compared: the tree of this recording was not found"}
        import tempfile
        fd, tmp = tempfile.mkstemp(prefix="f2t_compare_", suffix=".csv")      # the result's rows as a file of their own, outside the recording's folder
        os.close(fd)
        try:
            with open(tmp, "w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh)
                w.writerow(cols)
                for row in rows:
                    w.writerow(row)
            out = CE.compare_with_reference(tmp, db, CE.family_of_item(r))
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
        path = (r.get("code") or {}).get("path")
        try:
            if path and os.path.exists(path):
                with open(path, encoding="utf-8") as fh:
                    if "command_error_rules" in fh.read():
                        out["detail"] += " (this code calls the reference implementation itself, so the comparison shows nothing about it)"
        except OSError:
            pass
        return out
    if r.get("kind") not in ("distribution", "read_pattern") or not r.get("plan"):
        return None
    folder = upload_folder(upload_id)
    db = os.path.join(folder, "hier.sqlite") if folder else ""
    if not db or not os.path.exists(db):
        return None
    try:
        import sqlite3
        sql, params, _ps, _pp = family3.compile_rule(r)
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
        try:
            ref = {str(a): int(b) for a, b, _c in con.execute(sql, params).fetchall()}
        finally:
            con.close()
    except Exception as e:      # noqa: BLE001 - reported as not checked
        return {"check": "an independent count from the tree database agrees", "ok": True, "detail": "not checked: %s" % e}
    got = {}
    for row in rows:
        if len(row) >= 2 and _num(row[1]) is not None:
            got[row[0]] = int(_num(row[1]))
    diff = sorted(set(ref) ^ set(got)) + sorted(k for k in set(ref) & set(got) if ref[k] != got[k])
    return {"check": "an independent count from the tree database (a different program) agrees", "ok": not diff,
            "detail": "the same %d lines" % len(ref) if not diff else "differs on: %s" % ", ".join(diff[:8])}


# ------------------------------------------------------------------------------------------------ the Coder
CODER_INSTRUCTION = """You are the Coder of Family 3. Write the Python code that does EXACTLY the PROCEDURE below, step by step,
on the analyzer's CSV files. The admin wrote or approved the procedure; on your own, do not add, drop or change any step. If a
step is not clear enough to code, write the most literal reading and put your question in "questions".

THE ADMIN'S COMMENTS (ADMIN_ASKS, when present) come first. When a comment asks for something the procedure says differently or
does not say (for example other names in the output, a kind left out or merged, a step added or removed, another order), CHANGE
THE PROCEDURE as asked: return the whole changed procedure in "procedure" (the same shape: source_data, steps, output,
open_questions; keep every step the admin did not ask to change, word for word) and code that follows the changed procedure.
Say each change in "changes". When a comment asks a question (for example "what is this?"), answer it in "answers", plainly.
Without such a comment, "procedure" is null.

THE CODE MUST:
- define  def run(sources, out_csv):  sources = {file name: full path} of the procedure's source files; out_csv = the path of the
  output CSV to write (UTF-8; first row = the procedure's output columns, exactly, in that order)
- return a dict: {"rows_read": <data rows read>, "rows_written": <output rows>, "total": <the total used for percentages, or null>}
- read each CSV with csv.reader (NOT DictReader: the header repeats some names and has empty ones); find each column by its exact
  header text, first match (COLUMNS gives the position found in the real file); open files with newline="" and encoding "utf-8-sig"
- a file of FILES that has "written_as" is NOT written in that plain form, and the code must open it as written_as says:
  open(path, newline="", encoding=<written_as.encoding.codec>, errors="replace"); read and drop written_as.header.line - 1 lines
  with fh.readline() before giving fh to csv.reader (they stand above the header and are no rows); when the codec is "utf-16-le"
  or "utf-16-be", remove a leading "\\ufeff" from the first line read; csv.reader(fh, delimiter=<written_as.separator.value>). The
  header is on line written_as.header.line and the first record on the next line; a row's line number in the file counts from
  there. When written_as.separator.decided is false the separator could not be told from the file and the comma is used: say
  so in "questions". A file without "written_as" is comma-separated UTF-8 with its header on line 1
- a column of COLUMNS that has "number_style" does not write plain numbers. With style "decimal comma" or "decimal point", read a
  value as float(v.replace(<thousands_sign>, "").replace(<decimal_sign>, ".")) (no first replace when thousands_sign is null).
  With style "ambiguous" or "mixed" the column must NOT be read as a number: a step that needs its number cannot be done on
  such a row; do not guess a reading, put the sentence of "how" in "questions" for the admin
- the output CSV is always written plain (comma, UTF-8), whatever the form of the files read
- stream the rows: never load a whole file into memory (the files can hold millions of rows)
- parse each cell exactly as the procedure says; COLUMNS shows real values from the file, so handle every format seen there and
  empty cells; say in the step's comment how the cell is parsed (for example whether letter case is changed)
- import only: csv, re, math, collections, decimal, datetime, statistics, itertools, json, functools, operator, and
  "from nvme_hier import names" (names.opcode_name(opc: int, sqid: int) -> the NVMe specification's command name, "(admin)" added for queue 0)
- put a comment line "# step N: <the step's words, short>" right before the code of each step of the procedure
- no other files, no network, no os, no subprocess, no printing"""
CODER_INSTRUCTION_TREE = """You are the Coder of Family 3. Write the Python code that does EXACTLY the PROCEDURE below, step by step, on THE TREE that
Family 2 built from the recording's five files (with the joining rules the admin approved), using the meanings Family 1's data experts wrote.
The admin wrote or approved the procedure; on your own, do not add, drop or change any step. If a step is not clear enough to code, write the
most literal reading and put your question in "questions".

THE ADMIN'S COMMENTS (ADMIN_ASKS, when present) come first: when a comment asks for something the procedure says differently or does not say,
CHANGE THE PROCEDURE as asked: return the whole changed procedure in "procedure" (same shape; keep every step the admin did not ask to change, word
for word) and code that follows it; say each change in "changes". Answer questions in "answers". Without such a comment, "procedure" is null.

THE CODE MUST:
- define  def run(tree, out_csv):  tree = the recording's tree (THE_TREE below says every call); out_csv = the path of the output CSV to write
  (UTF-8; first row = the procedure's output columns, exactly, in that order)
- return a dict: {"rows_read": <rows read>, "rows_written": <output rows>, "total": <the total used for percentages, or null>}
- read the data ONLY through tree: tree.rows, tree.children, tree.parent, tree.ancestor, tree.descendants, tree.unlinked, tree.findings,
  tree.meaning. Never open a CSV file, never join two levels again by Tag, Address, CID, RequesterID or time stamp: the tree already joined
  them by identity, and a row the joins could not place has no parent (report it, do not guess one)
- stream: iterate tree.rows(...); never build a list of a whole level (a level can hold millions of rows)
- parse each cell exactly as the procedure says; COLUMNS shows real values from this tree, so handle every format seen there and empty cells
- write the output with csv.writer; import only: csv, re, math, collections, decimal, datetime, statistics, itertools, json, functools,
  operator, and "from nvme_hier import names" (names.opcode_name(opc: int, sqid: int))
- put a comment line "# step N: <the step's words, short>" right before the code of each step of the procedure
- no other files, no network, no os, no subprocess, no printing"""
CODER_SHAPE = """{"code": "<the whole Python file>", "how": ["step 1: how the code does it", "..."], "questions": ["..."],
 "procedure": null or {"source_data": [...], "steps": ["..."], "output": {"columns": ["..."], "order": "..."}, "open_questions": ["..."]},
 "changes": ["step 6: the kinds are now named sqread and RndRead, as the admin asked", "..."], "answers": ["..."]}"""

# the stand-in Coder (no model): the code of the two seeded procedures, written by hand, so the flow can be tested. Both read the one file
# nvme_command.csv as it is written (the codec, the lines above the header and the separator are written into the code by _standin_open from
# agentic/csv_dialect.py, as for every file procedure of the stand-in), line by line: nothing of the file is held in memory.
# STANDIN_CODE holds their text for a plain file (comma, UTF-8, header on line 1); standin_code() gives the text for the file at hand.
_SEED_TEMPLATES = {
    "command_type_share": '''import csv
from nvme_hier import names


def run(sources, out_csv):
    # step 1: read nvme_command.csv on its own, as it is written; columns found by their exact header text, first match; the tree is not used
    with open(sources["nvme_command.csv"], newline="", encoding=%(codec)s%(errors)s) as fh:
%(open)s
        head = next(rd)
        i_opc, i_sqid = head.index("OPC"), head.index("SQID")
        counts = {}
        n = 0
        for row in rd:
            n += 1
            opc_cell = row[i_opc].strip() if i_opc < len(row) else ""
            sqid_cell = row[i_sqid].strip() if i_sqid < len(row) else ""
            if not opc_cell:
                name = "(blank)"
            else:
                # step 2: OPC "0x02 (Read)" -> the text before the first space, read as hexadecimal (case does not matter)
                opc = int(opc_cell.split(" ")[0], 16)
                # step 3: SQID as a whole number (0 = admin queue)
                sqid = int(sqid_cell) if sqid_cell else None
                # step 4: the NVMe specification's name
                name = names.opcode_name(opc, sqid)
            # step 5: hash map: command type -> rows
            counts[name] = counts.get(name, 0) + 1
    # step 6: total = the sum of the counts
    total = sum(counts.values())
    # step 7 and the output: percent, one line per type, largest count first
    with open(out_csv, "w", newline="", encoding="utf-8") as out:
        w = csv.writer(out)
        w.writerow(["command type", "count", "percent"])
        for name, k in sorted(counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([name, k, round(100.0 * k / total, 3) if total else 0])
    return {"rows_read": n, "rows_written": len(counts), "total": total}
''',
    "read_pattern": '''import csv


def _ps(t):
    # step 4: "0000.400098983870s" -> picoseconds
    t = t.strip().rstrip("s")
    whole, _, frac = t.partition(".")
    return int(whole or 0) * 10 ** 12 + int((frac + "0" * 12)[:12] or 0)


def run(sources, out_csv):
    # step 1: read nvme_command.csv on its own, as it is written; columns by exact header text, first match; the tree is not used
    with open(sources["nvme_command.csv"], newline="", encoding=%(codec)s%(errors)s) as fh:
%(open)s
        head = next(rd)
        ix = {c: head.index(c) for c in ("OPC", "SQID", "NSID", "SLBA", "NLB", "Time Stamp")}
        prev = {}
        counts = {}
        n = 0
        for row in rd:
            n += 1
            cell = lambda c: row[ix[c]].strip() if ix[c] < len(row) else ""
            # step 2: reads only: OPC 2 (hexadecimal before the first space) on an I/O queue, SLBA and NLB present
            if not cell("OPC") or int(cell("OPC").split(" ")[0], 16) != 2:
                continue
            if not cell("SQID") or int(cell("SQID")) == 0 or not cell("SLBA") or not cell("NLB"):
                continue
            # step 3: whole numbers; NLB is 0-based
            ns, slba, nlb = int(cell("NSID") or 0), int(cell("SLBA")), int(cell("NLB"))
            # step 4: the Time Stamp in picoseconds
            t = _ps(cell("Time Stamp"))
            # step 5: the file's order; only the previous read of each namespace is kept (NSID -> time, SLBA, NLB)
            before = prev.get(ns)
            if before is not None and t < before[0]:
                raise ValueError("nvme_command.csv is not in time order: the read on row " + str(n) + " is earlier than the previous read of namespace "
                                 + str(ns) + ", so the reads cannot be taken in time order without holding them all in memory")
            # step 6: first / sequential / random
            if before is None:
                kind = "first read of its namespace"
            elif slba == before[1] + before[2] + 1:
                kind = "sequential read"
            else:
                kind = "random read (RndRead)"
            counts[kind] = counts.get(kind, 0) + 1
            prev[ns] = (t, slba, nlb)
    # step 7 and the output: total, percent, largest first
    total = sum(counts.values())
    with open(out_csv, "w", newline="", encoding="utf-8") as out:
        w = csv.writer(out)
        w.writerow(["kind of read", "count", "percent"])
        for kind, k in sorted(counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([kind, k, round(100.0 * k / total, 3) if total else 0])
    return {"rows_read": n, "rows_written": len(counts), "total": total}
''',
}


STANDIN_CODE = {}                 # item id -> the stand-in Coder's code text (the two seeds' plain text is added under _standin_open below)
STANDIN_CODE["near_limit"] = _near_limit().code_for()
# the rule families of the NVMe command level: should a model be connected and not answer, the stand-in Coder's hand-written code of the item
# is the application's reference implementation of its family
# (2026-11-15) no stand-in code for the rule families of the NVMe command level: without a model they run as application code (application_code),
# and with a model connected their code is written from the rule's text. Were the reference implementation handed out as "the stand-in Coder's
# code", the Tester would compare it with itself: check_code refuses that text (REFERENCE_REFUSAL), and the stand-in says NO_STANDIN_FOR_FAMILY.


FORMS_REMEMBERED = 64          # procedures whose files' forms are kept from coder_context for the stand-in Coder
_FORMS = {}                    # sha of a procedure -> {file name: how the file is written (csv_dialect.detect)}


def remember_forms(proc, forms):
    """Keep how each source file of this procedure is written, for the stand-in Coder that writes its code next."""
    forms = {k: v for k, v in (forms or {}).items() if v and not v.get("refused")}
    key = sha(proc)
    _FORMS.pop(key, None)
    if forms:
        _FORMS[key] = forms
        while len(_FORMS) > FORMS_REMEMBERED:
            _FORMS.pop(next(iter(_FORMS)))


def forms_of(proc, paths):
    """{file name: how the file is written} for the procedure's source files that are in paths (a refused file is left out)."""
    out = {}
    for s in proc.get("source_data") or []:
        p = (paths or {}).get(s.get("file"))
        if p and s.get("file") != TREE and os.path.isfile(p):
            try:
                out[s["file"]] = CD.detect(p)
            except OSError:
                pass
    return out


def _standin_open(name, proc, forms=None):
    """The lines of a stand-in code template that open one file as it is written: the codec, the lines above the header
    skipped, the separator. forms: {file name: csv_dialect.detect}; None = what coder_context saw for this procedure. A plain
    file (or one whose form is not known) gives the lines the template always had."""
    d = (forms if forms is not None else _FORMS.get(sha(proc)) or {}).get(name)
    if not d or d.get("as_before"):
        return {"codec": '"utf-8-sig"', "errors": "", "open": "        rd = csv.reader(fh)"}
    lines = []
    skip = d["header_line"] - 1
    if skip:
        lines += ["        for _ in range(%d):            # the lines above the header are no rows of the table" % skip, "            fh.readline()"]
    if d["codec"].startswith("utf-16") and not skip:
        lines += ["        if fh.read(1) != \"\\ufeff\":           # the byte order mark, when the file starts with one", "            fh.seek(0)"]
    lines.append("        rd = csv.reader(fh%s)" % ("" if d["separator"] == "," else ", delimiter=%r" % d["separator"]))
    return {"codec": json.dumps(d["codec"]), "errors": ', errors="replace"', "open": "\n".join(lines)}


SEED_FILE = "nvme_command.csv"          # the one file the two seeded analytics procedures read


def seed_code(rid, proc=None, forms=None):
    """The stand-in Coder's code of a seeded analytics procedure (command_type_share, read_pattern), opening nvme_command.csv as it is written:
    forms as in standin_share_code ({} = a plain file; None = what coder_context saw for this procedure)."""
    if proc is None and forms is None:
        forms = {}
    return _SEED_TEMPLATES[rid] % _standin_open(SEED_FILE, proc or SEEDS[rid], forms)


STANDIN_CODE.update({rid: seed_code(rid) for rid in _SEED_TEMPLATES})


def standin_code(r, proc, forms=None):
    """The stand-in Coder's code of an item -> the text, or None. A seeded analytics item whose procedure still reads nvme_command.csv gets its
    hand-written code for the file as it is written; any other item what STANDIN_CODE holds for it, else the share or rows shape of
    standin_share_code. A test may put its own text in STANDIN_CODE: that text is then given as it is."""
    rid = (r or {}).get("id")
    code = STANDIN_CODE.get(rid)
    if (rid in _SEED_TEMPLATES and code == seed_code(rid) and isinstance(proc, dict)
            and proc.get("source_data") == SEEDS[rid]["source_data"]):
        return seed_code(rid, proc, forms)
    return code or standin_share_code(proc, forms)


def standin_share_code(proc, forms=None):
    """The stand-in Coder's code for the one procedure shape the stand-in Rule writer makes: the share of each value of one
    column of one file (output: the column, count, percent). None for any other procedure. The code opens the file as it is
    written (forms: {file name: csv_dialect.detect}; None = what coder_context saw for this procedure)."""
    src = proc.get("source_data") or []
    if uses_tree(proc):
        return standin_tree_rows_code(proc)     # a procedure on the tree: the one shape the stand-in Rule writer makes for it, or None
    if len(src) != 1 or len(src[0].get("columns") or []) != 1:
        return None
    col = src[0]["columns"][0]
    if proc.get("output", {}).get("columns") != [col, "count", "percent"]:
        return standin_rows_code(proc, forms)
    return '''import csv


def run(sources, out_csv):
    # step 1: read %(file)s row by row; the column found by its exact header text, first match
    with open(sources[%(file)r], newline="", encoding=%(codec)s%(errors)s) as fh:
%(open)s
        head = next(rd)
        i = head.index(%(col)r)
        counts, n = {}, 0
        for row in rd:
            n += 1
            # step 2: the cell as it is, spaces at both ends removed, letter case unchanged; empty -> "(blank)"
            v = row[i].strip() if i < len(row) else ""
            v = v or "(blank)"
            # step 3: hash map value -> rows
            counts[v] = counts.get(v, 0) + 1
    # step 4: total and percent
    total = sum(counts.values())
    # step 5: one line per value, largest count first
    with open(out_csv, "w", newline="", encoding="utf-8") as out:
        w = csv.writer(out)
        w.writerow([%(col)r, "count", "percent"])
        for v, k in sorted(counts.items(), key=lambda x: (-x[1], x[0])):
            w.writerow([v, k, round(100.0 * k / total, 3) if total else 0])
    return {"rows_read": n, "rows_written": len(counts), "total": total}
''' % dict(_standin_open(src[0]["file"], proc, forms), file=src[0]["file"], col=col)


STANDIN_ROWS_STEP = 'Keep the row when its %s cell is exactly "%s".'


def standin_rows_code(proc, forms=None):
    """The stand-in Coder's code for the second procedure shape the stand-in Rule writer makes: the rows of one file whose cell in one
    column is exactly one value, each with its row number in the file (other_errors.ROW_COLUMN) and its own cells. None for any other.
    The code opens the file as it is written (forms as in standin_share_code)."""
    from . import other_errors as OE
    src = proc.get("source_data") or []
    if len(src) != 1 or len(src[0].get("columns") or []) != 1:
        return None
    col = src[0]["columns"][0]
    cols = proc.get("output", {}).get("columns") or []
    lead, tail = (STANDIN_ROWS_STEP % (col, "\x00")).split("\x00")
    value = next((st[len(lead):len(st) - len(tail)] for st in proc.get("steps") or [] if isinstance(st, str) and st.startswith(lead) and st.endswith(tail)), None)
    if value is None or not cols or cols[0] != OE.ROW_COLUMN:
        return None
    return '''import csv


def run(sources, out_csv):
    # step 1: read %(file)s row by row; the column found by its exact header text, first match; the first row under the header is row 1
    with open(sources[%(file)r], newline="", encoding=%(codec)s%(errors)s) as fh, open(out_csv, "w", newline="", encoding="utf-8") as out:
%(open)s
        head = next(rd)
        i = head.index(%(col)r)
        w = csv.writer(out)
        w.writerow([%(rowcol)r] + head)
        n = k = 0
        for row in rd:
            n += 1
            # step 2: the cell as it is, spaces at both ends removed, letter case unchanged
            v = row[i].strip() if i < len(row) else ""
            # step 3: keep the row when the cell is exactly the value
            if v == %(value)r:
                # step 4: its row number in the file, then every cell of the row as it is
                w.writerow([n] + row)
                k += 1
    return {"rows_read": n, "rows_written": k}
''' % dict(_standin_open(src[0]["file"], proc, forms), file=src[0]["file"], col=col, value=value, rowcol=OE.ROW_COLUMN)


STANDIN_TREE_WALK = "Walk the rows of the level %s of the tree (tree.rows), in the file's order; no other level is read and nothing is joined."
STANDIN_TREE_STEP = 'Keep the row only when its %s cell is exactly "%s" (the cell as the export wrote it, spaces at both ends removed; a row whose cell is empty is not kept).'
STANDIN_TREE_OUT = "Output one line per kept row: its row number in the file (row.row of the tree), then the cells named above as they are."


def standin_tree_rows(level, wanted):
    """The procedure the stand-in Rule writer makes for "the rows of one level of the tree whose cells are exactly these values"
    (wanted: [(column, value)]): each kept row with its row number in the level's file (nvme_hier/coded_findings.ROW_COLUMN)."""
    from nvme_hier import coded_findings as CF
    return {"source_data": [{"file": TREE, "columns": ["%s: %s" % (level, c) for c, _v in wanted]}],
            "steps": [STANDIN_TREE_WALK % level] + [STANDIN_TREE_STEP % (c, v) for c, v in wanted] + [STANDIN_TREE_OUT],
            "output": {"columns": [CF.ROW_COLUMN] + [c for c, _v in wanted], "order": "the file's own order"}, "open_questions": []}


def standin_tree_rows_code(proc):
    """The stand-in Coder's code for the procedure of standin_tree_rows (read back from its own steps), or None for any other procedure
    on the tree. The code reads the tree only: run(tree, out_csv)."""
    from nvme_hier import coded_findings as CF
    src = proc.get("source_data") or []
    cols = [tree_column(c) for c in (src[0].get("columns") or [])] if len(src) == 1 and src[0].get("file") == TREE else []
    levels = {lv for lv, _c in cols}
    if not cols or len(levels) != 1 or None in levels:
        return None
    level = levels.pop()
    steps = [st for st in proc.get("steps") or [] if isinstance(st, str)]
    wanted = []
    for _lv, col in cols:
        lead, tail = (STANDIN_TREE_STEP % (col, "\x00")).split("\x00")
        value = next((st[len(lead):len(st) - len(tail)] for st in steps if st.startswith(lead) and st.endswith(tail)), None)
        if value is None:
            return None
        wanted.append((col, value))
    if not steps or steps[0] != STANDIN_TREE_WALK % level or (proc.get("output") or {}).get("columns") != [CF.ROW_COLUMN] + [c for c, _v in wanted]:
        return None
    return '''import csv

LEVEL = %(level)r
WANTED = %(wanted)r          # (column, the exact cell text) of every condition of the procedure


def run(tree, out_csv):
    # step 1: the rows of the level, in the file's order; nothing else is read
    n = k = 0
    with open(out_csv, "w", newline="", encoding="utf-8") as out:
        w = csv.writer(out)
        w.writerow([%(rowcol)r] + [c for c, _v in WANTED])
        for row in tree.rows(LEVEL):
            n += 1
            # the conditions: each cell as the export wrote it, spaces at both ends removed; an empty cell never matches
            cells = [(row.get(c) or "").strip() for c, _v in WANTED]
            if all(cell != "" and cell == v for cell, (_c, v) in zip(cells, WANTED)):
                # the last step: the row's number in its file (row.row), then the cells named above
                w.writerow([row.row] + cells)
                k += 1
    return {"rows_read": n, "rows_written": k}
''' % {"level": level, "wanted": wanted, "rowcol": CF.ROW_COLUMN}


def _own_dictionary(path):
    """(Family 1's approved dictionary of a CSV that is not one of the five exports, or None; the file's inventory entry or None)."""
    try:
        f = next((x for x in family1.inventory(os.path.dirname(path)) if x["path"] == path or x["name"] == os.path.basename(path)), None)
        d = family1.approved_dictionary(f["format_key"], f["name"]) if f else None
    except Exception:           # noqa: BLE001 - no dictionary is not a fault: the Coder is told the meaning is not known
        f = d = None
    return d, f


def own_meanings(path):
    """{column: (meaning, where it comes from)} of a CSV that is not one of the five exports: from its own data dictionary
    approved in Family 1 (none approved yet: empty)."""
    d, _f = _own_dictionary(path)
    return {str(c["column"]): (str(c.get("meaning") or ""), "Family 1's approved dictionary of %s (version %s)" % (os.path.basename(path), d.get("version") or "?"))
            for c in (d or {}).get("columns") or [] if isinstance(c, dict) and c.get("column")}


def own_form(path):
    """How a CSV that is not one of the five exports is written, as a Coder gets it:
    {"written_as": the file's form or None for a plain file, "refused": the plain sentence or None,
     "number_style": {column: how it writes its numbers}}.
    The form is read from the file that is here now (never from a dictionary made for another file with the same header:
    the same columns can come with another separator). The number styles are those Family 1 counted on the whole file, kept
    in its approved dictionary; a column the dictionary says nothing about is left to what the first rows show
    (columns_info)."""
    out = {"written_as": None, "refused": None, "number_style": {}}
    try:
        d = CD.detect(path)
    except OSError as e:
        out["refused"] = "%s could not be opened: %s." % (os.path.basename(path), e)
        return out
    if d["refused"]:
        out["refused"] = d["refused"]
        return out
    out["written_as"] = written_for_coder(d)
    dic, _f = _own_dictionary(path)
    for c in (dic or {}).get("columns") or []:
        if isinstance(c, dict) and c.get("column"):
            style = style_for_coder(c.get("number_style"), "the whole file, by Family 1 (dictionary version %s)" % (dic.get("version") or "?"))
            if style:
                out["number_style"][str(c["column"])] = style
    return out


def coder_context(r, proc, upload_id, paths=None):
    """What the Coder is given: the procedure, and for each source file its path, the named columns' positions and real
    values (from the file itself), and Family 1's meaning of each column (with where the meaning comes from). A file that
    is not plain (comma, UTF-8, header on line 1) also has "written_as", a column that does not write plain numbers has
    "number_style", and a file that cannot be read as a table has "not_read" with the plain sentence.
    paths: {file name: path} when the analysis has no upload (no tree was built: the folder's files, see recording_paths)."""
    paths = paths or source_paths(upload_id)
    remember_forms(proc, forms_of(proc, paths))
    files = []
    for s in proc["source_data"]:
        lv = LEVEL_OF_FILE.get(s["file"])
        info = columns_info(paths[s["file"]], s["columns"]) if s["file"] in paths else {}
        meanings = E._meanings(lv) if lv else own_meanings(paths[s["file"]]) if s["file"] in paths else {}
        form = own_form(paths[s["file"]]) if s["file"] in paths and s["file"] != TREE else {"written_as": None, "refused": None, "number_style": {}}
        cols = []
        for c in s["columns"]:
            col = {"name": c, "position": (info.get(c) or {}).get("position"), "real_values_seen": (info.get(c) or {}).get("samples"),
                   "rows_with_value_in_scan": (info.get(c) or {}).get("rows_with_value"),
                   "meaning_from_family_1": (meanings.get(c) or ("", ""))[0], "meaning_source": (meanings.get(c) or ("", "not in Family 1's dictionary"))[1]}
            style = form["number_style"].get(c) or (info.get(c) or {}).get("number_style")
            if style:
                col["number_style"] = style
            cols.append(col)
        entry = {"file": s["file"], "path_in_this_recording": paths.get(s["file"]), "header_cells": info.get("_header_cells"),
                 "rows_scanned_for_samples": info.get("_rows_scanned"), "COLUMNS": cols}
        if form["written_as"]:
            entry["written_as"] = form["written_as"]
        if form["refused"]:
            entry["not_read"] = form["refused"]
        files.append(entry)
    return {"item": r.get("name"), "PROCEDURE": {"version": proc.get("version", 0), "source_data": proc["source_data"], "steps": proc["steps"],
                                                  "output": proc["output"]}, "FILES": files}


def tree_meanings():
    """{level: {column: meaning}} from Family 1's approved dictionaries: what tree.meaning(level, column) answers inside the code."""
    return {lv: {c: (m or ("",))[0] for c, m in E._meanings(lv).items()} for lv in FILE_NAME}


def tree_facts(db):
    """What THE_TREE context says about one built tree: the guide, rows per level, rows the joins left without a parent."""
    from nvme_hier import tree_api as T
    t = T.Tree(db)
    try:
        levels = t.levels()
        no_parent = {lv: t.con.execute("SELECT COUNT(*) FROM %s WHERE parent IS NULL AND (relation IS NULL OR relation != 'context')" % T.TABLE[lv]).fetchone()[0]
                     for lv in levels if lv != "nvme_command"}
        context = {lv: t.con.execute("SELECT COUNT(*) FROM %s WHERE relation = 'context'" % T.TABLE[lv]).fetchone()[0] for lv in levels if lv == "packets"}
    finally:
        t.close()
    return {"guide": T.GUIDE, "rows_per_level": levels, "rows_without_a_parent": no_parent, "context_rows": context}


def tree_samples(db, level, column, n=12):
    from nvme_hier import tree_api as T
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        key = '$."%s"' % column.replace('"', '')
        vals = [r[0] for r in con.execute("SELECT DISTINCT json_extract(raw, ?) FROM (SELECT raw FROM %s LIMIT 5000) WHERE json_extract(raw, ?) IS NOT NULL LIMIT ?"
                                          % T.TABLE[level], (key, key, n))]
        filled = con.execute("SELECT COUNT(*) FROM (SELECT raw FROM %s LIMIT 5000) WHERE COALESCE(json_extract(raw, ?), '') != ''" % T.TABLE[level], (key,)).fetchone()[0]
    finally:
        con.close()
    return vals, filled


def tree_column_state(db, level, column):
    """"filled", "in the file, empty in every row" or "not in the file" for one column of a level of the tree (nvme_hier/tree_api
    Tree.column_state): a column the header names and no row fills is in the file, not missing."""
    from nvme_hier import tree_api as T
    t = T.Tree(db)
    try:
        return t.column_state(level, column) if level in t.present else T.MISSING
    finally:
        t.close()


def coder_context_tree(r, proc, upload_id):
    """What the Coder is given for a procedure on the tree: the procedure, THE_TREE (guide, rows per level, rows without a parent) and each
    column used, with real values from this tree and Family 1's approved meaning and its source. No raw file path is given."""
    db = source_paths(upload_id).get(TREE)
    facts = tree_facts(db) if db else {"guide": "no tree is built for this recording"}
    cols = []
    for s in proc["source_data"]:
        if s["file"] != TREE:
            continue
        for c in s["columns"]:
            lv, col = tree_column(c)
            vals, filled = tree_samples(db, lv, col) if db and lv else ([], 0)
            m = E._meanings(lv).get(col) if lv else None
            cols.append({"level": lv, "file": FILE_NAME.get(lv), "name": col, "real_values_seen": vals, "rows_with_value_in_first_5000": filled,
                         "in_the_file": tree_column_state(db, lv, col) if db and lv and not filled else "filled",
                         "meaning_from_family_1": (m or ("", ""))[0], "meaning_source": (m or ("", "not in Family 1's dictionary"))[1]})
    return {"item": r.get("name"), "PROCEDURE": {"version": proc.get("version", 0), "source_data": proc["source_data"], "steps": proc["steps"],
                                                  "output": proc["output"]}, "THE_TREE": dict(facts, COLUMNS=cols)}


def _fold_wal(db):
    """Fold the tree's write-ahead log into its main file, so a process that may only read can open the file alone (immutable). True when the
    log is empty afterwards; False (the reader then opens it read-only in the usual way) when a writer is busy with it."""
    try:
        con = sqlite3.connect(db, timeout=5)
        try:
            con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        finally:
            con.close()
    except sqlite3.Error:
        pass
    wal = db + "-wal"
    return not os.path.exists(wal) or os.path.getsize(wal) == 0
