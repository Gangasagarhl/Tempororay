"""The step engine, the agent runner, the evidence checks and the reference search.

Every job is a RUN made of named STEPS executed in a fixed order. Each step has a state that the page shows:

    waiting -> running -> done                      (the step finished, nothing to review)
                       -> needs_review -> approved   (the admin approved what the step proposes)
                                       -> waiting    (the admin asked for changes: the step runs again with the comment)
                                       -> rejected   (the run stops)
                       -> skipped                    (nothing to do, with the reason)
                       -> failed                     (with the error; "run again" retries from this step)

Runs, steps, reviews, chat lines and evidence live in one SQLite file (db/agentic.sqlite) so that every family and the
admin see the same records. A run interrupted by a server stop is resumed at start-up from its first unfinished step
(steps are written to be repeatable). Each agent call works in its own sandbox folder (runs/<run>/<agent>/) where its
instruction, context and answer are kept.
"""
import json
import os
import re
import sqlite3
import subprocess
import sys
import types
import threading
import time
import traceback

SCHEMA = """
CREATE TABLE IF NOT EXISTS project (id INTEGER PRIMARY KEY, admin TEXT, name TEXT, folder TEXT, refs TEXT, rea TEXT,
  upload_id TEXT, notes TEXT, created REAL, updated REAL, source_tool TEXT);
CREATE TABLE IF NOT EXISTS run (id INTEGER PRIMARY KEY, project INTEGER, kind TEXT, target TEXT, params TEXT, state TEXT,
  created REAL, updated REAL, heartbeat REAL, summary TEXT);
CREATE TABLE IF NOT EXISTS step (id INTEGER PRIMARY KEY, run INTEGER, idx INTEGER, key TEXT, title TEXT, family TEXT,
  agent TEXT, state TEXT, needs_review INTEGER, input TEXT, output TEXT, error TEXT, note TEXT, attempts INTEGER DEFAULT 0,
  started REAL, finished REAL, heartbeat REAL, producer TEXT);
CREATE INDEX IF NOT EXISTS ix_step_run ON step (run, idx);
CREATE TABLE IF NOT EXISTS review (id INTEGER PRIMARY KEY, run INTEGER, step INTEGER, title TEXT, body TEXT, data TEXT,
  state TEXT, decided_by TEXT, decided_at REAL, comment TEXT, created REAL);
CREATE TABLE IF NOT EXISTS chat (id INTEGER PRIMARY KEY, review INTEGER, role TEXT, text TEXT, at REAL);
CREATE TABLE IF NOT EXISTS evidence (id INTEGER PRIMARY KEY, run INTEGER, step INTEGER, claim TEXT, kind TEXT, ref TEXT,
  quote TEXT, verified INTEGER, why TEXT);
"""

# columns added after the first release: a database made by an earlier build gets them when the application starts
# (table, column, type). project.source_tool: the tool that exported the recording, asked on the start page (the reference
# library's key; empty when it was not asked: the Data Grounder then recognises the tool from the column names)
ADDED_COLUMNS = (("project", "source_tool", "TEXT"),)

RUNNING_STATES = ("waiting", "running")
DONE_STATES = ("done", "approved", "skipped")


def now():
    return time.time()


class Store:
    """The shared records (one SQLite file). Every call opens its own connection: the engine threads and the page share it."""

    def __init__(self, path):
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        con = self.con()
        con.executescript(SCHEMA)
        for table, column, kind in ADDED_COLUMNS:
            if column not in {r[1] for r in con.execute("PRAGMA table_info(%s)" % table)}:
                try:
                    con.execute("ALTER TABLE %s ADD COLUMN %s %s" % (table, column, kind))
                except sqlite3.OperationalError:            # another process added it at the same moment
                    if column not in {r[1] for r in con.execute("PRAGMA table_info(%s)" % table)}:
                        raise
        con.commit()
        con.close()

    def con(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA busy_timeout=30000")
        return c

    def one(self, sql, args=()):
        c = self.con()
        try:
            r = c.execute(sql, args).fetchone()
            return dict(r) if r else None
        finally:
            c.close()

    def all(self, sql, args=()):
        c = self.con()
        try:
            return [dict(r) for r in c.execute(sql, args)]
        finally:
            c.close()

    def claim(self, sql, args=()):
        """One conditional update: True when it changed a row, so of two callers at the same moment exactly one gets it."""
        c = self.con()
        try:
            cur = c.execute(sql, args)
            c.commit()
            return cur.rowcount > 0
        finally:
            c.close()

    def exec(self, sql, args=()):
        c = self.con()
        try:
            cur = c.execute(sql, args)
            c.commit()
            return cur.lastrowid
        finally:
            c.close()

    def many(self, sql, rows):
        """The same statement for many rows in one transaction (one write to the disk, not one per row)."""
        rows = list(rows)
        if not rows:
            return
        c = self.con()
        try:
            c.executemany(sql, rows)
            c.commit()
        finally:
            c.close()


def jload(s, default=None):
    if s is None or s == "":
        return default
    try:
        return json.loads(s)
    except (TypeError, ValueError, OverflowError):
        return default


# ---------------------------------------------------------------------------------------------- evidence
EVIDENCE_KINDS = {"data", "document", "admin", "project", "rea", "web", "ticket", "model"}


def norm(t):
    return re.sub(r"\s+", " ", str(t or "")).strip().lower()


class References:
    """The reference documents the admin gives (LeCroy manuals, specification extracts, notes saved earlier, REA notes).
    Text files are read as they are; PDFs through pdftotext (kept in a cache next to the sandbox). search() returns the
    lines that name a term, with file and line, so that every meaning an agent states can point to a real line."""

    TEXT_EXT = (".md", ".txt", ".json", ".csv", ".c", ".h", ".cpp", ".py", ".html")

    def __init__(self, folders, cache_dir):
        self.folders = [f for f in (folders or []) if f and os.path.isdir(f)]
        self.cache_dir = cache_dir
        self._docs = None
        self._low = None
        self._found = {}

    def docs(self):
        if self._docs is not None:
            return self._docs
        out = {}
        for folder in self.folders:
            for base, _dirs, files in os.walk(folder):
                for fn in sorted(files):
                    p = os.path.join(base, fn)
                    low = fn.lower()
                    try:
                        if low.endswith(self.TEXT_EXT) and os.path.getsize(p) < 20 * 1024 * 1024:
                            with open(p, encoding="utf-8", errors="replace") as f:
                                out[p] = f.read().splitlines()
                        elif low.endswith(".pdf"):
                            out[p] = self._pdf_lines(p)
                    except OSError:
                        continue
        self._docs = out
        return out

    def _pdf_lines(self, p):
        os.makedirs(self.cache_dir, exist_ok=True)
        key = re.sub(r"[^A-Za-z0-9]+", "_", p)[-150:] + ".txt"
        cp = os.path.join(self.cache_dir, key)
        if not os.path.exists(cp) or os.path.getmtime(cp) < os.path.getmtime(p):
            try:
                subprocess.run(["pdftotext", "-layout", p, cp], timeout=300, check=False, capture_output=True)
            except (OSError, subprocess.TimeoutExpired):
                return []
        try:
            with open(cp, encoding="utf-8", errors="replace") as f:
                return f.read().splitlines()
        except OSError:
            return []

    def _index(self):
        """Per document: its text in lower case as one string and where each line starts in it. A term is first looked for there
        (one fast scan of the whole document) and only the lines that hold it are checked as whole words (measured 2026-11-11: the
        line-by-line check of every term took minutes on a specification, with nothing on the screen)."""
        if self._low is None:
            low = {}
            for p, lines in self.docs().items():
                ll = [x.lower() for x in lines]
                starts, at = [], 0
                for x in ll:
                    starts.append(at)
                    at += len(x) + 1
                low[p] = ("\n".join(ll), starts)
            self._low = low
        return self._low

    def _lines_with(self, p, lines, term, rx):
        """The numbers (0 = first) of the lines of one document that name the term, in order."""
        if not term.isascii():                  # lower case is only used as a first filter where it cannot change what matches
            for i, line in enumerate(lines):
                if rx.search(line):
                    yield i
            return
        import bisect
        text, starts = self._index()[p]
        t, at = term.lower(), 0
        while True:
            at = text.find(t, at)
            if at < 0:
                return
            i = bisect.bisect_right(starts, at) - 1
            if rx.search(lines[i]):
                yield i
            if i + 1 >= len(starts):
                return
            at = starts[i + 1]

    def search(self, term, limit=3, context=1):
        """Lines naming `term` (whole word, case-insensitive): [{"ref": "file:line", "quote": text}]."""
        term = (term or "").strip()
        if len(term) < 2:
            return []
        key = (term.lower(), limit, context)
        if key in self._found:                  # the same term is asked for many columns (a leaf name, a keyword)
            return [dict(h) for h in self._found[key]]
        rx = re.compile(r"(?<![A-Za-z0-9_])%s(?![A-Za-z0-9_])" % re.escape(term), re.I)
        hits = []
        for p, lines in self.docs().items():
            for i in self._lines_with(p, lines, term, rx):
                lo, hi = max(0, i - context), min(len(lines), i + context + 1)
                quote = " ".join(x.strip() for x in lines[lo:hi] if x.strip())[:400]
                hits.append({"ref": "%s:%d" % (p, i + 1), "quote": quote})
                if len(hits) >= limit * 4:
                    break
            if len(hits) >= limit * 4:
                break
        # prefer short, specific lines (tables and definitions) over long paragraphs
        hits.sort(key=lambda h: len(h["quote"]))
        self._found[key] = hits[:limit]
        return [dict(h) for h in hits[:limit]]

    def has_quote(self, ref, quote):
        """True when `quote` (normalised) appears in the referenced file (and near the line, when a line is given)."""
        path, _, line = (ref or "").rpartition(":")
        if not path:
            path, line = ref, ""
        lines = self.docs().get(path)
        if lines is None:
            return False
        q = norm(quote)[:160]
        if not q:
            return False
        if line.isdigit():
            i = int(line) - 1
            window = norm(" ".join(lines[max(0, i - 3):i + 4]))
            if q in window:
                return True
        return q in norm(" ".join(lines))


class WebSources:
    """The web pages the agents quote. Every page is fetched by THE PROGRAM ITSELF (not taken from the model's word) and
    the quote must be found on it: a web claim whose words are not on that page stays NOT verified. Pages are kept in a
    cache folder, so a page is fetched once per run. Only http(s) addresses on the internet are fetched."""

    UA = "Mozilla/5.0 (compatible; field-to-test-evidence-check/1.0)"

    def __init__(self, cache_dir, timeout=25, max_bytes=8 * 1024 * 1024, allow_local=False):
        self.cache_dir, self.timeout, self.max_bytes, self.allow_local = cache_dir, timeout, max_bytes, allow_local
        self._mem = {}

    def _allowed(self, url):
        import ipaddress
        import urllib.parse
        u = urllib.parse.urlparse(url or "")
        if u.scheme not in ("http", "https") or not u.hostname:
            return False
        if self.allow_local:
            return True
        host = u.hostname.lower()
        if host == "localhost" or host.endswith(".local"):
            return False
        try:
            ip = ipaddress.ip_address(host)
            return not (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved)
        except ValueError:
            return True

    def text(self, url):
        """The readable text of a page (HTML without its tags and scripts, a PDF through pdftotext), or None."""
        import hashlib
        import html as H
        import urllib.request
        if url in self._mem:
            return self._mem[url]
        if not self._allowed(url):
            return None
        os.makedirs(self.cache_dir, exist_ok=True)
        cp = os.path.join(self.cache_dir, hashlib.sha1(url.encode()).hexdigest() + ".txt")
        if os.path.exists(cp):
            t = open(cp, encoding="utf-8", errors="replace").read()
            self._mem[url] = t
            return t
        try:
            req = urllib.request.Request(url, headers={"User-Agent": self.UA, "Accept": "text/html,application/pdf,text/plain,*/*"})
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                ctype = (r.headers.get("Content-Type") or "").lower()
                raw = r.read(self.max_bytes + 1)[:self.max_bytes]
        except Exception:       # noqa: BLE001 - an unreadable page verifies nothing
            self._mem[url] = None
            return None
        if "pdf" in ctype or raw[:5] == b"%PDF-":
            pdf = cp[:-4] + ".pdf"
            with open(pdf, "wb") as fh:
                fh.write(raw)
            try:
                subprocess.run(["pdftotext", "-layout", pdf, cp], timeout=300, check=False, capture_output=True)
                t = open(cp, encoding="utf-8", errors="replace").read()
            except (OSError, subprocess.TimeoutExpired):
                t = ""
        else:
            t = raw.decode("utf-8", errors="replace")
            if "html" in ctype or "<html" in t[:2000].lower():
                t = re.sub(r"(?is)<(script|style|noscript)[^>]*>.*?</\1>", " ", t)
                t = re.sub(r"(?s)<[^>]+>", " ", t)
                t = H.unescape(t)
            with open(cp, "w", encoding="utf-8") as fh:
                fh.write(t)
        self._mem[url] = t
        return t

    @staticmethod
    def _loose(t):
        # letters and digits only: quotes survive the page's own punctuation, dashes and line breaks
        return re.sub(r"[^0-9a-z]+", " ", norm(t)).strip()

    def has_quote(self, url, quote):
        q = self._loose(quote)
        if len(q) < 12:
            return False          # a quote too short proves nothing
        t = self.text(url)
        return bool(t) and q[:200] in self._loose(t)


def check_claims(claims, refs=None, data_values=None, admin_texts=None, web=None):
    """Zero hallucination, applied by code: a claim is kept as verified only when its source holds it.
    data: the quoted value occurs in the profile of that column; document/rea: the quote is in that file; admin: the quote
    is in what the admin wrote; project: a project note (checked like a document when the file is known); web: the program
    fetches the page itself and finds the quoted words on it. Everything else (model knowledge, a ticket without a
    connector) is kept as UNVERIFIED and shown as such."""
    out = []
    for c in claims or []:
        src = c.get("source") or {}
        kind = (src.get("kind") or "model").lower()
        ref, quote = src.get("ref") or "", src.get("quote") or ""
        ok, why = False, ""
        if kind == "data":
            vals = (data_values or {}).get(ref)
            if vals is None:
                why = "no such column in the data: %s" % ref
            elif norm(quote) and any(norm(quote) in norm(v) or norm(v) in norm(quote) for v in vals):
                ok = True
            else:
                why = "the quoted value is not among the values seen in %s" % ref
        elif kind in ("document", "rea", "project"):
            if refs is not None and refs.has_quote(ref, quote):
                ok = True
            else:
                why = "the quote was not found in %s" % (ref or "the reference")
        elif kind == "admin":
            ok = any(norm(quote) and norm(quote) in norm(t) for t in (admin_texts or []))
            why = "" if ok else "the admin did not say this"
        elif kind == "web":
            if web is None:
                why = "a web page, but checking web pages is off"
            elif web.has_quote(ref, quote):
                ok = True
            else:
                why = "the program fetched %s and did not find the quoted words on it" % (ref or "the page")
        else:
            why = "no source that the program can check (%s)" % kind
        out.append(dict(c, verified=ok, why=why))
    return out


# ---------------------------------------------------------------------------------------------- agent runner
def _end_tree(p):
    """End a process and every program it started: its process group on Linux and macOS, taskkill /T on Windows."""
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True, timeout=30)
        else:
            import signal
            os.killpg(os.getpgid(p.pid), signal.SIGKILL)
    except (OSError, subprocess.SubprocessError):
        try:
            p.kill()
        except OSError:
            pass


def custom_url():
    """True when the Settings page set an address of its own (a company gateway), not Anthropic's."""
    b = (os.environ.get("ANTHROPIC_BASE_URL") or "").strip().lower()
    return bool(b) and "api.anthropic.com" not in b


def _free_memory():
    """Bytes of memory still free for this server (None where it cannot be told, for example on Windows)."""
    try:
        from nvme_hier import loader
        return loader.memory_available()
    except Exception:       # noqa: BLE001 - no number is better than a wrong one: the caller then sets no memory limit
        return None


class Slots:
    """How many model calls run at the same time, for all agents of the server together (owner, 2026-11-11: "look at the number
    of cores in the laptop and do the calls simultaneously"). The number can be changed while calls run (Settings). When the
    model service answers "too many calls" (HTTP 429) or "overloaded" it is halved, and it climbs back by one after as many
    good calls in a row as it allows at once: the service's own limit, not the computer, is then what sets the speed."""
    CUT_APART = 5.0             # seconds: refusals that arrive together are one cut, not one cut each

    PER_SECOND = 5              # calls started in any one second at most (owner, 2026-11-12: "for 1 second 5 different requests can be made from the API")
    SECOND = 1.1                # the "one second" as this counter measures it, a tenth longer than a second: a call leaves the
    #                             computer a moment after its start is counted, and with exactly 1.0 six calls were measured to
    #                             reach a model server on this machine within 0.915 s (2026-11-12). The tenth keeps the arrivals
    #                             at 5 in a second too.

    def __init__(self, ceiling, per_second=None):
        self._cv = threading.Condition()
        self.per_second = max(1, int(per_second or self.PER_SECOND))
        self._starts = []           # when the calls of the last second started
        self.ceiling = max(1, int(ceiling))     # what Settings or the computer allow
        self.limit = self.ceiling               # what is used now (lower after refusals)
        self.active = 0
        self.most = 0               # the most calls seen running together
        self.refused = 0            # how many times the service said "too many calls"
        self._good = 0
        self._cut_at = 0.0

    def set(self, ceiling):
        with self._cv:
            was = self.ceiling
            self.ceiling = max(1, int(ceiling))
            self.limit = self.ceiling if self.limit >= was else min(self.limit, self.ceiling)     # a limit lowered by refusals stays lowered
            self._cv.notify_all()

    def take(self, check=None):
        """Wait for a free place, and for the second to have room: no more than `per_second` calls start within any one second,
        however many places are free. check() is called while waiting and may raise (a stopped run does not wait on)."""
        with self._cv:
            while True:
                now = time.time()
                self._starts = [t for t in self._starts if 0 <= now - t < self.SECOND]
                if self.active < self.limit and len(self._starts) < self.per_second:
                    break
                wait = 0.5
                if self.active < self.limit:        # a place is free: only the second has to pass
                    wait = max(0.01, min(0.5, self.SECOND - (now - min(self._starts))))
                self._cv.wait(wait)
                if check:
                    check()
            self._starts.append(time.time())
            self.active += 1
            self.most = max(self.most, self.active)

    def give(self):
        with self._cv:
            self.active = max(0, self.active - 1)
            self._cv.notify_all()

    def __enter__(self):
        self.take()
        return self

    def __exit__(self, *_exc):
        self.give()

    def too_many(self):
        with self._cv:
            self.refused += 1
            self._good = 0
            if time.time() - self._cut_at >= self.CUT_APART:
                self._cut_at = time.time()
                self.limit = max(1, self.limit // 2)

    def went_well(self):
        with self._cv:
            self._good += 1
            if self.limit < self.ceiling and self._good >= self.limit:
                self.limit += 1
                self._good = 0
                self._cv.notify_all()


class AgentRunner:
    """Runs one agent call in its own sandbox folder, with a fixed instruction and a fixed answer shape (JSON).

    runtime "claude-code": the Claude Code CLI in headless mode (claude -p) in the sandbox folder, only able to read
    files there; "http": the configured model over HTTP (the application's model connection); "standin": no model, a
    deterministic answer written by the program. When the chosen runtime fails the next one is used, and the step
    records who answered. Answers are checked by the code before the next step starts.

    runtime "opencode" (owner, 2026-11-13: "redirect from api calling to terminal with holding sessions ... api use is
    not allowed"): the opencode program in a terminal, with the model chosen in Settings. Every agent holds a session
    there: its next question continues the same conversation, and the application keeps the session's name, its number
    at opencode and every question and answer (agentic/sessions.py). It never falls back to the Model connection."""

    ORDER = {"claude-code": ["claude-code", "http", "standin"], "http": ["http", "standin"], "standin": ["standin"],
             "opencode": ["opencode", "standin"]}
    OPENCODE_BYTES = 600 * 1024 ** 2        # memory of one opencode call (a program of its own; measured 555 to 567 MB each)
    SESSION_FILL = 0.95         # (owner, 2026-11-14: "auto compact when it reaches 95%") a held conversation is continued while it and the
                                # next question fill at most this share of what the model reads; then it is compacted and goes on as its next part
    CONTEXT_FALLBACK = 200000   # what a model reads when neither the service nor the configuration says (tokens)
    KEEP_LAST_TURNS = 2         # turns given word for word after a compaction, besides the model's summary
    CHARS_PER_TOKEN = 2         # measured: 332,027 characters of rows with numbers were 157,969 tokens
    TERMINAL_TRIES = 3          # a turn the service refused for "too many calls", that did not reach the service, or that came back empty, is asked again
    TERMINAL_WAITS = (5, 15)    # ... after these seconds
    CALLS_MOST = 64             # the most model calls at the same time that Settings accept
    CLAUDE_CODE_BYTES = 400 * 1024 ** 2     # memory of one Claude Code call (a program of its own; measured 350 to 400 MB each)
    MAX_TOKENS = 16000          # the longest answer of one call over the Model connection
    TOO_MANY = (429, 503, 529)  # the service says: too many calls, or overloaded
    READ_ONLY_HERE = "Read(./**),Grep(./**),Glob(./**)"     # the agent's own folder only: a bare "Read" lets it open any file the service can read, a key file included (measured 2026-11-10)
    RETRY_WAIT_LIMIT = 60       # the longest wait, in seconds, that a service's "retry after" is obeyed for

    WEB_RULES = ("For every fact taken "
                 "from a web page, give the source as kind \"web\", ref = the page's full URL, quote = words copied EXACTLY "
                 "from that page (one sentence or a table row). The program fetches the page itself and checks the quote; a "
                 "quote that is not on the page is shown to the admin as NOT verified.")
    WEB_NOTE = ("\n\nTHE WEB: you may also search the web when CONTEXT does not say it (official specifications: PCI-SIG, "
                "NVM Express; the Teledyne LeCroy documentation; standards bodies; at most 5 searches). " + WEB_RULES)

    def __init__(self, sandbox_root, runtime="http", llm_getter=None, model=None, timeout=420, http_model=None, claude_path=None, web=True, calls_at_once=0,
                 opencode_path=None, opencode_model=None, sessions=None, api_allowed=True):
        self.sandbox_root = sandbox_root
        self.context_limit = None       # tokens the Model connection's model reads; None = asked of the service once, else the table below
        self._context_of = {}
        self.api_allowed = bool(api_allowed)    # False (the application's own setting, server.api_calls off): never Claude Code, never the Model connection
        self.opencode_path = opencode_path
        self.opencode_model = opencode_model  # "provider/model" as opencode lists it (Settings)
        self.sessions = sessions              # agentic.sessions.Sessions: the terminal sessions held, with their conversations
        self.web_enabled = bool(web)        # the admin's setting: may the agents also search the web
        self.runtime = runtime if runtime in self.ORDER else "http"
        self.llm_getter = llm_getter or (lambda: None)
        self.model = model
        self.timeout = timeout
        self.http_model = http_model          # the model of the application's own connection (config llm.model)
        self.claude_path = claude_path
        self.cancelled = set()              # runs that were stopped: their next model calls are refused (owner, 2026-11-11: "stop means stop")
        self.web_refused = ""               # the address that refused the web tools: it is not asked for them again (see _http)
        self.procs = {}                     # run -> the Claude Code processes working for it now, ended by cancel()
        self._procs_lock = threading.Lock()
        self._local = threading.local()
        self.slots = Slots(4)               # model calls at the same time, however many agents are working; sized just below
        self.calls_wanted, self._slots_at = 0, 0.0
        self.set_calls(calls_at_once)

    # ---- how many model calls at the same time
    def path_now(self):
        """Where a call goes now: "claude-code" (a program per call), "http" (the Model connection) or "standin" (no model)."""
        if self.runtime == "standin":
            return "standin"
        if self.runtime == "opencode" or not self.api_allowed:
            return "opencode"
        if self.runtime == "claude-code" and not custom_url() and self.find_claude(self.claude_path):
            return "claude-code"
        return "http"

    def calls_auto(self):
        """-> (number, why in words): what this computer runs at the same time when Settings leave the number automatic.
        Over the Model connection a call only waits on the network, so 2 per processor core (4 to 32). A Claude Code call is a
        program of its own: 1 per core (2 to 16), and no more than half of the free memory holds."""
        cores = os.cpu_count() or 4
        if self.path_now() in ("claude-code", "opencode"):
            oc = self.path_now() == "opencode"
            each, what = (self.OPENCODE_BYTES, "opencode") if oc else (self.CLAUDE_CODE_BYTES, "Claude Code")
            n, why = max(2, min(16, cores)), "1 per processor core: every %s call is a program of its own" % what
            free = _free_memory()
            if free is not None:
                room = int((free + self.slots.active * each) // 2 // each)
                if room < n:
                    n, why = max(2, room), "what half of the free memory holds (%s free, about %d MB per %s call)" % (fmt_bytes(free), each // 1024 ** 2, what)
            return n, why
        return max(4, min(32, 2 * cores)), "2 per processor core: over the Model connection a call only waits on the network"

    def set_calls(self, n):
        """Settings: 0 = automatic (from this computer), otherwise the number itself (1 to CALLS_MOST)."""
        try:
            n = int(n or 0)
        except (TypeError, ValueError, OverflowError):
            n = 0
        self.calls_wanted = max(0, min(self.CALLS_MOST, n))
        self._slots_at = 0.0
        return self.calls_at_once()

    def calls_at_once(self):
        """How many model calls may run together now (looked at again every 20 s: Settings, the runtime, the free memory)."""
        if time.time() - self._slots_at >= 20:
            self._slots_at = time.time()
            n = self.calls_wanted or self.calls_auto()[0]
            if n != self.slots.ceiling:
                self.slots.set(n)
        return self.slots.limit

    def calls_facts(self):
        """The numbers behind it, for Settings and the status lines."""
        auto, why = self.calls_auto()
        return {"wanted": self.calls_wanted, "auto": auto, "why": why, "cores": os.cpu_count() or 0, "now": self.calls_at_once(),
                "ceiling": self.slots.ceiling, "refused": self.slots.refused, "path": self.path_now(), "most": self.CALLS_MOST,
                "started_per_second_at_most": self.slots.per_second}

    def cancel(self, rid):
        """Stop: the run's next calls are refused and its Claude Code processes are ended now."""
        self.cancelled.add(rid)
        with self._procs_lock:
            procs = list(self.procs.get(rid, ()))
        for p in procs:
            _end_tree(p)

    def resume(self, rid):
        self.cancelled.discard(rid)

    def _stopped(self):
        rid = getattr(self._local, "run", None)
        if rid is not None and rid in self.cancelled:
            raise RuntimeError("the run was stopped")

    def _run_cli(self, cmd, prompt, cwd, timeout, env):
        """subprocess.run, with the process kept so that Stop can end it."""
        rid = getattr(self._local, "run", None)
        # its own process group, so that Stop (or the time limit) ends Claude Code together with the programs it started
        p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", cwd=cwd, env=env,
                             **({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}))
        with self._procs_lock:
            self.procs.setdefault(rid, set()).add(p)
        try:
            out, err = p.communicate(prompt, timeout=timeout)
        except subprocess.TimeoutExpired:
            _end_tree(p)
            p.communicate()
            raise
        finally:
            with self._procs_lock:
                self.procs.get(rid, set()).discard(p)
        self._stopped()
        return types.SimpleNamespace(returncode=p.returncode, stdout=out, stderr=err)

    def _run_watched(self, cmd, prompt, cwd, timeout, env, refused, on_line=None):
        """Like _run_cli, and the program's error lines are read while it works: refused(line) -> True ends the call at
        once. (Measured 2026-11-13: when its service says "Free usage limit reached", opencode writes that to its log and
        waits in silence; without this the call sat there until the time limit, 240 s, and the reason was never seen.)
        -> returncode, stdout, stderr, ended_for (the line that ended it, or None), timed_out."""
        rid = getattr(self._local, "run", None)
        p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace",
                             cwd=cwd, env=env, **({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}))
        with self._procs_lock:
            self.procs.setdefault(rid, set()).add(p)
        out, err, hit = [], [], []

        def feed():
            try:
                p.stdin.write(prompt)
                p.stdin.close()
            except (OSError, ValueError):
                pass

        def read_out():
            try:
                if on_line is None:
                    out.append(p.stdout.read())
                    return
                for line in p.stdout:           # the program's event lines as they come: the page shows what the agent is doing
                    out.append(line)
                    try:
                        on_line(line)
                    except Exception:           # noqa: BLE001 - showing the status never ends the call
                        pass
            except (OSError, ValueError):
                pass

        def read_err():
            try:
                for line in p.stderr:
                    err.append(line)
                    if not hit and refused(line):
                        hit.append(line.strip())
                        _end_tree(p)
            except (OSError, ValueError):
                pass
        threads = [threading.Thread(target=f, daemon=True) for f in (feed, read_out, read_err)]
        for t in threads:
            t.start()
        timed_out = False
        try:
            try:
                p.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                _end_tree(p)
                p.wait()
        finally:
            with self._procs_lock:
                self.procs.get(rid, set()).discard(p)
            for t in threads:
                t.join(5)
        self._stopped()
        return types.SimpleNamespace(returncode=p.returncode, stdout="".join(out), stderr="".join(err), ended_for=hit[0] if hit else None, timed_out=timed_out)

    @staticmethod
    def find_claude(configured=None):
        """The Claude Code program: the configured path, then PATH, then the usual install folders (a service started by
        systemd does not inherit the login shell's PATH, so ~/.npm-global/bin is not on it)."""
        import glob
        import shutil
        if configured and os.path.isfile(configured):
            return configured
        p = shutil.which("claude")
        if p:
            return p
        home = os.path.expanduser("~")
        if os.name == "nt":                  # Windows: npm's claude.cmd, or the installer's claude.exe
            for c in [os.path.join(os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming"), "npm", "claude.cmd"),
                      os.path.join(home, ".local", "bin", "claude.exe"), os.path.join(home, ".claude", "local", "claude.exe")]:
                if os.path.isfile(c):
                    return c
            return None
        for c in [os.path.join(home, ".npm-global", "bin", "claude"), os.path.join(home, ".local", "bin", "claude"),
                  os.path.join(home, ".claude", "local", "claude"), "/usr/local/bin/claude"] + sorted(glob.glob(os.path.join(home, ".nvm", "versions", "node", "*", "bin", "claude"))):
            if os.path.isfile(c) and os.access(c, os.X_OK):
                return c
        return None

    def sandbox(self, run_id, agent):
        d = os.path.join(self.sandbox_root, "run_%s" % run_id, re.sub(r"[^A-Za-z0-9_.-]+", "_", agent))
        os.makedirs(d, exist_ok=True)
        return d

    def web_sources(self):
        """The checker of web quotes (None when the agents may not use the web)."""
        return WebSources(os.path.join(self.sandbox_root, "_web_cache")) if self.web_enabled else None

    def web_refused_here(self):
        """True when the address in use has refused the web tools (a company gateway that does not offer them)."""
        return bool(self.web_refused) and self.web_refused == (custom_url() or "")

    def can_search_web(self):
        return self.web_enabled and self.runtime in ("claude-code", "http", "opencode") and not self.web_refused_here()

    def ask(self, run_id, agent, instruction, context, schema_text, must_have, standin, files=None, runtime=None, web=False, effort=None, on_start=None,
            web_note=None, http_effort=None):
        """-> (answer dict, producer text, sandbox folder). web=True: the agent may also search the web (when the admin
        allows it); its web facts must cite the page and a quote, which the code then checks (WebSources).
        effort: Claude Code's effort level for this call (the Coder asks "high": the same model, more thinking).
        http_effort: the effort level for this call when it goes over the Model connection (Family 4's Coder and Tester:
        with a company URL every call goes there, and "think harder" must hold there too). None: nothing is said, as before.
        on_start: called when the call has its place among the calls running at the same time (before: it waits for one).
        web_note: what the agent is told about the web instead of WEB_NOTE (what to search for depends on the file's tool)."""
        self._local.run = run_id
        self._stopped()
        self.calls_at_once()
        web = bool(web and self.web_enabled and not self.web_refused_here())
        if web:
            instruction = instruction + (web_note or self.WEB_NOTE)
        box = self.sandbox(run_id, agent)
        for name, content in (files or {}).items():
            with open(os.path.join(box, name), "w", encoding="utf-8") as f:
                f.write(content if isinstance(content, str) else json.dumps(content, indent=1))
        prompt = "%s\n\nANSWER: one JSON object only, no text around it, of this shape:\n%s\n\nCONTEXT:\n%s" % (
            instruction, schema_text, context if isinstance(context, str) else json.dumps(context, indent=1)[:180000])
        with open(os.path.join(box, "prompt.txt"), "w", encoding="utf-8") as f:
            f.write(prompt)
        tried = []
        order = list(self.ORDER.get(runtime or self.runtime, ["standin"]))
        if not self.api_allowed:
            # (owner, 2026-11-13: "Api calls are strictly not allowed ... use only the terminal sessions call") whatever was asked
            # for, a call goes to opencode in a terminal or, when that fails or the stand-in was asked for, to the stand-in
            order = ["standin"] if order == ["standin"] else ["opencode", "standin"]
        if custom_url() and "claude-code" in order:
            # (owner, 2026-11-11: "it has to go to the URL I gave, not log into Anthropic again and again") with a company URL the
            # agents use the Model connection: every call goes to that URL with the Settings key and model; Claude Code, which has
            # its own Anthropic login and traffic, is not started
            order = [x for x in order if x != "claude-code"]
        for rt in order:
            t0 = time.time()
            self._stopped()                 # a stopped run tries nothing more (not even the stand-in)
            try:
                if rt == "standin":
                    ans, producer = standin(), "stand-in (no model)"
                else:
                    self.slots.take(self._stopped)      # waits for a free place; a run stopped meanwhile leaves the queue
                    try:
                        self._stopped()
                        t0 = time.time()        # the wait for a free place is not the call's own time
                        if on_start:
                            on_start()
                        if rt == "claude-code":
                            ans, producer = self._claude_code(prompt, box, web, effort), "Claude Code (headless)%s%s" % (
                                ", with web search" if web else "", ", effort %s" % effort if effort else "")
                        elif rt == "opencode":
                            ans, producer = self._opencode(prompt, box, web, effort or http_effort, "run:%s" % run_id, agent,
                                                           "run %s · %s" % (run_id, agent))
                        elif self.sessions is not None and runtime is None:
                            ans, producer = self.api_turn(prompt, "run:%s" % run_id, agent, "run %s · %s" % (run_id, agent), web, http_effort)
                        else:
                            ans, producer = self._http(prompt, web, http_effort)
                    finally:
                        self.slots.give()
                if not isinstance(ans, dict) or must_have not in ans:
                    raise RuntimeError("the answer has no '%s' field" % must_have)
                meta = {"runtime": rt, "producer": producer, "seconds": round(time.time() - t0, 1), "tried": tried}
                with open(os.path.join(box, "answer.json"), "w", encoding="utf-8") as f:
                    json.dump({"meta": meta, "answer": ans}, f, indent=1)
                if tried:
                    producer += " (after: %s)" % "; ".join(tried)
                return ans, producer, box
            except Exception as e:      # noqa: BLE001 - the next runtime is tried; the reason is recorded
                if str(e) == "the run was stopped":
                    raise
                tried.append("%s failed: %s" % (rt, str(e)[:160]))
        raise RuntimeError("no runtime answered: " + "; ".join(tried))

    def _web_tools(self):
        """Anthropic's server-side web search and web fetch for the model connection: the dynamic-filtering versions on
        the models that take them (Opus / Sonnet 4.6 and later), the basic ones otherwise (Haiku)."""
        m = (self.http_model or "").lower()
        new = re.search(r"(opus|sonnet)-(4-[6-9]|[5-9])", m) is not None
        return [{"type": "web_search_20260209" if new else "web_search_20250305", "name": "web_search", "max_uses": 5},
                {"type": "web_fetch_20260209" if new else "web_fetch_20250910", "name": "web_fetch", "max_uses": 5}]

    def _http(self, prompt, web=False, effort=None):
        """The Model connection; with a company URL a call that the address refuses because of the web tools (Anthropic's own
        server tools, which a gateway may not offer) is made once more without them, and the producer says so. The same
        holds for an effort level the address does not take: the call is made once more without it, and that is remembered."""
        if effort and not web:
            if getattr(self, "effort_refused", "") == (custom_url() or "anthropic"):
                ans, producer = self._http_call(prompt, False)
                return ans, producer + " (this address did not take the effort setting: answered at its usual effort)"
            try:
                ans, producer = self._http_call(prompt, False, effort)
                return ans, producer + ", effort %s" % effort
            except RuntimeError as e:
                if "HTTP 400" not in str(e):        # only a request the address refused; never no credit, a refused key or a missing model
                    raise
                ans, producer = self._http_call(prompt, False)
                self.effort_refused = custom_url() or "anthropic"
                return ans, producer + " (this address did not take the effort setting: answered at its usual effort)"
        if web and custom_url():
            if self.web_refused_here():             # a call that started before the refusal was known
                ans, producer = self._http_call(prompt, False)
                return ans, producer + " (this address did not take web search: answered without it)"
            try:
                return self._http_call(prompt, True)
            except RuntimeError as e:
                if "HTTP 400" not in str(e):        # only a request the address refused (its tools); never no credit, a refused key or a missing model
                    raise
                ans, producer = self._http_call(prompt, False)
                # the same question was answered once the tools were left out: the tools were the reason. It is remembered, so the
                # hundreds of calls of a wide file are not each made twice (measured: every refused call cost one more round trip)
                self.web_refused = custom_url() or ""
                return ans, producer + " (this address did not take web search: answered without it)"
        return self._http_call(prompt, web)

    def _http_call(self, prompt, web=False, effort=None):
        """The Messages API over plain HTTPS with the application's key (ANTHROPIC_API_KEY) and model; the answer's JSON
        object is read from the text, as for Claude Code. Transient failures are retried (2, 4, 8 s). web=True adds the
        server-side web search and web fetch tools (a paused turn is continued up to 3 times)."""
        import urllib.error
        import urllib.request
        if not self.api_allowed:
            from .policy import NOT_ALLOWED
            raise RuntimeError(NOT_ALLOWED)
        key, tok = os.environ.get("ANTHROPIC_API_KEY"), os.environ.get("ANTHROPIC_AUTH_TOKEN")
        if not (key or tok):
            raise RuntimeError("no API key in the environment (ANTHROPIC_API_KEY)")
        if not self.http_model:
            raise RuntimeError("no model name in the configuration (llm.model)")
        base = (os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com").rstrip("/")
        # a held conversation (api_turn): the agent's earlier turns come first, and what was sent before is read from the
        # service's cache (the prefix is the same bytes as last time; a gateway that does not take the field is remembered)
        history = list(getattr(self._local, "history", None) or [])
        self._local.usage = None
        messages = history + [{"role": "user", "content": prompt}]
        body = {"model": self.http_model, "max_tokens": self.MAX_TOKENS, "messages": messages}
        if history and getattr(self, "cache_refused", "") != (custom_url() or "anthropic"):
            body["cache_control"] = {"type": "ephemeral"}
        if web:
            body["tools"] = self._web_tools()
        if effort:
            body["output_config"] = {"effort": effort}      # the same field the stage 2 client sends (stage2/llm_adapter.py)
        headers = {"content-type": "application/json", "anthropic-version": "2023-06-01"}
        if key:
            headers["x-api-key"] = key
        else:
            headers["authorization"] = "Bearer " + tok
        texts = []
        for _turn in range(4):          # a server-tool turn can pause: it is sent again to continue (at most 3 times)
            resp, last = None, ""
            tries = 4
            for attempt in range(tries):
                self._stopped()
                req = urllib.request.Request(base + "/v1/messages", data=json.dumps(body).encode(), headers=headers, method="POST")
                wait = 2 * (2 ** attempt)
                try:
                    with urllib.request.urlopen(req, timeout=self.timeout) as r:
                        resp = json.loads(r.read().decode())
                    self.slots.went_well()
                    break
                except urllib.error.HTTPError as e:
                    last = "HTTP %s: %s" % (e.code, e.read().decode(errors="replace")[:200])
                    if e.code in self.TOO_MANY:
                        self.slots.too_many()       # fewer calls at the same time from now on; it climbs back when calls go well again
                    if e.code not in (408, 409, 429, 500, 502, 503, 504, 529):
                        break
                    told = e.headers.get("retry-after", "") if e.headers else ""
                    if told.isdigit():
                        wait = min(max(wait, int(told)), self.RETRY_WAIT_LIMIT)
                except (urllib.error.URLError, OSError) as e:
                    last = "connection: %s" % e
                except ValueError:
                    last = "the service answered with something that is not JSON"
                if attempt < tries - 1:         # after the last try there is nothing to wait for
                    time.sleep(wait)
            if resp is None:
                raise RuntimeError(last or "no answer")
            content = resp.get("content") if isinstance(resp, dict) else None
            if not isinstance(content, list):
                raise RuntimeError("the service's answer has no content")
            if isinstance(resp.get("usage"), dict):
                self._local.usage = resp["usage"]
            texts += [b.get("text", "") for b in content if isinstance(b, dict) and b.get("type") == "text"]
            if resp.get("stop_reason") == "pause_turn":
                body["messages"] = messages + [{"role": "assistant", "content": content}]
                continue
            if resp.get("stop_reason") == "max_tokens":     # said as it is: before, a cut answer was reported as "not JSON" and asked again the same way
                raise RuntimeError("the answer was cut off: it was longer than one call may write (%d tokens)" % self.MAX_TOKENS)
            break
        # with web search the answer comes after the searches: the JSON is read from the last text holding one
        for t in reversed(texts):
            if "{" in t:
                try:
                    return parse_json_object(t), "%s (model connection%s)" % (self.http_model, ", with web search" if web else "")
                except ValueError:
                    continue
        return parse_json_object("".join(texts)), "%s (model connection)" % self.http_model

    # ---- the Model connection with a held conversation per agent (owner, 2026-11-14: "when you are making many different agent
    # calls, it should be stateful. You should be able to save that in the disk ... next time if I am opening it, those states
    # need to come back to the agents ... auto compact when it reaches 95%")
    def context_tokens(self):
        """How many tokens the Model connection's model reads: the configured number, else what the service says for the
        model (GET /v1/models/<id>, asked once), else by the model's name, else CONTEXT_FALLBACK."""
        if self.context_limit:
            return int(self.context_limit)
        m = self.http_model or ""
        key = (custom_url() or "anthropic", m)
        if key in self._context_of:
            return self._context_of[key]
        n = None
        if self.api_allowed and m and (os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN")):
            try:
                import urllib.request
                k, tok = os.environ.get("ANTHROPIC_API_KEY"), os.environ.get("ANTHROPIC_AUTH_TOKEN")
                base = (os.environ.get("ANTHROPIC_BASE_URL") or "https://api.anthropic.com").rstrip("/")
                req = urllib.request.Request(base + "/v1/models/" + m, headers=dict({"anthropic-version": "2023-06-01"}, **({"x-api-key": k} if k else {"authorization": "Bearer " + tok})))
                with urllib.request.urlopen(req, timeout=15) as r:
                    got = json.loads(r.read().decode())
                if isinstance(got, dict) and isinstance(got.get("max_input_tokens"), int) and got["max_input_tokens"] > 0:
                    n = got["max_input_tokens"]
            except Exception:           # noqa: BLE001 - a gateway without this route: the table decides
                n = None
        if n is None:
            low = m.lower()
            n = 1000000 if re.search(r"(fable|mythos|opus|sonnet|haiku)-5|(opus|sonnet)-4-[6-9]", low) else self.CONTEXT_FALLBACK
        self._context_of[key] = n
        return n

    def fill_limit(self, context):
        """Tokens a held conversation may hold with its next question: SESSION_FILL of what the model reads, and never so
        much that a full answer no longer fits (what published harnesses do: the trigger leaves the reply its room)."""
        return int(max(1000, min(context * self.SESSION_FILL, context - self.MAX_TOKENS - 2000 if context > 4 * self.MAX_TOKENS else context * self.SESSION_FILL)))

    @staticmethod
    def _used(usage, fallback_chars=0, per=2):
        """What a conversation holds after a turn, from the service's own count of that turn."""
        if isinstance(usage, dict):
            n = sum(int(usage.get(k) or 0) for k in ("input_tokens", "cache_read_input_tokens", "cache_creation_input_tokens", "output_tokens"))
            if n:
                return n
        return fallback_chars // per

    def _compact(self, turns):
        """The model's own summary of a held conversation (agentic/prompts/compaction.md), or "" when it could not be made."""
        from . import prompts
        self._local.history = [m for t in turns for m in ({"role": "user", "content": t["asked"]}, {"role": "assistant", "content": t["answered"]})]
        try:
            ans, _who = self._http(prompts.load("compaction"), False, None)
            text = ans.get("summary") if isinstance(ans, dict) else None
            return text.strip() if isinstance(text, str) else ""
        except Exception:               # noqa: BLE001 - the code's own shortened turns are used instead
            return ""
        finally:
            self._local.history = None

    def api_turn(self, prompt, scope, agent, name, web=False, effort=None):
        """One question over the Model connection in the agent's held conversation. -> (answer dict, producer).

        The agent's earlier answered turns are sent before the question, so it has what it asked and said before; every
        turn is written to the application's record (agentic/sessions.py) and comes back after a restart. A turn whose
        question is word for word a question asked before (a step run again) is not sent twice. When the conversation and
        the new question would fill more than SESSION_FILL of what the model reads, the model writes a summary of it
        (compaction), the conversation is closed and kept to read, and it goes on as its next part from the summary and
        the last turns."""
        S, model = self.sessions, self.http_model or ""
        with S.lock(scope, agent):
            held = S.open_for(scope, agent, "api", model)
            turns = [t for t in (S.conversation(held["id"]) if held else []) if t["ok"] and t["asked"] != prompt]
            limit = self.context_tokens()
            need = len(prompt) // self.CHARS_PER_TOKEN
            size = held["size_tokens"] if held else 0
            sent, note = prompt, ""
            if held and turns and size + need > self.fill_limit(limit):
                summary = self._compact(turns)
                last = turns[-self.KEEP_LAST_TURNS:]
                room = max(0, self.fill_limit(limit) - need) * self.CHARS_PER_TOKEN // 2
                each = room // max(1, 2 * len(last))
                word_for_word = "\n\n".join("[turn %d] ASKED: %s\nYOU ANSWERED: %s" % (t["n"], t["asked"][:each], t["answered"][:each]) for t in last) if each >= 400 else ""
                if summary:
                    sent = ("SUMMARY OF THIS CONVERSATION SO FAR (written by you when it had filled %d%% of what you can read; the application "
                            "keeps the full text):\n%s\n\n%sTHE QUESTION NOW:\n%s" % (
                                int(self.SESSION_FILL * 100), summary, ("THE LAST TURNS, WORD FOR WORD (shortened where long):\n%s\n\n" % word_for_word) if word_for_word else "", prompt))
                else:
                    sent = self.earlier_turns(scope, agent, self.fill_limit(limit) - need) + prompt
                S.close(held["id"], "compacted: it held %s tokens and the next question about %s; this model reads %s, and a conversation is "
                                    "continued up to %d%% of that. %s" % ("{:,}".format(size), "{:,}".format(need), "{:,}".format(limit), int(self.SESSION_FILL * 100),
                                                                      "The model's summary starts the next part." if summary else "No summary could be made: the last turns, shortened, start the next part."))
                held, turns, note = None, [], ", after compaction"
            if held is None:
                part = S.last_part(scope, agent) + 1
                title = name if part == 1 else "%s · part %d" % (name, part)
                sid = S.begin(scope, agent, title, "api", model, None, part)
                S.set_terminal(sid, "kept by the application")         # the service keeps nothing: the conversation is this record
                S.close_others(scope, agent, sid, "a new conversation took over: another model was chosen, or this one was compacted")
                row = {"id": sid, "name": title}
            else:
                row = held
            self._local.history = [m for t in turns for m in ({"role": "user", "content": t["asked"]}, {"role": "assistant", "content": t["answered"]})]
            t0 = time.time()
            try:
                try:
                    ans, producer = self._http(sent, web, effort)
                except RuntimeError as e:
                    if "HTTP 400" in str(e) and self._local.history and getattr(self, "cache_refused", "") != (custom_url() or "anthropic"):
                        self.cache_refused = custom_url() or "anthropic"        # an address that does not take the caching field: asked once more without it
                        ans, producer = self._http(sent, web, effort)
                    else:
                        raise
            except Exception as e:      # noqa: BLE001 - written down, then the caller decides (the next runtime, the stand-in)
                if str(e) != "the run was stopped":
                    S.add_turn(row["id"], sent, "", ok=False, problem=str(e)[:400], seconds=round(time.time() - t0, 1))
                raise
            finally:
                self._local.history = None
            usage = getattr(self._local, "usage", None)
            answered = json.dumps(ans, ensure_ascii=False)
            n = S.add_turn(row["id"], sent, answered, ok=True, seconds=round(time.time() - t0, 1), tokens=usage, producer=model,
                           size_tokens=self._used(usage, sum(len(t["asked"]) + len(t["answered"]) for t in turns) + len(sent) + len(answered), self.CHARS_PER_TOKEN))
            if n > 1 or note:
                producer += " (conversation \"%s\", turn %d%s)" % (row["name"], n, note)
            return ans, producer

    # ---- opencode in a terminal, one held session per agent
    def opencode_ready(self):
        """-> (program path or None, the chosen model's facts or None, problem in words or "")."""
        from . import opencode_cli as oc
        exe = oc.find(self.opencode_path)
        if not exe:
            return None, None, "the opencode program was not found on this computer: install it, or set agentic.opencode_path in the configuration"
        if not self.opencode_model:
            return exe, None, "no model is chosen for opencode: choose one in Settings"
        facts = oc.model_facts(exe, self.opencode_model)
        if facts is None:
            _lst, problem = oc.models(exe)
            return exe, None, problem or "opencode does not offer the model %s on this computer: choose another in Settings" % self.opencode_model
        return exe, facts, ""

    def _opencode(self, prompt, box, web, effort, scope, agent, name):
        """One turn. -> (answer dict, producer). See terminal_turn."""
        out = self.terminal_turn(prompt, box, scope, agent, name, web=web, effort=effort, want_json=True)
        return out["answer"], out["producer"]

    def terminal_turn(self, prompt, box, scope, agent, name, web=False, effort=None, want_json=True, timeout=None,
                      oc_agent=None, read_dirs=None, on_line=None):
        """One question to the agent's held opencode session; the session is started when the agent has none.

        -> {"answer" (the JSON object, when want_json), "text", "producer", "session" (the application's row), "turn"}.
        The agent's open session is continued while the session and the new question fit in SESSION_FILL of what the
        model reads; otherwise a new session continues the conversation as its next part, and the earlier one is closed
        and kept to read. A session opencode no longer has (its own store was cleared) is replaced the same way, once.
        Every turn is written down with its question, also the ones that failed."""
        from . import opencode_cli as oc
        exe, facts, problem = self.opencode_ready()
        if problem:
            raise RuntimeError(problem)
        model, S = self.opencode_model, self.sessions
        variant = oc.variant_for(effort, facts["variants"])
        env = dict(oc.environment(exe=exe, read_dirs=read_dirs), PWD=box)       # the program takes its folder from PWD too: without it the agent's folder was the server's
        limit = timeout or self.timeout * (2 if web or effort else 1)
        room = int((facts["context"] or 200000) * self.SESSION_FILL)
        need = len(prompt) // self.CHARS_PER_TOKEN
        lock = S.lock(scope, agent) if S is not None else threading.Lock()
        with lock:
            held = S.open_for(scope, agent, "opencode", model) if S is not None else None
            if held and held["size_tokens"] + need > room:
                S.close(held["id"], "full: it held %d tokens and the next question about %d; this model reads %d, and a session is "
                                    "continued up to %d%% of that" % (held["size_tokens"], need, facts["context"] or 200000, int(self.SESSION_FILL * 100)))
                held = None
            replaced, last = False, "no answer"
            for attempt in range(self.TERMINAL_TRIES):
                self._stopped()
                sent = prompt
                if held is None:
                    part = (S.last_part(scope, agent) + 1) if S is not None else 1
                    title = name if part == 1 else "%s · part %d" % (name, part)
                    if S is not None and part > 1:
                        # a new session does not have the earlier turns: they are given from the application's own record
                        sent = self.earlier_turns(scope, agent, room - need) + prompt
                    row = {"id": S.begin(scope, agent, title, "opencode", model, box, part) if S is not None else None, "name": title,
                           "part": part, "turns": 0, "terminal_id": None}
                    if S is not None:
                        S.close_others(scope, agent, row["id"], "a new session took over: another model was chosen, or this one was full or could not be continued")
                    cmd = oc.command(exe, model, title=title, web=web, variant=variant, agent=oc_agent)
                else:
                    row = held
                    cmd = oc.command(exe, model, session=held["terminal_id"], web=web, variant=variant, agent=oc_agent)
                t0 = time.time()
                p = self._run_watched(cmd + ["--print-logs", "--log-level", "ERROR"], sent, box, limit, env, oc.service_refused, on_line)
                r = oc.read_events(p.stdout)
                said = oc.service_said(p.stderr)
                secs = round(time.time() - t0, 1)
                if S is not None and r["session"] and not row.get("terminal_id"):
                    S.set_terminal(row["id"], r["session"])
                    row["terminal_id"] = r["session"]
                answer, text, bad = None, r["text"], ""
                too_many = bool(r["too_many"] or p.ended_for)
                if p.ended_for:
                    bad = "the model's service refused the call: %s" % (said or p.ended_for)[:300]
                elif p.timed_out:
                    bad = "no answer within %d s: the call was ended%s" % (limit, " (the model's service said: %s)" % said[:200] if said else "")
                elif p.returncode != 0 or r["error"]:
                    bad = (r["error"] or said or (p.stderr or "").strip()[-300:] or "exit %d" % p.returncode)
                elif not "".join(r["texts"]).strip():
                    bad = "the model wrote nothing"
                elif want_json:
                    for t in reversed(r["texts"]):      # with tools the answer comes after them: the last text holding an object
                        if "{" in t:
                            try:
                                answer, text = parse_json_object(t), t
                                break
                            except ValueError:
                                continue
                    if answer is None:
                        bad = "the answer holds no JSON object"
                size = oc.size_now(r["tokens"])
                if not bad:
                    turn = S.add_turn(row["id"], sent, text, ok=True, seconds=secs, tokens=r["tokens"], size_tokens=size,
                                      producer=facts["name"]) if S is not None else 1
                    self.slots.went_well()
                    tools = sorted({t["tool"] for t in r["tools"] if t["tool"]})
                    producer = "%s (opencode in a terminal, session \"%s\", turn %d%s%s%s)" % (
                        facts["name"], row["name"], turn, ", with web search" if web else "", ", effort %s" % variant if variant else "",
                        ", read with: %s" % ", ".join(tools) if tools else "")
                    return {"answer": answer, "text": text, "producer": producer, "session": row, "turn": turn, "seconds": secs}
                last = bad
                if S is not None:
                    S.add_turn(row["id"], sent, "".join(r["texts"]), ok=False, problem=bad, seconds=secs, tokens=r["tokens"],
                               size_tokens=size or None)
                if too_many:
                    self.slots.too_many()
                net = oc.network_trouble(bad) and not too_many     # the service was not reached: nothing is wrong with the session
                if held is not None and not replaced and not net:
                    # the turn failed in the held session (opencode's own store may have been cleared; measured: a session the
                    # service once refused stayed refused while a new one was answered): the conversation goes on in a new one
                    if S is not None:
                        S.close(held["id"], "a turn failed in it (%s): a new session goes on" % bad[:120])
                    held, replaced = None, True
                    continue
                if S is not None and (too_many or not row.get("terminal_id")):
                    S.close(row["id"], ("the model's service refused it: %s" if row.get("terminal_id") else "it never started: %s") % bad[:200])
                    held = None
                else:
                    held = S.get(row["id"]) if S is not None else None
                if attempt < self.TERMINAL_TRIES - 1 and (too_many or net or bad == "the model wrote nothing"):
                    wait_until = time.time() + self.TERMINAL_WAITS[min(attempt, len(self.TERMINAL_WAITS) - 1)]
                    while time.time() < wait_until:
                        self._stopped()
                        time.sleep(0.5 if self.TERMINAL_WAITS[0] >= 1 else 0.01)
                    continue
                break
            raise RuntimeError(last)

    EARLIER_TURNS, EARLIER_CHARS = 6, 20000     # what a new session is given of the conversation before it

    def earlier_turns(self, scope, agent, room_tokens=None):
        """The agent's last answered turns from the application's record, as text put before the question of a session that
        starts where another ended (full, refused, another model). "" when there is none."""
        S = self.sessions
        rows = S.recent_turns(scope, agent, self.EARLIER_TURNS) if S is not None else []
        if not rows:
            return ""
        budget = self.EARLIER_CHARS if room_tokens is None else max(0, min(self.EARLIER_CHARS, room_tokens * self.CHARS_PER_TOKEN // 2))
        each = budget // max(1, len(rows))
        if each < 400:
            return ""
        parts = []
        for t in rows:
            asked, answered = t["asked"], t["answered"]
            cut = asked.find("\n\nCONTEXT:\n")     # the question without its long context
            asked = asked if cut < 0 else asked[:cut]
            mark = asked.rfind("THE QUESTION NOW:\n")
            asked = asked if mark < 0 else asked[mark + len("THE QUESTION NOW:\n"):]
            parts.append("[earlier turn %d of session \"%s\"]\nASKED (shortened): %s\nYOU ANSWERED: %s" % (
                t["n"], t["name"], asked[:each // 3].strip(), answered[:each * 2 // 3].strip()))
        return ("EARLIER IN THIS CONVERSATION (kept by the application: the earlier session could not be continued, so its last "
                "turns are given here, oldest first):\n\n" + "\n\n".join(parts) + "\n\nTHE QUESTION NOW:\n")

    def _claude_code(self, prompt, box, web=False, effort=None):
        if not self.api_allowed:                # Claude Code works with the API key of Settings: not started
            from .policy import NOT_ALLOWED
            raise RuntimeError(NOT_ALLOWED)
        exe = self.find_claude(self.claude_path)
        if not exe:
            raise RuntimeError("the Claude Code program (claude) was not found: set agentic.claude_path in the configuration")
        cmd = [exe, "-p", "--output-format", "json", "--allowedTools", self.READ_ONLY_HERE + (",WebSearch,WebFetch" if web else "")]
        if self.model:
            cmd += ["--model", self.model]
        if effort:
            cmd += ["--effort", effort]
        # Claude Code inherits the Settings key and URL; its own background traffic to Anthropic (updates, error reports, telemetry) is off
        env = dict(os.environ, CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC="1")
        p = self._run_cli(cmd, prompt, box, self.timeout * (2 if web or effort else 1), env)
        if p.returncode != 0:
            # the reason is in the JSON answer on stdout (its "result"); stderr holds warnings: keep both, the reason last
            reason = ""
            try:
                o = json.loads(p.stdout or "")
                reason = str(o.get("result") or o.get("error") or "") if isinstance(o, dict) else ""
            except ValueError:
                pass
            raise RuntimeError((reason.strip() or ("%s\n%s" % (p.stderr or "", p.stdout or "")).strip())[-300:] or "exit %d" % p.returncode)
        outer = json.loads(p.stdout)
        text = outer.get("result") if isinstance(outer, dict) else None
        if not text:
            raise RuntimeError("empty result")
        return parse_json_object(text)


# ---------------------------------------------------------------------------------------------- progress, in one format
# (owner, 2026-11-09: the status with its percentage everywhere: reading, building, running). Every long step writes its
# note as "37% · <what> · 2.2 GB of 6.0 GB read · 1 min 10 s so far · about 2 min left"; the pages draw the bar from it.
def fmt_secs(s):
    s = int(max(0, s))
    return "%d s" % s if s < 60 else "%d min %02d s" % (s // 60, s % 60) if s < 3600 else "%d h %02d min" % (s // 3600, (s % 3600) // 60)


def fmt_bytes(n):
    for unit, k in (("GB", 1 << 30), ("MB", 1 << 20), ("KB", 1 << 10)):
        if n >= k:
            return "%.1f %s" % (n / k, unit)
    return "%d bytes" % n


def progress_text(pct, t0, what="", done=None, total=None):
    pct = max(0.0, min(99.9, float(pct)))
    el = time.time() - t0
    parts = ["%d%%" % int(pct)]
    if what:
        parts.append(what)
    if done is not None and total:
        parts.append("%s of %s read" % (fmt_bytes(done), fmt_bytes(total)))
    parts.append("%s so far" % fmt_secs(el))
    if pct >= 1:
        parts.append("about %s left" % fmt_secs(el * (100 - pct) / pct))
    return " · ".join(parts)


def parse_json_object(text):
    """The first complete JSON object in a text (models sometimes wrap it in a code fence)."""
    text = text.strip()
    m = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    if m:
        text = m.group(1)
    i = text.find("{")
    if i < 0:
        raise ValueError("no JSON object in the answer")
    dec = json.JSONDecoder()
    obj, _ = dec.raw_decode(text[i:])
    return obj


# ---------------------------------------------------------------------------------------------- the engine
class StepContext:
    def __init__(self, engine, run, step):
        self.engine, self.run, self.step = engine, run, step
        self.params = jload(run.get("params"), {}) or {}
        self.input = jload(step.get("input"), {}) or {}

    @property
    def project(self):
        p = self.engine.store.one("SELECT * FROM project WHERE id=?", (self.run["project"],)) or {}
        # the person who started THIS run is the admin its reviews are addressed to ("Admin <name>, need review"),
        # not necessarily the person who created the project
        if p and self.params.get("started_by"):
            p = dict(p, admin=self.params["started_by"])
        return p

    def progress(self, text):
        t = now()
        self.engine.store.exec("UPDATE step SET note=?, heartbeat=? WHERE id=?", (str(text)[:900], t, self.step["id"]))     # a status can say a lot
        self.engine.store.exec("UPDATE run SET heartbeat=?, updated=? WHERE id=?", (t, t, self.run["id"]))

    def output_of(self, key):
        r = self.engine.store.one("SELECT output FROM step WHERE run=? AND key=?", (self.run["id"], key))
        return jload(r["output"], {}) if r else {}

    def admin_comments(self):
        return [r["comment"] for r in self.engine.store.all(
            "SELECT comment FROM review WHERE run=? AND comment IS NOT NULL AND comment != '' ORDER BY id", (self.run["id"],))]

    def evidence(self, claims):
        rows = []
        for c in claims:
            src = c.get("source") or {}
            rows.append((self.run["id"], self.step["id"], c.get("text", "")[:2000], src.get("kind"), src.get("ref"),
                         (src.get("quote") or "")[:1000], 1 if c.get("verified") else 0, c.get("why", "")))
        sql = "INSERT INTO evidence (run, step, claim, kind, ref, quote, verified, why) VALUES (?,?,?,?,?,?,?,?)"
        many = getattr(self.engine.store, "many", None)
        if many:                            # a wide file has hundreds of claims: one write, not one per claim
            many(sql, rows)
        else:
            for r in rows:
                self.engine.store.exec(sql, r)


class Result:
    """What a step returns. review: {"title", "body" (plain sentences, may hold a markdown table), "data"} to stop for
    the admin's review; skip: a reason to mark the step skipped."""

    def __init__(self, output=None, review=None, skip=None, producer=None):
        self.output, self.review, self.skip, self.producer = output or {}, review, skip, producer


class Engine:
    """Runs the steps of every run in a background thread, one run at a time per thread."""

    def __init__(self, store, kinds, runner, services=None, cfg=None):
        self.services = services
        self.cfg = cfg or {}
        self.store = store
        self.kinds = kinds              # kind -> module with steps(params, project) -> [ {key,title,family,agent,review} ] and run_step(ctx)
        self.runner = runner
        self.threads = {}
        self.ahead = {}
        self.lock = threading.Lock()
        self.again = set()              # runs whose loop was kicked while it was alive: it looks once more before it ends (see kick)
        self.leaving = set()            # runs whose loop has decided to end: a kick from then on starts a new loop, although the old thread still lives for a moment

    # ---- runs
    def start(self, project_id, kind, target="", params=None):
        mod = self.kinds[kind]
        project = self.store.one("SELECT * FROM project WHERE id=?", (project_id,)) or {}
        plan = mod.steps(params or {}, project)
        t = now()
        rid = self.store.exec("INSERT INTO run (project, kind, target, params, state, created, updated, heartbeat) VALUES (?,?,?,?,?,?,?,?)",
                              (project_id, kind, target or "", json.dumps(params or {}), "running", t, t, t))
        # a run number can come back: the database gives the number of a deleted last run to the next one. A run that was
        # stopped and then deleted must not leave its "stopped" behind for the new run of that number (found 2026-11-13:
        # every model call of the new run was refused with "the run was stopped")
        try:
            self.runner.resume(rid)
        except Exception:           # noqa: BLE001 - a runner without that method (a test's stand-in)
            pass
        # ... and for the same reason a new run never inherits the terminal sessions of an earlier run of its number
        try:
            held = getattr(self.runner, "sessions", None)
            if held is not None:
                held.delete_scope("run:%s" % rid)
        except Exception:           # noqa: BLE001
            pass
        for i, s in enumerate(plan):
            self.store.exec("INSERT INTO step (run, idx, key, title, family, agent, state, needs_review, input) VALUES (?,?,?,?,?,?,?,?,?)",
                            (rid, i, s["key"], s["title"], s.get("family", ""), s.get("agent", ""), "waiting", 1 if s.get("review") else 0,
                             json.dumps(s.get("input") or {})))
        self.kick(rid)
        return rid

    def insert_steps(self, rid, after_idx, plan):
        """Add steps to a run right after the step at after_idx (the later steps move down). Used when a review decides
        what comes next, for example the Family 3 items the admin picked for this data."""
        if not plan:
            return
        c = self.store.con()
        try:
            c.execute("UPDATE step SET idx = idx + ? WHERE run=? AND idx > ?", (len(plan), rid, after_idx))
            for i, s in enumerate(plan):
                c.execute("INSERT INTO step (run, idx, key, title, family, agent, state, needs_review, input) VALUES (?,?,?,?,?,?,?,?,?)",
                          (rid, after_idx + 1 + i, s["key"], s["title"], s.get("family", ""), s.get("agent", ""), "waiting",
                           1 if s.get("review") else 0, json.dumps(s.get("input") or {})))
            c.commit()
        finally:
            c.close()

    def set_input(self, rid, key, **values):
        """Merge values into the input of one step of a run (what an approval hands to the next step)."""
        s = self.store.one("SELECT id, input FROM step WHERE run=? AND key=?", (rid, key))
        if s is None:
            return
        inp = jload(s["input"], {}) or {}
        inp.update(values)
        self.store.exec("UPDATE step SET input=? WHERE id=?", (json.dumps(inp), s["id"]))

    def kick(self, rid):
        with self.lock:
            th = self.threads.get(rid)
            if th and th.is_alive() and rid not in self.leaving:
                # (2026-11-15) The loop is alive, but it may be on its way out: it read "this step waits for the admin" a moment before the
                # admin's decision was stored. Before, this kick returned, the loop ended, and nobody ran the next step: the run stayed
                # "running" with nothing running (seen twice in tests/test_application_code_items.py, where four flows are approved as fast
                # as their cards appear). Now the loop is told to look once more before it ends, so a decision is never lost.
                self.again.add(rid)
                return
            self.again.discard(rid)
            self.leaving.discard(rid)
            th = threading.Thread(target=self._loop, args=(rid,), name="agentic-run-%s" % rid, daemon=True)
            self.threads[rid] = th
            th.start()

    def _may_leave(self, rid):
        """The loop of a run asks before it ends. False: a kick came meanwhile, look once more. True: it leaves, and a kick from now on
        starts a new loop (decided under the same lock as kick, so no kick falls between the two)."""
        with self.lock:
            if rid in self.again:
                self.again.discard(rid)
                return False
            if self.threads.get(rid) is threading.current_thread():
                self.leaving.add(rid)           # this loop ends now; the entry in self.threads stays (other readers look it up), kick starts a new one
            return True

    def resume_all(self):
        """At start-up: every run left 'running' (the server stopped under it) continues from its first unfinished step."""
        for r in self.store.all("SELECT id FROM run WHERE state='running'"):
            self.store.exec("UPDATE step SET state='waiting' WHERE run=? AND state='running'", (r["id"],))
            self.kick(r["id"])

    def _loop(self, rid):
        while True:
            run = self.store.one("SELECT * FROM run WHERE id=?", (rid,))
            if not run or run["state"] != "running":
                if self._may_leave(rid):
                    return
                continue
            step = self.store.one("SELECT * FROM step WHERE run=? AND state NOT IN ('done','approved','skipped') ORDER BY idx LIMIT 1", (rid,))
            if step is None:
                self._finish(rid, "finished")
                if self._may_leave(rid):
                    return
                continue
            self._start_ahead(run)
            if step["state"] in ("needs_review", "failed", "rejected"):
                if self._may_leave(rid):
                    return          # the run waits for the admin (or for "run again"); what may work ahead goes on
                continue            # a decision came while this loop was on its way out: the steps are read again
            if step["state"] == "running":
                time.sleep(1)       # it is already working ahead of its turn: wait for it, never run it twice
                continue
            self._run_step(run, step)

    # ---- work ahead of its turn (owner, 2026-11-10: "why not simultaneous if there is space, just wait for approval")
    AHEAD_AT_ONCE = 2           # chains working ahead at the same time, beside the run's own step; their model calls share the runner's places (AgentRunner.slots)

    def _start_ahead(self, run):
        """Steps the run's kind says may work before their turn (they need no decision and read only their own input) start in the background, a few at a time."""
        mod = self.kinds.get(run["kind"])
        if mod is None or not hasattr(mod, "ahead_chains"):
            return
        try:
            chains = mod.ahead_chains(self.store.all("SELECT id, key, state, idx FROM step WHERE run=? ORDER BY idx", (run["id"],)))
        except Exception:           # noqa: BLE001 - working ahead is an extra; the run goes on in order without it
            return
        me = threading.current_thread()
        with self.lock:
            live = [t for t in self.ahead.get(run["id"], []) if t.is_alive() and t is not me]
            names = {t.name for t in live}
            for chain in chains:
                if len(live) >= self.AHEAD_AT_ONCE:
                    break
                name = "ahead-%d-%d" % (run["id"], chain[0])
                if name in names:
                    continue
                th = threading.Thread(target=self._run_chain, args=(run["id"], chain), name=name, daemon=True)
                live.append(th)
                th.start()
            self.ahead[run["id"]] = live

    def _run_chain(self, rid, chain):
        for sid in chain:
            run = self.store.one("SELECT * FROM run WHERE id=?", (rid,))
            if not run or run["state"] != "running" or not self._claim(sid):
                return              # stopped, or taken by the run itself: nothing to do here
            self._run_step(run, self.store.one("SELECT * FROM step WHERE id=?", (sid,)), claimed=True)
            if (self.store.one("SELECT state FROM step WHERE id=?", (sid,)) or {}).get("state") not in ("done", "skipped"):
                return              # a failure waits for the admin like any other
        run = self.store.one("SELECT * FROM run WHERE id=?", (rid,))
        if run and run["state"] == "running":
            self._start_ahead(run)  # the next file

    def _claim(self, sid):
        t = now()
        return self.store.claim("UPDATE step SET state='running', started=?, heartbeat=?, attempts=attempts+1, error=NULL WHERE id=? AND state='waiting'", (t, t, sid))

    def _typical_seconds(self, step):
        """How long steps of this kind took before (a model call, a tester...): the median, or two minutes when none has run yet."""
        kind = lambda k: k.rsplit(":", 1)[-1] if k.startswith("f3:") else k.split(":", 1)[0]        # noqa: E731
        rows = self.store.all("SELECT key, finished - started AS d FROM step WHERE finished IS NOT NULL AND started IS NOT NULL ORDER BY id DESC LIMIT 400")
        same = sorted(r["d"] for r in rows if kind(r["key"]) == kind(step["key"]) and r["d"] and r["d"] > 0)
        return max(10.0, same[len(same) // 2]) if same else 120.0

    def _tick_step(self, step, t0, done, every=4.0):
        """Every step shows a percentage. A step that reports its own is left alone. One that cannot (waiting for a model, one long query)
        gets an estimate from how long steps of its kind took before, marked "about" and never past 95 %."""
        typical = self._typical_seconds(step)
        while not done.wait(every):
            r = self.store.one("SELECT note, state FROM step WHERE id=?", (step["id"],)) or {}
            note = r.get("note") or ""
            base = re.sub(r" · [^·]* so far$", "", re.sub(r"^about \d+% · ", "", note))
            if r.get("state") != "running" or (re.search(r"\d+(\.\d+)?\s*%", base) and not note.startswith("about ")):
                continue
            el = now() - t0
            text = "about %d%% · %s · %s so far" % (min(95, int(100 * el / typical)), base or step["title"], fmt_secs(el))
            if not done.is_set():
                self.store.exec("UPDATE step SET note=? WHERE id=? AND state='running'", (text[:500], step["id"]))

    def _run_step(self, run, step, claimed=False):
        if not claimed and not self._claim(step["id"]):
            return                  # another thread took it a moment ago
        step = self.store.one("SELECT * FROM step WHERE id=?", (step["id"],))
        t = step["started"] or now()
        ctx = StepContext(self, run, step)
        ticking = threading.Event()
        threading.Thread(target=self._tick_step, args=(step, t, ticking), name="tick-%s" % step["id"], daemon=True).start()
        try:
            try:
                res = self.kinds[run["kind"]].run_step(ctx)
            finally:
                ticking.set()
        except Exception as e:      # noqa: BLE001 - the step is marked failed with its error; the run waits
            if self.store.claim("UPDATE step SET state='failed', error=?, finished=? WHERE id=? AND state='running'",
                                ("%s\n%s" % (e, traceback.format_exc()[-2000:]), now(), step["id"])):
                self.store.exec("UPDATE run SET summary=?, updated=? WHERE id=?", ("step '%s' failed: %s" % (step["title"], str(e)[:200]), now(), run["id"]))
            return
        out = json.dumps(res.output)
        if (self.store.one("SELECT state FROM run WHERE id=?", (run["id"],)) or {}).get("state") == "stopped":
            # the run was stopped while this step worked (for example: its procedure was edited meanwhile): its result is
            # kept on the step, but no review is opened for it
            self.store.exec("UPDATE step SET state='skipped', output=?, note=?, finished=?, producer=? WHERE id=? AND state='running'",
                            (out, "the run was stopped while this step worked: its result is not shown for review", now(), res.producer, step["id"]))
            return
        if res.skip:
            self.store.exec("UPDATE step SET state='skipped', output=?, note=?, finished=?, producer=? WHERE id=? AND state='running'",
                            (out, res.skip, now(), res.producer, step["id"]))
        elif res.review and step["needs_review"]:
            if not self.store.claim("UPDATE step SET state='needs_review', output=?, finished=?, producer=? WHERE id=? AND state='running'",
                                    (out, now(), res.producer, step["id"])):
                return              # stopped meanwhile: no review is opened
            self.store.exec("INSERT INTO review (run, step, title, body, data, state, created) VALUES (?,?,?,?,?,?,?)",
                            (run["id"], step["id"], res.review.get("title", step["title"]), res.review.get("body", ""),
                             json.dumps(res.review.get("data") or {}), "open", now()))
        else:
            self.store.exec("UPDATE step SET state='done', output=?, finished=?, producer=? WHERE id=? AND state='running'", (out, now(), res.producer, step["id"]))

    def _finish(self, rid, state):
        self.store.exec("UPDATE run SET state=?, updated=? WHERE id=?", (state, now(), rid))
        mod = self.kinds.get((self.store.one("SELECT kind FROM run WHERE id=?", (rid,)) or {}).get("kind"))
        if mod is not None and hasattr(mod, "on_finish"):
            try:
                mod.on_finish(self, rid)
            except Exception as e:      # noqa: BLE001 - recorded on the run
                self.store.exec("UPDATE run SET summary=? WHERE id=?", ("finished, but the final step failed: %s" % e, rid))

    # ---- the admin's decisions
    def decide(self, review_id, decision, admin, comment="", edits=None):
        rv = self.store.one("SELECT * FROM review WHERE id=?", (review_id,))
        if not rv or rv["state"] != "open":
            raise ValueError("this review is not open")
        # one press counts: the review is taken in one step, so two admins (or a double click) cannot both decide it
        if not self.store.claim("UPDATE review SET state='deciding' WHERE id=? AND state='open'", (review_id,)):
            raise ValueError("this review is not open")
        try:
            return self._decide(rv, review_id, decision, admin, comment, edits)
        except Exception:
            self.store.exec("UPDATE review SET state='open' WHERE id=? AND state='deciding'", (review_id,))     # nothing was decided
            raise

    def _decide(self, rv, review_id, decision, admin, comment, edits):
        t = now()
        if decision not in ("approve", "change", "reject"):
            raise ValueError("the decision must be approve, change or reject")
        state = {"approve": "approved", "change": "changes", "reject": "rejected"}[decision]
        data = jload(rv["data"], {}) or {}
        if edits is not None:
            data["edits"] = edits
        if comment:
            data["comment"] = comment
        run = self.store.one("SELECT * FROM run WHERE id=?", (rv["run"],))
        mod = self.kinds[run["kind"]]
        if decision == "approve" and hasattr(mod, "on_approve"):
            # what the approval stores (a dictionary, a strategy, a rule version) is written first: if it cannot be
            # stored, the review stays open and the admin sees why
            mod.on_approve(self, run, self.store.one("SELECT * FROM step WHERE id=?", (rv["step"],)), data, admin)
        if decision == "change" and hasattr(mod, "on_change"):
            # what a "change" records before the step runs again (for example the signal "wrong" on a proposal)
            mod.on_change(self, run, self.store.one("SELECT * FROM step WHERE id=?", (rv["step"],)), data, admin, comment)
        self.store.exec("UPDATE review SET state=?, decided_by=?, decided_at=?, comment=?, data=? WHERE id=?",
                        (state, admin, t, comment or "", json.dumps(data), review_id))
        if decision == "approve":
            self.store.exec("UPDATE step SET state='approved' WHERE id=?", (rv["step"],))
        elif decision == "change":
            step = self.store.one("SELECT * FROM step WHERE id=?", (rv["step"],))
            inp = jload(step["input"], {}) or {}
            inp.setdefault("comments", []).append(comment or "")
            if edits is not None:
                inp["edits"] = edits
            self.store.exec("UPDATE step SET state='waiting', input=? WHERE id=?", (json.dumps(inp), rv["step"]))
        else:
            self.store.exec("UPDATE step SET state='rejected' WHERE id=?", (rv["step"],))
            self.store.exec("UPDATE run SET state='stopped', summary=?, updated=? WHERE id=?",
                            ("rejected by %s at '%s'%s" % (admin, rv["title"], (": " + comment) if comment else ""), t, rv["run"]))
            if hasattr(mod, "on_reject"):
                # what a rejection takes back (for example what the rejected step kept for later runs). The rejection is
                # already written above; whatever goes wrong here, the run is still stopped
                try:
                    mod.on_reject(self, run, self.store.one("SELECT * FROM step WHERE id=?", (rv["step"],)), data, admin)
                except Exception as e:      # noqa: BLE001 - one line for the log; the rejection stands
                    sys.stderr.write("on_reject failed for review %s (run %s): %s: %s\n" % (review_id, rv["run"], type(e).__name__, " ".join(str(e).split())[:300]))
            self._halt(rv["run"], admin)
            return
        self.kick(rv["run"])

    def retry(self, rid):
        self.runner.resume(rid)
        self.store.exec("UPDATE step SET state='waiting' WHERE run=? AND state IN ('failed', 'stopped')", (rid,))
        self.store.exec("UPDATE run SET state='running', updated=? WHERE id=?", (now(), rid))
        self.kick(rid)

    def stop(self, rid, admin, why=""):
        self.store.exec("UPDATE run SET state='stopped', summary=?, updated=? WHERE id=?", ("stopped by %s%s" % (admin, ": " + why if why else ""), now(), rid))
        # a stopped run waits for nobody: its open reviews are closed
        self.store.exec("UPDATE review SET state='rejected', comment=? WHERE run=? AND state='open'", ("the run was stopped%s" % (": " + why if why else ""), rid))
        self._halt(rid, admin)

    def _halt(self, rid, admin):
        """(owner, 2026-11-11: "stop means stop") every step of the run still working, its own and those working ahead, is
        stopped now, and its model calls end: Claude Code processes are ended, the next calls refused; a result that still
        comes back is not written. "Run again" puts the stopped steps back to waiting."""
        self.store.exec("UPDATE step SET state='stopped', note=?, finished=? WHERE run=? AND state='running'", ("stopped by %s" % admin, now(), rid))
        try:
            self.runner.cancel(rid)
        except Exception:           # noqa: BLE001 - the run is stopped in the records whatever happens to a process
            pass

    # ---- what the page shows
    def view(self, rid):
        run = self.store.one("SELECT * FROM run WHERE id=?", (rid,))
        if not run:
            return None
        run["params"] = jload(run["params"], {})
        steps = self.store.all("SELECT * FROM step WHERE run=? ORDER BY idx", (rid,))
        for s in steps:
            s["input"] = jload(s["input"], {})
            s["output"] = jload(s["output"], {})
        reviews = self.store.all("SELECT * FROM review WHERE run=? ORDER BY id", (rid,))
        for r in reviews:
            r["data"] = jload(r["data"], {})
            r["chat"] = self.store.all("SELECT role, text, at FROM chat WHERE review=? ORDER BY id", (r["id"],))
        ev = self.store.all("SELECT * FROM evidence WHERE run=? ORDER BY id", (rid,))
        alive = bool(self.threads.get(rid) and self.threads[rid].is_alive())
        return {"run": run, "steps": steps, "reviews": reviews, "evidence": ev, "worker_alive": alive,
                "seconds_since_heartbeat": round(now() - (run.get("heartbeat") or run["created"]), 1)}
