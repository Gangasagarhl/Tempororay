# Work list for the agent in the real environment: close the gaps to the opportunity statement

Written on 2026-11-14 and brought up to date on 2026-11-15 for the engineer or the AI coding agent who has what the
development machine never had: real analyzer captures, a real drive, a lab bench, and engineers whose time can be
measured. Your job is a loop: **evaluate on real data, fix what fails, evaluate again, write down what you measured.**

Read first, in this order:
1. `docs/OPPORTUNITY_STATEMENT.md`: the project's official statement as 16 numbered statements (S1 to S16).
2. `docs/OPPORTUNITY_COVERAGE_2026-11-15.md`: the check of each statement against this code, under the owner's design,
   with a column that says what was built on 14 and 15 November. **Result: 0 of 16 fully covered, 14 partly, 2 not.**
   Every "partly" rests on synthetic recordings and a simulated drive. (It replaces
   `docs/OPPORTUNITY_COVERAGE_2026-11-14.md`, which put the question about VIAVI wrongly.)
3. `docs/CHANGES_2026-11-15.md`: what was built on 14 and 15 November, part by part, with what each part's own tests
   showed and what is not done. Then `docs/CHANGES_2026-11-15_round2.md`: the second round of 15 November (the start
   page without the tool question, the hierarchy of the rules library, the order of the flow, 52 rule families for
   NVMe command errors, timing on the procedural graph). Items A8 and B11 to B15 below come from it.
4. `deploy/WINDOWS.md` if the machine is Windows (the application has never run there), and section 1 of
   `deploy/AGENT_INSTRUCTIONS.md` (seven hard rules).

**The state of the code of 14 and 15 November.** Several items below now have code. Each part passed its own tests on
synthetic recordings, a simulated drive, or with a stand-in in place of the model, as `docs/CHANGES_2026-11-15.md` says
part by part. The whole test suite ran once on the joined code (15 November, 01:00 to 01:45): 58 of 60 offline groups
and 8 of 10 groups through the running application and the browser passed; the four failures were repaired, and one of
them was a real fault of this round (`docs/CHANGES_2026-11-15.md`, section 19). A second run on the final code
followed at 02:11; its result is the line below. No new page was looked at by a person in a browser; the browser test
groups ran against the application. "Has code" below never means "works on real data".

TESTS ON THE JOINED CODE: on 15 November 2026, from 02:11 to 02:51, the whole suite ran on the joined code in five parts side by side: 60 offline groups and 10 groups through the running application and the browser. All 70 passed. After that run one module was corrected once more (the recheck by the terminal agent, after its trial with the real opencode program), and the eight groups that touch it were run again on the final code at 02:52: all eight passed (unit_f4recheck 60 tests, unit_family4 40, unit_f4faults 42, unit_flowpage 15, unit_form 20, the flow on any CSV 0 checks failed, the agent families through the application 86 checks, a whole flow twice 72 checks). This is synthetic data, a simulated drive, and the stand-in in place of the model in most groups.

**The second round of 15 November** (`docs/CHANGES_2026-11-15_round2.md`) was built after the run above. Each of its
parts passed its own tests, on synthetic recordings, a simulated drive, the stand-in or a scripted model in place of a
real model, and hand-written result files in place of a real validation suite. The run of the whole suite on that
joined code is recorded in the last section of that record. No real model, no real opencode program, no real capture,
no real drive and no real validation suite was used for any of it. **A fault of the engine was found in that round and
fixed** (section 0a of that record): Approve pressed at one exact moment could leave an analysis "running" with
nothing running, until the application was started again. One unit test and one clean run cover the fix; one clean run
does not prove that a race is gone. If an analysis ever stands still after Approve, write down which card it was and
tell the owner.

**The design you must keep.** There is no code per measuring tool. The people who have a tool convert its recording to
CSV (or another delimited text) with the tool's own software. Family 1 learns the columns from the files. Family 2
(joining files into one tree) is optional. Family 3 is the admin with agents making rules. Family 4 is the coding
research family. Never add a loader or a column list in code for a tool.

---

## 1. Rules

1. The seven hard rules of `deploy/AGENT_INSTRUCTIONS.md` section 1, and the nine rules of `deploy/WINDOWS.md` section 2.
2. **A drive is touched only with the owner's word, each time.** Never format, sanitize or download firmware. Use a
   scratch namespace. The written tests refuse to run without their allow-list and their erase confirmation
   (`nvme_hier/regress/f2t_nvme.py`): never bypass those switches.
3. **Real captures are confidential.** Never put a row of a real capture, a serial number or a customer name into a
   test file, a document or the public repository. A test made from real data keeps only a small cut with the
   identifying values replaced, and the owner agrees first.
4. **No model is trained or fine-tuned** (the owner's rule). "Learning" in this project is counting and a search whose
   state is stored. Section 3 item B4 stays inside that rule.
5. **A number is only what was measured.** State the unit, the sample (which recordings, how many, real or synthetic)
   and the script that produced it. A machine's seconds are not an engineer's hours.
6. **Do not delete or weaken a test.** A fix comes with a test that fails without it. After every change:
   `bash run_tests.sh --offline` must pass as before.
7. Ask the owner when a step needs a decision that is theirs: section 4 lists them.

---

## 2. Gaps of the first kind: built, and only the real environment can prove or break them

These need no new feature first. Run them on real data, record the result, fix what fails.

| No. | What to do | Statements | What to record |
|---|---|---|---|
| A1 | Load one real five-file LeCroy export through the main flow (start page, pages 1 to 4). Then a second, larger one (4 to 6 GB) | S1, S3, S5, S14 | load time and memory; per join how many rows stayed unlinked; errors found per rule; every stop or wrong-looking result with the rows that show it |
| A2 | Compare the errors found with what the analyzer software itself reports for the same capture (its error summary; `README_FIRST.md`, "Comparing with the analyzer's own error list") | S1, S14 | per error kind: the analyzer's count, this application's count, the reason for each difference |
| A3 | Check three faults that were known and left open (see below) on the real capture. Two of them now have code | S1, S5 | whether each one shows on real data, with counts |
| A4 | Let the real model propose (Settings, Model connection) on real errors: the isolation text, the expected outcomes, the test plan with "author: model" | S6, S15 | how often the admin had to correct the proposal, and what was wrong |
| A5 | With a drive (after item B1): run written tests of `suite/hier/` on the faulty firmware and on the fixed one | S2, S3, S8, S14 | per test: caught on faulty (yes/no), passes on fixed (yes/no), runs needed, time to the first reproduction |
| A6 | Measure the two outcome numbers with people (protocol in section 5) | S2, S13, S15 | engineer minutes with and without the tool on the same recordings; minutes to write a test by hand and with the tool |
| A7 | Try once what was built on 14 and 15 November with a real model and the real opencode program (list below) | S5, S6, S15 | per point of the list: what happened, seconds, model calls |
| A8 | Try once what the second round of 15 November built, on a real five-file export and with a real model (list below, after A7) | S1, S3, S5, S14 | per point of the list: what happened, the counts, seconds, model calls |

**What changed on 14 and 15 November for A1 to A6:**
- **A1.** Three more things to record on the real export. (1) The build's report now has a count of link transactions
  closed by a later Ack (see A3); write it down. (2) Each isolated error now keeps the rows around it in the knowledge
  base: record the size of one archived window (on the synthetic sample S17: 0.5 to 1.8 megabytes compressed; the limit
  of 32 megabytes rests on that one sample). (3) Whether the export gives the data bytes of packets or only their
  length ("64 B"): the cause of a never-completed command needs the bytes.
- **A2.** Nothing changed.
- **A3.** See the three faults below.
- **A4.** The real model ran once on 14 November through Family 1, Family 3 and Family 4, on a made-up CSV with
  disguised column names (not a real export). The three faults that run showed are repaired, tested with a scripted
  model only. Run it again with the real model (A7). The run did not include the isolation text, the expected outcomes
  or the test plan, so A4 itself is as open as before.
- **A5.** The approved tests can now be handed over as a package (B7): its README gives the exact command for a real
  drive and for the simulated drive, and the result file can be brought back. Use it for A5 and record the same things.
  The commands in that README are written for a Unix shell.
- **A6.** Nothing changed. No person was timed.

**The three known open faults (A3):**
- **Cause rules for a command that never completed: now has code.** `nvme_hier/evidence.py` finds the host's Abort
  that names the command and the controller reset by identity in the packets file, counts what the drive answered
  during the wait, and decides by seven rules in a fixed order. Its own tests (18, on the synthetic sample S17 and on
  hand-made copies of its tree): the seven timeout errors of S17 get causes the rows justify (the four lost Writes
  "device internal delay" in place of "firmware stall", the two unanswered Aborts "host reset or driver recovery").
  **Still to do in the real environment:** see it on a real capture. Where an export gives only "64 B" in place of the
  data bytes, every never-completed command with an Abort or a register write in its wait gets "unknown cause" with
  that reason: check that this is what happens. Measure the time of one card on a large recording (1 to 6 ms on S17).
  The owner must decide the keyword for a lost command while the drive answers others (section 4).
- **Sequence number reused after 4,096: now has code, with a switch.** A packet whose number comes round again is its
  own link transaction once a later Ack (acknowledgement) covered the earlier one and the analyzer wrote a link row for
  it (`nvme_hier/builder.py`). An independent review gave "release with a switch": the setting `tree.round_rule` in
  `config/app_config.json`, shipped on; off is the join as it was. Its own tests: 22 hand-made cases, 300 generated
  recordings, and 18 simulated recordings in the review. All of that is hand-made or generated data. **Still to do in
  the real environment:** on the first real recording where the report's count of link transactions closed by a later
  Ack is above zero, compare a few of those link transactions with the analyzer's own display. If they disagree, set
  `tree.round_rule` to false, build the tree again and tell the owner. Look once at the premise the repair rests on: a
  link row's time is the time of its first packet, never later. **Four limits are known and kept as tests:** numbering
  that restarts with nothing acknowledged before; a whole round with no covering Ack in the recording; a Nak (negative
  acknowledgement) joined to a link transaction acknowledged long before; a resend after a Nak that the analyzer
  exported as a link row of its own. Record whether any of the four shows on a real capture.
- **Completion-queue doorbells: no code changed.** The earlier document measured that 212 of 40,261 NVMe transactions
  on 13 generated sets are placed under a different command than the generator's record says (none is left without a
  command). A repair needs the owner's decision (`docs/CHANGES_2026-11-12.md`), a look at whether the generator's
  repeated head values are something a real host does, and a real capture.

**A7: to try once with a real model and the real opencode.** None of this has been tried. The full list, with what to
compare against, is `docs/CHANGES_2026-11-15.md` section 18. In short:
1. The unknown-CSV run again with the same answers (above all "add a third output column"): is the first build clean?
   The run of 14 November needed 5 rounds, 423 s and 12 model calls there.
2. The research step: one surprise and no conflict on that file; are real open decisions now dropped?
3. A Coder objection the Tester agrees with: does the card say "withdrawn"?
4. The REA agent with a real folder of findings and the admin's tick in Family 4: the calls and seconds it adds; do the
   answers carry quotes?
5. The recheck of Family 4's code by the terminal agent. **It ships as "only when the admin asks on the card"**
   (`agentic.f4_recheck` = `"ask"` in `config/app_config.json`; not "always"), so press the button "Recheck this code
   with the terminal agent" on the code card. Does the agent save its program and result, answer in the form and
   finish in 300 seconds? Is a right program refused for a reason of form? Does it find a planted fault? A trial with
   the real opencode program was started on 2026-11-15; its result is in the project's research notes.
6. Confinement of the recheck with the real program. The recheck uses the investigation agent's permission profile
   (the coordinator's decision). A profile of its own exists (`f2t-recheck` in `agentic/opencode_cli.py`: reading, no
   edit tool, Python and listing commands, no folder outside its own but the data folder); it is not used and has
   never run with the real program. **Known and not closed: the Python the agent starts is not confined. It can
   change or delete the data files.** Against that stand the instruction text and a watch: the application records
   every data file before the agent starts (size, change time, a fingerprint of the content) and compares after it
   ended; when a file changed, the recheck is refused with the sentence "The data changed while the terminal agent was
   rechecking: ..." and the record is kept in `recheck<k>.data_watch.json` in the run's folder. **The watch detects a
   change of a data file; it prevents nothing** and it makes no copy. It cannot catch a change that is undone before
   the comparison, data that is sent elsewhere, or a change in the middle of a file above 256 megabytes with size and
   change time kept (`docs/CHANGES_2026-11-15.md`, section 12). Work on a copy of the capture, read the watch's
   record after each recheck, and tell the owner the result before the recheck is used on real captures.
7. Stop during a real recheck: the program and the Python it started both end.
8. A review card attached to a question to the terminal agent: does it open the card file by itself? A card whose text
   holds an order: does it report the sentence and not act on it?
9. A semicolon file with decimal commas through Family 1 with a real model: are the stated facts about the form used
   well? The same file through Family 4: does the Coder open it as its instruction now says, and does it ask about a
   column whose numbers cannot be read for sure instead of guessing? (Every reader of the agent families now reads a
   file in its own form; still assuming comma, UTF-8 and a header on line 1 are the stand-in of Family 2, "Ask all the
   Managers" and the list of refused files on the flow pages.)
10. A rule in the section "Errors" on a file outside the tree: does the Rule writer put the row-number column into the
    output? (The two built-in sections are called "Data analytics" and "Errors"; "Errors" was called "Error roots"
    before 15 November.)

**A8: to try once what the second round of 15 November built.** None of this has been tried on real data or with a
real model. The full list is `docs/CHANGES_2026-11-15_round2.md` section 16. For each point: what to do, how to know
it worked, and the file that holds the code.

1. **The start page without the tool question.** Give the folder of a real five-file export and press "Check".
   *It worked when* every CSV file has a sentence that names the tool it was recognised as, the folder line reads
   "Recognised from the files: an export of Teledyne LeCroy PCIe Protocol Analysis (5 of the 5 CSV tables match that
   tool's column list)", and the fixed joining strategy is offered after Family 1. Then a folder of another tool's
   CSV files: the line must say that no tool was recognised and that the agents learn the columns from the files.
   Code: `agentic/source_tools.py` (`recognised_from`), `app/api/agentic_api.py` (the inventory and start routes).
2. **A folder with no CSV table.** Give a folder that holds only files that are not CSV. *It worked when* the page
   says "No CSV table in this folder: the agent families read tables." with the files grouped by ending, count and
   size, and "Start the flow" is off. Code: `agentic/family1.py` (`other_files`), `app/static/js/agents.js`
   (`checkFolder`).
3. **The page of one error waits for the approval.** In an analysis with a tree, open the address of an error whose
   pattern's result card is still open. *It worked when* the page shows only "This error cannot be opened yet" with
   the reason, and opens normally after the result is approved. Code: `agentic/pipeline.py`
   (`error_page_refusal`), `app/api/isolate_api.py` (`_flow_refusal`).
4. **A rule of your own, the whole way.** Under Errors, NVMe errors, NVMe command level errors, add an item in your
   own words, with a real model connected. *It worked when* the Rule writer's procedure names the column "row number
   in the file" first, Family 4's requirements and code cards come, the result card says "Approve to accept it and
   file ...", nothing is on the errors page before you approve, and after the approval each found row is an error
   that goes through the isolation, the cause and solution, and the test. Compare the found rows with a count made
   by hand. Code: `nvme_hier/coded_findings.py`, `agentic/family3.py`, `agentic/pipeline.py`.
5. **The header of a level's file.** Load a real upload with this round's code: the loader keeps the header of each
   level at the load. (For an upload loaded earlier, the plan card of page 3 must have been made once.) Then write a
   rule that names a column the first row of the file leaves empty, for example the number of blocks. *It worked when*
   Family 4 does not answer that the file has no such column. Also record, on a real file of several gigabytes: the
   load time (on a synthetic sample of 64 megabytes keeping the header made no measurable difference), and how long
   Family 4's facts take for a column that is empty in every row of the packets file (the builder estimates about a
   minute for each such column on 6 gigabytes, with no progress shown; not measured). Code: `nvme_hier/loader.py`
   (`header_names`, `store_header`), `nvme_hier/tree_api.py` (`columns`, `column_state`, `store_headers`),
   `agentic/family4.py` (`data_facts`).
6. **The hierarchy in a browser.** The Rules library reads section, kind of recording, level; add a kind, a level
   with its file pattern and an item; edit and delete them. *It worked when* each appears at its place under every
   section, the place line of the item names all its parts, and deleting a level that holds an item is refused with
   the count. Code: `agentic/rule_hierarchy.py`, `app/api/rules_hierarchy_api.py`.
7. **A rule of the application's rule set, the whole way, without a model.** Under Errors, NVMe errors, NVMe command
   level errors, tick the built-in rule "NVMe command timeout" and the rule "A command never completed", with no model
   connected. *It worked when* nothing is on the errors page before you approve each result; the result card of the
   second rule says "The same command, found twice" with the rows when both rules found the same commands; after the
   approval each found row is an error with a page of its own; and on the errors page both errors of one command say
   "The same command is also listed under ..." with a link to the other. Compare the found rows with a count made by
   hand. Code: `agentic/pipeline.py` (`same_command`), `agentic/family3.py` (`rule_origin`),
   `nvme_hier/coded_findings.py`.

---

## 3. Gaps of the second kind: what a real environment does not fix by itself

In the order of how much of the statement each one unlocks. For each: where the code is today, what exists since 14 and
15 November and what its own tests showed, and what the real environment must still do. An item with code is not
closed: its "done when" names what is still open.

**B1. The lab bench connection** (S2, S3, S7, S8, S12). **Not built.**
- Today: `app/bench_hook.py` `run()` stops with "not implemented"; `config/app_config.json` has
  `stage2.bench = "synthetic"`, so every lab run is simulated.
- Build: `run(scenario)` and `detect(trace)` exactly as `deploy/BENCH_INTEGRATION.md` sections 1 to 6 describe (drive
  the device, capture with the analyzer, export, run the detector, return the record). Then `stage2.bench = "hook"`.
- New on 14 and 15 November: two parts now wait for the bench. (1) The search on the page of one error (B2) calls the
  bench with a scenario that also carries the recorded steps with their gaps and the queue depth, and reads
  `reproduced` and an optional time of the failing command in microseconds. (2) A bench may return the detector's
  findings alone; the application computes stage, closeness and "reproduced" from them (B3). Both are now described
  in a paragraph at the end of section 2.5 of `deploy/BENCH_INTEGRATION.md` (built on 2026-11-14, never run on a real
  bench); the text of `app/bench_hook.py` does not describe either yet. Read also `nvme_hier/replay_search.py` (class
  `RealBench`) and `stage2/search_memory.py` (`stage_from_findings`).
- Done when: `python deploy/preflight.py` passes with the hook, one known defect is reproduced on the faulty firmware
  and not on the fixed one, and the capture of that run is kept.
- Note: the replay library of the written tests uses the Linux NVMe passthrough. On Windows there is none in this code.

**B2. The search and the stress step inside the main flow** (S7, S8, S9, S16). **Has code since 14 November.**
- What exists: on the page of one error, between the solution and the test, a search over the recorded commands before
  the failing one (which are kept, their order, the gaps, the queue depth), then the "most stressful conditions" step,
  then the written test from the searched or the most stressful sequence (`nvme_hier/replay_search.py`, routes in
  `app/api/isolate_api.py`). The earlier `/packets` workflow keeps its own search.
- What its own tests showed (42 tests, simulated drive only): on a simulated drive with a hidden trigger, 200 bench
  runs, 50 triggers: with the drive's time hint the search found 50 of 50 and a random choice 37 of 50. **Without the
  hint the search found 33 of 50 and the random choice 37 of 50: worse than random.** The hint is that the failing
  command gets slower as more hidden conditions are met. A real drive may give no such hint.
- Still to do in the real environment: connect the bench (B1). Then measure on a real drive whether the measured time
  of the failing command moves as the sequence gets closer to the failure. If it does not, the search as built should
  not be trusted over a random choice; say so and propose another signal. The written test cannot replay a queue depth
  yet (the replay library sends one command at a time).
- Done when (still open): a flow test shows seed -> search -> stress -> written test for one error (today the chain is
  tested at the route level only), the earlier workflow still passes (`packet_loop`, 65 checks; not run on the joined
  code), and the search has run on a real bench.

**B3. A reward tied to the failure signature** (S7). **Has code since 14 November; no real input yet.**
- What exists: `stage2/search_memory.py` `stage_from_findings` computes stage, closeness and "reproduced" from the
  detector's findings alone, by the table of `deploy/BENCH_INTEGRATION.md` section 2.5. Closeness compares the measured
  timing of the finding with the recorded failure when both carry one.
- What its own tests showed: hand-made records only (for example 41,000 against 43,000 microseconds gives closeness
  0.9535); a bench that returns findings only is searched to a confirmed reproduction on the simulated bench.
- Still to do: the detector's findings carry no measured timing today, and the flow's target carries only the error
  type, its group and the first rule. Until both carry timing, closeness on real findings is the detector's own score.
- Done when (still open): the search runs on the real bench without any value that only a simulator can know.

**B4. Learning from history** (S11). **Has code since 14 November; measured on the simulated bench only.**
- What exists: after every search of the earlier packet workflow, what it learned (the counts of the 14 change
  operators, the best procedure, the lab runs to the first reproduction) is kept as one event in the knowledge base.
  The next search of the same kind of defect starts from the latest 20 such searches, with the carried counts limited
  to the weight of 14 lab runs. Switch: `stage2.search_memory`, shipped on. Counting only; rule 4.
- What its own tests showed (simulated bench, 5 kinds of defect x 12 seeds = 60 pairs, 300 lab runs allowed): the
  second search needed fewer lab runs than the first in 49 of 60 pairs, the same in 11 (neither confirmed), more in 0;
  median 301 -> 72 lab runs. **The gain comes from the stored best procedure, not from the carried counts:** the counts
  alone gave 26 better, 18 equal, 16 worse.
- Limits: on the simulated bench the hidden trigger of a kind is the same in both searches, so a stored procedure
  reproduces again. After a firmware change on a real drive that need not hold. The memory is keyed by the kind of
  defect only, not by device and firmware, and it does not decay on a firmware change.
- Done when (half open): the first half (a test shows the second search needs fewer lab runs, on the simulated bench)
  is met by its own test. The second half, "the same is measured on the real bench", is open.

**B5. A recording of VIAVI, or of any other tool** (S5, S12). **Rewritten on 15 November to the design.**
- What was wrong here before: this item asked for a VIAVI column list and a loader. That contradicts the design and is
  withdrawn. **No loader and no column list in code is needed for VIAVI or for any tool.**
- What exists since 14 and 15 November: the start page has the answer "Another tool, or I do not know": Family 1 then
  learns the columns from the files themselves. The reader decides a file's form from its first lines: comma,
  semicolon, tab or vertical bar; a header that is not on line 1; UTF-8 or UTF-16; decimal commas. A file that is not a
  table is refused in one sentence. Rows a rule finds in such a file become errors with a page of their own (B9 says
  how far that page goes).
- What its own tests showed: files written by the tests, the stand-in in place of the model; one run with a real model
  on a made-up CSV with disguised names. **No VIAVI export and no real export of any other tool has been read.**
- What the real environment must do:
  1. Get a real VIAVI export. The people who have the VIAVI software convert the trace to delimited text with VIAVI's
     own "Export to Text File" tool (VIAVI's release notes name the tool "Export To Text"; its columns, separator and
     time unit are shown in no public document that could be read, and the columns are chosen by the user, so two
     exports need not match).
  2. Put the file in a folder (if its name does not end in `.csv`, rename a copy: the folder scan takes only that
     ending) and start an analysis on the start page with **"Another tool, or I do not know"**.
  3. Check what Family 1 learns from it: how the reader decided its form (the Manager answers this), for how many
     columns the meaning is right, and for how many the meaning has a source the program can check (B10). Have a person
     who knows the tool judge the dictionary before it is approved.
  4. Write a rule on it with the admin, let Family 4 code it, and compare its result with a count made by hand.
- Done when: one real VIAVI export has gone from the start page to a counted rule result, and the share of right and of
  sourced meanings is written down. VIAVI's documents show two levels (events, and exchanges that group them), not
  five, so a five-file tree should not be expected.
- The label on the `/packets` page ("LeCroy / VIAVI 113-column export") still promises more than that page does: that
  page needs the 113 column names of the Teledyne LeCroy export.
- **Changed in the second round of 15 November: the start page no longer asks which tool exported the recording.**
  Wherever this item says to answer "Another tool, or I do not know", nothing is answered now: give the folder, press
  "Check", and read the line "Recognised from the files: ...". For a tool the application has no column list for, it
  says that the agents learn the columns from the files themselves. A file that is not CSV is listed by its ending,
  and the terminal agent can be asked how it becomes a table (B14). A kind of recording and its levels can be named in
  the rules library (B15).

**B6. The knowledge base** (S10). **Has code since 14 November.**
- What exists: the rows of the window around an error are kept in `db/hier_knowledge.sqlite` when the admin names the
  defect, stores or judges a solution, keeps the isolation or approves the test (`nvme_hier/archive.py`). A table for
  external workload records, kept as given, validated only by the admin's own action (routes only, no screen). One
  look-up of a defect across both stores.
- What its own tests showed (synthetic sample S17): an archived window is read back equal after the upload folder is
  deleted. So the "done when" of this item holds in a test on a synthetic recording.
- Still to do: measure a window on a real capture and adjust the limit of 32 megabytes if needed. The look-up across
  the two stores will answer "no link between the two stores for this defect" on real data, because no reliable mapping
  between the two stores exists: that needs a link the admin declares, or a mapping written by whoever owns both rule
  sets. Check the workload limits (0.25 megabytes for the definition, 4 megabytes for the result) against a real
  workload result. Decide with the owner whether the knowledge base needs a ceiling or a clean-up.
- Done when (open on real data): a validated defect of a real capture can be read back with its trace rows after the
  upload it came from was deleted.

**B7. The formal validation suite** (S8, S12). **Has code since 14 November; no suite is linked.**
- What exists: the admin ticks approved tests and downloads one package (`nvme_hier/handover.py`,
  `app/api/handover_api.py`, part 7 of the page of one error). The package holds the tests unchanged, the replay
  library, a manifest with each test's approval record and fingerprint, and a README with the exact commands and the
  safety switches. The result file of a run (JUnit XML, the format pytest writes) is brought back and recorded per
  test.
- What its own tests showed (23 tests, temporary folders, simulated drive): only approved and unchanged tests go in;
  the README's own simulated-drive command is run in the test; hostile result files are refused.
- Known: the main flow's test file names do not match what pytest collects from a folder, so the package brings a
  `pytest.ini` that names each file. The one approved main-flow test names an older replay library than today's. The
  tests of the earlier workflow need the application's stage 2 program to run.
- Still to do: the owner's answers (section 4) decide the form. Then run one package in the team's suite on a real
  drive and bring the result back.
- Done when (open): a test approved here has run inside the team's validation suite and its result is recorded here.

**B8. Looking for weaknesses before a failure** (S4). **Has code since 14 November.**
- What exists: the rules-library item "Commands that completed but came close to the limit" (`nvme_hier/near_limit.py`;
  under "Data analytics", level NVMe commands, not ticked). It lists every completed command at or above the admin's
  share of the host's time limit and under the limit. The default share is 50 per cent, the application's own starting
  value. A function gives the starting point of a sweep from such a command; no route or page uses it.
- Its code is part of the application, as the detector's rules are: in a flow no model is asked for it, the coding
  family's steps skip with one sentence, and the run step runs the application's own code. (In the first run of the
  whole suite, before this was so, the item stopped every flow in which it was chosen; repaired on 15 November.) The
  admin's share is set in the item's plan (`share_percent`, `share_set_by`); there is no field for it on a page. If
  you add a built-in item, add its kind to the one list in `agentic/procedures.py` (`APPLICATION_KINDS`) and run it
  through a whole flow in a test.
- What its own tests showed: on the four synthetic samples nothing is listed at any sensible share, because their times
  are microseconds against a limit of 30 s (largest share about 0.0013 per cent). On a copy with stretched times the
  right commands are listed in the right order.
- Still to do: run it on a real capture with no error, where times are realistic; have the owner confirm the share; and
  build the sweep that starts from a listed command (it needs the bench, B1).
- Done when (open): a command near its limit on a real recording has been swept on the bench.

**B9. The second half for any CSV** (S1, S3, S5, S9, S16). **Not built.** Found by the research of 14 November.
- Today: for a CSV file that is not part of the Teledyne LeCroy five-file tree, the flow reads the file, learns the
  columns, writes and codes a rule, counts the result, lists the found rows as errors and opens a page for one error.
  That page shows the row with its meanings, the rows around it, and an isolation written by the model around facts
  the code states. **It goes no further.** The cause by fixed rules, the procedural graph (defect, cause, solution) and
  the replay test exist only for NVMe commands of the Teledyne LeCroy five-file export.
- What exists towards it: the page shows a table of the six things the NVMe command path would need, read from the
  meanings in the approved data dictionary. It reports and changes nothing.
- Build (a design is needed first, with the owner): how a file of another tool gets a cause, a place in the graph and a
  test, without code per tool. This is the largest open piece between the design and "works for any CSV".
- Done when: an error found in a real export of another tool reaches a cause, a stored solution and a written test.

**B10. Sources for meanings** (S5, S14). **Not built.** Found by the research of 14 November.
- Today: in the one run with a real model on an unknown file, the data dictionary was right for 15 of 15 columns, but
  **11 of the 15 column meanings and 13 of 13 keyword meanings had no source the program can check** ("from the
  model's knowledge"). For the other 4, "checked" means only that the quoted value occurs in the column. The file was
  easy: short English abbreviations. A real export can have hundreds of columns whose names give no hint. Everything
  after the dictionary stands on those meanings.
- What to do in the real environment: on a real export, count the meanings with and without a source, and have a
  person who knows the tool judge them. Try the same file with web search on and record whether the share of sourced
  meanings rises (not measured so far). Where the tool's own manual is at hand, give it as a reference document: that
  is a document, not code, and it keeps the design.
- Done when: for a real export the share of meanings with a checkable source, and the share judged right by a person,
  are written down, and the admin is shown plainly which meanings have none before approving.

**Items B11 to B15 were added by the second round of 15 November** (`docs/CHANGES_2026-11-15_round2.md`). Each has
code. None has met real data.

**B11. The 52 rule families for NVMe command errors on a real capture** (S5, S14). **Has code since 15 November.**
- What exists: `nvme_hier/command_error_rules.py` holds 52 rule families in three groups (status the drive returned,
  behaviour over time, rules of the protocol). 38 run and are items of the library under Errors, NVMe errors, NVMe
  command level errors; none is chosen in advance. 14 are listed only, each with what it would need. Without a model
  an item runs the application's reference implementation and the admin decides one card. With a model Family 4 writes
  the code (at least 10 calls to the model and 3 cards for each rule, counted with the stand-in on the synthetic
  sample S17) and the Tester compares its rows with the reference. Nothing is listed before the result is approved;
  then each found row is an error with a page of its own, through the isolation, the cause, the solution and the test.
  The same command found by two rules is said on both errors. The page `/nvme-rules` shows every family with the count
  for a recording.
- What its own tests showed: on the four synthetic samples the 38 families found 16 rows in all (15 in S17, 1 in
  `demo_225_commands`). Each status family was tested on a recording made from S17 by changing cells. 200,000
  generated commands were streamed by one status family in 9.5 seconds, on rows of 13 cells. One flow test on S17 with
  the stand-in took five families and the built-in timeout rule through the whole flow, without a model and with a
  model said to be connected (61 tests, all passed; the Coder's programs were written by hand for the test).
- What to do in the real environment:
  1. Load a real five-file export, choose all 38 items, and run the flow. Write down, per family, the rows found.
  2. Compare with what a person finds by hand and with the analyzer's own report, family by family.
  3. Record which families say "cannot be checked on this recording", and why. Above all: whether the size of the
     namespace is filled on an Identify row (without it the block range family cannot run); whether "do not retry",
     "more" and the retry delay are filled on the completion rows; under which column names the status cells arrive.
  4. Record whether a real host's re-initialisation shows as the mark the reset family looks for. Record how the
     analyzer itself writes a command identifier that is used again while its command is open: in the application's
     tree such a case cannot be seen (a case made on the sample S17 showed the earlier command as "never completed"),
     and the rule says so in every result.
  5. Measure the time of one family on real rows (a real row can have up to 1,598 cells).
  6. With a real model connected: let Family 4 code one family, and one family that finds nothing in the recording.
     Record the calls to the model and the seconds for each rule. For a rule that finds errors the Tester's check
     should read "the code wrote rows, or found none"; if an empty result fails the check, that is a fault to repair
     (`agentic/family3.py`, the Tester's checks). A model's code that calls the application's reference implementation
     instead of reading the tree should be refused with a sentence (`agentic/procedures.py`, `check_code`); see
     whether the model then writes its own code in the next round. Both behaviours are tested with the stand-in and
     with programs written by hand in place of a model's code. No real model has been through this path.
  7. Record how many commands are listed by more than one rule, and whether the admin wants them as one error or as
     one for each rule (a decision of the owner; built: one for each rule, said on both).
- How to know it worked: for at least one real capture, a table per family with "found by the application", "found by
  hand" and the reason for each difference; and no family that stops a flow.
- Done when: that table exists for one real capture with a confirmed defect, and the families that cannot run on it
  are named with what the export lacks.
- Known and not closed: a model's code may read what the detector already filed for the recording, so for the four
  families that reuse the detector's findings the comparison with the reference does not show an independent finding.
  The page of one error does not yet say that another rule lists the same command. The loader and the check-again job
  of `/nvme-rules` write the tree without the lock that the errors step and the code runs take.
- Code: `nvme_hier/command_error_rules.py` (the families, `find`, `compare_with_reference`), `agentic/family3.py`
  (`seed`, `rule_origin`), `agentic/procedures.py` (`MODEL_CONNECTED`, `check_code`, `TreeLock`),
  `agentic/pipeline.py`, `nvme_hier/coded_findings.py`, `nvme_hier/nvme_command_rules.py`. Tests:
  `tests/test_command_error_rules.py`, `tests/test_command_rules_flow.py`.

**B12. Timing on the procedural graph, on a real bench** (S2, S7, S9, S11). **Has code since 15 November; measured on
a simulated drive only.** Needs B1 first.
- What exists: three tables on the graph (`nvme_hier/graph_learning.py`): lab counts per stored solution and bench;
  the timing of a solution's sequence as values (the gap before each step in microseconds, the queue depth), keyed by
  the command and its place before the failing command; and counts at a value, from which a bracket is computed. The
  search on the page of one error tries the leading stored solution and the best stored values first, then goes on
  as before, and writes its runs back. The admins' judgements are a separate ledger and are never changed by a lab
  run. Rule 4 holds: counts and a random draw, no trained model.
- What its own tests showed (simulated drive with a hidden trigger, S17, 30 triggers, 200 lab runs allowed): with
  history of the same kind and firmware, better in 28 of 30, median 10 against 48 lab runs. With stale history,
  worse in 25 of 30. With wrong history, worse in 30 of 30; the worst single case cost 84 lab runs more. At the
  median stale and wrong history cost 4 runs more.
- What to do in the real environment:
  1. Capture the same kind of defect twice on the same firmware, and search both. Does the second search, started
     from the graph, need fewer lab runs than the first? This is the question the whole benefit rests on.
  2. The same after a firmware change: is the stored timing a useful starting point, or does it cost runs?
  3. Measure the four constants (`PRIOR_RUNS`, `STALE_CAP_RUNS`, `YES_SHARE`, `NO_MIN_RUNS`; all chosen by the
     builder, none measured): how often does a real drive miss a reproduction from run to run, and are 2 runs without
     the failure enough to say "stayed away"?
  4. A second real recording of the same kind of defect with a different workload before the failure: does the step
     key find the right commands, and which stored steps are dropped?
  5. Whether the host can place gaps under about 100 microseconds dependably.
- How to know it worked: a table like the one of the change record (better, equal, worse, median, worst case), made
  on the real bench, with the number of pairs stated.
- Done when: that table exists for the real bench, and the constants are either confirmed or changed with the
  measurement that justifies it.
- Code: `nvme_hier/graph_learning.py`, `nvme_hier/replay_search.py`, `app/api/isolate_api.py` (the search block),
  `app/api/dg_api.py` (the lab and timing routes). Tests: `tests/test_graph_learning.py`.
- Not built, to know: the written test still replays gaps only and one command at a time; tuning inside the bracket;
  marking a stored point stale; host settings (power saving, time limits) as searchable values.

**B13. A validation suite's result counted on the procedural graph** (S8, S9). **Has code since 15 November; no suite
is linked.** Continues B7.
- What exists: the package's manifest says for each test which stored solution it was approved for. A result file
  brought back is counted as lab runs of that solution when the file states the bench (a real drive or the simulated
  drive), that the run looked for the error, and in how many runs the failure came back. One run is counted once.
  Any other result is kept, and the page says in one sentence why it was not counted.
- What its own tests showed: hand-written result files and the package's own simulated-drive command. No real
  validation suite and no real drive.
- What to do in the real environment: approve a test for a version of a stored solution, build a package, run it in
  the team's suite on a real drive, and bring the result file in on part 7 of the page of one error.
- How to know it worked: the line beside "Bring in" reads "The result of the test ... was counted on the procedural
  graph as lab runs of stored solution number ...: the failure came back in k of n runs on the real drive. No
  judgement and no order changed.", and part 5 shows the lab line for the real drive. Bring the same file in again:
  it must be refused. If the suite writes its own result file, expect "kept, but it was not counted" with the reason,
  and tell the owner: that case needs a decision.
- Done when: one result of a real drive is counted, once, on the right solution.
- Code: `nvme_hier/handover.py` (`solution_of_test`, `read_results`), `nvme_hier/graph_learning.py` (`add_lab`).
  Tests: `tests/test_join_error_page.py`.

**B14. The terminal agent for a folder of files that are not CSV** (S5, S12). **Has code since 15 November; never
tried with the real opencode program.**
- What exists: from the start page, the button "Ask the terminal agent about the files of this folder" opens a
  conversation of that folder's own. The agent is given a list of the folder's files and may read that folder only.
  A CSV file it writes reaches the folder only when the admin presses "Put this CSV file into the folder"; a file of
  that name already there is never replaced.
- **Known and not closed: a Python program the agent starts is not confined.** It could read, change or delete any
  file the application's user can. Only the instruction text holds it back.
- What to do in the real environment: on a copy of a real folder (never the only copy) with files that are not CSV,
  ask "what is each file, and what do I need to bring?". Then ask for one text file as a table, put it into the
  folder, and press "Check".
- How to know it worked: the agent says for each file what it saw in it; for a binary trace it names the tool that
  must export it and quotes the notes without inventing an option; the table it writes has columns named from the
  file's own names; the new CSV file is listed by "Check"; and the size and change time of every other file of the
  folder are unchanged.
- Done when: one real folder of another tool's files has been turned into CSV tables this way and started as an
  analysis.
- Code: `agentic/investigate.py` (`folder_place`, `files_note`), `app/api/investigate_api.py`,
  `agentic/prompts/investigation.md`, `app/static/js/terminal_agent.js`. Tests: `tests/test_terminal_folder.py`.

**B15. A kind of recording of your own in the rules library** (S5). **Has code since 15 November.**
- What exists: the library reads section, kind of recording, level, items. The admin can add a kind of recording and
  levels under it; each level names the file it reads, by name or pattern. A rule of such a level is written on the
  files of the analysis that match. Stored in `knowledge/rules/kinds.json`. This is naming and grouping, not code per
  tool: the design holds.
- What to do in the real environment: for the real export of another tool (B5), add its kind and one level per
  exported file, and write one rule at a level.
- How to know it worked: the rule's procedure names the level's file, the code runs on it, and the count matches a
  count made by hand.
- Known: the plan does not yet say "cannot run here" when no file of the folder matches the level's pattern; the
  Rule writer is then given all the other files.
- Done when: one rule at an added level has run on a real file of another tool.
- Code: `agentic/rule_hierarchy.py`, `app/api/rules_hierarchy_api.py`. Tests: `tests/test_rule_hierarchy.py`.

---

## 4. Decisions that are the owner's

- Which drive, firmware pair (faulty and fixed) and namespace may be used, and when.
- Which real captures may be used, and what may be kept from them.
- What "the formal validation suite" is: its name, where its tests live, the form a new test must have. The hand-over
  builder's ten questions are in `docs/CHANGES_2026-11-15.md` section 17 (which suite, its form, how it collects tests,
  its result format, who sets the safety switches, a second approver, the earlier workflow's tests, a test written with
  an older replay library, how the package travels, what a real-drive result should change).
- Who provides a real VIAVI export, converted with VIAVI's own export tool (B5).
- Whether the optional policy-gradient search may be used on the bench, or only the shipped bandit search.
- Whether a Windows way to send NVMe commands is to be written, or the drive tests stay on Linux.
- New on 15 November:
  - The cause keyword for a command the drive lost while it answered others: "device internal delay" (as built) or
    "firmware stall".
  - Whether the link join's new rule ships switched on, and which of its four known limits to repair.
  - The default share of 50 per cent for "close to the limit".
  - Whether the admin's tick "Start with <tool> all the same" should ever override the recognition limits (today it
    only lets the flow start).
  - Whether every isolation should keep its window in the knowledge base, or only from "Continue with this defect" on.
  - The reader's thresholds, and whether a table of one column should be refused.
- New in the second round of 15 November: 45 decisions, each with the cautious choice that is built today, are in
  `docs/CHANGES_2026-11-15_round2.md` section 14. The ones the real environment meets first:
  - Whether a failed lab run should also count against the cause (built: against the solution only).
  - Whether the lab counts should change the order of the solutions shown (built: no; they order only what the search
    tries first).
  - The four constants of the timing method, to be measured on the bench (B12).
  - Whether a suite's run that expects a fixed drive, or a result without the replay library's own verdict line,
    should be counted (built: kept, not counted).
  - The rule of the guard on the page of one error (built: it waits only when an analysis on the recording holds the
    pattern and no round of it has an approved result).
  - Which host limits the rule families use (built: the Linux values, 30 seconds for I/O and 60 seconds for admin
    commands, unless the admin set another limit).
  - Whether the same command found by two rules is one error or one for each rule (built: one for each rule and
    row, never merged, and said on both).
  - Whether the admin may approve a result when a model's code and the reference implementation do not find the
    same rows (built: yes; the card says the difference in words).

---

## 5. The two measurements that need people (A6)

The statement promises about 50 % less manual effort for the first log analysis. It was never measured: the only
figure is about 93 % fewer commands to read on synthetic recordings, which counts rows.

1. Take at least 10 real recordings with known defects. Two engineers of similar experience.
2. Each recording is analysed twice, by different engineers: once by hand as today, once with the application. Swap
   who uses the tool from recording to recording.
3. Stop the clock when the engineer names the failing command, the kind of defect and the cause. Record minutes, and
   whether the answer was right.
4. The same for writing a test: minutes by hand, minutes with the application including the admin's checks.
5. Report per recording and the median. Do not report a percentage without the minutes behind it.

---

## 6. Where the results go

Write `docs/REAL_ENVIRONMENT_RESULTS.md`: per item (A1 to A8, B1 to B15) what was run, on what, the numbers, what was
changed (file and line), the test that covers it, and the new verdict of each statement it touches (covered, partly,
not covered), with what the verdict now rests on. Keep the list of what is still open at the top. A verdict changes
only when the part was tested as a whole and, where the statement needs it, on real data.
