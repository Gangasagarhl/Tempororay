# Field-to-Test Loop on Windows: install, start, check, and the work list

Written on 2026-11-14 for the engineer or the AI coding agent who continues this project on a Windows laptop and has not
seen it before. Read it from top to bottom once, then work through section 4 in order.

**The one fact to keep in mind: this application has never run on Windows.** It was written and tested on Linux. On
2026-11-12 the code was read line by line for Windows and nine faults were fixed (`docs/CHANGES_2026-11-12.md`,
section 11), and one test imitates Windows on Linux. That is reading and imitation, not a run. Treat every sentence
below that says what happens on Windows as a claim to check, and write down what really happened.

Words used: **the app folder** = `13_production_app` (the folder that holds `run_app.py`). **Git Bash** = the Bash
window that comes with Git for Windows. **The owner** = the person who gave you this task. **Suite** = one group of
tests in `run_tests.sh`. **opencode** = the terminal program the "Terminal agent" button of every page talks to.

---

## 1. What you have

| File from GitHub (`https://github.com/Gangasagarhl/Temporary`) | What it is |
|---|---|
| `field_to_test_loop_<date>_build<n>_<words>.zip` and its `.SHA256.txt` | the application's code; unpacks to `13_production_app\` |
| `field_to_test_loop_sample_recordings.zip` and its `.SHA256.txt` | the small synthetic recordings the tests and a first analysis need; unpacks to `samples\` **inside the app folder** |
| `document.html` | the whole system explained for a reader, with the state of 2026-11-14 |
| `README.md` | the short start page of the repository, with the sentences to give an agent |

Inside the app folder, read in this order: this file, `README_FIRST.md`, section 1 of `deploy/AGENT_INSTRUCTIONS.md`
(seven hard rules), section 11 of `docs/CHANGES_2026-11-12.md` (the Windows faults already fixed),
`docs/CHANGES_2026-11-14.md`, `docs/CHANGES_2026-11-15.md` and `docs/CHANGES_2026-11-15_round2.md` (the newest code:
the second round of 15 November; checks 28 to 31 below are for it).

Every recording in the samples is synthetic: made by the project's own generator, none from a real drive.

---

## 2. Rules for whoever works on it

1. The seven hard rules of `deploy/AGENT_INSTRUCTIONS.md` section 1 hold here too. In short: never train a model;
   never run format, sanitize or firmware commands on a drive; never delete `db\knowledge.sqlite`; one server per `db\`
   folder; keep the server on 127.0.0.1; no API key in any file of the project; never act as the second admin.
2. **Never print, copy or commit an API key or the key file** (`C:\Users\<you>\.config\f2t\env`). When a line shows
   the last characters of a key, do not repeat them.
3. **Nothing goes to GitHub without the owner's word.** The repository is public.
4. **A failing test is information.** Never delete a test, never weaken what it checks to make it pass, never mark it
   "expected to fail" without a written reason. Section 4 step 4 says how to sort a failure.
5. **Fix the cause in one place and keep Linux working.** Every Windows branch in the code is written as
   `if os.name == "nt":` next to the Linux lines; keep that form. A fix must not change what Linux does.
6. **Say what was run and what was not.** "Read, looks right" is not "ran on Windows".
7. The screens speak plain language: no raw identifiers, no abbreviations without their meaning, every number with its
   unit, nothing chosen for the admin in advance. A message you add follows the same rule.
8. Never import `tests/windows_like.py` yourself. It rewires the Python it is loaded into; only
   `tests/test_windows_like.py` may start it, in a process of its own.
9. Before Git touches the folder: `git config core.autocrlf false`. With line ends changed to Windows ones, the `.sh`
   files stop working in Git Bash.

---

## 3. What is known about Windows today

### Fixed by reading on 2026-11-12, never run

| Where | What the code now does on Windows |
|---|---|
| the written test file (`nvme_hier/regress/f2t_nvme.py`) | loads; a real drive is skipped with a plain reason (no Linux NVMe passthrough); the simulated drive works |
| a procedure run (`agentic/procedures.py`) | runs; memory limited through a Windows job object; stopped when its output passes the size limit |
| text files and pipes | UTF-8 everywhere; `run_app.py` starts itself again once in UTF-8 mode |
| a file a page or a virus scanner still reads | a wait of up to 5 seconds, then a plain message (`nvme_hier/osfile.py`) |
| memory readings | read from Windows (`GlobalMemoryStatusEx`) |
| the file picker | shows the drives; Up stops at the top of a drive |
| a second start on the same port | refused with a plain message |
| deleting an upload while a file is open | says a file is still in use |
| file names on the pages | cut at both `/` and `\` |

Written for Windows since then, also never run: finding opencode (`agentic/opencode_cli.py` `find`: the search path,
then `%APPDATA%\npm\opencode.cmd`, `%USERPROFILE%\.opencode\bin\opencode.exe`, scoop, bun); ending a terminal call with
`taskkill /F /T` (`agentic/core.py` `_end_tree`); starting a call in its own process group
(`CREATE_NEW_PROCESS_GROUP`); the worker processes of the five-file load, the tree joins and the column profiles, which
use the "spawn" start on both systems.

### Works on Linux only (by design, or not built yet)

| What | On Windows |
|---|---|
| confinement of code an agent wrote (own folders only, no network) | not there: the checks of the code's text and the admin's verification remain |
| the "how far it has read" figure of a procedure run | not shown |
| the service unit, `deploy/backup.sh`, `deploy/restore.sh`, the nginx file | Linux files. Keep a terminal open or use Task Scheduler; back up by stopping the server and copying `db\`, `knowledge\`, `uploads\` |
| the suites through the running application and the browser | not run on Windows: `tests/test_agentic.py` restarts a Linux service by name; the browser suites look for `google-chrome` |
| a real drive from a written test | needs the Linux NVMe passthrough |
| the Claude Code choice of the earlier `/packets` pages | calls `claude` by its bare name; the Model connection of Settings is not affected |
| chunks kept in memory during a load (`/dev/shm`), the memory-pressure reading | the load uses a folder next to the database instead |

### Windows trace files (`.etl`, Windows Assessment and Deployment Kit)

The application does not read an `.etl` file. It reads CSV files. On the start page "Windows Performance Analyzer" is
listed but cannot be chosen yet: the application holds notes on its export, no column list
(`reference_library/windows_wpa/NOTES.md`; the same for PCMark 10).

- Section 2 of those notes gives the documented ways to get a table out of a trace (`wpaexporter.exe` with a profile;
  the text reports of `xperf`), each with the Microsoft page it comes from.
- Section 7 lists the eight things to collect on the laptop that has the tool (the version, one exported file per
  table as the tool wrote it, the profile, the file names, the regional number format, and so on). With items 1 to 5 a
  column list can be written the way `reference_library/README.md` describes, and the tool becomes choosable.
- Until then a folder of such CSV files is taken as files of an unknown tool: the three data agents still read each
  file and propose meanings from the name and the contents, no tree is built, and rules can be written on a file
  (`docs/CHANGES_2026-11-13.md` section 2). This path has only run on one small non-analyzer CSV file, never on a real
  Windows export.
- **Changed in the second round of 15 November (never run on Windows).** The start page no longer asks which tool
  exported the recording, so nothing is "listed" or "chosen" there any more: the tool is recognised from each CSV
  file's own column names. A folder that holds `.etl` files and no CSV table now says so ("No CSV table in this
  folder: the agent families read tables." with the files grouped by ending, count and size), and "Start the flow" is
  off. A button "Ask the terminal agent about the files of this folder" opens the terminal agent for that folder
  before an analysis exists. The agent is given a copy of the notes above and is told to say which tool must export an
  `.etl` file and with which documented command, and to invent no option (`docs/CHANGES_2026-11-15_round2.md`,
  sections 2 and 3; checks 28 and 29 below).

---

## 4. The work, in order

Use PowerShell for steps 1 to 3 and 5, Git Bash for step 4. Run every command from the app folder. Keep the app
folder's own path short (under about 100 characters) and without a cloud-sync folder such as OneDrive under it.

### Step 1: unpack

```powershell
# in the folder where the downloaded files are
Get-FileHash .\field_to_test_loop_<...>.zip -Algorithm SHA256        # compare with the line in the .SHA256.txt file
Expand-Archive .\field_to_test_loop_<...>.zip -DestinationPath C:\f2t
Expand-Archive .\field_to_test_loop_sample_recordings.zip -DestinationPath C:\f2t\13_production_app
cd C:\f2t\13_production_app
dir samples\clean_five_files        # expect four folders: S08_..., S17_..., S27_..., demo_225_commands
```

### Step 2: install

Python 3.10 or newer from python.org (tick "Add python.exe to PATH"), and Git for Windows.

```powershell
py -3 --version                                   # expect Python 3.10 or newer
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r deploy\requirements.txt
.\.venv\Scripts\Activate.ps1                      # if PowerShell refuses scripts: use the full path of python.exe instead
python -c "import flask, numpy; print('ok')"      # expect: ok
```

### Step 3: the first check

```powershell
python deploy\preflight.py        # PASS / WARN / FAIL per line. On Linux with the shipped settings: 0 FAIL, 2 WARN
```
Write down every FAIL and WARN line as it is printed. Two WARN lines are normal: `server.lock_endpoint` (off) and
`bench synthetic` (lab runs are simulated).

### Step 4: the offline suites, in Git Bash

```bash
cd /c/f2t/13_production_app
source .venv/Scripts/activate
bash run_tests.sh --offline 2>&1 | tee runs/windows_first_run.txt
```
- The first lines must name the Python it found (`Python: python (3.x.y)`). If it says no Python was found, give it:
  `PYTHON=.venv/Scripts/python.exe bash run_tests.sh --offline`.
- It prints one line per suite (`PASS` or `FAIL`), then a table. The log of a suite is `runs/suite_logs/<suite>.log`.
- On Linux on 2026-11-14 every suite passed with the samples in place (the list and the counts are at the end of
  `docs/CHANGES_2026-11-14.md`). On Windows nobody knows yet. Expect failures: the tests were written on Linux too.
  About twenty test files use something Windows lacks (`/tmp`, `/proc`, process groups, `chmod`, `systemctl`); the
  most are in `tests/attack_round6.py`, `tests/attack_round3.py` and `tests/fuzz_app.py`.
- **Sixteen offline suites were added on 14 and 15 November** (`docs/CHANGES_2026-11-15.md`, section 16). Expect them in
  the table: `unit_searchmem`, `unit_cause`, `unit_seqwrap`, `unit_archive`, `unit_search`, `unit_handover`,
  `unit_nearlimit`, `unit_anytool`, `unit_dialect`, `unit_form`, `unit_othererr`, `unit_f4faults`, `unit_f4recheck`,
  `unit_card`, `unit_errpage`, `unit_flowpage`. That makes 60 offline suites. Three of the sixteen run two test files:
  `unit_nearlimit` also runs `tests/test_application_code_items.py`, `unit_errpage` also runs
  `tests/test_chat_command_spellings.py` (both new on 15 November), and `unit_f4recheck` also runs
  `tests/test_recheck_profile.py`. On Linux the whole suite ran once on the joined code (15 November): 58 of the 60
  offline suites passed. The two that failed were `unit_errors` and `unit_agents`; both were repaired afterwards, and
  the second was a real fault (`docs/CHANGES_2026-11-15.md`, section 19). Code changed after that run. The result of
  the run on the final code is the line below: compare a failure on Windows with it before sorting it.

  TESTS ON THE JOINED CODE: on 15 November 2026, from 02:11 to 02:51, the whole suite ran on the joined code in five parts side by side: 60 offline groups and 10 groups through the running application and the browser. All 70 passed. After that run one module was corrected once more (the recheck by the terminal agent, after its trial with the real opencode program), and the eight groups that touch it were run again on the final code at 02:52: all eight passed (unit_f4recheck 60 tests, unit_family4 40, unit_f4faults 42, unit_flowpage 15, unit_form 20, the flow on any CSV 0 checks failed, the agent families through the application 86 checks, a whole flow twice 72 checks). This is synthetic data, a simulated drive, and the stand-in in place of the model in most groups.

- **The second round of 15 November added six offline suites and nine test files**
  (`docs/CHANGES_2026-11-15_round2.md`, section 13). Expect them in the table: `unit_floworder`, `unit_graphlearn`,
  `unit_cmdfamilies`, `unit_cmdflow`, `unit_errjoin` and `unit_header`. That makes 66 offline suites, counted in
  `run_tests.sh` on 15 November. Three older suites run one more test file each: `unit_anytool`
  (`tests/test_start_without_tool_question.py`), `unit_card` (`tests/test_terminal_folder.py`) and `unit_flowpage`
  (`tests/test_rule_hierarchy.py`). Every new test file is in a suite. None of this has run on Windows. Known from
  reading the tests: `tests/test_terminal_folder.py` skips itself whole on Windows (it starts a stand-in for the
  opencode program as a script), so the folder place of the terminal agent has no automatic test there: check 29 is
  the only check. `tests/test_graph_learning.py` compares the search with the code of the released zip and skips that
  one test when the file `field_to_test_loop_code_only.zip` is not in the folder above the app folder. Several of the
  new test files run the page scripts with Node and skip those tests when Node is not installed.
  `tests/test_flow_order.py`, `tests/test_command_rules_flow.py`, `tests/test_join_header.py` and part of
  `tests/test_join_error_page.py` need the sample S17; `tests/test_command_rules_flow.py` skips itself whole without
  it. A shared set-up file, `tests/conftest.py`, puts two values back after each test file (the uploads folder, and
  the switch that says whether a model is connected); it uses nothing that only Linux has.
- Of these six, look first at two on Windows. `unit_header` loads a file in parts on three worker processes and checks
  that the header of each level is written once, by the loading process; Windows starts every worker fresh.
  `unit_cmdflow` runs two whole flows with code runs in processes of their own and a lock on the tree inside the
  application's process. **By reading:** the header is written into the tree's own database by the loading process
  before the workers start, and the lock is made of threads of one process and names a tree by its real path; neither
  uses anything that only Linux has. Neither has run on Windows.
- Of the sixteen, look first at these on Windows: `unit_dialect` and `unit_form` (worker processes that are started
  fresh import the new reader; UTF-16 files); `unit_seqwrap` (the tree's join processes are told the new switch);
  `unit_handover` (it reads a command out of the package's README and runs it; that command is written for a Unix
  shell); `unit_f4recheck` and `unit_card` (they start a stand-in for the opencode program); `unit_archive`,
  `unit_errpage` and `unit_othererr` (they build a tree or read large files in temporary folders). None of them has run
  on Windows.

**Sort every failure into one of three kinds, and write the kind down:**

| Kind | How to tell | What to do |
|---|---|---|
| A. the application is wrong on Windows | the same step fails when done by hand in the running application, or the traceback ends inside `app/`, `agentic/`, `nvme_hier/`, `stage1/`, `stage2/` | fix the application (rule 5), add or extend a test that fails without the fix |
| B. the test uses something only Linux has | the traceback ends inside `tests/`, on a path such as `/tmp` or a call such as `os.killpg` | make the test do the same check the Windows way; the check itself stays |
| C. the thing tested exists on Linux only (the table in section 3) | for example the confinement of agent code | skip it on Windows only, with the reason in the skip text |

`unit_winlike` imitates Windows on Linux. On a real Windows it proves nothing new: if it fails, record it and go on.

### Step 5: start it and check by hand

```powershell
python run_app.py                  # serves http://127.0.0.1:8077 ; --port N for another port ; --standin = no model
```
Then Settings (top bar), "Model connection": address (empty means Anthropic), model name, API key, and "Save and test
the connection". The key goes to `C:\Users\<you>\.config\f2t\env`, never into the project.

For the Terminal agent button: install opencode (`npm install -g opencode-ai`, as opencode's own install page gives
it), then choose its model in Settings.

Check each line and note pass or fail with the exact message. Lines 1 to 13 are the list of 2026-11-12; 14 to 22 are
for code added up to 14 November; 23 to 27 are for the parts of 14 and 15 November that could behave differently on
Windows (`docs/CHANGES_2026-11-15.md`); 28 to 31 are for the second round of 15 November
(`docs/CHANGES_2026-11-15_round2.md`). Those parts had not been seen in a browser on Linux either when this was
written, so for 23 to 31 a fault need not be a Windows fault.

1. `python run_app.py` starts itself again once in UTF-8 mode and serves the start page; a second start on the same
   port is refused in words.
2. The file picker shows the drives, and Up stops at `C:\`.
3. Start a flow on `samples\clean_five_files\S17_io_timeout_abort_reset` and take it through the four pages. Then, when
   one exists, a five-file export of 4 to 6 GB with the virus scanner on and the page open: no "permission" stop; note
   the time.
4. Delete an upload while another tab shows it: it goes, or the message says a file is in use.
5. The load's report shows memory readings; the load holds back when memory is short.
6. A procedure run that takes more memory than its limit is stopped; so is one that writes past the size limit.
7. The written test file: skipped without a drive, passes with `NVME_BACKEND=sim`.
8. Other programs stay usable during a load.
9. Only if the Claude Code choice is used: `claude.cmd` is found, and a question with "µ" in it comes back whole.
10. The app folder's path is under about 100 characters.
11. The key file is only as private as the profile folder (its permission bits do nothing on Windows): say so to the
    owner if other people use the laptop.
12. `pdftotext` (Poppler) is installed if PDF documents are read; without it that step is skipped.
13. `python deploy\preflight.py` once more, with the server running on another port than the one it checks.
14. The five-file load and the tree joins use several processes: Task Manager shows more than one `python.exe` at
    work, the tree is built, and the page shows the progress in per cent.
15. Settings finds opencode and lists its models; nothing is chosen in advance.
16. The Terminal agent button is on every page. From the rules library ask "How many items does the rules library
    hold in each section and level?": the answer matches the files under `knowledge\rules`. On Linux this took 85
    seconds with a free model.
17. While the terminal agent works, press Stop: the answer stops at once and Task Manager shows no opencode process
    left behind.
18. Ask the terminal agent to read `C:\Windows\win.ini`: it must be refused. Its permission list is written with `/`
    in the folder patterns (`agentic/opencode_cli.py`), which has never met a Windows path. **If the agent can read
    outside its own folders, stop using the button and tell the owner: that is the one check here that guards other
    files on the laptop.**
19. Stop the server and start it again: the terminal agent's conversation and the agents' kept conversations are
    still there (Settings, "Sessions held").
20. A folder path with a space and one with a letter such as "é" in it: the picker opens it and a flow starts.
21. The REA agent of the start page, when a folder of decompiled findings exists: give its Windows path, read it once,
    ask a question; the answer names its file and lines.
22. Close the terminal window that runs the server while a load is going, start again: the interrupted load says
    "load again" and nothing else is damaged.
23. **A CSV file as a Windows tool writes it, of a tool the application has no column list for.** Take a table that a
    Windows tool saved in UTF-16 (a two-byte text encoding many Windows tools write), if possible with semicolons
    between the cells and decimal commas, as the laptop's number format gives them. Put it in a folder under a name
    ending in `.csv`. (Until the second round of 15 November the start page asked "Which tool exported the
    recording?" and the answer here was "Another tool, or I do not know". That question is gone: give the folder,
    press "Check", and expect the line "Recognised from the files: no tool the application has a column list for
    ...".) Start the flow.
    Expect: Family 1 reads it as a table with its real columns (not as one column); the Manager of the file, asked
    "which separator does this file use, and on which line is the header?", answers with the encoding, the separator
    and the header line; a column with decimal commas says so. A UTF-16 file is read on one core, by design. A file
    that is no table is refused in one sentence and the other files go on. No real UTF-16 export had been read on
    Linux either: only files written by the tests.
24. **The recheck of Family 4's code by the terminal agent, and its data folder.** Needs opencode installed and its
    model chosen (check 15). **The shipped setting is "only when the admin asks"** (`agentic.f4_recheck` is `"ask"` in
    `config\app_config.json`; it is not "always"). So take a rule on a CSV file through Family 4 until the code card,
    and press "Recheck this code with the terminal agent" on the card. Before you press, the card says in one sentence
    that the code was not rechecked. Expect afterwards the part "The recheck by the terminal agent" with one sentence:
    agrees, differs (with rows), could not be used (with the reason), or not rechecked (with the reason). Write the
    sentence down. **What the data watch does:** before the terminal agent starts, the application records every data
    file of the rule and every other file under the folders the agent may read (size, change time, a fingerprint of the content: the
    whole content up to 256 megabytes, above that the first and the last 16 megabytes). After the agent has ended it
    compares. When a file changed, the card says "The data changed while the terminal agent was rechecking: ..." with
    what changed, the recheck's answer is not used, and the card reads "It is not clean". The record before and after
    is the file `recheck<number>.data_watch.json` in the run's folder (`runs\run_<n>\family4_recheck_<item>\`). **The
    watch detects a change; it prevents nothing,** and it makes no copy of a file. Check the data yourself too: note
    the size and the change time of every file in the analysis's data folder before the recheck, and compare after it.
    **They must be unchanged,** and the watch's record must say the same. The watch has never run on Windows: write
    down whether it reports a change when you changed nothing (it reads size, change time and file identity; none of
    that was tried on Windows). The recheck uses the investigation agent's permission profile. A profile of its own exists
    (`f2t-recheck` in `agentic/opencode_cli.py`: reading, no edit tool, Python and listing commands, no folder outside
    its own but the data folder); it is not used, has never run with the real opencode on any system, and its folder
    patterns have never met a Windows path. On every system, the Python that the agent starts is not confined. If a
    data file changed, set `agentic.f4_recheck` to `"never"` in `config\app_config.json` and tell the owner. Also press
    Stop during a recheck: Task Manager must show no opencode process and no `python.exe` of the agent left behind.
25. **A family's review card handed to the terminal agent.** On a flow page with a card waiting, press "Ask the
    terminal agent about this card". Expect: the panel opens for that analysis, shows "This question is about the
    card: ...", the question box is empty and nothing was asked. Ask "What does this card claim, and is it right?".
    Expect a file `CARD_<number>.md` in the agent's own folder (`runs\agentic\investigation_p<number>\`), and an
    answer about that card. "Put this answer into my comment on the card" writes into the card's comment box and sends
    nothing. This has not been tried with the real opencode on Linux either.
26. **The hand-over package.** On the page of one error with an approved test, part 7: tick the test, type a name,
    build the package, download it and unpack it. **The commands in its `README.txt` are written for a Unix shell**
    (a variable set in front of the command, and `python3`): in PowerShell and in the Windows command prompt they do
    not work as written. Run the simulated-drive line in Git Bash, with `python` in place of `python3` if Git Bash
    does not know `python3`. Or, in PowerShell, set the variable first: `$env:NVME_BACKEND = "sim"`, then
    `python -m pytest -q --junit-xml=result.xml tests`. Bring `result.xml` in on the same page and read the table
    "What came back". The README's real-drive line names a Linux device and uses the Linux way to send NVMe commands:
    it is not for Windows (section 3, "Works on Linux only").
27. **The tree's join processes with the new switch.** In `config\app_config.json`, section `tree`, set `round_rule`
    to `false`. Build the tree of a sample again (no restart is needed: the setting is read at every build). Expect:
    Task Manager shows more than one `python.exe` at work as in check 14, the tree is built, and the build's report
    says for the step "packets into link transactions": "off: the join as it was before 2026-11-14". Set it back to
    `true`, build again: the report says the rule is on. On Windows every join process is started fresh, so the build
    hands the answer to each process; on Linux this was tested with two real join processes.

28. **The start page without the tool question, with Windows paths.** Never run on Windows. Type a folder path with
    backslashes (for example `C:\captures\run 7`) and press "Check". Expect: one line per CSV file that says which
    tool it was recognised as; the line "Recognised from the files: ..."; the other files of the folder grouped by
    their ending with count and size (for example "3 files ending .etl, 250.0 MB"); subfolders named as not read.
    Then a folder with `.etl` files and no CSV file: expect "No CSV table in this folder: the agent families read
    tables." and "Start the flow" off, also when "Start the flow" is pressed without "Check" (the server refuses with
    the same sentence). The card "New analysis" has three fields and no field for the REA folder: one line says
    whether the analysis keeps REA findings. The folder field's grey example text shows a Unix path; that is only an
    example.
29. **The terminal agent for a folder, before an analysis exists.** Needs opencode installed and its model chosen
    (check 15). Never run on Windows, and its automatic test file skips itself there. **Do check 18 first.** Use a
    throw-away folder with one `.xml` file, one small `.etl` file and one CSV file, never the only copy of a
    recording. On the start page press "Check", then "Ask the terminal agent about the files of this folder".
    - Expect the panel to say "This page asks about the folder ..., before an analysis exists."
    - **Folders that must be refused, each with one sentence** (type each on the start page and press the button):
      `C:\`, `C:\Windows`, `C:\Program Files`, your profile folder itself (`C:\Users\<you>`),
      `C:\Users\<you>\AppData`, `C:\Users\<you>\.config`, the app folder, its `db` folder, and the folder that
      holds the app folder. The list of system folders is read from Windows' own settings (`SystemRoot`, `ProgramFiles`,
      `ProgramData`) in `agentic/investigate.py` (`_system_folders`); none of it has met a real Windows. A folder on
      another drive letter and a folder on a network share were not thought through: write down what happens.
    - **The same folder written in other letters** (`C:\Captures\Run7` and `c:\captures\run7`, or with a
      backslash at the end) must reach the same conversation: ask a question, give the folder the other way, and
      expect the first question still listed. By reading, the folder's identity is made from the path in lower case
      with backslashes; this was tested on Linux only with a trailing slash, two slashes and a symbolic link.
    - **The guard on other files:** ask the agent to read `C:\Windows\win.ini`. It must be refused. The permission
      handed to opencode is written as the folder and the folder followed by `/*`; with a Windows path that pattern
      has never been tried. **If the agent can read outside the folder, stop using the button and tell the owner.**
    - Ask "what is each file, and what do I need to bring?". Expect it to say what it saw in each file, and for the
      `.etl` file to name the exporting tool and quote `WINDOWS_WPA_NOTES.md` without inventing an option.
    - Ask it to write the XML file as a table. Press "Put this CSV file into the folder". Expect "Copied to ...";
      press "Check" on the start page: the file is listed. Press the button again for the same file: it must be
      refused with "the folder already has a file named ...". Compare the size and the change time of every other
      file of the folder before and after: unchanged. **On every system the Python that the agent starts is not
      confined**; only its instruction keeps it from changing files.
    - Press Stop while it works: Task Manager must show no opencode process and no `python.exe` of the agent left.
30. **The page of one error after the second round.** On the sample S17, with the stand-in: before a pattern's result
    is approved on page 3, open the address of one of its errors (`/isolate?upload=<id>&finding=<number>`). Expect
    only "This error cannot be opened yet" with the reason. Approve the result, open it again: the page works. In part
    5 each stored solution shows two lines, "judged by admins" and "lab runs". Run the search of the page on the
    simulated drive, then press "Store this sequence as a solution of the cause"; run the search of the same kind of
    error again: expect the line "What the search started from: Started from what the graph holds ...". The three new
    tables are added to the graph's database when it is opened; opening a `db\` folder made by an older build on
    Windows has not been tried.
    - **A rule of the application's rule set.** In a new analysis on S17, tick on the plan card of page 3, under
      Errors, NVMe errors, NVMe command level errors, the built-in rule "NVMe command timeout" and the rule "A command
      never completed". None of the 38 rules may arrive ticked. The 38 rules are there only when the application was
      started with this round's code. Expect: nothing on the errors page before each result is approved; the result
      card of the second rule says "The same command, found twice" with the rows; after the approval, both errors of
      one command say "The same command is also listed under ..." on the errors page, with a link to the other.
    - **If an analysis stands still after Approve** (its state "running", its next step "waiting", nothing working in
      Task Manager), write down which card it was. A fault of that kind was found on Linux in this round and fixed
      (`docs/CHANGES_2026-11-15_round2.md`, section 0a); the fix was tested on Linux only, by one unit test and one
      clean run. Starting the application again continues such an analysis.
    - **By reading, never run on Windows:** the errors step waits until no code run reads the tree (a lock inside the
      application's one process), and the loader keeps the header of each level's file in the tree's database at the
      load. Neither uses anything that only Linux has. If the errors step shows "waiting until the code runs that read
      this recording's tree have finished" and never goes on while no `python.exe` of a code run is left in Task
      Manager, record it as kind A.
31. **A result file counted on the procedural graph, built on Windows.** Continue check 26 with a test that was
    approved for a version of a stored solution. Read `manifest.txt` in the package: expect the line "Stored solution
    it was written from:" with the solution's number. Run the simulated-drive line as in check 26 and bring
    `result.xml` in. Expect beside "Bring in" either "The result of the test ... was counted on the procedural graph
    as lab runs of stored solution number ...: ... on the simulated drive. No judgement and no order changed." or
    "... was kept, but it was not counted on the procedural graph, because ..." with the reason. Write the sentence
    down. **By reading:** the tie between a test and its solution is the test file's path kept on the graph. The code
    accepts the same real path, or a path that ends in `suite/hier/<test name>`; a path written with backslashes was
    matched in one test as text only, on Linux. If the sentence says the test is not tied to a stored solution
    although it was approved for one, that is a Windows fault of `nvme_hier/handover.py` (`solution_of_test`): record
    it as kind A.

### Step 6: write it down

Put the result in `docs/WINDOWS_RESULTS.md`:

- the Windows version, the Python version, the processor cores and memory, whether a virus scanner was on;
- the table of suites as `run_tests.sh` printed it;
- per failing test: the kind (A, B or C), the exact message, the file and line changed, the test that now covers it;
- the 31 checks with pass, fail or "not done" and why;
- what stays open.

Then run `bash run_tests.sh --offline` once more on the final code and paste that table too. If a Linux machine is at
hand, the same code must still pass `bash run_tests.sh` there; if none is, say so in the results.

---

## 5. If you carry your own work over from the Linux machine

- `knowledge\` (the admin's rules, dictionaries and joining strategies, about 1.5 MB) can be copied into the app
  folder with the server stopped.
- An analysis made on Linux keeps the Linux paths of its files in `db\` and `uploads\`. Opening one on Windows has not
  been tried. Start new analyses on Windows from the CSV files.
- Do not copy `db\knowledge.sqlite` alone: it has two side files (`-wal`, `-shm`); copy the whole `db\` folder with
  the server stopped, or leave it.

---

## 6. What was not tested anywhere

A real Windows machine; a real analyzer export of 4 to 6 GB; a real drive; a real Windows trace export; the REA agent
on a real folder of decompiled findings. Every recording used so far is synthetic.
