"""The joins of 2026-11-15 between "the order of the flow", "rows of an admin's rule become errors" and "the graph learns from lab runs":

  1. nvme_hier/isolate.rule_in_words   a finding filed by an admin's rule shows detail.admin_rule.words, never the rule key
  2. nvme_hier/rules.basis             a key that starts with "admin." -> the admin's rule, the item's meaning, the stated source sentence
  3. the page of one error             (app/static/js/isolate.js, isolate.html) the 409 of the first request is the page's message; the admin's
                                       rule in words; where the defect's name comes from (the page's own functions, run by node)
  4. app/api/isolate_api.py            the three search routes refuse (HTTP 409, one sentence) while the pattern's result waits
  5. app/api/dg_api.py                 occurrences, causes, solutions, optimized refuse likewise when the request names the error
  6. nvme_hier/handover.py             a validation suite's result becomes lab runs of the stored solution its test was written from:
                                       once, never twice, never without a stated bench
  7. the tester's points of 2026-11-15 no rule key, cause keyword or test file name on the page of one error (the detector's errors, an
                                       admin's rule, a rule of the application's rule set); the solution form says who proposed; the
                                       refusal names the analysis that waits; a refused page's header; every table in a scroll box

Everything is written under temporary folders; no server is used; the tree is built on one core from the sample S17.
ERROR_PAGE_TREE=<a hier.sqlite built from that sample> skips the loading (a developer's shortcut, nothing else).

    F2T_WORKERS=1 python3 -m pytest -q -p no:cacheprovider tests/test_join_error_page.py
"""
import copy
import csv
import hashlib
import io
import json
import os
import re
import shlex
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import types
import zipfile
from xml.sax.saxutils import quoteattr

import pytest

os.environ.setdefault("F2T_WORKERS", "1")
HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for _p in (APP, os.path.join(APP, "app"), HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from nvme_hier import coded_findings as CF      # noqa: E402
from nvme_hier import defect_graph as DG        # noqa: E402
from nvme_hier import handover as HO            # noqa: E402
from nvme_hier import isolate as ISO            # noqa: E402
from nvme_hier import rules as RL               # noqa: E402
from nvme_hier import terms as TM               # noqa: E402
from nvme_hier import testplan as TP            # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
NODE = "/home/raghavendra/.nvm/versions/node/v22.23.2/bin/node"
PAGE = os.path.join(APP, "app", "static", "isolate.html")
SCRIPT = os.path.join(APP, "app", "static", "js", "isolate.js")
UID = "up-join"
ANALYSIS = "join analysis"
TIMEOUT = "errors/nvme_command/cmd_timeout"
OWN = "errors/nvme_command/aborted_commands"
OWN_KEY = "admin.errors.nvme_command.aborted_commands.v1"
OWN_WORDS = "Found by the admin's own rule 'aborted commands' (version 1 of its procedure, coded by Family 4)."
OWN_MEANING = "commands where ST.SCT is 0 and ST.SC is 7"
SOURCE = "Source: the admin's own rule in the rules library, coded by Family 4 and approved on page 3."
KIND_FROM = ("In the name the fixed dictionary gives such a defect, the part \"matched the admin's rule 'aborted commands'\" comes from your own rule "
             "\u201caborted commands\u201d; the command, its status and the rest of the name come from the recording, as for the detector's errors. No model names it.")
WAITS = ("The result of '%s' waits for your decision on page 3 of the analysis \u201c" + ANALYSIS + "\u201d: this error can be opened and worked on "
         "(stage 1, stage 2 and its test) after you approve that result.")
NOT_YET = ("The rule '%s' has not reached its result yet in the analysis \u201c" + ANALYSIS + "\u201d (page 3 shows where it stands): this error can be "
           "opened and worked on after you approve that result.")
WAITS_FOR = "the approval of the pattern's result on page 3"
STEPS = [{"command": "Write", "position": "above", "gap_us": 10, "source_row": 5, "opc": 1}, {"command": "Read", "position": "fault", "gap_us": 10, "source_row": 9, "opc": 2}]


def _read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


# ============================================================================================== 1. rule_in_words
def test_a_finding_of_an_admins_rule_shows_its_words_never_the_key():
    detail = {"kind": "matched the admin's rule 'aborted commands'", "admin_rule": {"item": "errors/nvme_command/aborted_commands", "procedure_version": 1,
                                                                                   "name": "aborted commands", "words": OWN_WORDS}}
    f = {"rule": OWN_KEY, "level": "nvme_command", "name": "aborted commands (found by the admin's own rule)", "detail": detail}
    assert ISO.rule_in_words(f) == OWN_WORDS                                         # the detail as the API hands it over (a dict)
    assert ISO.rule_in_words(dict(f, detail=json.dumps(detail))) == OWN_WORDS        # as a row of the tree keeps it (JSON text)
    assert ISO.rule_in_words(dict(f, detail=json.dumps(detail).encode("utf-8"))) == OWN_WORDS
    # every sentence the stand-in builds from it carries the words and never the key
    for text in (ISO.reason_text(f, "Drive A"), "\n".join(ISO.defect_lines(f, "Drive A")[:2]), ISO.standin_isolation(dict(f, name=None), "Drive A", None, 144)["why"]):
        assert "Found by the admin's own rule 'aborted commands'" in text, text
    assert "admin.errors" not in ISO.reason_text(f, "Drive A") and "errors.nvme command" not in ISO.reason_text(f, "Drive A")


@pytest.mark.parametrize("detail", [None, {}, "", "not json", "[1, 2]", [], 7, {"admin_rule": None}, {"admin_rule": "words"}, {"admin_rule": {"words": None}},
                                    {"admin_rule": {"words": ["a"]}}, {"admin_rule": {"words": "   "}}, json.dumps({"admin_rule": {"words": 5}}), b"\xff\xfe"])
def test_without_readable_words_the_sentence_comes_from_the_keys_parts_and_is_still_never_the_key(detail):
    got = ISO.rule_in_words({"rule": OWN_KEY, "level": "nvme_command", "detail": detail})
    assert got == OWN_WORDS, got                                 # made from the item's id and the version in the key
    for key in ("admin.", "admin.x", "admin.errors.nvme_command.v1", "admin.{limit}.{name}.x.v1x", "admin." + "a" * 5000):
        got = ISO.rule_in_words({"rule": key, "level": "nvme_command", "detail": detail})
        assert "admin." not in got and got.startswith("Found by "), (key[:40], got)


def test_the_built_in_rules_read_as_before():
    f = {"rule": "spl.latency_over_limit", "level": "split", "limit_ps_text": "50 ms", "name": "x", "detail": {"kind": "late"}}
    assert ISO.rule_in_words(f) == "timing error at the split level: the answer to the memory request came later than 50 ms"
    assert ISO.rule_in_words(dict(f, detail=json.dumps({"kind": "late"}))) == ISO.rule_in_words(f)
    assert ISO.rule_in_words({"rule": "cmd.timeout", "level": "nvme_command", "detail": {"kind": "never completed"}}) == "NVMe command level: timeout"
    assert ISO.rule_in_words({"rule": "pkt.some_new_rule", "level": "packets"}) == "packet level: some new rule"
    assert ISO.rule_in_words({"level": "packets"}) == "packet level: "                # no rule at all: as before, no failure


# ============================================================================================== 2. basis
@pytest.fixture()
def library(tmp_path, monkeypatch):
    """A rules library in a temporary knowledge folder, with the admin's item 'aborted commands' in Error roots, NVMe commands."""
    from agentic import family1, family3
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path / "knowledge"))
    family3._SECTIONS_SEEN[0] = None
    item = family3.add_item("errors", "nvme_command", "aborted commands", OWN_MEANING, "t")
    assert item["id"] == "aborted_commands"
    yield types.SimpleNamespace(family3=family3, root=str(tmp_path / "knowledge"), item=item)
    family3._SECTIONS_SEEN[0] = None


def test_the_basis_of_an_admins_rule_is_the_items_own_meaning(library):
    b = RL.basis(OWN_KEY)
    assert b["kind"] == "the admin's rule" and b["words"] == SOURCE and b["firm"] is True
    assert b["text"] == "aborted commands: " + OWN_MEANING
    assert b["ref"] == "the rules library, the item 'aborted commands', version 1 of its procedure"
    assert set(b) == set(RL.basis("cmd.timeout"))                                     # the same fields as every other basis
    assert RL.basis("admin.errors.nvme_command.aborted_commands.v7")["ref"].endswith("version 7 of its procedure")
    # the item's words are read when asked: an edit of the item shows at once; an item without words says so
    r = library.family3.load_rule("errors", "nvme_command", "aborted_commands")
    library.family3.save_rule(dict(r, description="", definition="1. Take the commands. 2. Keep those the host aborted."))
    assert RL.basis(OWN_KEY)["text"] == "aborted commands: 1. Take the commands. 2. Keep those the host aborted."
    library.family3.save_rule(dict(r, description="", definition=""))
    assert RL.basis(OWN_KEY)["text"] == "The rules library holds the item 'aborted commands', but no words that say what it means."


def test_an_item_that_cannot_be_read_is_said_in_words(library):
    library.family3.delete_item("errors", "nvme_command", "aborted_commands", "t", "the test deletes it")
    b = RL.basis(OWN_KEY)
    assert b["kind"] == "the admin's rule" and b["words"] == SOURCE
    assert b["text"] == "The item 'aborted commands' cannot be read from the rules library any more (it may have been deleted or moved), so its meaning cannot be shown here."
    with open(os.path.join(library.root, "rules", "errors", "nvme_command", "broken.json"), "w", encoding="utf-8") as fh:
        fh.write("{ this is not JSON")
    assert "cannot be read from the rules library" in RL.basis("admin.errors.nvme_command.broken.v1")["text"]


@pytest.mark.parametrize("key", ["admin.", "admin.x", "admin.errors.nvme_command.v1", "admin.errors.nvme_command.aborted_commands", "admin.errors.nvme_command.aborted_commands.v",
                                 "admin.errors.nvme_command.../../../etc/passwd.v1", "admin.errors.nvme_command.a\x00b.v1", "admin.no_such_section.nvme_command.x.v1",
                                 "admin.errors.no_such_level.x.v1", "admin.errors.nvme_command." + "a" * 100000 + ".v1", "admin.errors.nvme_command.x.v" + "9" * 400,
                                 "admin.errors.nvme_command.<script>alert(1)</script>.v1", "admin.errors.nvme_command.x y.v1", "admin.%s.%d.{0}.v1"])
def test_a_hostile_key_gets_words_and_touches_nothing(library, key):
    before = sorted(os.path.join(d, f) for d, _x, fs in os.walk(library.root) for f in fs)
    b = RL.basis(key)
    assert b["kind"] == "the admin's rule" and b["words"] == SOURCE and isinstance(b["text"], str) and b["text"] and isinstance(b["ref"], str)
    assert "cannot be" in b["text"], b["text"][:200]                                 # said in words: no meaning is invented
    assert sorted(os.path.join(d, f) for d, _x, fs in os.walk(library.root) for f in fs) == before


def test_every_other_key_has_the_basis_it_had():
    assert RL.basis("cmd.timeout") == {"kind": RL.BASIS["cmd.timeout"][0], "text": RL.BASIS["cmd.timeout"][1], "ref": RL.BASIS["cmd.timeout"][2],
                                       "firm": RL.BASIS["cmd.timeout"][0] in ("specification", "analyzer", "owner's rule"),
                                       "words": RL.source_words(RL.BASIS["cmd.timeout"][0], RL.BASIS["cmd.timeout"][2])}
    unknown = {"kind": "unknown", "text": "no basis recorded for this rule", "ref": "", "firm": False, "words": "Source: none recorded for this rule."}
    for key in ("no.such.rule", "", None, "administrator.rule", "Admin.errors.nvme_command.x.v1", "xadmin.errors"):
        assert RL.basis(key) == unknown, key


# ============================================================================================== the throw-away application
def _copy_db(src, dst):
    a = sqlite3.connect("file:%s?mode=ro" % src, uri=True)
    b = sqlite3.connect(dst)
    a.backup(b)
    a.close()
    b.close()


@pytest.fixture(scope="module")
def tree(tmp_path_factory):
    """The tree of the sample S17, built once on one core."""
    cache = os.environ.get("ERROR_PAGE_TREE")
    if cache and os.path.isfile(cache):
        return cache
    if not os.path.isdir(S17) or not all(os.path.exists(os.path.join(S17, n)) for n in NAMES.values()):
        pytest.skip("the S17 sample recording is not on this machine (the code-only zip carries no samples)")
    from nvme_hier import builder as B, loader as L
    db = str(tmp_path_factory.mktemp("join_tree") / "hier.sqlite")
    was = os.environ.get("F2T_WORKERS")
    os.environ["F2T_WORKERS"] = "1"          # a test must not compete with the owner's running work
    try:
        L.load_upload(db, {k: os.path.join(S17, n) for k, n in NAMES.items()})
        B.build(db)
        RL.apply(db)
    finally:
        if was is None:
            os.environ.pop("F2T_WORKERS", None)
        else:
            os.environ["F2T_WORKERS"] = was
    return db


class Flow:
    """The records of the analyses (db/agentic.sqlite of the throw-away application), written by hand: which pattern's result stands where."""

    def __init__(self, root):
        from agentic import core
        self.store = core.Store(os.path.join(root, "db", "agentic.sqlite"))

    def none(self):
        for t in ("step", "run", "project"):
            self.store.exec("DELETE FROM %s" % t)

    def set(self, states, upload=UID):
        """{item: state of its result step} for one analysis on the recording; everything before is removed."""
        self.none()
        pid = self.store.exec("INSERT INTO project (admin, name, folder, refs, upload_id, created, updated) VALUES ('t', ?, '/x', '[]', ?, 0, 0)", (ANALYSIS, upload))
        rid = self.store.exec("INSERT INTO run (project, kind, target, params, state, created, updated) VALUES (?, 'flow', '', '{}', 'running', 0, 0)", (pid,))
        titles = {TIMEOUT: "NVMe command timed out", OWN: "aborted commands"}
        for n, (item, state) in enumerate(states.items()):
            self.store.exec("INSERT INTO step (run, idx, key, title, family, agent, state, needs_review) VALUES (?, ?, ?, ?, '3', 'Manager', ?, 1)",
                            (rid, 5 + n, "f3:%s:result" % item, "%s \u00b7 the result, for your review" % titles[item], state))
        return pid

    def also(self, states, name, upload=UID):
        """One more analysis on the recording, beside the ones that are there."""
        pid = self.store.exec("INSERT INTO project (admin, name, folder, refs, upload_id, created, updated) VALUES ('t', ?, '/x', '[]', ?, 0, 0)", (name, upload))
        rid = self.store.exec("INSERT INTO run (project, kind, target, params, state, created, updated) VALUES (?, 'flow', '', '{}', 'running', 0, 0)", (pid,))
        titles = {TIMEOUT: "NVMe command timed out", OWN: "aborted commands"}
        for n, (item, state) in enumerate(states.items()):
            self.store.exec("INSERT INTO step (run, idx, key, title, family, agent, state, needs_review) VALUES (?, ?, ?, ?, '3', 'Manager', ?, 1)",
                            (rid, 5 + n, "f3:%s:result" % item, "%s \u00b7 the result, for your review" % titles[item], state))
        return pid


@pytest.fixture(scope="module")
def world(tree):
    """A throw-away application with the S17 tree as the recording up-join; one error of the built-in pattern cmd.timeout and one error
    filed by the admin's own rule 'aborted commands' (row 144). What it replaces in the application's modules is put back afterwards."""
    from agentic import core, family1, family3, procedures as PR
    from api import config_api, hier_api
    root = tempfile.mkdtemp(prefix="join_error_page_%d_" % os.getpid())
    was = (config_api.save_config, hier_api.ENV_FILE, family1.knowledge_dir, core.Engine.kick)
    uploads = PR._UPLOADS[0]                 # create_app points the uploads folder at the throw-away application: put back afterwards
    try:
        with open(os.path.join(APP, "config", "app_config.json"), encoding="utf-8") as fh:
            cfg = copy.deepcopy(json.load(fh))
        cfg["_path"] = os.path.join(root, "app_config.json")
        cfg["llm"].update(base_url="http://127.0.0.1:9", api_key_env="FUZZ_NO_SUCH_KEY", backend="http")
        cfg["agentic"].update(runtime="standin", web=False)
        cfg.setdefault("server", {})["api_calls"] = True
        config_api.save_config = lambda c: None
        hier_api.ENV_FILE = os.path.join(root, "env")            # a test must never reach the real key file
        family1.knowledge_dir = lambda: os.path.join(root, "knowledge")
        core.Engine.kick = lambda self, rid: None
        family3._SECTIONS_SEEN[0] = None
        for d in ("knowledge", "config", "uploads", "db"):
            os.makedirs(os.path.join(root, d), exist_ok=True)
        shutil.copy(os.path.join(APP, "config", "app_config.json"), os.path.join(root, "config", "app_config.json"))
        from server import create_app
        app = create_app(cfg, root)
        app.config["PROPAGATE_EXCEPTIONS"] = False
        app.logger.disabled = True
        d = os.path.join(root, "uploads", UID)
        os.makedirs(d)
        db = os.path.join(d, "hier.sqlite")
        _copy_db(tree, db)
        with open(os.path.join(d, "meta.json"), "w", encoding="utf-8") as fh:
            json.dump({"upload_id": UID, "created": 1, "operator": "t", "device": "D", "trace_name": "S17 sample", "recording_date": "", "notes": "",
                       "files": {k: os.path.join(S17, n) for k, n in NAMES.items()}, "status": "loaded", "thresholds": {}, "file_stats": {}}, fh)
        family3.tree()                                           # the seeds of the rules library (the built-in pattern cmd_timeout among them)
        family3.add_item("errors", "nvme_command", "aborted commands", OWN_MEANING, "t")
        res = os.path.join(root, "own_result.csv")
        with open(res, "w", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerows([[CF.ROW_COLUMN, "ST.SCT", "ST.SC"], ["144", "0", "7"]])
        filed = CF.file_findings(db, "errors", "nvme_command", "aborted_commands", 1, "aborted commands", res, "t")
        assert filed["rule"] == OWN_KEY and filed["added"] == 1
        con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
        t_fid = con.execute("SELECT id FROM finding WHERE level='nvme_command' AND rule='cmd.timeout' ORDER BY id LIMIT 1").fetchone()[0]
        o_fid = con.execute("SELECT id FROM finding WHERE rule=?", (OWN_KEY,)).fetchone()[0]
        con.close()
        yield types.SimpleNamespace(app=app, c=app.test_client(), root=root, db=db, t_fid=t_fid, o_fid=o_fid, flow=Flow(root),
                                    kb=os.path.join(root, "db", "hier_knowledge.sqlite"))
    finally:
        config_api.save_config, hier_api.ENV_FILE, family1.knowledge_dir, core.Engine.kick = was
        PR.use_uploads_folder(uploads)
        family3._SECTIONS_SEEN[0] = None
        shutil.rmtree(root, ignore_errors=True)


def _count(kb, table):
    if not os.path.exists(kb):
        return 0
    con = sqlite3.connect("file:%s?mode=ro" % kb, uri=True)
    try:
        return con.execute("SELECT COUNT(*) FROM %s" % table).fetchone()[0]
    except sqlite3.OperationalError:
        return 0
    finally:
        con.close()


def _graph_counts(kb):
    return {t: _count(kb, t) for t in ("dg_defect", "dg_cause", "dg_occurrence", "dg_solution", "dg_revision", "dg_verdict", "dg_lab", "kb_trace")}


def _defect(w, name="Read never completed (join test)"):
    r = w.c.post("/api/dg/defects", json={"name": name, "term_key": "join|" + name, "rule": "cmd.timeout", "level": "nvme_command", "what": "what", "admin": "t"})
    assert r.status_code == 200, r.get_json()
    return r.get_json()["id"]


def _refused(r, sentence):
    j = r.get_json(silent=True) or {}
    number = j.pop("project", None)             # the routes of the page of one error also say which analysis waits (its number), when it is one
    assert r.status_code == 409 and j == {"error": sentence, "waits_for": WAITS_FOR}, (r.status_code, j)
    assert number is None or (isinstance(number, int) and not isinstance(number, bool) and number > 0), number


# ============================================================================================== 1 + 2 + 3a, through the header route
def test_the_header_of_an_error_of_the_admins_rule_carries_the_words_the_basis_and_the_name_sentence(world):
    world.flow.none()
    r = world.c.get("/api/isolate/%s/%d" % (UID, world.o_fid))
    assert r.status_code == 200, r.get_json()
    f = r.get_json()["finding"]
    assert f["rule"] == OWN_KEY and f["rule_words"] == OWN_WORDS and f["detail"]["admin_rule"]["words"] == OWN_WORDS
    assert f["admin_rule"] == {"words": OWN_WORDS, "name": "aborted commands", "kind_words": "matched the admin's rule 'aborted commands'", "kind_from": KIND_FROM}
    assert f["basis"] == {"kind": "the admin's rule", "text": "aborted commands: " + OWN_MEANING, "firm": True, "words": SOURCE,
                          "ref": "the rules library, the item 'aborted commands', version 1 of its procedure"}
    # an error of a built-in pattern has no such part and reads as before
    g = world.c.get("/api/isolate/%s/%d" % (UID, world.t_fid)).get_json()["finding"]
    assert "admin_rule" not in g and g["rule_words"] == ISO.rule_in_words(g) and g["basis"]["kind"] != "the admin's rule"


# ============================================================================================== 4. the search routes
SEARCH_ROUTES = ["/search", "/search/stop", "/search/store"]


def _search_answers(w, fid, body=None, query=""):
    return {tail: w.c.post("/api/isolate/%s/%d%s%s" % (UID, fid, tail, query), json=body if body is not None else {}) for tail in SEARCH_ROUTES}


def test_the_three_search_routes_refuse_while_the_patterns_result_waits(world):
    from api import isolate_api as IA
    kept = os.path.join(world.root, "uploads", UID, "replay_search")
    stored = lambda: {f: os.path.getmtime(os.path.join(kept, f)) for f in os.listdir(kept)} if os.path.isdir(kept) else None      # noqa: E731
    files = stored()
    for item, fid, name in ((TIMEOUT, world.t_fid, "NVMe command timed out"), (OWN, world.o_fid, "aborted commands")):
        world.flow.set({item: "needs_review"})
        before = dict(IA._JOBS), dict(IA._SEARCHES)
        for tail, r in _search_answers(world, fid).items():
            _refused(r, WAITS % name)
        for tail, r in _search_answers(world, fid, {"sequence": [{"position": "fault"}], "bench": "simulated", "name": "t", "which": "best"}, "?job=1").items():
            _refused(r, WAITS % name)                             # refused before a background job is started
        assert (dict(IA._JOBS), dict(IA._SEARCHES)) == before and stored() == files      # no job, no search, no stored result was made or changed
        world.flow.set({item: "waiting"})                         # the run has not reached its result yet
        for tail, r in _search_answers(world, fid).items():
            _refused(r, NOT_YET % name)
        world.flow.set({item: "rejected"})
        for tail, r in _search_answers(world, fid).items():
            _refused(r, WAITS % name)
    # the other pattern's result waiting says nothing about this error
    world.flow.set({OWN: "needs_review"})
    assert all(r.status_code != 409 for r in _search_answers(world, world.t_fid).values())
    world.flow.none()


def _own_answers(w, fid):
    """What the three routes answer when the guard lets them through, with an empty request: each in its own way, never 409."""
    got = _search_answers(w, fid)
    assert got["/search"].status_code == 400 and "choose the bench" in got["/search"].get_json()["error"]
    assert got["/search/stop"].status_code == 200 and got["/search/stop"].get_json() == {"stopping": False, "note": "no search is running for this error"}
    assert got["/search/store"].status_code == 400 and "write your name first" in got["/search/store"].get_json()["error"]


def test_the_search_routes_work_without_a_flow_and_after_the_approval(world):
    from nvme_hier import replay_search as RS
    world.flow.none()                                             # no analysis uses the recording
    _own_answers(world, world.t_fid)
    _own_answers(world, world.o_fid)
    world.flow.set({TIMEOUT: "approved", OWN: "approved"})        # the admin approved the results
    _own_answers(world, world.t_fid)
    _own_answers(world, world.o_fid)
    world.flow.set({TIMEOUT: "needs_review"}, upload="another-recording")     # another recording's analysis says nothing here
    _own_answers(world, world.t_fid)
    # a whole search after the approval: started, finished, stored; then the result waits again in a NEW analysis and storing is refused
    world.flow.set({TIMEOUT: "approved"})
    base = "/api/isolate/%s/%d" % (UID, world.t_fid)
    iso = world.c.post(base + "/isolate", json={"anyway": True, "standin": True, "name": "t", "n": 15, "m": 2})
    assert iso.status_code == 200, iso.get_json()
    r = world.c.post(base + "/search", json={"sequence": iso.get_json()["sequence"], "budget": RS.BUDGET_MIN, "bench": "simulated", "pool_n": 15, "trigger_seed": 3, "name": "t"})
    assert r.status_code == 200 and r.get_json()["stored"] is True, r.get_json()
    assert os.path.exists(os.path.join(world.root, "uploads", UID, "replay_search", "f%d.json" % world.t_fid))
    world.flow.set({TIMEOUT: "needs_review"})
    _refused(world.c.post(base + "/search/store", json={"name": "t", "which": "best"}), WAITS % "NVMe command timed out")
    world.flow.set({TIMEOUT: "approved"})
    r = world.c.post(base + "/search/store", json={"name": "t", "which": "best"})
    assert r.status_code in (200, 400) and "waits_for" not in (r.get_json() or {}), r.get_json()      # its own answer (no cause is named for this error yet)
    world.flow.none()


@pytest.mark.parametrize("upload", ["no-such-upload", "..", "%2e%2e", "up-join%2F..", "a" * 3000, "up join", "%00", "<script>", "up-join;drop"])
def test_a_hostile_address_is_answered_as_before_by_the_search_routes(world, monkeypatch, upload):
    from api import isolate_api as IA
    world.flow.set({TIMEOUT: "needs_review"})
    urls = ["/api/isolate/%s/%s%s" % (upload, fid, tail) for tail in SEARCH_ROUTES for fid in (world.t_fid, 0, 10 ** 12)]
    urls += ["/api/isolate/%s/%s%s" % (UID, fid, tail) for tail in SEARCH_ROUTES for fid in (0, 10 ** 12, 10 ** 30, "abc", "-1", "1.5")]
    now = [world.c.post(u, json={}).status_code for u in urls]
    monkeypatch.setattr(IA, "_flow_refusal", lambda s, uid, fid: None)
    assert now == [world.c.post(u, json={}).status_code for u in urls]               # the guard changed no answer of a request that names no waiting error
    assert 409 not in now
    world.flow.none()


# ============================================================================================== 5. the graph routes
def _dg_bodies(w, fid, did, cid):
    return {"/api/dg/occurrences": {"defect_id": did, "cause_id": None, "upload_id": UID, "finding_id": fid, "device": "D", "admin": "t"},
            "/api/dg/causes": {"defect_id": did, "keyword": "host_abort_by_tool_or_test", "admin": "t", "upload_id": UID, "finding_id": fid},
            "/api/dg/solutions": {"cause_id": cid, "error_seq": STEPS, "optimized": ["do not abort the Read early"], "admin": "t", "upload_id": UID, "finding_id": fid},
            "/api/dg/optimized": {"upload_id": UID, "finding_id": fid, "isolation": {}, "cause": {}, "error_seq": [], "standin": True}}


def test_the_four_graph_routes_refuse_while_the_patterns_result_waits_and_write_nothing(world):
    from api import isolate_api as IA
    world.flow.none()
    did = _defect(world, "Read never completed (refusal test)")
    cid = world.c.post("/api/dg/causes", json={"defect_id": did, "side": "device", "header": "the controller stalls (refusal test)", "admin": "t"}).get_json()["id"]
    for item, fid, name in ((TIMEOUT, world.t_fid, "NVMe command timed out"), (OWN, world.o_fid, "aborted commands")):
        world.flow.set({item: "needs_review"})
        before, jobs = _graph_counts(world.kb), dict(IA._JOBS)
        for url, body in _dg_bodies(world, fid, did, cid).items():
            _refused(world.c.post(url, json=body), WAITS % name)
            _refused(world.c.post(url, json=dict(body, finding_id=str(fid))), WAITS % name)       # the error's number written as text is the same error
        _refused(world.c.post("/api/dg/optimized?job=1", json=_dg_bodies(world, fid, did, cid)["/api/dg/optimized"]), WAITS % name)
        assert _graph_counts(world.kb) == before and dict(IA._JOBS) == jobs          # nothing was stored, no job was started
        world.flow.set({item: "running"})
        for url, body in _dg_bodies(world, fid, did, cid).items():
            _refused(world.c.post(url, json=body), NOT_YET % name)
    world.flow.none()


def test_a_graph_request_that_names_no_error_behaves_as_before_while_a_result_waits(world):
    world.flow.none()
    did = _defect(world, "Read never completed (no error named)")
    world.flow.set({TIMEOUT: "needs_review", OWN: "needs_review"})
    r = world.c.post("/api/dg/causes", json={"defect_id": did, "keyword": "host_abort_by_tool_or_test", "admin": "t"})
    assert r.status_code == 200 and r.get_json()["created"] is True, r.get_json()
    cid = r.get_json()["id"]
    for more in ({}, {"upload_id": UID}, {"finding_id": world.t_fid}, {"upload_id": "", "finding_id": world.t_fid}, {"upload_id": UID, "finding_id": ""},
                 {"upload_id": None, "finding_id": None}):
        r = world.c.post("/api/dg/solutions", json=dict({"cause_id": cid, "error_seq": STEPS, "optimized": ["x"], "admin": "t"}, **more))
        assert r.status_code == 200 and r.get_json()["id"], (more, r.get_json())
    # an error of another recording, and an error whose pattern no analysis of this recording holds, are not under this flow's order
    r = world.c.post("/api/dg/solutions", json={"cause_id": cid, "error_seq": STEPS, "optimized": ["x"], "admin": "t", "upload_id": "another-recording", "finding_id": world.t_fid})
    assert r.status_code == 200, r.get_json()
    world.flow.set({OWN: "needs_review"})
    r = world.c.post("/api/dg/occurrences", json={"defect_id": did, "cause_id": cid, "upload_id": UID, "finding_id": world.t_fid, "admin": "t"})
    assert r.status_code == 200 and r.get_json()["id"], r.get_json()
    world.flow.none()


@pytest.mark.parametrize("state", ["no analysis", "approved"])
def test_the_four_graph_routes_work_without_a_flow_and_after_the_approval(world, state):
    world.flow.none()
    did = _defect(world, "Read never completed (%s)" % state)
    if state == "approved":
        world.flow.set({TIMEOUT: "approved", OWN: "approved"})
    for fid in (world.t_fid, world.o_fid):
        occ = world.c.post("/api/dg/occurrences", json=_dg_bodies(world, fid, did, None)["/api/dg/occurrences"])
        assert occ.status_code == 200 and occ.get_json()["id"], occ.get_json()
        cz = world.c.post("/api/dg/causes", json=_dg_bodies(world, fid, did, None)["/api/dg/causes"])
        assert cz.status_code == 200 and cz.get_json()["id"], cz.get_json()
        sol = world.c.post("/api/dg/solutions", json=_dg_bodies(world, fid, did, cz.get_json()["id"])["/api/dg/solutions"])
        assert sol.status_code == 200 and sol.get_json()["solution"]["lab"]["lines"] == ["lab runs: none yet"], sol.get_json()
        opt = world.c.post("/api/dg/optimized", json=_dg_bodies(world, fid, did, None)["/api/dg/optimized"])
        assert opt.status_code == 200 and opt.get_json()["standin"] is True and opt.get_json()["lines"] == [], opt.get_json()
        st = world.c.get("/api/dg/status?upload=%s&findings=%d" % (UID, fid)).get_json()["status"][str(fid)]
        assert st["state"] == "solved" and st["solution_id"] == sol.get_json()["id"], st
    world.flow.none()


HOSTILE = [{"upload_id": ["x"], "finding_id": 1}, {"upload_id": "a\x00b", "finding_id": 1}, {"upload_id": "../../etc", "finding_id": 1}, {"upload_id": "..", "finding_id": 1},
           {"upload_id": UID, "finding_id": [1]}, {"upload_id": UID, "finding_id": True}, {"upload_id": UID, "finding_id": "12abc"}, {"upload_id": UID, "finding_id": 10 ** 30},
           {"upload_id": UID, "finding_id": -5}, {"upload_id": UID, "finding_id": 1.5}, {"upload_id": "x" * 100000, "finding_id": 1}, {"upload_id": UID, "finding_id": "9" * 5000},
           {"upload_id": {"a": 1}, "finding_id": {"b": 2}}, {"upload_id": UID, "finding_id": 10 ** 9}, {"upload_id": UID, "finding_id": None}, {"upload_id": 7, "finding_id": 7},
           {"upload_id": UID, "finding_id": " "}, {"upload_id": UID + "\n", "finding_id": 1}, {"upload_id": "no-such-upload", "finding_id": 1}]


def test_hostile_values_never_fail_the_guard_and_never_change_an_answer(world, monkeypatch):
    from api import dg_api
    world.flow.none()
    did = _defect(world, "Read never completed (hostile)")
    cid = world.c.post("/api/dg/causes", json={"defect_id": did, "side": "device", "header": "the controller stalls (hostile)", "admin": "t"}).get_json()["id"]
    world.flow.set({TIMEOUT: "needs_review", OWN: "needs_review"})
    with world.app.test_request_context():
        for b in HOSTILE + [[], "x", 3, None, [{"upload_id": UID, "finding_id": world.t_fid}]]:
            assert dg_api._flow_wait(b) is None, repr(b)[:80]                    # none of them names the waiting error: no refusal, no failure
        assert dg_api._flow_wait({"upload_id": UID, "finding_id": world.t_fid})[1] == 409
        assert dg_api._flow_wait({"upload_id": UID, "finding_id": " %d " % world.t_fid})[1] == 409     # as the routes' own reading of a number takes it
    calls = [(url, dict(body, **bad)) for bad in HOSTILE for url, body in _dg_bodies(world, world.t_fid, did, cid).items()]
    now = [world.c.post(u, json=b).status_code for u, b in calls]
    assert 409 not in now
    monkeypatch.setattr(dg_api, "_flow_wait", lambda b: None)
    assert now == [world.c.post(u, json=b).status_code for u, b in calls]         # each request is answered as it was without the guard
    world.flow.none()


# ============================================================================================== 6. a validation suite's result -> lab runs
def _plan(upload, fid, version, slba):
    """A small plan the way the main flow builds it (nvme_hier/testplan.build_plan): a Write, then the Read that failed in the field."""
    finding = {"id": fid, "rule": "cmd.read_failure", "level": "nvme_command", "detail": {"SCT": 2, "SC": 0x81},
               "observed_outcome": "Read of 8 blocks at block %d ended with status type 2 code 81h (Unrecovered Read Error)" % slba}
    steps = [{"step": 1, "command": "Write", "opc": 0x01, "admin": False, "queue": 1, "parameters": {"nsid": 1, "slba": slba, "nlb": 7}, "gap_us": 10, "position": "above", "source_row": 11, "why": []},
             {"step": 2, "command": "Read", "opc": 0x02, "admin": False, "queue": 1, "parameters": {"nsid": 1, "slba": slba, "nlb": 7}, "gap_us": 10, "position": "fault", "source_row": 12, "why": []}]
    return TP.build_plan(finding, steps, "v1|dev:TEST DRIVE|err:cmd.read_failure", "Read fails with an unrecovered read error", upload, version, "Test drive", None,
                         30 * 10 ** 6, [], [], "Tester", "%s_f%d" % (upload, fid))


def _approve(path, uid, fid, who="Asha"):
    """The approval record exactly as app/api/isolate_api.py approve_testcase writes it."""
    with open(path, "rb") as fh:
        sha = hashlib.sha256(fh.read()).hexdigest()
    with open(path + ".approved.json", "w", encoding="utf-8") as fh:
        json.dump({"approved_by": who, "at": time.time(), "sha256": sha, "status": "approved", "comment": "", "upload_id": uid, "finding": fid, "two_sided": True}, fh, indent=1)


TIED, FREE = "up-lab-1_f3_v1.py", "up-lab-1_f4_v1.py"


@pytest.fixture()
def lab(tmp_path):
    """A temporary application root: two approved tests in suite/hier; the procedural graph holds one solution, and the first test is the
    approved test of that solution's version (what approve_testcase writes); the second test was approved without a solution."""
    root = str(tmp_path / "app")
    hier = os.path.join(root, "suite", "hier")
    os.makedirs(os.path.join(root, "db"))
    plans = {TIED: _plan("up-lab-1", 3, 1, 1000), FREE: _plan("up-lab-1", 4, 1, 5000)}
    paths = {n: TP.write(p, hier, n) for n, p in plans.items()}
    _approve(paths[TIED], "up-lab-1", 3)
    _approve(paths[FREE], "up-lab-1", 4)
    g = DG.DefectGraph(HO.knowledge_db(root))
    did, _ = g.add_defect("Read: completed with an error status", "cmd.read_failure", "nvme_command", "what", "t", term_key="lab|1")
    cid, _ = g.add_cause(did, "device", "the drive cannot read the blocks", "t")
    sid, rid = g.add_solution(cid, STEPS, ["replace the drive"], "", "admin:t", "t", "up-lab-1", 3)
    other, _r = g.add_solution(cid, STEPS, ["another solution"], "", "admin:t", "t")
    g.verdict(other, "correct", "t")                              # a judged solution beside it: the order by judgements must not move
    g.set_test_path(rid, os.path.realpath(paths[TIED]), "up-lab-1", 3)
    return types.SimpleNamespace(root=root, hier=hier, g=g, did=did, cid=cid, sid=sid, rid=rid, other=other, plans=plans, paths=paths)


def junit(test, package=None, stamp="2026-11-15T09:00:00.000001", case=None, inner="", **facts):
    """A JUnit result file as pytest writes it for one test of a package; facts are the replay library's properties (backend, expect, verdict,
    drive_model, drive_firmware); a fact given as None is left out of the file."""
    stem = test[:-3]
    tid, ver = stem.rsplit("_v", 1)
    props = ([("handover_package", package)] if package else []) + [("test_id", tid), ("test_version", ver)] + [(k, v) for k, v in facts.items() if v is not None]
    return ('<?xml version="1.0" encoding="utf-8"?><testsuites><testsuite name="pytest" tests="1"%s><properties>%s</properties>'
            '<testcase classname="tests.%s" name=%s time="0.1">%s</testcase></testsuite></testsuites>' % (
                (" timestamp=%s" % quoteattr(stamp)) if stamp is not None else "", "".join("<property name=%s value=%s/>" % (quoteattr(k), quoteattr(str(v))) for k, v in props),
                stem, quoteattr(case or HO.REPLAY_CASE), inner)).encode("utf-8")


FAILED = '<failure message="FAILED: the recorded fault did not appear">long text</failure>'
REAL = {"backend": "real", "expect": "fault", "drive_model": "Model X", "drive_firmware": "FW 2.1"}


def _labs(lab, sid=None):
    return [(r["bench"], r["source"], r["runs"], r["reproduced"], r["counted"]) for r in lab.g.lab_rows(solution_id=sid or lab.sid)]


def test_the_package_keeps_the_stored_solution_of_each_test(lab, tmp_path):
    assert HO.solution_of_test(lab.root, TIED) == {"solution_id": lab.sid, "revision_id": lab.rid, "version": 1,
                                                  "words": "The test %s was approved for version 1 of stored solution number %d of the procedural graph: the graph keeps this "
                                                           "test file as the approved test of that version." % (TIED, lab.sid)}
    free = HO.solution_of_test(lab.root, FREE)
    assert (free["solution_id"], free["revision_id"]) == (None, None) and "do not tie the test %s to a stored solution" % FREE in free["words"]
    made = HO.build_package(lab.root, [TIED, FREE], "Kiran")
    a, b = made["manifest"]["tests"]
    assert a["stored_solution"]["solution_id"] == lab.sid and a["stored_solution"]["revision_id"] == lab.rid and a["stored_solution"]["version"] == 1
    assert a["stored_solution"]["words"].endswith("A result brought back for this test is counted as lab runs of that solution.")
    assert b["stored_solution"]["solution_id"] is None and b["stored_solution"]["words"].endswith("A result brought back for it is kept, but it is not counted as lab runs of a solution.")
    with zipfile.ZipFile(io.BytesIO(made["zip"])) as z:
        man, txt = json.loads(z.read("manifest.json")), z.read("manifest.txt").decode("utf-8")
    assert man == json.loads(json.dumps(made["manifest"])) and "Stored solution it was written from:" in txt and ("stored solution number %d" % lab.sid) in txt.replace("\n    ", " ")
    con = sqlite3.connect(HO.knowledge_db(lab.root))
    assert sorted(con.execute("SELECT test, solution_id, revision_id FROM handover_package_test WHERE package_id = ?", (made["package_id"],)).fetchall()) == \
        [(TIED, lab.sid, lab.rid), (FREE, None, None)]
    con.close()
    # the tie is the test file itself: the same name under another application folder (the folder was moved) is the same file; a look-alike is not
    lab.g.set_test_path(lab.rid, "C:\\somewhere\\else\\suite\\hier\\" + TIED)
    assert HO.solution_of_test(lab.root, TIED)["solution_id"] == lab.sid
    for path in ("/x/suite/hier/other_" + TIED, "/x/suite/other/" + TIED, TIED, "/x/suite/hier/" + TIED + ".bak", "", "\x00"):
        lab.g.set_test_path(lab.rid, path)
        assert HO.solution_of_test(lab.root, TIED)["solution_id"] is None, path
    # two solutions naming the same test file: it is tied to neither, and the words say so
    lab.g.set_test_path(lab.rid, lab.paths[TIED])
    lab.g.set_test_path(lab.g.solution(lab.other)["revision_id"], lab.paths[TIED])
    two = HO.solution_of_test(lab.root, TIED)
    assert two["solution_id"] is None and "More than one stored solution" in two["words"]


def test_a_result_from_a_real_drive_becomes_one_lab_row_and_is_never_counted_twice(lab):
    made = HO.build_package(lab.root, [TIED], "Kiran")
    order = [s["id"] for s in lab.g.solutions(lab.cid)]
    judged = {s: (lab.g.solution(s)["correct"], lab.g.solution(s)["judged"]) for s in (lab.sid, lab.other)}
    xml = junit(TIED, made["package_id"], verdict="reproduced 1 of 3", **REAL)
    r = HO.read_results(lab.root, xml, "Divya")
    assert r["graph"] == {"counted": 1, "not_counted": 0} and r["recorded"][0]["graph"]["counted"] is True and r["recorded"][0]["graph"]["solution_id"] == lab.sid
    assert r["graph_words"] == ("The result of the test %s was counted on the procedural graph as lab runs of stored solution number %d: the failure came back in 1 of 3 runs "
                                "on the real drive. No judgement and no order changed." % (TIED, lab.sid))
    assert "_verdict" not in r["recorded"][0] and "_tie" not in r["recorded"][0]
    rows = lab.g.lab_rows(solution_id=lab.sid)
    assert len(rows) == 1 and rows[0]["id"] == r["recorded"][0]["graph"]["lab_row"]
    row = rows[0]
    assert (row["bench"], row["source"], row["runs"], row["reproduced"], row["counted"], row["by"]) == ("real drive", "validation_suite", 3, 1, True, "Divya")
    assert (row["revision_id"], row["defect_id"], row["cause_id"], row["model"], row["firmware"], row["upload_id"], row["finding_id"]) == \
        (lab.rid, lab.did, lab.cid, "Model X", "FW 2.1", "up-lab-1", 3)
    assert made["package_id"] in row["note"] and TIED in row["note"]
    assert lab.g.solution(lab.sid)["lab"]["real"]["words"] == "lab runs: the failure came back in 1 of 3 on the real drive" and lab.g.solution(lab.sid)["lab"]["simulated"] is None
    # the same file again: refused whole, as before; nothing more on the graph
    with pytest.raises(HO.HandoverError, match="already brought in"):
        HO.read_results(lab.root, xml, "Divya")
    assert len(lab.g.lab_rows(solution_id=lab.sid)) == 1
    # the same run of the same package and test in another file (other bytes): the result is kept, the run is not counted a second time
    again = HO.read_results(lab.root, xml.replace(b'time="0.1"', b'time="0.2"'), "Ravi")
    assert again["graph"] == {"counted": 0, "not_counted": 1} and again["counts"]["passed"] == 1
    assert again["graph_words"] == ("The result of the test %s was kept, but it was not counted on the procedural graph, because a result of this package and this test for the "
                                    "same run (run on 2026-11-15T09:00:00.000001) is already counted there: one run is counted once." % TIED)
    assert len(lab.g.lab_rows(solution_id=lab.sid)) == 1
    assert len(HO.results(lab.root, TIED)["tests"][0]["results"]) == 2                # both result files are kept
    # another run of the same package (its own time stamp) is another lab row; a run that did not bring the failure back counts against the solution
    more = HO.read_results(lab.root, junit(TIED, made["package_id"], stamp="2026-11-16T10:00:00", inner=FAILED, verdict="not reproduced in 10 runs", **REAL), "Divya")
    assert more["graph"]["counted"] == 1 and "the failure came back in 0 of 10 runs on the real drive" in more["graph_words"]
    assert _labs(lab) == [("real drive", "validation_suite", 3, 1, True), ("real drive", "validation_suite", 10, 0, True)]
    assert lab.g.solution(lab.sid)["lab"]["real"]["words"] == "lab runs: the failure came back in 1 of 13 on the real drive"
    # a second package of the same test is another package: its run is its own
    made2 = HO.build_package(lab.root, [TIED], "Kiran")
    HO.read_results(lab.root, junit(TIED, made2["package_id"], verdict="reproduced 2 of 2", **REAL), "Divya")
    assert len(lab.g.lab_rows(solution_id=lab.sid)) == 3
    # no judgement and no order changed, and the other solution has no lab row
    assert [s["id"] for s in lab.g.solutions(lab.cid)] == order
    assert {s: (lab.g.solution(s)["correct"], lab.g.solution(s)["judged"]) for s in (lab.sid, lab.other)} == judged
    assert lab.g.lab_rows(solution_id=lab.other) == []
    con = sqlite3.connect(HO.knowledge_db(lab.root))
    assert con.execute("SELECT COUNT(*), COUNT(lab_row) FROM handover_lab").fetchone() == (3, 3)
    con.close()


def test_a_result_that_does_not_say_its_bench_is_kept_and_not_counted(lab):
    made = HO.build_package(lab.root, [TIED], "Kiran")
    r = HO.read_results(lab.root, junit(TIED, made["package_id"], verdict="reproduced 1 of 3", expect="fault", backend=None), "Divya")
    assert r["counts"] == {"passed": 1, "failed": 0, "skipped": 0} and r["graph"] == {"counted": 0, "not_counted": 1}
    assert r["graph_words"] == ("The result of the test %s was kept, but it was not counted on the procedural graph, because the result file does not say which bench it ran on "
                                "(a real drive or the simulated drive)." % TIED)
    assert r["recorded"][0]["drive_kind"] == "not said in the result file" and r["recorded"][0]["graph"]["lab_row"] is None
    assert lab.g.lab_rows(solution_id=lab.sid) == [] and HO.results(lab.root, TIED)["tests"][0]["count"] == 1
    # the same run brought in later WITH its bench is counted then (nothing was used up by the refusal)
    r = HO.read_results(lab.root, junit(TIED, made["package_id"], verdict="reproduced 1 of 3", expect="fault", backend="sim"), "Divya")
    assert r["graph"]["counted"] == 1 and _labs(lab) == [("simulated drive", "validation_suite", 3, 1, True)]
    assert lab.g.solution(lab.sid)["lab"]["simulated"]["words"] == "lab runs: the failure came back in 1 of 3 on the simulated drive" and lab.g.solution(lab.sid)["lab"]["real"] is None


NOT_COUNTED = [
    (dict(REAL, backend="REAL", verdict="reproduced 1 of 3"), "", None, "does not say which bench it ran on"),
    (dict(REAL, backend="real drive", verdict="reproduced 1 of 3"), "", None, "does not say which bench it ran on"),
    (dict(REAL, backend="", verdict="reproduced 1 of 3"), "", None, "does not say which bench it ran on"),
    (dict(REAL, backend="simulated; DROP TABLE dg_lab", verdict="reproduced 1 of 3"), "", None, "does not say which bench it ran on"),
    (dict(REAL, expect="fixed", verdict="fixed: 30 clean runs"), "", None, "the run looked for the fix, not for the error"),
    (dict(REAL, expect="fixed", verdict="fault seen again"), FAILED, None, "the run looked for the fix, not for the error"),
    (dict(REAL, expect=None, verdict="reproduced 1 of 3"), "", None, "does not say that the run looked for the error"),
    (dict(REAL, expect="spec", verdict="reproduced 1 of 3"), "", None, "does not say that the run looked for the error"),
    (dict(REAL, verdict=None), "", None, "does not say in how many runs the failure came back"),
    (dict(REAL, verdict="passed"), "", None, "does not say in how many runs the failure came back"),
    (dict(REAL, verdict="reproduced -1 of 3"), "", None, "does not say in how many runs the failure came back"),
    (dict(REAL, verdict="reproduced 1.5 of 3"), "", None, "does not say in how many runs the failure came back"),
    (dict(REAL, verdict="reproduced 1 of 3; reproduced 3 of 3"), "", None, "does not say in how many runs the failure came back"),
    (dict(REAL, verdict="reproduced 99999999999999999999 of 3"), "", None, "does not say in how many runs the failure came back"),
    (dict(REAL, verdict="reproduced 5 of 3"), "", None, "the run counts in the result file are not possible"),
    (dict(REAL, verdict="reproduced 0 of 0"), FAILED, None, "the run counts in the result file are not possible"),
    (dict(REAL, verdict="reproduced 1 of 9999999"), "", None, "the run counts in the result file are not possible"),
    (dict(REAL, verdict="reproduced 2 of 5"), FAILED, None, "its outcome (failed) and its own count (the failure came back in 2 of 5 runs) do not agree"),
    (dict(REAL, verdict="not reproduced in 4 runs"), "", None, "its outcome (passed) and its own count (the failure came back in 0 of 4 runs) do not agree"),
    (dict(REAL, verdict="reproduced 0 of 4"), "", None, "do not agree"),
    (dict(REAL, verdict="reproduced 1 of 3"), '<skipped message="no drive given">x</skipped>', None, "the test was skipped, so no run was made"),
    (dict(REAL, verdict="invalid: the firmware revision changed during the run"), '<error message="boom">x</error>', None, "does not say in how many runs"),
    (dict(REAL, verdict="reproduced 1 of 3"), "", "test_deallocate_range", "this case of the test file is not the replay of the solution's sequence"),
    (dict(REAL, verdict="reproduced 1 of 3"), "", "test_defect_reproduces_or_stays_fixed ", "this case of the test file is not the replay"),
]


@pytest.mark.parametrize("facts,inner,case,why", NOT_COUNTED)
def test_a_result_that_does_not_state_everything_is_kept_and_not_counted(lab, facts, inner, case, why):
    made = HO.build_package(lab.root, [TIED], "Kiran")
    before = _graph_counts(HO.knowledge_db(lab.root))
    r = HO.read_results(lab.root, junit(TIED, made["package_id"], case=case, inner=inner, **facts), "Divya")
    assert len(r["recorded"]) == 1 and r["graph"] == {"counted": 0, "not_counted": 1}, r
    assert r["graph_words"].startswith("The result of the test %s was kept, but it was not counted on the procedural graph, because " % TIED) and why in r["graph_words"], r["graph_words"]
    assert _graph_counts(HO.knowledge_db(lab.root)) == before and lab.g.lab_rows(solution_id=lab.sid) == []
    con = sqlite3.connect(HO.knowledge_db(lab.root))
    assert con.execute("SELECT COUNT(*) FROM handover_lab").fetchone()[0] == 0        # nothing was used up: the run can still be counted when it states everything
    con.close()


def test_a_test_that_is_tied_to_no_solution_is_never_given_one(lab):
    made = HO.build_package(lab.root, [TIED, FREE], "Kiran")
    r = HO.read_results(lab.root, junit(FREE, made["package_id"], verdict="reproduced 3 of 3", **REAL), "Divya")
    assert r["graph"] == {"counted": 0, "not_counted": 1} and r["recorded"][0]["graph"]["solution_id"] is None
    assert r["graph_words"] == ("The result of the test %s was kept, but it was not counted on the procedural graph, because the application's records do not tie this test to "
                                "a stored solution (it was approved without naming a version of a solution)." % FREE)
    assert _count(HO.knowledge_db(lab.root), "dg_lab") == 0
    # a solution deleted from the graph after the package was built: the graph's refusal is said, and the run stays free
    con = sqlite3.connect(HO.knowledge_db(lab.root))
    con.execute("DELETE FROM dg_solution WHERE id = ?", (lab.sid,))
    con.commit()
    con.close()
    r = HO.read_results(lab.root, junit(TIED, made["package_id"], verdict="reproduced 3 of 3", **REAL), "Divya")
    assert r["graph"]["counted"] == 0 and "the procedural graph did not take it (no such stored solution)" in r["graph_words"]
    assert _count(HO.knowledge_db(lab.root), "dg_lab") == 0 and _count(HO.knowledge_db(lab.root), "handover_lab") == 0


def test_a_result_without_a_run_time_is_counted_once_and_a_second_one_cannot_be_told_apart(lab):
    made = HO.build_package(lab.root, [TIED], "Kiran")
    r = HO.read_results(lab.root, junit(TIED, made["package_id"], stamp=None, verdict="reproduced 1 of 2", **REAL), "Divya")
    assert r["graph"]["counted"] == 1 and r["recorded"][0]["run_at"] is None
    r = HO.read_results(lab.root, junit(TIED, made["package_id"], stamp=None, verdict="reproduced 2 of 2", **REAL), "Divya")
    assert r["graph"]["counted"] == 0 and "does not say when the run was made" in r["graph_words"] and "it cannot be told from the same run given twice" in r["graph_words"]
    assert _labs(lab) == [("real drive", "validation_suite", 2, 1, True)]


def test_a_package_built_before_today_is_tied_by_the_same_identity_while_its_file_is_unchanged(lab):
    made = HO.build_package(lab.root, [TIED], "Kiran")
    con = sqlite3.connect(HO.knowledge_db(lab.root))
    con.execute("UPDATE handover_package_test SET solution_id = NULL, revision_id = NULL")       # as a package of 2026-11-14 was recorded
    con.commit()
    con.close()
    r = HO.read_results(lab.root, junit(TIED, made["package_id"], verdict="reproduced 1 of 1", **REAL), "Divya")
    assert r["graph"]["counted"] == 1 and _labs(lab) == [("real drive", "validation_suite", 1, 1, True)]
    with open(lab.paths[TIED], "a", encoding="utf-8") as fh:
        fh.write("\n# changed after the package was built\n")
    r = HO.read_results(lab.root, junit(TIED, made["package_id"], stamp="2026-11-17T08:00:00", verdict="reproduced 1 of 1", **REAL), "Divya")
    assert r["graph"]["counted"] == 0 and "or the test file was changed or removed since the package was built" in r["graph_words"]
    assert len(lab.g.lab_rows(solution_id=lab.sid)) == 1


def test_an_older_knowledge_base_gains_the_columns_and_keeps_its_rows(tmp_path):
    root = str(tmp_path / "old")
    os.makedirs(os.path.join(root, "db"))
    con = sqlite3.connect(HO.knowledge_db(root))
    con.executescript("CREATE TABLE handover_package (package_id TEXT PRIMARY KEY, built_at REAL, built_by TEXT, zip_sha256 TEXT, n_tests INTEGER);"
                      "CREATE TABLE handover_package_test (package_id TEXT, test TEXT, workflow TEXT, classname TEXT, sha256 TEXT, PRIMARY KEY (package_id, test));"
                      "INSERT INTO handover_package VALUES ('handover-20261114-000000-aaaaaa', 1.0, 'Kiran', 'x', 1);"
                      "INSERT INTO handover_package_test VALUES ('handover-20261114-000000-aaaaaa', 'up-old_f1_v1.py', 'main flow', 'tests.up-old_f1_v1', 'y');")
    con.commit()
    con.close()
    assert HO.packages(root)["packages"][0]["tests"] == ["up-old_f1_v1.py"]
    con = sqlite3.connect(HO.knowledge_db(root))
    assert con.execute("SELECT test, sha256, solution_id, revision_id FROM handover_package_test").fetchall() == [("up-old_f1_v1.py", "y", None, None)]
    con.close()
    # a result for that old package's test, whose file is not on this computer: recorded, tied to nothing, the graph's tables are not even made
    r = HO.read_results(root, junit("up-old_f1_v1.py", "handover-20261114-000000-aaaaaa", verdict="reproduced 1 of 1", **REAL), "Divya")
    assert r["graph"]["counted"] == 0 and "do not tie this test to a stored solution" in r["graph_words"] and _count(HO.knowledge_db(root), "dg_lab") == 0


def test_hostile_facts_reach_the_graph_only_as_bounded_text(lab):
    made = HO.build_package(lab.root, [TIED], "Kiran")
    r = HO.read_results(lab.root, junit(TIED, made["package_id"], stamp="T" * 5000, backend="real", expect="fault", verdict="  reproduced   2 of 4 ",
                                        drive_model="M<script>alert(1)</script>" + "m" * 5000, drive_firmware="'); DROP TABLE dg_lab;--"), "Divya")
    assert r["graph"]["counted"] == 1
    row = lab.g.lab_rows(solution_id=lab.sid)[0]
    assert (row["runs"], row["reproduced"], row["firmware"]) == (4, 2, "'); DROP TABLE dg_lab;--") and len(row["model"]) == 200 and len(row["note"]) <= 600
    con = sqlite3.connect(HO.knowledge_db(lab.root))
    assert [len(k[0]) for k in con.execute("SELECT run_key FROM handover_lab")] == [80]
    con.close()
    for who in ("", "   ", None, 5, "x" * 500, "a\x00b"):                           # who brings it in is checked before anything is recorded
        with pytest.raises(HO.HandoverError):
            HO.read_results(lab.root, junit(TIED, made["package_id"], stamp="2026-11-18T08:00:00", verdict="reproduced 1 of 1", **REAL), who)
    assert len(lab.g.lab_rows(solution_id=lab.sid)) == 1


def test_the_route_says_in_one_sentence_what_was_counted_and_what_was_not(lab):
    from flask import Flask
    from api import handover_api
    app = Flask("join_handover_test")
    app.config["services"] = types.SimpleNamespace(root=lab.root)
    app.config["PROPAGATE_EXCEPTIONS"] = False
    app.register_blueprint(handover_api.bp)
    c = app.test_client()
    z = c.post("/api/handover/package", json={"tests": [TIED], "name": "Kiran"})
    assert z.status_code == 200
    pkg = z.headers["X-Handover-Package"]
    with zipfile.ZipFile(io.BytesIO(z.data)) as zf:
        assert json.loads(zf.read("manifest.json"))["tests"][0]["stored_solution"]["solution_id"] == lab.sid
    r = c.post("/api/handover/results", data={"file": (io.BytesIO(junit(TIED, pkg, verdict="reproduced 1 of 3", expect="fault")), "result.xml"), "name": "Divya"},
               content_type="multipart/form-data")
    assert r.status_code == 200 and r.get_json()["words"] == "1 result recorded: 1 passed, 0 failed, 0 skipped."
    assert r.get_json()["graph_words"] == ("The result of the test %s was kept, but it was not counted on the procedural graph, because the result file does not say which bench "
                                           "it ran on (a real drive or the simulated drive)." % TIED)
    assert lab.g.lab_rows(solution_id=lab.sid) == []
    r = c.post("/api/handover/results?name=Divya", data=junit(TIED, pkg, stamp="2026-11-16T07:00:00", verdict="reproduced 1 of 3", **REAL), content_type="application/xml")
    assert r.status_code == 200 and r.get_json()["graph"] == {"counted": 1, "not_counted": 0} and "on the real drive" in r.get_json()["graph_words"]
    assert _labs(lab) == [("real drive", "validation_suite", 3, 1, True)]
    again = c.post("/api/handover/results?name=Divya", data=junit(TIED, pkg, stamp="2026-11-16T07:00:00", verdict="reproduced 1 of 3", **REAL), content_type="application/xml")
    assert again.status_code == 400 and "already brought in" in again.get_json()["error"] and len(lab.g.lab_rows(solution_id=lab.sid)) == 1


def test_the_packages_own_command_on_the_simulated_drive_gives_results_that_are_counted_as_simulated(lab, tmp_path):
    """The real path: the package is unpacked, its README's command runs the unchanged test on the simulated drive (never a real one), and
    the result file pytest wrote is brought in. The counts are the replay library's own words in that file."""
    made = HO.build_package(lab.root, [TIED], "Kiran")
    folder = str(tmp_path / "unpacked")
    with zipfile.ZipFile(io.BytesIO(made["zip"])) as z:
        z.extractall(folder)
    line = next(x.strip() for x in _read(os.path.join(folder, "README.txt")).splitlines() if x.strip().startswith("NVME_BACKEND=sim python3 -m pytest"))
    words = shlex.split(line)
    assert words[:2] == ["NVME_BACKEND=sim", "python3"]
    env = {k: v for k, v in os.environ.items() if not k.startswith("NVME_") and k != "EXPECT"}
    env.update(NVME_BACKEND="sim", PYTHONDONTWRITEBYTECODE="1", NVME_REPEAT="2")
    cfg = str(tmp_path / "sim.json")
    with open(cfg, "w", encoding="utf-8") as fh:
        json.dump({"lba_bytes": 512, "nsze": 1 << 20, "drb": 1, "thinp": True, "dae": True, "nsid": 1, "faults": [TP.sim_fault(lab.plans[TIED])]}, fh)
    seen = []
    for more, outcome in (({"NVME_SIM": cfg}, "passed"), ({}, "failed")):     # a simulated drive with the recorded fault, then a correct one
        assert "NVME_NS" not in env
        p = subprocess.run([sys.executable] + words[2:] + ["-p", "no:cacheprovider"], capture_output=True, text=True, timeout=300, cwd=folder, env=dict(env, **more))
        with open(os.path.join(folder, "result.xml"), "rb") as fh:
            xml = fh.read()
        said = re.search(rb'<property name="verdict" value="([^"]*)"', xml)
        assert said, (p.stdout[-800:], p.stderr[-800:])
        r = HO.read_results(lab.root, xml, "Divya")
        assert r["recorded"][0]["outcome"] == outcome and r["recorded"][0]["drive_kind"] == "simulated" and r["graph"] == {"counted": 1, "not_counted": 0}, r
        seen.append(said.group(1).decode())
    assert re.fullmatch(r"reproduced 1 of [12]", seen[0]) and seen[1] == "not reproduced in 2 runs", seen
    k1, n1 = (int(x) for x in re.findall(r"\d+", seen[0]))
    assert _labs(lab) == [("simulated drive", "validation_suite", n1, k1, True), ("simulated drive", "validation_suite", 2, 0, True)]
    assert lab.g.solution(lab.sid)["lab"]["real"] is None                              # a simulated run is never shown as a real one


# ============================================================================================== 3. the page of one error (its own functions, run by node)
def piece(text, name):
    """One top-level function or constant of the page script, as its text: from its first line to the line where its braces close."""
    m = re.search(r"^(?:async )?function %s\(|^const %s = " % (re.escape(name), re.escape(name)), text, re.M)
    assert m, "the page script has no top-level %s" % name
    out, depth, seen = [], 0, False
    for line in text[m.start():].split("\n"):
        out.append(line)
        depth += line.count("{") - line.count("}")
        seen = seen or "{" in line
        if depth == 0 and (seen or line.rstrip().endswith(";")):
            return "\n".join(out) + "\n"
    raise AssertionError("the braces of %s do not close" % name)


STAND_IN_PAGE = r"""
// a stand-in page: only what the functions under test touch
const els = {};
const el = (id, more) => (els[id] = Object.assign({ id, hidden: false, className: "", innerHTML: "", textContent: "", disabled: false }, more || {}));
const sections = ["s-waits", "s-error", "s-window", "s-isolate", "s-graph", "s-solution", "s-search", "s-test", "s-handover", "s-ask"].map(id => el(id, { hidden: id === "s-waits" }));
const navs = [1, 2, 3].map(() => ({ disabled: false }));
["page-title", "load-error", "iso-status", "iso-out", "win-status"].forEach(id => el(id, { hidden: id === "load-error" }));
const document = { title: "One error", getElementById: id => els[id] || null,
  querySelectorAll: sel => sel === "main > section.card" ? sections : sel === "aside button.nav" ? navs : [] };
const $ = id => document.getElementById(id);
const status = (id, text, cls = "") => { const e = $(id); if (e) { e.textContent = text; e.className = "status " + cls; } };
const IN = JSON.parse(require("fs").readFileSync(process.argv[2], "utf8"));
let Q = new URLSearchParams(IN.query || "");
const asked = [];
let NEXT = null;
async function fetch(url, opt) { asked.push((opt && opt.method) + " " + url); return { ok: NEXT.code < 400, status: NEXT.code, statusText: "refused", json: async () => { if (NEXT.body === undefined) throw new Error("no JSON"); return NEXT.body; } }; }
"""
PAGE_FUNCTIONS = ["api", "isWait", "page3Href", "waitsHtml", "waitLine", "refusedHere", "showWaits", "ruleWords", "ruleShort", "nameFrom",
                  "S", "KEY_LEVEL", "RULE_KEY", "NO_CAUSE", "ruleKeyWords", "ruleNamed", "causeName", "plain", "nf", "paramWords", "KIND_PART", "kindWords", "badge",
                  "SEARCH_RECORD", "noTestFile", "proposalWords"]


def run_node(tmp_path, scenario, given):
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    text = _read(SCRIPT)
    esc = re.search(r"^export (const esc = .*)$", _read(os.path.join(APP, "app", "static", "js", "api.js")), re.M).group(1)      # the page's own escaping
    d = tmp_path / "page"
    os.makedirs(str(d), exist_ok=True)
    (d / "in.json").write_text(json.dumps(given), encoding="utf-8")
    body = STAND_IN_PAGE + esc + "\n" + "".join(piece(text, n) for n in PAGE_FUNCTIONS) + "\n(async () => {\n" + scenario + "\n})().catch(e => { console.log('FAILED ' + e.stack); });\n"
    (d / "run.cjs").write_text(body, encoding="utf-8")
    p = subprocess.run([NODE, str(d / "run.cjs"), str(d / "in.json")], capture_output=True, text=True, encoding="utf-8", timeout=60)
    line = next((ln for ln in p.stdout.splitlines() if ln.startswith("RESULT ")), None)
    assert line, (p.stdout[-1500:], p.stderr[-1500:])
    return json.loads(line[7:])


def test_the_refusal_of_the_first_request_becomes_the_pages_message_and_nothing_else_is_loaded(tmp_path, world):
    pid = world.flow.set({TIMEOUT: "needs_review"})
    r = world.c.get("/api/isolate/%s/%d" % (UID, world.t_fid))                       # the real answer of the route
    world.flow.none()
    assert r.status_code == 409 and r.get_json()["project"] == pid                   # the number of the analysis that waits (2026-11-15)
    out = run_node(tmp_path, r"""
  NEXT = { code: 409, body: IN.answer };
  let err = null;
  try { await api("GET", "/api/isolate/up-join/3"); } catch (e) { err = e; }
  showWaits(err.answer);
  console.log("RESULT " + JSON.stringify({ message: err.message, status: err.status, waits: err.waits, asked, box: els["s-waits"], title: els["page-title"].textContent,
    tab: document.title, hidden: sections.filter(s => s.hidden).map(s => s.id), navs: navs.map(n => n.disabled), loadError: els["load-error"].hidden }));
""", {"answer": r.get_json(), "query": "upload=up-join&finding=3&back=" + "/#/p/7/errors"})
    sentence = WAITS % "NVMe command timed out"
    assert out["message"] == sentence and out["status"] == 409 and out["waits"] is True and out["asked"] == ["GET /api/isolate/up-join/3"]
    box = out["box"]
    assert box["hidden"] is False and box["className"] == "card waits"
    assert "<h2>This error cannot be opened yet</h2>" in box["innerHTML"] and sentence.replace("'", "'") in box["innerHTML"]
    assert '<a class="waits-link" href="/#/p/%d/rules"><b>Go to page 3 of the analysis</b></a>' % pid in box["innerHTML"]     # from the answer's number; "back=" is used when there is none
    assert "Nothing of this error was read or changed." in box["innerHTML"]
    assert out["hidden"] == ["s-error", "s-window", "s-isolate", "s-graph", "s-solution", "s-search", "s-test", "s-handover", "s-ask"] and out["navs"] == [True, True, True]
    assert out["title"] == "This error waits for the approval of its pattern's result" and out["tab"] == "This error cannot be opened yet" and out["loadError"] is True
    # the wiring: the page stops at the refusal, before the hand-over part and the window are asked for
    js = _read(SCRIPT)
    wiring = js[js.index("try { await loadError(); }"):]
    assert wiring.index("if (e.waits) { showWaits(e.answer); return; }") < wiring.index("showHandover()") < wiring.index("await showWindow();")
    html = _read(PAGE)
    assert '<section id="s-waits" class="card waits" hidden' in html and html.index('id="load-error"') < html.index('id="s-waits"') < html.index('id="s-error"')


def test_the_link_to_page_3_is_built_only_from_what_is_known(tmp_path):
    out = run_node(tmp_path, r"""
  const backs = IN.backs.map(b => page3Href(b, { error: "x", waits_for: "y" }));
  const answers = IN.answers.map(a => page3Href("", a));
  const without = waitsHtml("The result of '<b>x</b>' & \"more\" waits.", null);
  const hostile = waitsHtml("s", page3Href("/#/p/12/errors/errors%2Fnvme_command%2Fcmd_timeout", null));
  console.log("RESULT " + JSON.stringify({ backs, answers, without, hostile }));
""", {"backs": ["/#/p/7/errors", "/#/p/7", "/#/p/123456789012/errors/x", "/", "", None, "/#/p/abc/errors", "//evil.example/#/p/7/errors", "javascript:alert(1)//#/p/7/",
                "https://evil.example/#/p/7/errors", "/#/p/7x/errors", "/#/p/1234567890123/errors", "/#/run/7", " /#/p/7/errors", "/#/p/-7/errors"],
      "answers": [{"project": 5}, {"project": "5"}, {"project": 5.5}, {"project": 0}, {"project": -1}, {"project": "5/../x"}, {"project": None}, {}, None]})
    assert out["backs"] == ["/#/p/7/rules", "/#/p/7/rules", "/#/p/123456789012/rules"] + [None] * 12
    assert out["answers"] == ["/#/p/5/rules"] + [None] * 8
    assert "The result of '&lt;b&gt;x&lt;/b&gt;' &amp; &quot;more&quot; waits." in out["without"] and "<b>x</b>" not in out["without"]
    assert 'Open the analysis from <a href="/">the list of your analyses</a> and go to its page 3' in out["without"] and "waits-link" not in out["without"]
    assert 'href="/#/p/12/rules"' in out["hostile"]


def test_a_later_refusal_shows_its_sentence_where_the_result_would_have_appeared(tmp_path):
    out = run_node(tmp_path, r"""
  const got = [];
  for (const n of IN.cases) {
    NEXT = n; els["iso-out"].innerHTML = "the isolation shown before"; els["iso-status"].textContent = ""; els["iso-status"].className = "";
    let err = null;
    try { await api("POST", "/api/isolate/up-join/3/isolate?job=1", { n: 15 }); } catch (e) { err = e; }
    if (err) refusedHere(err, "iso-status", "iso-out");
    got.push({ threw: !!err, waits: err ? err.waits : null, status: err ? err.status : null, message: err ? err.message : null, line: els["iso-status"].textContent,
               cls: els["iso-status"].className, box: els["iso-out"].innerHTML });
  }
  refusedHere(Object.assign(new Error("x"), { waits: true }), null, "no-such-box");      // a part that is not on the page: nothing fails
  console.log("RESULT " + JSON.stringify({ got, asked }));
""", {"cases": [{"code": 409, "body": {"error": "The result of 'a <b>' waits.", "waits_for": WAITS_FOR}},
                {"code": 409, "body": {"error": "a search for this error is already running: wait for it or stop it first"}},
                {"code": 400, "body": {"error": "choose the bench", "waits_for": WAITS_FOR}},
                {"code": 409, "body": {"waits_for": WAITS_FOR}}, {"code": 409, "body": {"error": ["x"], "waits_for": True}}, {"code": 500},
                {"code": 200, "body": {"job": "abc"}}]})
    g = out["got"]
    assert g[0]["waits"] is True and g[0]["line"] == "The result of 'a <b>' waits." and g[0]["cls"] == "status bad"
    assert g[0]["box"] == '<p class="status bad waits" style="margin:8px 0;font-size:14px"><b>Not yet.</b> The result of \'a &lt;b&gt;\' waits.</p>'
    # another refusal with the same code (a search already running), or the mark on another code, is not the flow's refusal: what was shown stays
    for k in (1, 2, 3, 4, 5):
        assert g[k]["threw"] and g[k]["waits"] is False and g[k]["box"] == "the isolation shown before" and g[k]["cls"] == "status bad", g[k]
    assert g[1]["line"] == "a search for this error is already running: wait for it or stop it first" and g[5]["line"] == "refused"
    assert g[6] == {"threw": False, "waits": None, "status": None, "message": None, "line": "", "cls": "", "box": "the isolation shown before"}
    js = _read(SCRIPT)
    for call in ('refusedHere(e, "iso-status", "iso-out")', 'refusedHere(e, "name-status", "name-trace")', 'refusedHere(e, "cause-status", "cause-trace")',
                 'refusedHere(e, "store-status", "sol-prog")', 'refusedHere(e, "test-status", "expect-out")', 'refusedHere(e, "write-status", "file-out")',
                 'refusedHere(e, "search-status", "search-result")', "if (e.waits) return waitLine(e.message);", '<td colspan="7">${waitLine(e.message)}</td>',
                 'catch (e) { box.innerHTML = ""; throw e; }'):
        assert call in js, call
    # the cause's request names the error, so the server can check the order of the flow there too
    assert '"/api/dg/causes", { defect_id: S.defect, keyword: kw, admin: name(), upload_id: UID, finding_id: FID }' in js


def test_the_page_shows_the_admins_rule_in_words_and_where_the_name_comes_from(tmp_path, world):
    world.flow.none()
    own = world.c.get("/api/isolate/%s/%d" % (UID, world.o_fid)).get_json()["finding"]
    builtin = world.c.get("/api/isolate/%s/%d" % (UID, world.t_fid)).get_json()["finding"]
    older = dict(own, rule_words="NVMe commands level: errors.nvme command.aborted commands.v1")     # what the Python before the restart still answers
    older.pop("admin_rule")
    out = run_node(tmp_path, r"""
  const one = f => ({ words: ruleWords(f), short: ruleShort(f, "cmd.timeout"), from: nameFrom(f) });
  console.log("RESULT " + JSON.stringify({ own: one(IN.own), builtin: one(IN.builtin), older: one(IN.older), nothing: [one(null), one({}), one({ detail: null }), one({ detail: { admin_rule: null } })] }));
""", {"own": own, "builtin": builtin, "older": older})
    assert out["own"] == {"words": OWN_WORDS, "short": "your own rule \u201caborted commands\u201d", "from": KIND_FROM}
    assert out["builtin"] == {"words": builtin["rule_words"], "short": "the detector's rule \u201can NVMe command timed out\u201d", "from": ""}     # in words, never the key (2026-11-15)
    assert out["older"] == {"words": OWN_WORDS, "short": "your own rule \u201caborted commands\u201d", "from": ""}     # the words kept with the finding win over the key
    assert out["nothing"] == [{"words": "", "short": "the detector's rule \u201ctimeout\u201d", "from": ""}] * 4      # no words from the server: the words of the key's own last part
    js = _read(SCRIPT)
    for shown in ('["The pattern (rule)", esc(ruleWords(f))]', '[["Where the defect\'s name comes from", esc(nameFrom(f))]]', "${esc(ruleShort((S.H || {}).finding, sl.rule))}",
                  "${esc(nameFrom((S.H || {}).finding))}", "[j.words || \"recorded\", j.graph_words].filter(Boolean).join(\" \")"):
        assert shown in js, shown
    assert "esc(f.rule_words)" not in js                                             # the raw answer is never shown past ruleWords


def test_the_page_script_is_a_sound_module_with_no_name_twice(tmp_path):
    js = _read(SCRIPT)
    names = [a or b for a, b in re.findall(r"^(?:async\s+)?function\s+([A-Za-z_$][\w$]*)|^(?:const|let|var|class)\s+([A-Za-z_$][\w$]*)", js, flags=re.M)]
    assert sorted({n for n in names if names.count(n) > 1}) == [] and set(PAGE_FUNCTIONS) <= set(names)
    imported = re.search(r"^import \{([^}]*)\} from \"\./api\.js\";", js, re.M).group(1)
    assert {x.strip() for x in imported.split(",")} == {"$", "esc"}                    # api is the page's own now: importing it too would be a second name
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    copy_ = str(tmp_path / "isolate_copy.mjs")
    shutil.copy(SCRIPT, copy_)
    done = subprocess.run([NODE, "--check", copy_], capture_output=True, text=True)
    assert done.returncode == 0, done.stderr


# ============================================================================================== 7. the tester's points of 2026-11-15
# A tester looked at the page of one error in a browser and saw: a rule key in the test table, "(unknown_cause)" in parts 3 and 4, "the model
# proposed it" over an empty box, a refusal that linked only the list of analyses, "recording -" on the refused page, a page 264 px too wide in
# a 400 px window, and a test file's name in the search part. The page's own script is run here by node, whole, on a stand-in page, with the
# answers of the real routes of the throw-away application.
SHORT_OWN = "your own rule “late commands”"
NO_CAUSE = "no cause could be named from the evidence"
LEVEL_KEYS = r"\bnvme_(?:command|transaction)\b(?!\.csv)"
KEY_ON_SCREEN = re.compile(r"\badmin\.[a-z0-9_]+\.[a-z0-9_.]+|\b(?:cmd|ntx|spl|lnk|pkt)\.[a-z][a-z0-9_]*|\b(?:%s)\b|%s|tests/\w+\.py|\btest_\w+\.py|\bstand-?in\b"
                           % ("|".join(sorted(TM.CAUSES)), LEVEL_KEYS), re.I)


def _seen(markup):
    """What a reader sees of a piece of the page: its text without the tags (the page escapes < and > in every value it shows)."""
    import html as H
    typed = [v for tag, v in re.findall(r'(<input\b[^>]*?)\bvalue="([^"]*)"', markup or "") if 'type="checkbox"' not in tag and 'type="radio"' not in tag]     # what a field shows
    typed += re.findall(r'\bplaceholder="([^"]*)"', markup or "")
    return " ".join(H.unescape(re.sub(r"<[^>]*>", " ", markup or "") + " " + " ".join(typed)).split())


def _keys(text):
    return sorted(set(m.group(0) for m in KEY_ON_SCREEN.finditer(text or "")))


def _file_one(w, rid, name, row, origin=None):
    """One error filed by a rule of the rules library on one row of nvme_command.csv (once): -> its number in the tree."""
    key = CF.rule_key("errors", "nvme_command", rid, 1)
    con = sqlite3.connect("file:%s?mode=ro" % w.db, uri=True)
    got = con.execute("SELECT id FROM finding WHERE rule=?", (key,)).fetchone()
    con.close()
    if got:
        return got[0]
    res = os.path.join(w.root, "result_%s.csv" % rid)
    with open(res, "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows([[CF.ROW_COLUMN], [str(row)]])
    filed = CF.file_findings(w.db, "errors", "nvme_command", rid, 1, name, res, "t", origin=origin)
    assert filed["rule"] == key and filed["added"] == 1, filed
    con = sqlite3.connect("file:%s?mode=ro" % w.db, uri=True)
    got = con.execute("SELECT id FROM finding WHERE rule=?", (key,)).fetchone()
    con.close()
    return got[0]


@pytest.fixture(scope="module")
def kinds(world):
    """The kinds of error the page is opened for, each on an error of its own (so the other tests' errors stay as they are): an error of the
    detector on the NVMe command level and one on the link level, an error of a rule of the admin's own, and an error of a rule of the
    application's rule set for the NVMe command level (the kind the tester saw: its key ends in cmd_family_..._01.v1)."""
    from agentic import family3
    from nvme_hier import command_error_rules as CE
    fam = CE.FAMILIES[0]
    rid = CE.ITEM_PREFIX + fam["id"]
    origin = family3.rule_origin({"id": rid, "kind": CE.KIND, "plan": {"family": fam["id"]}, "procedure": {"version": 1}}, by_application=True)
    assert origin and origin["is"] == "application" and origin["short"] == "the rule “%s” of %s" % (fam["name"], family3.RULE_SET_WORDS)
    con = sqlite3.connect("file:%s?mode=ro" % world.db, uri=True)
    detector = con.execute("SELECT id FROM finding WHERE level='nvme_command' AND rule='cmd.timeout' AND id != ? ORDER BY id LIMIT 1", (world.t_fid,)).fetchone()[0]
    link = con.execute("SELECT id FROM finding WHERE rule='lnk.response_over_limit' ORDER BY id LIMIT 1").fetchone()[0]
    con.close()
    return types.SimpleNamespace(detector=detector, link=link, own=_file_one(world, "late_commands", "late commands", 146),
                                 family=_file_one(world, rid, fam["name"], 145, origin), family_key=CF.rule_key("errors", "nvme_command", rid, 1),
                                 family_short=origin["short"], family_name=fam["name"])


def _finding(w, fid):
    w.flow.none()
    r = w.c.get("/api/isolate/%s/%d" % (UID, fid))
    assert r.status_code == 200, r.get_json(silent=True)
    return r.get_json()


# ---------------------------------------------------------------------------------------------- item 1, the texts the code builds
def test_the_rule_is_named_in_words_in_every_text_the_code_builds_for_the_three_kinds_of_error(world, kinds, monkeypatch):
    family, own, detector, link = (_finding(world, n)["finding"] for n in (kinds.family, kinds.own, kinds.detector, kinds.link))
    assert family["rule"] == kinds.family_key and family["rule"].startswith("admin.errors.nvme_command.cmd_family_") and family["rule"].endswith(".v1")
    # the short name of the rule, as the header's admin_rule.short gives it; the header's answer carries it for every error
    assert ISO.rule_short(family) == kinds.family_short == family["rule_short"] == family["admin_rule"]["short"]
    assert ISO.rule_short(own) == SHORT_OWN == own["rule_short"]
    assert ISO.rule_short(detector) == "the detector's rule “an NVMe command timed out”" == detector["rule_short"]
    assert ISO.rule_short(link) == "the detector's rule “a link transaction took longer than %s to complete”" % (link.get("limit_ps_text") or "the limit") == link["rule_short"]
    steps = [{"step": 1, "command": "Write"}, {"step": 2, "command": "Read"}, {"step": 3, "command": "Read"}]
    for f in (family, own, detector, link):
        out = ISO.standin_outcomes(f, steps, 2, 2, 30000000, "30 s", "the host's limit for a command")["outcomes"]
        # the exact sentences of the "why" column: who filled the line, the rule in words, the limit with its source
        assert out[0]["basis"] == ("Filled by the code; no model answered. On a correct drive %s finds no error at this step. Time limit: 30 s "
                                   "(the host's limit for a command)." % ISO.rule_short(f))
        assert out[1]["basis"] == ("Filled by the code; no model answered. This command must complete with the NVMe status Successful Completion within the "
                                   "time limit for a command: 30 s (the host's limit for a command).")
        said_too = [str(v) for o in out for v in o.values()] + list(ISO.expected_outcome(f).values())      # the fields of the table: the status, the check
        assert not _keys(" ".join(said_too)), (f["rule"], _keys(" ".join(said_too)))
        iso = ISO.standin_isolation(f, "Drive A", None, 5)
        assert iso["how"] == "%s found this row; how it came about needs the model's reading of the window." % (ISO.rule_short(f)[:1].upper() + ISO.rule_short(f)[1:])
        said = [o["basis"] for o in out] + [v for k, v in iso.items() if isinstance(v, str) and k != "cause_key"] + [ISO.reason_text(f, "Drive A"), ISO.rule_in_words(f)]
        said += list(ISO.standin_summary(f, "Drive A", None, steps, None).values()) + [ISO.standin_chat(f, "Drive A", [], "hello", None, [])["answer"]]
        for text in said:
            assert not _keys(text.replace("Stand-in answer", "")), (f["rule"], text)
    # a rule without an outcome of its own: the check names the rule in words (the sentence it comes from holds the key)
    for f in (family, own, detector, link, {"rule": kinds.family_key}, {"rule": "cmd.made_up"}, {}):
        exp = ISO.expected_outcome(f)
        assert set(exp) == {"status", "description", "check"} and all(exp.values()) and not _keys(" ".join(exp.values())), (f.get("rule"), exp)
    assert ISO.expected_outcome({"rule": "cmd.status_error"})["check"] == "status == (0, 0)"       # a rule with an outcome of its own: as it was
    # the sentence as nvme_hier/chat.py wrote it until today (it held the key): ISO.expected_outcome says the rule in words
    monkeypatch.setattr(ISO.CH, "expected_outcome_default", lambda f: {"status": "no finding at this step", "description": "the rule that fired here stays silent",
                                                                        "check": "the rule %s does not fire" % (f.get("rule") or "")})
    assert ISO.expected_outcome(family)["check"] == "%s finds no error at this step" % kinds.family_short
    assert ISO.expected_outcome(detector)["check"] == "the detector's rule “an NVMe command timed out” finds no error at this step"
    assert ISO.expected_outcome({})["check"] == "the detector's rule for this row finds no error at this step"
    monkeypatch.undo()
    # a key that came without its words: the item's id in words, and never a statement of whose rule it is
    assert ISO.rule_short({"rule": kinds.family_key}) == "the rule “%s” of the rules library" % kinds.family_key.split(".")[3].replace("_", " ")
    for hostile in ({"rule": "admin."}, {"rule": "admin.x.y." + "z" * 5000 + ".v1"}, {"rule": ["cmd.timeout"]}, {"rule": None}, {}, None, "cmd.timeout", {"rule": "cmd.{limit}.{name}"},
                    {"rule": "admin.a.b.c.v1", "detail": "not json"}, {"rule": "admin.a.b.c.v1", "detail": {"admin_rule": {"short": 5, "name": ["x"]}}}, {"rule": "cmd.status_error"}):
        got = ISO.rule_short(hostile)
        assert isinstance(got, str) and 0 < len(got) < 200 and not re.search(r"\badmin\.|\bcmd\.|\{|\}", got), (hostile, got)
    # the words of every rule of the detector, for a key a card still holds (a link event): never a key, never empty
    names = ISO.rule_names()
    assert set(ISO.RULE_WORDS) <= set(names) and "cmd.timeout" in names and names["pkt.recovery"] == "the link went through recovery"
    assert all(w and not _keys(w) and "{" not in w for w in names.values()), names
    assert ISO.rule_in_words({"rule": "cmd.status_error", "level": "nvme_command"}) == "status error: the command completed with an error status (the row holds its status)"
    # the other sentences that held a key: the checks of an isolation, the log line of a round that no model answered
    clean, problems = ISO.check_isolation({"cause_key": "made_up", "cause_side": "nobody"}, {})
    assert clean["cause_key"] == "unknown_cause" and "the cause that was given is not in the dictionary's fixed list of causes: " + NO_CAUSE in problems
    assert "the side of the cause was not one of the list: it is recorded as not decided" in problems and not _keys(" ".join(problems))
    ans = {"verdict": "reason", "reason": "the drive was late"}
    assert ISO.round_text(ans, 2) == "round 2: the model gave its reason: the drive was late"                       # as before when a model answered
    assert ISO.round_text(ans, 2, by_model=False) == "round 2: no model answered; the code gave the reason: the drive was late"
    need = {"verdict": "need_more_evidence", "need": {"more_above": 0, "levels": ["packets"], "commands": [7], "why": ""}}
    assert ISO.round_text(need, 1, by_model=False) == "round 1: no model answered; the code asked for the packets of command 7"
    card = {"command": {"row": 5}, "stages": []}
    prompt = ISO.explain_prompt(family, card, TM.cause_of("unknown_cause"), "none of the fixed rules applies", {k: "x" for k in ("what", "when", "where", "which", "who")}, [])
    assert "THE CAUSE, DECIDED BY THE FIXED RULES (do not change it): %s. The rule that decided it" % NO_CAUSE in prompt and "unknown_cause" not in prompt


# ---------------------------------------------------------------------------------------------- item 2, the names of the causes (the code's side)
def test_every_cause_keyword_has_a_plain_name_and_the_unknown_one_a_sentence():
    for key, (side, name, points) in TM.CAUSES.items():
        assert ISO.cause_words(key) == (NO_CAUSE if key == "unknown_cause" else name) and key not in ISO.cause_words(key)
        assert "_" not in name and len(name.split()) >= 3, (key, name)                # words, not a keyword
    for other in (None, "", "made_up", 5, ["firmware_stall"], {"a": 1}):
        assert ISO.cause_words(other) == NO_CAUSE
    assert ISO.NO_CAUSE_WORDS == NO_CAUSE


# ---------------------------------------------------------------------------------------------- the whole page script on a stand-in page
WHOLE_PAGE = r"""
// a stand-in page for the whole page script: an element exists when the page file has its id or when a part of the page wrote it (id="...")
const IN = JSON.parse(require("fs").readFileSync(process.argv[2], "utf8"));
const made = {}, every = [];
function fake(label) {
  const e = { label, hidden: false, className: "", innerHTML: "", textContent: "", value: "", disabled: false, open: false, style: {}, dataset: {}, files: [], added: [], kids: {},
    querySelector(sel) { return this.kids[sel] || (this.kids[sel] = fake(label + " " + sel)); }, querySelectorAll() { return []; }, closest() { return null; },
    insertAdjacentHTML(where, html) { this.added.push(html); }, addEventListener() {}, focus() {}, scrollIntoView() {}, classList: { toggle() {}, contains() { return false; } } };
  every.push(e); return e;
}
const onPage = id => IN.ids.includes(id) || every.some(e => (e.innerHTML + e.added.join("")).includes(`id="${id}"`));
const document = { title: "One error", getElementById: id => (onPage(id) ? (made[id] || (made[id] = fake(id))) : null), querySelectorAll: () => [], querySelector: () => null, addEventListener() {} };
const window = { addEventListener() {} }, location = { search: IN.query };
const $ = id => document.getElementById(id);
const setTimeout = f => setImmediate(f);
const asked = [], jobs = {};
let ANSWER = () => [404, { error: "the stand-in page has no answer" }];
async function fetch(url, opt) {
  const method = (opt && opt.method) || "GET"; asked.push(method + " " + url);
  const reply = (code, body) => ({ ok: code < 400, status: code, statusText: "refused", json: async () => { if (body === undefined) throw new Error("no JSON"); return body; } });
  const job = /\/api\/isolate\/jobs\/(\w+)/.exec(url);
  if (job) return reply(200, { state: "done", pct: 100, seconds: 1, text: IN.progress || "", log: (IN.log || []).map(text => ({ s: 1, pct: 50, text })), result: jobs[job[1]] });
  const [code, body] = ANSWER(method, url.replace(/\?.*$/, ""), opt && opt.body ? JSON.parse(opt.body) : null);
  if (/[?&]job=1/.test(url) && code < 400) { const id = "j" + Object.keys(jobs).length; jobs[id] = body; return reply(200, { job: id }); }
  return reply(code, body);
}
// the answers of the routes, in the order the page asks: [method, the address without its question part, the answers one after the other]
const routes = () => { const left = (IN.routes || []).map(r => [r[0], r[1], r[2].slice()]);
  ANSWER = (method, path) => { const r = left.find(x => x[0] === method && x[1] === path); if (!r) return [404, { error: "the stand-in page has no answer for " + method + " " + path }]; return [200, r[2].length > 1 ? r[2].shift() : r[2][0]]; }; };
const shown = () => every.map(e => ({ label: e.label, html: e.innerHTML + e.added.join(""), text: e.textContent, hidden: e.hidden })).filter(x => x.html || x.text);
"""


def run_page(tmp_path, scenario, given):
    """The page's whole script (without its import line and its start-up lines) run by node on the stand-in page; -> what the scenario printed."""
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    text = _read(SCRIPT)
    assert text.count('import { $, esc } from "./api.js";') == 1 and text.count("// ------------------------------------------------------------------ wiring") == 1
    text = text.replace('import { $, esc } from "./api.js";', "")
    text = text[:text.index("// ------------------------------------------------------------------ wiring")]
    esc = re.search(r"^export (const esc = .*)$", _read(os.path.join(APP, "app", "static", "js", "api.js")), re.M).group(1)
    d = tmp_path / "whole"
    os.makedirs(str(d), exist_ok=True)
    given = dict(given, ids=sorted(set(re.findall(r'\bid="([\w-]+)"', _read(PAGE)))))
    given.setdefault("query", "?upload=%s&finding=1" % UID)
    (d / "in.json").write_text(json.dumps(given), encoding="utf-8")
    (d / "run.cjs").write_text(WHOLE_PAGE + esc + "\n" + text + "\n(async () => {\n" + scenario + "\n})().catch(e => { console.log('FAILED ' + e.stack); });\n", encoding="utf-8")
    p = subprocess.run([NODE, str(d / "run.cjs"), str(d / "in.json")], capture_output=True, text=True, encoding="utf-8", timeout=120)
    line = next((ln for ln in p.stdout.splitlines() if ln.startswith("RESULT ")), None)
    assert line, (p.stdout[-3000:], p.stderr[-3000:])
    return json.loads(line[7:])


SEARCH_SENTENCE = ("(how often the search found a hidden trigger with this many runs; the measurement is recorded in the change record docs/CHANGES_2026-11-15.md, "
                   "section 5)")


def _stand_in_search(seq):
    """A finished search, as the search route stores it (written by hand: the search itself is tested in tests/test_replay_search.py)."""
    part = {"reproduced": 9, "runs": 10, "lower_bound": 0.606, "queue_depth": 1, "changes": ["the gap before step 2 was halved (from 10 to 5 microseconds)"],
            "steps": [{"step": k + 1, "position": x.get("position"), "command": x.get("command"), "source_row": x.get("source_row") or 1, "gap_us": 5, "why": ["kept by the search"]}
                      for k, x in enumerate(seq[:4])]}
    return {"bench": {"simulated": True}, "simulated_drive": {"note": "This ran on a simulated drive with a hidden trigger, not on a real one.", "hidden_trigger_words": ["a Write follows a Read"]},
            "at": 1794700000, "by": "Asha", "failure": "the command never completes", "label": "simulated drive", "verdict": "found",
            "budget": {"search": 120, "confirm": 30, "smaller": 20, "asked": 200, "stress": 12, "stress_allowance": 90, "used": 182}, "seed": {"reproduced": 0, "runs": 2}, "best": part,
            "stress": {"conditions": [{"words": "the gap before step 2 down to 1 microsecond"}], "need": "a step is kept when the failure comes back in at least 2 of 3 runs",
                       "steps": [{"value": "gap before step 2", "from": 5, "to": 2, "unit": "microseconds", "reproduced": 3, "runs": 3, "kept": True}]},
            "most_stressful": dict(part, reproduced=3, runs=3), "recorded_time_us": 182996, "order_rule": "admin commands and Flush never move",
            "candidates": [{"no": 1, "phase": "search", "how": "one gap halved", "rows": [1, 2], "gaps_us": [10, 5], "queue_depth": 1, "reproduced": 1, "runs": 2, "mean_time_us": 180000}]}


def _walk(w, fid):
    """Every answer the page asks for while an admin goes from part 1 to part 7 with no model connected, taken from the real routes of the
    throw-away application in the page's own order; -> the routes for the stand-in page, and what they answered."""
    w.flow.none()
    c, base = w.c, "/api/isolate/%s/%d" % (UID, fid)

    def ok(r):
        assert r.status_code == 200, (r.status_code, r.get_json(silent=True))
        return r.get_json()
    head = ok(c.get(base))
    window = ok(c.get(base + "/window?n=15&m=15&levels="))
    isolated = ok(c.post(base + "/isolate?standin=1", json={"n": 15, "m": 15, "levels": ["nvme_transaction", "split", "link", "packets"], "history": True, "anyway": True,
                                                              "isolation": True, "rewrite": False, "name": "Asha", "standin": True}))
    i = isolated["isolation"]
    t = i["term"]
    record = dict({k: i.get(k) for k in ("what", "why", "when", "where", "who", "which", "how", "cause_key", "cause_header", "cited_rows")}, term=t["key"])
    did = ok(c.post("/api/dg/defects", json={"name": t["name"], "term_key": t["key"], "rule": i["rule"], "level": i["level"], "what": i["what"], "admin": "Asha"}))["id"]
    kept = {"upload_id": UID, "finding_id": fid, "device": i["device"], "firmware": i["firmware"], "isolation": record, "admin": "Asha", "n": 15, "m": 15, "queue": "all"}
    occ1 = ok(c.post("/api/dg/occurrences", json=dict(kept, defect_id=did, cause_id=None)))
    view1 = ok(c.get("/api/dg/defects/%d" % did))
    terms = ok(c.get("/api/dg/terms"))
    cid = ok(c.post("/api/dg/causes", json={"defect_id": did, "keyword": i["cause_key"], "admin": "Asha", "upload_id": UID, "finding_id": fid}))["id"]
    occ2 = ok(c.post("/api/dg/occurrences", json=dict(kept, defect_id=did, cause_id=cid)))
    view2 = ok(c.get("/api/dg/defects/%d" % did))
    cause = next(x for x in view2["causes"] if x["id"] == cid)
    proposal = ok(c.post("/api/dg/optimized", json={"upload_id": UID, "finding_id": fid, "isolation": record, "cause": {"side": cause["side"], "header": cause["header"]},
                                                    "error_seq": isolated["sequence"], "standin": True}))
    stored = ok(c.post("/api/dg/solutions", json={"cause_id": cid, "error_seq": isolated["sequence"], "optimized": ["Wait 10 microseconds before the next command"], "admin": "Asha",
                                                  "upload_id": UID, "finding_id": fid, "n": 15, "m": 15, "queue": "all"}))
    view3 = ok(c.get("/api/dg/defects/%d" % did))
    search = ok(c.get(base + "/search"))
    search["result"] = _stand_in_search(isolated["sequence"])
    expected = ok(c.post(base + "/testcase?standin=1", json={"sequence": isolated["sequence"], "expected_after": 3, "name": "Asha", "standin": True}))
    test = {"name": "%s_f%d_v1.py" % (UID, fid), "version": 1, "defect": t["name"], "finding": fid, "recording": {"upload": UID},
            "approval": {"can_hand_over": True, "approved_by": "Asha", "approved_at": "2026-11-15 02:24:48 UTC", "state": "approved"},
            "run_history": {"only_simulated_drive": True, "words": "Only ever run on a simulated drive."}}
    results = {"tests": [{"results": [{"test": test["name"], "case_name": "the replay", "outcome": "failed", "expect": "fault", "reason": "the recorded fault did not appear", "drive_kind": "real",
                                       "drive_model": "Model X", "run_at": "2026-11-15T09:00:00", "brought_in_at": "2026-11-15 09:10 UTC", "brought_in_by": "Asha", "package_id": "7"}]}]}
    routes = [["GET", base, [head]], ["GET", base + "/window", [window]], ["POST", base + "/isolate", [isolated]], ["POST", "/api/dg/defects", [{"id": did}]],
              ["POST", "/api/dg/occurrences", [occ1, occ2]], ["GET", "/api/dg/defects/%d" % did, [view1, view2, view3]], ["GET", "/api/dg/terms", [terms]],
              ["POST", "/api/dg/causes", [{"id": cid}]], ["POST", "/api/dg/optimized", [proposal]], ["POST", "/api/dg/solutions", [stored]], ["GET", base + "/search", [search]],
              ["POST", base + "/testcase", [expected]], ["GET", "/api/handover/tests", [{"tests": [test]}]], ["GET", "/api/handover/results", [results]]]
    return {"routes": routes, "query": "?upload=%s&finding=%d&standin=1" % (UID, fid), "head": head, "isolated": isolated, "expected": expected, "proposal": proposal, "search": search,
            "progress": "the cause is decided by the fixed rules (%s); the model explains why and how" % i["cause_key"],
            "log": ["the cause is decided by the fixed rules (%s); the model explains why and how" % i["cause_key"], "round 1: the model reads 40 rows of evidence, the error last"]}


THE_WALK = r"""
  routes();
  $("name").value = "Asha"; $("n-above").value = "15"; $("m-below").value = "15";
  await loadError(); await showHandover(); await showWindow();
  await isolate(false);
  await nameDefect();
  const part4 = $("graph-out").innerHTML;
  await useCause((S.iso.isolation.cause || {}).key || S.iso.isolation.cause_key);
  const form = $("sol-out").innerHTML + $("sol-out").added.join("");
  $("opt-new").value = "Wait 10 microseconds before the next command";
  await $("btn-store").onclick();
  await showSearch();
  await proposeExpected();
  console.log("RESULT " + JSON.stringify({ shown: shown(), asked, part3: $("iso-out").innerHTML, part4, form, test: $("expect-out").innerHTML, search: $("search-out").innerHTML + " " + $("search-result").innerHTML,
    handover: $("handover-out").innerHTML + " " + $("ho-results").innerHTML, more: $("error-more").innerHTML, error: $("error-kv").innerHTML, title: $("page-title").textContent,
    badges: [$("upload-badge").textContent, $("foot-upload").hidden, $("model-badge").textContent, $("foot-model").hidden], status: ["iso-status", "cause-status", "name-status", "test-status", "store-status"].map(id => ($(id) || {}).textContent) }));
"""


@pytest.fixture(scope="module")
def walks(world, kinds, tmp_path_factory):
    """The page walked once for each kind of error: what the routes answered and everything the page showed."""
    out = {}
    for kind in ("family", "own", "detector", "link"):
        given = _walk(world, getattr(kinds, kind))
        page = run_page(tmp_path_factory.mktemp("walk_" + kind), THE_WALK, given)
        out[kind] = types.SimpleNamespace(given=given, page=page, seen=" ".join(_seen(x["html"]) + " " + x["text"] for x in page["shown"]))
    return out


def test_no_key_reaches_the_screen_for_the_three_kinds_of_error(walks, kinds):
    for kind, w in walks.items():
        # the page went through its parts: the requests it made, in its own order
        asked = " ".join(w.page["asked"])
        for part in ("/window?", "/isolate?standin=1&job=1", "POST /api/dg/defects", "POST /api/dg/causes", "POST /api/dg/optimized?job=1", "POST /api/dg/solutions", "/search", "/testcase?standin=1&job=1"):
            assert part in asked, (kind, part, w.page["asked"])
        assert len(w.seen) > 3000 and "a correct drive answers" in w.seen and "The evidence card" in w.seen or kind == "link", kind
        where = [(x["label"], _keys(_seen(x["html"]) + " " + x["text"])) for x in w.page["shown"] if _keys((_seen(x["html"]) + " " + x["text"]).replace("Stand-in answer", ""))]
        assert where == [], (kind, where)                        # which part of the page shows which key
        assert "undefined" not in w.seen and "[object Object]" not in w.seen and "NaN" not in w.seen, kind
    # the "why" column of the test table (the tester's line): the rule's short name, in the server's sentence, shown as it is
    rows = [o for o in walks["family"].given["expected"]["expected_outcomes"] if o["step"] == walks["family"].given["expected"]["fault_step"]]
    assert rows and rows[0]["basis"].startswith("Filled by the code; no model answered. On a correct drive %s finds no error at this step. Time limit: " % kinds.family_short)
    assert _seen(rows[0]["basis"]) in _seen(walks["family"].page["test"]) and kinds.family_key not in walks["family"].page["test"]
    assert "On a correct drive %s finds no error at this step." % SHORT_OWN in _seen(walks["own"].page["test"])
    assert "On a correct drive the detector's rule “an NVMe command timed out” finds no error at this step." in _seen(walks["detector"].page["test"])
    # part 3 names the rule by the same short words; "More about this error" says how errors of the same kind are recognised, in words
    assert "never typed: %s, the command" % kinds.family_short in _seen(walks["family"].page["part3"])
    assert "never typed: the detector's rule “an NVMe command timed out”, the command" in _seen(walks["detector"].page["part3"])
    more = _seen(walks["family"].page["more"])
    assert "Errors of the same kind are recognised by: found by %s; at the NVMe command level; on the command " % kinds.family_short in more
    assert more.endswith("Times, measured values and row numbers are not part of it.") and "|" not in more and "Key of this kind" not in more
    assert walks["family"].given["head"]["finding"]["signature"]["display"] not in walks["family"].page["more"]          # the stored key itself stays off the screen
    # the recording is named by the name it was given, not by its internal number
    assert walks["family"].page["badges"] == ["S17 sample", False, "no model (the code's own answers)", False]


def test_a_sentence_written_before_today_is_shown_without_its_keys(tmp_path, kinds):
    """What an application that was not restarted yet still answers, a kept isolation, a model's own words: the page says every key in words."""
    out = run_page(tmp_path, r"""
  S.H = IN.head; S.causes = IN.causes;
  const texts = IN.texts.map(plain);
  S.H = { finding: { rule: IN.key } };          // no words from the server at all
  const bare = IN.texts.map(plain);
  const card = cardHtml({ command: { row: 5 }, stages: [], link_events: [{ rule: "pkt.recovery" }, { rule: "pkt.recovery" }, { rule: "pkt.made_up_event" }, { rule: null }], packets: 3, nak: 0, unacked: 0 });
  const params = [paramWords({ nsid: 1, slba: 2106616, nlb: 7, fua: 0 }), paramWords({ nsid: 0 }), paramWords({ nlb: 0, fua: 1, nbytes: 4096 }), paramWords({ queue_size: 64, x: null }), paramWords(null), paramWords({ nlb: "x" })];
  console.log("RESULT " + JSON.stringify({ texts, bare, card, params, seq: seqTable([{ step: 1, command: "Write", parameters: { nsid: 1, slba: 8, nlb: 7, fua: 0 }, position: "fault", gap_us: 10 }]) }));
""", {"head": {"finding": {"rule": kinds.family_key, "rule_short": kinds.family_short}, "rule_names": ISO.rule_names()}, "key": kinds.family_key,
      "causes": TM.cause_choices(),
      "texts": ["stand-in: the rule that fired (%s) must stay silent; limit 30 s (the host's limit)" % kinds.family_key,
                "the cause is decided by the fixed rules (unknown_cause); the model explains why and how",
                "a link event happened while the command was outstanding (pkt.link_down, pkt.recovery)",
                "the model wrote: cmd.timeout fired, the cause is firmware_stall", "row 5 of nvme_command.csv and NVME_Transactions.csv, 3.5 ms", ""]})
    assert out["texts"] == ["stand-in: the rule that fired (%s) must stay silent; limit 30 s (the host's limit)" % kinds.family_short,
                            "the cause is decided by the fixed rules (%s); the model explains why and how" % NO_CAUSE,
                            "a link event happened while the command was outstanding (the detector's rule “the link went down”, the detector's rule “the link went through recovery”)",
                            "the model wrote: the detector's rule “an NVMe command timed out” fired, the cause is “the drive's firmware stopped making progress”",
                            "row 5 of nvme_command.csv and NVME_Transactions.csv, 3.5 ms", ""]
    words = kinds.family_key.split(".")[3].replace("_", " ")
    assert out["bare"][0] == "stand-in: the rule that fired (the rule “%s” of the rules library) must stay silent; limit 30 s (the host's limit)" % words
    assert out["bare"][2].endswith("(the detector's rule “link down”, the detector's rule “recovery”)") and all(not _keys(t.replace("stand-in", "")) for t in out["bare"] + out["texts"])
    # the evidence card's link events and a command's parameters in words
    assert "link events: recovery, made up event, an event without a name" in _seen(out["card"]) and "pkt." not in out["card"]
    assert out["params"] == ["namespace 1, first block 2106616, 8 blocks", "namespace 0", "1 block, 4,096 bytes, written to the drive's storage before it is answered (Force Unit Access)",
                             "queue size 64", "", ""]
    assert "namespace 1, first block 8, 8 blocks" in _seen(out["seq"]) and not re.search(r"\b(nsid|slba|nlb|fua)\b", out["seq"])


# ---------------------------------------------------------------------------------------------- item 2, on the page
def test_parts_3_and_4_name_the_cause_in_words_and_never_show_its_keyword(tmp_path, walks):
    for kind, w in walks.items():
        i = w.given["isolated"]["isolation"]
        said = NO_CAUSE if i["cause_key"] == "unknown_cause" else TM.CAUSES[i["cause_key"]][1]
        part3, part4 = _seen(w.page["part3"]), _seen(w.page["part4"])
        assert "How the cause was decided: %s, because " % said in part3, (kind, part3[:600])
        assert "The fixed rules decided: %s" % said in part4, (kind, part4)
        for key in TM.CAUSES:
            assert key not in part3 and "(%s" % key not in part4 and "%s," % key not in part4, (kind, key)
        assert ("Continue without a named cause" in part4) == (i["cause_key"] == "unknown_cause") and ("Use this cause" in part4) == (i["cause_key"] != "unknown_cause")
        assert w.page["status"][1] == "this error is kept under that cause (one count for it, with this drive)"      # the button still sends the keyword
    # every keyword of the dictionary, the unknown one, one that is in no dictionary, and none at all
    out = run_page(tmp_path, r"""
  const named = IN.causes.map(c => causeName(c, c.key)), byKey = IN.causes.map(c => causeName(null, c.key));
  S.causes = IN.causes;
  const known = IN.causes.map(c => causeName(null, c.key));
  // part 4 for an error whose cause the rules did decide
  S.iso = { isolation: { cause: IN.causes[0], cause_key: IN.causes[0].key, cause_header: "the rows say so" } }; S.defect = 1;
  ANSWER = (m, path) => [200, path === "/api/dg/terms" ? { causes: IN.causes } : { name: "D", causes: [{ id: 1, key: "kw:" + IN.causes[0].key, header: "h", side_words: "s", chosen_words: "c", solutions: [] }], seen: 1, devices: [] }];
  await showGraph();
  console.log("RESULT " + JSON.stringify({ named, byKey, known, odd: [causeName(null, ""), causeName({}, undefined), causeName({ key: "gone_cause" }, "gone_cause"), causeName(null, "unknown_cause"), causeName({ key: "unknown_cause", name: "x" })],
    part4: $("graph-out").innerHTML }));
""", {"causes": TM.cause_choices()})
    names = [NO_CAUSE if c["key"] == "unknown_cause" else c["name"] for c in TM.cause_choices()]
    assert out["named"] == names and out["known"] == names
    assert out["byKey"] == [NO_CAUSE if c["key"] == "unknown_cause" else "a cause that is not in the dictionary any more" for c in TM.cause_choices()]      # before the list is read
    assert out["odd"] == [NO_CAUSE, NO_CAUSE, "a cause that is not in the dictionary any more", NO_CAUSE, NO_CAUSE]
    first = TM.cause_choices()[0]
    part4 = _seen(out["part4"])
    assert "The fixed rules decided: %s (%s; already stored for this defect) Because the rows say so. Use this cause" % (first["name"], first["side_words"]) in part4
    assert "(%s" % first["key"] not in part4


# ---------------------------------------------------------------------------------------------- item 3, the solution form
FORM = r"""
  S.iso = { isolation: { what: "w", cause_key: "firmware_stall" }, sequence: IN.seq }; S.defect = 1; S.cause = 1; S.shownWindow = { n: 15, m: 15 };
  $("name").value = "Asha";
  const got = [];
  for (const c of IN.cases) {
    asked.length = 0; $("sol-out").innerHTML = '<p class="locked">This opens after you name the cause in part 4.</p>'; $("sol-out").added = [];
    let sent = null;
    ANSWER = (m, path, body) => path === "/api/dg/optimized" ? [c.code, c.answer] : path === "/api/dg/solutions" ? (sent = body, [500, { error: "kept for the test" }])
      : [200, { name: "D", causes: [{ id: 1, header: "the drive's firmware stopped making progress", side: "device", side_words: "the device", solutions: [] }] }];
    await showSolutions();
    const html = $("sol-out").innerHTML + $("sol-out").added.join("");
    const box = (/<textarea class="seqbox" id="opt-new">([^<]*)<\/textarea>/.exec(html) || [])[1];
    $("opt-new").value = c.typed === undefined ? (box || "").replace(/&quot;/g, '"') : c.typed;
    await $("btn-store").onclick();
    got.push({ html, box, asked: asked.slice(), producer: sent ? (sent.producer === undefined ? null : sent.producer) : "nothing was sent", optimized: sent && sent.optimized });
  }
  console.log("RESULT " + JSON.stringify(got));
"""


def test_the_solution_form_says_a_model_proposed_only_when_its_lines_are_in_the_box(tmp_path, walks):
    stand_in = walks["family"].given["proposal"]              # the real route's answer with no model connected
    assert stand_in["standin"] is True and stand_in["lines"] == []
    lines = ["Raise the host's limit for a Write to 60 seconds (to be measured)", "Send the Write again"]
    model = {"lines": lines, "note": "It gives the drive time to finish.", "producer": "model-x", "standin": False}
    cases = [{"code": 200, "answer": model}, {"code": 200, "answer": model, "typed": lines[0] + "\n  \nSend it twice"}, {"code": 200, "answer": stand_in, "typed": "Wait 1 second"},
             {"code": 200, "answer": {"lines": [], "note": "", "producer": "model-x", "standin": False}, "typed": "Wait 1 second"},
             {"code": 200, "answer": {"lines": ["  ", ""], "note": "n", "producer": "model-x", "standin": False}, "typed": "Wait 1 second"},
             {"code": 500, "answer": {"error": "the model's service did not answer"}, "typed": "Wait 1 second"}, {"code": 200, "answer": stand_in, "typed": "   "}]
    out = run_page(tmp_path, FORM, {"cases": cases, "seq": STEPS})
    proposed = "one action per line; the model proposed the lines in the box: edit them before you store them"
    none = "one action per line; no model answered, so no proposal was made: write it yourself"
    empty = "one action per line; the model answered without a proposal: write it yourself"
    failed = "one action per line; no proposal could be made (the model's service did not answer): write it yourself"
    for k, want in enumerate([proposed, proposed, none, empty, empty, failed, none]):
        seen = _seen(out[k]["html"])
        assert want in seen and sum(x in seen for x in (proposed, none, empty, failed)) == 1, (k, seen[-700:])
        assert "the model proposed it" not in seen
        # the request for a proposal is really sent (until today it failed inside the page: its progress box was not on the page yet)
        assert out[k]["asked"][:2] == ["GET /api/dg/defects/1", "POST /api/dg/optimized?job=1"], out[k]["asked"]
        assert out[k]["html"].index('id="sol-prog"') < out[k]["html"].index('id="opt-new"')
    # a model's lines are in the box, with its note; without a proposal the box is empty and no note of a model is shown
    assert out[0]["box"] == "\n".join(lines).replace('"', "&quot;") and "It gives the drive time to finish." in out[0]["html"]
    for k in (2, 3, 4, 5, 6):
        assert out[k]["box"] == "" and "It gives the drive" not in out[k]["html"], k
    # what is stored says who wrote the solution: the model's lines unchanged, the model's lines edited, or the admin alone (no producer sent: the server records the admin)
    assert [o["producer"] for o in out] == ["model, stored unchanged by Asha", "model, edited by Asha", None, None, None, None, "nothing was sent"]
    assert out[0]["optimized"] == lines and out[1]["optimized"] == [lines[0], "Send it twice"] and out[2]["optimized"] == ["Wait 1 second"]
    # the walk with no model connected: the real route's answer gives the stand-in sentence, and the form never says a model proposed
    for kind, w in walks.items():
        assert none in _seen(w.page["form"]) and "the model proposed" not in w.seen, kind
    js = _read(SCRIPT)
    assert "the model proposed it: edit it before you store it" not in js and "producer: `model, edited by ${name()}`, upload_id" not in js


# ---------------------------------------------------------------------------------------------- item 4a, the refusal names the analysis that waits
def test_the_refusal_carries_the_number_of_the_analysis_that_waits(tmp_path, world, monkeypatch):
    base = "/api/isolate/%s/%d" % (UID, world.t_fid)
    pid = world.flow.set({TIMEOUT: "needs_review"})
    try:
        j = world.c.get(base).get_json()
        assert j == {"error": WAITS % "NVMe command timed out", "waits_for": WAITS_FOR, "project": pid} and isinstance(j["project"], int)
        # every route of the page answers with the same number
        for r in (world.c.get(base + "/window?n=1&m=1&levels="), world.c.post(base + "/isolate", json={"n": 1, "m": 1}), world.c.post(base + "/search", json={})):
            assert r.status_code == 409 and r.get_json()["project"] == pid
        # an analysis of the recording that does not hold the pattern is not the one that waits
        other = world.flow.also({OWN: "needs_review"}, "an analysis without the pattern")
        assert other != pid and world.c.get(base).get_json()["project"] == pid
        # the page: without "back=" in the address the link goes to page 3 of that analysis
        out = run_node(tmp_path, r"""
  NEXT = { code: 409, body: IN.answer };
  let err = null;
  try { await api("GET", "/api/isolate/up-join/3"); } catch (e) { err = e; }
  showWaits(err.answer);
  console.log("RESULT " + JSON.stringify({ box: els["s-waits"].innerHTML }));
""", {"answer": j, "query": "upload=up-join&finding=3"})
        assert '<a class="waits-link" href="/#/p/%d/rules"><b>Go to page 3 of the analysis</b></a>' % pid in out["box"] and "the list of your analyses" not in out["box"]
        # the number could not be looked up: the refusal stands as it was, without a number (the page then links the list)
        monkeypatch.setattr(CF, "item_of", lambda rule: (_ for _ in ()).throw(RuntimeError("no")))
        from agentic import pipeline
        monkeypatch.setattr(pipeline, "error_page_refusal", lambda *a, **k: "The result waits.")
        r = world.c.get(base)
        assert r.status_code == 409 and r.get_json() == {"error": "The result waits.", "waits_for": WAITS_FOR}
    finally:
        world.flow.none()


def test_with_two_waiting_analyses_the_refusal_says_so_and_the_page_links_the_list(tmp_path, world):
    base = "/api/isolate/%s/%d" % (UID, world.t_fid)
    first = world.flow.set({TIMEOUT: "needs_review"})
    second = world.flow.also({TIMEOUT: "running"}, "second look")
    try:
        j = world.c.get(base).get_json()
        two = ("Two analyses of this recording hold this pattern, and its result is approved in neither: “%s” and “second look”. Approving it in one of "
               "them is enough: open that analysis from the list of your analyses." % ANALYSIS)
        assert first != second and "project" not in j and j["analyses"] == 2 and j["analyses_words"] == two and j["waits_for"] == WAITS_FOR
        assert j["error"] == NOT_YET.replace(ANALYSIS, "second look") % "NVMe command timed out"           # the rule's own sentence, as before
        third = world.flow.also({TIMEOUT: "rejected"}, "third look")
        k = world.c.get(base).get_json()
        assert "project" not in k and k["analyses"] == 3 and third not in (first, second)
        assert k["analyses_words"].startswith("3 analyses of this recording hold this pattern, and its result is approved in none of them: “%s”, “second look”, “third look”." % ANALYSIS)
        out = run_node(tmp_path, r"""
  const boxes = [];
  for (const q of ["upload=up-join&finding=3", "upload=up-join&finding=3&back=/%23/p/9/errors"]) {
    Q = new URLSearchParams(q); NEXT = { code: 409, body: IN.answer };
    let err = null;
    try { await api("GET", "/api/isolate/up-join/3"); } catch (e) { err = e; }
    showWaits(err.answer); boxes.push(els["s-waits"].innerHTML);
  }
  console.log("RESULT " + JSON.stringify({ boxes, hostile: waitsHtml("s", null, "<b>two</b> & more"), none: [waitsHtml("s", null), waitsHtml("s", null, ""), waitsHtml("s", "/#/p/1/rules", undefined)].map(h => h.includes("waits-more")) }));
""", {"answer": j})
        box = out["boxes"][0]
        assert '<p class="waits-more" style="max-width:95ch">%s</p>' % two in box and box.index("waits-why") < box.index("waits-more")
        assert 'Open the analysis from <a href="/">the list of your analyses</a> and go to its page 3' in box and "waits-link" not in box
        # opened from one analysis's errors page: the link goes back to that analysis, and the sentence about the two is still shown
        assert 'href="/#/p/9/rules"' in out["boxes"][1] and "waits-more" in out["boxes"][1]
        assert "&lt;b&gt;two&lt;/b&gt; &amp; more" in out["hostile"] and out["none"] == [False, False, False]
        # approving the result in one of them is enough, as the sentence says
        world.flow.none()
        world.flow.set({TIMEOUT: "approved"})
        world.flow.also({TIMEOUT: "needs_review"}, "second look")
        assert world.c.get(base).status_code == 200
    finally:
        world.flow.none()


# ---------------------------------------------------------------------------------------------- item 4b, the header of a refused page
def test_a_refused_page_shows_no_part_of_the_header_that_has_nothing_to_show(tmp_path):
    html = _read(PAGE)
    foot = re.search(r'<div class="foot">(.*?)</div>', html, re.S).group(1)
    assert foot == ('<span id="foot-upload" hidden>recording <b id="upload-badge"></b><br></span><span id="foot-model" hidden>answers by <b id="model-badge"></b></span>')
    assert ">-<" not in html and '<div class="ctx" id="name-box">' in html             # no placeholder dash anywhere; both parts start hidden
    out = run_node(tmp_path, r"""
  ["foot-upload", "foot-model", "name-box", "upload-badge", "model-badge"].forEach(id => el(id));
  els["foot-upload"].hidden = true; els["foot-model"].hidden = true;       // as the page file has them
  const before = ["foot-upload", "foot-model", "name-box"].map(id => els[id].hidden);
  badge("foot-upload", "upload-badge", "S17 sample"); badge("foot-model", "model-badge", "no model (the code's own answers)");
  const opened = ["foot-upload", "foot-model", "name-box"].map(id => els[id].hidden).concat([els["upload-badge"].textContent, els["model-badge"].textContent]);
  badge("foot-upload", "upload-badge", ""); badge("foot-model", "model-badge", null); badge("no-such-box", "no-such-badge", "x");
  const unnamed = ["foot-upload", "foot-model"].map(id => els[id].hidden);
  badge("foot-upload", "upload-badge", "S17 sample"); badge("foot-model", "model-badge", "m");
  NEXT = { code: 409, body: { error: "The result waits.", waits_for: "x" } };
  let err = null;
  try { await api("GET", "/api/isolate/up-join/3"); } catch (e) { err = e; }
  showWaits(err.answer);
  console.log("RESULT " + JSON.stringify({ before, opened, unnamed, refused: ["foot-upload", "foot-model", "name-box"].map(id => els[id].hidden), box: els["s-waits"].hidden }));
""", {"query": "upload=up-join&finding=3"})
    assert out["before"] == [True, True, False]
    assert out["opened"] == [False, False, False, "S17 sample", "no model (the code's own answers)"]
    assert out["unnamed"] == [True, True]                                            # a recording without a name: the part is not shown, never a dash or an internal number
    assert out["refused"] == [True, True, True] and out["box"] is False
    js = _read(SCRIPT)
    assert 'badge("foot-upload", "upload-badge", H.trace_name || "")' in js and '$("upload-badge").textContent = UID' not in js


# ---------------------------------------------------------------------------------------------- item 5, every table in a scroll box
def _tables_outside_a_scroll_box(markup):
    """The tables of a piece of HTML that are not inside an element whose class makes it scroll sideways (.xscroll, or .treewrap of the commands' tree)."""
    from html.parser import HTMLParser
    VOID = {"br", "input", "img", "hr", "meta", "link", "col", "wbr", "source", "area", "base", "embed", "track", "param"}

    class P(HTMLParser):
        def __init__(self):
            super().__init__(convert_charrefs=True)
            self.open, self.tables, self.outside = [], 0, []

        def handle_starttag(self, tag, attrs):
            cls = (dict(attrs).get("class") or "").split()
            if tag == "table":
                self.tables += 1
                if not any(c for c in self.open if c[1]):
                    self.outside.append(dict(attrs))
            if tag not in VOID:
                self.open.append((tag, "xscroll" in cls or "treewrap" in cls))

        def handle_endtag(self, tag):
            for k in range(len(self.open) - 1, -1, -1):
                if self.open[k][0] == tag:
                    del self.open[k:]
                    break
    p = P()
    p.feed(markup or "")
    return p.tables, p.outside


def test_every_table_of_the_page_is_in_its_own_scroll_box(walks):
    html, js = _read(PAGE), _read(SCRIPT)
    # the page file: its one table (the commands around the error) is in the tree's scroll box; the styles make both kinds of box scroll
    assert _tables_outside_a_scroll_box(html) == (1, [])
    style = re.search(r"<style>(.*?)</style>", html, re.S).group(1)
    assert ".xscroll { overflow-x: auto; max-width: 100%; }" in style and re.search(r"\.treewrap \{[^}]*overflow: auto;", style)
    assert "main { overflow-wrap: break-word; }" in style and "main :not(td) > input, main :not(td) > select, main :not(td) > textarea, main button { max-width: 100%; }" in style
    phone = re.search(r"@media \(max-width: 760px\) \{(.*?)\n\}", style, re.S).group(1)
    assert "main button:not(.small):not(.exp) { height: auto; min-height: 32px; white-space: normal; }" in phone and ".answer .q { grid-template-columns: 1fr; }" in phone
    for wraps in (".row { display: flex; gap: 10px; align-items: flex-end; flex-wrap: wrap; }", ".verdicts { display: flex; gap: 8px; flex-wrap: wrap;"):
        assert wraps in style, wraps
    shared = _read(os.path.join(APP, "app", "static", "app.css"))
    assert re.search(r"\.topbar \{[^}]*flex-wrap: wrap;", shared) and re.search(r"^main \{[^}]*min-width: 0;", shared, re.M)      # the header row wraps; the page column may shrink
    # the script: every table it writes opens inside a scroll box and closes with it
    assert js.count("<table") == js.count('<div class="xscroll"><table class="steps') == js.count("</table></div>") == js.count("</table>") == 9
    # what the page really built for each kind of error: the evidence card, the sequences, the test table, the search result, the hand-over part
    for kind, w in walks.items():
        total = 0
        for x in w.page["shown"]:
            n, outside = _tables_outside_a_scroll_box(x["html"])
            total += n
            assert outside == [], (kind, x["label"], outside)
        assert total >= (9 if kind != "link" else 8), (kind, total)
        for part, least in (("test", 1), ("search", 4), ("handover", 2), ("form", 1)):
            assert _tables_outside_a_scroll_box(w.page[part])[0] >= least, (kind, part)
    assert _tables_outside_a_scroll_box(walks["detector"].page["part3"])[0] >= 2          # the evidence card and what followed the command
    assert _tables_outside_a_scroll_box("<div><table></table></div><div class='xscroll'><p><table class='steps'></table></p></div>") == (2, [{}])     # the check itself sees a bare table


# ---------------------------------------------------------------------------------------------- item 6, the search part names no test file
def test_the_search_part_names_the_change_record_and_no_test_file(tmp_path, walks):
    for kind, w in walks.items():
        seen = _seen(w.page["search"])
        assert "tests/" not in seen and not re.search(r"\btest_\w+\.py\b", seen) and "bench runs: one run replays one candidate sequence once." in seen, (kind, seen[:900])
        why = w.given["search"]["defaults"]["budget_why"]
        if "test_replay_search.py" in why:              # the server's sentence still names the file: the page says where the measurement is recorded instead
            assert "The number is a starting point measured on the simulated drive %s, not a property of any real drive. Allowed: " % SEARCH_SENTENCE in seen, seen[:1500]
        else:
            assert _seen(why) in seen
    assert os.path.isfile(os.path.join(APP, "docs", "CHANGES_2026-11-15.md"))        # the document the sentence names is there to be opened
    record = _read(os.path.join(APP, "docs", "CHANGES_2026-11-15.md"))
    assert "## 5. The search and the most stressful conditions on the page of one error" in record and "hidden triggers" in record
    out = run_page(tmp_path, r"""
  console.log("RESULT " + JSON.stringify(IN.texts.map(t => noTestFile(t, SEARCH_RECORD)).concat([noTestFile("measured (tests/test_x.py) here"), noTestFile(null), SEARCH_RECORD])));
""", {"texts": ["measured on the simulated drive (tests/test_replay_search.py), not a property", "see tests/test_replay_search.py for it", "measured on the simulated drive, not a property",
                "the file up-join_f3_v1.py is yours", ""]})
    assert out == ["measured on the simulated drive %s, not a property" % SEARCH_SENTENCE, "see %s for it" % SEARCH_SENTENCE, "measured on the simulated drive, not a property",
                   "the file up-join_f3_v1.py is yours", "", "measured here", "", SEARCH_SENTENCE]


# ---------------------------------------------------------------------------------------------- the evidence card's new facts (card version 3)
def test_the_evidence_card_says_which_abort_it_means_and_what_was_read_from_the_tree(tmp_path):
    """nvme_hier/evidence.py gives a card: abort_unreadable ({row}: an Abort whose own parameters cannot be read), names (the command an Abort
    names), read_from_tree (sentences), not_timed, cycle_unread. The page says the first three; the model that explains gets all five."""
    out = run_page(tmp_path, r"""
  const base = { command: { row: 5 }, stages: [], packets: 3, nak: 0, unacked: 0 };
  console.log("RESULT " + JSON.stringify(IN.cards.map(c => cardHtml(Object.assign({}, base, c)))));
""", {"cards": [{"abort": {"row": 9, "after_doorbell_ps": 30000000000000}, "abort_unreadable": {"row": 7}},
                {"abort_unreadable": {"row": 7, "after_doorbell_ps": 5, "why": "its parameters <b>"}}, {}, {"abort_unreadable": "yes"},
                {"names": {"queue": 3, "id": 26, "row": 155, "completed": False, "sent_before_ps": 2000000000}, "read_from_tree": ["the steps <of> the command", "the host's limit", 5, " "]},
                {"names": {"unreadable": "the rows under the Abort are not in the tree"}, "read_from_tree": "not a list", "median_ps": 86207000, "host_limit_ps": None},
                {"names": {"queue": 0, "id": 1, "row": None}, "median_ps": 86207000, "host_limit_ps": 30000000000000}]})
    seen = [_seen(h) for h in out]
    named, unread, none = "The host's Abort: row 9, 30.000 s after the doorbell.", "but what it names cannot be read.", "No Abort that names it while it was outstanding."
    assert named in seen[0] and unread not in seen[0] and none not in seen[0]                       # an Abort that names it: as before
    assert "An Abort was sent while it was outstanding (NVMe command row 7), but what it names cannot be read." in seen[1] and none not in seen[1]
    assert none in seen[2] and unread not in seen[2]
    assert "An Abort was sent while it was outstanding, but what it names cannot be read." in seen[3]       # the fact without its row: still never "no Abort"
    assert all("No Abort while it was outstanding" not in s for s in seen) and "No Abort while it was outstanding" not in _read(SCRIPT)
    assert ("This command is itself an Abort. The command it names: queue 3, command identifier 26: NVMe command row 155, sent 2.000 ms before this Abort; "
            "the drive never completed it.") in seen[4]
    assert "Read from the tree for this card, because the error's own record did not hold it: the steps <of> the command; the host's limit." in seen[4]
    assert "the steps &lt;of&gt; the command" in out[4] and "<of>" not in out[4]                    # escaped
    assert "The command it names: cannot be read (the rows under the Abort are not in the tree)." in seen[5] and "Read from the tree" not in seen[5]
    assert "This command type usually takes 86.207 µs here." in seen[5] and "driver limit" not in seen[5]        # a command the host sets no limit for: no empty limit is shown
    assert "queue 0, command identifier 1: no command with that queue and identifier was sent before it." in seen[6]
    assert "This command type usually takes 86.207 µs here; the host's driver limit is 30.000 s." in seen[6]
    for s in seen[:4]:
        assert "itself an Abort" not in s and "Read from the tree" not in s
    # the model that writes why and how is handed the same facts
    facts = {"names": {"queue": 3, "id": 26}, "not_timed": {"name": "Asynchronous Event Request", "why": "it waits by design"}, "cycle_unread": "the steps cannot be read",
             "abort_unreadable": {"row": 7}, "read_from_tree": ["the steps of the command"]}
    card = dict(facts, command={"row": 5}, kept_back="not a fact of the card")
    prompt = ISO.explain_prompt({"rule": "cmd.timeout"}, card, TM.cause_of("firmware_stall"), "the rule's words", {k: "x" for k in ("what", "when", "where", "which", "who")}, [])
    handed = json.loads(next(line for line in prompt.split("\n") if line.startswith('{"rule"')))
    assert {k: handed[k] for k in facts} == facts and "kept_back" not in handed and handed["command"] == {"row": 5}
