"""Shared by every pytest file: what one test file changes in the application's modules is put back for the next.

The tests run in a shuffled order (pytest-randomly), file by file. A test file that builds an application of its own
(`create_app` on a throw-away folder) makes `agentic.procedures` point at that folder's uploads; a file that ran after
it and expected the application's own uploads folder then failed, in some orders only (seen 2026-11-15 in
tests/test_rule_evidence.py after tests/test_other_csv_errors.py, tests/test_defect_graph.py and others).

The fixture below keeps the uploads folder, and the switch that says whether a model is connected (set where an engine
is made), as they were when a test file started and puts them back when the file ends.
It imports nothing: it only looks at modules a test has already loaded.
"""
import os
import sys

import pytest

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OWN_UPLOADS = os.path.join(APP, "uploads")


def _procedures_modules():
    return [m for m in list(sys.modules.values())
            if m is not None and getattr(m, "__name__", "").split(".")[-1] == "procedures"
            and isinstance(getattr(m, "_UPLOADS", None), list) and hasattr(m, "use_uploads_folder")]


@pytest.fixture(scope="module", autouse=True)
def _uploads_folder_put_back():
    before = {id(m): (list(m._UPLOADS), getattr(m, "MODEL_CONNECTED", None)) for m in _procedures_modules()}
    yield
    for m in _procedures_modules():
        uploads, connected = before.get(id(m), ([OWN_UPLOADS], None))
        m._UPLOADS[:] = uploads
        if hasattr(m, "MODEL_CONNECTED"):
            m.MODEL_CONNECTED = connected       # an engine made by a test file says "a model is connected or not" for its own runner only
