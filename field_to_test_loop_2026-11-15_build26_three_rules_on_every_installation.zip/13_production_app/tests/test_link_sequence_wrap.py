"""The link join when a sequence number comes round again (2026-11-14; docs/CHANGES_2026-11-14.md, "4,096 sequence numbers").

A data-link sequence number has 12 bits: the 4,097th TLP of one direction carries the number of the first again. One Ack acknowledges every TLP up to and
including its number, so a TLP need not get an Ack of its own; a Nak acknowledges up to its number and asks for the later ones again. Before, a link
transaction whose own Ack never came stayed open, and a round later the new TLP with its number was counted as a resend of it. Now a TLP that meets an open
link transaction with its number is a NEW link transaction when an Ack or a Nak has covered the open one since it was opened (its number or one of the 2,047
after it, modulo 4,096) and a link row of its own is there for it; otherwise it is the resend it was before.

Every recording here is hand-made: packets.csv and link.csv are written row by row with the export's own header (nvme_hier/columns.py), the three NVMe-side
files are the small ones of tests/test_nvme_hier.py. Everything is written into temporary folders, loaded on one core and built there.
"""
import csv
import os
import shutil
import sqlite3
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from nvme_hier import builder as B, columns as C, loader as L     # noqa: E402
import joins_as_they_were as WAS                                  # noqa: E402
import test_hierarchy_parallel as HP                              # noqa: E402  (loader, signature, differences)
import test_nvme_hier as T                                        # noqa: E402  (make_files)

DOWN, UP = "Downstream", "Upstream"
REAL_BUILD = B.Build            # built() puts another class in B.Build for the join as it was; a later built() in the same test must get this one back
ROUND = 4096


class Recording:
    """The rows of packets.csv and link.csv in the order they are written. A TLP that opens a link transaction writes its link row too."""

    def __init__(self):
        self.packets, self.links, self.t = [], [], 1000

    def _packet(self, **cells):
        self.t += 10
        cells.update({"Packet": str(len(self.packets)), "Time Stamp": "0001.%012ds" % self.t})
        self.packets.append(cells)
        return len(self.packets) - 1           # the packet's place: 0 for the first row

    def tlp(self, d, psn, counted=2, link_psn=None):
        """A TLP and the link transaction it opens (`counted` = Metrics.# Packets of that link row). Returns (packet place, link place)."""
        at = self._packet(**{"Link Dir": d, "TLP Type": "MWr(64)", "PSN": str(psn)})
        self.links.append({"Link Tra": str(len(self.links) + 1), "Link Dir": d, "PSN": str(psn if link_psn is None else link_psn), "Mem.TLP Type": "MWr(64)",
                           "Metrics.# Packets": str(counted), "Time Stamp": "0001.%012ds" % self.t, "Address": "0x00000004800A0000", "RequesterID": "000:00:0", "Tag": "0"})
        return at, len(self.links) - 1

    def again(self, d, psn):
        """The same TLP sent again: a packet, no link row."""
        return self._packet(**{"Link Dir": d, "TLP Type": "MWr(64)", "PSN": str(psn)})

    def ack(self, of, seq, kind="ACK"):
        """An Ack (or Nak) for the TLPs of direction `of`: it travels the other way."""
        return self._packet(**{"Link Dir": B._other(of), "DLLP Type": kind, "AckNak Seq Num": str(seq)})

    def nak(self, of, seq):
        return self.ack(of, seq, "NAK")

    def write(self, folder):
        os.makedirs(folder, exist_ok=True)
        small = os.path.join(folder, "small")
        os.makedirs(small, exist_ok=True)
        files, _truth = T.make_files(small)                          # split, NVMe transactions and commands: the three-row files of the loader's own test
        for key, rows in (("packets", self.packets), ("link", self.links)):
            names, canon, blank = C.original_names(key), C.canonical_names(key), set(C.label_less_positions(key))
            place = {canon[i]: i for i in range(len(names))}
            path = os.path.join(folder, key + ".csv")
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["" if i in blank else names[i] for i in range(len(names))])
                for cells in rows:
                    row = [""] * len(names)
                    for k, v in cells.items():
                        row[place[k]] = v
                    w.writerow(row)
            files[key] = path
        return files


def load(rec, tmp_path, name="rec"):
    folder = str(tmp_path / name)
    files = rec.write(folder)
    db = os.path.join(folder, "hier.sqlite")
    with HP.loader(WORKERS=1):
        L.load_upload(db, files)
    con = sqlite3.connect(db)
    assert con.execute("SELECT COUNT(*) FROM pkt").fetchone()[0] == len(rec.packets) and con.execute("SELECT COUNT(*) FROM lnk").fetchone()[0] == len(rec.links)
    con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    con.close()
    return db


@pytest.fixture(autouse=True)
def the_rule_is_on(monkeypatch):
    """The tests of this file run with the rule on (the shipped value), whatever config/app_config.json says on this machine. A test of the switch
    gives the value with the build's settings, or sets B.ROUND_RULE itself."""
    monkeypatch.setattr(B, "ROUND_RULE", True)


def built(db, monkeypatch, cls=None, settings=None):
    """Build on one core, in this process -> (report of the link join, parent link place of every packet place, relation of every packet place)."""
    monkeypatch.setattr(B, "JOINS_AT_ONCE_MIN_US", 10 ** 18)
    monkeypatch.setattr(B, "Build", cls if cls is not None else REAL_BUILD)
    with HP.loader(WORKERS=1):
        rep = B.build(db, settings=settings)
    return (rep["steps"]["packets_to_links"],) + tree(db)


def tree(db):
    con = sqlite3.connect(db)
    link_place = {r[0]: i for i, r in enumerate(con.execute("SELECT rowid_file FROM lnk ORDER BY rowid_file"))}
    parent, relation = [], []
    for par, lvl, rel in con.execute("SELECT parent, parent_level, relation FROM pkt ORDER BY rowid_file"):
        parent.append(link_place[par] if (lvl == "link" and par is not None) else None)
        relation.append(rel)
    con.close()
    return parent, relation


def test_load_and_build_understand_the_hand_made_files(tmp_path, monkeypatch):
    """The plainest recording: three TLPs, each with its own Ack. Without this the other tests could pass on files the loader did not understand."""
    r = Recording()
    rows = []
    for psn in (7, 8, 9):
        p, l = r.tlp(DOWN, psn)
        rows.append((p, l, r.ack(DOWN, psn)))
    rep, parent, relation = built(load(r, tmp_path), monkeypatch)
    for p, l, a in rows:
        assert parent[p] == l and parent[a] == l and relation[p] == relation[a] == "member"
    assert rep["tlp_packets"] == 3 and rep["ack_nak_packets"] == 3 and rep["replays_seen"] == 0 and rep["tlp_without_link_row"] == 0
    assert rep["links_with_fewer_packets_than_counted"] == 0 and "links_closed_by_a_later_ack" not in rep


def one_missing_ack():
    """4,200 TLPs in one direction, each with its Ack, except the TLP with number 10 of the first round: the Ack for 11 covers it."""
    r = Recording()
    place = {}
    for i in range(4200):
        p, l = r.tlp(DOWN, i % ROUND)
        a = None if i == 10 else r.ack(DOWN, i % ROUND)
        place[i] = (p, l, a)
    return r, place


def test_a_the_same_number_a_round_later_is_its_own_link_transaction(tmp_path, monkeypatch):
    r, place = one_missing_ack()
    db = load(r, tmp_path)
    was_db = str(tmp_path / "was.sqlite")
    shutil.copy(db, was_db)
    rep, parent, relation = built(db, monkeypatch)
    for i, (p, l, a) in place.items():
        assert parent[p] == l and relation[p] == "member", "TLP %d hangs under link row %s, its own is %d" % (i, parent[p], l)
        if a is not None:
            assert parent[a] == l, "the Ack of TLP %d hangs under link row %s" % (i, parent[a])
    assert rep["links_closed_by_a_later_ack"] == 1 and rep["replays_seen"] == 0 and rep["tlp_without_link_row"] == 0 and rep["ack_nak_without_open_link"] == 0
    assert rep["links_with_fewer_packets_than_counted"] == 1, "the link transaction whose own Ack never came has one packet of the two the analyzer counted"
    assert rep["link_rows_matched"] == 4200 and rep["link_rows_skipped"] == 0
    # the fault as it was: the TLP of the second round was counted as a resend of the first round's link transaction, and its own link row got nothing
    rep_was, parent_was, _rel = built(was_db, monkeypatch, WAS.BuildBefore)
    p_new, l_new, a_new = place[ROUND + 10]
    assert parent_was[p_new] == place[10][1] and rep_was["replays_seen"] == 1 and parent_was[a_new] is None


def test_b_one_ack_for_five_tlps_closes_all_five(tmp_path, monkeypatch):
    r = Recording()
    first = [r.tlp(DOWN, psn) for psn in range(100, 105)]
    ack = r.ack(DOWN, 104)                                           # names 104 (explicit), covers 100 to 103 (implicit)
    for i in range(105, 100 + ROUND):                                # the rest of the round: link transactions of one packet, which never stay open
        r.tlp(DOWN, i % ROUND, counted=1)
    second = [r.tlp(DOWN, psn) for psn in range(100, 105)]
    acks = [r.ack(DOWN, psn) for psn in range(100, 105)]
    rep, parent, relation = built(load(r, tmp_path), monkeypatch)
    assert parent[ack] == first[4][1], "the Ack belongs to the link transaction it names"
    for (p, l) in first + second:
        assert parent[p] == l
    for (p, l), a in zip(second, acks):
        assert parent[a] == l, "an Ack of the second round hangs under a link row of the first: all five were not closed"
    members = [sum(1 for x in parent if x == l) for _p, l in first]
    assert members == [1, 1, 1, 1, 2], "packets under the five link rows of the first round: %s" % members
    assert rep["links_closed_by_a_later_ack"] == 4, "100 to 103 were closed by the Ack for 104 (implicitly acknowledged); 104 by its own"
    assert rep["links_with_fewer_packets_than_counted"] == 4 and rep["replays_seen"] == 0 and rep["tlp_without_link_row"] == 0 and rep["ack_nak_without_open_link"] == 0


def test_c_a_resend_after_a_nak_is_still_a_resend(tmp_path, monkeypatch):
    r = Recording()
    p4, l4 = r.tlp(DOWN, 4)                                          # never gets an Ack of its own
    p5, l5 = r.tlp(DOWN, 5)
    a5 = r.ack(DOWN, 5)
    p6, l6 = r.tlp(DOWN, 6, counted=3)                               # the TLP, the Nak, the TLP again
    p7, l7 = r.tlp(DOWN, 7, counted=3)                               # the TLP, the TLP again, its Ack
    nak = r.nak(DOWN, 5)                                             # 5 was the last good one: 6 and 7 are wanted again
    p6b, p7b = r.again(DOWN, 6), r.again(DOWN, 7)
    a7 = r.ack(DOWN, 7)
    rep, parent, relation = built(load(r, tmp_path), monkeypatch)
    assert [parent[x] for x in (p4, p5, a5, p6, p7, nak, p6b, p7b, a7)] == [l4, l5, l5, l6, l7, l6, l6, l7, l7]
    assert rep["replays_seen"] == 2 and "links_closed_by_a_later_ack" not in rep and rep["tlp_without_link_row"] == 0 and rep["ack_nak_without_open_link"] == 0


def test_c_a_resend_with_no_link_row_of_its_own_stays_a_resend_even_after_a_covering_ack(tmp_path, monkeypatch):
    """The Ack was seen by the analyzer, the sender sent the TLP again all the same (its timer ran out): no link row is there for the second sending."""
    r = Recording()
    p20, l20 = r.tlp(DOWN, 20, counted=3)
    p21, l21 = r.tlp(DOWN, 21)
    a21 = r.ack(DOWN, 21)                                            # covers 20
    p20b = r.again(DOWN, 20)
    p22, l22 = r.tlp(DOWN, 22, counted=1)
    rep, parent, relation = built(load(r, tmp_path), monkeypatch)
    assert [parent[x] for x in (p20, p21, a21, p20b, p22)] == [l20, l21, l21, l20, l22]
    assert rep["replays_seen"] == 1 and "links_closed_by_a_later_ack" not in rep


def test_d_an_ack_that_covers_numbers_on_both_sides_of_4095_to_0(tmp_path, monkeypatch):
    r = Recording()
    numbers = (4093, 4094, 4095, 0, 1)
    first = [r.tlp(DOWN, psn) for psn in numbers]
    ack = r.ack(DOWN, 1)                                             # names 1, covers 4093, 4094, 4095 and 0
    for psn in range(2, 4093):
        r.tlp(DOWN, psn, counted=1)
    second = [r.tlp(DOWN, psn) for psn in numbers]
    acks = [r.ack(DOWN, psn) for psn in numbers]
    rep, parent, relation = built(load(r, tmp_path), monkeypatch)
    assert parent[ack] == first[4][1]
    for (p, l) in first + second:
        assert parent[p] == l
    for (p, l), a in zip(second, acks):
        assert parent[a] == l
    assert rep["links_closed_by_a_later_ack"] == 4 and rep["replays_seen"] == 0 and rep["tlp_without_link_row"] == 0 and rep["ack_nak_without_open_link"] == 0


def test_d_an_ack_does_not_cover_the_numbers_after_it_across_4095_to_0(tmp_path, monkeypatch):
    """An Ack for 4094 covers 4093 and not 0: 0 sent again is a resend although a link row with number 0 lies in the window; 4093 again with a link row of
    its own is a new link transaction."""
    r = Recording()
    first = {psn: r.tlp(DOWN, psn, counted=3) for psn in (4093, 4094, 4095, 0, 1)}
    ack = r.ack(DOWN, 4094)
    zero_again = r.again(DOWN, 0)                                    # no link row of its own, and not covered
    new_4093 = r.tlp(DOWN, 4093)                                     # covered, and a link row of its own
    spare_zero = r.tlp(DOWN, 0, counted=1)                           # written as a link row with number 0 for a TLP that is also number 0 ...
    rep, parent, relation = built(load(r, tmp_path), monkeypatch)
    assert parent[ack] == first[4094][1]
    assert parent[zero_again] == first[0][1], "0 was not covered by the Ack for 4094: it is a resend"
    assert parent[new_4093[0]] == new_4093[1]
    # ... and that TLP too meets the open, uncovered link transaction 0: a resend again, which fills it (3 of 3); its link row stays without a packet
    assert parent[spare_zero[0]] == first[0][1]
    assert rep["links_closed_by_a_later_ack"] == 1 and rep["replays_seen"] == 2


def test_e_the_two_directions_come_round_at_different_moments(tmp_path, monkeypatch):
    r = Recording()
    sent = {DOWN: 0, UP: 0}
    start = {DOWN: 4000, UP: 100}                                    # Downstream passes 4095 after 96 TLPs, Upstream after 3,996
    silent = {DOWN: 10, UP: 10}                                      # the TLP of each direction that never gets an Ack of its own
    place = {DOWN: {}, UP: {}}

    def one(d):
        i = sent[d]
        sent[d] += 1
        psn = (start[d] + i) % ROUND
        p, l = r.tlp(d, psn)
        place[d][i] = (p, l, None if i == silent[d] else r.ack(d, psn))
    for i in range(4300):                                            # two Downstream TLPs for one Upstream TLP: Downstream comes round first
        one(DOWN)
        if i % 2 == 0:
            one(UP)
    assert sent[UP] < ROUND < sent[DOWN]
    half = len(r.packets)
    for _ in range(2100):                                            # then Upstream alone, until it has come round too
        one(UP)
    assert sent[UP] > ROUND + silent[UP]
    db = load(r, tmp_path)
    rep, parent, relation = built(db, monkeypatch)
    for d in (DOWN, UP):
        for i, (p, l, a) in place[d].items():
            assert parent[p] == l, "%s TLP %d hangs under link row %s, its own is %d" % (d, i, parent[p], l)
            if a is not None:
                assert parent[a] == l, "the Ack of %s TLP %d hangs under link row %s, its own is %d" % (d, i, parent[a], l)
    assert rep["links_closed_by_a_later_ack"] == 2 and rep["replays_seen"] == 0 and rep["tlp_without_link_row"] == 0 and rep["ack_nak_without_open_link"] == 0
    assert rep["links_with_fewer_packets_than_counted"] == 2
    # after the first part only Downstream had come round
    part = Recording()
    part.packets, part.links = r.packets[:half], [x for x in r.links if int(x["Time Stamp"][5:-1]) <= int(r.packets[half - 1]["Time Stamp"][5:-1])]
    rep_part = built(load(part, tmp_path, "part"), monkeypatch)[0]
    assert rep_part["links_closed_by_a_later_ack"] == 1 and rep_part["links_with_fewer_packets_than_counted"] == 2


def test_f_a_damaged_sequence_number_cell_does_not_stop_the_build(tmp_path, monkeypatch):
    r = Recording()
    good = [r.tlp(DOWN, 1), r.tlp(DOWN, 2)]
    a2 = r.ack(DOWN, 2)
    bad_tlp, bad_link = r.tlp(DOWN, "??", link_psn=3)                # the packet's cell is damaged, its link row is whole
    empty_tlp, _l = r.tlp(DOWN, "", link_psn=4)                      # the packet's cell is empty
    both, both_link = r.tlp(DOWN, "", link_psn="")                   # packet and link row both without a number, and two packets counted: it stays open
    bad_ack = r.ack(DOWN, "x9")                                      # an Ack whose number cannot be read
    nak = r.nak(DOWN, 2)                                             # a Nak while a link transaction without a number is open (this line failed before)
    after = r.tlp(DOWN, 5)
    a5 = r.ack(DOWN, 5)
    db = load(r, tmp_path)
    con = sqlite3.connect(db)
    read = [x[0] for x in con.execute("SELECT psn FROM pkt ORDER BY rowid_file")]
    con.close()
    rep, parent, relation = built(db, monkeypatch)
    assert parent[good[0][0]] == good[0][1] and parent[good[1][0]] == good[1][1] and parent[a2] == good[1][1]
    assert parent[after[0]] == after[1] and parent[a5] == after[1], "the rows after the damaged ones are joined as usual"
    assert read[bad_tlp] is None and parent[bad_tlp] is None and relation[bad_tlp] != "member", "a TLP whose number cannot be read is not joined"
    assert read[empty_tlp] is None and parent[empty_tlp] is None and relation[empty_tlp] != "member"
    assert rep["tlp_without_link_row"] == 2, "the two TLPs that were not joined are counted: %s" % rep
    assert parent[both] == both_link, "packet and link row both without a number: joined as before, by their place and time"
    assert parent[bad_ack] is None and relation[bad_ack] == "context"
    assert parent[nak] is None and relation[nak] == "context" and rep["ack_nak_without_open_link"] >= 1
    assert "links_closed_by_a_later_ack" not in rep


@pytest.mark.parametrize("processes", [2, 4])
def test_g_the_same_tree_with_one_two_and_four_join_processes(tmp_path, monkeypatch, processes):
    r, place = one_missing_ack()
    r.nak(DOWN, (4199 - 3) % ROUND)                                  # and a Nak with a resend at the end, so that every branch is met
    r.again(DOWN, (4199 - 2) % ROUND)
    db = load(r, tmp_path)
    other = str(tmp_path / "other.sqlite")
    shutil.copy(db, other)
    monkeypatch.setattr(B, "JOINS_AT_ONCE_MIN_US", 10 ** 18)
    with HP.loader(WORKERS=1):
        rep_one = B.build(db)
    assert "parallel" not in rep_one and rep_one["steps"]["packets_to_links"]["links_closed_by_a_later_ack"] == 1
    monkeypatch.setattr(B, "JOINS_AT_ONCE_MIN_US", 0)
    with HP.loader(WORKERS=processes):
        rep = B.build(other)
    assert rep["parallel"]["processes"] == processes and "packets_to_links" in rep["parallel"]["joins_at_the_same_time"], rep.get("parallel")
    assert rep["parallel"]["run_on_one_core_instead"] == {}
    assert HP.differences(HP.signature(db), HP.signature(other)) == []
    assert tree(db) == tree(other)
    p, l, a = place[ROUND + 10]
    assert tree(other)[0][p] == l and tree(other)[0][a] == l


# ====================================================================================================================================================
# After the independent review of 2026-11-14 (research_notes/Opportunity statement coverage check/review_link_sequence_wrap.md): the switch, the short
# list of the latest Acks, the review's sequence S17, and the four cases that are wrong exactly as before, kept here as known limits.
# ====================================================================================================================================================
WORDS = "rule_for_a_number_that_comes_round"


def counts(rep):
    """The link join's report without what may differ between the join now and the join as it was: the time, and the line that says which rule was used."""
    return {k: v for k, v in rep.items() if k not in ("seconds", WORDS)}


def test_switch_off_is_the_join_as_it_was_and_the_report_says_which_rule(tmp_path, monkeypatch):
    r, place = one_missing_ack()
    r.nak(DOWN, (4199 - 3) % ROUND)
    r.again(DOWN, (4199 - 2) % ROUND)
    db = load(r, tmp_path)
    off_db, was_db = str(tmp_path / "off.sqlite"), str(tmp_path / "was.sqlite")
    shutil.copy(db, off_db)
    shutil.copy(db, was_db)
    rep_on, parent_on, _ = built(db, monkeypatch)
    rep_off, parent_off, rel_off = built(off_db, monkeypatch, settings={"round_rule": False})
    rep_was, parent_was, rel_was = built(was_db, monkeypatch, WAS.BuildBefore)
    assert rep_on[WORDS] == B.ROUND_RULE_ON == "a packet whose number comes round again is its own link transaction once a later Ack covered the earlier one: on"
    assert rep_off[WORDS] == B.ROUND_RULE_OFF == "off: the join as it was before 2026-11-14"
    assert WORDS not in rep_was
    assert (parent_off, rel_off) == (parent_was, rel_was) and counts(rep_off) == counts(rep_was)
    # every table and the whole stored report: one difference, the line that says which rule was used
    assert HP.differences(HP.signature(off_db), HP.signature(was_db)) == ["/meta/build/steps/packets_to_links/%s is in one only" % WORDS]
    assert parent_on != parent_off and "links_closed_by_a_later_ack" in rep_on and "links_closed_by_a_later_ack" not in rep_off
    # the three look-ahead numbers are what they were: the switch is not one of them
    con = sqlite3.connect(off_db)
    whole = __import__("json").loads(con.execute("SELECT v FROM meta WHERE k='build'").fetchone()[0])
    con.close()
    assert whole["settings"] == B.settings_of(None) and set(whole["settings"]) == {"look_links", "look_splits", "look_cmds"}


def test_switch_is_read_from_the_configuration_file_and_the_builds_own_setting_wins(tmp_path, monkeypatch):
    cfg = str(tmp_path / "app_config.json")
    monkeypatch.setattr(B, "CONFIG_FILE", cfg)
    monkeypatch.setattr(B, "ROUND_RULE", None)
    assert B.round_rule_of(None) is True                                    # no file: the shipped value
    for text, want in (('{"tree": {"round_rule": false}}', False), ('{"tree": {"round_rule": true}}', True), ('{"tree": {"round_rule": "off"}}', False),
                       ('{"tree": {}}', True), ('{"pipeline": {"workers": 0}}', True), ('{"tree": 5}', True), ('not json at all', True), ('[1, 2]', True)):
        with open(cfg, "w", encoding="utf-8") as f:
            f.write(text)
        assert B.round_rule_of(None) is want, text
    with open(cfg, "w", encoding="utf-8") as f:
        f.write('{"tree": {"round_rule": false}}')
    assert B.round_rule_of({"round_rule": True}) is True and B.round_rule_of({"look_links": 5}) is False
    monkeypatch.setattr(B, "ROUND_RULE", True)
    assert B.round_rule_of(None) is True and B.round_rule_of({"round_rule": False}) is False
    # the file the application ships: the key is there and on
    with open(os.path.join(APP, "config", "app_config.json"), encoding="utf-8") as f:
        shipped = __import__("json").load(f)
    assert shipped["tree"]["round_rule"] is True


def test_switch_off_in_the_configuration_file_reaches_a_build_and_its_join_processes(tmp_path, monkeypatch):
    """The join processes are started fresh ("spawn"): they see neither B.ROUND_RULE nor the changed B.CONFIG_FILE of this process, only what the build gives them."""
    cfg = str(tmp_path / "app_config.json")
    with open(cfg, "w", encoding="utf-8") as f:
        f.write('{"tree": {"round_rule": false}}')
    monkeypatch.setattr(B, "CONFIG_FILE", cfg)
    monkeypatch.setattr(B, "ROUND_RULE", None)
    r, place = one_missing_ack()
    db = load(r, tmp_path)
    was_db = str(tmp_path / "was.sqlite")
    shutil.copy(db, was_db)
    monkeypatch.setattr(B, "JOINS_AT_ONCE_MIN_US", 0)
    with HP.loader(WORKERS=2):
        rep = B.build(db)
    assert rep["parallel"]["processes"] == 2 and "packets_to_links" in rep["parallel"]["joins_at_the_same_time"] and rep["parallel"]["run_on_one_core_instead"] == {}
    assert rep["steps"]["packets_to_links"][WORDS] == B.ROUND_RULE_OFF and "links_closed_by_a_later_ack" not in rep["steps"]["packets_to_links"]
    rep_was, parent_was, rel_was = built(was_db, monkeypatch, WAS.BuildBefore)
    assert tree(db) == (parent_was, rel_was) and counts(rep["steps"]["packets_to_links"]) == counts(rep_was)
    p, l, a = place[ROUND + 10]
    assert tree(db)[0][p] == place[10][1], "off: the TLP of the second round is the resend it was before"


# ---------------------------------------------------------------------------------------------------------------- the short list of the latest Acks
def test_the_short_list_of_acks_answers_what_the_long_way_answers_on_300_generated_recordings(tmp_path, monkeypatch):
    """B.RECENT_ACKS = 0 keeps no list: every "was it covered since it was opened" is answered the long way, over the 2,048 numbers (the form the review
    measured). With a list of 1, 2, 3, 7 or 64 the scratch tables and the report must be the same, row for row."""
    import random
    import test_tree_build_lookups as TB
    asked = {"came_round": 0, "resends": 0}
    for seed in range(300):
        db = str(tmp_path / ("r%d.sqlite" % seed))
        settings = dict(TB.recording(db, seed), round_rule=True)
        monkeypatch.setattr(B, "RECENT_ACKS", 0)
        long_way = TB.decided(db, B.Build, "packets_to_links", settings, "long")
        for keep in (random.Random(seed).choice([1, 2, 3, 7]), 64):
            monkeypatch.setattr(B, "RECENT_ACKS", keep)
            short = TB.decided(db, B.Build, "packets_to_links", settings, "short")
            assert short == long_way, "seed %d, a list of %d: %s, the long way: %s" % (seed, keep, short[1], long_way[1])
        asked["came_round"] += 1 if "links_closed_by_a_later_ack" in long_way[1] else 0
        asked["resends"] += long_way[1]["replays_seen"]
        for ext in ("", "-wal", "-shm"):
            if os.path.exists(db + ext):
                os.remove(db + ext)
    assert asked["came_round"] >= 100 and asked["resends"] >= 1000, "the generated recordings asked the question too seldom: %s" % asked


def resends_nothing_covers(path, groups):
    """The review's costly case: TLP P (three packets counted), the Ack for P - 1, TLP P again, the Ack for P; `groups` times. Every second TLP is a resend
    that no Ack since the opening covers."""
    import test_tree_build_lookups as TB
    con = L.open_db(path)
    for k in TB.LEVELS:
        L.create_tables(con, k)
    links, packets = [], []
    for i in range(groups):
        p, t = i % ROUND, 1000 + 40 * i
        links.append((DOWN, p, 3, t))
        packets += [(DOWN, "MWr(64)", None, p, None, t), (UP, None, "Ack", None, (p - 1) % ROUND, t + 10), (DOWN, "MWr(64)", None, p, None, t + 20), (UP, None, "Ack", None, p, t + 30)]
    TB.insert(con, "lnk", ("dir", "psn", "n_packets", "t_ps"), links)
    TB.insert(con, "pkt", ("dir", "tlp_type", "dllp_type", "psn", "acknak", "t_ps"), packets)
    L.set_meta(con, "levels_present", list(TB.LEVELS))
    con.commit()
    con.close()


def test_a_resend_that_no_ack_covers_does_not_look_up_2048_numbers(tmp_path, monkeypatch):
    """Measured by the review: 30,000 such resends, 6.67 s against 0.55 s for the join as it was. With the short list: the same rows, and no slower than
    twice the join as it was (the long way took about ten times as long)."""
    import time
    import test_tree_build_lookups as TB
    db = str(tmp_path / "cost.sqlite")
    resends_nothing_covers(db, 30000)
    t0 = time.time()
    was = TB.decided(db, WAS.BuildBefore, "packets_to_links", None, "was")
    t1 = time.time()
    now = TB.decided(db, B.Build, "packets_to_links", {"round_rule": True}, "now")
    t2 = time.time()
    monkeypatch.setattr(B, "RECENT_ACKS", 0)
    long_way = TB.decided(db, B.Build, "packets_to_links", {"round_rule": True}, "long")
    t3 = time.time()
    assert now == long_way == was and now[1]["replays_seen"] == 30000 and "links_closed_by_a_later_ack" not in now[1]
    print("30,000 resends that no Ack covers: the join as it was %.2f s, the long way %.2f s, with the short list %.2f s" % (t1 - t0, t3 - t2, t2 - t1))
    assert (t2 - t1) < 2 * (t1 - t0) + 0.5, "a resend that nothing covers is slow again: %.2f s now, %.2f s the join as it was" % (t2 - t1, t1 - t0)


# -------------------------------------------------------------------------------------------------- the review's sequence S17 (closed) and known limits
KNOWN_LIMITS = {}


def known_limit(sentence):
    """Marks a test that documents what the join does TODAY in a case where that is known to be wrong. The test passing means "still wrong in the same way";
    whoever repairs the case changes the expectation and takes the mark away."""
    def mark(test):
        KNOWN_LIMITS[test.__name__] = sentence
        test.known_limit = sentence
        return test
    return mark


def test_s17_a_duplicate_before_a_restart_does_not_take_the_link_row_of_the_later_tlp(tmp_path, monkeypatch):
    """The review's S17. TLP 0 (three packets counted), TLP 1, the Ack for 1 (covers 0), TLP 0 sent again with no link row of its own; numbering starts
    again; TLP 0 with its link row, its Ack. The duplicate found the later TLP's link row at the head of the window, on its number alone. Closed without a
    guess: a link row carries the time of its first packet and the rows are in the order of time, so a head row that begins after the packet is not the
    packet's row. Time orders here; the join itself is still direction + number."""
    r = Recording()
    p0, l0 = r.tlp(DOWN, 0, counted=3)
    p1, l1 = r.tlp(DOWN, 1)
    a1 = r.ack(DOWN, 1)
    dup = r.again(DOWN, 0)
    p0b, l0b = r.tlp(DOWN, 0)          # after the restart of numbering
    a0b = r.ack(DOWN, 0)
    p1b, l1b = r.tlp(DOWN, 1)
    a1b = r.ack(DOWN, 1)
    rep, parent, relation = built(load(r, tmp_path), monkeypatch)
    assert parent[dup] == l0, "the duplicate belongs to the first link transaction"
    assert parent[p0b] == l0b and parent[a0b] == l0b and parent[p1b] == l1b and parent[a1b] == l1b and parent[p0] == l0 and parent[p1] == parent[a1] == l1
    assert rep["replays_seen"] == 1 and rep["links_closed_by_a_later_ack"] == 1 and rep["ack_nak_without_open_link"] == 0 and rep["tlp_without_link_row"] == 0


def same_as_before(db, tmp_path, monkeypatch, parent, rep):
    """A known limit that the rule of 2026-11-14 neither made nor repaired: the join as it was decides the same."""
    was_db = str(tmp_path / "limit_was.sqlite")
    shutil.copy(db, was_db)
    return built(was_db, monkeypatch, WAS.BuildBefore)


@known_limit("When numbering starts again (the link went down) and nothing was acknowledged before, the first packets after the restart are counted as "
             "resends of the old link transactions with their numbers, and their Acks join nothing: the join does not look at the state of the link.")
def test_known_limit_numbering_restarts_with_nothing_acknowledged(tmp_path, monkeypatch):
    """The review's S08."""
    r = Recording()
    p0, l0 = r.tlp(DOWN, 0)
    p1, l1 = r.tlp(DOWN, 1)
    # the link goes down; nothing was acknowledged; numbering starts again
    p0b, l0b = r.tlp(DOWN, 0)
    a0b = r.ack(DOWN, 0)
    p1b, l1b = r.tlp(DOWN, 1)
    a1b = r.ack(DOWN, 1)
    db = load(r, tmp_path)
    was = same_as_before(db, tmp_path, monkeypatch, None, None)
    rep, parent, relation = built(db, monkeypatch)
    # right would be: parent[p0b] == parent[a0b] == l0b and parent[p1b] == parent[a1b] == l1b
    assert [parent[x] for x in (p0, p1, p0b, a0b, p1b, a1b)] == [l0, l1, l0, None, l1, None]
    assert rep["replays_seen"] == 2 and rep["ack_nak_without_open_link"] == 2 and rep["link_rows_skipped"] == 2 and "links_closed_by_a_later_ack" not in rep
    assert (parent, relation) == was[1:] and counts(rep) == counts(was[0])


@known_limit("When a whole round of 4,096 packets passes and no Ack that covers the open link transaction is in the recording, the packet with the same "
             "number a round later is counted as a resend of it: without a recorded Ack nothing tells a new packet from a resend.")
def test_known_limit_a_round_with_no_covering_ack_recorded(tmp_path, monkeypatch):
    """The review's S18."""
    r = Recording()
    first, l_first = r.tlp(DOWN, 10)
    for i in range(11, ROUND + 10):
        r.tlp(DOWN, i % ROUND, counted=1)
    again, l_again = r.tlp(DOWN, 10)
    a = r.ack(DOWN, 10)
    db = load(r, tmp_path)
    was = same_as_before(db, tmp_path, monkeypatch, None, None)
    rep, parent, relation = built(db, monkeypatch)
    # right would be: parent[again] == parent[a] == l_again
    assert parent[again] == l_first and parent[a] is None
    assert rep["replays_seen"] == 1 and rep["ack_nak_without_open_link"] == 1 and rep["link_rows_skipped"] == 1 and "links_closed_by_a_later_ack" not in rep
    assert (parent, relation) == was[1:] and counts(rep) == counts(was[0])


@known_limit("A Nak with no open link transaction after its number is joined to a link transaction that an Ack covered long before and that was never "
             "closed, because covered link transactions are not closed at the Ack.")
def test_known_limit_a_nak_joins_a_link_acknowledged_long_before(tmp_path, monkeypatch):
    """The review's S15: the Nak for 3000 lands in the link transaction of TLP 12, acknowledged 2,988 TLPs earlier."""
    r = Recording()
    p12, l12 = r.tlp(DOWN, 12)                 # two packets counted, its own Ack never comes
    r.tlp(DOWN, 13)
    r.ack(DOWN, 13)                            # covers 12
    for i in range(14, 3000):
        r.tlp(DOWN, i, counted=1)
    r.tlp(DOWN, 3000)
    r.ack(DOWN, 3000)
    nak = r.nak(DOWN, 3000)                    # nothing is open after 3000
    r.tlp(DOWN, 3001)
    r.ack(DOWN, 3001)
    db = load(r, tmp_path)
    was = same_as_before(db, tmp_path, monkeypatch, None, None)
    rep, parent, relation = built(db, monkeypatch)
    # right would be: parent[nak] is None (relation "context")
    assert parent[nak] == l12 and relation[nak] == "member"
    assert rep["ack_nak_without_open_link"] == 0 and rep["replays_seen"] == 0
    assert (parent, relation) == was[1:] and counts(rep) == counts(was[0])


@known_limit("If the analyzer exports a resend after a Nak as a link row of its own, the resend still hangs under the first link row, its own link row "
             "is skipped and the Ack after it joins nothing: whether the analyzer writes such a row is not documented.")
def test_known_limit_a_resend_after_a_nak_exported_as_its_own_link_row(tmp_path, monkeypatch):
    """The review's S22."""
    r = Recording()
    p5, l5 = r.tlp(DOWN, 5)
    a5 = r.ack(DOWN, 5)
    p6, l6 = r.tlp(DOWN, 6)
    nak = r.nak(DOWN, 5)                       # 5 arrived, 6 is asked for again
    p6b, l6b = r.tlp(DOWN, 6)                  # the resend, with a link row of its own
    a6 = r.ack(DOWN, 6)
    db = load(r, tmp_path)
    was = same_as_before(db, tmp_path, monkeypatch, None, None)
    rep, parent, relation = built(db, monkeypatch)
    # right (if the analyzer does write such a row) would be: parent[p6b] == parent[a6] == l6b
    assert [parent[x] for x in (p5, a5, p6, nak, p6b, a6)] == [l5, l5, l6, l6, l6, None]
    assert rep["replays_seen"] == 1 and rep["ack_nak_without_open_link"] == 1 and rep["link_rows_skipped"] == 1 and "links_closed_by_a_later_ack" not in rep
    assert (parent, relation) == was[1:] and counts(rep) == counts(was[0])


def test_the_known_limits_are_the_four_the_review_listed():
    assert sorted(KNOWN_LIMITS) == ["test_known_limit_a_nak_joins_a_link_acknowledged_long_before", "test_known_limit_a_resend_after_a_nak_exported_as_its_own_link_row",
                                    "test_known_limit_a_round_with_no_covering_ack_recorded", "test_known_limit_numbering_restarts_with_nothing_acknowledged"]
    assert all(len(v) > 40 for v in KNOWN_LIMITS.values())
