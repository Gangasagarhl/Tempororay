"""Items whose code is part of the application (the detector's rules, and the built-in item "commands that completed but came close
to the limit", nvme_hier/near_limit.py) inside a whole flow and in the rules browser. No real model: the stand-in only.

What is checked, on a throw-away root (nothing of the application's own db/, runs/, uploads/ or knowledge/ is read or written):
  - a whole flow on S08 in which the admin chooses EVERY item of the plan and approves every card (no "go on with open points"
    tick) finishes; the same on S17, which has timeout errors
  - the item's research, requirements and code steps are skipped with the one sentence, and no model was asked for them
  - its run step gave the CSV with the 17 columns; the Tester passed; the result card carries the per-kind summary sentences
  - the errors list, the errors gate and the report's errors are the same as in a flow without the item
  - a changed share in the item's plan reaches the code and the result (0.0005 per cent on S17 lists 5 commands)
  - a share that is not a share is refused in plain words at the code step, and the flow says so instead of running
  - the rules browser: Code it answers with a plain sentence (no Coder), Run and Proceed run the application's own code
"""
import csv
import json
import os
import shutil
import sys
import tempfile
import threading
import time
import types

import pytest

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for _p in (APP, os.path.join(APP, "app"), os.path.join(APP, "tests")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from agentic import core, family1, family3, family4, procedures as PR      # noqa: E402
from nvme_hier import near_limit as NL                                       # noqa: E402

SAMPLES = os.path.join(APP, "samples", "clean_five_files")
S08 = os.path.join(SAMPLES, "S08_interrupt_before_completion")
S17 = os.path.join(SAMPLES, "S17_io_timeout_abort_reset")
ITEM = "analytics/nvme_command/near_limit"
SENTENCE = "this item runs code that is part of the application (nvme_hier/near_limit.py): there is nothing to research, to ask or to code"
HOSTILE = "__import__('os').system('echo taken')"


class Yes:
    """Every choice the flow asks for, answered the plain way (as tests/test_agent_layer.py does)."""
    def random(self):
        return 0.0

    def choice(self, seq):
        return seq[0]

    def sample(self, seq, k):
        return list(seq)[:k]

    def randint(self, _a, b):
        return b


def drive(c, FD, name, folder, choose, out, limit=900):
    """One whole flow with an admin who approves every card as it is; choose(keys) -> the items taken on the plan card."""
    p = c.post("/api/agents/projects", json={"admin": "t", "name": name, "folder": folder}).get_json()
    rid = c.post("/api/agents/projects/%d/flow" % p["id"], json={"admin": "t"}).get_json()["run"]
    t0, plan = time.time(), []
    while time.time() - t0 < limit:
        v = c.get("/api/agents/runs/%d" % rid).get_json()
        failed = [s for s in v["steps"] if s["state"] == "failed"]
        if v["run"]["state"] != "running" or failed:
            out[name] = {"run": rid, "project": p["id"], "state": "failed" if failed else v["run"]["state"], "view": v, "plan": plan, "seconds": time.time() - t0}
            return
        rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
        if rv is None:
            time.sleep(0.2)
            continue
        st = next(s for s in v["steps"] if s["id"] == rv["step"])
        d = rv.get("data") or {}
        if st["key"] == "f3_plan":
            plan = [i["key"] for i in d.get("items") or []]
            edits = {"selected": choose(plan)}
        else:
            edits = FD.edits_for(st["key"], d, Yes())
        assert not (edits or {}).get("go_on_with_open_points"), "the admin of this test never ticks 'go on with the open points'"
        r = c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t", "edits": edits})
        assert r.status_code < 500, r.get_data()[:300]
    out[name] = {"run": rid, "project": p["id"], "state": "no end in %d s" % limit, "view": c.get("/api/agents/runs/%d" % rid).get_json(), "plan": plan, "seconds": limit}


def set_plan(**plan):
    r = family3.load_rule("analytics", "nvme_command", "near_limit")
    r["plan"] = dict(plan)
    family3.save_rule(r)


@pytest.fixture(scope="module")
def world():
    import fuzz_app as F
    import fuzz_deep as FD
    from api import config_api, hier_api
    root = tempfile.mkdtemp(prefix="application_code_items_%d_" % os.getpid())
    kept = (core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK)
    uploads = list(PR._UPLOADS)          # create_app points the procedures at the throw-away root's uploads: put back for the tests that follow (2026-11-15)
    calls = []
    try:
        app, _c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kept[0]
        c = app.test_client()
        c.get("/api/agents/state")
        # (2026-11-15) a new installation starts the item in Deleted items (Data analytics reads one CSV file; this item needs the NVMe
        # transaction file too): the admin of this test restores it, to check the application's code machinery on it as before
        family3.tree()
        if family3.load_rule(*ITEM.split("/")) is None:
            family3.restore_item(*ITEM.split("/"), "t")
        eng = app.config["services"].agentic_engine
        assert eng is not None
        runner = eng.runner

        def counted(fn, where):
            def call(*a, **k):
                calls.append(str(k.get("agent") if "agent" in k else (a[where] if len(a) > where else "")))
                return fn(*a, **k)
            return call
        runner.ask = counted(runner.ask, 1)                     # ask(run_id, agent, ...)
        runner.api_turn = counted(runner.api_turn, 2)           # api_turn(prompt, scope, agent, name)
        runner.terminal_turn = counted(runner.terminal_turn, 3)  # terminal_turn(prompt, box, scope, agent, ...)
        out = {}
        every = lambda keys: list(keys)                                  # noqa: E731
        without = lambda keys: [k for k in keys if k != ITEM]            # noqa: E731
        only = lambda keys: [ITEM]                                       # noqa: E731
        # 1. the starting share: with every item, and without the item, on both samples (four flows at the same time)
        ts = [threading.Thread(target=drive, args=(app.test_client(), FD, n, f, ch, out)) for n, f, ch in (
            ("S08 every item", S08, every), ("S08 without", S08, without), ("S17 every item", S17, every), ("S17 without", S17, without))]
        [t.start() for t in ts]
        [t.join() for t in ts]
        calls_first = list(calls)
        # 2. the admin changes the share in the item's plan
        set_plan(share_percent=0.0005, share_set_by="admin t")
        drive(app.test_client(), FD, "S17 changed share", S17, only, out)
        # 3. a share that is not a share
        set_plan(share_percent=HOSTILE, share_set_by="admin t")
        drive(app.test_client(), FD, "S08 hostile share", S08, only, out)
        hostile_state = PR.code_state(family3.load_rule("analytics", "nvme_command", "near_limit"))
        hostile_run = c.post("/api/agents/rules/%s/run" % ITEM, json={"project": out["S08 every item"]["project"], "admin": "t"})
        # 4. the rules browser, with the plan as the application seeds it
        set_plan(**json.loads(json.dumps(NL.ITEM["plan"])))
        yield {"app": app, "c": c, "eng": eng, "out": out, "calls": calls, "calls_first": calls_first, "root": root, "FD": FD,
               "hostile_state": hostile_state,
               "hostile_run": (hostile_run.status_code, hostile_run.get_json())}
    finally:
        core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK = kept
        PR._UPLOADS[:] = uploads
        shutil.rmtree(root, ignore_errors=True)


def steps_of(flow, item=ITEM):
    return {s["key"].rsplit(":", 1)[1]: s for s in flow["view"]["steps"] if s["key"].startswith("f3:%s:" % item)}


def card_of(flow, sub, item=ITEM):
    s = steps_of(flow, item)[sub]
    return next(q for q in flow["view"]["reviews"] if q["step"] == s["id"])


def errors_of(flow):
    """What the analysis holds as errors: every errors list, the gate before the report, and the report's errors."""
    v = flow["view"]
    lists = {s["key"]: ((s.get("output") or {}).get("pattern"), (s.get("output") or {}).get("total"),
                        [(e["what"], e["where"], e["when"], e["serious"], e["level"], e["row"]) for e in (s.get("output") or {}).get("errors") or []])
             for s in v["steps"] if s["key"].endswith(":errors")}
    gate = next(s for s in v["steps"] if s["key"] == "errors_done")["output"]
    rep_step = next(s for s in v["steps"] if s["key"] == "report")
    with open(rep_step["output"]["files"]["json"], encoding="utf-8") as fh:
        rep = json.load(fh)
    return {"lists": lists, "gate": gate, "report": [(e["pattern"], e["where"], e["what"]) for e in rep["errors"]], "other": rep.get("other_errors")}, rep


@pytest.mark.parametrize("sample", ["S08", "S17"])
def test_a_whole_flow_with_every_item_chosen_finishes_and_the_item_runs_as_application_code(world, sample):
    flow = world["out"]["%s every item" % sample]
    assert flow["state"] == "finished", (flow["state"], [(s["key"], s["state"], (s.get("error") or "")[:300]) for s in flow["view"]["steps"] if s["state"] not in ("done", "approved", "skipped")])
    assert ITEM in flow["plan"] and len(flow["plan"]) >= 4
    st = steps_of(flow)
    # research, requirements and code: skipped with the one sentence; no card was opened for them
    for sub in ("research", "req", "code"):
        assert st[sub]["state"] == "skipped", (sub, st[sub]["state"])
        assert (st[sub].get("note") or "").startswith(SENTENCE), st[sub].get("note")
        assert not [q for q in flow["view"]["reviews"] if q["step"] == st[sub]["id"]]
    code = st["code"]["output"]
    assert code["kind"] == "python" and code["verified"] is True and code["application"] == "nvme_hier/near_limit.py"
    assert "this code is part of it (nvme_hier/near_limit.py)" in code["verified_by"] and "nobody approved it here" in code["verified_by"], code["verified_by"]
    assert code["share"]["is_default"] is True and "Nobody set it" in st["code"]["note"]
    with open(code["code_file"], encoding="utf-8") as fh:
        text = fh.read()
    assert text == NL.code_for(None, None) and "near_limit.run_on_tree(tree, out_csv, share=SHARE_PER_CENT, set_by=SET_BY)" in text
    assert os.path.realpath(code["code_file"]).startswith(os.path.realpath(world["root"]) + os.sep)
    # run: the CSV with the 17 columns, written by the application's code runner
    run = st["run"]["output"]
    assert st["run"]["state"] == "done" and run["kind"] == "python" and run["code_file"] == code["code_file"]
    with open(run["output_csv"], newline="", encoding="utf-8") as fh:
        rows = list(csv.reader(fh))
    assert rows[0] == [c for c, _m in NL.OUTPUT_COLUMNS] and len(rows[0]) == 17 and run["columns"] == rows[0]
    assert len(rows) == 1 and run["rows"] == 0                      # nothing is listed on the clean samples at the starting share
    assert os.path.exists(os.path.join(os.path.dirname(run["output_csv"]), "run", "runner.py"))      # the application's normal code runner ran it
    # the Tester passed, on the item's own checks (an empty list is a result, not a failure)
    test = st["test"]["output"]
    assert test["passed"] is True, [c for c in test["checks"] if not c["ok"]]
    assert any("an empty list is a result here, not a failure" in c["detail"] for c in test["checks"])
    assert not any(c["check"] == "the code wrote rows" for c in test["checks"])
    # export, and the result card with the per-kind sentences
    assert st["export"]["state"] == "done" and os.path.exists(st["export"]["output"]["files"]["csv"])
    card = card_of(flow, "result")
    kinds = run["summary"]["summary"]
    assert len(kinds) >= 3 and all(k["words"].startswith("No %s command came closer to the limit than " % k["kind"]) for k in kinds)
    for k in kinds:
        assert "- " + k["words"] in card["body"], k["words"]
    assert "all checks passed" in card["body"] and "SOME CHECKS FAILED" not in card["body"]
    assert "**In plain words:** No command came close to the limit" in card["body"] and "Nobody set it" in card["body"]
    assert "nothing of it is an error" in card["body"] and "no model was asked and no Coder wrote it" in card["body"]
    assert [k["words"] for k in card["data"]["summary"]["kinds"]] == [k["words"] for k in kinds]
    assert card["data"]["defects"] is False and st["result"]["state"] == "approved"
    # analytics: no errors step of its own, nothing in an errors list
    assert "errors" not in st
    if sample == "S17":
        assert run["summary"]["completed_measured"] == 601 and any("292.347 us" in k["words"] for k in kinds)


@pytest.mark.parametrize("sample", ["S08", "S17"])
def test_the_errors_of_the_analysis_are_the_same_with_and_without_the_item(world, sample):
    a, rep_a = errors_of(world["out"]["%s every item" % sample])
    b, rep_b = errors_of(world["out"]["%s without" % sample])
    assert world["out"]["%s without" % sample]["state"] == "finished"
    assert a == b
    assert not any("near_limit" in k for k in a["lists"])
    assert not any("close to the limit" in str(e[0] or "") for e in a["report"])
    mine = [x for x in rep_a["family3"] if x["item"].startswith(ITEM)]
    assert len(mine) == 1 and mine[0]["rows"] == 0 and mine[0]["tester_passed"] is True and mine[0]["error"] is None
    assert not [x for x in rep_b["family3"] if x["item"].startswith(ITEM)]
    if sample == "S17":
        assert a["gate"]["errors"] > 0 and a["report"]            # the sample has timeout errors, and they are all still there


def test_no_model_was_asked_for_the_item_in_any_flow(world):
    calls = world["calls"]
    assert not [a for a in calls if "near_limit" in a], [a for a in calls if "near_limit" in a]
    # the counter does count: the other chosen items were researched and coded by the stand-in
    assert any("command_type_share" in a for a in world["calls_first"]), sorted(set(world["calls_first"]))[:40]


def test_the_three_steps_never_touch_the_runner(world):
    class Boom:
        def __getattr__(self, name):
            raise AssertionError("a step of an item whose code is part of the application reached the engine (%s)" % name)
    sec, lvl, rid = ITEM.split("/")
    for key, fn in (("research", family4._research), ("req", family4._req), ("code", family4._code), ("code", family3._code)):
        ctx = types.SimpleNamespace(params={"section": sec, "level": lvl, "id": rid}, input={}, step={"key": key}, run={"id": 1}, project={}, engine=Boom())
        res = fn(ctx)
        assert res.skip and res.skip.startswith(SENTENCE) and res.review is None, (key, res.skip)
    assert res.output["verified"] is True and os.path.exists(res.output["code_file"])
    # one function answers the question for both kinds of application code
    r = family3.load_rule(sec, lvl, rid)
    assert PR.application_code(r)["what"] == "near_limit" and PR.application_code(r)["file"] == "nvme_hier/near_limit.py"
    det = family3.load_rule("errors", "nvme_command", "cmd_timeout")
    assert PR.application_code(det)["what"] == "detector" and PR.code_state(det)["kind"] == "detector"
    assert PR.application_code(family3.load_rule("analytics", "nvme_command", "command_type_share")) is None
    # a procedure the admin changed would be a rule of its own, coded by the Coder; this one reads the tree, and an item of Data analytics
    # reads one CSV file on its own (2026-11-15): the change is refused with the one sentence, and nothing is stored
    with pytest.raises(ValueError) as e:
        PR.store(json.loads(json.dumps(r)), dict(PR.procedure_of(r), steps=PR.procedure_of(r)["steps"] + ["One more step of the admin's own."]), "admin t")
    assert str(e.value) == PR.ANALYTICS_TREE_REFUSAL


def test_a_changed_share_in_the_plan_reaches_the_code_and_the_result(world):
    flow = world["out"]["S17 changed share"]
    assert flow["state"] == "finished", flow["state"]
    st = steps_of(flow)
    code, run = st["code"]["output"], st["run"]["output"]
    with open(code["code_file"], encoding="utf-8") as fh:
        text = fh.read()
    assert "SHARE_PER_CENT = 0.0005 " in text and "SET_BY = 'admin t'" in text
    assert code["share"]["percent"] == 0.0005 and code["share"]["set_by"] == "admin t" and "set by admin t" in st["code"]["note"]
    assert code["code_file"] != steps_of(world["out"]["S17 every item"])["code"]["output"]["code_file"]        # another share is another text
    assert run["rows"] == 5 and run["summary"]["share"]["percent"] == 0.0005 and run["summary"]["listed"] == 5
    with open(run["output_csv"], newline="", encoding="utf-8") as fh:
        rows = list(csv.reader(fh))
    i = rows[0].index("share of the limit used (per cent)")
    shares = [float(x[i]) for x in rows[1:]]
    assert len(shares) == 5 and shares == sorted(shares, reverse=True) and all(0.0005 <= s < 100 for s in shares)
    assert st["test"]["output"]["passed"] is True, [c for c in st["test"]["output"]["checks"] if not c["ok"]]
    card = card_of(flow, "result")
    assert "set by admin t" in card["body"] and "used 0.0005 per cent of the limit or more" in card["body"]
    # still analytics: five listed commands are not five errors
    gate = next((s for s in flow["view"]["steps"] if s["key"] == "errors_done"), None)
    assert "errors" not in st and not ((gate or {}).get("output") or {}).get("errors")
    assert not [s for s in flow["view"]["steps"] if s["key"].endswith(":errors")]


def test_a_share_that_is_not_a_share_is_refused_at_the_code_step_and_the_flow_says_so(world):
    flow = world["out"]["S08 hostile share"]
    st = steps_of(flow)
    assert flow["state"] == "failed" and st["code"]["state"] == "failed"
    said = (st["code"]["error"] or "").split("\n")[0]            # the step's own sentence (the engine keeps where it stopped under it)
    assert "was not run: what its plan states cannot be used." in said and "is not a number" in said and "State a share of the host's limit" in said
    assert "Traceback" not in said and "Refused" not in said and "RuntimeError" not in said
    now = world["c"].get("/api/agents/runs/%d" % flow["run"]).get_json()
    assert "was not run: what its plan states cannot be used." in (now["run"].get("summary") or "")      # the flow says so
    assert st["research"]["state"] == "skipped" and st["req"]["state"] == "skipped"
    assert st["run"]["state"] not in ("done", "running") and not (st["run"].get("output") or {}).get("output_csv")
    assert not [f for _d, _s, fs in os.walk(world["root"]) for f in fs if f == "taken"]
    state = world["hostile_state"]
    assert state["kind"] == "python" and state["verified"] is False and "is not a number" in state["refused"] and "path" not in state
    # the rules browser with that plan: Run is refused, and Code it gives the refusal in plain words (the run it starts fails at once)
    assert world["hostile_run"][0] == 409
    # every other value that is not a share, at the function that writes the code: refused in words, nothing written
    r = family3.load_rule("analytics", "nvme_command", "near_limit")
    d = os.path.join(family1.knowledge_dir(), "rules_code", "analytics", "nvme_command")
    before = sorted(os.listdir(d))
    for bad in (0, 100, -5, "many", True, [1], float("inf"), float("nan"), 10 ** 400, {"a": 1}, "50; import os", "1e999"):
        with pytest.raises(ValueError) as e:
            PR.application_code_file(dict(r, plan={"share_percent": bad, "share_set_by": "admin t"}))
        assert "was not run" in str(e.value) and "State a share of the host's limit as a number above 0 and below 100" in str(e.value), (bad, str(e.value))
    with pytest.raises(ValueError):
        PR.application_code_file(dict(r, plan={"share_percent": 80, "share_set_by": {"x": 1}}))
    assert sorted(os.listdir(d)) == before
    # a name that tries to leave its quotes stays a text in the code
    out = PR.application_code_file(dict(r, plan={"share_percent": "80 %", "share_set_by": "x'\nimport os\n'"}))
    with open(out["code_file"], encoding="utf-8") as fh:
        text = fh.read()
    assert PR.check_code(text, tree=True) == [] and "\nimport os" not in text and out["share"]["percent"] == 80.0
    os.remove(out["code_file"])


def wait(c, rid, limit=120, approve=None):
    t0 = time.time()
    while time.time() - t0 < limit:
        v = c.get("/api/agents/runs/%d" % rid).get_json()
        if v["run"]["state"] != "running" or [s for s in v["steps"] if s["state"] == "failed"]:
            return v
        rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
        if rv is not None and approve:
            c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t", "edits": None})
        time.sleep(0.2)
    return c.get("/api/agents/runs/%d" % rid).get_json()


def test_the_rules_browser_answers_for_application_code(world):
    c, calls = world["c"], world["calls"]
    project = world["out"]["S08 every item"]["project"]
    n0 = len(calls)
    # the item as the browser shows it: verified code, with the reason
    r = family3.load_rule(*ITEM.split("/"))
    st = PR.code_state(r)
    assert st["kind"] == "python" and st["verified"] is True and "this code is part of it (nvme_hier/near_limit.py)" in st["verified_by"]
    listed = next(i for s in family3.tree() if s["section"] == "analytics" for lv in s["levels"] for i in lv["items"] if i["id"] == "near_limit")
    assert listed["code"] == "verified"
    # Code it: a plain sentence, no Coder
    x = c.post("/api/agents/rules/%s/code" % ITEM, json={"project": project, "admin": "t"})
    assert x.status_code == 409 and x.get_json()["error"] == "the code of this version is already verified"
    # Run: the application's own code on the recording, checked and exported
    x = c.post("/api/agents/rules/%s/run" % ITEM, json={"project": project, "admin": "t"})
    assert x.status_code == 200, x.get_json()
    v = wait(c, x.get_json()["run"])
    S = {s["key"]: s for s in v["steps"]}
    assert v["run"]["state"] == "finished", [(s["key"], s["state"], s.get("error")) for s in v["steps"]]
    assert S["code"]["state"] == "skipped" and S["code"]["note"].startswith(SENTENCE)
    assert S["run"]["output"]["rows"] == 0 and S["run"]["output"]["columns"] == [c_ for c_, _m in NL.OUTPUT_COLUMNS] and S["test"]["output"]["passed"] is True
    # Proceed: the same, with the result card
    x = c.post("/api/agents/rules/%s/proceed" % ITEM, json={"project": project, "admin": "t"})
    assert x.status_code == 200, x.get_json()
    v = wait(c, x.get_json()["run"], approve=True)
    S = {s["key"]: s for s in v["steps"]}
    assert v["run"]["state"] == "finished", [(s["key"], s["state"], s.get("error")) for s in v["steps"]]
    card = next(q for q in v["reviews"] if q["step"] == S["result"]["id"])
    assert "came closer to the limit than" in card["body"] and "all checks passed" in card["body"]
    assert not [a for a in calls[n0:] if "near_limit" in a]
    # with a share that is not a share: Code it starts a run that stops at once with the refusal in plain words (no Coder is asked)
    set_plan(share_percent=HOSTILE, share_set_by="admin t")
    try:
        x = c.post("/api/agents/rules/%s/code" % ITEM, json={"project": project, "admin": "t"})
        assert x.status_code == 200, x.get_json()
        v = wait(c, x.get_json()["run"])
        assert [s for s in v["steps"] if s["state"] == "failed" and "is not a number" in (s.get("error") or "").split("\n")[0]], [(s["key"], s["state"], s.get("error")) for s in v["steps"]]
        assert not [a for a in calls[n0:] if "near_limit" in a]
    finally:
        set_plan(**json.loads(json.dumps(NL.ITEM["plan"])))
