"""Browser check: every page of the application can reach the terminal agent (headless Chrome, port 9333). Read-only:
no question is asked, so no terminal program is started.

    python3 tests/ui_smoke_terminal.py

(owner, 2026-11-14: "each and every page should have communication with the terminal agent".) On each page: the button is
there and can be seen, a click opens the panel, the panel says which session the questions of this page go to (the
analysis the page shows, the analysis the recording on it belongs to, or the application), the question box is there with
its line saying what is sent, Escape closes the panel, and the page has no script error from it.

Then (owner, 2026-11-15), when a card waits for a decision: the card has the button "Ask the terminal agent about this
card", the panel opens for the card's analysis with the card attached and the question box empty, nothing is asked by
that, and the card can be taken off (card_checks).
"""
import json
import os
import socket
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ui_smoke_hier import Chrome   # noqa: E402

BASE = "http://127.0.0.1:8077"
R = {"pass": 0, "fail": 0}


def check(name, ok, detail=""):
    R["pass" if ok else "fail"] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:220]) if detail != "" else ""), flush=True)


def get(path):
    with urllib.request.urlopen(BASE + path, timeout=30) as r:
        return json.loads(r.read())


def card_checks(c):
    """A review card of the flow page and the terminal agent (owner, 2026-11-15: "make a connection between your terminal
    code and ... that open code one"). Read-only: the button is pressed, the panel is looked at, the card is taken off;
    no question is asked, nothing is written into a comment box that is kept, nothing is decided."""
    waiting = [r for r in get("/api/agents/reviews?state=open") if r.get("project")]
    if not waiting:
        print("SKIP  no card waits for a decision in any analysis: the button on a review card could not be looked at", flush=True)
        return
    r = waiting[0]
    place = get("/api/agents/terminal?pid=%d" % r["project"])
    asked_before = len(place.get("conversation") or [])
    c.errors.clear()
    found = None
    for address in ("/#/run/%d" % r["run"], "/#/p/%d" % r["project"]):
        c.goto(BASE + address)
        for _ in range(24):
            time.sleep(0.25)
            found = c.js("(() => { const b = document.querySelector('#rv%d [data-terminal-card]'); if (!b) return null; const q = b.getBoundingClientRect(); "
                         "return {text: b.innerText.trim(), n: b.dataset.terminalCard, title: b.title, w: q.width, h: q.height, cards: document.querySelectorAll('section.review[data-review]').length, "
                         "buttons: document.querySelectorAll('section.review[data-review] [data-terminal-card]').length, box: !!document.getElementById('cm%d')}; })()" % (r["id"], r["id"]))
            if found:
                break
        if found:
            break
    check("a review card of the flow page has the button 'Ask the terminal agent about this card' with a title in plain words",
          bool(found) and found["text"] == "Ask the terminal agent about this card" and found["n"] == str(r["id"]) and found["w"] > 40 and found["h"] > 14
          and "opencode program in a terminal" in found["title"] and "Nothing is asked until you write a question" in found["title"], found)
    if not found:
        return
    check("every review card on the page has the button once", found["cards"] == found["buttons"] and found["box"], found)
    c.js("document.getElementById('cm%d').value = ''" % r["id"])
    c.js("document.querySelector('#rv%d [data-terminal-card]').click()" % r["id"])
    text = ""
    for _ in range(40):
        time.sleep(0.25)
        text = c.js("(document.getElementById('ta-body') || {}).innerText") or ""
        if "Your question" in text or "not ready" in text:
            break
    panel = c.js("(() => { const k = document.getElementById('ta-card'), q = document.getElementById('ta-q'); return {card: k ? k.innerText : '', box: q ? q.value : null, "
                 "off: !!document.getElementById('ta-card-off'), why: k && k.querySelector('.ta-why') ? k.querySelector('.ta-why').innerText.length : 0, "
                 "wide: document.documentElement.scrollWidth <= innerWidth + 1 || document.getElementById('ta-panel').getBoundingClientRect().right <= innerWidth + 1}; })()") or {}
    check("the button opens the panel for the card's own analysis", "This page belongs to analysis %d" % r["project"] in text, text[:160])
    check("the panel shows the attached card in one line, with why and a way to take it off",
          panel.get("card", "").startswith("This question is about the card: ") and panel.get("off") and panel.get("why", 0) > 60 and panel.get("wide"), panel)
    check("the question box is empty: no question is written for the admin", panel.get("box") == "", panel.get("box"))
    time.sleep(2.5)
    after = get("/api/agents/terminal?pid=%d" % r["project"])
    check("nothing was asked by pressing the button", len(after.get("conversation") or []) == asked_before and not after.get("running"), (asked_before, len(after.get("conversation") or [])))
    ctx = c.js("JSON.stringify(window.F2TTerminal.context())")
    check("the page's own context is as before (the card's number is added only to a question that is sent)", "review" not in (json.loads(ctx) if ctx else {"review": 1}), ctx)
    check("window.F2TTerminal can open the panel with a card attached, and open, close and context are still there",
          c.js("['open', 'close', 'context', 'openCard'].every(k => typeof window.F2TTerminal[k] === 'function')") is True)
    # an earlier answer about this very card offers to go into the card's comment box; one about no card, or a card not on the screen, does not
    puts = c.js("(() => [...document.querySelectorAll('#ta-panel [data-ta-put]')].map(b => b.innerText.trim()))()") or []
    about = [t for t in (after.get("conversation") or []) if t.get("ok") and (t.get("card") or {}).get("review") == r["id"]]
    check("'Put this answer into my comment on the card' is offered exactly under the answers that were about a card on the screen",
          len(puts) == len(about) and all(p == "Put this answer into my comment on the card" for p in puts), (len(puts), len(about)))
    if puts:
        c.js("document.querySelector('#ta-panel [data-ta-put]').click()")
        time.sleep(0.3)
        put = c.js("(() => ({box: document.getElementById('cm%d').value.length, msg: (document.querySelector('#ta-panel [id^=ta-put-]') || {}).innerText || ''}))()" % r["id"]) or {}
        check("the answer is written into the card's own comment box, and the panel says that nothing was sent or approved",
              put.get("box", 0) > 0 and "Nothing was sent and nothing was approved" in put.get("msg", ""), put)
        still = next((x for x in get("/api/agents/reviews?state=open") if x["id"] == r["id"]), None)
        check("the card still waits for the admin's decision, without a comment stored", bool(still) and not still.get("comment"), still)
        c.js("document.getElementById('cm%d').value = ''" % r["id"])           # the check leaves the comment box as it found it
    c.js("document.getElementById('ta-card-off').click()")
    time.sleep(1.0)
    check("'Take the card off' removes the line; the panel stays open for the same analysis",
          c.js("!document.getElementById('ta-card') && !!document.getElementById('ta-q')") is True)
    c.js("document.dispatchEvent(new KeyboardEvent('keydown', {key: 'Escape'}))")
    time.sleep(0.2)
    mine = [e for e in c.errors if "terminal" in e.lower() or "ta-" in e]
    check("no script error or failed request from the card's button and the panel", not mine, mine[:2])


def folder_checks(c):
    """(2026-11-15) F2TTerminal.openFolder: the panel for a throw-away folder, before an analysis exists. Only the state is
    read (nothing is asked): the panel names the folder, the question box is empty, and no question was sent."""
    import shutil
    import tempfile
    d = os.path.realpath(tempfile.mkdtemp(prefix="ui_smoke_folder_"))       # the panel names the folder by its real path (a temporary folder can be a link)
    try:
        with open(os.path.join(d, "trace.etl"), "wb") as fh:
            fh.write(b"\x00\x01")
        c.goto(BASE + "/#/")
        time.sleep(2.0)
        check("the start page offers F2TTerminal.openFolder", c.js("typeof (window.F2TTerminal || {}).openFolder === 'function'") is True)
        c.js("window.F2TTerminal.openFolder(%s)" % json.dumps(d))
        text = ""
        for _ in range(40):
            time.sleep(0.25)
            text = c.js("(document.getElementById('ta-body') || {}).innerText") or ""
            if "Your question" in text or "not ready" in text:
                break
        check("the panel says it asks about the folder, before an analysis exists", ("This page asks about the folder %s, before an analysis exists" % d) in text, text[:200])
        check("the question box is empty and nothing was asked", c.js("(document.getElementById('ta-q') || {}).value") == "" and "Question 1" not in text, text[:200])
        c.js("document.dispatchEvent(new KeyboardEvent('keydown', {key: 'Escape'}))")
        time.sleep(0.2)
        mine = [e for e in c.errors if "terminal" in e.lower() or "ta-" in e]
        check("no script error or failed request from the folder's panel", not mine, mine[:2])
    finally:
        shutil.rmtree(d, ignore_errors=True)


def main():
    with socket.socket() as sk:
        if sk.connect_ex(("127.0.0.1", 9333)) == 0:
            sys.exit("port 9333 is busy (another headless Chrome)")
    projects = get("/api/agents/state").get("projects") or []
    linked = next((p for p in projects if p.get("upload_id")), None)
    first = projects[0] if projects else None
    # (address, what it is, the place its questions must go to: "application", or the analysis number)
    pages = [("/#/", "the start page", "application"), ("/#/library", "the rules library", None), ("/packets", "the packet workflow", "application"),
             ("/db", "the stored data", "application"), ("/defect", "the defect page", "application"), ("/hier", "the tree pages", "application"),
             ("/nvme-errors", "the NVMe command errors", "application"), ("/nvme-rules", "the NVMe command rules", "application"),
             ("/how", "the guide", "application"), ("/static/how_joins.html", "how the joins work", "application"),
             ("/static/how_files.html", "how the files are read", "application"), ("/static/how_grouping.html", "how grouping works", "application"),
             ("/static/how_isolate.html", "how isolation works", "application"), ("/static/how_rules.html", "how the rules work", "application")]
    if first:
        pages.append(("/#/p/%d" % first["id"], "a page of analysis %d" % first["id"], first["id"]))
    if linked:
        pages.append(("/isolate?upload=%s&finding=1" % linked["upload_id"], "the page of one error of analysis %d's recording" % linked["id"], linked["id"]))
        pages.append(("/hier?upload=%s" % linked["upload_id"], "the tree page of analysis %d's recording" % linked["id"], linked["id"]))
    c = Chrome()
    try:
        for address, what, place in pages:
            c.errors.clear()
            c.goto(BASE + address)
            time.sleep(2.0)
            btn = c.js("(() => { const b = document.getElementById('ta-btn') || document.getElementById('inv-btn'); if (!b) return null; const r = b.getBoundingClientRect(); "
                       "return {id: b.id, text: b.innerText.trim(), hidden: b.hidden, w: r.width, h: r.height, in: r.right <= innerWidth + 1 && r.bottom <= innerHeight + 1 && r.left >= 0 && r.top >= 0}; })()")
            check("%s (%s): the Terminal agent button is there and can be seen" % (what, address),
                  bool(btn) and not btn["hidden"] and btn["w"] > 20 and btn["h"] > 20 and btn["in"] and "Terminal agent" in btn["text"], btn)
            if not btn:
                continue
            before = c.js("document.documentElement.scrollWidth") or 0        # a page may be wider than the window by itself (a wide table)
            c.js("document.getElementById('%s').click()" % btn["id"])
            text = ""
            for _ in range(40):
                time.sleep(0.25)
                text = c.js("(document.getElementById('ta-body') || {}).innerText") or ""
                if "Your question" in text or "not ready" in text:
                    break
            says = ("This page shows no single analysis" in text) if place == "application" else ("This page belongs to analysis %s" % place in text) if place else \
                ("This page shows no single analysis" in text or "This page belongs to analysis" in text)
            check("%s: the panel opens and says which session the questions go to" % what, says, text[:160])
            box = c.js("(() => { const q = document.getElementById('ta-q'), w = document.querySelector('#ta-panel .ta-why'); "
                       "return {box: !!q, why: w ? w.innerText.length : 0, send: !!document.getElementById('ta-send'), wide: document.documentElement.scrollWidth <= Math.max(innerWidth, %d) + 1}; })()" % before) or {}
            check("%s: the question box, its line saying what is sent, and the Ask button are there; the panel does not make the page wider" % what,
                  box.get("box") and box.get("why", 0) > 40 and box.get("send") and box.get("wide"), box)
            ctx = c.js("JSON.stringify(window.F2TTerminal.context())")
            ctx = json.loads(ctx) if ctx else {}
            check("%s: the page says where the admin is (path and address)" % what, ctx.get("path") == address.split("?")[0].split("#")[0] and ctx.get("address", "").startswith(ctx.get("path", "?")), ctx)
            c.js("document.dispatchEvent(new KeyboardEvent('keydown', {key: 'Escape'}))")
            time.sleep(0.2)
            check("%s: Escape closes the panel" % what, c.js("!document.getElementById('ta-panel')") is True)
            mine = [e for e in c.errors if "terminal" in e.lower() or "ta-" in e]
            check("%s: no script error or failed request from the terminal agent" % what, not mine, mine[:2])
        card_checks(c)
        folder_checks(c)
        c.goto(BASE + "/packets")
        time.sleep(1.5)
        c.js("document.getElementById('ta-btn').click()")
        time.sleep(1.5)
        print("screenshot:", c.shot("terminal_agent_panel"))
    finally:
        c.close()
    print("%d checks, %d failed" % (R["pass"] + R["fail"], R["fail"]))
    sys.exit(1 if R["fail"] else 0)


if __name__ == "__main__":
    main()
