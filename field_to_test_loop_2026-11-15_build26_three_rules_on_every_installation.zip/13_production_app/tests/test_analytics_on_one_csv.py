"""Data analytics reads one CSV file on its own, never the tree (owner, 2026-11-15: "it's okay to work only on the individual CSV ... these
rules will be determined by the admin ... convert that to only for the individual CSV, not for the tree").

    python3 -m pytest -q -p no:cacheprovider tests/test_analytics_on_one_csv.py

What is checked, on throw-away folders (nothing of the application's own db/, runs/, uploads/ or knowledge/ is read or written):
  - the two kept built-in items (command type percentages, read patterns) read nvme_command.csv only, with its own column names, and the
    stand-in code reads that one file as it is written (agentic/csv_dialect.py), line by line
  - on the sample S17 they give the same numbers from the file as the tree's own count gave (the plan's SQL on the tree's database),
    also when the file is written with semicolons in UTF-16 with two lines above the header
  - "Commands that completed but came close to the limit" needs the completion time, which the NVMe command file does not carry: a new
    installation starts it in Deleted items with the reason; a deleted seed stays deleted; Restore brings it back
  - a Data analytics procedure that reads the tree is refused with the one sentence (store, the code check, the Rule writer, the plan)
  - an Errors item still reads the tree
  - the section's text and the kind's text under Data analytics (server and page)
  - a whole stand-in flow on S17 with the two analytics items and the timeout rule finishes, and the analytics items' code reads the file
"""
import csv
import importlib.util
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import time
import types

import pytest

os.environ.setdefault("F2T_WORKERS", "1")
APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for _p in (APP, os.path.join(APP, "app"), os.path.join(APP, "tests")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from agentic import core, family1, family3, pipeline, procedures as PR, rule_hierarchy as RH      # noqa: E402
from nvme_hier import builder as B, loader as L, near_limit as NL                                   # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
FIVE = {"nvme_command": "nvme_command.csv", "nvme_transaction": "NVME_Transactions.csv", "split": "split.csv", "link": "link.csv", "packets": "packets.csv"}
SHARE, READS, TIMEOUT = "analytics/nvme_command/command_type_share", "analytics/nvme_command/read_pattern", "errors/nvme_command/cmd_timeout"
SECTION_LINE = "Each rule reads one CSV file of the recording on its own; the tree is not used here."
KIND_ANALYTICS = "The five files the Teledyne LeCroy analyzer exports from one recording. " + SECTION_LINE
KIND_ERRORS = "The five files the Teledyne LeCroy analyzer exports from one recording. Their rules can read the tree that joins the five files."
# the numbers of S17 (counted on the tree before 2026-11-15, and by the file now)
S17_TYPES = [("Read", 360, 59.211), ("Write", 179, 29.441), ("Create I/O Completion Queue (admin)", 17, 2.796), ("Create I/O Submission Queue (admin)", 17, 2.796),
             ("Identify (admin)", 15, 2.467), ("Abort (admin)", 5, 0.822), ("Set Features (admin)", 5, 0.822), ("Delete I/O Completion Queue (admin)", 4, 0.658),
             ("Delete I/O Submission Queue (admin)", 4, 0.658), ("Flush", 2, 0.329)]
S17_READS = [("sequential read", 260, 72.222), ("random read (RndRead)", 99, 27.5), ("first read of its namespace", 1, 0.278)]
TREE_PLANS = {"command_type_share": {"kind": "distribution", "plan": {"table": "cmd", "label": {"expr": "opcode_name"}, "filter": [], "measure": "percent"}},
              "read_pattern": {"kind": "read_pattern", "plan": {"opcode": 2, "partition": ["nsid"], "gap_blocks": 0}}}
needs_s17 = pytest.mark.skipif(not os.path.isdir(S17), reason="the S17 sample recording is not on this machine (the code-only zip carries no samples)")


@pytest.fixture
def knowledge(tmp_path, monkeypatch):
    """A rules library of its own: a new installation."""
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path))
    family3._SECTIONS_SEEN[0] = None
    yield tmp_path
    family3._SECTIONS_SEEN[0] = None


def run_text(code, sources, out_csv, tmp):
    """The code text run in this process (the same run(sources, out_csv) the code runner calls) -> the result rows, typed."""
    f = os.path.join(str(tmp), "code_%d.py" % abs(hash(code)))
    with open(f, "w", encoding="utf-8") as fh:
        fh.write(code)
    spec = importlib.util.spec_from_file_location("analytics_code_%d" % abs(hash(code)), f)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    m.run(sources, out_csv)
    with open(out_csv, newline="", encoding="utf-8") as fh:
        rows = list(csv.reader(fh))
    return rows[0], [(a, int(b), float(c)) for a, b, c in rows[1:]]


@pytest.fixture(scope="module")
def tree_db():
    if not os.path.isdir(S17):
        pytest.skip("no S17")
    d = tempfile.mkdtemp(prefix="analytics_tree_")
    db = os.path.join(d, "hier.sqlite")
    L.load_upload(db, {k: os.path.join(S17, n) for k, n in FIVE.items()})
    B.build(db)
    yield db
    shutil.rmtree(d, ignore_errors=True)


# ---------------------------------------------------------------------------------------------- the built-in items
def test_the_two_kept_items_read_nvme_command_csv_only_with_its_own_column_names(knowledge):
    family3.tree()
    with open(os.path.join(S17, "nvme_command.csv"), newline="", encoding="utf-8-sig") if os.path.isdir(S17) else open(os.devnull) as fh:
        head = next(csv.reader(fh), [])
    for rid in ("command_type_share", "read_pattern"):
        r = family3.load_rule("analytics", "nvme_command", rid)
        proc = PR.procedure_of(r)
        assert [s["file"] for s in proc["source_data"]] == ["nvme_command.csv"] and not PR.uses_tree(proc) and not family3.needs_tree(r)
        assert proc["steps"][0] == PR.ONE_FILE_STEP and "the tree is not used" in proc["steps"][0]
        assert all(":" not in c for c in proc["source_data"][0]["columns"])          # named as in the file, not "nvme_command: OPC"
        if head:
            assert all(c in head for c in proc["source_data"][0]["columns"]), [c for c in proc["source_data"][0]["columns"] if c not in head]
        assert PR.analytics_tree_problem(r, proc) == "" and pipeline.cannot_run_here(r, False, {"nvme_command.csv": "x"}) == ""
        code = PR.standin_code(r, proc, {})
        assert 'sources["nvme_command.csv"]' in code and "def run(sources, out_csv):" in code and "tree" not in code.replace("the tree is not used", "")
        assert PR.check_code(code, analytics=True) == []
    # the near-limit item is not one of them: its procedure reads the tree, so it is not offered under Data analytics
    assert PR.uses_tree(PR.TREE_SEEDS["near_limit"])
    assert not [i for s in family3.tree() if s["section"] == "analytics" for lv in s["levels"] for i in lv["items"] if i["id"] == "near_limit"]


def test_a_seed_nobody_coded_takes_the_new_wording_as_a_new_version_and_a_coded_one_is_kept(knowledge):
    old_steps = ["Read nvme_command.csv row by row. Find each column by its exact header name (first match)."] + PR.SEEDS["command_type_share"]["steps"][1:]
    for rid, coded in (("command_type_share", False), ("read_pattern", True)):
        r = {"id": rid, "section": "analytics", "level": "nvme_command", "name": rid, "kind": "x", "status": "draft", "version": 0, "history": [],
             "procedure": dict(PR.SEEDS[rid], steps=old_steps, version=1, edited_by=PR.SEED_MARK)}
        if coded:
            r["code"], r["coded_from_sha"] = {"path": "/x.py", "procedure_version": 1}, "abc"
        family3.save_rule(r)
    family3.seed()
    a, b = family3.load_rule("analytics", "nvme_command", "command_type_share"), family3.load_rule("analytics", "nvme_command", "read_pattern")
    assert a["procedure"]["version"] == 2 and a["procedure"]["steps"] == PR.SEEDS["command_type_share"]["steps"]
    assert PR.code_state(a)["verified"] is False and PR.code_state(a)["procedure_version"] == 2           # its code is made again
    assert b["procedure"]["version"] == 1 and b["procedure"]["steps"] == old_steps                          # coded: never reworded


@needs_s17
@pytest.mark.parametrize("rid,expected", [("command_type_share", S17_TYPES), ("read_pattern", S17_READS)])
def test_the_numbers_from_the_file_are_the_numbers_the_tree_gave(tree_db, tmp_path, rid, expected):
    sql, params, _p, _pp = family3.compile_rule(TREE_PLANS[rid])
    con = sqlite3.connect("file:%s?mode=ro" % tree_db, uri=True)
    try:
        by_tree = [tuple(x) for x in con.execute(sql, params).fetchall()]
    finally:
        con.close()
    src = os.path.join(S17, "nvme_command.csv")
    head, by_file = run_text(PR.standin_code({"id": rid, "section": "analytics"}, PR.SEEDS[rid], PR.forms_of(PR.SEEDS[rid], {"nvme_command.csv": src})),
                             {"nvme_command.csv": src}, str(tmp_path / "out.csv"), tmp_path)
    assert by_file == expected and sorted(by_tree) == sorted(by_file)
    assert head == PR.SEEDS[rid]["output"]["columns"]
    # the same file written another way (semicolons, UTF-16, two lines above the header): read as it is written, the same numbers
    other = str(tmp_path / "nvme_command.csv")
    with open(src, newline="", encoding="utf-8-sig") as fi, open(other, "w", newline="", encoding="utf-16") as fo:
        fo.write("exported by a tool\r\nsecond line above the header\r\n")
        w = csv.writer(fo, delimiter=";")
        for row in csv.reader(fi):
            w.writerow(row)
    forms = PR.forms_of(PR.SEEDS[rid], {"nvme_command.csv": other})
    assert forms["nvme_command.csv"]["separator"] == ";" and forms["nvme_command.csv"]["header_line"] == 3
    code = PR.standin_code({"id": rid, "section": "analytics"}, PR.SEEDS[rid], forms)
    assert PR.check_code(code, analytics=True) == []
    _h, again = run_text(code, {"nvme_command.csv": other}, str(tmp_path / "out2.csv"), tmp_path)
    assert again == expected


def test_the_read_pattern_code_streams_and_stops_in_words_on_a_file_that_is_not_in_time_order(tmp_path):
    src = str(tmp_path / "nvme_command.csv")
    with open(src, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["OPC", "SQID", "NSID", "SLBA", "NLB", "Time Stamp"])
        w.writerows([["0x02 (Read)", "1", "1", "0", "7", "0000.000000000100s"], ["0x02 (Read)", "1", "1", "8", "7", "0000.000000000200s"],
                     ["0x02 (Read)", "1", "1", "100", "0", "0000.000000000150s"]])
    code = PR.standin_code({"id": "read_pattern", "section": "analytics"}, PR.SEEDS["read_pattern"], {})
    assert "by_ns" not in code and ".sort(" not in code and "prev[ns] = (t, slba, nlb)" in code         # only the previous read of each namespace is kept
    with pytest.raises(ValueError) as e:
        run_text(code, {"nvme_command.csv": src}, str(tmp_path / "o.csv"), tmp_path)
    assert "is not in time order" in str(e.value) and "row 3" in str(e.value)


# ---------------------------------------------------------------------------------------------- the near-limit item
def test_near_limit_cannot_be_one_csv_and_a_new_installation_starts_it_in_deleted_items(knowledge):
    # the NVMe command file carries no completion time: Time Stamp (when the command was sent) and Time Delta (the time since the previous row)
    with open(os.path.join(APP, "data", "lecroy_real_headers.json"), encoding="utf-8") as fh:
        real = json.load(fh)["files"]["nvme_command.csv"][0]
    cols = [str(c) for c in real["header"]] + [str(c) for c in real["columns"].values()]
    if os.path.isdir(S17):
        with open(os.path.join(S17, "nvme_command.csv"), newline="", encoding="utf-8-sig") as fh:
            cols += next(csv.reader(fh))
    timing = [c for c in cols if any(w in c.lower() for w in ("latency", "duration", "complet", "elapsed", "response", "end time"))]
    assert not timing, timing
    assert "Time Stamp" in cols and "Time Delta" in cols
    assert NL.PROCEDURE["source_data"][0]["file"] == PR.TREE and "nvme_transaction: Time Stamp" in NL.PROCEDURE["source_data"][0]["columns"]
    family3.tree()
    assert family3.load_rule("analytics", "nvme_command", "near_limit") is None
    gone = {(x["section"], x["level"], x["id"]): x for x in family3.deleted_items()}
    e = gone[("analytics", "nvme_command", "near_limit")]
    assert e["why"] == ("it needs the completion time, which is in the NVMe transaction file, not in the NVMe command file; the owner keeps "
                        "Data analytics on one CSV file") and e["by"] in family3.INSTALLATION_BY and e["detector"] is False
    family3.tree()
    family3.seed()
    assert family3.load_rule("analytics", "nvme_command", "near_limit") is None             # a deleted seed stays deleted
    assert len([x for x in family3._register() if x["id"] == "near_limit"]) == 1            # and is not put there twice
    r = family3.restore_item("analytics", "nvme_command", "near_limit", "Sagar")            # Restore brings it back, as it was seeded
    assert r["kind"] == "near_limit" and r["name"] == NL.ITEM["name"]
    family3.delete_item("analytics", "nvme_command", "near_limit", "Sagar", family3.NEAR_LIMIT_DELETED_WHY)    # the application's own delete path
    family3.seed()
    assert family3.load_rule("analytics", "nvme_command", "near_limit") is None


def test_an_installation_that_holds_the_near_limit_item_keeps_it_until_the_admin_deletes_it(knowledge):
    family3.save_rule(dict(json.loads(json.dumps(NL.ITEM)), status="draft", version=0, history=[]))
    family3.seed()
    assert family3.load_rule("analytics", "nvme_command", "near_limit") is not None
    assert not [x for x in family3.deleted_items() if x["id"] == "near_limit"]


# ---------------------------------------------------------------------------------------------- the refusal
def tree_proc():
    return {"source_data": [{"file": PR.TREE, "columns": ["nvme_command: OPC", "nvme_transaction: Type"]}],
            "steps": ["Walk the commands of the tree and their NVMe transactions."], "output": {"columns": ["command type", "count"], "order": ""}, "open_questions": []}


def test_a_data_analytics_procedure_that_reads_the_tree_is_refused_with_the_sentence(knowledge):
    r = family3.add_item("analytics", "nvme_command", "commands with their transactions", "joined", "Sagar")
    with pytest.raises(ValueError) as e:
        PR.store(r, tree_proc(), "Sagar")
    assert str(e.value) == PR.ANALYTICS_TREE_REFUSAL
    assert PR.ANALYTICS_TREE_REFUSAL == ("A rule of Data analytics reads one CSV file of the recording on its own, never the tree: name the level's own file "
                                         "(for example nvme_command.csv) as its source data, with the columns as that file names them.")
    tree_code = PR.standin_tree_rows_code(PR.standin_tree_rows("nvme_command", [("OPC", "0x02 (Read)")]))
    assert PR.check_code(tree_code, tree=True, analytics=True)[0] == PR.ANALYTICS_TREE_REFUSAL
    assert PR.check_code(tree_code, tree=True) == []                                         # the same code is fine for an Errors item
    # an item written on the tree before the change: the plan does not run it, and says what to do
    family3.save_rule(dict(r, procedure=dict(tree_proc(), version=1, edited_by="Sagar")))
    r2 = family3.load_rule("analytics", "nvme_command", r["id"])
    assert pipeline.cannot_run_here(r2, True, {}) == pipeline.ANALYTICS_ON_TREE_ITEM
    with pytest.raises(RuntimeError) as e:
        family3._code(types.SimpleNamespace(params={"section": "analytics", "level": "nvme_command", "id": r["id"]}, input={}, step={"key": "code"}, run={"id": 1}, project={}))
    assert str(e.value) == PR.ANALYTICS_TREE_REFUSAL


class Runner:
    """The model's place: the Rule writer's answer is given here, and what it was told is kept."""
    def __init__(self, answer):
        self.answer, self.told = answer, []

    def ask(self, run_id, agent, instruction, context, shape, what, standin, **k):
        self.told.append((instruction, context))
        return self.answer, "a model (the test's)", None


def writer_ctx(section, rid, answer, folder):
    eng = types.SimpleNamespace(runner=Runner(answer), store=types.SimpleNamespace(one=lambda *a, **k: None))
    return types.SimpleNamespace(params={"section": section, "level": "nvme_command", "id": rid, "message": "count by command type and transaction type"},
                                 input={}, step={"key": "write"}, run={"id": 1}, project={"folder": folder, "admin": "Sagar"}, engine=eng)


def test_the_rule_writer_is_told_one_file_and_its_tree_procedure_is_refused_while_errors_keep_the_tree(knowledge, tmp_path):
    folder = str(tmp_path / "rec")
    os.makedirs(folder)
    with open(os.path.join(folder, "nvme_command.csv"), "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows([["OPC", "SQID"], ["0x02 (Read)", "1"]])
    a = family3.add_item("analytics", "nvme_command", "joined counts", "count by command type and transaction type", "Sagar")
    ctx = writer_ctx("analytics", a["id"], {"procedure": tree_proc(), "answers": []}, folder)
    res = family3._write(ctx)
    assert res.output["procedure"] is None and res.output["problem"] == PR.ANALYTICS_TREE_REFUSAL
    instruction, context = ctx.engine.runner.told[0]
    assert "AN ITEM OF THE SECTION DATA ANALYTICS" in instruction
    assert '"file": "nvme_command.csv"' in context["item"]["ONE_FILE_ONLY"] and "never the tree" in context["item"]["ONE_FILE_ONLY"]
    assert context["THE_TREE"].startswith("not used for this item")
    assert {f["file"] for f in context["FILES"]} == {"nvme_command.csv"}             # only the level's own file is offered
    # written on the file, the same item is fine
    good = {"procedure": {"source_data": [{"file": "nvme_command.csv", "columns": ["OPC"]}], "steps": ["Read nvme_command.csv on its own."],
                          "output": {"columns": ["OPC", "count", "percent"], "order": ""}, "open_questions": []}, "answers": []}
    assert family3._write(writer_ctx("analytics", a["id"], good, folder)).output["problem"] == ""
    # an Errors item is not concerned: it is not told so, and a procedure on the tree is stored
    e = family3.add_item("errors", "nvme_command", "reads on queue one", "rows where SQID is 1", "Sagar")
    ectx = writer_ctx("errors", e["id"], {"procedure": tree_proc(), "answers": []}, folder)
    family3._write(ectx)
    assert "ONE_FILE_ONLY" not in ectx.engine.runner.told[0][1]["item"]
    stored, changed = PR.store(family3.load_rule("errors", "nvme_command", e["id"]), PR.standin_tree_rows("nvme_command", [("SQID", "1")]), "Sagar")
    assert changed and PR.uses_tree(stored["procedure"]) and family3.needs_tree(stored) and PR.analytics_tree_problem(stored, stored["procedure"]) == ""
    family3.tree()
    t = family3.load_rule("errors", "nvme_command", "cmd_timeout")
    assert PR.code_state(t)["kind"] == "detector" and family3.needs_tree(t)                   # the detector's rule reads the tree, as before


# ---------------------------------------------------------------------------------------------- the texts
def test_the_section_and_the_kind_say_it_on_page_3_and_in_the_rules_library(knowledge):
    family3.tree()
    assert SECTION_LINE in family3.SECTION_INFO["analytics"]["about"] and "tree" not in family3.SECTION_INFO["errors"]["about"].replace("isolation", "")
    h = RH.hierarchy()
    sec = {s["section"]: s for s in h["sections"]}
    lecroy = lambda s: next(k for k in sec[s]["kinds"] if k["kind"] == RH.LECROY)          # noqa: E731
    assert lecroy("analytics")["about"] == KIND_ANALYTICS and "Their rules can read the tree" not in lecroy("analytics")["about"]
    assert lecroy("errors")["about"] == KIND_ERRORS
    assert pipeline.item_steps("analytics", "nvme_command", "x", "X", False)[-4]["title"].endswith("run on its own CSV file")
    assert any(s["title"].endswith("run on the tree") for s in pipeline.item_steps("errors", "nvme_command", "x", "X", False))
    with open(os.path.join(APP, "app", "static", "js", "agents.js"), encoding="utf-8") as fh:
        js = fh.read()
    assert 'analytics_about: "%s"' % KIND_ANALYTICS in js and 'about: "%s"' % KIND_ERRORS in js
    assert '(s.section === "analytics" && k.analytics_about) || k.about' in js
    assert "Each rule of Data analytics reads one CSV file of the recording on its own; the tree is not used there." in js


# ---------------------------------------------------------------------------------------------- a whole flow
class Yes:
    def random(self):
        return 0.0

    def choice(self, seq):
        return seq[0]

    def sample(self, seq, k):
        return list(seq)[:k]

    def randint(self, _a, b):
        return b


@pytest.fixture(scope="module")
def flow():
    """One whole flow on S17 with the stand-in (no model, no server): the two analytics items and the timeout rule, every card approved."""
    if not os.path.isdir(S17):
        pytest.skip("no S17")
    import fuzz_app as F
    import fuzz_deep as FD
    from api import config_api, hier_api
    root = tempfile.mkdtemp(prefix="analytics_flow_%d_" % os.getpid())
    kept = (core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK)
    uploads = PR._UPLOADS[0]
    try:
        app, c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kept[0]
        family3._SECTIONS_SEEN[0] = None
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "one csv", "folder": S17}).get_json()["id"]
        rid = c.post("/api/agents/projects/%d/flow" % pid, json={"admin": "t"}).get_json()["run"]
        t0, plan = time.time(), None
        while time.time() - t0 < 900:
            v = c.get("/api/agents/runs/%d" % rid).get_json()
            failed = [(s["key"], (s.get("error") or "")[-600:]) for s in v["steps"] if s["state"] == "failed"]
            if failed or v["run"]["state"] != "running":
                break
            rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
            if rv is None:
                time.sleep(0.2)
                continue
            st = next(s for s in v["steps"] if s["id"] == rv["step"])
            if st["key"] == "f3_plan":
                plan = rv.get("data") or {}
                edits = {"selected": [SHARE, READS, TIMEOUT]}
            elif st["key"].endswith(":result"):
                edits = None
            else:
                edits = FD.edits_for(st["key"], rv.get("data") or {}, Yes())
            r = c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t", "edits": edits})
            assert r.status_code == 200, (st["key"], r.get_json())
        v = c.get("/api/agents/runs/%d" % rid).get_json()
        yield {"view": v, "plan": plan, "root": root}
    finally:
        core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK = kept
        PR.use_uploads_folder(uploads)
        family3._SECTIONS_SEEN[0] = None
        shutil.rmtree(root, ignore_errors=True)


def test_a_whole_flow_with_the_two_analytics_items_and_the_timeout_rule_finishes_and_the_analytics_read_the_file(flow):
    v = flow["view"]
    assert v["run"]["state"] == "finished", [(s["key"], s["state"], (s.get("error") or "")[-300:]) for s in v["steps"] if s["state"] not in ("done", "approved", "skipped")]
    offered = [i["key"] for i in flow["plan"]["items"]]
    assert SHARE in offered and READS in offered and "analytics/nvme_command/near_limit" not in offered
    for item, expected in ((SHARE, S17_TYPES), (READS, S17_READS)):
        st = {s["key"].rsplit(":", 1)[1]: s for s in v["steps"] if s["key"].startswith("f3:%s:" % item)}
        assert st["run"]["title"].endswith("run on its own CSV file") and st["run"]["state"] == "done"
        run = st["run"]["output"]
        with open(run["code_file"], encoding="utf-8") as fh:
            code = fh.read()
        assert 'sources["nvme_command.csv"]' in code and "def run(sources, out_csv):" in code and "tree.rows" not in code
        assert PR.check_code(code, analytics=True) == []
        with open(run["output_csv"], newline="", encoding="utf-8") as fh:
            rows = [(a, int(b), float(c)) for a, b, c in list(csv.reader(fh))[1:]]
        assert rows == expected
        assert st["test"]["output"]["passed"] is True, [c for c in st["test"]["output"]["checks"] if not c["ok"]]
    t = {s["key"].rsplit(":", 1)[1]: s for s in v["steps"] if s["key"].startswith("f3:%s:" % TIMEOUT)}
    assert t["run"]["title"].endswith("run on the tree") and t["run"]["output"]["kind"] == "detector"
