"""The second half for ANY CSV, first slice (2026-11-14): the rows a rule finds in a CSV file that is not part of the tree become errors
of the analysis, each with a page of its own (agentic/other_errors.py, app/api/other_error_api.py, app/static/other_error.html).

No model is called: the flow runs with the stand-in, and the one test of a model's answer uses a made-up answer. Everything is written
under pytest's temporary folders: a throw-away application, store, knowledge folder and engine.
"""
import copy
import csv
import json
import os
import random
import re
import shutil
import subprocess
import sys
import time
import tracemalloc
import zipfile

import pytest

os.environ.setdefault("F2T_WORKERS", "1")
HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app")):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import admin_ask, core, family1, family3, other_errors as OE, pipeline, procedures as PR  # noqa: E402

ITEM_A = "analytics/other/share_of_each_command"
ITEM_E = "errors/other/timed_out_commands"
RELEASED = os.path.join(os.path.dirname(APP), "field_to_test_loop_code_only.zip")
NODE = "/home/raghavendra/.nvm/versions/node/v22.23.2/bin/node"
EXPERIMENT = "/tmp/f2t_exp_unknown_csv_CLe95S"          # the real-model run on a disguised CSV (E_real_model_run_on_unknown_csv.md)

# The approved dictionary of the disguised file of the real-model run (cmd_trace_export.csv), copied on 2026-11-14 from
# <EXPERIMENT>/root/knowledge/dictionaries/340ec36b5800/cmd_trace_export.current.json: the model's own words, and how the dictionary marks each.
DATA, MODEL = "data", "model"
DISGUISED = [
    ("Idx", "Sequential row number of the traced command, counting from 1 to 608.", DATA),
    ("T Submit [ns]", "Time at which the command was submitted to the device queue, in nanoseconds on the trace clock.", MODEL),
    ("Dev", "Address of the traced device, apparently in bus:device:function form; it is the same on every row.", MODEL),
    ("QID", "Queue ID of the submission queue that carried the command. Queue 0 is probably the admin queue; 1 to 4 are I/O queues.", MODEL),
    ("Tag", "Command tag (command identifier) that matches a command to its completion within a queue; it is reused over time.", MODEL),
    ("Op", "Name of the NVMe command (opcode name) issued in this row.", MODEL),
    ("Code", "Hexadecimal NVMe opcode of the command; its meaning depends on the queue, so 0x01 is Write for I/O and Create I/O SQ for admin.", DATA),
    ("NS", "Namespace ID the command addresses; 0 on commands that name no namespace.", MODEL),
    ("LBA Start", "Starting logical block address of the transfer, for Read and Write commands.", MODEL),
    ("Blocks", "Number of logical blocks transferred by the Read or Write command.", MODEL),
    ("Xfer [B]", "Transfer size in bytes for Read, Write and Identify commands; for Read and Write it is Blocks times 512.", DATA),
    ("Buf Addr", "Host memory address of the data buffer for Read, Write, Create queue and Identify commands.", MODEL),
    ("Result", "Completion outcome of the command.", MODEL),
    ("T Done [ns]", "Time at which the command completed, in nanoseconds; empty for commands that are still pending.", MODEL),
    ("Svc Time [us]", "Service time in microseconds, the difference between completion time and submit time.", DATA),
]


def dictionary(cols, kinds=()):
    """A dictionary in the shape Family 1 approves: [(column, meaning, kind of source)]."""
    status = {DATA: "from the column's name and contents (checked: the value is in the column)", MODEL: "from the model's knowledge (no source to check)",
              "admin": "written by the admin"}
    return {"file": "x.csv", "version": 1, "approved_by": "Sagar", "kind_of_row": {"columns": list(kinds)},
            "columns": [{"column": c, "meaning": m, "status": status.get(k, ""), "source": {"kind": k, "ref": c if k == DATA else "", "quote": ""}} for c, m, k in cols]}


def write_bench(path, rows=300, seed=7):
    random.seed(seed)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write("Command,Queue,Latency_us,Result\n")
        for i in range(rows):
            fh.write("%s,%d,%d,%s\n" % (random.choice(["Read"] * 6 + ["Write"] * 3 + ["Flush"]), random.randint(1, 4), random.randint(80, 9000), "ok" if i % 50 else "timeout"))


class World:
    """A throw-away application and one finished analysis of a CSV that is not an analyzer export, with the stand-in (no model)."""

    def __init__(self, root, mp):
        from api import config_api, hier_api
        self.root = str(root)
        know = os.path.join(self.root, "knowledge")
        os.makedirs(know)
        mp.setattr(family1, "knowledge_dir", lambda: know)
        mp.setattr(config_api, "save_config", lambda c: None)
        mp.setattr(hier_api, "ENV_FILE", os.path.join(self.root, "env"))       # a test never reaches the real key file
        # (2026-11-15) what the application made below writes into agentic/procedures.py is put back by mp.undo() as well: create_app points
        # the uploads folder at this throw-away root (use_uploads_folder writes into the list _UPLOADS: it gets a list of its own here, and
        # the application's own list comes back untouched), and the engine sets MODEL_CONNECTED to ask its own runner. Left as they were,
        # a test file that ran after this one looked for the application's recordings in a folder that is gone (seen in
        # tests/test_rule_evidence.py: the path of a recording's file was None, in some orders only).
        mp.setattr(PR, "_UPLOADS", list(PR._UPLOADS))
        mp.setattr(PR, "MODEL_CONNECTED", PR.MODEL_CONNECTED)
        family3._SECTIONS_SEEN[0] = None
        with open(os.path.join(APP, "config", "app_config.json"), encoding="utf-8") as fh:
            cfg = copy.deepcopy(json.load(fh))
        cfg["_path"] = os.path.join(self.root, "app_config.json")
        cfg["llm"].update(base_url="http://127.0.0.1:9", api_key_env="OTHER_CSV_NO_SUCH_KEY", backend="http")
        cfg["agentic"].update(runtime="standin", web=False)
        from server import create_app
        self.app = create_app(cfg, self.root)
        from api import other_error_api
        self.api = other_error_api
        if "other_error" not in self.app.blueprints:               # the coordinator registers it in app/server.py; until then the test does
            self.app.register_blueprint(other_error_api.bp)
        self.app.config["PROPAGATE_EXCEPTIONS"] = False
        self.app.logger.disabled = True
        self.c = self.app.test_client()
        self.folder = os.path.join(self.root, "bench")
        os.makedirs(self.folder)
        self.csv = os.path.join(self.folder, "bench_log.csv")
        write_bench(self.csv)
        with self.app.app_context():
            from api.agentic_api import engine
            self.eng = engine()
        self.store = self.eng.store
        self.pid = self.store.exec("INSERT INTO project (admin, name, folder, refs, created, updated) VALUES (?,?,?,?,?,?)", ("Sagar", "bench", self.folder, "[]", time.time(), time.time()))
        self.rid = self.eng.start(self.pid, "flow", "", {"started_by": "Sagar"})
        self.seen = self.drive()
        self.steps = {s["key"]: s for s in self.store.all("SELECT * FROM step WHERE run=? ORDER BY idx", (self.rid,))}
        self.db = OE.store_path(self.eng.runner.sandbox_root, self.rid)
        self.base = "/api/other-errors/%d" % self.rid
        # the dictionary the stand-in approved has no meanings a person wrote: for the page's tests, three columns get one, each marked differently
        inv = next(f for f in family1.inventory(self.folder) if f["name"] == "bench_log.csv")
        self.dict_path = os.path.join(know, "dictionaries", inv["format_key"], "bench_log.current.json")
        with open(self.dict_path, encoding="utf-8") as fh:
            d = json.load(fh)
        new = {"Command": ("The kind of command the bench sent.", {"kind": "data", "ref": "Command", "quote": "Read"}, "from the column's name and contents (checked: the value is in the column)"),
               "Queue": ("Queue ID the command was sent on.", {"kind": "model", "ref": "model knowledge", "quote": ""}, "from the model's knowledge (no source to check)"),
               "Result": ("How the command ended.", {"kind": "admin", "ref": "Sagar", "quote": ""}, "written by the admin")}
        for c in d["columns"]:
            if c["column"] in new:
                c["meaning"], c["source"], c["status"] = new[c["column"]]
            else:
                c["meaning"], c["source"], c["status"] = "", {}, ""
        d["kind_of_row"] = {"columns": []}
        with open(self.dict_path, "w", encoding="utf-8") as fh:
            json.dump(d, fh)

    def drive(self, limit=240):
        seen, t0 = [], time.time()
        while time.time() - t0 < limit:
            run = self.store.one("SELECT * FROM run WHERE id=?", (self.rid,))
            failed = self.store.one("SELECT key, error FROM step WHERE run=? AND state='failed'", (self.rid,))
            assert not failed, (failed["key"], failed["error"][-1500:])
            if run["state"] != "running":
                return seen
            rv = self.store.one("SELECT * FROM review WHERE run=? AND state='open' ORDER BY id LIMIT 1", (self.rid,))
            if not rv:
                time.sleep(0.1)
                continue
            key = self.store.one("SELECT key FROM step WHERE id=?", (rv["step"],))["key"]
            seen.append(key)
            edits = None
            if key == admin_ask.GATE:
                edits = {"stage2": "skip"}
            elif key == "f3_plan":
                edits = {"selected": [], "new": [{"section": "analytics", "level": "other", "name": "share of each command", "description": "percentage by Command"},
                                                 {"section": "errors", "level": "other", "name": "timed out commands", "description": "rows where Result is timeout"}]}
            self.eng.decide(rv["id"], "approve", "Sagar", "", edits)
        raise AssertionError("the flow did not finish in time: %s" % seen)

    def out(self, key):
        return json.loads(self.steps[key]["output"] or "{}")


@pytest.fixture(scope="module")
def world(tmp_path_factory):
    mp = pytest.MonkeyPatch()
    # another test file of the same session may have switched the engine's own start off (tests/fuzz_app.py setup keeps it as
    # REAL_KICK); a flow needs it, so it is put back for this module, as tests/test_any_tool_start.py does
    import sys as _sys
    from agentic import core as _core
    kick = getattr(_sys.modules.get("fuzz_app"), "REAL_KICK", None)
    if kick is not None:
        mp.setattr(_core.Engine, "kick", kick)
    try:
        yield World(tmp_path_factory.mktemp("other_csv"), mp)
    finally:
        mp.undo()
        family3._SECTIONS_SEEN[0] = None


def slow_timeouts(path):
    """The slow recomputation: every row of the file whose Result is exactly "timeout", by Python's csv reader, the first row under the header being row 1."""
    with open(path, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        head = next(rd)
        return [(n, row) for n, row in enumerate(rd, 1) if row[head.index("Result")].strip() == "timeout"]


# ---------------------------------------------------------------------------------------------- 1. a rule's rows become errors
def test_a_rule_of_the_errors_section_on_another_csv_gives_errors_equal_to_a_slow_recomputation(world):
    assert world.store.one("SELECT state FROM run WHERE id=?", (world.rid,))["state"] == "finished"
    want = slow_timeouts(world.csv)
    assert len(want) == 6
    eo = world.out("f3:%s:errors" % ITEM_E)
    assert eo["kind"] == OE.KIND == "other_csv" and eo["total"] == len(want) and not eo.get("refused")
    assert [(x["file"], x["row"], x["cells"]) for x in eo["other_errors"]] == [("bench_log.csv", n, row) for n, row in want]
    assert all(x["rule"] == "timed out commands" and x["item"] == ITEM_E and x["kind"] == OE.KIND for x in eo["other_errors"])
    # the tree's list stays empty: no later step can take a row of another file for a finding of the tree
    assert eo["errors"] == [] and eo["upload_id"] is None
    j = world.c.get(world.base).get_json()
    assert j["total"] == len(want) and [(e["file"], e["row"], e["cells"]) for e in j["errors"]] == [("bench_log.csv", n, row) for n, row in want]
    assert all(e["link"] == "/other-error?run=%d&error=%d" % (world.rid, e["error"]) for e in j["errors"])
    assert [(r["item"], r["total"], r["refused"]) for r in j["rules"]] == [(ITEM_E, len(want), None)]
    # the Tester checked that the result names its rows, and the report lists these errors apart from the tree's
    assert any(c["check"].startswith("every found row says which row of the file it is") and c["ok"] for c in world.out("f3:%s:test" % ITEM_E)["checks"])
    card = json.loads(world.store.one("SELECT data FROM review WHERE step=?", (world.steps["f3:%s:result" % ITEM_E]["id"],))["data"])
    assert card["errors_page"] is True and card["other_errors"]["kind"] == "other_csv"       # the result card offers no defect picker of the tree for these rows
    with open(world.out("report")["files"]["json"], encoding="utf-8") as fh:
        rep = json.load(fh)
    assert rep["errors"] == [] and [(x["rule"], x["total"]) for x in rep["other_errors"]] == [("timed out commands", len(want))]


def test_an_analytics_item_on_the_same_file_never_adds_to_the_errors(world):
    assert ("f3:%s:errors" % ITEM_A) not in world.steps and world.out("f3:%s:run" % ITEM_A)["rows"] == 3            # it ran, and has no errors step at all
    assert [x["item"] for x in OE.listings(world.db)] == [ITEM_E]
    assert {e["item"] for e in OE.list_errors(world.db, limit=1000)} == {ITEM_E}
    done = world.out("errors_done")
    assert (done["patterns"], done["errors"]) == (0, 0)                      # the tree's counts: nothing of another file is in them
    assert (done["other_patterns"], done["other_errors"]) == (1, 6)
    assert not family3.errors_of_a_file(family3.load_rule("analytics", "other", "share_of_each_command"))
    assert family3.errors_of_a_file(family3.load_rule("errors", "other", "timed_out_commands"))


def test_a_result_that_does_not_name_its_source_rows_is_refused_in_plain_words(world, tmp_path):
    src = {"bench_log.csv": world.csv}
    db = str(tmp_path / "s" / "errors.sqlite")

    def result(header, rows):
        p = str(tmp_path / ("r%d.csv" % len(os.listdir(str(tmp_path)))))
        with open(p, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(header)
            w.writerows(rows)
        return p
    want = slow_timeouts(world.csv)
    cases = [
        (["Command", "Queue", "Latency_us", "Result"], [row for _n, row in want], "does not say which rows of bench_log.csv it found"),
        ([OE.ROW_COLUMN, "Result"], [["the first", "timeout"]], "is not a whole number of 1 or more"),
        ([OE.ROW_COLUMN, "Result"], [["0", "timeout"]], "is not a whole number of 1 or more"),
        ([OE.ROW_COLUMN, "Result"], [["-3", "timeout"]], "is not a whole number of 1 or more"),
        ([OE.ROW_COLUMN, "Result"], [["301", "timeout"]], "that file has 300 rows under its header"),
        ([OE.ROW_COLUMN] + ["Command", "Queue", "Latency_us", "Result"], [[n + 1] + row for n, row in want], "Either the row number is not the file's"),   # one off
        ([OE.ROW_COLUMN, OE.ROW_COLUMN], [["1", "1"]], "more than one column named"),
    ]
    for header, rows, words in cases:
        with pytest.raises(OE.Refused) as e:
            OE.ingest(db, "errors/other/x", "my rule", result(header, rows), src)
        msg = str(e.value)
        assert words in msg and "No error is listed" in msg and "Traceback" not in msg and len(msg) > 60, msg
        assert OE.list_errors(db) == [] and OE.listings(db)[0]["refused"] == msg and OE.listings(db)[0]["total"] == 0
    with pytest.raises(OE.Refused) as e:                                   # two files, and the result does not say which
        OE.ingest(db, "errors/other/x", "my rule", result([OE.ROW_COLUMN], [["1"]]), {"bench_log.csv": world.csv, "copy.csv": world.csv})
    assert "does not say in which of them each row is" in str(e.value)
    # the same refusal through the flow's own step: the errors step lists nothing and says why
    class Ic:
        engine, run, project, item = world.eng, {"id": 990001}, {"folder": world.folder, "admin": "Sagar"}, ITEM_E
        params = {"section": "errors", "level": "other", "id": "timed_out_commands"}
        input = {}

        def progress(self, text):
            pass

        def output_of(self, key):
            return {}
    bad = result(["Command", "Result"], [["Read", "timeout"]])
    res = pipeline._errors_of_a_file(Ic(), {"rows": 1, "output_csv": bad})
    assert res.output["errors"] == [] and res.output["other_errors"] == [] and res.output["total"] == 0
    assert "does not say which rows of bench_log.csv it found" in res.output["refused"] and OE.ROW_COLUMN in res.output["refused"]
    # the Rule writer's procedure is checked before anything is coded, and a good result is taken (rows repeated in it are listed once)
    assert OE.result_problem(["Command", "count"], ["bench_log.csv"], "r") and not OE.result_problem([OE.ROW_COLUMN, "Result"], ["bench_log.csv"], "r")
    good = result([OE.ROW_COLUMN, "Result"], [[n, "timeout"] for n, _r in want] + [[want[0][0], "timeout"]])
    got = OE.ingest(db, "errors/other/x", "my rule", good, src)
    assert (got["total"], got["repeated"]) == (len(want), 1) and [e["row"] for e in OE.list_errors(db)] == [n for n, _r in want]


# ---------------------------------------------------------------------------------------------- 2. the tree's errors are as before
COMPARE = r'''
import json, os, sqlite3, sys
app, db, know = sys.argv[1:4]
sys.path.insert(0, app); sys.path.insert(0, os.path.join(app, "app"))
from agentic import family1, family3, pipeline
family1.knowledge_dir = lambda: know
family3.tree()
out = {}
for rid in ("cmd_timeout", "cmd_read_failure"):
    r = family3.load_rule("errors", "nvme_command", rid)
    sql, params, _p, _q = family3.compile_rule({"kind": "detection_rule", "plan": {"rule": r["plan"]["rule"]}})
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    cur = con.execute(sql, params)
    cols = [d[0] for d in cur.description]
    rows = [list(x) for x in cur.fetchall()]
    con.close()
    class Ic:
        item = "errors/nvme_command/%s" % rid
        params = {"section": "errors", "level": "nvme_command", "id": rid}
        def output_of(self, key):
            return {"upload_id": "up-s17", "columns": cols, "rows": len(rows), "head": rows[:200], "kind": "detector"} if key == "run" else {}
    res = pipeline._errors(Ic())
    out[rid] = {"output": res.output, "skip": res.skip, "producer": res.producer}
class Eng:
    def view(self, rid):
        return {"steps": [{"key": "f3:errors/nvme_command/%s:errors" % k, "output": v["output"]} for k, v in out.items()]}
class Ctx:
    engine, run, project = Eng(), {"id": 1}, {"admin": "Sagar"}
d = pipeline._errors_done(Ctx())
out["done"] = {"patterns": d.output["patterns"], "errors": d.output["errors"], "body": d.review["body"]}
print("RESULT " + json.dumps(out, sort_keys=True))
'''


def test_the_errors_of_the_tree_are_exactly_as_in_the_released_code(tmp_path):
    """S17 (io timeout, abort, reset), built once; the flow's errors step and the errors gate run on it by the working copy and by the released
    code from the zip: the same list of errors, the same counts, the same words."""
    if not os.path.exists(RELEASED):
        pytest.skip("the released code (%s) is not on this computer" % RELEASED)
    from nvme_hier import builder as B, loader as L, rules as RL
    base = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
    names = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
    db = str(tmp_path / "hier.sqlite")
    L.load_upload(db, {k: os.path.join(base, n) for k, n in names.items()})
    B.build(db)
    RL.apply(db)
    old = tmp_path / "released"
    with zipfile.ZipFile(RELEASED) as z:
        z.extractall(str(old), [n for n in z.namelist() if n.startswith("13_production_app/") and not n.startswith("13_production_app/tests/")])
    script = tmp_path / "scripts" / "compare.py"
    os.makedirs(str(script.parent))
    script.write_text(COMPARE, encoding="utf-8")
    got = {}
    for label, app in (("released", str(old / "13_production_app")), ("now", APP)):
        know = tmp_path / ("know_" + label)
        os.makedirs(str(know))
        p = subprocess.run([sys.executable, "-I", str(script), app, db, str(know)], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300,
                           cwd=str(script.parent), env=dict(os.environ, F2T_WORKERS="1"))
        line = next((ln for ln in p.stdout.splitlines() if ln.startswith("RESULT ")), None)
        assert line, (label, p.stdout[-800:], p.stderr[-1500:])
        got[label] = json.loads(line[7:])
    assert len(got["released"]["cmd_timeout"]["output"]["errors"]) > 0                  # S17 has timeout errors: the comparison is not of two empty lists
    assert got["now"] == got["released"]
    assert got["now"]["done"]["errors"] == sum(len(got["now"][k]["output"]["errors"]) for k in ("cmd_timeout", "cmd_read_failure"))


# ---------------------------------------------------------------------------------------------- 3. the page's routes
def first_error(world, k=2):
    return world.c.get(world.base).get_json()["errors"][k]


def test_the_row_is_shown_with_every_column_its_value_and_the_dictionarys_meaning_and_source(world):
    e = first_error(world)
    j = world.c.get("%s/%d" % (world.base, e["error"])).get_json()
    assert j["kind"] == "other_csv" and j["file"] == "bench_log.csv" and j["row"] == e["row"] and j["file_rows"] == 300
    assert "Row %d of 300 rows of bench_log.csv" % e["row"] in j["where"]
    cols = {c["column"]: c for c in j["columns"]}
    assert list(cols) == ["Command", "Queue", "Latency_us", "Result"] and [c["value"] for c in j["columns"]] == e["cells"]
    assert cols["Command"]["meaning"] == "The kind of command the bench sent." and cols["Command"]["sourced"] and "the file's own data" in cols["Command"]["source_words"]
    assert cols["Queue"]["meaning"] == "Queue ID the command was sent on." and not cols["Queue"]["sourced"]
    assert cols["Queue"]["source_words"].startswith("meaning not sourced") and "no source to check" in cols["Queue"]["source_words"]      # as the dictionary marks it
    assert cols["Result"]["sourced"] and "the admin" in cols["Result"]["source_words"]
    assert cols["Latency_us"]["meaning"] == "" and cols["Latency_us"]["source_words"] == OE.NO_MEANING       # the code writes no meaning of its own
    assert j["rule"]["name"] == "timed out commands" and j["rule"]["admin_words"] == "rows where Result is timeout" and len(j["rule"]["steps"]) == 4
    assert j["window_default"]["n"] == 15 and j["window_default"]["m"] == 15 and len(j["window_default"]["why"]) > 40
    # what the page cannot do, said plainly, with what would be needed
    assert "Teledyne LeCroy" in j["cannot"]["words"] and "replay test" in j["cannot"]["words"] and "status" in j["cannot"]["would_need"]
    m = j["cannot"]["mapping"]
    assert m["holds_what_is_needed"] is False and m["changes_nothing"] is True and len(m["needs"]) == 6
    # without an approved dictionary every column says so, and nothing is offered
    saved = world.dict_path + ".aside"
    os.rename(world.dict_path, saved)
    try:
        j2 = world.c.get("%s/%d" % (world.base, e["error"])).get_json()
    finally:
        os.rename(saved, world.dict_path)
    assert all(c["meaning"] == "" and c["source_words"] == OE.NO_DICTIONARY for c in j2["columns"]) and not j2["dictionary"]["approved"]
    # without a dictionary the dictionary offers no column; a column an admin named (another test of this shared analysis may
    # have named one: the tests run in a shuffled order) is rightly still offered, with the admin's name
    assert [c for c in j2["same_value_columns"] if c["named_by"] == "the dictionary"] == []


def test_the_window_above_and_below_and_the_same_value_choice_only_for_a_named_column(world):
    e = first_error(world)                                                 # row 101
    with open(world.csv, newline="", encoding="utf-8") as fh:
        every = list(csv.reader(fh))[1:]
    w = world.c.get("%s/%d/window?n=4&m=7" % (world.base, e["error"])).get_json()
    assert [r["row"] for r in w["rows"]] == list(range(e["row"] - 4, e["row"] + 8)) and all(r["cells"] == every[r["row"] - 1] for r in w["rows"])
    assert [r["position"] for r in w["rows"]] == ["above"] * 4 + ["the error"] + ["below"] * 7
    assert (w["n_set_by"], w["m_set_by"], w["above"], w["below"]) == ("admin", "admin", 4, 7) and w["default_reason"] == ""
    d = world.c.get("%s/%d/window" % (world.base, e["error"])).get_json()                # nothing typed: the default, said to be nobody's choice, with its reason
    assert (d["n"], d["m"], d["n_set_by"], d["m_set_by"]) == (15, 15, "default", "default") and len(d["default_reason"]) > 40 and len(d["rows"]) == 31
    top = world.c.get("%s/%d/window?n=500&m=0" % (world.base, world.c.get(world.base).get_json()["errors"][0]["error"])).get_json()      # row 1: nothing above it
    assert [r["row"] for r in top["rows"]] == [1] and top["above"] == 0
    # the same-value choice: only the column the dictionary names by its own words ("Queue ID"); never Latency_us or Command
    one = world.c.get("%s/%d" % (world.base, e["error"])).get_json()
    assert [(c["column"], c["named_by"]) for c in one["same_value_columns"]] == [("Queue", "the dictionary")]
    assert "\"queue id\"" in one["same_value_columns"][0]["why"] and "Queue ID the command was sent on." in one["same_value_columns"][0]["why"]
    q = e["cells"][1]
    s = world.c.get("%s/%d/window?n=3&m=3&same=Queue" % (world.base, e["error"])).get_json()
    slow_above = [i for i in range(e["row"] - 1, 0, -1) if every[i - 1][1] == q][:3][::-1]
    slow_below = [i for i in range(e["row"] + 1, 301) if every[i - 1][1] == q][:3]
    assert [r["row"] for r in s["rows"]] == slow_above + [e["row"]] + slow_below and s["same"] == {"column": "Queue", "value": q}
    # the isolation refuses a column nobody named; after the admin names it, it is offered and used
    r = world.c.post("%s/%d/isolate" % (world.base, e["error"]), json={"admin": "Sagar", "same": "Command", "standin": True})
    assert r.status_code == 400 and "not a column that the dictionary or the admin named" in r.get_json()["error"]
    r = world.c.post("%s/%d/group-column" % (world.base, e["error"]), json={"column": "Command", "admin": "Sagar", "why": "the same kind of command belongs together"})
    assert r.status_code == 200 and [(c["column"], c["named_by"]) for c in r.get_json()["same_value_columns"]] == [("Queue", "the dictionary"), ("Command", "Sagar")]
    r = world.c.post("%s/%d/isolate" % (world.base, e["error"]), json={"admin": "Sagar", "same": "Command", "standin": True, "n": 2, "m": 2})
    assert r.status_code == 200 and r.get_json()["same_column"] == "Command"


def test_the_isolation_is_kept_with_who_asked_and_a_cited_row_outside_the_window_is_refused(world, monkeypatch):
    e = world.c.get(world.base).get_json()["errors"][3]                    # row 151
    url = "%s/%d" % (world.base, e["error"])
    t0 = time.time()
    a = world.c.post(url + "/isolate", json={"admin": "Sagar", "n": 3, "m": 2, "standin": True}).get_json()
    assert a["standin"] is True and a["marked"].startswith("STAND-IN") and a["producer"].startswith("stand-in") and a["refused"] == ""
    assert a["answer"]["cited_rows"] == [e["row"]] and "Row %d of 300 rows of the file bench_log.csv" % e["row"] in a["answer"]["where"]
    assert a["written_by"]["where"] == "the code, from the file" and a["answer"]["why"].startswith("Not known")
    assert set(a["answer"]) == set(OE.ISOLATION_KEYS) | {"cited_rows"}

    class Fake:
        name = "made-up model"
        answer = None
        prompts = []

        def generate_json(self, prompt, schema):
            Fake.prompts.append(prompt)
            return dict(Fake.answer)
    monkeypatch.setattr(world.api, "_llm", lambda body: Fake())
    words = {"what": "The command in row %d ended with timeout." % e["row"], "why": "Not known from these rows.", "when": "Not known from these rows.",
             "who": "Not known from these rows.", "which": "Row %d." % e["row"], "how": "The row before it ended ok and this one did not."}
    Fake.answer = dict(words, cited_rows=[e["row"], e["row"] - 1])
    b = world.c.post(url + "/isolate", json={"admin": "Asha", "n": 3, "m": 2}).get_json()
    assert b["standin"] is False and b["producer"] == "made-up model" and b["answer"]["cited_rows"] == [e["row"], e["row"] - 1] and b["answer"]["what"] == words["what"]
    assert b["written_by"]["why"] == "the model (made-up model)" and b["written_by"]["where"] == "the code, from the file" and b["marked"] == ""
    prompt = Fake.prompts[-1]                      # the model saw the dictionary's meanings, the window rows and the code's facts; nothing about NVMe is put in
    assert "Queue: Queue ID the command was sent on. [meaning not sourced" in prompt and "row %d (THE ERROR)" % e["row"] in prompt and "Latency_us: no meaning known" in prompt
    assert "NVMe" not in prompt and "row %d:" % (e["row"] - 3) in prompt and "row %d:" % (e["row"] - 4) not in prompt
    Fake.answer = dict(words, cited_rows=[e["row"], e["row"] + 40])                    # a row that is not in the window of 3 above and 2 below
    c = world.c.post(url + "/isolate", json={"admin": "Asha", "n": 3, "m": 2}).get_json()
    assert c["standin"] is True and "row %d" % (e["row"] + 40) in c["refused"] and "is refused" in c["refused"] and c["answer"]["what"] != words["what"]
    assert c["producer"] == "stand-in (the model's answer was refused)"
    kept = world.c.get(url + "/isolations").get_json()["isolations"]
    assert [(k["asked_by"], k["standin"], bool(k["refused"])) for k in kept] == [("Asha", True, True), ("Asha", False, False), ("Sagar", True, False)]
    assert all(t0 - 1 <= k["asked_at"] <= time.time() + 1 and (k["n"], k["m"]) == (3, 2) for k in kept)
    assert len(world.c.get(url).get_json()["isolations"]) == 3                        # the page shows them when it is opened again
    assert OE.listings(world.db)[0]["isolated"] >= 1


# ---------------------------------------------------------------------------------------------- 4. a large file is never loaded
def test_the_window_of_an_error_near_the_end_of_300000_rows_is_read_without_loading_the_file(tmp_path, capsys):
    path, n = str(tmp_path / "big.csv"), 300000
    random.seed(3)
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write("Seq,Channel,Value,Note,State\n")
        for i in range(1, n + 1):
            fh.write("%d,%d,%d,\"note %d, with a comma\",%s\n" % (i, i % 7, random.randint(0, 10 ** 9), i, "bad" if i % 60000 == 59990 or i == n - 10 else "fine"))
    size = os.path.getsize(path)
    res = str(tmp_path / "res.csv")
    found = [i for i in range(1, n + 1) if i % 60000 == 59990 or i == n - 10]
    with open(res, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow([OE.ROW_COLUMN, "Seq", "State"])
        w.writerows([i, i, "bad"] for i in found)
    db = str(tmp_path / "store" / "errors.sqlite")
    tracemalloc.start()
    base = tracemalloc.get_traced_memory()[0]
    t0 = time.time()
    got = OE.ingest(db, "errors/other/big", "bad states", res, {"big.csv": path})
    t_ingest, peak_ingest = time.time() - t0, tracemalloc.get_traced_memory()[1] - base
    assert got["total"] == len(found) and got["files"] == {"big.csv": n}
    last = [e for e in OE.list_errors(db) if e["row"] == n - 10][0]
    assert last["cells"][0] == str(n - 10) and last["cells"][3] == "note %d, with a comma" % (n - 10)
    tracemalloc.reset_peak()
    base = tracemalloc.get_traced_memory()[0]
    t0 = time.time()
    w = OE.window(db, last["error"], 25, 25)
    t_window, peak_window = time.time() - t0, tracemalloc.get_traced_memory()[1] - base
    tracemalloc.reset_peak()
    base = tracemalloc.get_traced_memory()[0]
    t0 = time.time()
    s = OE.window(db, last["error"], 20, 20, same=None)
    name_ok = OE.name_group_column(db, "big.csv", w["header"], "Channel", "Sagar", "one channel")
    s = OE.window(db, last["error"], 20, 20, same="Channel")
    t_same, peak_same = time.time() - t0, tracemalloc.get_traced_memory()[1] - base
    tracemalloc.stop()
    assert name_ok is None
    assert [r["row"] for r in w["rows"]] == list(range(n - 35, n + 1)) and w["below"] == 10 and w["above"] == 25          # only 10 rows are left below it
    assert all(r["cells"][0] == str(r["row"]) for r in w["rows"]) and w["rows_read"] <= OE.CHECKPOINT_ROWS + 51
    ch = str((n - 10) % 7)
    assert [r["row"] for r in s["rows"]] == [n - 10 - 7 * k for k in range(20, 0, -1)] + [n - 10, n - 3] and all(r["cells"][1] == ch for r in s["rows"])
    assert s["rows_read"] < 3 * OE.CHECKPOINT_ROWS
    mb = 1024.0 * 1024
    with capsys.disabled():
        print("\n300,000 rows (%.1f MB): the errors listed in %.2f s (Python memory grew %.2f MB at its peak); the window of 25 above and 25 below of row %s read in "
              "%.4f s, %s rows read, memory grew %.3f MB; with 'only rows with the same Channel' %.4f s, %s rows read, memory grew %.3f MB"
              % (size / mb, t_ingest, peak_ingest / mb, "{:,}".format(n - 10), t_window, "{:,}".format(w["rows_read"]), peak_window / mb, t_same,
                 "{:,}".format(s["rows_read"]), peak_same / mb))
    assert size > 12 * mb and peak_window < 1 * mb and peak_same < 1 * mb and peak_ingest < 4 * mb        # far less than the file: it is never loaded
    assert t_window < 2.0 and t_same < 2.0
    # a file that changed after the rule ran is refused in words: its row numbers may no longer be the same
    with open(path, "a", encoding="utf-8") as fh:
        fh.write("300001,0,1,x,fine\n")
    with pytest.raises(OE.Refused) as e:
        OE.window(db, last["error"], 1, 1)
    assert "changed after the rule ran" in str(e.value)


# ---------------------------------------------------------------------------------------------- 4b. a file in its own form (2026-11-15)
FORM_HEAD = ["Seq", "Channel", "Value", "Note", "State"]
FORMS = ("plain", "semicolon", "tab", "utf16")


def form_rows(n):
    """The same data for every form: a decimal comma in Value, and in some notes a semicolon, a letter whose UTF-16 bytes hold the byte
    of a line end (U+010A is 0A 01) and a sign that takes four bytes in UTF-16."""
    for i in range(1, n + 1):
        yield [str(i), str(i % 7), "%d,%02d" % (i * 3, i % 100), ("note %d; with Ċ and \U0001F600" % i) if i % 9 == 0 else "note %d" % i,
               "bad" if i % 400 == 399 or i == n - 10 else "fine"]


def write_form(folder, form, n, name="f.csv"):
    """plain: comma, UTF-8, header on line 1. semicolon: a title line, then semicolons, \r\n. tab: tabs. utf16: the semicolon form in UTF-16 with its mark."""
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, name)
    if form == "plain":
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(FORM_HEAD)
            w.writerows(form_rows(n))
        return path
    with open(path, "w", newline="", encoding="utf-16" if form == "utf16" else "utf-8") as out:       # "utf-16" writes its mark first
        if form != "tab":
            out.write("Bench report of drive D\r\n")
        w = csv.writer(out, delimiter="\t" if form == "tab" else ";", lineterminator="\r\n")
        w.writerow(FORM_HEAD)
        w.writerows(form_rows(n))
    return path


def listed(tmp_path, form, n, measured=None):
    """The errors of one form: the rule's result names the rows whose State is bad -> (store, the file's path, the errors).
    measured: a dict that gets the listing's seconds and the growth of Python's memory at its peak (the listing alone)."""
    path = write_form(str(tmp_path / form), form, n)
    res = str(tmp_path / form / "res.csv")
    found = [i for i in range(1, n + 1) if i % 400 == 399 or i == n - 10]
    with open(res, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow([OE.ROW_COLUMN, "Seq", "State"])
        w.writerows([i, i, "bad"] for i in found)
    db = str(tmp_path / form / "store" / "errors.sqlite")
    if measured is not None:
        # how the file is written is decided once from its first 1 MB (csv_dialect.detect keeps the answer, and Family 1 has asked before a rule runs):
        # asked here first, so that what is measured is the reading of the file itself. The first asking is measured apart.
        from agentic import csv_dialect
        tracemalloc.start()
        b0 = tracemalloc.get_traced_memory()[0]
        csv_dialect.detect(path)
        measured["detect_peak"] = tracemalloc.get_traced_memory()[1] - b0
        tracemalloc.stop()
        tracemalloc.start()
    base, t0 = (tracemalloc.get_traced_memory()[0] if measured is not None else 0), time.time()
    got = OE.ingest(db, "errors/other/forms", "bad states", res, {"f.csv": path})
    if measured is not None:
        measured.update(seconds=time.time() - t0, peak=tracemalloc.get_traced_memory()[1] - base)
        tracemalloc.stop()
    assert got["total"] == len(found) and got["files"] == {"f.csv": n}
    return db, path, OE.list_errors(db, limit=10 ** 6)


def test_the_errors_of_a_semicolon_a_tab_and_a_utf16_file_equal_those_of_the_plain_file(tmp_path):
    n = 2500
    got = {form: listed(tmp_path, form, n) for form in FORMS}
    plain = [(e["file"], e["row"], e["cells"]) for e in got["plain"][2]]
    assert [x[1] for x in plain] == [i for i in range(1, n + 1) if i % 400 == 399 or i == n - 10]
    assert all(c == r for (_f, k, c), r in zip(plain, (r for r in form_rows(n) if r[4] == "bad")))            # the row's own cells, the decimal comma kept as written
    for form in FORMS[1:]:
        assert [(e["file"], e["row"], e["cells"]) for e in got[form][2]] == plain, form
    # where in the file: row 1 is the first row under the header; the real line of the file is given beside it (line = row + header line)
    for form, header_line in (("plain", 1), ("semicolon", 2), ("tab", 1), ("utf16", 2)):
        db, path, errs = got[form]
        e = OE.get_error(db, errs[0]["error"])
        assert e["row"] == 399 and e["line"] == 399 + header_line and e["header_line"] == header_line, (form, e["line"])
        assert e["where"] == "row 399 of f.csv (line %d of the file)" % (399 + header_line)
        w = OE.window(db, e["error"], 3, 3)
        assert [(r["row"], r["line"]) for r in w["rows"]] == [(k, k + header_line) for k in range(396, 403)]
        assert ("row 1 is on line %d" % (header_line + 1) in w["order"]) == (header_line > 1), w["order"]
        fx = OE.facts(e, w, "")
        assert "the first row under the line of column names is row 1" in fx["where"] and "line %d of the file" % (399 + header_line) in fx["where"]
        assert ("semicolon" in e["written_as"]) == (form in ("semicolon", "utf16")) and ("UTF-16" in e["written_as"]) == (form == "utf16")
        # the markers are bytes of the file at the start of a row: the row read from each marker is that row
        con = OE.connect(db, create=False)
        marks = [(x["row"], x["offset"], x["line"]) for x in con.execute("SELECT * FROM checkpoint ORDER BY row")]
        con.close()
        assert [m[0] for m in marks] == [1, 1001, 2001] and [m[2] for m in marks] == [m[0] + header_line for m in marks]
        for row, offset, _line in marks:
            assert next(OE.rows_from(path, offset, row))[2][0] == str(row), (form, row)
    assert "lines above the header" in OE.requirement_words() and "first row under the header as row 1" in OE.requirement_words()


def test_the_window_near_the_end_of_100000_rows_of_a_semicolon_and_a_utf16_file_equals_the_plain_files(tmp_path, capsys):
    n, mb, said, wins = 100000, 1024.0 * 1024, [], {}
    for form in ("plain", "semicolon", "utf16"):
        took = {}
        db, path, errs = listed(tmp_path, form, n, took)
        t_ingest, peak_ingest = took["seconds"], took["peak"]
        last = [e for e in errs if e["row"] == n - 10][0]
        tracemalloc.start()
        base = tracemalloc.get_traced_memory()[0]
        t0 = time.time()
        w = OE.window(db, last["error"], 25, 25)
        t_window, peak_window = time.time() - t0, tracemalloc.get_traced_memory()[1] - base
        s = OE.window(db, last["error"], 20, 20, same="Channel")
        tracemalloc.stop()
        wins[form] = ([(r["row"], r["cells"], r["position"]) for r in w["rows"]], [(r["row"], r["cells"]) for r in s["rows"]])
        assert w["rows_read"] <= OE.CHECKPOINT_ROWS + 51 and s["rows_read"] < 3 * OE.CHECKPOINT_ROWS          # read by seeking, never from the start
        assert peak_window < 1 * mb and peak_ingest < 4 * mb and t_window < 2.0, (form, peak_window, peak_ingest, t_window)
        said.append("%s (%.1f MB): listed in %.2f s with the memory tracer on (memory grew %.2f MB at its peak); the window of row %s read in %.4f s, %s rows read, "
                    "memory grew %.3f MB; deciding how the file is written, once, from its first 1 MB: %.2f MB" % (
                        form, os.path.getsize(path) / mb, t_ingest, peak_ingest / mb, "{:,}".format(n - 10), t_window,
                        "{:,}".format(w["rows_read"]), peak_window / mb, took["detect_peak"] / mb))
    assert [x[0] for x in wins["plain"][0]] == list(range(n - 35, n + 1)) and all(c[0] == str(k) for k, c, _p in wins["plain"][0])
    assert wins["semicolon"] == wins["plain"] and wins["utf16"] == wins["plain"]
    with capsys.disabled():
        print("\n100,000 rows in three forms:\n  " + "\n  ".join(said))


def test_a_file_written_with_line_ends_of_the_old_kind_and_a_cell_over_two_lines_keeps_rows_and_lines_right(tmp_path):
    # \r alone as the line end (read as lines by csv_dialect's text reading); and in another file a quoted cell that holds a line break
    folder = str(tmp_path / "old")
    os.makedirs(folder)
    a, b = os.path.join(folder, "a.csv"), os.path.join(folder, "b.csv")
    with open(a, "wb") as fb:
        fb.write(b"K,V\r" + b"".join(b"%d,%s\r" % (i, b"bad" if i == 7 else b"ok") for i in range(1, 11)))
    with open(b, "wb") as fb:
        fb.write(b'K,V,Note\n1,ok,"two\nlines"\n2,bad,x\n3,ok,y\n')
    for path, row, line in ((a, 7, 8), (b, 2, 4)):
        res = path + ".res.csv"
        with open(res, "w", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerows([[OE.ROW_COLUMN, "K", "V"], [row, row, "bad"]])
        db = path + ".store/errors.sqlite"
        OE.ingest(db, "errors/other/old", "bad", res, {os.path.basename(path): path})
        e = OE.list_errors(db)[0]
        assert (e["row"], e["line"], e["cells"][:2]) == (row, line, [str(row), "bad"]), e
        w = OE.window(db, e["error"], 1, 1)
        assert [r["row"] for r in w["rows"]] == [row - 1, row, row + 1] and w["rows"][0]["cells"][0] == str(row - 1)


def test_a_source_file_that_is_not_a_table_is_refused_in_a_plain_sentence(tmp_path):
    notes, binary = str(tmp_path / "notes.csv"), str(tmp_path / "picture.csv")
    with open(notes, "w", encoding="utf-8") as fh:
        fh.write("".join("line %d of some notes without any cells\n" % i for i in range(1, 30)))
    with open(binary, "wb") as fb:
        fb.write(bytes(range(256)) * 64)
    res = str(tmp_path / "res.csv")
    with open(res, "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows([[OE.ROW_COLUMN], [3]])
    db = str(tmp_path / "store" / "errors.sqlite")
    for k, path in enumerate((notes, binary)):
        name = os.path.basename(path)
        with pytest.raises(OE.Refused) as e:
            OE.ingest(db, "errors/other/refused%d" % k, "rows of notes", res, {name: path})
        said = str(e.value)
        assert said.startswith("The rule 'rows of notes' reads a file that is not a table: %s cannot be read as a table" % name) and said.endswith("No error is listed for this rule.")
        assert "Traceback" not in said and "Error" not in said
    assert OE.list_errors(db) == [] and [(x["total"], bool(x["refused"])) for x in OE.listings(db)] == [(0, True), (0, True)]


def test_a_store_written_before_the_file_form_was_read_still_opens_and_reads_the_plain_form(tmp_path):
    db, path, errs = listed(tmp_path, "plain", 1200)
    con = OE.connect(db)
    con.executescript("ALTER TABLE error DROP COLUMN line; ALTER TABLE checkpoint DROP COLUMN line; ALTER TABLE source DROP COLUMN form;")
    con.commit()
    con.close()
    e = OE.get_error(db, errs[0]["error"])                      # read without the added columns: no line is claimed
    assert e["line"] is None and e["where"] == "row 399 of f.csv" and e["header_line"] == 1
    w = OE.window(db, e["error"], 2, 2)
    assert [r["cells"][0] for r in w["rows"]] == ["397", "398", "399", "400", "401"] and w["rows"][0]["line"] is None


# ---------------------------------------------------------------------------------------------- 5. hostile input
def test_hostile_input_on_every_route_is_refused_in_a_plain_sentence_and_never_fails(world):
    e = first_error(world)
    one = "%s/%d" % (world.base, e["error"])
    bad_400 = [
        ("GET", "/api/other-errors/abc", None), ("GET", "/api/other-errors/-1", None), ("GET", "/api/other-errors/1.5", None), ("GET", "/api/other-errors/0", None),
        ("GET", world.base + "?offset=-1", None), ("GET", world.base + "?limit=0", None), ("GET", world.base + "?limit=many", None), ("GET", world.base + "?item=a%00b", None),
        ("GET", world.base + "/abc", None), ("GET", world.base + "/-5", None), ("GET", world.base + "/1e3", None),
        ("GET", one + "/window?n=-1", None), ("GET", one + "/window?m=-1", None), ("GET", one + "/window?n=abc", None), ("GET", one + "/window?n=1.5", None),
        ("GET", one + "/window?n=99999", None), ("GET", one + "/window?n=1%00", None), ("GET", one + "/window?same=../../etc/passwd", None),
        ("GET", one + "/window?same=NoSuchColumn", None), ("GET", one + "/window?same=Queue%00", None),
        ("POST", one + "/isolate", {}), ("POST", one + "/isolate", {"admin": 7}), ("POST", one + "/isolate", {"admin": "S", "n": -1, "standin": True}),
        ("POST", one + "/isolate", {"admin": "S", "n": [1], "standin": True}), ("POST", one + "/isolate", {"admin": "S", "m": {"a": 1}, "standin": True}),
        ("POST", one + "/isolate", {"admin": "S", "n": True, "standin": True}), ("POST", one + "/isolate", {"admin": "S", "standin": "yes"}),
        ("POST", one + "/isolate", {"admin": "S", "same": 5, "standin": True}), ("POST", one + "/isolate", {"admin": "S", "same": "/etc/passwd", "standin": True}),
        ("POST", one + "/isolate", {"admin": "S\x00", "standin": True}), ("POST", one + "/isolate", {"admin": "x" * 5000, "standin": True}),
        ("POST", one + "/isolate", [1, 2]), ("POST", one + "/isolate", "not json"),
        ("POST", one + "/group-column", {}), ("POST", one + "/group-column", {"column": "Queue"}), ("POST", one + "/group-column", {"column": 3, "admin": "S"}),
        ("POST", one + "/group-column", {"column": "../x", "admin": "S"}), ("POST", one + "/group-column", {"column": "Queue\x00", "admin": "S"}),
        ("POST", one + "/group-column", {"column": "Queue", "admin": "S", "why": ["a"]}),
        ("GET", world.base + "/mapping", None), ("GET", world.base + "/mapping?file=/etc/passwd", None), ("GET", world.base + "/mapping?file=../bench/bench_log.csv", None),
        ("GET", world.base + "/mapping?file=" + world.csv, None), ("GET", world.base + "/mapping?file=bench_log.csv%00", None), ("GET", world.base + "/mapping?file=x.txt", None),
    ]
    for method, url, body in bad_400:
        r = world.c.open(url, method=method, data=body, content_type="application/json") if isinstance(body, str) else world.c.open(url, method=method, json=body)
        j = r.get_json(silent=True) or {}
        assert r.status_code == 400, (method, url, body, r.status_code, r.data[:200])
        assert isinstance(j.get("error"), str) and len(j["error"]) > 20 and "Traceback" not in j["error"] and "Error(" not in j["error"], (url, j)
    # a number that is well written and names nothing: "no such ..." in a plain sentence (404, as the page of an error of the tree answers), never a failure
    for url in ("/api/other-errors/987654", world.base + "/987654", world.base + "/987654/window", world.base + "/mapping?file=nothing_here.csv"):
        r = world.c.get(url)
        assert r.status_code == 404 and len(r.get_json()["error"]) > 20, (url, r.status_code)
    r = world.c.post(world.base + "/987654/isolate", json={"admin": "S"})
    assert r.status_code == 404
    # what the address checker of the application answers for a NUL or a path in the address is not a failure either
    for url in (world.base + "/%00", "/api/other-errors/..%2F..%2Fetc", world.base + "/1/window/../../../x"):
        assert world.c.get(url).status_code in (400, 404), url
    assert world.c.get(one + "/window?n=0&m=0").get_json()["rows"][0]["row"] == e["row"]             # 0 is a number of rows: the row alone
    assert world.c.get(world.base + "/mapping?file=bench_log.csv").status_code == 200
    assert world.c.get("/other-error").status_code == 200


# ---------------------------------------------------------------------------------------------- 6. the page files
def test_the_page_explains_every_field_chooses_nothing_and_its_script_is_sound(tmp_path):
    with open(os.path.join(APP, "app", "static", "other_error.html"), encoding="utf-8") as fh:
        page = fh.read()
    with open(os.path.join(APP, "app", "static", "js", "other_error.js"), encoding="utf-8") as fh:
        script = fh.read()
    labels = re.findall(r"<label class=\"f\"", page)
    with_why = re.findall(r"<label class=\"f\"[^>]*>(?:(?!</label>).)*</label>\s*<div class=\"why\"[^>]*>((?:(?!</div>).)*)</div>", page, flags=re.S)
    assert len(labels) >= 6 and len(with_why) == len(labels)                    # every field label has its why-line directly under it
    assert all(len(re.sub(r"<[^>]+>", "", w).strip()) > 40 for w in with_why), [w for w in with_why if len(w) <= 40]
    assert "class=\"f\"" not in script                                          # the script adds no field of its own without a why-line
    for text in (page, script):                                                 # nothing is chosen in advance: no ticked box, no chosen option, no filled-in value
        assert not re.search(r"<(?:option|input)[^>]*\s(?:selected|checked)\b|\.(?:selected|checked|selectedIndex)\s*=[^=]", text)
        assert not re.search(r"<input[^>]*\svalue=", text)
    first_options = re.findall(r"<select[^>]*>\s*<option value=\"([^\"]*)\"", page)
    assert first_options == ["", ""]                                            # each list starts on "choose ..."
    assert "<script src=\"/static/js/terminal_agent.js\"></script>" in page and "<script type=\"module\" src=\"/static/js/other_error.js\"></script>" in page
    assert "meaning not sourced" in page and "Teledyne LeCroy" in page and "never guesses" in page
    ids = set(re.findall(r"\bid=\"([^\"]+)\"", page))
    used = set(re.findall(r"\$\(\"([^\"]+)\"\)", script))
    assert used and used <= ids, sorted(used - ids)                             # every element the script fills is on the page
    tops = re.findall(r"^(?:export\s+)?(?:async\s+)?(?:const|let|var|function|class)\s+([A-Za-z_$][\w$]*)", script, flags=re.M)
    assert len(tops) > 10 and len(tops) == len(set(tops)), sorted(t for t in set(tops) if tops.count(t) > 1)
    if os.path.exists(NODE):
        copy_ = tmp_path / "other_error.mjs"
        shutil.copy(os.path.join(APP, "app", "static", "js", "other_error.js"), str(copy_))
        p = subprocess.run([NODE, "--check", str(copy_)], capture_output=True, text=True, timeout=60)
        assert p.returncode == 0, p.stderr[-800:]


HARNESS = r"""
import fs from "fs";
const dir = process.argv[2];
const data = JSON.parse(fs.readFileSync(dir + "/answers.json", "utf8"));
const els = {}, asked = [];
const el = id => els[id] || (els[id] = { id, value: "", textContent: "", innerHTML: "", className: "", listeners: {}, addEventListener(t, f) { this.listeners[t] = f; } });
globalThis.document = { getElementById: el, title: "" };
globalThis.location = { search: data.search };
globalThis.fetch = async (url, opt) => { const key = ((opt && opt.method) || "GET") + " " + url.replace(/\?.*$/, ""); asked.push(key + (url.includes("?") ? "?" + url.split("?")[1] : ""));
  const j = data.answers[key]; return { ok: !!j, statusText: "no canned answer", json: async () => j || { error: "no canned answer for " + key } }; };
const wait = () => new Promise(r => setTimeout(r, 30));
await import(dir + "/other_error.js");
await wait();
const out = { title: el("page-title").textContent, row: el("row-out").innerHTML, same_options: el("win-same").innerHTML, same_value: el("win-same").value,
              cannot: el("cannot-out").innerHTML, why_n: el("why-n").textContent, n_value: el("win-n").value, m_value: el("win-m").value };
await el("btn-window").listeners.click(); await wait();
out.window_without_a_choice = el("window-status").textContent; out.asked_before_choice = asked.slice();
el("win-same").value = "all"; el("win-n").value = "4"; el("win-m").value = "7";
await el("btn-window").listeners.click(); await wait();
out.window = el("window-out").innerHTML; out.window_status = el("window-status").textContent;
await el("btn-isolate").listeners.click(); await wait();
out.isolate_without_a_name = el("isolate-status").textContent;
el("name").value = "Sagar";
await el("btn-isolate").listeners.click(); await wait();
out.isolation = el("isolate-out").innerHTML; out.history = el("history-out").innerHTML; out.asked = asked;
console.log("RESULT " + JSON.stringify(out));
"""


def test_the_pages_script_shows_the_servers_answers_and_chooses_nothing(world, tmp_path):
    """The page's own script, run by node against the answers of the real routes (a made-up page of elements, no browser)."""
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    e = first_error(world)
    one = "%s/%d" % (world.base, e["error"])
    answers = {"GET " + one: world.c.get(one).get_json(), "GET " + one + "/window": world.c.get(one + "/window?n=4&m=7").get_json(),
               "POST " + one + "/isolate": world.c.post(one + "/isolate", json={"admin": "Sagar", "n": 4, "m": 7, "standin": True}).get_json(),
               "GET " + one + "/isolations": world.c.get(one + "/isolations").get_json()}
    d = tmp_path / "page"
    os.makedirs(str(d))
    for name in ("other_error.js", "api.js"):
        shutil.copy(os.path.join(APP, "app", "static", "js", name), str(d / name))
    (d / "package.json").write_text("{\"type\": \"module\"}", encoding="utf-8")
    (d / "answers.json").write_text(json.dumps({"search": "?run=%d&error=%d" % (world.rid, e["error"]), "answers": answers}), encoding="utf-8")
    (d / "harness.mjs").write_text(HARNESS, encoding="utf-8")
    p = subprocess.run([NODE, str(d / "harness.mjs"), str(d)], capture_output=True, text=True, encoding="utf-8", timeout=60, cwd=str(d))
    line = next((ln for ln in p.stdout.splitlines() if ln.startswith("RESULT ")), None)
    assert line, (p.stdout[-500:], p.stderr[-1500:])
    out = json.loads(line[7:])
    assert out["title"] == "One error: row %d of bench_log.csv" % e["row"]
    for c in ("Command", "Queue", "Latency_us", "Result"):                       # no column without its meaning, or the plain statement that none is known
        assert "<b>%s</b>" % c in out["row"]
    assert "Queue ID the command was sent on." in out["row"] and "meaning not sourced" in out["row"] and "The approved dictionary gives no meaning for this column." in out["row"]
    # nothing is chosen in advance: the list stays on "choose ...", the numbers are empty, and pressing the button without a choice reads nothing
    assert out["same_value"] == "" and out["n_value"] == "" and out["m_value"] == "" and "selected" not in out["same_options"]
    assert "only rows with the same value of “Queue”" in out["same_options"] and "Latency_us" not in out["same_options"]
    assert "nothing is chosen for you" in out["window_without_a_choice"] and out["asked_before_choice"] == ["GET " + one]
    assert "Leave it empty to use 15 rows" in out["why_n"] and "starting value" in out["why_n"]
    assert out["window"].count("<tr class=\"\">") == 11 and out["window"].count("<tr class=\"err\">") == 1 and "THE ERROR" in out["window"] and "12 rows shown." == out["window_status"]
    assert "GET %s/window?n=4&m=7" % one in out["asked"]                           # "every row" sends no column
    assert "Type your name" in out["isolate_without_a_name"]
    assert "STAND-IN" in out["isolation"] and "written by the code, from the file" in out["isolation"] and "Asked by Sagar" in out["history"]
    assert "Teledyne LeCroy" in out["cannot"] and "Missing: no column" in out["cannot"]


# ---------------------------------------------------------------------------------------------- 7. the stated mapping to the NVMe command path
def test_the_mapping_names_each_needed_column_of_the_disguised_file_with_the_dictionarys_own_words():
    d = dictionary(DISGUISED, kinds=["Op"])
    live = os.path.join(EXPERIMENT, "root", "knowledge", "dictionaries", "340ec36b5800", "cmd_trace_export.current.json")
    if os.path.exists(live):                        # while the experiment's folder is still there: the copy above is its dictionary, word for word
        with open(live, encoding="utf-8") as fh:
            real = json.load(fh)
        assert [(c["column"], c["meaning"], c["source"]["kind"]) for c in real["columns"]] == DISGUISED
        d = real
    before = json.dumps(d, sort_keys=True)
    m = OE.nvme_command_mapping(d)
    assert json.dumps(d, sort_keys=True) == before and m["changes_nothing"] is True          # it only reports
    assert m["holds_what_is_needed"] is True and m["missing"] == [] and m["not_decided"] == []
    got = {n["need"]: {f["role"]: [h["column"] for h in f["columns"]] for f in n["found"]} for n in m["needs"]}
    # the answer sheet of the experiment: Op = the command name, Code = the opcode, QID = the queue, Tag = the command identifier, T Submit = the time of
    # submission, T Done = the time of completion, Svc Time = the latency, Result = the completion status
    assert got == {"command": {"the command's name": ["Op"], "the command's operation code (opcode)": ["Code"]}, "queue": {"the queue": ["QID"]},
                   "identifier": {"the command's identifier": ["Tag"]}, "submit_time": {"the time it was sent": ["T Submit [ns]"]},
                   "completion": {"the time it completed": ["T Done [ns]"], "how long it took": ["Svc Time [us]"]}, "status": {"the status": ["Result"]}}
    sheet = os.path.join(EXPERIMENT, "answer_sheet.json")
    if os.path.exists(sheet):
        with open(sheet, encoding="utf-8") as fh:
            truth = json.load(fh)["columns"]
        for col, word in (("Op", "command name"), ("Code", "opcode"), ("QID", "queue"), ("Tag", "command identifier"), ("T Submit [ns]", "submission"),
                          ("T Done [ns]", "completion"), ("Svc Time [us]", "latency"), ("Result", "status")):
            assert word in truth[col]["must_say"], (col, truth[col]["must_say"])
    means = dict((c, mm) for c, mm, _k in DISGUISED)
    for n in m["needs"]:                            # the evidence is the dictionary's own sentence, and an unsourced meaning is said to be unsourced
        assert n["state"] == "identified" and n["sentence"].startswith("Identified: ")
        for f in n["found"]:
            for h in f["columns"]:
                assert h["evidence"] == means[h["column"]] and h["words_found"] in h["evidence"].lower() and h["evidence"] in n["sentence"]
    q = next(n for n in m["needs"] if n["need"] == "queue")["found"][0]["columns"][0]
    assert q["sourced"] is False and q["source_words"].startswith("meaning not sourced")
    assert "not fed" in m["verdict"]
    # the page's same-value choice for this file: only columns the dictionary's own words name, each with the sentence as the reason
    offered = OE.group_columns(os.path.join(EXPERIMENT, "no_such_store.sqlite"), d, [c for c, _m, _k in DISGUISED], "cmd_trace_export.csv")
    assert [c["column"] for c in offered] == ["QID", "Tag", "Op"] and all(c["named_by"] == "the dictionary" and len(c["why"]) > 60 for c in offered)


def test_the_mapping_says_what_is_missing_and_never_chooses_between_two_columns():
    half = dictionary([("Op", "Name of the command the bench issued.", MODEL), ("T Start", "Time at which the command was sent, in milliseconds.", MODEL),
                       ("Dur", "Duration of the command in milliseconds.", DATA), ("Temp", "Temperature of the board in degrees Celsius.", DATA)])
    m = OE.nvme_command_mapping(half)
    assert m["holds_what_is_needed"] is False and m["not_decided"] == []
    assert m["missing"] == ["the queue the command was sent on", "the command's identifier", "the command's status"]
    state = {n["need"]: n["state"] for n in m["needs"]}
    assert state == {"command": "identified", "queue": "missing", "identifier": "missing", "submit_time": "identified", "completion": "identified", "status": "missing"}
    assert "does not hold everything" in m["verdict"] and "missing: the queue the command was sent on" in m["verdict"]
    assert all(n["sentence"].startswith("Missing: no column's meaning") for n in m["needs"] if n["state"] == "missing")
    # a column's NAME is never read: a column called "Status" whose meaning says something else is not the status
    named_only = dictionary([("Status", "Free text typed by the operator.", MODEL), ("QID", "", MODEL)])
    assert OE.nvme_command_mapping(named_only)["missing"] == [w for _k, w, _r in OE.NEEDS]
    # two columns whose meanings both fit one need: reported, not chosen
    two = dictionary([("Q1", "Queue ID on the host side.", MODEL), ("Q2", "Queue ID on the device side.", MODEL)])
    q = next(n for n in OE.nvme_command_mapping(two)["needs"] if n["need"] == "queue")
    assert q["state"] == "more than one column fits" and "the admin must say which" in q["sentence"] and "\"Q1\"" in q["sentence"] and "\"Q2\"" in q["sentence"]
    assert OE.nvme_command_mapping(two)["not_decided"] == ["the queue the command was sent on"]
    none = OE.nvme_command_mapping(None)
    assert none["holds_what_is_needed"] is False and "No dictionary of this file is approved" in none["verdict"]


def test_the_stand_in_code_of_a_rows_rule_names_the_row_of_the_file():
    proc = {"source_data": [{"file": "bench_log.csv", "columns": ["Result"]}], "steps": ["read", PR.STANDIN_ROWS_STEP % ("Result", "timeout")],
            "output": {"columns": [OE.ROW_COLUMN, "Command", "Queue", "Latency_us", "Result"], "order": "the file's own order"}}
    code = PR.standin_share_code(proc)
    assert code and PR.check_code(code) == [] and repr(OE.ROW_COLUMN) in code
    assert PR.standin_share_code(dict(proc, output={"columns": ["Command", "Result"], "order": ""})) is None          # no row number: no stand-in code
