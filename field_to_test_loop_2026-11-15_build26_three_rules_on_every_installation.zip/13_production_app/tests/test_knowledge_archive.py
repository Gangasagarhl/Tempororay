"""The knowledge base keeps what proved a result (project statement: "archives validated results (PCIe traces, external workloads) as a
knowledge base"; coverage check of 2026-11-14, row S10, work item B6): the rows of the window around a validated error stay when its
upload is deleted, and an external workload is kept as given, validated only by the admin's own action.

    python3 -m pytest -q -p no:cacheprovider tests/test_knowledge_archive.py

Everything runs in temporary folders; the tree is built from samples/clean_five_files/S17_io_timeout_abort_reset.
"""
import json
import os
import shutil
import sqlite3
import sys
import tempfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
sys.path.insert(0, HERE)

from nvme_hier import archive as AR          # noqa: E402
from nvme_hier import defect_graph as DG     # noqa: E402
from nvme_hier import tree_api as T          # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
LOWER = ("nvme_transaction", "split", "link", "packets")


def _one_core():
    """The sample is read on one core here: the result is the same, and a test must not compete with the owner's running work."""
    was = os.environ.get("F2T_WORKERS")
    os.environ["F2T_WORKERS"] = "1"
    return was


def _cores_back(was):
    if was is None:
        os.environ.pop("F2T_WORKERS", None)
    else:
        os.environ["F2T_WORKERS"] = was


def _copy_db(src, dst):
    a = sqlite3.connect("file:%s?mode=ro" % src, uri=True)
    b = sqlite3.connect(dst)
    a.backup(b)
    a.close()
    b.close()


@pytest.fixture(scope="module")
def s17(tmp_path_factory):
    """The tree of the sample S17 (a read that timed out, was aborted, then a reset), built once: its hier.sqlite."""
    if not os.path.isdir(S17) or not all(os.path.exists(os.path.join(S17, n)) for n in NAMES.values()):
        pytest.skip("the S17 sample recording is not on this machine (the code-only zip carries no samples)")
    from nvme_hier import builder as B, loader as L, rules as RL
    db = str(tmp_path_factory.mktemp("s17_tree") / "hier.sqlite")
    was = _one_core()
    try:
        L.load_upload(db, {k: os.path.join(S17, n) for k, n in NAMES.items()})
        B.build(db)
        RL.apply(db)
    finally:
        _cores_back(was)
    return db


def _an_error(db, rule_like="cmd.%"):
    """An error of the sample with its command in the middle of the recording: (error number, its command's row)."""
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        n = con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0]
        r = con.execute("SELECT id, cmd_rowid FROM finding WHERE rule LIKE ? AND cmd_rowid > 20 AND cmd_rowid < ? ORDER BY id LIMIT 1", (rule_like, n - 20)).fetchone()
        assert r, "the sample has no command-level error away from the ends of the recording"
        return r[0], r[1]
    finally:
        con.close()


def _expected(db, command_rows):
    """The rows of these commands straight from the tree, by its own public look-ups (another way than the archive reads them):
    {level: {row: (cells, parent, relation, time, number)}}."""
    tree = T.Tree(db)
    try:
        out = {lv: {} for lv in T.LEVELS}
        for c in command_rows:
            r = tree.get("nvme_command", c)
            out["nvme_command"][r.row] = (dict(r), r.parent, r.relation, r.time_ps, r.number)
            for lv in LOWER:
                for r in tree.descendants("nvme_command", c, lv, include_context=True):
                    out[lv][r.row] = (dict(r), r.parent, r.relation, r.time_ps, r.number)
        return out
    finally:
        tree.close()


def _as_read(w):
    return {lv: {r["row"]: (r["cells"], tuple(r["parent"]) if r["parent"] else None, r["relation"], r["time_ps"], r["number"]) for r in blk["rows"]}
            for lv, blk in w["levels"].items()}


def test_the_window_of_a_kept_defect_is_archived_and_read_back_equal_to_the_trees_rows(s17, tmp_path, capsys):
    g = DG.DefectGraph(str(tmp_path / "k.sqlite"))
    fid, cmd = _an_error(s17)
    d, _ = g.add_defect("Read aborted by host", "cmd.timeout", "nvme_command", "", "Sagar")
    g.record_occurrence(d, None, "up-s17", fid, "the drive of the sample", "firmware 1", {}, "Sagar")
    r = g.archive_trace(s17, "up-s17", fid, "Sagar", "the admin recorded this error as an occurrence of a defect", n=15, m=15, files=NAMES, trace_name="S17")
    assert r["changed"] and r["complete"] and r["did"].startswith("archived: ") and r["archived_by"] == "Sagar" and r["archived_at"]
    assert (r["n_above"], r["m_below"], r["command_row"]) == (15, 15, cmd) and r["window_words"] == "the error's command with 15 commands above and 15 below"
    assert (r["device"], r["firmware"]) == ("the drive of the sample", "firmware 1")        # from the stored occurrence when the caller gives none
    assert r["files"] == NAMES and r["trace_name"] == "S17" and r["bytes_rows"] <= AR.WINDOW_LIMIT_BYTES
    w = g.archived_trace("up-s17", fid)
    want = _expected(s17, range(cmd - 15, cmd + 16))
    got = _as_read(w)
    assert set(got) == {lv for lv in want if want[lv]} and len(got["nvme_command"]) == 31
    for lv in got:
        assert got[lv] == want[lv], "the archived rows of %s differ from the tree's" % lv
        cols = w["levels"][lv]["columns"]             # every column name the kept rows use, each once, the first row's columns first
        assert len(cols) == len(set(cols)) and set(cols) == {k for cells, *_ in want[lv].values() for k in cells} and w["levels"][lv]["file"] == NAMES[lv]
    assert all(got[lv] for lv in LOWER), "the sample's window has rows at every level"
    assert [c["row"] for c in w["commands"]] == list(range(cmd - 15, cmd + 16)) and all(c["lower_rows"] for c in w["commands"])
    assert g.archived_trace(occurrence_id=g.occurrence(1)["id"], rows=False)["levels"]["packets"]["count"] == len(got["packets"])
    assert g.archived_trace("up-s17", fid, levels=["link"])["levels"].keys() == {"link"}
    assert g.archived_trace("up-s17", fid + 100000) is None
    assert g.archived_traces(d)["archived"] == 1
    with capsys.disabled():
        print("\n  measured on S17, error %d, 15 commands above and 15 below: %d rows, %s" % (fid, sum(len(v) for v in got.values()), r["size_words"]))


def test_the_archived_rows_are_still_read_back_after_the_upload_folder_is_deleted(s17, tmp_path):
    up = tmp_path / "uploads" / "up-s17"
    up.mkdir(parents=True)
    _copy_db(s17, str(up / "hier.sqlite"))
    g = DG.DefectGraph(str(tmp_path / "k.sqlite"))
    fid, cmd = _an_error(s17)
    g.archive_trace(str(up / "hier.sqlite"), "up-s17", fid, "Sagar", "a solution was stored for this error", n=3, m=2)
    before = g.archived_trace("up-s17", fid)
    shutil.rmtree(str(tmp_path / "uploads"))
    after = DG.DefectGraph(str(tmp_path / "k.sqlite")).archived_trace("up-s17", fid)        # a fresh opening, no upload anywhere
    assert after["levels"] == before["levels"] and _as_read(after) == {lv: v for lv, v in _expected(s17, range(cmd - 3, cmd + 3)).items() if v}
    again = g.archive_trace(str(up / "hier.sqlite"), "up-s17", fid, "Meera", "a solution was judged on this error")
    assert not again["changed"] and "the recording is not on this computer any more" in again["did"]
    assert g.archived_trace("up-s17", fid)["levels"] == before["levels"]
    assert [x["by"] for x in g.archived_trace("up-s17", fid)["log"]] == ["Meera", "Sagar"]          # who asked, newest first
    with pytest.raises(ValueError, match="nothing of it was archived before"):
        g.archive_trace(str(up / "hier.sqlite"), "up-s17", fid + 1, "Sagar", "x")


def test_above_the_size_limit_the_errors_own_rows_are_kept_and_the_record_says_what_was_left_out(s17, tmp_path):
    """A hostile window: four packets under the command just above the error each carry a cell a third of the limit long."""
    db = str(tmp_path / "hostile.sqlite")
    _copy_db(s17, db)
    fid, cmd = _an_error(s17)
    tree = T.Tree(db)
    try:
        victims = [r.row for r in tree.descendants("nvme_command", cmd - 1, "packets", include_context=True)][:4]
    finally:
        tree.close()
    assert len(victims) == 4
    con = sqlite3.connect(db)
    for v in victims:
        raw = json.loads(con.execute("SELECT raw FROM pkt WHERE rowid_file=?", (v,)).fetchone()[0])
        raw[next(iter(raw))] = "A" * (AR.WINDOW_LIMIT_BYTES // 3)
        con.execute("UPDATE pkt SET raw=? WHERE rowid_file=?", (json.dumps(raw), v))
    con.commit()
    con.close()
    g = DG.DefectGraph(str(tmp_path / "k.sqlite"))
    r = g.archive_trace(db, "up-hostile", fid, "Sagar", "a hostile window", n=15, m=15)
    assert not r["complete"] and r["bytes_rows"] <= AR.WINDOW_LIMIT_BYTES
    words = r["left_out"]["words"]
    assert "larger than the limit of 32.00 megabytes" in words and "The error's own rows are all kept." in words and "without the rows of the lower levels" in words
    left = r["left_out"]["detail"]["commands_without_their_lower_rows"]
    assert cmd - 1 in left and cmd not in left and not r["left_out"]["detail"]["own_rows_cut"]
    got = _as_read(g.archived_trace("up-hostile", fid))
    own = _expected(db, [cmd])
    for lv in T.LEVELS:
        assert {k: v for k, v in got.get(lv, {}).items() if k in own[lv]} == own[lv], "the error's own rows of %s are not all kept" % lv
    assert len(got["nvme_command"]) == 31                       # the neighbouring commands themselves are kept: only their lower rows are left out
    assert not set(victims) & set(got.get("packets", {}))
    # a limit below the error's own rows: the first of them are kept and the record says from where they are left out
    small = g.archive_trace(s17, "up-small", fid, "Sagar", "a very small limit", n=2, m=2, limit_bytes=4000)
    assert not small["complete"] and small["bytes_rows"] <= 4000 and "from row" in small["left_out"]["words"] and "are left out" in small["left_out"]["words"]


def test_archiving_twice_does_not_duplicate_and_the_widest_window_stays(s17, tmp_path):
    g = DG.DefectGraph(str(tmp_path / "k.sqlite"))
    fid, cmd = _an_error(s17)
    a = g.archive_trace(s17, "up-s17", fid, "Sagar", "a solution was stored for this error", n=4, m=4)
    b = g.archive_trace(s17, "up-s17", fid, "Sagar", "a solution was judged on this error", n=4, m=4)
    c = g.archive_trace(s17, "up-s17", fid, "Sagar", "the test of this error was approved")          # no window given: the archived one
    assert a["changed"] and not b["changed"] and not c["changed"] and "nothing was copied again" in b["did"] and a["fingerprint"] == c["fingerprint"]
    narrower = g.archive_trace(s17, "up-s17", fid, "Sagar", "a narrower look", n=1, m=1)
    assert not narrower["changed"] and (narrower["n_above"], narrower["m_below"]) == (4, 4)
    wider = g.archive_trace(s17, "up-s17", fid, "Sagar", "a wider look", n=6, m=4)
    assert wider["changed"] and (wider["n_above"], wider["m_below"]) == (6, 4) and wider["id"] == a["id"]
    con = sqlite3.connect(g.path)
    try:
        assert con.execute("SELECT COUNT(*) FROM kb_trace").fetchone()[0] == 1
        assert con.execute("SELECT COUNT(*), COUNT(DISTINCT level) FROM kb_trace_level").fetchone() == (5, 5)
        assert con.execute("SELECT COUNT(*) FROM kb_trace_log").fetchone()[0] == 5
    finally:
        con.close()
    assert len(_as_read(g.archived_trace("up-s17", fid))["nvme_command"]) == 11
    # the errors of a recording were numbered anew: the archived window follows its error
    assert g.remap_findings("up-s17", {fid: fid + 5000}) >= 1
    assert g.archived_trace("up-s17", fid) is None and g.archived_trace("up-s17", fid + 5000)["command_row"] == cmd
    for bad, word in ((dict(n=-1), "below 0"), (dict(n=10 ** 6), "above 100"), (dict(m="many"), "whole number"), (dict(n=1.5), "whole number")):
        with pytest.raises(ValueError, match=word):
            g.archive_trace(s17, "up-s17", fid, "Sagar", "x", **bad)
    for bad in ("../../etc/passwd", "up\x00s17", "", 7, None, "/tmp/x"):
        with pytest.raises(ValueError):
            g.archive_trace(s17, bad, fid, "Sagar", "x")
    with pytest.raises(ValueError, match="no error with the number"):
        g.archive_trace(s17, "up-s17", 10 ** 9, "Sagar", "x")


def test_a_workload_is_stored_as_given_and_validated_only_by_the_admins_own_action(tmp_path):
    kb = str(tmp_path / "k.sqlite")
    g = DG.DefectGraph(kb)
    d, _ = g.add_defect("Read aborted by host", "cmd.timeout", "nvme_command", "", "Sagar")
    o = g.record_occurrence(d, None, "up-1", 7, "drive", "fw", {}, "Sagar")
    job = "[global]\n  ioengine=libaio\t\n\n[randread]\nrw=randread   \nbs=4k\n"          # kept to the letter: spaces, tabs and the last line break
    wid = AR.add_workload(kb, "fio", job, "READ: bw=1MiB/s \n", "Sagar", occurrence_id=o, note="run on the bench")
    w = AR.workload(kb, wid)
    assert w["tool"] == "fio" and w["definition"] == job and w["result"] == "READ: bw=1MiB/s \n" and w["result_kind"] == "text"
    assert (w["defect_id"], w["occurrence_id"], w["added_by"]) == (d, o, "Sagar") and w["added_at"]
    assert w["validated"] is False and w["validated_by"] is None and w["validation_words"].startswith("not validated")
    res = {"jobs": [{"jobname": "randread", "read": {"iops": 12.5, "clat_ns": {"percentile": {"99.000000": 4000}}}}], "note": None, "ok": True}
    w2 = AR.workload(kb, AR.add_workload(kb, "a tool of our own", "bench --run 3", res, "Meera", defect_id=d))
    assert w2["result"] == res and w2["result_kind"] == "json" and not w2["validated"]
    for confirm in (None, "yes", 1, "true", False):
        with pytest.raises(ValueError, match="explicit confirmation"):
            AR.validate_workload(kb, wid, "Sagar", confirm)
    assert not AR.workload(kb, wid)["validated"]
    v = AR.validate_workload(kb, wid, "Sagar", True)
    assert v["validated"] and v["validated_by"] == "Sagar" and v["validated_at"] and v["validation_words"].startswith("validated by Sagar on ")
    assert not AR.workload(kb, w2["id"])["validated"]                                   # only the record the admin acted on
    back = AR.validate_workload(kb, wid, "Meera", True, withdraw=True)
    assert not back["validated"] and [x["action"] for x in back["log"]] == ["stored as given, not validated", "validated", "validation taken back"]
    lst = AR.workloads(kb, defect_id=d)
    assert [x["id"] for x in lst] == [w2["id"], wid] and "definition" not in lst[0] and lst[1]["definition_bytes"] == len(job.encode("utf-8"))
    assert AR.workloads(kb, occurrence_id=o)[0]["id"] == wid and AR.workload(kb, 999) is None and AR.validate_workload(kb, 999, "Sagar", True) is None
    # refusals, in plain words, and nothing stored
    n = len(AR.workloads(kb))
    for definition, word in (("x" * (AR.DEFINITION_LIMIT_BYTES + 1), "too large: 0.25 megabytes, at most 0.25 megabytes"), (12, "must be text"), (["fio", "--rw"], "must be text"),
                             ({"job": 1}, "must be text"), (b"fio", "must be text"), (None, "must be text"), ("fio\x00--rw", "NUL character"), ("   ", "is needed")):
        with pytest.raises(ValueError, match=word):
            AR.add_workload(kb, "fio", definition, "ok", "Sagar")
    for kw, word in ((dict(result="y" * (AR.RESULT_LIMIT_BYTES + 1)), "too large"), (dict(result=5), "must be text"), (dict(result=""), "is needed"),
                     (dict(result={}), "is needed"), (dict(result={"a": "\x00"}), "NUL character"), (dict(result="ok", tool="../../bin/sh\x00"), "control character"),
                     (dict(result="ok", tool="t" * 500), "too long"), (dict(result="ok", tool=3), "must be text"), (dict(result="ok", by=""), "is needed"),
                     (dict(result="ok", defect_id=-1), "below 1"), (dict(result="ok", defect_id=4242), "no stored defect"), (dict(result="ok", occurrence_id="x"), "whole number"),
                     (dict(result="ok", occurrence_id=4242), "no stored occurrence"), (dict(result="ok", note=7), "note")):
        args = dict(dict(tool="fio", definition="fio job", by="Sagar"), **kw)
        with pytest.raises(ValueError, match=word):
            AR.add_workload(kb, args.pop("tool"), args.pop("definition"), args.pop("result"), args.pop("by"), **args)
    assert len(AR.workloads(kb)) == n


def test_one_look_up_reports_a_link_between_the_two_stores_only_when_the_data_holds_one(tmp_path):
    kb, packet_kb = str(tmp_path / "k.sqlite"), str(tmp_path / "knowledge.sqlite")
    g = DG.DefectGraph(kb)
    d, _ = g.add_defect("Read aborted by host", "cmd.timeout", "nvme_command", "", "Sagar", term_key="cmd.timeout|read|aborted")
    g.record_occurrence(d, None, "up-1", 7, "drive", "fw", {}, "Sagar")
    r = AR.across_stores(kb, packet_kb, "cmd.timeout|read|aborted")
    assert r["link"] == AR.NO_LINK == "no link between the two stores for this defect" and r["packet_store"] is None and "not on this computer" in r["why"]
    assert r["defect"]["occurrences"] == 1 and r["defect"]["archived_windows"] == 0 and AR.across_stores(kb, packet_kb, "no such defect") is None
    from stage2 import kgdb as KG
    con = sqlite3.connect(packet_kb)
    con.executescript(KG.SCHEMA)
    con.execute("INSERT INTO signature (sig, pattern, feats, first_seen, seen) VALUES ('C-TIMEOUT', 'P19', '[]', 1, 4)")
    con.commit()
    assert AR.across_stores(kb, packet_kb, d)["link"] == AR.NO_LINK                 # another error type: similar words are never matched
    con.execute("INSERT INTO signature (sig, pattern, feats, first_seen, seen) VALUES ('CMD.TIMEOUT', 'P20', '[]', 2, 3)")
    con.execute("INSERT INTO node (id, kind, sig) VALUES ('CMD.TIMEOUT::c1', 'cause', 'CMD.TIMEOUT')")
    con.commit()
    con.close()
    r = AR.across_stores(kb, packet_kb, "Read aborted by HOST")
    hit = r["packet_store"]["error_types"]
    assert r["link"].startswith("the same identifier is used in both stores") and [(h["error_type"], h["times_seen"], h["causes"]) for h in hit] == [("CMD.TIMEOUT", 3, 1)]
    con = sqlite3.connect(packet_kb)
    assert con.execute("SELECT COUNT(*) FROM signature").fetchone()[0] == 2         # read-only: nothing was written to the earlier store
    con.close()


def test_a_database_of_the_previous_version_opens_and_gains_the_tables(tmp_path):
    p = str(tmp_path / "old.sqlite")
    con = sqlite3.connect(p)
    con.executescript(DG.SCHEMA)                                                    # the tables of the version before 2026-11-14: dg_* only
    con.execute("ALTER TABLE dg_occurrence ADD COLUMN test_path TEXT")
    con.execute("INSERT INTO dg_defect (key, name, rule, level, what, created, created_by) VALUES ('read aborted', 'Read aborted', 'cmd.timeout', 'nvme_command', '', 1, 'Sagar')")
    con.execute("INSERT INTO dg_occurrence (defect_id, upload_id, finding_id, device, firmware, isolation, admin, at) VALUES (1, 'up-old', 7, 'drive', 'fw', '{}', 'Sagar', 1)")
    con.commit()
    assert not [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE name LIKE 'kb_%'")]
    con.close()
    g = DG.DefectGraph(p)
    con = sqlite3.connect(p)
    try:
        assert {"kb_trace", "kb_trace_level", "kb_trace_log", "kb_workload", "kb_workload_log"} <= {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    finally:
        con.close()
    assert g.find_defect("Read aborted")["id"] == 1 and g.view(1)["seen"] == 1 and g.status("up-old", [7])[7]["state"] == "isolated"
    assert g.archived_trace("up-old", 7) is None and g.archived_traces(1) == {"occurrences": [dict(g.archived_traces(1)["occurrences"][0], archived=False)], "archived": 0, "not_archived": 1}
    assert "not kept" in g.archived_traces(1)["occurrences"][0]["words"]
    assert AR.workload(p, AR.add_workload(p, "fio", "fio job", "ok", "Sagar", occurrence_id=1))["defect_id"] == 1
    assert AR.across_stores(p, None, 1)["link"] == AR.NO_LINK
    # a database with nothing at all, opened by the archive alone, gains its tables too
    empty = str(tmp_path / "empty.sqlite")
    assert AR.workloads(empty) == [] and AR.read_window(empty, "up-x", 1) is None


# ---------------------------------------------------------------------------------------------- the routes
@pytest.fixture(scope="module")
def app_s17(s17):
    """A throw-away application (its own root, the model connection pointing nowhere) with the S17 tree as the upload up-s17."""
    import fuzz_app as F
    from agentic import core
    if not os.path.isdir(F.BASE):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    root = tempfile.mkdtemp(prefix="kb_archive_%d_" % os.getpid())
    kick = core.Engine.kick
    was = _one_core()
    try:
        app, c, _k, _r = F.setup(root)
        d = os.path.join(root, "uploads", "up-s17")
        os.makedirs(d)
        _copy_db(s17, os.path.join(d, "hier.sqlite"))
        with open(os.path.join(d, "meta.json"), "w", encoding="utf-8") as fh:
            json.dump({"upload_id": "up-s17", "created": 1, "operator": "t", "device": "", "trace_name": "S17 sample", "recording_date": "", "notes": "",
                       "files": {k: os.path.join(S17, n) for k, n in NAMES.items()}, "status": "loaded", "thresholds": {}, "file_stats": {}}, fh)
        yield c, root
    finally:
        _cores_back(was)
        core.Engine.kick = kick
        shutil.rmtree(root, ignore_errors=True)


def test_the_routes_keep_the_rows_with_the_admins_actions_and_give_them_back_after_the_upload_is_gone(app_s17, s17):
    c, root = app_s17
    fid, cmd = _an_error(s17)
    d = c.post("/api/dg/defects", json={"name": "Read aborted by host after late completion", "rule": "cmd.timeout", "level": "nvme_command", "what": "a read", "admin": "Sagar"}).get_json()
    occ = c.post("/api/dg/occurrences", json={"defect_id": d["id"], "cause_id": None, "upload_id": "up-s17", "finding_id": fid, "device": "drive", "admin": "Sagar", "n": 5, "m": 3})
    assert occ.status_code == 200
    t = occ.get_json()["trace"]
    assert t["archived"] and t["words"].startswith("The rows around this error are kept in the knowledge base (the error's command with 5 commands above and 3 below; ")
    assert t["record"]["files"] == NAMES and t["record"]["trace_name"] == "S17 sample" and t["record"]["archived_by"] == "Sagar"
    cz = c.post("/api/dg/causes", json={"defect_id": d["id"], "side": "host", "header": "host timer shorter than the drive's read time", "admin": "Sagar"}).get_json()["id"]
    sol = c.post("/api/dg/solutions", json={"cause_id": cz, "error_seq": [{"command": "Read"}], "optimized": ["raise the timeout"], "admin": "Sagar", "upload_id": "up-s17", "finding_id": fid}).get_json()
    assert sol["trace"]["archived"] and "nothing was copied again" in sol["trace"]["did"]
    ver = c.post("/api/dg/solutions/%d/verdict" % sol["id"], json={"signal": "correct", "admin": "Sagar", "occurrence_id": occ.get_json()["id"]}).get_json()
    assert ver["trace"]["archived"] and ver["did"][-1] == "nothing else changed"
    # an occurrence of an upload that is not here is still recorded; the answer says in words that its rows were not kept
    gone = c.post("/api/dg/occurrences", json={"defect_id": d["id"], "upload_id": "up-not-here", "finding_id": 3, "admin": "Sagar"}).get_json()
    assert gone["id"] and not gone["trace"]["archived"] and "were not kept" in gone["trace"]["words"]
    before = c.get("/api/dg/trace?upload=up-s17&finding=%d" % fid).get_json()
    shutil.rmtree(os.path.join(root, "uploads", "up-s17"))
    after = c.get("/api/dg/trace?upload=up-s17&finding=%d" % fid)
    assert after.status_code == 200 and after.get_json()["levels"] == before["levels"]
    assert _as_read(after.get_json()) == {lv: v for lv, v in _expected(s17, range(cmd - 5, cmd + 4)).items() if v}
    by_occ = c.get("/api/dg/occurrences/%d/trace?level=nvme_command" % occ.get_json()["id"]).get_json()
    assert list(by_occ["levels"]) == ["nvme_command"] and by_occ["levels"]["nvme_command"]["count"] == 9
    tr = c.get("/api/dg/defects/%d/traces" % d["id"]).get_json()
    assert (tr["archived"], tr["not_archived"]) == (1, 1)
    assert c.get("/api/dg/trace?upload=up-s17&finding=%d&rows=0" % fid).get_json()["levels"]["packets"].get("rows") is None
    assert c.get("/api/dg/trace?upload=up-s17&finding=999999").status_code == 404
    late = c.post("/api/dg/trace", json={"upload_id": "up-s17", "finding_id": fid, "admin": "Sagar"}).get_json()
    assert late["archived"] and "the recording is not on this computer any more" in late["did"]
    # workloads and the look-up, through the routes
    w = c.post("/api/dg/workloads", json={"tool": "fio", "definition": "fio --name=x --rw=randread\n", "result": {"iops": 5}, "defect_id": d["id"], "admin": "Sagar"}).get_json()
    assert w["workload"]["validated"] is False and w["workload"]["definition"] == "fio --name=x --rw=randread\n"
    assert c.post("/api/dg/workloads/%d/validate" % w["id"], json={"admin": "Sagar"}).status_code == 400
    assert c.post("/api/dg/workloads/%d/validate" % w["id"], json={"admin": "Sagar", "confirm": True}).get_json()["validated_by"] == "Sagar"
    assert [x["id"] for x in c.get("/api/dg/workloads?defect_id=%d" % d["id"]).get_json()["workloads"]] == [w["id"]]
    assert c.get("/api/dg/workloads/%d" % w["id"]).get_json()["result"] == {"iops": 5}
    a = c.get("/api/dg/across?defect_id=%d" % d["id"]).get_json()
    assert a["link"] == "no link between the two stores for this defect" and a["defect"]["archived_windows"] == 1 and a["defect"]["validated_workloads"] == 1


def test_hostile_input_on_every_new_route_is_refused_in_a_plain_sentence_never_a_server_error(app_s17, s17):
    c, root = app_s17
    fid, _cmd = _an_error(s17)
    asked = []
    did = c.post("/api/dg/defects", json={"name": "A defect for the refusals", "rule": "cmd.timeout", "level": "nvme_command", "what": "", "admin": "Sagar"}).get_json()["id"]

    def refused(r, what):
        asked.append(what)
        body = r.get_json(silent=True)
        assert r.status_code == 400, "%s answered %d: %r" % (what, r.status_code, r.get_data(as_text=True)[:300])
        assert isinstance(body, dict) and isinstance(body.get("error"), str) and len(body["error"]) > 10, (what, body)
        assert "Traceback" not in body["error"] and "Error:" not in body["error"] and "\x00" not in body["error"], (what, body)

    paths = ["../../etc/passwd", "/etc/passwd", "..\\..\\windows", "up\x00s17", "", "a/b", "." * 3, "x" * 500]
    for bad in paths + [7, -1, ["up-s17"], {"a": 1}, None, True, 1.5]:
        refused(c.post("/api/dg/trace", json={"upload_id": bad, "finding_id": fid, "admin": "Sagar"}), "keep the rows, upload %r" % (bad,))
    for bad in ["x", -1, None, [1], {"a": 1}, 1.5, True, 2 ** 70, "1\x00", ""]:
        refused(c.post("/api/dg/trace", json={"upload_id": "up-s17", "finding_id": bad, "admin": "Sagar"}), "keep the rows, error number %r" % (bad,))
    for field in ("n", "m"):
        for bad in [-1, "many", 1.5, [3], 10 ** 9, True, "\x00"]:
            refused(c.post("/api/dg/trace", json={"upload_id": "up-s17", "finding_id": fid, "admin": "Sagar", field: bad}), "keep the rows, %s %r" % (field, bad))
            refused(c.post("/api/dg/occurrences", json={"defect_id": did, "upload_id": "up-s17", "finding_id": fid, "admin": "Sagar", field: bad}), "occurrence, %s %r" % (field, bad))
    for bad in ["", None, 7, ["a"], "a\x00b"]:
        refused(c.post("/api/dg/trace", json={"upload_id": "up-s17", "finding_id": fid, "admin": bad}), "keep the rows, admin %r" % (bad,))
    refused(c.post("/api/dg/trace", json={"upload_id": "up-nowhere", "finding_id": 1, "admin": "Sagar"}), "keep the rows of an upload that is not here")
    refused(c.post("/api/dg/trace", json={"upload_id": "up-s17", "finding_id": 10 ** 9, "admin": "Sagar"}), "keep the rows of an error that is not there")
    for raw in (b"[1, 2]", b"7", b"\"text\"", b"not json", b"", b"null", b"\x00\x01"):
        for url in ("/api/dg/trace", "/api/dg/workloads", "/api/dg/workloads/1/validate"):
            refused(c.post(url, data=raw, content_type="application/json"), "%s with the body %r" % (url, raw))
    for q in ["upload=../../etc/passwd&finding=1", "upload=/etc/passwd&finding=1", "upload=up%00s17&finding=1", "finding=1", "upload=up-s17", "upload=up-s17&finding=-1",
              "upload=up-s17&finding=abc", "upload=up-s17&finding=1.5", "upload=up-s17&finding=%00", "upload=up-s17&finding=99999999999999999999999999",
              "upload=up-s17&finding=1&level=../x", "upload=up-s17&finding=1&level=%00", "upload=up-s17&finding=1&level=cmd"]:
        refused(c.get("/api/dg/trace?" + q), "read the rows with %s" % q)
    for bad in ["-1", "abc", "1.5", "0", "99999999999999999999999999"]:
        refused(c.get("/api/dg/occurrences/%s/trace" % bad), "the rows of occurrence %s" % bad)
        refused(c.get("/api/dg/defects/%s/traces" % bad), "the windows of defect %s" % bad)
        refused(c.get("/api/dg/workloads/%s" % bad), "workload record %s" % bad)
        refused(c.post("/api/dg/workloads/%s/validate" % bad, json={"admin": "Sagar", "confirm": True}), "validate workload record %s" % bad)
        refused(c.get("/api/dg/workloads?defect_id=%s" % bad), "the workloads of defect %s" % bad)
        refused(c.get("/api/dg/workloads?occurrence_id=%s" % bad), "the workloads of occurrence %s" % bad)
        refused(c.get("/api/dg/across?defect_id=%s" % bad), "the look-up of defect %s" % bad)
    refused(c.get("/api/dg/occurrences/1/trace?level=%00"), "the rows of an occurrence, a level that is a NUL character")
    good = {"tool": "fio", "definition": "fio job", "result": "ok", "admin": "Sagar"}
    for field, values in (("tool", [None, 7, "", "a\x00b", "a\nb", "t" * 500, ["fio"], {"a": 1}]), ("definition", [None, 7, "", ["a"], {"a": 1}, "a\x00b", True, "x" * (AR.DEFINITION_LIMIT_BYTES + 1)]),
                          ("result", [None, 7, "", [], {}, "a\x00b", True, 1.5]), ("admin", [None, 7, "", "a\x00b", ["a"]]),
                          ("defect_id", [-1, "x", 1.5, [1], {"a": 1}, True, 2 ** 70, 0, 4242, "../1"]), ("occurrence_id", [-1, "x", 1.5, [1], True, 2 ** 70, 0, 4242, "\x00"]),
                          ("note", [7, ["a"], "a\x00b", "n" * 5000]), ("validated", [True, False, "Sagar"]), ("validated_by", ["Sagar"])):
        for bad in values:
            refused(c.post("/api/dg/workloads", json=dict(good, **{field: bad})), "store a workload, %s %r" % (field, str(bad)[:30]))
    wid = c.post("/api/dg/workloads", json=good).get_json()["id"]
    for body in ({"admin": "Sagar"}, {"admin": "Sagar", "confirm": "true"}, {"admin": "Sagar", "confirm": 1}, {"admin": "", "confirm": True}, {"confirm": True},
                 {"admin": 7, "confirm": True}, {"admin": "a\x00b", "confirm": True}, {"admin": "Sagar", "confirm": [True]}):
        refused(c.post("/api/dg/workloads/%d/validate" % wid, json=body), "validate with %r" % (body,))
    assert c.get("/api/dg/workloads/%d" % wid).get_json()["validated"] is False
    for q in ["", "defect=", "defect=%00", "defect=a%0Ab", "defect=" + "x" * 900]:
        refused(c.get("/api/dg/across?" + q), "the look-up with %r" % q[:30])
    assert c.get("/api/dg/across?defect=../../etc/passwd").status_code == 404          # a name that names no defect: nothing is opened by it
    assert len(asked) > 150
