#!/usr/bin/env python3
"""The header of each level's file goes with the tree from the load on, and Family 4's facts say what an empty column is (2026-11-15).

Offline: no server, no model, no network, its own temporary folders. What is proven:
  1. nvme_hier/loader.py load_file stores the header (meta, tree_api.HEADERS_KEY) in the form tree_api.store_headers writes: the named
     columns in the file's order, as the loader aligned them, for the samples' layout and for the real export's layout (bare sub-names, the
     first row's text in label-less cells), read on one core, in parts on several processes, and when the parts fall back to one core;
  2. it is written once per file by the process that loads (no worker that reads a part writes it), and it is what the file's header says;
  3. Tree.columns reads it without the file; a tree loaded before this (no stored header) still answers from the file, and store_headers
     then writes exactly what the loader writes; a file that cannot be read as its level leaves no header of an earlier load behind;
  4. agentic/family4.py data_facts says, for a column of the tree without a value in the first 5,000 rows, which of the three it is:
     "filled" (a later row has a value), "in the file, empty in every row" or "not in the file".

Run: python3 -m pytest -q -p no:cacheprovider tests/test_join_header.py
"""
import concurrent.futures
import contextlib
import csv
import json
import os
import re
import sqlite3
import sys
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)
from nvme_hier import columns as C, loader as L, tree_api as T   # noqa: E402

S17 = os.path.join(ROOT, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NAMES = {"nvme_command": "nvme_command.csv", "nvme_transaction": "NVME_Transactions.csv", "split": "split.csv", "link": "link.csv"}
ONE_CORE = {"WORKERS": 1}
# three worker processes and parts of 64 kB on every file, however small (the settings of tests/test_hierarchy_parallel.py)
IN_PARTS = {"WORKERS": 3, "PARALLEL_MIN_BYTES": 0, "CHUNK_BYTES": 64 * 1024, "MIN_CHUNK_BYTES": 16 * 1024}


@contextlib.contextmanager
def loader(**settings):
    """The loader's module settings for the length of one block, put back afterwards whatever happens."""
    before = {k: getattr(L, k) for k in settings}
    for k, v in settings.items():
        setattr(L, k, v)
    try:
        yield
    finally:
        for k, v in before.items():
            setattr(L, k, v)


def sample_files():
    """The NVMe command, NVMe transaction, split and link files of the sample S17 (the packets file is left out: 52 MB, and it adds nothing here)."""
    files = {k: os.path.join(S17, n) for k, n in NAMES.items()}
    if not all(os.path.isfile(p) for p in files.values()):
        pytest.skip("the sample S17 is not on this computer")
    return files


def as_real_export(files, out_dir):
    """The same rows under the header of the real export (tests/test_hierarchy_parallel.py as_real_export, 2026-11-03): sub-columns bare after
    their group cell, no "#2" on the second column of a name, the label-less cells holding text of the first row, no blank separator columns."""
    os.makedirs(out_dir, exist_ok=True)
    out = {}
    for key, path in files.items():
        with open(path, newline="") as fh:
            rows = list(csv.reader(fh))
        al = L.align_header(key, rows[0], L.prescan_values(path, L.ambiguous_columns(key, rows[0])))
        known, orig, label_less = C.canonical_names(key), C.original_names(key), set(C.label_less_positions(key))
        cells, picks = [], []
        for i, name in enumerate(known):
            if name not in al.positions:
                continue
            if i in label_less:
                cell = orig[i]
            elif "." in name and name.partition(".")[0] in set(known):
                cell = name.partition(".")[2]
            else:
                cell = name.replace(" ", "_") if name == "AckNak Seq Num" else name
            cells.append(re.sub(r"#\d+$", "", cell))
            picks.append(al.positions[name])
        out[key] = os.path.join(out_dir, os.path.basename(path))
        with open(out[key], "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(cells)
            for r in rows[1:]:
                r = r + [""] * (len(rows[0]) - len(r))
                w.writerow([r[p] for p in picks])
    return out


def header_cells(path):
    with open(path, newline="", encoding="utf-8-sig") as fh:
        return [h.strip() for h in next(csv.reader(fh))]


def stored_text(db):
    """The stored header exactly as it lies in the tree's database (the text of the meta value), or None."""
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        r = con.execute("SELECT v FROM meta WHERE k = ?", (T.HEADERS_KEY,)).fetchone()
        return r[0] if r else None
    finally:
        con.close()


def stored(db):
    text = stored_text(db)
    return json.loads(text) if text else {}


def aligned(key, path):
    """The header as the loader aligns it, computed here from the file: {name: position of its cell} of the named columns."""
    hdr = header_cells(path)
    al = L.align_header(key, hdr, L.prescan_values(path, L.ambiguous_columns(key, hdr)))
    return dict(list(al.positions.items()) + [(h, i) for i, h in al.unknown]), al


def load(files, db, settings, progress=None):
    with loader(**settings):
        return L.load_upload(db, files, progress=progress)


@pytest.fixture(scope="module")
def loaded(tmp_path_factory):
    """The sample read once on one core: (the files, the database)."""
    files = sample_files()
    db = str(tmp_path_factory.mktemp("join_header") / "hier.sqlite")
    rep = load(files, db, ONE_CORE)
    assert all(not r.get("error") and r["parallel"] is None for r in rep.values())
    return files, db


def copy_of(db, tmp_path, name="copy.sqlite"):
    p = str(tmp_path / name)
    a, b = sqlite3.connect(db), sqlite3.connect(p)
    a.backup(b)
    b.close()
    a.close()
    return p


# ---------------------------------------------------------------------------------------------- 1. stored at the load, the samples' layout
def test_the_load_stores_each_levels_header_in_the_files_order(loaded):
    files, db = loaded
    have = stored(db)
    assert sorted(have) == sorted(files)                                    # every level that was loaded, and no other
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        for key, path in files.items():
            names, cells = have[key], header_cells(path)
            where, al = aligned(key, path)
            # the form tree_api.store_headers writes: what tree_api reads from the file itself
            assert names == T.header_of_file(con, key) == L.header_names(al), key
            assert len(set(names)) == len(names) and all(isinstance(n, str) and n for n in names) and not any(T.SPACER.match(n) for n in names), key
            # the file's order: the position of each name's cell goes up
            assert [where[n] for n in names] == sorted(where[n] for n in names), key
            # equal to the file's header: every cell that has a text is a named column under that very text, in the same order ...
            texts = [c for c in cells if c]
            assert [n for n in names if cells[where[n]]] == texts and all(cells[where[n]] == n for n in names if cells[where[n]]), key
            # ... and a name on a blank cell is one of the level's label-less columns (the samples leave those cells blank); the other blank cells are spacers
            known = C.canonical_names(key)
            label_less = {known[i] for i in C.label_less_positions(key)}
            blank_named = [n for n in names if not cells[where[n]]]
            assert set(blank_named) <= label_less and len(names) + len(al.separators) == len(cells), (key, blank_named[:5])
            # the header, not the first row: columns no row of the first one fills are there too
            first = json.loads(con.execute("SELECT raw FROM %s ORDER BY rowid_file LIMIT 1" % T.TABLE[key]).fetchone()[0])
            assert set(first) - {n for n in first if T.SPACER.match(n)} <= set(names) and len(names) > len(first), key
    finally:
        con.close()
    assert "NLB" in have["nvme_command"]


def test_the_tree_reads_the_stored_header_without_the_file(loaded, tmp_path):
    files, db = loaded
    p = copy_of(db, tmp_path)
    con = sqlite3.connect(p)
    rep = json.loads(con.execute("SELECT v FROM meta WHERE k='load_reports'").fetchone()[0])
    for lv in rep:
        rep[lv]["path"] = os.path.join(str(tmp_path), "not_there", os.path.basename(rep[lv]["path"]))      # the file is "gone"
    con.execute("UPDATE meta SET v=? WHERE k='load_reports'", (json.dumps(rep),))
    con.commit()
    con.close()
    t = T.Tree(p)
    try:
        for key in files:
            assert t.columns(key)[:len(stored(db)[key])] == stored(db)[key] and t.columns_from(key) == "the header stored with the tree", key
        assert "NLB" in t.columns("nvme_command") and "NLB" not in t._first_keys("nvme_command")
        with pytest.raises(T.NotInTree):
            t.columns("packets")                                            # a level that was not loaded has no header either
    finally:
        t.close()
    assert "packets" not in stored(db)


def test_store_headers_finds_nothing_left_to_write_after_a_load(loaded, tmp_path):
    files, db = loaded
    p = copy_of(db, tmp_path)
    before = stored_text(p)
    counts = T.store_headers(p)
    assert stored_text(p) == before and counts == {k: len(v) for k, v in json.loads(before).items()}


def test_a_tree_loaded_before_this_keeps_working_and_gets_the_same_header(loaded, tmp_path):
    """A tree loaded before 2026-11-15 has no stored header: Tree.columns reads the file, and tree_api.store_headers (page 3's plan card) then
    writes, letter for letter, what the loader writes today: one form, whoever writes it."""
    files, db = loaded
    p = copy_of(db, tmp_path)
    con = sqlite3.connect(p)
    con.execute("DELETE FROM meta WHERE k = ?", (T.HEADERS_KEY,))
    con.commit()
    con.close()
    assert stored_text(p) is None
    t = T.Tree(p)
    try:
        for key in files:
            assert t.columns(key)[:len(stored(db)[key])] == stored(db)[key] and "read from the file" in t.columns_from(key), key
    finally:
        t.close()
    assert T.store_headers(p) == {k: len(v) for k, v in stored(db).items()}
    assert json.loads(stored_text(p)) == stored(db)
    assert {k: json.dumps(v) for k, v in json.loads(stored_text(p)).items()} == {k: json.dumps(v) for k, v in stored(db).items()}


# ---------------------------------------------------------------------------------------------- 2. in parts on several processes, and the fallback
def test_parts_on_several_processes_store_the_same_header(loaded, tmp_path):
    files, db = loaded
    db3 = str(tmp_path / "parts.sqlite")
    settings = {k: getattr(L, k) for k in IN_PARTS}
    rep = load(files, db3, IN_PARTS)
    assert {k: getattr(L, k) for k in IN_PARTS} == settings                 # the loader's settings are put back
    for key in files:
        assert rep[key]["parallel"] and rep[key]["parallel"]["workers"] > 1 and rep[key]["parallel"]["chunks"] > 1, (key, rep[key]["parallel"])
        assert "read_on_one_core_because" not in rep[key], key
    assert stored_text(db3) == stored_text(db)                              # letter for letter what one core stored


def test_the_header_is_written_once_per_file_by_the_loading_process_and_by_no_worker(loaded, tmp_path, monkeypatch):
    """The load's own call is put aside (it is written down and writes nothing): were a worker process to write the header as well, it would be
    in the database afterwards. It is not there; the call came once per file, from this process, with the file's header, before any row."""
    files, db = loaded
    calls = []

    def write_nothing(con, level, names):
        rows = con.execute("SELECT COUNT(*) FROM %s" % T.TABLE[level]).fetchone()[0]
        calls.append((os.getpid(), level, list(names) if names else names, rows))
    monkeypatch.setattr(L, "store_header", write_nothing)
    db3 = str(tmp_path / "parts_no_write.sqlite")
    rep = load(files, db3, IN_PARTS)
    assert all(rep[k]["parallel"] and rep[k]["parallel"]["chunks"] > 1 and rep[k]["rows"] > 0 for k in files)
    assert stored_text(db3) is None                                         # no worker wrote it
    assert sorted(c[1] for c in calls) == sorted(files) and {c[0] for c in calls} == {os.getpid()}
    assert all(names == stored(db)[level] and rows == 0 for _pid, level, names, rows in calls)
    # such a tree (no stored header) is the tree of before: its columns come from the file
    t = T.Tree(db3)
    try:
        assert t.columns("nvme_command")[:len(stored(db)["nvme_command"])] == stored(db)["nvme_command"] and "read from the file" in t.columns_from("nvme_command")
    finally:
        t.close()


def test_parts_that_fall_back_to_one_core_store_the_header_too(loaded, tmp_path, monkeypatch):
    files, db = loaded
    # (a) every worker fails (the folder for its rows is not there): the table is made again and the file is read on one core
    lost = str(tmp_path / "no such folder")
    monkeypatch.setattr(L, "chunk_folder", lambda beside: (lost, False))
    one = {"link": files["link"]}
    db_a = str(tmp_path / "fallback_a.sqlite")
    rep = load(one, db_a, IN_PARTS)
    assert rep["link"]["parallel"] is None and "a worker process could not read its part" in rep["link"]["read_on_one_core_because"]
    assert stored(db_a) == {"link": stored(db)["link"]}
    monkeypatch.undo()
    # (b) no worker process can be started at all
    def no_processes(*a, **kw):
        raise OSError("no more processes")
    monkeypatch.setattr(concurrent.futures, "ProcessPoolExecutor", no_processes)
    db_b = str(tmp_path / "fallback_b.sqlite")
    rep = load(files, db_b, IN_PARTS)
    monkeypatch.undo()
    assert all(rep[k]["parallel"] is None and "could not be started" in rep[k]["read_on_one_core_because"] for k in files)
    assert stored_text(db_b) == stored_text(db)
    con_a, con_1 = sqlite3.connect(db_b), sqlite3.connect(db)
    try:
        for key in files:
            q = "SELECT COUNT(*), SUM(LENGTH(raw)) FROM %s" % T.TABLE[key]
            assert con_a.execute(q).fetchone() == con_1.execute(q).fetchone(), key
    finally:
        con_a.close()
        con_1.close()


def test_a_file_under_the_size_for_parts_and_a_file_read_with_a_row_limit_store_it(loaded, tmp_path):
    files, db = loaded
    db_s = str(tmp_path / "small.sqlite")
    with loader(WORKERS=3):                                                 # the samples' files here are under 16 MB: one core, although workers are allowed
        rep = L.load_upload(db_s, {"split": files["split"]}, limit=10)
    assert rep["split"]["parallel"] is None and rep["split"]["rows"] == 10 and stored(db_s) == {"split": stored(db)["split"]}


# ---------------------------------------------------------------------------------------------- 3. the real export's layout
def test_the_real_exports_layout_stores_the_names_the_rows_carry(loaded, tmp_path):
    files, db = loaded
    real = as_real_export(files, str(tmp_path / "real"))
    cells = {k: header_cells(p) for k, p in real.items()}
    assert "" not in cells["link"] and "16.0" in cells["link"] and "SCT" in cells["nvme_command"] and "ST.SCT" not in cells["nvme_command"]
    db1, db3 = str(tmp_path / "real_one.sqlite"), str(tmp_path / "real_parts.sqlite")
    rep1 = load(real, db1, ONE_CORE)
    rep3 = load(real, db3, IN_PARTS)
    assert all(not rep1[k]["missing_columns"] and not rep1[k]["unknown_columns"] and rep3[k]["parallel"] for k in real)
    assert stored_text(db1) == stored_text(db3)                             # on one core and in parts
    have = stored(db1)
    con = sqlite3.connect("file:%s?mode=ro" % db1, uri=True)
    try:
        for key, path in real.items():
            names, hdr = have[key], cells[key]
            assert names == T.header_of_file(con, key) and len(names) == len(hdr) and len(set(names)) == len(names), key      # no spacer cells in this layout: one name per cell
            known = C.canonical_names(key)
            label_less = {known[i] for i in C.label_less_positions(key)}
            for cell, name in zip(hdr, names):
                plain = re.sub(r"#\d+$", "", name)
                assert (name == cell or plain == cell or plain.endswith("." + cell) or name.replace(" ", "_") == cell
                        or (name in label_less and L._looks_label_less(cell))), (key, cell, name)
            # the names the rows carry, not the cells' texts: a bare sub-name is stored under its group, a label-less cell under its name
            first = json.loads(con.execute("SELECT raw FROM %s ORDER BY rowid_file LIMIT 1" % T.TABLE[key]).fetchone()[0])
            assert set(first) <= set(names), (key, sorted(set(first) - set(names))[:5])
    finally:
        con.close()
    assert "ST.SCT" in have["nvme_command"] and "SCT" not in have["nvme_command"] and "NLB" in have["nvme_command"]
    assert "Link Speed" in have["link"] and "16.0" not in have["link"]
    # the same columns as the samples' layout of the same files (that layout's header may list them in another order)
    for key in real:
        assert sorted(have[key]) == sorted(stored(db)[key]), key
    t = T.Tree(db3)
    try:
        assert t.columns("nvme_command") == have["nvme_command"] and t.columns_from("link") == "the header stored with the tree"
        assert t.column_state("nvme_command", "ST.SCT") == T.FILLED and t.column_state("nvme_command", "SCT") == T.MISSING
    finally:
        t.close()


def test_the_customers_own_stored_headers_give_one_name_per_named_cell_in_the_files_order(monkeypatch):
    """data/lecroy_real_headers.json (the customer's export of 2026-11-03, cell by cell): what the loader would store for each of the five
    files is the stored column of every named cell, in the order of the cells, and nothing for a separator cell."""
    monkeypatch.setattr(C, "_REAL", None)           # the stored table is read from its file here, whatever an earlier test left in its place
    with open(C.REAL_HEADERS_JSON, encoding="utf-8") as fh:
        d = json.load(fh)
    assert set(d["files"]) == set(C.FILE_KEYS.values())
    for fname, entries in d["files"].items():
        key = next(k for k, v in C.FILE_KEYS.items() if v == fname)
        e = entries[-1]
        al = L.align_header(key, e["header"])
        assert al.header_format.startswith("the customer's stored header"), (fname, al.header_format)
        names = L.header_names(al)
        assert names == [e["columns"][i] for i in sorted(e["columns"], key=int)], fname
        assert len(names) + len(al.separators) == len(e["header"]) and len(set(names)) == len(names), fname
        con = sqlite3.connect(":memory:")
        L.store_header(con, key, names)
        assert json.loads(con.execute("SELECT v FROM meta WHERE k = ?", (T.HEADERS_KEY,)).fetchone()[0]) == {key: names}
        con.close()


# ---------------------------------------------------------------------------------------------- 4. what the loader does not keep
def short_command_file(path, rows, header=("NVMe Cmd", "Link Dir", "OPC", "SQID", "CQID", "CID", "SLBA", "NLB", "ST.SCT", "ST.SC", "Time Stamp")):
    """A small NVMe command file. rows: (opc, sqid, nlb) per command; SLBA is in the header and empty in every row."""
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        for i, (opc, sqid, nlb) in enumerate(rows, 1):
            cell = dict(zip(header, [""] * len(header)))
            cell.update({"NVMe Cmd": str(i), "Link Dir": "Downstream", "OPC": opc, "SQID": str(sqid), "CQID": str(sqid), "CID": str(i % 60000), "NLB": nlb,
                         "ST.SCT": "0", "ST.SC": "0", "Time Stamp": "0001.%012ds" % (i * 1000)})
            w.writerow([cell[h] for h in header])
    return path


def test_a_file_that_is_not_its_level_leaves_no_header_of_an_earlier_load(tmp_path):
    good = short_command_file(str(tmp_path / "nvme_command.csv"), [("0x06", 0, ""), ("0x02", 3, "7")])
    db = str(tmp_path / "hier.sqlite")
    with loader(**ONE_CORE):
        L.load_upload(db, {"nvme_command": good})
        assert stored(db) == {"nvme_command": ["NVMe Cmd", "Link Dir", "OPC", "SQID", "CQID", "CID", "SLBA", "NLB", "ST.SCT", "ST.SC", "Time Stamp"]}
        con = L.open_db(db)
        L.store_header(con, "link", ["Link Tra", "PSN"])                    # another level's entry: it must stay as it is
        con.commit()
        # an empty file: the table of the earlier load is not touched, and neither is its header
        empty = str(tmp_path / "empty.csv")
        open(empty, "w").close()
        assert L.load_file(con, "nvme_command", empty)["error"] == "empty file"
        con.commit()
        assert stored(db)["nvme_command"][2] == "OPC" and con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0] == 2
        # some other table: the level's table is made again, empty, and the header kept from the earlier load is taken away
        other = str(tmp_path / "other.csv")
        with open(other, "w", newline="") as fh:
            csv.writer(fh).writerows([["alpha", "beta"], ["1", "2"]])
        rep = L.load_file(con, "nvme_command", other)
        con.commit()
        assert "none of the columns of this level are in the file" in rep["error"] and con.execute("SELECT COUNT(*) FROM cmd").fetchone()[0] == 0
        assert stored(db) == {"link": ["Link Tra", "PSN"]}
        # loaded again from the good file: its header is back, once
        L.load_file(con, "nvme_command", good)
        con.commit()
        con.close()
    assert stored(db)["nvme_command"][7] == "NLB" and stored(db)["link"] == ["Link Tra", "PSN"] and sorted(stored(db)) == ["link", "nvme_command"]


def test_store_header_alone(tmp_path):
    """The one writer: a database without a meta table, a damaged stored value, names that are not text, nothing to remove."""
    con = sqlite3.connect(str(tmp_path / "plain.sqlite"))                   # not opened by open_db: no meta table yet (load_file is called this way by tests)
    L.store_header(con, "split", ["Split Tra", 7])
    assert json.loads(con.execute("SELECT v FROM meta WHERE k = ?", (T.HEADERS_KEY,)).fetchone()[0]) == {"split": ["Split Tra", "7"]}
    L.store_header(con, "link", None)                                       # nothing stored for it: nothing changes
    L.store_header(con, "link", [])
    assert json.loads(con.execute("SELECT v FROM meta WHERE k = ?", (T.HEADERS_KEY,)).fetchone()[0]) == {"split": ["Split Tra", "7"]}
    for damaged in ("{not json", "[1, 2]", "", "null"):
        con.execute("UPDATE meta SET v = ? WHERE k = ?", (damaged, T.HEADERS_KEY))
        L.store_header(con, "packets", ["Packet"])
        assert json.loads(con.execute("SELECT v FROM meta WHERE k = ?", (T.HEADERS_KEY,)).fetchone()[0]) == {"packets": ["Packet"]}
    L.store_header(con, "packets", None)
    assert json.loads(con.execute("SELECT v FROM meta WHERE k = ?", (T.HEADERS_KEY,)).fetchone()[0]) == {}
    con.close()
    # header_names: the file's order over the known and the unknown columns together, spacer cells left out
    al = L.align_header("link", ["Link Tra", "Link Dir", "", "Link Tra Error", "Mystery", "PSN"] + C.canonical_names("link")[5:], {2})
    names = L.header_names(al)
    assert names[:6] == ["Link Tra", "Link Dir", "Link Speed", "Link Tra Error", "Mystery", "PSN"] and al.unknown == [(4, "Mystery")]


# ---------------------------------------------------------------------------------------------- 5. Family 4's facts: the three states
@pytest.fixture()
def facts_of(tmp_path, monkeypatch):
    """data_facts on a small tree of 5,001 commands: the first 5,000 are admin commands without a block count, the last is a Read with one.
    The recording and the dictionaries are handed to it here (no upload folder, no library is read); monkeypatch puts both back."""
    from agentic import family3, family4, procedures as PR
    path = short_command_file(str(tmp_path / "nvme_command.csv"), [("0x06", 0, "")] * 5000 + [("0x02", 3, "7")])
    db = str(tmp_path / "hier.sqlite")
    with loader(**ONE_CORE):
        rep = L.load_upload(db, {"nvme_command": path})
    assert rep["nvme_command"]["rows"] == 5001
    monkeypatch.setattr(family3, "recording", lambda ctx: (db, "up-x", {PR.TREE: db}))
    monkeypatch.setattr(family4, "_dictionaries", lambda folder, paths: {})
    ctx = types.SimpleNamespace(project={"folder": None}, params={})

    def facts(columns):
        return family4.data_facts(ctx, {"source_data": [{"file": PR.TREE, "columns": list(columns)}]})
    return facts, db, PR


def test_the_facts_say_which_of_the_three_states_a_column_without_values_is(facts_of):
    facts, db, PR = facts_of
    f = facts(["nvme_command: OPC", "nvme_command: NLB", "nvme_command: SLBA", "nvme_command: No Such Column", "packets: PSN"])
    by = {c["name"]: c for c in f["sources"][0]["columns"]}
    # a column with values in the first 5,000 rows: nothing to explain, the fact is as before
    opc = by["nvme_command: OPC"]
    assert opc["in_the_data"] and opc["rows_with_value_in_first_5000"] == 5000 and "in_the_file" not in opc and "first_value_is_after_row_5000" not in opc
    # filled, but only after the first 5,000 rows (the block count of the one Read): in the file, and not empty
    nlb = by["nvme_command: NLB"]
    assert nlb["in_the_data"] and nlb["rows_with_value_in_first_5000"] == 0 and nlb["real_values_seen"] == []
    assert nlb["in_the_file"] == "filled" == PR.tree_column_state(db, "nvme_command", "NLB") and nlb["first_value_is_after_row_5000"] is True
    # in the header and empty in every row: in the file, so the rule is not blocked, and the fact says that no row fills it
    slba = by["nvme_command: SLBA"]
    assert slba["in_the_data"] and slba["rows_with_value_in_first_5000"] == 0
    assert slba["in_the_file"] == "in the file, empty in every row" == PR.tree_column_state(db, "nvme_command", "SLBA") and "first_value_is_after_row_5000" not in slba
    # not in the header: not in the file, and that blocks, in the same words as before
    gone = by["nvme_command: No Such Column"]
    assert not gone["in_the_data"] and gone["rows_with_value_in_first_5000"] == 0 and gone["in_the_file"] == "not in the file" and "first_value_is_after_row_5000" not in gone
    # a level this tree does not have: not in the file either
    pkt = by["packets: PSN"]
    assert not pkt["in_the_data"] and pkt["in_the_file"] == "not in the file"
    assert f["blocking"] == ["nvme_command.csv has no column No Such Column (the tree's columns were read by code)",
                             "the tree of this analysis has no packets.csv (its file was not loaded)"]
    assert f["on_tree"] and f["sources"][0]["in_this_analysis"] is True
    # the three states are the tree's own words (nvme_hier/tree_api.py)
    assert {nlb["in_the_file"], slba["in_the_file"], gone["in_the_file"]} == {T.FILLED, T.EMPTY, T.MISSING}


def test_the_facts_of_a_tree_without_a_stored_header_say_the_same(facts_of):
    """A tree loaded before 2026-11-15 (no stored header): the file is read for the header, and the three states are the same."""
    facts, db, _PR = facts_of
    con = sqlite3.connect(db)
    con.execute("DELETE FROM meta WHERE k = ?", (T.HEADERS_KEY,))
    con.commit()
    con.close()
    by = {c["name"]: c for c in facts(["nvme_command: NLB", "nvme_command: SLBA", "nvme_command: No Such Column"])["sources"][0]["columns"]}
    assert [by["nvme_command: " + c]["in_the_file"] for c in ("NLB", "SLBA", "No Such Column")] == ["filled", "in the file, empty in every row", "not in the file"]


def test_the_near_limit_item_names_nlb_among_its_tree_columns_and_the_facts_do_not_block_it(loaded, monkeypatch):
    """nvme_hier/near_limit.py: NLB is back under the procedure's tree columns (the first command of the sample is an admin command, so the
    first row leaves NLB empty: that made it look missing before Tree.columns gave the header), and the sentence that said otherwise is gone."""
    from agentic import family3, family4, procedures as PR
    from nvme_hier import near_limit as NL
    files, db = loaded
    cols = NL.PROCEDURE["source_data"][0]["columns"]
    assert NL.PROCEDURE["source_data"][0]["file"] == PR.TREE and "nvme_command: NLB" in cols and len(set(cols)) == len(cols)
    assert "not one of the tree's named columns" not in json.dumps(NL.PROCEDURE) and "not listed under the source data" not in json.dumps(NL.PROCEDURE)
    # one list of the command file's columns, said three times: the item (for Family 1), the procedure, the evidence card
    of_command = [PR.tree_column(c)[1] for c in cols if PR.tree_column(c)[0] == "nvme_command"]
    assert of_command == NL.ITEM["family1"]["columns"] == [c["column"] for c in NL.evidence()["columns"] if c["file"] == "nvme_command"]
    assert PR.validate(json.loads(json.dumps(NL.PROCEDURE)))["source_data"][0]["columns"] == cols
    t = T.Tree(db)
    try:
        assert "NLB" not in t._first_keys("nvme_command")
        for c in cols:
            lv, col = PR.tree_column(c)
            assert lv in t.present and col in t.columns(lv), c
    finally:
        t.close()
    monkeypatch.setattr(family3, "recording", lambda ctx: (db, "up-x", {PR.TREE: db}))
    monkeypatch.setattr(family4, "_dictionaries", lambda folder, paths: {})
    f = family4.data_facts(types.SimpleNamespace(project={"folder": None}, params={}), NL.PROCEDURE)
    assert f["blocking"] == [] and all(c["in_the_data"] for c in f["sources"][0]["columns"])
    nlb = next(c for c in f["sources"][0]["columns"] if c["name"] == "nvme_command: NLB")
    assert nlb["rows_with_value_in_first_5000"] > 0 and "in_the_file" not in nlb


def test_a_library_seeded_with_the_older_wording_takes_the_procedure_with_nlb(tmp_path, monkeypatch):
    """The rules library of an installation holds the item's procedure as it was seeded (without NLB, with the sentence that is gone). Nobody
    edited or coded it, so the next seeding gives it the present wording; one the admin edited is left as the admin wrote it."""
    from agentic import family1, family3, procedures as PR
    from nvme_hier import near_limit as NL
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path))
    family3._SECTIONS_SEEN[0] = None                                            # the sections are read again from this folder, and again from the next test's
    try:
        family3.tree()                                                          # a rules folder of its own: seeded now
        # (2026-11-15) a new installation starts the item in Deleted items (Data analytics reads one CSV file): restored, the seed gives it its procedure
        family3.restore_item("analytics", "nvme_command", "near_limit", "Sagar")
        family3.tree()
        r = family3.load_rule("analytics", "nvme_command", "near_limit")
        assert r["procedure"]["edited_by"] == PR.SEED_MARK and "nvme_command: NLB" in r["procedure"]["source_data"][0]["columns"]
        older = json.loads(json.dumps(r["procedure"]))
        older["source_data"][0]["columns"].remove("nvme_command: NLB")
        older["steps"][5] = older["steps"][5].replace("when the recording was loaded)", "when the recording was loaded; it is not one of the tree's named columns, so it is not listed under the source data)")
        assert older["steps"][5] != r["procedure"]["steps"][5]
        r["procedure"] = older
        family3.save_rule(r)
        family3.tree()
        now = family3.load_rule("analytics", "nvme_command", "near_limit")["procedure"]
        assert now["source_data"] == NL.PROCEDURE["source_data"] and now["steps"] == NL.PROCEDURE["steps"] and now["edited_by"] == PR.SEED_MARK
        # the admin's own wording is never replaced
        r = family3.load_rule("analytics", "nvme_command", "near_limit")
        r["procedure"] = dict(older, edited_by="Sagar", version=2)
        family3.save_rule(r)
        family3.tree()
        assert family3.load_rule("analytics", "nvme_command", "near_limit")["procedure"]["steps"][5] == older["steps"][5]
    finally:
        family3._SECTIONS_SEEN[0] = None


def test_the_facts_without_a_tree_are_as_before(tmp_path, monkeypatch):
    from agentic import family3, family4, procedures as PR
    monkeypatch.setattr(family3, "recording", lambda ctx: (None, None, {}))
    monkeypatch.setattr(family4, "_dictionaries", lambda folder, paths: {})
    ctx = types.SimpleNamespace(project={"folder": None}, params={})
    f = family4.data_facts(ctx, {"source_data": [{"file": PR.TREE, "columns": ["nvme_command: NLB"]}]})
    assert f["sources"] == [{"file": PR.TREE, "in_this_analysis": False, "columns": [{"name": "nvme_command: NLB", "in_the_data": False}]}]
    assert f["blocking"] == [family4.TREE_MISSING]


if __name__ == "__main__":
    sys.exit(pytest.main(["-q", "-p", "no:cacheprovider", __file__]))
