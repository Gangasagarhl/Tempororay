"""Commands that completed but came close to the limit (nvme_hier/near_limit.py; project statement S4, work item B8).

    python3 -m pytest -q -p no:cacheprovider tests/test_near_limit.py

The four samples under samples/clean_five_files are loaded the way tests/test_nvme_command_rules.py loads a recording (the NVMe command
file and the NVMe transactions file, the tree, the rules), each into a temporary folder. What the item lists is compared with a slow,
simple recomputation written here in plain Python. Nothing of the application's own folders is written.
"""
import csv
import hashlib
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import tracemalloc

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
if APP_DIR not in sys.path:
    sys.path.insert(0, APP_DIR)
from nvme_hier import builder as B, loader as L, rules as RL   # noqa: E402
from nvme_hier import near_limit as NL   # noqa: E402

SAMPLES = os.path.join(APP_DIR, "samples", "clean_five_files")
NAMES = ("demo_225_commands", "S08_interrupt_before_completion", "S27_lcrc_nak_replay", "S17_io_timeout_abort_reset")
IO, ADM = 30 * 10 ** 12, 60 * 10 ** 12          # the Linux NVMe driver's defaults, in picoseconds (rules.DEFAULT_LIMITS)
NOT_TIMED = {0x80, 0x84, 0x14, 0x10, 0x11, 0x0C}
HOST_ABORT = {(0, 7), (0, 8), (3, 0x71)}
MEMORY_GROWTH_MB = 64                           # the stated bound of the streaming test (Python memory at its peak while the item runs)


@pytest.fixture(scope="module")
def built():
    """{sample: database} of the samples that are on this machine, each loaded once into a temporary folder."""
    base = os.environ.get("F2T_TEST_TMP") or None
    if base:
        os.makedirs(base, exist_ok=True)
    d = tempfile.mkdtemp(prefix="near_limit_", dir=base)
    out = {}
    for name in NAMES:
        f = os.path.join(SAMPLES, name)
        files = {"nvme_command": os.path.join(f, "nvme_command.csv"), "nvme_transaction": os.path.join(f, "NVME_Transactions.csv")}
        if not all(os.path.exists(p) for p in files.values()):
            continue
        db = os.path.join(d, name, "hier.sqlite")
        os.makedirs(os.path.dirname(db))
        L.load_upload(db, files)
        B.build(db)
        RL.apply(db)
        out[name] = db
    yield out
    shutil.rmtree(d, ignore_errors=True)


def sample(built, name, tmp_path):
    if name not in built:
        pytest.skip("the sample folder samples/clean_five_files/%s is not on this machine" % name)
    p = str(tmp_path / "hier.sqlite")
    a, b = sqlite3.connect(built[name]), sqlite3.connect(p)
    a.backup(b)
    b.close()
    a.close()
    return p


def slow(db, share, io=IO, adm=ADM):
    """{row: share used in per cent} of the commands the item must list, worked out row by row without the item's code."""
    con = sqlite3.connect(db)
    first = {}
    for parent, t, typ in con.execute("SELECT parent, t_ps, type FROM ntx WHERE parent_level = 'nvme_command' AND parent IS NOT NULL AND t_ps IS NOT NULL"):
        low = (typ or "").lower()
        if "completion" in low and "doorbell" not in low and "submission" not in low:
            first[parent] = t if parent not in first else min(first[parent], t)
    out = {}
    for rid, opc, sqid, sct, sc, t in con.execute("SELECT rowid_file, opc, sqid, sct, sc, t_ps FROM cmd"):
        if rid not in first or t is None or (sqid == 0 and opc in NOT_TIMED) or (sct is None and sc is None) or (sct or 0, sc) in HOST_ABORT:
            continue
        dur, lim = first[rid] - t, (adm if sqid == 0 else io)
        if dur < lim and dur >= lim * share / 100.0:
            out[rid] = dur * 100.0 / lim
    con.close()
    return out


def listed(path):
    with open(path, newline="", encoding="utf-8") as fh:
        rd = csv.reader(fh)
        head = next(rd)
        return head, [dict(zip(head, r)) for r in rd]


def errors_of(db):
    con = sqlite3.connect(db)
    f = con.execute("SELECT * FROM finding ORDER BY id").fetchall()
    m = con.execute("SELECT k, v FROM meta ORDER BY k").fetchall()
    con.close()
    with open(db, "rb") as fh:
        return f, m, hashlib.sha256(fh.read()).hexdigest()


def stretch(db, row, time_ps):
    """The command's completion entries moved so that its time is exactly time_ps."""
    con = sqlite3.connect(db)
    t = con.execute("SELECT t_ps FROM cmd WHERE rowid_file = ?", (row,)).fetchone()[0]
    con.execute("UPDATE ntx SET t_ps = ? WHERE parent_level = 'nvme_command' AND parent = ? AND lower(type) LIKE '%completion queue entry%'", (t + time_ps, row))
    con.commit()
    con.close()


@pytest.mark.parametrize("name", NAMES)
def test_the_listed_commands_are_exactly_those_at_or_above_the_stated_share_and_the_errors_stay_as_they_were(built, name, tmp_path):
    db = sample(built, name, tmp_path)
    before = errors_of(db)
    for share in (0.00001, 0.0002, 0.0005, 0.001, 50, 99.999):
        out = str(tmp_path / "list.csv")
        r = NL.run(db, out, share=share, set_by="the admin of the test", summary_csv=str(tmp_path / "summary.csv"))
        want = slow(db, share)
        head, rows = listed(out)
        assert head == [c for c, _m in NL.OUTPUT_COLUMNS]
        got = [int(x["row of the NVMe command file"]) for x in rows]
        assert sorted(got) == sorted(want) and len(got) == len(set(got)) == r["listed"] == sum(e["at_or_above_the_share"] for e in r["summary"])
        shares = [float(x["share of the limit used (per cent)"]) for x in rows]
        assert shares == sorted(shares, reverse=True)                                  # the closest to the limit first
        for x in rows:
            assert abs(float(x["share of the limit used (per cent)"]) - want[int(x["row of the NVMe command file"])]) < 1e-5
            assert x["measured time"].split()[-1] in ("s", "ms", "us", "ns", "ps") and "Linux" in x["source of the limit"]
            assert x["the host's limit for this kind"] in ("30 s", "60 s")
        assert r["share"]["percent"] == share and r["share"]["set_by"] == "the admin of the test" and "set by the admin of the test" in r["words"]
        assert r["adds_to_the_error_list"] is False
        for e in r["summary"]:                                                          # the summary per command kind, and its sentence when none is listed
            if not e["at_or_above_the_share"]:
                assert e["words"].startswith("No %s command came closer to the limit than " % e["kind"]) and "per cent" in e["words"]
            assert abs(e["largest_share_per_cent"] + e["margin_per_cent"] - 100) < 1e-6
        _h, srows = listed(str(tmp_path / "summary.csv"))
        assert len(srows) == len(r["summary"]) > 0
    assert slow(db, 0.00001), "the lowest share of this test must list something, or it proves nothing"
    assert errors_of(db) == before                                                      # the error list, the counts and the file itself: unchanged
    d = NL.run(db, str(tmp_path / "d.csv"))                                             # nobody stated a share: the default, said with its reason
    assert d["share"]["is_default"] and d["share"]["percent"] == NL.DEFAULT_SHARE_PERCENT and "Nobody set it" in d["words"] and NL.DEFAULT_SHARE_REASON in d["words"]
    assert d["listed"] == len(slow(db, NL.DEFAULT_SHARE_PERCENT))
    assert errors_of(db) == before


@pytest.mark.parametrize("name", NAMES)
def test_the_usual_time_is_the_timeout_rules_own(built, name, tmp_path):
    db = sample(built, name, tmp_path)
    con = NL._ro(db)
    lims, usual, why = NL._prepare(con, None)
    con.close()
    kept = json.loads(sqlite3.connect(db).execute("SELECT v FROM meta WHERE k='rules'").fetchone()[0])["timing"]["usual"]
    assert why == "" and lims["io"]["ps"] == IO and lims["admin"]["ps"] == ADM and len(kept) == len(usual) > 0
    for g in kept:
        mine = usual[(1 if g["admin"] else 0, g["opc"], (g["blocks"] - 1) if g["blocks"] is not None else -1)]
        assert mine["bar_ps"] == g["bar_ps"] and mine["n"] == g["n"]
        if g["bar_ps"] is not None:
            assert mine["usual_ps"] == g["median_ps"]
        else:
            assert mine["usual_ps"] is None                                             # fewer than 20: no usual time, and none is made up


def test_stretched_commands_are_listed_by_their_share_and_those_at_or_over_the_limit_are_the_timeout_rules(built, tmp_path):
    db = sample(built, "S17_io_timeout_abort_reset", tmp_path)
    con = sqlite3.connect(db)
    rows = [r[0] for r in con.execute("SELECT c.rowid_file FROM cmd c WHERE c.sqid != 0 AND c.opc = 2 AND c.sct = 0 AND c.sc = 0 AND c.t_ps IS NOT NULL AND EXISTS "
                                      "(SELECT 1 FROM ntx x WHERE x.parent_level = 'nvme_command' AND x.parent = c.rowid_file AND lower(x.type) LIKE '%completion queue entry%') "
                                      "ORDER BY c.rowid_file LIMIT 6 OFFSET 40")]
    con.close()
    assert len(rows) == 6
    parts = (60, 80, 95, 99.9, 100, 101)
    for row, pc in zip(rows, parts):
        stretch(db, row, IO * pc // 100 if pc != 99.9 else IO * 999 // 1000)
    RL.rerun_command_rules(db, {})
    before = errors_of(db)
    r = NL.run(db, str(tmp_path / "list.csv"), share=50, set_by="the admin of the test", thresholds={})
    _h, got = listed(str(tmp_path / "list.csv"))
    assert [int(x["row of the NVMe command file"]) for x in got] == [rows[3], rows[2], rows[1], rows[0]] == sorted(slow(db, 50), key=lambda k: -slow(db, 50)[k])
    assert [float(x["share of the limit used (per cent)"]) for x in got] == [99.9, 95.0, 80.0, 60.0]
    assert [float(x["margin left (per cent of the limit)"]) for x in got] == [pytest.approx(0.1), 5.0, 20.0, 40.0]
    assert all(x["measured time"] == t for x, t in zip(got, ("29.970 s", "28.500 s", "24 s", "18 s")))
    con = sqlite3.connect(db)
    filed = {rid: json.loads(d)["kind"] for rid, d in con.execute("SELECT rowid, detail FROM finding WHERE rule = 'cmd.timeout'")}
    con.close()
    assert filed[rows[4]] == filed[rows[5]] == "over the host's limit"                  # 100 and 101 per cent: errors of the existing rule ...
    near = {int(x["row of the NVMe command file"]) for x in got}
    assert rows[4] not in near and rows[5] not in near                                   # ... and never near-limit entries
    assert not [k for k in near if filed.get(k) in ("over the host's limit", "never completed", "aborted by the host")]      # no command is counted twice
    for x in got:                                                                        # the same command as slower than usual: said in its own column
        said = x["what the timeout rule says of this command"]
        assert said.startswith("also filed as an error by the timeout rule: slower than usual") == (filed.get(int(x["row of the NVMe command file"])) == "slower than usual")
        assert float(x["times slower than the usual time"]) > 1000
    reads = next(e for e in r["summary"] if e["kind"] == "Read")
    assert reads["at_or_above_the_share"] == 4 and reads["at_or_above_the_limit"] == 2 and reads["largest_share_per_cent"] == 99.9 and reads["row_of_the_slowest"] == rows[3]
    assert r["listed"] == 4 and r["at_or_above_the_limit"] == 2 and "the timeout rule files them as errors" in r["words"]
    assert errors_of(db) == before
    # the admin's own limit for the recording is the limit used, with its source
    r2 = NL.run(db, str(tmp_path / "l2.csv"), share=50, set_by="t", thresholds={"nvme_command": {"ps": 40 * 10 ** 12, "source": "set by the admin: 40 s"}})
    assert r2["limits"]["io"] == {"ps": 40 * 10 ** 12, "text": "40 s", "source": "set by the admin: 40 s", "set_by_admin": True}
    assert sorted(x["row"] for x in r2["rows"]) == sorted(slow(db, 50, io=40 * 10 ** 12, adm=40 * 10 ** 12)) and r2["listed"] == 5      # 18 s is 45 per cent of 40 s: no longer listed; 30 s and 30.3 s are now under the limit
    # the starting point of a sweep from the closest command: the window and the first sequence of the page of one error
    w = NL.window(db, rows[3], n=5, m=5, same_queue=False)
    assert [x["position"] for x in w["rows"]] == ["above"] * 5 + ["fault"] + ["below"] * 5 and w["window"]["anchor"] == "near_limit"
    assert [x["rowid_file"] for x in w["rows"]] == list(range(rows[3] - 5, rows[3] + 6))
    mid = next(x for x in w["rows"] if x["position"] == "fault")
    assert mid["rowid_file"] == rows[3] and mid["keep"] and isinstance(mid["raw"], dict) and mid["raw"].get("OPC")
    q = NL.window(db, rows[3], n=5, m=5)                                                 # as the page of one error asks by default: the same queue only
    assert len({x["sqid"] for x in q["rows"]}) == 1 and [x["position"] for x in q["rows"]].count("fault") == 1
    step = next(s for s in w["steps"] if s["position"] == "fault")
    assert step["source_row"] == rows[3] and step["command"] == "Read" and "it is not a fault" in step["expected"] and "99.9 per cent" in step["expected"]
    assert [s["step"] for s in w["steps"]] == list(range(1, len(w["steps"]) + 1)) and w["near_limit"]["share_per_cent"] == 99.9
    for bad in (rows[4], 10 ** 9, "x"):                                                  # over the limit, no such row, not a number: a plain refusal
        with pytest.raises(NL.Refused):
            NL.window(db, bad)
    assert errors_of(db) == before


def test_a_share_that_is_not_a_share_is_refused_in_plain_words(built, tmp_path):
    db = sample(built, "demo_225_commands", tmp_path)
    out = str(tmp_path / "list.csv")
    for bad, word in ((0, "selects nothing"), (100, "error of the timeout rule"), (-5, "selects nothing"), ("many", "is not a number"), (10 ** 400, "too large"),
                      (1e308, "cannot be used"), (float("nan"), "real number"), (float("inf"), "real number"), (True, "not yes or no"), ([50], "must be a number"), ("1e999", "real number")):
        with pytest.raises(NL.Refused) as e:
            NL.run(db, out, share=bad)
        assert word in str(e.value) and "above 0 and below 100" in str(e.value)
    assert not os.path.exists(out)                                                       # a refusal writes nothing
    assert NL.share_of("80 %")["percent"] == NL.share_of("80 per cent")["percent"] == NL.share_of(80)["percent"] == 80.0      # the documented meaning of text
    assert NL.share_of("")["is_default"] and NL.share_of(None)["is_default"]


def generated(path, n, extra=()):
    """A recording made here with only the tables and columns the item reads: n Reads of 8 blocks on queue 1, each with one completion entry."""
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
    con.execute("CREATE TABLE cmd (rowid_file INTEGER PRIMARY KEY, n INTEGER, opc INTEGER, sqid INTEGER, cid INTEGER, nsid INTEGER, slba INTEGER, nlb INTEGER, fua INTEGER, "
                "sct INTEGER, sc INTEGER, t_ps INTEGER, dur_ps INTEGER, raw TEXT)")
    con.execute("CREATE TABLE ntx (rowid_file INTEGER PRIMARY KEY, parent INTEGER, parent_level TEXT, type TEXT, t_ps INTEGER)")
    con.execute("INSERT INTO meta VALUES ('levels_present', ?)", (json.dumps(["nvme_command", "nvme_transaction"]),))
    step = 10 ** 9                                           # one command each millisecond

    def cmds():
        for i in range(1, n + 1):
            yield (i, i, 2, 1, i % 65536, 1, i * 8, 7, 0, 0, 0, i * step, None, "{}")

    def ends():
        for i in range(1, n + 1):                            # times from 0.3 s to 29.7 s, so nearly all are at or above 1 per cent of 30 s
            yield (i, i, "nvme_command", "I/O Completion Queue Entry", i * step + 3 * 10 ** 11 + (i * 7919 % 98) * 3 * 10 ** 11)
    con.executemany("INSERT INTO cmd VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", cmds())
    con.executemany("INSERT INTO ntx VALUES (?,?,?,?,?)", ends())
    for k, (opc, sqid, dur) in enumerate(extra, n + 1):
        con.execute("INSERT INTO cmd VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (k, k, opc, sqid, 1, 1, 0, 0, 0, 0, 0, k * step, None, "{}"))
        con.execute("INSERT INTO ntx VALUES (?,?,?,?,?)", (k, k, "nvme_command", "I/O Completion Queue Entry" if sqid else "Admin Completion Queue Entry", k * step + dur))
    con.commit()
    con.close()
    return path


def test_a_command_kind_with_a_single_command_has_no_usual_time_and_says_so(tmp_path):
    db = generated(str(tmp_path / "one.sqlite"), 40, extra=[(0x06, 0, 45 * 10 ** 12)])          # one Identify (admin) at 75 per cent of 60 s
    r = NL.run(db, str(tmp_path / "list.csv"), share=70, set_by="the admin of the test")
    one = next(x for x in r["rows"] if x["kind"] == "Identify (admin)")
    assert one["share_per_cent"] == 75.0 and one["limit"] == "60 s" and one["times_slower_than_usual"] is None and one["usual"] == ""
    assert one["about_the_usual_time"].startswith("no usual time: only 1 completed command of this kind and size") and "at least 20 are needed" in one["about_the_usual_time"]
    _h, rows = listed(str(tmp_path / "list.csv"))
    line = next(x for x in rows if x["command kind"] == "Identify (admin)")
    assert line["times slower than the usual time"] == "" and line["usual time for its kind and size"] == "" and line["size (blocks)"] == ""
    read = next(x for x in rows if x["command kind"] == "Read")                                 # 40 Reads of one size: a usual time, and a real factor
    assert read["usual time for its kind and size"] and float(read["times slower than the usual time"]) > 0 and read["size (blocks)"] == "8"
    # the same through the tree a procedure's code is given: the main file alone, read-only, temporary tables beside the output
    from nvme_hier import tree_api
    tree = tree_api.Tree(db)
    t = NL.run_on_tree(tree, str(tmp_path / "tree.csv"), share=70, set_by="the admin of the test")
    tree.close()
    assert t["listed"] == r["listed"] and t["rows_written"] == len(listed(str(tmp_path / "tree.csv"))[1]) and [x["row"] for x in t["rows"]] == [x["row"] for x in r["rows"]]
    # a recording without the NVMe transactions: said in words, an empty list, never a crash
    bare = str(tmp_path / "bare.sqlite")
    con = sqlite3.connect(bare)
    con.execute("CREATE TABLE meta (k TEXT PRIMARY KEY, v TEXT)")
    con.execute("CREATE TABLE cmd (rowid_file INTEGER PRIMARY KEY, n INTEGER, opc INTEGER, sqid INTEGER, cid INTEGER, nlb INTEGER, sct INTEGER, sc INTEGER, t_ps INTEGER, raw TEXT)")
    con.commit()
    con.close()
    r = NL.run(bare, str(tmp_path / "bare.csv"))
    assert r["can_be_measured"] is False and "NVMe transactions file" in r["why_not"] and listed(str(tmp_path / "bare.csv"))[1] == []


def test_the_list_is_streamed_to_the_file_on_a_recording_of_200_000_commands(tmp_path):
    n = 200000
    db = generated(str(tmp_path / "big.sqlite"), n)
    out = str(tmp_path / "list.csv")
    said = []
    tracemalloc.start()
    start = tracemalloc.get_traced_memory()[0]
    r = NL.run(db, out, share=1, set_by="the admin of the test", progress=lambda stage, detail: said.append(detail))
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    grown = (peak - start) / 1024.0 ** 2
    want = slow(db, 1)
    assert r["listed"] == len(want) >= 190000 and len(r["rows"]) == NL.SHOWN_AT_ONCE and r["has_more"]        # the answer holds 200 rows, the file all of them
    with open(out, newline="", encoding="utf-8") as fh:
        assert sum(1 for _ in fh) == r["listed"] + 1
    assert os.path.getsize(out) > 20 * 1024 ** 2                                                              # the list itself is far larger than what was held
    assert grown < MEMORY_GROWTH_MB, "the item held %.1f MB while writing a list of %.1f MB" % (grown, os.path.getsize(out) / 1024.0 ** 2)
    assert said[-1] == "done (100 %)" and len(said) > 50 and all("%" in s for s in said)
    print("\nstreaming: %d commands listed, CSV %.1f MB, Python memory grew by %.1f MB at its peak (bound: %d MB)" % (r["listed"], os.path.getsize(out) / 1024.0 ** 2, grown, MEMORY_GROWTH_MB))


def test_the_item_has_the_structure_of_a_library_item_and_every_column_has_its_meaning():
    it, proc = NL.ITEM, NL.PROCEDURE
    assert (it["section"], it["level"], it["id"]) == ("analytics", "nvme_command", "near_limit") and it["kind"] != "detection_rule"
    assert set(("id", "section", "level", "name", "description", "definition", "kind", "plan", "family1", "source")) <= set(it)
    assert all(c and m and len(m) > 20 for c, m in NL.OUTPUT_COLUMNS + NL.SUMMARY_COLUMNS) and proc["output"]["columns"] == [c for c, _m in NL.OUTPUT_COLUMNS]
    assert "percent" not in [c.lower() for c in proc["output"]["columns"]] and "count" not in [c.lower() for c in proc["output"]["columns"]]
    ev = NL.evidence()
    with open(os.path.join(APP_DIR, ev["code"]["path"]), encoding="utf-8") as fh:
        text = fh.read().split("\n")
    for s in ev["code"]["snippets"]:                                                    # the code lines shown are the lines of the file
        assert text[s["from"] - 1].startswith("def %s(" % s["function"]) and "\n".join(text[s["from"] - 1:s["to"]]) == s["text"]
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE cmd (%s)" % ", ".join(c for _n, c, _f in L.KEYS["nvme_command"]))
    con.execute("CREATE TABLE ntx (%s, parent, parent_level)" % ", ".join(c for _n, c, _f in L.KEYS["nvme_transaction"]))
    have = {"nvme_command": {r[1] for r in con.execute("PRAGMA table_info(cmd)")}, "nvme_transaction": {r[1] for r in con.execute("PRAGMA table_info(ntx)")}}
    assert all(col in have[lv] for lv, col in ev["reads"])                              # every column it says it reads is a column of the tree
    named = {name for name, _c, _f in L.KEYS["nvme_command"]} | {name for name, _c, _f in L.KEYS["nvme_transaction"]}
    assert all(c["column"] in named and c["use"] for c in ev["columns"]) and set(it["family1"]["columns"]) <= named
    code = NL.code_for(80, "the admin")
    compile(code, "near_limit_item.py", "exec")
    assert "SHARE_PER_CENT = 80.0" in code and "def run(tree, out_csv):" in code


# ---- the result as the Tester checks it and as the result card says it (agentic/procedures.py application_checks, application_card)
def test_the_testers_checks_pass_on_an_empty_list_and_on_a_list_and_catch_a_changed_result(built, tmp_path):
    db = sample(built, "S17_io_timeout_abort_reset", tmp_path)
    out = str(tmp_path / "list.csv")
    r = NL.run(db, out)                                                                 # the starting share: nothing is listed on the sample
    checks = NL.result_checks(out, r)
    assert r["listed"] == 0 and all(c["ok"] for c in checks), [c for c in checks if not c["ok"]]
    assert any("an empty list is a result here, not a failure" in c["detail"] for c in checks)
    assert any(c["check"] == "it is analytics: it adds nothing to the errors of the recording" for c in checks)
    lines, data = NL.card_lines(r)
    said = [e["words"] for e in r["summary"]]
    assert said and all(("- " + w) in lines for w in said) and all(w.startswith("No ") and "came closer to the limit than" in w for w in said)
    assert any(x.startswith("**In plain words:** No command came close to the limit") and "Nobody set it" in x for x in lines)
    assert [k["words"] for k in data["kinds"]] == said and data["is_an_error_rule"] is False and data["share"]["is_default"] is True
    r = NL.run(db, out, share=0.0005, set_by="the admin")                               # five listed (the builder's report)
    checks = NL.result_checks(out, r)
    assert r["listed"] == 5 and all(c["ok"] for c in checks), [c for c in checks if not c["ok"]]
    lines, data = NL.card_lines(r)
    assert any("set by the admin" in x for x in lines) and data["listed"] == 5
    # a result file that is not the one the summary describes is caught: a line taken away, a share under the admin's, the order turned
    with open(out, newline="", encoding="utf-8") as fh:
        rows = list(csv.reader(fh))
    i = rows[0].index("share of the limit used (per cent)")

    def failed(changed):
        p = str(tmp_path / "changed.csv")
        with open(p, "w", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerows(changed)
        return [c["check"] for c in NL.result_checks(p, r) if not c["ok"]]
    assert failed(rows[:-1]) == ["the list holds exactly the commands the summary counts per command kind"]
    low = [list(x) for x in rows]
    low[-1][i] = "0.0000001"
    assert failed(low) == ["every listed command is at or above the share and under the host's limit"]
    assert "the list is in its order: the largest share of the limit first" in failed([rows[0]] + rows[1:][::-1])
    assert "the output has the item's columns, in its order" in failed([rows[0][:-1]] + [x[:-1] for x in rows[1:]])
    # nothing that can be measured: the result says why, and the checks pass on that
    empty = str(tmp_path / "empty.sqlite")
    generated(empty, 0)
    r0 = NL.run(empty, out)
    if r0.get("can_be_measured") is False:
        assert all(c["ok"] for c in NL.result_checks(out, r0)), NL.result_checks(out, r0)
        assert NL.card_lines(r0)[0]
