"""The joins of 2026-11-15 on the flow pages (app/static/js/agents.js) and in the Settings (app/api/config_api.py):

  - the errors page: errors a rule found in a CSV file that is not part of the tree get a section of their own, each with a link to its own
    page, and the tree's lists no longer show such a rule with a count and an empty table;
  - the rules browser shows the application's own lines behind the built-in item "commands that completed but came close to the limit";
  - Family 4's requirements card: the tick "Ask the REA agent", the two choices for a changed procedure, "Rests on", the two new ledger kinds;
  - Family 4's code card: the recheck by the terminal agent, and the button that asks for it;
  - the start page's words for a recording of any tool; the files that were not read as a table;
  - Settings: three switches of the settings file, which the server takes with exactly their allowed values and refuses otherwise.

No browser and no model: a throw-away application (the one tests/test_other_csv_errors.py builds, with one finished analysis of a CSV file that
is not an analyzer export), and the page's own functions run by node against a stand-in page with the real answers of the routes. Everything
is written under pytest's temporary folders.
"""
import copy
import json
import os
import re
import shutil
import subprocess
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

import test_other_csv_errors as OTHER  # noqa: E402  (its World: the throw-away application and the finished analysis)
from api import config_api, svc  # noqa: E402
from nvme_hier import near_limit  # noqa: E402

REAL_SAVE = config_api.save_config          # kept before any test replaces it: the saving itself is tested here, into the throw-away folder
NODE = "/home/raghavendra/.nvm/versions/node/v22.23.2/bin/node"
JS = os.path.join(APP, "app", "static", "js", "agents.js")
ITEM_E = OTHER.ITEM_E

SWITCHES = [("stage2", "search_memory", [True, False]), ("tree", "round_rule", [True, False]), ("agentic", "f4_recheck", ["always", "ask", "never"])]
GARBAGE = {"stage2": [1, 0, "true", "on", None, [], {}, "x" * 200000, "tr\x00ue", 1.5],
           "tree": [1, 0, "false", "off", None, [True], {"a": 1}, "y" * 200000, "\x00", -1],
           "agentic": ["sometimes", "Always", "always ", "al\x00ways", "ask\x00", "z" * 200000, True, False, None, 3, ["always"], {"v": "never"}, ""]}
NEW_LABELS = ["Ask the REA agent", "The changed procedure", "Rests on", "Recheck by the terminal agent",
              "Stage 2: start each search from what earlier searches learned", "The tree: a packet whose number comes round again",
              "Family 4 · Coding research: the recheck of the finished code by the terminal agent"]
NEW_FUNCTIONS = ["otherCsvSteps", "otherCsvFromSteps", "loadOtherCsv", "otherCsvSection", "rbLibraryCode", "f4RestsOn", "f4ProcChange", "f4ReaTick", "f4ReaChanged", "f4Recheck",
                 "switchSection", "switchChanges"]


def script():
    with open(JS, encoding="utf-8") as fh:
        return fh.read()


def piece(text, name):
    """One top-level function or constant of the page script, as its text (to the closing brace in the first column, or to the line that ends it)."""
    m = re.search(r"^(?:async )?function %s\(.*?^}\n" % re.escape(name), text, re.M | re.S)
    if m:
        return m.group(0)
    m = re.search(r"^const %s = .*?;\n" % re.escape(name), text, re.M | re.S)
    assert m, "the page script has no top-level %s" % name
    return m.group(0)


STAND_IN_PAGE = r"""
// a stand-in page: only what the functions under test touch
const els = {}, radios = {};
const document = { getElementById: id => els[id] || null,
  querySelector: sel => { const m = /^input\[name="([^"]+)"\]:checked$/.exec(sel); return m && radios[m[1]] ? { value: radios[m[1]] } : null; } };
const window = { scrollY: 0, scrollTo() {} };
const $ = id => document.getElementById(id);
const IC = { chev: "", left: "" };
const S = { tok: 1, state: null, project: null };
const asked = [];
const ANSWERS = JSON.parse(require("fs").readFileSync(process.argv[2], "utf8"));
async function api(method, url, body) { const k = method + " " + url; asked.push(k); if (!(k in ANSWERS)) throw new Error("this address does not answer"); return ANSWERS[k]; }
async function refreshState() { S.state = ANSWERS["GET /api/agents/state"]; }
function setProject(id) { S.project = id; }
function crumb() {}
function captureUi() { return null; }
function restoreUi() {}
function sigOf() { return ""; }
function plainDefects() { return null; }
"""


def run_node(tmp_path, names, scenario, answers):
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    text = script()
    d = tmp_path / "page"
    os.makedirs(str(d), exist_ok=True)
    (d / "answers.json").write_text(json.dumps(answers), encoding="utf-8")
    body = STAND_IN_PAGE + "\n".join(piece(text, n) for n in names) + "\n(async () => {\n" + scenario + "\n})().catch(e => { console.log('FAILED ' + e.stack); });\n"
    (d / "run.cjs").write_text(body, encoding="utf-8")
    p = subprocess.run([NODE, str(d / "run.cjs"), str(d / "answers.json")], capture_output=True, text=True, encoding="utf-8", timeout=60)
    line = next((ln for ln in p.stdout.splitlines() if ln.startswith("RESULT ")), None)
    assert line, (p.stdout[-1500:], p.stderr[-1500:])
    return json.loads(line[7:])


@pytest.fixture(scope="module")
def world(tmp_path_factory):
    mp = pytest.MonkeyPatch()
    try:
        # the tests run in a shuffled order (pytest-randomly): a test of the same session may have switched the engine's start off for good
        # (tests/fuzz_app.py setup); a flow needs the engine's own start, which that file keeps as REAL_KICK
        kick = getattr(sys.modules.get("fuzz_app"), "REAL_KICK", None)
        if kick is not None:
            mp.setattr(OTHER.core.Engine, "kick", kick)
        w = OTHER.World(tmp_path_factory.mktemp("flow_page_joined"), mp)
        mp.setattr(config_api, "save_config", REAL_SAVE)          # the settings file of this throw-away application is really written
        with w.app.app_context():
            w.cfg = svc().cfg
        assert w.cfg["_path"].startswith(w.root) and REAL_SAVE.__name__ == "save_config"
        yield w
    finally:
        mp.undo()
        OTHER.family3._SECTIONS_SEEN[0] = None


def saved(world):
    with open(world.cfg["_path"], encoding="utf-8") as fh:
        return json.load(fh)


def plain(cfg):
    return json.loads(json.dumps({k: v for k, v in cfg.items() if not k.startswith("_")}))


# ---------------------------------------------------------------------------------------------- 1. the settings routes
def test_each_allowed_value_of_the_three_switches_is_saved_and_nothing_else_changes(world):
    c = world.c
    for sec, key, values in SWITCHES:
        for v in values + values[:1]:
            before = plain(world.cfg)
            r = c.put("/api/config", json={sec: {key: v}})
            assert r.status_code == 200 and r.get_json()["ok"] is True, (sec, key, v, r.get_data(as_text=True)[:300])
            after = plain(world.cfg)
            assert after[sec][key] is v or after[sec][key] == v and type(after[sec][key]) is type(v)
            want = copy.deepcopy(before)
            want[sec][key] = v
            assert after == want                                                    # the other switches, the endpoint lock and everything else as they were
            assert saved(world) == after                                            # and that is what the settings file holds
            assert c.get("/api/config").get_json()["config"][sec][key] == v         # what the page reads back


def test_anything_else_is_refused_in_a_plain_sentence_and_nothing_is_saved(world):
    c = world.c
    c.put("/api/config", json={"stage2": {"search_memory": True}})                  # so that the file exists
    before, file_before = plain(world.cfg), saved(world)
    n = 0
    for sec, key, _values in SWITCHES:
        for bad in GARBAGE[sec]:
            r = c.put("/api/config", json={sec: {key: bad}})
            words = (r.get_json() or {}).get("error") or ""
            assert r.status_code == 400, (sec, key, repr(bad)[:40], r.status_code)
            assert words.startswith("The switch “") and words.endswith("so nothing was saved.") and "takes only" in words and len(words) < 400, words[:300]
            assert "\x00" not in words and "Traceback" not in words and "xxxx" not in words and "yyyy" not in words and "zzzz" not in words
            n += 1
    # a group that is not a group, and a body that is not a set of groups
    for body in ({"tree": "on"}, {"tree": [1]}, {"agentic": 7}, {"agentic": "never"}):
        r = c.put("/api/config", json=body)
        words = (r.get_json() or {}).get("error", "")
        assert r.status_code == 400 and words.startswith("The group “") and words.endswith("so nothing was saved."), (body, r.status_code, words)
        n += 1
    for body in ([1, 2], "always", 5):                                               # the application refuses such a body before any route sees it
        r = c.put("/api/config", json=body)
        assert r.status_code == 400 and len((r.get_json() or {}).get("error", "")) > 20 and "Traceback" not in r.get_data(as_text=True), (body, r.status_code)
        n += 1
    assert config_api.switch_problem([1, 2]).endswith("so nothing was saved.") and config_api.switch_problem({}) is None
    # a good value beside a bad one: nothing of the request is saved
    r = c.put("/api/config", json={"tree": {"round_rule": not before["tree"]["round_rule"]}, "agentic": {"f4_recheck": "at times"}})
    assert r.status_code == 400
    assert n >= 40 and plain(world.cfg) == before and saved(world) == file_before


def test_the_endpoint_lock_is_not_touched_and_does_not_stop_the_switches(world):
    c, server = world.c, world.cfg["server"]
    was = server.get("lock_endpoint")
    try:
        for lock in (False, True):
            server["lock_endpoint"] = lock
            for sec, key, values in SWITCHES:
                for v in values:
                    r = c.put("/api/config", json={sec: {key: v}, "server": {"lock_endpoint": not lock, "port": 1}})
                    assert r.status_code == 200, (lock, sec, key, v, r.get_data(as_text=True)[:200])
                    assert world.cfg["server"]["lock_endpoint"] is lock and world.cfg["server"]["port"] != 1
                    assert saved(world)["server"]["lock_endpoint"] is lock
        # the lock still does what it did: the address of the model cannot be changed from the page
        server["lock_endpoint"] = True
        r = c.put("/api/config", json={"llm": {"base_url": "http://127.0.0.1:1/other"}, "tree": {"round_rule": True}})
        assert r.status_code == 403 and "locked by server.lock_endpoint" in r.get_json()["error"]
        # of the two groups that have their own address, only the switch is taken
        server["lock_endpoint"] = False
        runtime = world.cfg["agentic"]["runtime"]
        r = c.put("/api/config", json={"agentic": {"f4_recheck": "ask", "runtime": "claude-code", "model": "x"}, "tree": {"round_rule": True, "other": 1}})
        assert r.status_code == 200 and world.cfg["agentic"]["runtime"] == runtime and world.cfg["agentic"]["f4_recheck"] == "ask" and "other" not in world.cfg["tree"]
    finally:
        server["lock_endpoint"] = was
        c.put("/api/config", json={"agentic": {"f4_recheck": "always"}})


# ---------------------------------------------------------------------------------------------- 2. the page script as text
def test_the_script_is_sound_in_the_form_the_page_loads_it(tmp_path):
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    with open(os.path.join(APP, "app", "static", "agents.html"), encoding="utf-8") as fh:
        tag = re.search(r"<script[^>]*src=\"/static/js/agents\.js\"[^>]*>", fh.read()).group(0)
    forms = ["agents.mjs"] if 'type="module"' in tag else ["agents.cjs", "agents.mjs"]       # a classic script; as a module too, where a name declared twice is an error
    for name in forms:
        dst = str(tmp_path / name)
        shutil.copyfile(JS, dst)
        r = subprocess.run([NODE, "--check", dst], capture_output=True, text=True, timeout=120)
        assert r.returncode == 0, (name, r.stderr[-1500:])


def test_no_top_level_name_is_declared_twice_and_every_new_part_is_there():
    text = script()
    seen = [a or b for a, b in re.findall(r"^(?:async )?function\*? ([A-Za-z0-9_$]+)|^(?:const|let|var|class) ([A-Za-z0-9_$]+)", text, re.M)]
    twice = sorted({n for n in seen if seen.count(n) > 1})
    assert len(seen) > 100 and not twice, twice
    for name in NEW_FUNCTIONS + ["OTHER_CSV_WORDS", "F4_KIND_WORDS"]:
        assert seen.count(name) == 1, name
    for words in ('id="sec-other-csv"', 'two("set-memory", mem)', 'two("set-round", round)', 'pick("set-recheck", ', 'id="f4rea${r.id}"', 'name="f4pc${r.id}"', "Confirm the changed procedure", "This is not what I meant",
                  "Recheck this code with the terminal agent", "REA agent (findings from the analyzer's decompiled code)", 'requirement: "Requirement"',
                  "What these lines test, in words:", "Files of the folder that were not read as a table", "Not read as a table: "):
        assert words in text, words
    # the three places that use the new parts
    assert "h += otherCsvSection(otherCsv);" in text and "${rbLibraryCode(x.library_code)}" in text and "${switchSection(appCfg)}" in text
    assert "${f4RestsOn(r)}" in text and "${f4ProcChange(r)}${f4ReaTick(r)}" in text and "f4Recheck(r, ask)" in text


def test_every_new_field_label_has_its_why_line_directly_under_it():
    text = script()
    for label in NEW_LABELS:
        m = re.search(r"<label class=\"f\"[^>]*>%s</label>\s*<div class=\"why\">((?:(?!</div>).)*)</div>" % re.escape(label), text, re.S)
        assert m, label
        assert len(re.sub(r"<[^>]+>|\$\{[^}]*\}", "", m.group(1))) > 40, label
    # and no field label of the new functions is without one
    for name in NEW_FUNCTIONS:
        body = piece(text, name)
        labels = re.findall(r"<label class=\"f\"", body)
        with_why = re.findall(r"<label class=\"f\"[^>]*>(?:(?!</label>).)*</label>\s*<div class=\"why\">((?:(?!</div>).)*)</div>", body, re.S)
        assert len(labels) == len(with_why) and all(len(re.sub(r"<[^>]+>|\$\{[^}]*\}", "", w)) > 40 for w in with_why), name
    # the builders' own sentences, word for word
    for words in ("Why: the REA agent holds findings from the analyzer's decompiled code. With the tick, Family 4 puts the questions its research raised to it; it answers only with the file, "
                  "the lines and the quoted words, or says that the findings do not hold it. Without the tick the findings are not looked at.",
                  "Why: the procedure is your approved text. Your answer changed what the output must be, so the code is written from the changed procedure only after you confirm it.",
                  "Why: every requirement names its evidence: your words, Family 1's answer (yes / no / cannot tell), a measured fact of the data research, or a REA answer with its quote.",
                  "Why: the Coder and the Tester cannot open your file or run a program. The terminal agent can: it writes a second program from the requirements alone, runs it on the whole "
                  "file, and the application compares the two results itself.",
                  "Why: the setting says the recheck is made only when you ask. It starts one round of Coder and Tester from this code and then the recheck: at most 2 rechecks, 300 seconds each.",
                  "Start each search from what earlier searches of the same kind of defect learned. On: the best procedure found earlier is run first and the counts of which changes helped are "
                  "carried over, limited to the weight of 14 lab runs. Off: every search starts without history and stores nothing.",
                  "a packet whose number comes round again is its own link transaction once a later Ack", "Off: the join as it was before 2026-11-14.",
                  "a tree already built keeps its joins until it is built again"):
        assert words in text, words[:60]


def test_nothing_is_chosen_or_filled_in_for_the_admin_in_the_new_parts():
    text = script()
    for name in NEW_FUNCTIONS:
        body = piece(text, name)
        assert not re.search(r"<input[^>]*\schecked[\s>/]", body), name                    # a tick or a choice is never written as chosen
        assert not re.search(r"<input[^>]*type=\"(?:text|number)\"[^>]*value=", body) and "<textarea" not in body, name       # no field is filled in
        for opt in re.findall(r"<option(?:\$\{[^}]*\}|[^>$])*>", body):
            fixed = re.sub(r"\$\{[^}]*\}", "", opt)                                         # what is written whatever the settings file holds
            assert " selected" not in fixed or 'value=""' in fixed, (name, opt)             # only "not set" can be written as the shown entry
    assert '${on ? " checked" : ""}' in piece(text, "f4ReaTick") and '${was("confirm")}' in piece(text, "f4ProcChange") and '${was("refuse")}' in piece(text, "f4ProcChange")


def test_the_start_page_speaks_of_a_recording_of_any_tool_and_keeps_the_words_for_the_five_file_export():
    text = script()
    at = text.index('<label class="f" for="np-folder">')
    why = text[at:text.index("</div>", at)]
    for words in ("all in one folder, whichever tool exported them", "For a Teledyne LeCroy export (one .pex recording, up to five levels) the levels are recognised and the tree can be built from them",
                  "for another tool every CSV file is read by itself", "they stay where they are and nothing is copied", "<b>Check</b>"):
        assert words in why, words
    check = piece(text, "checkFolder")
    assert "not an analyzer level" not in text and "one .pex file, up to five levels). The agents read them here and build the tree" not in text
    assert "not one of the five levels of a Teledyne LeCroy export: read by itself" in check
    assert "All five levels are there" in check and "never makes up a missing level" in check and "No tree can be built from them (stage 2 is a choice after stage 1)." in check
    assert "For a recording of another tool that is as expected: every CSV file is read by itself and gets its data dictionary" in check
    assert '${lv === 5 ? "muted" : lv ? "err" : ""}' in check                             # no level at all is not shown as a fault: it is the usual case for another tool


# ---------------------------------------------------------------------------------------------- 3. the page's functions, run by node
ERRORS_PAGE = ["ERR_WORDS", "errorLists", "errorsWaiting", "errorsNothing", "sameCommand", "errNotes", "loadErrStatus", "errStat", "errHref", "errCounts", "OTHER_CSV_WORDS", "otherCsvSteps", "otherCsvFromSteps", "loadOtherCsv",
               "otherCsvSection", "loadFlow", "renderErrorsPage", "esc", "nf",
               "errorsNoLongerFound", "errNumbersChecked", "errNumbersNote"]      # (2026-11-15) the listed numbers are checked against the recording before a link is drawn


def flow_answers(world):
    c = world.c
    out = {"GET /api/agents/state": c.get("/api/agents/state").get_json(),
           "GET /api/agents/runs?project=%d" % world.pid: c.get("/api/agents/runs?project=%d" % world.pid).get_json(),
           "GET /api/agents/runs/%d" % world.rid: c.get("/api/agents/runs/%d" % world.rid).get_json(),
           "GET /api/other-errors/%d" % world.rid: c.get("/api/other-errors/%d" % world.rid).get_json()}
    assert all(isinstance(v, (dict, list)) and "error" not in v for v in out.values())
    return out


def test_the_errors_page_lists_the_other_csv_errors_with_links_and_no_empty_table(world, tmp_path):
    answers = flow_answers(world)
    view, listed = answers["GET /api/agents/runs/%d" % world.rid], answers["GET /api/other-errors/%d" % world.rid]
    steps = {s["key"]: s for s in view["steps"]}
    # the case the builder reported: the item's errors step is of the kind "other_csv" with an empty list, and its run step has rows
    assert steps["f3:%s:errors" % ITEM_E]["output"]["kind"] == "other_csv" and steps["f3:%s:errors" % ITEM_E]["output"]["errors"] == []
    assert steps["f3:%s:run" % ITEM_E]["output"]["head"] and listed["total"] == len(listed["errors"]) > 0
    out = run_node(tmp_path, ERRORS_PAGE, r"""
      const v = ANSWERS["GET /api/agents/runs/%(rid)d"], m = { innerHTML: "" };
      await renderErrorsPage(m, %(pid)d, null, false);
      const first = [...asked];
      delete ANSWERS["GET /api/other-errors/%(rid)d"];           // the address does not answer: the same data from the flow's own steps
      const m2 = { innerHTML: "" };
      await renderErrorsPage(m2, %(pid)d, null, false);
      const plain = JSON.parse(JSON.stringify(v)); plain.steps = plain.steps.filter(s => !(s.output && s.output.kind === "other_csv"));
      // (2026-11-15) the page also says which patterns are not listed yet (errorsWaiting): nothing in this finished analysis; one sentence when a result still waits
      const waits = JSON.parse(JSON.stringify(v)); for (const s of waits.steps) if (s.key === "f3:%(item)s:result") s.state = "needs_review";
      console.log("RESULT " + JSON.stringify({ lists: errorLists(v).map(s => s.key), page: m.innerHTML, asked: first, fallback: m2.innerHTML,
        older_way_without_the_kind: errorLists(plain).map(s => s.key), no_section_without_such_a_step: otherCsvSection(await loadOtherCsv(plain)),
        nothing_waits: errorsWaiting(v), a_result_waits: errorsWaiting(waits), listed_no_error: errorsNothing(v),
        a_rule_found_nothing: errorsNothing({ steps: [{ key: "f3:errors/nvme_command/x:errors", state: "skipped", output: { nothing: "The rule <x> found no error in this recording." } }] }) }));
    """ % {"rid": world.rid, "pid": world.pid, "item": ITEM_E}, answers)
    page, t = out["page"], listed["texts"]
    assert steps["f3:%s:result" % ITEM_E]["state"] == "approved" and out["nothing_waits"] == "" and "Not listed yet" not in page and "Not listed yet" not in out["fallback"]
    assert out["a_result_waits"].startswith('<div class="card"><h2>Not listed yet</h2>') and out["a_result_waits"].count("<p ") == 1
    assert "waits for your decision on page 3: its errors are listed here after you approve it." in out["a_result_waits"]
    # ... and which rules listed no error (errorsNothing): none here, where the one errors rule found errors; the server's sentence when one found nothing
    assert out["listed_no_error"] == "" and "Rules that listed no error" not in page and "Rules that listed no error" not in out["fallback"]
    assert out["a_rule_found_nothing"] == ('<div class="card"><h2>Rules that listed no error</h2><p class="muted" style="max-width:85ch">'
                                           'The rule &lt;x&gt; found no error in this recording.</p></div>')
    assert out["lists"] == []                                                              # not among the tree's errors
    assert out["older_way_without_the_kind"] == ["f3:%s:errors" % ITEM_E]                    # (the older way would have listed it: that was the fault)
    assert "<th>What was found</th>" not in page and 'id="sec-%s"' % ITEM_E not in page and "No errors yet" not in page          # no section with a count and an empty table
    assert page.count('<section class="card" id="sec-other-csv">') == 1 and "<h2 style=\"margin:0\">Errors in CSV files that are not part of the tree</h2>" in page
    esc = lambda s: s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;")      # noqa: E731
    for words in (t["title"], t["about"], t["cannot"], t["where"], t["rule"]):
        assert esc(words) in page, words[:50]                                              # the server's own words
    assert esc(t["none"]) not in page
    for e in listed["errors"]:
        link = '<a class="btn small primary" href="/other-error?run=%d&amp;error=%d" target="_blank" rel="noopener">Open this error&#39;s page</a>' % (world.rid, e["error"])
        assert page.count(link) == 1 and "<td>%s</td>" % esc(e["where"]) in page
    assert page.count("<tr><td>") == len(listed["errors"]) and page.count('target="_blank"') == len(listed["errors"])
    rule = listed["rules"][0]
    assert "<b>%s</b>: %s error" % (esc(rule["rule"]), "{:,}".format(rule["total"])) in page and "isolation written for %d of them" % rule["isolated"] in page
    assert "GET /api/other-errors/%d" % world.rid in out["asked"] and not any("/api/dg/status" in a for a in out["asked"])
    # when the address does not answer: the same errors from the steps, and the page says where they come from
    fb = out["fallback"]
    assert "The full list could not be read from the server (this address does not answer)" in fb and "the first 200 errors of each rule" in fb
    assert fb.count('href="/other-error?run=%d&amp;error=' % world.rid) == min(len(listed["errors"]), 200) and esc(t["cannot"]) in fb
    assert out["no_section_without_such_a_step"] == ""


F4 = ["esc", "nf", "F4_KIND_WORDS", "f4Research", "f4RestsOn", "f4ProcChange", "f4ReaTick", "f4ReaChanged", "f4ReqForm", "f4ReqEdits", "f4Proof", "f4ProofEdits", "f4Recheck", "f4Trail", "editsOf"]


def test_the_requirements_card_shows_the_tick_only_with_findings_and_chooses_nothing(tmp_path):
    """The card's data in the shape agentic/family4.py gives it (f4_rea, f4_procedure_change, f4_rests_on, the ledger with its kinds); made by hand."""
    data = {"f4_req": True, "questions": [{"question": "Which columns are meant?", "why": "the rule names two"}], "rounds": 10, "rounds_most": 20,
            "f4_research": {"files": [], "ledger": [{"what": "requirement R1", "kind": "requirement", "state": "established", "source": "the admin's words", "detail": "one line per city"},
                                                    {"what": "asked of the REA agent: what does the column hold?", "kind": "REA", "state": "to decide", "source": "", "detail": ""},
                                                    {"what": "the column City", "kind": "column", "state": "established", "source": "Family 1", "detail": ""}]},
            "f4_rests_on": {"R1": [{"basis": "the admin's words", "what": "the rule in the admin's words and the procedure he approved (version 2)"},
                                   {"basis": "measured by the data research", "what": "cities.csv column City: 6 of the 6 rows hold a value (counted by the program)"}], "R2": []},
            "f4_procedure_change": {"before": {"version": 2, "steps": ["a"], "output": {"columns": ["City"]}}, "after": {"steps": ["b"], "output": {"columns": ["City", "Count"]}}, "changes": ["Count added"]}}
    out = run_node(tmp_path, F4, r"""
      const base = ANSWERS.data, card = rea => ({ id: 7, data: Object.assign({}, base, rea === undefined ? {} : { f4_rea: rea }) });
      const res = {};
      res.no_findings = f4ReqForm(card(undefined));
      res.findings_null = f4ReqForm(card(null));
      res.not_given = f4ReqForm(card({ given: false, wanted: false }));
      res.given = f4ReqForm(card({ given: true, folder: "/findings", wanted: false, usable: null, why: "" }));
      res.edits_untouched = f4ReqEdits(card({ given: true, wanted: false }));               // no tick on the page yet: the key is not sent
      res.edits_without_findings = f4ReqEdits(card(undefined));
      els["f4rea7"] = { checked: false };
      res.edits_unticked = f4ReqEdits(card({ given: true, wanted: false }));
      res.changed_unticked = f4ReaChanged(card({ given: true, wanted: false }));
      els["f4rea7"].checked = true;                                                          // the admin ticks it
      res.edits_ticked = f4ReqEdits(card({ given: true, wanted: false }));
      res.changed_ticked = f4ReaChanged(card({ given: true, wanted: false }));
      res.drawn_again_after_the_tick = f4ReqForm(card({ given: true, wanted: false }));
      res.same_as_sent_before = f4ReaChanged(card({ given: true, wanted: true }));
      delete els["f4rea7"];
      res.asked_before = f4ReqForm(card({ given: true, wanted: true }));
      radios["f4pc7"] = "refuse";                                                            // the admin chooses
      res.edits_refuse = f4ReqEdits(card(undefined));
      res.drawn_again_after_the_choice = f4ReqForm(card(undefined));
      delete radios["f4pc7"];
      const bare = { id: 8, data: { f4_req: true, questions: [] } };
      res.bare = f4ReqForm(bare);
      console.log("RESULT " + JSON.stringify(res));
    """, {"data": data})
    tick = '<input type="checkbox" id="f4rea7" data-keep="f4rea7">'
    for k in ("no_findings", "findings_null", "not_given", "bare"):
        assert "f4rea" not in out[k] and "Ask the REA agent" not in out[k], k                # absent without findings
    assert out["given"].count(tick) == 1 and "checked" not in out["given"]                   # there, and not ticked; no choice made anywhere on the card
    assert '<label class="f" for="f4rea7">Ask the REA agent</label>\n    <div class="why">Why: the REA agent holds findings from the analyzer&#39;s decompiled code.'.replace("&#39;", "'") in out["given"]
    assert "use_rea" not in out["edits_untouched"] and "use_rea" not in out["edits_without_findings"]
    assert out["edits_unticked"]["use_rea"] is False and out["changed_unticked"] is False
    assert out["edits_ticked"]["use_rea"] is True and out["changed_ticked"] is True and out["same_as_sent_before"] is False
    assert '<input type="checkbox" id="f4rea7" data-keep="f4rea7" checked>' in out["drawn_again_after_the_tick"]             # the admin's own tick is kept when the page is drawn again
    assert '<input type="checkbox" id="f4rea7" data-keep="f4rea7" checked>' in out["asked_before"] and "ticked by you before" in out["asked_before"]
    # the changed procedure: two choices, none chosen; the choice is sent only when made
    g = out["given"]
    assert g.count('<input type="radio" name="f4pc7" value="confirm"> Confirm the changed procedure') == 1 and g.count('<input type="radio" name="f4pc7" value="refuse"> This is not what I meant') == 1
    assert "Nothing is chosen for you." in g and "procedure_change" not in out["edits_ticked"] and "f4pc" not in out["bare"]
    assert out["edits_refuse"]["procedure_change"] == "refuse" and 'value="refuse" checked>' in out["drawn_again_after_the_choice"] and 'value="confirm">' in out["drawn_again_after_the_choice"]
    # "Rests on": every requirement that has evidence, with the kind of evidence and the evidence
    assert '<label class="f">Rests on</label>' in g and "(1 requirement, numbered as in the text above)" in g and '<td rowspan="2"><b>R1</b></td>' in g and "<b>R2</b>" not in g
    assert "<td>measured by the data research</td><td>cities.csv column City: 6 of the 6 rows hold a value (counted by the program)</td>" in g and "Rests on" not in out["bare"]
    # the two new kinds of ledger line are named; another kind is left as it is
    assert '<td><div class="muted">Requirement</div>requirement R1</td>' in g and "<td><div class=\"muted\">REA agent (findings from the analyzer&#39;s decompiled code)</div>asked of the REA agent" in g
    assert "<td>the column City</td>" in g


def test_send_my_answers_goes_through_with_the_tick_alone():
    """The page refuses "Send my answers" without an answer or a comment; a changed tick alone goes through, and no words are written for the admin."""
    text = script()
    flow, lib = piece(text, "decide"), piece(text, "rbAct")
    assert 'const tickOnly = dec === "change" && !!(r.data && r.data.f4_req) && f4ReaChanged(r);' in flow
    assert 'if (dec === "change" && !comment.trim() && !b.dataset.recheck && !tickOnly) { msg.innerHTML = `<span class="err">${r.data && r.data.f4_req ? "write your answers first' in flow
    assert 'if (b.dataset.dec === "change" && !comment.trim() && !b.dataset.recheck && !(isReq && f4ReaChanged(rvw))) { $("rbcm-" + id).innerHTML = `<span class="err">${isReq ? "write your answers first' in lib
    assert "was set" not in flow and "was set" not in lib                                     # the comment stays what the admin wrote
    assert flow.index("tickOnly") < flow.index("const edits = editsOf(r, s, b);")             # and the tick itself is sent with the decision (f4ReqEdits: use_rea)


def test_the_code_card_shows_the_recheck_and_the_button_only_when_the_admin_may_ask(tmp_path):
    """The recheck's data in the shape agentic/family4.py gives it (state, sentence, lines, rechecks, most, setting, can_ask); made by hand."""
    out = run_node(tmp_path, F4, r"""
      const card = k => ({ id: 9, data: Object.assign({ f4_trail: [], f4: {} }, k ? { f4_recheck: k } : {}) });
      const ask = `data-act="dec" data-r="9" data-dec="change" data-recheck="1"`;
      console.log("RESULT " + JSON.stringify({ never: f4Trail(card(null), ask),
        agrees: f4Trail(card({ state: "agrees", sentence: "Rechecked by the terminal agent: agrees on all 3 requirements; 1 recheck made of at most 2.", lines: [], rechecks: 1, most: 2, setting: "always", can_ask: false }), ask),
        differs: f4Trail(card({ state: "differs", sentence: "Rechecked by the terminal agent: it differs on R2.", lines: ["only in the recheck's result: [\"Pune\", \"3\"] (rows 1, 2, 4 of the data file)"], can_ask: false }), ask),
        may_ask: f4Trail(card({ state: "not rechecked", sentence: "Not rechecked by the terminal agent: the setting says the recheck by the terminal agent is made only when you ask for it on this card.", lines: [], setting: "ask", can_ask: true }), ask),
        edits: editsOf({ id: 9, data: { f4_open: [{ id: "R1" }] } }, { key: "x:code" }, { dataset: { recheck: "1" } }) }));
    """, {})
    assert out["never"] == ""                                                                # the setting "never": nothing is drawn
    assert '<label class="f">Recheck by the terminal agent</label>' in out["agrees"] and "agrees on all 3 requirements; 1 recheck made of at most 2." in out["agrees"] and "<button" not in out["agrees"]
    assert '<p class="err">Rechecked by the terminal agent: it differs on R2.</p>' in out["differs"] and "<li>only in the recheck&#39;s result: [&quot;Pune&quot;, &quot;3&quot;] (rows 1, 2, 4 of the data file)</li>" in out["differs"]
    assert '<button type="button" class="btn small" data-act="dec" data-r="9" data-dec="change" data-recheck="1">Recheck this code with the terminal agent</button>' in out["may_ask"]
    assert out["edits"] == {"recheck": True}                                                 # a real true, and nothing else
    text = script()
    assert 'if (dec === "change" && !comment.trim() && !b.dataset.recheck && ' in piece(text, "decide")   # it may go with an empty comment
    assert 'const edits = b.dataset.recheck ? { recheck: true } :' in piece(text, "rbAct") and '!comment.trim() && !b.dataset.recheck && ' in piece(text, "rbAct")


def test_the_settings_show_the_present_value_choose_nothing_and_send_only_what_changed(world, tmp_path):
    c = world.c
    c.put("/api/config", json={"stage2": {"search_memory": True}, "tree": {"round_rule": False}, "agentic": {"f4_recheck": "ask"}})
    cfg = c.get("/api/config").get_json()["config"]
    bare = copy.deepcopy(cfg)
    del bare["stage2"]["search_memory"], bare["tree"], bare["agentic"]["f4_recheck"]
    out = run_node(tmp_path, ["esc", "switchSection", "switchChanges"], r"""
      const res = { now: switchSection(ANSWERS.cfg), bare: switchSection(ANSWERS.bare), unread: switchSection(null) };
      res.nothing_drawn = switchChanges();
      els["set-memory"] = { value: "true", dataset: { now: "true" } }; els["set-round"] = { value: "false", dataset: { now: "false" } }; els["set-recheck"] = { value: "ask", dataset: { now: "ask" } };
      res.untouched = switchChanges();
      els["set-round"].value = "true";
      res.one = switchChanges();
      els["set-memory"].value = "false"; els["set-recheck"].value = "never";
      res.three = switchChanges();
      els["set-memory"] = { value: "", dataset: { now: "" } }; els["set-round"] = { value: "", dataset: { now: "" } }; delete els["set-recheck"];
      res.not_set_and_not_chosen = switchChanges();
      els["set-round"].value = "false";
      res.not_set_then_chosen = switchChanges();
      console.log("RESULT " + JSON.stringify(res));
    """, {"cfg": cfg, "bare": bare})
    now = out["now"]
    assert now.count("<select ") == 3 and now.count(" selected>") == 3
    assert '<select id="set-memory" data-now="true"><option value="true" selected>On</option><option value="false">Off</option></select>' in now and "Now: on, as the settings file says." in now
    assert '<select id="set-round" data-now="false"><option value="true">On</option><option value="false" selected>Off</option></select>' in now and "Now: off, as the settings file says." in now
    assert '<select id="set-recheck" data-now="ask"><option value="always">Always, when the terminal agent is ready</option><option value="ask" selected>Only when the admin asks on the code card</option>' \
           '<option value="never">Never</option></select>' in now and "Now: only when the admin asks on the code card, as the settings file says." in now
    assert now.count("A change is saved only when you press Save.") == 3
    # a switch the settings file does not hold: nothing is chosen for the admin; the third one is drawn only when the file has it
    bare_html = out["bare"]
    assert bare_html.count("<select ") == 2 and "set-recheck" not in bare_html
    assert bare_html.count('<option value="" selected>not set in the settings file: nothing is chosen for you</option>') == 2 and bare_html.count(" selected>") == 2
    assert bare_html.count('data-now=""') == 2 and "The settings file holds no value for this switch." in bare_html
    assert out["unread"] == "" and out["nothing_drawn"] is None and out["untouched"] is None and out["not_set_and_not_chosen"] is None
    assert out["one"] == {"tree": {"round_rule": True}} and out["not_set_then_chosen"] == {"tree": {"round_rule": False}}
    assert out["three"] == {"stage2": {"search_memory": False}, "tree": {"round_rule": True}, "agentic": {"f4_recheck": "never"}}
    # what the page sends is what the server takes
    for body in (out["one"], out["three"]):
        assert c.put("/api/config", json=body).status_code == 200
    got = c.get("/api/config").get_json()["config"]
    assert (got["stage2"]["search_memory"], got["tree"]["round_rule"], got["agentic"]["f4_recheck"]) == (False, True, "never")
    c.put("/api/config", json={"stage2": {"search_memory": True}, "agentic": {"f4_recheck": "always"}})
    # the page asks for the settings file, draws the section and sends the changes only on Save
    text = script()
    opened = piece(text, "openSettings")
    assert 'appCfg = (await api("GET", "/api/config")).config;' in opened and opened.count('api("PUT", "/api/config", sw)') == 1
    assert opened.index('api("PUT", "/api/config", sw)') > opened.index('$("set-save").onclick')


def test_the_rules_browser_shows_the_applications_own_lines_behind_the_near_limit_item(tmp_path):
    ev = near_limit.evidence()                                                              # what agentic/rule_evidence.py puts into library_code, read from the file itself
    lc = {"path": ev["code"]["path"], "snippets": ev["code"]["snippets"], "lines": [(x["from"], x["to"]) for x in ev["code"]["snippets"]], "test_in_words": ev["test_in_words"],
          "columns": ev["columns"], "about": "The code of this item calls these lines of the application's own file. They are shown as they are in the file."}
    out = run_node(tmp_path, ["esc", "LEVEL_LABELS", "rbLibraryCode"], r"""
      console.log("RESULT " + JSON.stringify({ shown: rbLibraryCode(ANSWERS.lc), none: rbLibraryCode(null) + rbLibraryCode(undefined) }));
    """, {"lc": lc})
    shown = out["shown"]
    esc = lambda s: str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;")      # noqa: E731
    assert out["none"] == "" and "<code>%s</code>" % esc(lc["path"]) in shown and esc(lc["about"]) in shown
    assert "<b>What these lines test, in words:</b> %s" % esc(ev["test_in_words"]) in shown
    assert len(lc["snippets"]) == 4
    for s in lc["snippets"]:
        assert "The function <code>%s</code> · lines %d to %d of <code>%s</code>" % (s["function"], s["from"], s["to"], esc(lc["path"])) in shown
        first = s["text"].split("\n")[0]
        assert '<span class="ln">%d</span>%s' % (s["from"], esc(first)) in shown and '<span class="ln">%d</span>' % s["to"] in shown
    assert "<th>File the column is in</th><th>Column</th><th>What the column means for this item</th>" in shown
    for col in lc["columns"]:                                                               # no column without its meaning
        assert len(col["use"]) > 10 and "<td><b>%s</b></td><td>%s</td>" % (esc(col["column"]), esc(col["use"])) in shown
    assert "<td>the file of the NVMe commands</td>" in shown and "<td>the file of the NVMe transactions</td>" in shown and "<td>nvme_command</td>" not in shown


def test_the_files_that_were_not_read_as_a_table_are_listed_with_the_servers_sentence():
    text = script()
    page = piece(text, "dataPage")
    assert 'x.ss.find(s => s.key === "director")' in page and "Array.isArray(dirStep.output.refused)" in page
    assert '<div class="file bad">${esc(r.line || `Not read as a table: ${r.name || ""}: ${r.why || ""}`)}</div>' in page
    assert "Files of the folder that were not read as a table (${notRead.length})" in page
    # the sentence the server gives has this form, so the page's own words for an entry without it are the same
    from agentic import family1
    assert family1.refused_line({"name": "notes.csv", "why": "it holds no table."}) == "Not read as a table: notes.csv: it holds no table."
    # the start page's Check: ready for the same list, which the server's answer does not carry yet
    assert "(r.refused || []).map(x => `<div class=\"file bad\">" in piece(text, "checkFolder")
