"""The order of the flow (owner, 2026-11-15): the rule is written (Family 3) -> requirements and code (Family 4) -> the code runs on the
tree -> the Tester checks -> the admin approves the result -> the errors are listed -> each error goes through stage 1 (the isolation of
the defect) -> stage 2 (its cause and its solution) -> its test. "You should not go directly wherever you want."

One whole flow on samples/clean_five_files/S17_io_timeout_abort_reset with the stand-in (no model, no server): the built-in pattern
cmd_timeout and a rule of the admin's own on the NVMe command level ("commands where ST.SCT is 0 and ST.SC is 7": Command Abort Requested;
S17 holds one such Read, row 144 of nvme_command.csv). The fixture stops the flow at each point of the order and writes down what the
application answers there; the tests read what was written down, so they do not depend on each other's order.

Also here: the bridge that files a coded rule's rows as errors of the tree (nvme_hier/coded_findings.py), Tree.columns (the level's
header), and the guard of the page of one error. Everything is written under temporary folders.
"""
import csv
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

import pytest

os.environ.setdefault("F2T_WORKERS", "1")
APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for _p in (APP, os.path.join(APP, "app"), os.path.join(APP, "tests")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from agentic import core, family1, family3, pipeline, procedures as PR      # noqa: E402
from nvme_hier import builder as B, coded_findings as CF, loader as L, rules as RL, terms, tree_api as T   # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NODE = "/home/raghavendra/.nvm/versions/node/v22.23.2/bin/node"
TIMEOUT = "errors/nvme_command/cmd_timeout"
OWN = "errors/nvme_command/aborted_commands"
OWN_WORDS = "commands where ST.SCT is 0 and ST.SC is 7"
ABORTED_ROW = 144                     # the one Read of S17 that completed with status type 0, status code 7 (read from the file below)
LOWER = ["nvme_transaction", "split", "link", "packets"]
pytestmark = pytest.mark.skipif(not os.path.isdir(S17), reason="the S17 sample recording is not on this machine (the code-only zip carries no samples)")


class Yes:
    def random(self):
        return 0.0

    def choice(self, seq):
        return seq[0]

    def sample(self, seq, k):
        return list(seq)[:k]

    def randint(self, _a, b):
        return b


def slow_aborted():
    """The slow recomputation, from the file itself: the rows of nvme_command.csv whose ST.SCT is 0 and ST.SC is 7 (row 1 = first under the header)."""
    with open(os.path.join(S17, "nvme_command.csv"), newline="", encoding="utf-8-sig") as fh:
        rd = csv.reader(fh)
        head = next(rd)
        a, b = head.index("ST.SCT"), head.index("ST.SC")
        return [n for n, row in enumerate(rd, 1) if row[a].strip() == "0" and row[b].strip() == "7"]


def view_of(c, rid):
    return c.get("/api/agents/runs/%d" % rid).get_json()


def drive(c, rid, stop, limit=900):
    """Approve the flow's cards the plain way until stop(step) is true -> (review, step, view)."""
    import fuzz_deep as FD
    t0 = time.time()
    while time.time() - t0 < limit:
        v = view_of(c, rid)
        failed = [(s["key"], (s.get("error") or "")[-800:]) for s in v["steps"] if s["state"] == "failed"]
        assert not failed, failed
        if v["run"]["state"] != "running":
            return None, None, v
        rv = next((q for q in v["reviews"] if q["state"] == "open"), None)
        if rv is None:
            time.sleep(0.2)
            continue
        st = next(s for s in v["steps"] if s["id"] == rv["step"])
        if stop(st):
            return rv, st, v
        if st["key"] == "f3_plan":
            edits = {"selected": [TIMEOUT], "new": [{"section": "errors", "level": "nvme_command", "name": "aborted commands", "description": OWN_WORDS}]}
        elif st["key"].endswith(":result"):
            edits = None
        else:
            edits = FD.edits_for(st["key"], rv.get("data") or {}, Yes())
        assert not (edits or {}).get("go_on_with_open_points")
        r = c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t", "edits": edits})
        assert r.status_code == 200, (st["key"], r.get_json())
    raise AssertionError("the flow did not reach the point in %d s" % limit)


ROUTES = [("GET", ""), ("GET", "/window"), ("POST", "/chat"), ("POST", "/isolate"), ("POST", "/testcase"), ("POST", "/testcase/approve"),
          ("POST", "/signal"), ("POST", "/reorder"), ("POST", "/summary")]


def ask_routes(c, up, fid):
    """Every guarded route of the page of one error -> {route: (status, the error sentence or None)}. The bodies are empty on purpose:
    a route that is let through answers in its own way (200, or its own refusal of an empty request), never with the guard's 409."""
    out = {}
    for method, tail in ROUTES:
        r = c.open("/api/isolate/%s/%d%s" % (up, fid, tail), method=method, json=({} if method == "POST" else None))
        j = r.get_json(silent=True) or {}
        out["%s %s" % (method, tail or "/")] = (r.status_code, j.get("error") if isinstance(j, dict) else None)
    return out


def findings_of(db, like="admin.%"):
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        return con.execute("SELECT id, rule, level, rowid, row_n, cmd_rowid, name, detail FROM finding WHERE rule LIKE ? ORDER BY id", (like,)).fetchall()
    finally:
        con.close()


def page_lists(view, tmp):
    """errorLists(v) and errorsWaiting(v) of the page's own script (app/static/js/agents.js), run by node on a view of the flow."""
    if not os.path.exists(NODE):
        return None
    with open(os.path.join(APP, "app", "static", "js", "agents.js"), encoding="utf-8") as fh:
        text = fh.read()
    part = text[text.index("function errorLists(v) {"):text.index("async function loadErrStatus(v) {")]
    d = tempfile.mkdtemp(prefix="page_", dir=tmp)
    with open(os.path.join(d, "view.json"), "w", encoding="utf-8") as fh:
        json.dump(view, fh)
    with open(os.path.join(d, "h.cjs"), "w", encoding="utf-8") as fh:
        fh.write("const esc = s => String(s ?? '');\nconst plainDefects = (cols, head) => (head || []).map(x => ({ no: x[0], what: x[3], where: '', when: '', sev: x[4], level: x[1], row: x[8] }));\n"
                 + part + "\nconst v = JSON.parse(require('fs').readFileSync(process.argv[2], 'utf8'));\n"
                 "console.log('RESULT ' + JSON.stringify({ lists: errorLists(v).map(s => ({ key: s.key, n: s.output.errors.length, findings: s.output.errors.map(e => e.finding) })), waiting: errorsWaiting(v) }));\n")
    p = subprocess.run([NODE, os.path.join(d, "h.cjs"), os.path.join(d, "view.json")], capture_output=True, text=True, encoding="utf-8", timeout=60)
    line = next((ln for ln in p.stdout.splitlines() if ln.startswith("RESULT ")), None)
    assert line, (p.stdout[-500:], p.stderr[-1500:])
    return json.loads(line[7:])


class FakeStore:
    def __init__(self, state):
        self.state = state

    def one(self, sql, args=()):
        return {"state": self.state, "decided_by": "t"}


class FakeIc:
    """The errors step of the admin's own rule, called again with another result (the step's context made by hand)."""

    def __init__(self, run_out, project, state="approved", item=OWN):
        self.item, self.prefix, self.run, self.project = item, "f3:%s:" % item, {"id": 1}, project
        self.params = {"section": "errors", "level": "nvme_command", "id": item.split("/")[2].split("#")[0]}
        self.engine = type("E", (), {"store": FakeStore(state)})()
        self._out = run_out

    def output_of(self, key):
        return self._out if key == "run" else {}

    def progress(self, text):
        pass


@pytest.fixture(scope="module")
def world():
    import fuzz_app as F
    from api import config_api, hier_api
    root = tempfile.mkdtemp(prefix="flow_order_%d_" % os.getpid())
    kept = (core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK)
    uploads = PR._UPLOADS[0]            # create_app points the uploads folder at the throw-away application: put back for the tests that run after this file
    w = {"root": root}
    try:
        app, c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kept[0]
        family3._SECTIONS_SEEN[0] = None
        pid = c.post("/api/agents/projects", json={"admin": "t", "name": "order", "folder": S17}).get_json()["id"]
        rid = c.post("/api/agents/projects/%d/flow" % pid, json={"admin": "t"}).get_json()["run"]
        step = lambda v, key: next(s for s in v["steps"] if s["key"] == key)                      # noqa: E731

        # ---- point 1: the result of the built-in pattern cmd_timeout waits for the admin
        rv, st, v = drive(c, rid, lambda s: s["key"] == "f3:%s:result" % TIMEOUT)
        up = step(v, "f3:%s:run" % TIMEOUT)["output"]["upload_id"]
        db = PR.source_paths(up)[PR.TREE]
        t_fid = step(v, "f3:%s:run" % TIMEOUT)["output"]["head"][0][0]
        w["p1"] = {"view": v, "routes": ask_routes(c, up, t_fid), "page": page_lists(v, root), "waiting": pipeline.waiting_patterns(v["steps"])}
        assert c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t"}).status_code == 200

        # ---- point 2: the admin's own rule was written, coded, run and checked; its result waits for the admin
        seen = []
        rv, st, v = drive(c, rid, lambda s: seen.append(s["key"]) or s["key"] == "f3:%s:result" % OWN)
        w["p2"] = {"view": v, "card": rv, "cards_before": list(dict.fromkeys(seen)), "routes_timeout": ask_routes(c, up, t_fid), "page": page_lists(v, root),
                   "waiting": pipeline.waiting_patterns(v["steps"]), "findings": findings_of(db), "upload": up, "db": db, "t_fid": t_fid}
        run_out = step(v, "f3:%s:run" % OWN)["output"]
        with open(run_out["output_csv"], newline="", encoding="utf-8") as fh:
            w["p2"]["result_rows"] = list(csv.reader(fh))
        with open(run_out["code_file"], encoding="utf-8") as fh:
            w["p2"]["code"] = fh.read()
        project = {"upload_id": up, "admin": "t", "folder": S17}
        w["p2"]["code_state"] = PR.code_state(family3.load_rule("errors", "nvme_command", "aborted_commands"))
        # the errors step called before the approval files nothing and says why
        early = pipeline._errors(FakeIc(run_out, project, state="needs_review"))
        w["p2"]["early"] = {"output": early.output, "findings": findings_of(db)}
        assert c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t"}).status_code == 200

        # ---- point 3: the errors gate: both patterns' errors are listed; the error of the admin's own rule goes through the stages
        rv, st, v = drive(c, rid, lambda s: s["key"] == "errors_done")
        eo = step(v, "f3:%s:errors" % OWN)
        w["p3"] = {"view": v, "gate": rv, "errors_step": eo, "page": page_lists(v, root), "findings": findings_of(db), "all_findings": len(findings_of(db, "%"))}
        fid = eo["output"]["errors"][0]["finding"]
        base = "/api/isolate/%s/%d" % (up, fid)
        w["p3"]["routes"] = ask_routes(c, up, fid)
        w["p3"]["header"] = c.get(base).get_json()
        iso = c.post(base + "/isolate", json={"n": 15, "m": 15, "levels": LOWER, "history": True, "anyway": True, "isolation": True, "name": "t", "standin": True}).get_json()
        w["p3"]["iso"] = iso
        i = iso["isolation"]
        status = lambda: c.get("/api/dg/status?upload=%s&findings=%d" % (up, fid)).get_json()["status"][str(fid)]     # noqa: E731
        w["p3"]["status_new"] = status()
        d = c.post("/api/dg/defects", json={"name": i["term"]["name"], "term_key": i["term"]["key"], "rule": i["rule"], "level": i["level"], "what": i["what"], "admin": "t"}).get_json()
        occ = c.post("/api/dg/occurrences", json={"defect_id": d["id"], "cause_id": None, "upload_id": up, "finding_id": fid, "device": i.get("device"), "admin": "t"}).get_json()
        w["p3"]["defect"], w["p3"]["status_isolated"] = c.get("/api/dg/defects/%d" % d["id"]).get_json(), status()
        cz = c.post("/api/dg/causes", json={"defect_id": d["id"], "keyword": "host_abort_by_tool_or_test", "admin": "t"}).get_json()
        c.post("/api/dg/occurrences", json={"defect_id": d["id"], "cause_id": cz["id"], "upload_id": up, "finding_id": fid, "admin": "t"})
        w["p3"]["cause"], w["p3"]["status_cause"] = cz, status()
        sol = c.post("/api/dg/solutions", json={"cause_id": cz["id"], "error_seq": iso["sequence"], "optimized": ["do not abort the Read before the drive's usual answer time"],
                                                "admin": "t", "upload_id": up, "finding_id": fid}).get_json()
        w["p3"]["solution"], w["p3"]["status_solved"] = sol, status()
        ex = c.post(base + "/testcase", json={"sequence": iso["sequence"], "expected_after": 3, "name": "t", "standin": True}).get_json()
        f = c.post(base + "/testcase", json={"sequence": ex["sequence"], "expected_outcomes": [dict(x, verified=True) for x in ex.get("expected_outcomes") or []],
                                             "verified": True, "name": "t", "standin": True}).get_json()
        w["p3"]["expected"], w["p3"]["testfile"] = ex, f
        w["p3"]["test_exists"] = bool(f.get("path")) and os.path.exists(f["path"])
        if f.get("path"):
            w["p3"]["approved"] = c.post(base + "/testcase/approve", json={"path": f["path"], "name": "t", "revision_id": sol.get("revision_id")}).get_json()
        w["p3"]["status_tested"] = status()
        w["p3"]["occ"] = occ

        # ---- the same item run again: the errors step with the same result, then with a result that does not name its rows
        again = pipeline._errors(FakeIc(run_out, project))
        w["again"] = {"output": again.output, "findings": findings_of(db), "all_findings": len(findings_of(db, "%"))}
        bad = os.path.join(root, "no_rows.csv")
        with open(bad, "w", newline="", encoding="utf-8") as fh:
            csv.writer(fh).writerows([["ST.SCT", "ST.SC"], ["0", "7"]])
        refused = pipeline._errors(FakeIc(dict(run_out, output_csv=bad, columns=["ST.SCT", "ST.SC"]), project))
        w["refused"] = {"output": refused.output, "findings": findings_of(db)}
        # the detector's own errors step, as before
        w["timeout_errors"] = step(v, "f3:%s:errors" % TIMEOUT)

        # ---- the item is deleted from the rules library: its errors leave the tree at the next sweep (the gate, a plan approval)
        w["before_delete"] = findings_of(db)
        family3.delete_item("errors", "nvme_command", "aborted_commands", "t", "the test deletes it")
        w["swept"] = pipeline.remove_deleted_items_errors(db)
        w["after_delete"] = findings_of(db)
        w["route_after_delete"] = c.get(base).status_code
        family3.restore_item("errors", "nvme_command", "aborted_commands", "t")

        # ---- the end of the flow
        assert c.post("/api/agents/reviews/%d/decide" % rv["id"], json={"decision": "approve", "admin": "t"}).status_code == 200
        _rv, _st, v = drive(c, rid, lambda s: False)
        w["end"] = {"state": v["run"]["state"], "view": v}
        yield w
    finally:
        core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK = kept
        PR.use_uploads_folder(uploads)
        family3._SECTIONS_SEEN[0] = None
        shutil.rmtree(root, ignore_errors=True)


def keys_of(view, item):
    return {s["key"].rsplit(":", 1)[1]: s for s in view["steps"] if s["key"].startswith("f3:%s:" % item)}


# ---------------------------------------------------------------------------------------------- D. the whole flow, in its order
def test_the_sample_holds_the_one_aborted_read():
    assert slow_aborted() == [ABORTED_ROW]


def test_before_the_result_of_the_builtin_pattern_is_approved_nothing_is_listed_and_its_error_page_refuses(world):
    p = world["p1"]
    st = keys_of(p["view"], TIMEOUT)
    assert st["run"]["state"] == "done" and st["run"]["output"]["rows"] >= 2 and st["result"]["state"] == "needs_review"
    assert st["errors"]["state"] == "waiting" and not st["errors"].get("output")
    waits = [x for x in p["waiting"] if x["item"] == TIMEOUT]
    assert len(waits) == 1 and waits[0]["state"] == "waits" and waits[0]["sentence"].startswith("The result of '")
    assert waits[0]["sentence"].endswith("waits for your decision on page 3: its errors are listed here after you approve it.")
    for route, (code, err) in p["routes"].items():
        assert code == 409, (route, code, err)
        assert err.startswith("The result of '") and "waits for your decision on page 3 of the analysis" in err and err.endswith("after you approve that result."), (route, err)
    if p["page"] is not None:               # the page's own script lists nothing, and says why in one sentence
        assert p["page"]["lists"] == []
        assert "waits for your decision on page 3: its errors are listed here after you approve it." in p["page"]["waiting"]


def test_the_admins_own_rule_goes_written_requirements_code_run_tester_result(world):
    p = world["p2"]
    st = keys_of(p["view"], OWN)
    order = [s["key"].rsplit(":", 1)[1] for s in p["view"]["steps"] if s["key"].startswith("f3:%s:" % OWN)]
    assert order == ["write", "research", "req", "code", "run", "test", "export", "result", "errors"], order
    cards = [k.rsplit(":", 1)[1] for k in p["cards_before"] if k.startswith("f3:%s:" % OWN)]
    assert cards == ["write", "req", "code", "result"], cards                      # the admin decided each of them, in this order
    proc = st["write"]["output"]["procedure"]
    assert proc["source_data"] == [{"file": "the tree", "columns": ["nvme_command: ST.SCT", "nvme_command: ST.SC"]}]
    assert proc["output"]["columns"] == [CF.ROW_COLUMN, "ST.SCT", "ST.SC"]
    # the code the Coder wrote became the verified code by the admin's approval of the code card, and that file is the one that ran
    assert st["code"]["state"] == "approved" and st["code"]["output"]["kind"] == "python"
    assert p["code_state"]["kind"] == "python" and p["code_state"]["verified"] is True and p["code_state"]["verified_by"]
    assert st["run"]["output"]["code_file"] == p["code_state"]["path"]
    assert "def run(tree, out_csv):" in p["code"] and "tree.rows(LEVEL)" in p["code"] and PR.check_code(p["code"], tree=True) == []
    run = st["run"]["output"]
    assert st["run"]["state"] == "done" and run["kind"] == "python" and run["rows"] == 1 and run["columns"] == [CF.ROW_COLUMN, "ST.SCT", "ST.SC"]
    assert p["result_rows"] == [[CF.ROW_COLUMN, "ST.SCT", "ST.SC"], [str(ABORTED_ROW), "0", "7"]]
    test = st["test"]["output"]
    assert test["passed"] is True, [x for x in test["checks"] if not x["ok"]]
    assert any(x["check"].startswith("every found row says which row of nvme_command.csv it is") and x["ok"] for x in test["checks"])
    assert st["result"]["state"] == "needs_review" and st["errors"]["state"] == "waiting"
    body = p["card"]["body"]
    assert "Approve to accept it and file the 1 row it found as an error of this recording (nvme_command.csv)" in body
    assert "Nothing is listed before you approve." in body
    assert "the part \"matched the admin's rule 'aborted commands'\" comes from your own rule" in body and "No model names it." in body


def test_before_the_result_of_the_admins_rule_is_approved_no_error_exists_and_nothing_is_listed(world):
    p = world["p2"]
    assert p["findings"] == []                                   # nothing was filed in the tree yet
    waits = {x["item"]: x for x in p["waiting"]}
    assert set(waits) == {OWN} and waits[OWN]["sentence"] == "The result of 'aborted commands' waits for your decision on page 3: its errors are listed here after you approve it."
    # the errors step itself, called too early, files nothing and says the same
    assert p["early"]["output"]["errors"] == [] and p["early"]["findings"] == []
    assert p["early"]["output"]["refused"] == "The result of the rule 'aborted commands' waits for your decision on page 3: its errors are listed here after you approve it."
    if p["page"] is not None:
        assert [x["key"] for x in p["page"]["lists"]] == ["f3:%s:errors" % TIMEOUT]          # the approved pattern is listed, the waiting one is not
        assert "The result of aborted commands waits for your decision on page 3: its errors are listed here after you approve it." in p["page"]["waiting"]
    # the built-in pattern's result is approved by now: its error's page works
    for route, (code, _err) in p["routes_timeout"].items():
        assert code != 409, (route, code)
    assert p["routes_timeout"]["GET /"][0] == 200 and p["routes_timeout"]["GET /window"][0] == 200


def test_after_the_approval_the_row_is_an_error_of_the_tree_and_is_listed(world):
    p = world["p3"]
    eo = p["errors_step"]
    assert eo["state"] == "done" and eo["output"]["kind"] == pipeline.CODED_KIND and eo["output"]["total"] == 1 and not eo["output"].get("refused")
    f = p["findings"]
    assert len(f) == 1
    fid, rule, level, rowid, row_n, cmd_rowid, name, detail = f[0]
    assert rule == "admin.errors.nvme_command.aborted_commands.v%d" % keys_of(p["view"], OWN)["run"]["output"]["procedure_version"] == eo["output"]["rule"]
    assert CF.item_of(rule)[:3] == ("errors", "nvme_command", "aborted_commands")
    assert (level, rowid, cmd_rowid) == ("nvme_command", ABORTED_ROW, ABORTED_ROW) and name == "aborted commands (found by the admin's own rule)"
    assert json.loads(detail)["kind"] == "matched the admin's rule 'aborted commands'" and json.loads(detail)["admin_rule"]["kind_comes_from"] == "the admin's rule"
    e = eo["output"]["errors"]
    assert [(x["finding"], x["level"], x["row"], x["serious"]) for x in e] == [(fid, "nvme_command", ABORTED_ROW, "error")]
    assert e[0]["where"].startswith("row %d of nvme_command.csv" % ABORTED_ROW) and e[0]["what"] == name
    assert "comes from your own rule" in eo["output"]["kind_from"]
    # the gate counts both patterns; the page lists both
    assert p["gate"]["data"]["errors_overview"] and "2 patterns found" in p["gate"]["body"] and "Not listed yet" not in p["gate"]["body"]
    if p["page"] is not None:
        assert sorted(x["key"] for x in p["page"]["lists"]) == sorted(["f3:%s:errors" % TIMEOUT, "f3:%s:errors" % OWN]) and p["page"]["waiting"] == ""
        assert next(x for x in p["page"]["lists"] if x["key"] == "f3:%s:errors" % OWN)["findings"] == [fid]
    for route, (code, _err) in p["routes"].items():
        assert code != 409, (route, code)


def test_stage_1_isolates_it_and_the_fixed_dictionary_names_the_defect(world):
    p = world["p3"]
    h = p["header"]["finding"]
    assert h["level"] == "nvme_command" and h["command"]["rowid"] == ABORTED_ROW and h["signature"]["fields"]["st"] == "sct0.sc07"
    iso = p["iso"]
    i = iso["isolation"]
    assert set("what why when where who which how".split()) <= set(i) and iso["window"]["n"] == 15 and iso["sequence"]
    assert str(i.get("producer") or "").startswith("stand-in")
    term = i["term"]
    want = terms.defect_term(dict(h, detail={"kind": CF.kind_words("aborted_commands")}))
    assert term["key"] == want["key"] and term["name"] == want["name"]
    assert term["name"] == "Read matched the admin's rule 'aborted commands', status Command Abort Requested", term["name"]
    assert term["key"].startswith("admin.errors.nvme_command.aborted_commands.v") and term["key"].endswith("|nvme.sc.0.07") and "|io.read|" in term["key"]
    assert term["slots"]["what"] == "matched the admin's rule 'aborted commands'"
    assert p["status_new"]["state"] == "new" and p["status_isolated"]["state"] == "isolated"
    assert p["defect"]["name"] == term["name"]


def test_stage_2_stores_a_cause_and_a_solution_and_the_test_file_is_written_and_tried(world):
    p = world["p3"]
    assert p["cause"]["id"] and p["status_cause"]["state"] == "cause"
    assert p["solution"]["solution"]["judged_words"] == "not yet judged" and p["status_solved"]["state"] == "solved"
    assert p["expected"]["sequence"] and p["test_exists"], p["testfile"]
    tried = json.dumps(p["testfile"])
    assert "simulated" in tried, tried[:600]                    # the written file was tried on the simulated drive, and the answer says so
    assert p["approved"]["ok"] and p["status_tested"]["state"] == "tested"


def test_running_the_item_again_does_not_double_its_errors(world):
    before, again = world["p3"]["findings"], world["again"]
    assert again["findings"] == before and again["all_findings"] == world["p3"]["all_findings"]
    assert again["output"]["filed"] == {"kept": 1, "added": 0, "removed": 0, "without_a_command": 0}
    assert [x["finding"] for x in again["output"]["errors"]] == [before[0][0]]


def test_a_result_that_does_not_name_its_rows_is_refused_in_words_and_changes_nothing(world):
    r = world["refused"]
    assert r["output"]["errors"] == [] and r["findings"] == world["p3"]["findings"]
    assert r["output"]["refused"].startswith("The result of 'aborted commands' does not say which rows of nvme_command.csv it found: it has no column named \"row number in the file\". "
                                             "No error is listed for it.")


def test_the_detectors_own_pattern_behaves_as_before_in_the_same_flow(world):
    eo = world["timeout_errors"]
    assert eo["state"] == "done" and "kind" not in eo["output"] and eo["output"]["total"] == len(eo["output"]["errors"]) >= 2
    con = sqlite3.connect("file:%s?mode=ro" % world["p2"]["db"], uri=True)
    try:
        want = [r[0] for r in con.execute("SELECT id FROM finding WHERE rule = 'cmd.timeout' ORDER BY id")]
    finally:
        con.close()
    assert sorted(x["finding"] for x in eo["output"]["errors"]) == want and all(x["where"].startswith("row ") for x in eo["output"]["errors"])
    st = keys_of(world["end"]["view"], TIMEOUT)
    assert [st[k]["state"] for k in ("research", "req", "code")] == ["skipped", "skipped", "done"] or st["code"]["output"]["kind"] == "detector"
    assert world["end"]["state"] == "finished"


def test_a_deleted_items_errors_leave_the_tree(world):
    assert len(world["before_delete"]) == 1 and world["swept"] == 1 and world["after_delete"] == []
    assert world["route_after_delete"] == 404                      # the error is gone: its page says "no such finding"


# ---------------------------------------------------------------------------------------------- A. the bridge, alone
@pytest.fixture(scope="module")
def built():
    d = tempfile.mkdtemp(prefix="flow_order_tree_")
    db = os.path.join(d, "hier.sqlite")
    names = {"nvme_command": "nvme_command.csv", "nvme_transaction": "NVME_Transactions.csv", "split": "split.csv", "link": "link.csv", "packets": "packets.csv"}
    L.load_upload(db, {k: os.path.join(S17, n) for k, n in names.items()})
    B.build(db)
    RL.apply(db)
    yield db
    shutil.rmtree(d, ignore_errors=True)


def tree_copy(built, tmp_path):
    p = str(tmp_path / "hier.sqlite")
    a, b = sqlite3.connect(built), sqlite3.connect(p)
    a.backup(b)
    b.close()
    a.close()
    return p


def result_file(tmp_path, rows, head=(CF.ROW_COLUMN, "note"), name="r.csv"):
    p = str(tmp_path / name)
    with open(p, "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows([list(head)] + [list(r) for r in rows])
    return p


def test_the_finding_table_made_here_is_the_detectors(built):
    con = sqlite3.connect(":memory:")
    con.execute(CF.FINDING_DDL)
    mine = [r[1:3] for r in con.execute("PRAGMA table_info(finding)")]
    con.close()
    con = sqlite3.connect("file:%s?mode=ro" % built, uri=True)
    theirs = [r[1:3] for r in con.execute("PRAGMA table_info(finding)")]
    con.close()
    assert mine == theirs


def test_rows_are_filed_once_kept_on_a_second_run_and_replaced_by_a_newer_version(built, tmp_path):
    db = tree_copy(built, tmp_path)
    n0 = len(findings_of(db, "%"))
    got = CF.file_findings(db, "errors", "nvme_command", "my_rule", 1, "my rule", result_file(tmp_path, [(144, "a"), (10, "b"), (300, "c")]))
    assert got == {"rule": "admin.errors.nvme_command.my_rule.v1", "total": 3, "kept": 0, "added": 3, "removed": 0, "without_a_command": 0}
    first = findings_of(db)
    assert [(f[3], f[5], f[2]) for f in first] == [(10, 10, "nvme_command"), (144, 144, "nvme_command"), (300, 300, "nvme_command")]
    assert min(f[0] for f in first) > n0 and len(findings_of(db, "%")) == n0 + 3            # their numbers follow the detector's
    # the same version again, one row gone and one new: the kept ones keep their numbers, nothing is doubled
    got = CF.file_findings(db, "errors", "nvme_command", "my_rule", 1, "my rule", result_file(tmp_path, [(144, "a"), (10, "b"), (7, "d")]))
    assert (got["kept"], got["added"], got["removed"], got["total"]) == (2, 1, 1, 3)
    second = findings_of(db)
    ids = {f[3]: f[0] for f in first}
    assert {f[3]: f[0] for f in second if f[3] in (10, 144)} == {10: ids[10], 144: ids[144]}
    assert next(f[0] for f in second if f[3] == 7) > max(ids.values())                       # a number is never given to another error
    # a newer version replaces every finding of the older one; another item's findings stay
    CF.file_findings(db, "errors", "nvme_command", "my_rule_2", 1, "my rule 2", result_file(tmp_path, [(5, "x")]))
    got = CF.file_findings(db, "errors", "nvme_command", "my_rule", 2, "my rule", result_file(tmp_path, [(144, "a")]))
    assert (got["kept"], got["added"], got["removed"]) == (0, 1, 3)
    assert sorted((f[1], f[3]) for f in findings_of(db)) == [("admin.errors.nvme_command.my_rule.v2", 144), ("admin.errors.nvme_command.my_rule_2.v1", 5)]
    assert CF.filed_items(db) == [("errors", "nvme_command", "my_rule", 2, 1), ("errors", "nvme_command", "my_rule_2", 1, 1)]
    # removed with its item; the detector's findings were never touched
    assert CF.remove(db, "errors", "nvme_command", "my_rule") == 1 and CF.remove(db, "errors", "nvme_command", "my_rule") == 0
    assert [f[1] for f in findings_of(db)] == ["admin.errors.nvme_command.my_rule_2.v1"] and len(findings_of(db, "%")) == n0 + 1
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    a = con.execute("SELECT COUNT(*), SUM(id) FROM finding WHERE rule NOT LIKE 'admin.%'").fetchone()
    con.close()
    con = sqlite3.connect("file:%s?mode=ro" % built, uri=True)
    b = con.execute("SELECT COUNT(*), SUM(id) FROM finding").fetchone()
    con.close()
    assert a == b


@pytest.mark.parametrize("rows,head,words", [
    ([(999999, "x")], None, "names row 999,999 of nvme_command.csv, and the tree has no such row (nvme_command.csv has 608 rows)"),
    ([(-3, "x")], None, "its \"row number in the file\" is \"-3\", and it must be a whole number, 1 or more, written in digits only"),
    ([(0, "x")], None, "its \"row number in the file\" is \"0\", and it must be a whole number"),
    ([("row 12", "x")], None, "its \"row number in the file\" is \"row 12\", and it must be a whole number"),
    ([("1.0", "x")], None, "its \"row number in the file\" is \"1.0\""),
    ([("", "x")], None, "its \"row number in the file\" is empty"),
    ([(10, "x"), (11, "y"), (10, "z")], None, "names row 10 of nvme_command.csv twice (the second time on its line 3)"),
    ([(10, "x")], ("row", "note"), "does not say which rows of nvme_command.csv it found: it has no column named \"row number in the file\""),
    ([(10, 10)], (CF.ROW_COLUMN, CF.ROW_COLUMN), "has more than one column named \"row number in the file\""),
])
def test_a_hostile_result_is_refused_in_one_plain_sentence_and_nothing_is_filed(built, tmp_path, rows, head, words):
    db = tree_copy(built, tmp_path)
    CF.file_findings(db, "errors", "nvme_command", "my_rule", 1, "my rule", result_file(tmp_path, [(144, "a")], name="good.csv"))
    before = findings_of(db, "%")
    with pytest.raises(CF.Refused) as e:
        CF.file_findings(db, "errors", "nvme_command", "my_rule", 1, "my rule", result_file(tmp_path, rows, head or (CF.ROW_COLUMN, "note")))
    assert words in str(e.value) and "No error is listed for" in str(e.value), str(e.value)
    assert findings_of(db, "%") == before                       # what was filed before stays as it was


def test_a_row_below_the_command_level_is_filed_with_the_command_it_belongs_to(built, tmp_path):
    db = tree_copy(built, tmp_path)
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    inside = con.execute("SELECT rowid_file, parent FROM ntx WHERE parent IS NOT NULL ORDER BY rowid_file LIMIT 1").fetchone()
    outside = con.execute("SELECT rowid_file FROM ntx WHERE parent IS NULL ORDER BY rowid_file LIMIT 1").fetchone()
    con.close()
    rows = [(inside[0], "a")] + ([(outside[0], "b")] if outside else [])
    got = CF.file_findings(db, "errors", "nvme_transaction", "odd_transactions", 3, "odd transactions", result_file(tmp_path, rows))
    assert got["total"] == len(rows) and got["without_a_command"] == (1 if outside else 0)
    by_row = {f[3]: f for f in findings_of(db)}
    assert by_row[inside[0]][5] == inside[1] and by_row[inside[0]][2] == "nvme_transaction"
    if outside:
        assert by_row[outside[0]][5] is None
    assert "no command to build the window" in CF.CANNOT_DO


def test_the_requirement_is_said_in_words_and_checked_on_the_procedure():
    words = CF.requirement_words("nvme_command")
    assert "a column named exactly \"row number in the file\"" in words and "nvme_command.csv" in words and "no row twice" in words
    r = {"name": "aborted commands", "section": "errors", "level": "nvme_command", "id": "x", "kind": None}
    good = PR.standin_tree_rows("nvme_command", [("ST.SCT", "0"), ("ST.SC", "7")])
    assert family3.errors_of_the_tree(r) and family3.tree_rows_problem(r, good) == ""
    no_col = dict(good, output={"columns": ["ST.SCT"], "order": ""})
    assert "does not say which rows of nvme_command.csv it found" in family3.tree_rows_problem(r, no_col)
    on_file = dict(good, source_data=[{"file": "nvme_command.csv", "columns": ["ST.SC"]}])
    assert "reads nvme_command.csv itself, not the tree" in family3.tree_rows_problem(r, on_file)
    # not asked of the detector's items, of analytics, or of a file that is not part of the tree
    assert not family3.errors_of_the_tree({"section": "errors", "level": "nvme_command", "id": "cmd_timeout", "kind": "detection_rule", "plan": {"rule": "cmd.timeout"}})
    assert not family3.errors_of_the_tree(dict(r, section="analytics")) and not family3.errors_of_the_tree(dict(r, level="other"))
    assert PR.check_code(PR.standin_share_code(good), tree=True) == []
    assert CF.rule_key("errors", "nvme_command", "x", 4) == "admin.errors.nvme_command.x.v4" and CF.item_of("admin.errors.nvme_command.x.v4") == ("errors", "nvme_command", "x", 4)
    assert CF.item_of("cmd.timeout") is None and not CF.is_coded("cmd.timeout")


# ---------------------------------------------------------------------------------------------- C. Tree.columns is the level's header
def file_header(name):
    with open(os.path.join(S17, name), newline="", encoding="utf-8-sig") as fh:
        return next(csv.reader(fh))


def test_columns_gives_the_levels_header_also_for_cells_the_first_row_leaves_empty(built, tmp_path):
    t = T.Tree(built)
    try:
        cols = t.columns("nvme_command")
        first = t._first_keys("nvme_command")
        assert "NLB" in cols and "NLB" not in first                 # the first command is an admin command: it has no block count
        assert set(first) <= set(cols) and len(cols) > len(first) and len(set(cols)) == len(cols)
        named = [h.strip() for h in file_header("nvme_command.csv") if h.strip()]
        assert [c for c in cols if c in set(named)] == [h for h in dict.fromkeys(named) if h in set(cols)]       # the file's order
        # the loader stores the header at the load (nvme_hier/loader.py store_header); a tree loaded before that reads it from the file: tests/test_join_header.py
        assert t.columns_from("nvme_command") == "the header stored with the tree"
        assert t.column_state("nvme_command", "NLB") == T.FILLED == "filled"
        empty = next(c for c in cols if t.column_state("nvme_command", c) == T.EMPTY)
        assert T.EMPTY == "in the file, empty in every row" and empty in cols
        con = sqlite3.connect("file:%s?mode=ro" % built, uri=True)
        assert con.execute("SELECT COUNT(*) FROM cmd WHERE json_extract(raw, ?) IS NOT NULL", ("$." + json.dumps(empty),)).fetchone()[0] == 0
        con.close()
        assert t.column_state("nvme_command", "no such column") == T.MISSING == "not in the file"
        assert PR.tree_column_state(built, "nvme_command", empty) == "in the file, empty in every row"
        with pytest.raises(ValueError):
            t.columns("no_such_level")
    finally:
        t.close()
    # a level that is not in this tree
    db = str(tmp_path / "two.sqlite")
    L.load_upload(db, {"nvme_command": os.path.join(S17, "nvme_command.csv")})
    t = T.Tree(db)
    try:
        with pytest.raises(T.NotInTree):
            t.columns("packets")
        with pytest.raises(T.NotInTree):
            t.column_state("packets", "x")
        assert "NLB" in t.columns("nvme_command")
    finally:
        t.close()


def test_the_header_is_stored_with_the_tree_and_read_without_the_file(built, tmp_path):
    db = tree_copy(built, tmp_path)
    t = T.Tree(db)
    want = {lv: t.columns(lv) for lv in T.LEVELS}
    t.close()
    stored = T.store_headers(db)
    assert stored == {lv: len([c for c in want[lv] if not T.SPACER.match(c)]) for lv in T.LEVELS}
    # the file is "gone" (its path in the load report is changed): the stored header answers, with the same columns
    con = sqlite3.connect(db)
    rep = json.loads(con.execute("SELECT v FROM meta WHERE k='load_reports'").fetchone()[0])
    for lv in rep:
        rep[lv]["path"] = os.path.join(str(tmp_path), "not_there", os.path.basename(rep[lv]["path"]))
    con.execute("UPDATE meta SET v=? WHERE k='load_reports'", (json.dumps(rep),))
    con.commit()
    con.close()
    t = T.Tree(db)
    try:
        assert {lv: t.columns(lv) for lv in T.LEVELS} == want and t.columns_from("nvme_command") == "the header stored with the tree"
    finally:
        t.close()
    # neither the stored header nor the file: the columns some row fills, and the tree says so
    con = sqlite3.connect(db)
    con.execute("DELETE FROM meta WHERE k=?", (T.HEADERS_KEY,))
    con.commit()
    con.close()
    t = T.Tree(db)
    try:
        cols = t.columns("nvme_command")
        assert "NLB" in cols and set(t._first_keys("nvme_command")) <= set(cols) and set(cols) < set(want["nvme_command"])
        assert "a column empty in every row is not listed" in t.columns_from("nvme_command")
    finally:
        t.close()


def test_the_near_limit_sentence_about_nlb_is_no_longer_true(built):
    """nvme_hier/near_limit.py says NLB "is not one of the tree's named columns": since Tree.columns gives the header, it is one. The file
    is another builder's: this test only writes the fact down (it is skipped once that sentence is corrected there)."""
    from nvme_hier import near_limit as NL
    t = T.Tree(built)
    try:
        assert "NLB" in t.columns("nvme_command")
    finally:
        t.close()
    text = json.dumps(NL.PROCEDURE)
    if "it is not one of the tree's named columns" not in text:
        pytest.skip("the sentence was corrected in nvme_hier/near_limit.py")


# ---------------------------------------------------------------------------------------------- B. the guard, alone
def test_the_guard_reads_the_flows_records_and_lets_a_recording_without_a_flow_through(built, tmp_path):
    root = str(tmp_path)
    os.makedirs(os.path.join(root, "db"))
    services = type("S", (), {"root": root, "agentic_engine": None})()
    assert pipeline.error_page_refusal(services, "up-x", built, 1) == ""            # no analysis was ever started
    store = core.Store(os.path.join(root, "db", "agentic.sqlite"))
    pid = store.exec("INSERT INTO project (admin, name, folder, refs, upload_id, created, updated) VALUES ('t','my analysis','/x','[]','up-x',0,0)")
    rid = store.exec("INSERT INTO run (project, kind, target, params, state, created, updated) VALUES (?, 'flow', '', '{}', 'running', 0, 0)", (pid,))
    con = sqlite3.connect("file:%s?mode=ro" % built, uri=True)
    fid = con.execute("SELECT id FROM finding WHERE rule='cmd.timeout' ORDER BY id LIMIT 1").fetchone()[0]
    other = con.execute("SELECT id FROM finding WHERE rule!='cmd.timeout' ORDER BY id LIMIT 1").fetchone()
    con.close()
    family3.tree()
    assert pipeline.error_page_refusal(services, "up-x", built, fid) == ""          # the flow does not hold the pattern (yet)
    sid = store.exec("INSERT INTO step (run, idx, key, title, family, agent, state, needs_review) VALUES (?, 5, ?, ?, '3', 'Manager', 'waiting', 1)",
                     (rid, "f3:%s:result" % TIMEOUT, "NVMe command timed out · the result, for your review"))
    assert pipeline.error_page_refusal(services, "up-x", built, fid) == (
        "The rule 'NVMe command timed out' has not reached its result yet in the analysis “my analysis” (page 3 shows where it stands): this error can be "
        "opened and worked on after you approve that result.")
    store.exec("UPDATE step SET state='needs_review' WHERE id=?", (sid,))
    assert pipeline.error_page_refusal(services, "up-x", built, fid) == (
        "The result of 'NVMe command timed out' waits for your decision on page 3 of the analysis “my analysis”: this error can be opened and worked on "
        "(stage 1, stage 2 and its test) after you approve that result.")
    assert pipeline.error_page_refusal(services, "another-upload", built, fid) == ""     # another recording's flow says nothing here
    if other:
        assert pipeline.error_page_refusal(services, "up-x", built, other[0]) == ""      # an error of a pattern this analysis does not hold
    assert pipeline.error_page_refusal(services, "up-x", built, 10 ** 9) == ""           # no such finding: the route answers that itself
    store.exec("UPDATE step SET state='approved' WHERE id=?", (sid,))
    assert pipeline.error_page_refusal(services, "up-x", built, fid) == ""               # approved: as before
    # a second round whose result waits does not close the page again: the first round's result was approved
    store.exec("INSERT INTO step (run, idx, key, title, family, agent, state, needs_review) VALUES (?, 9, ?, 'x · the result', '3', 'Manager', 'needs_review', 1)",
               (rid, "f3:%s#2:result" % TIMEOUT))
    assert pipeline.error_page_refusal(services, "up-x", built, fid) == ""


def test_the_pages_script_compiles():
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    d = tempfile.mkdtemp(prefix="agents_js_")
    try:
        shutil.copy(os.path.join(APP, "app", "static", "js", "agents.js"), os.path.join(d, "agents.cjs"))
        p = subprocess.run([NODE, "--check", os.path.join(d, "agents.cjs")], capture_output=True, text=True, timeout=60)
        assert p.returncode == 0, p.stderr[-800:]
    finally:
        shutil.rmtree(d, ignore_errors=True)
