"""A CSV file that is not written in the plain form (comma, UTF-8, header on line 1) is read rightly by EVERY reader of the
agent families, not only by Family 1 (2026-11-15).

One recording is written three ways with the same data: plain (comma, UTF-8, header on line 1), with semicolons and a title
line above the header, and the semicolon form in UTF-16. It has a column of decimal commas ("12,50"), a unit in a header
("Latency [ms]") and a column whose numbers cannot be told ("1,024": 1.024 or 1024). What must hold:

  1. each reader gives on the semicolon file, and on the UTF-16 file, what it gives on the plain file: the Coder's column
     facts, the records shown on a page, the sample copy (written in the file's own form), the Coder's FILES, the data
     research's one pass and its row count, the terminal agent's table of files, the start page's tool check, Family 4's
     header reading and the task of the re-check;
  2. the decimal-comma column is counted as numbers; a value of the column that cannot be told is never counted as a number;
  3. a file that is no table is said in plain words by each reader, and nothing crashes;
  4. a whole flow with the stand-in on the semicolon file (Family 1's dictionary, an analytics item and an errors item,
     Family 4's research, requirements and code, the result counted from the file) equals the same flow on the plain file.

No server, no model, no terminal agent. Run as a script it is the flow of point 4:
    python3 tests/test_form_in_every_reader.py flow <an empty folder> semicolon|comma   -> one JSON line at the end"""
import csv
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

NAME = "bench_log.csv"
TITLE = "Bench report of drive D"
HEADER = ["Command", "Queue", "Latency [ms]", "Result", "Blocks"]
N = 120
OTHERS = ("semicolon", "utf16")


def rows_of(n=N):
    """The same records for every form. Latency is written with a decimal comma; Blocks with one comma and three digits."""
    for i in range(1, n + 1):
        cents = (i * 733) % 90000 + 5
        yield [("Read", "Read", "Write", "Flush", "Read", "Write")[i % 6], str(i % 4 + 1), "%d,%02d" % (cents // 100, cents % 100),
               "timeout" if i % 20 == 1 else "ok", "%d,%03d" % (i % 7 + 1, (i * 8) % 1000)]


def latencies(n=N):
    return [float(r[2].replace(",", ".")) for r in rows_of(n)]


def write(folder, form, name=NAME, n=N):
    """The recording in one form -> its path. comma: the plain form; semicolon: a title line, then semicolons; utf16: the
    semicolon form in UTF-16 with a byte order mark."""
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, name)
    if form == "comma":
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(HEADER)
            w.writerows(rows_of(n))
        return path
    text = TITLE + "\r\n" + ";".join(HEADER) + "\r\n" + "".join(";".join(r) + "\r\n" for r in rows_of(n))
    with open(path, "wb") as fb:
        fb.write(text.encode("utf-8") if form == "semicolon" else text.encode("utf-16"))
    return path


def not_a_table(folder, name="notes.csv"):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, name)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("".join("line %d of some notes without any cells\n" % i for i in range(1, 30)))
    return path


def three(tmp_path):
    return {form: write(str(tmp_path / form), form) for form in ("comma",) + OTHERS}


# ------------------------------------------------------------------------------------------- 1. the readers of procedures.py
def test_the_three_files_are_what_they_are_meant_to_be(tmp_path):
    from agentic import csv_dialect as CD
    p = three(tmp_path)
    plain, semi, u16 = (CD.detect(p[k]) for k in ("comma", "semicolon", "utf16"))
    assert plain["as_before"] is True and plain["refused"] is None
    assert (semi["separator"], semi["header_line"], semi["codec"], semi["lines_before"]) == (";", 2, "utf-8-sig", [TITLE])
    assert (u16["separator"], u16["header_line"], u16["codec"], u16["lines_before"]) == (";", 2, "utf-16-le", [TITLE])


def test_the_coders_column_facts_are_the_same_in_every_form(tmp_path):
    from agentic import procedures as PR
    p = three(tmp_path)
    names = HEADER + ["Nowhere"]
    plain = PR.columns_info(p["comma"], names)
    assert [plain[c]["position"] for c in names] == [0, 1, 2, 3, 4, None] and plain["_rows_scanned"] == N and plain["_header_cells"] == 5
    assert "_written_as" not in plain and "_error" not in plain
    assert plain["Latency [ms]"]["number_style"]["style"] == "decimal comma" and plain["Latency [ms]"]["number_style"]["read_as_a_number"] is True
    assert plain["Latency [ms]"]["number_style"]["decimal_sign"] == "," and plain["Latency [ms]"]["rows_with_value"] == N
    assert plain["Blocks"]["number_style"]["style"] == "ambiguous" and plain["Blocks"]["number_style"]["read_as_a_number"] is False
    assert "number_style" not in plain["Queue"] and "number_style" not in plain["Command"]
    for form in OTHERS:
        got = PR.columns_info(p[form], names)
        w = got.pop("_written_as")
        assert got == plain, form
        assert w["separator"] == {"value": ";", "name": "semicolon", "decided": True} and w["header"]["line"] == 2 and w["header"]["first_record_line"] == 3
        assert w["header"]["lines_before"] == [TITLE] and w["encoding"]["codec"] == ("utf-8-sig" if form == "semicolon" else "utf-16-le")
        assert w["text"].startswith("Written as UTF-") and "semicolon" in w["text"] and "header on line 2" in w["text"]


def test_the_records_shown_on_a_page_are_the_same_and_keep_the_files_own_line_numbers(tmp_path):
    from agentic import procedures as PR
    p = three(tmp_path)
    plain = PR.sample_rows(p["comma"], None, 2, 7)
    assert plain["header"] == ["line"] + HEADER and [r[0] for r in plain["rows"]] == list(range(2, 9)) and plain["next_line"] == 9 and "written_as" not in plain
    assert [r[1:] for r in plain["rows"]] == list(rows_of(7))
    for form in OTHERS:
        got = PR.sample_rows(p[form], None, 2, 7)                # asked from line 2 on: the first record of this file is on line 3
        assert got["header"] == plain["header"] and [r[1:] for r in got["rows"]] == [r[1:] for r in plain["rows"]], form
        assert [r[0] for r in got["rows"]] == list(range(3, 10)) and got["next_line"] == 10 and got["header_line"] == 2
        assert "semicolon" in got["written_as"] and "header on line 2" in got["written_as"]
        more, more_plain = PR.sample_rows(p[form], ["Result", "Latency [ms]"], got["next_line"], 5), PR.sample_rows(p["comma"], ["Result", "Latency [ms]"], plain["next_line"], 5)
        assert [r[1:] for r in more["rows"]] == [r[1:] for r in more_plain["rows"]] and [r[0] - 1 for r in more["rows"]] == [r[0] for r in more_plain["rows"]]
        end = PR.sample_rows(p[form], ["Command"], N + 2, 5)       # the last record is on line N + 2 of this file
        assert [r[0] for r in end["rows"]] == [N + 2] and end["next_line"] is None


def test_the_sample_copy_is_written_in_the_files_own_form(tmp_path):
    from agentic import csv_dialect as CD, procedures as PR, f4_research as RS
    p = three(tmp_path)
    out = PR.sample_sources({NAME: p["comma"]}, str(tmp_path / "box_comma"), records=10)
    with open(out[NAME], "rb") as fb:
        raw = fb.read()
    assert raw.startswith(b"Command,Queue,Latency [ms],Result,Blocks\r\n") and CD.detect(out[NAME])["as_before"] is True and RS.count_rows(out[NAME]) == 10
    plain_rows = CD.sniff(out[NAME], 50)[:2]
    for form in OTHERS:
        out = PR.sample_sources({NAME: p[form]}, str(tmp_path / ("box_" + form)), records=10)
        real, copy = CD.detect(p[form]), CD.detect(out[NAME])
        for k in ("codec", "bom_bytes", "separator", "separator_decided", "header_line", "lines_before", "encoding"):
            assert copy[k] == real[k], (form, k)
        assert tuple(CD.sniff(out[NAME], 50)[:2]) == tuple(plain_rows), form            # the same header and the same ten records
        with open(out[NAME], "rb") as fb, open(p[form], "rb") as fr:
            head = fb.read(60)
            assert head == fr.read(60), form                                              # byte for byte the same start: mark, title line, header


def test_the_coders_files_carry_the_form_per_file_and_the_number_style_per_column(tmp_path, monkeypatch):
    from agentic import family1, procedures as PR
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path / "knowledge"))
    p = three(tmp_path)
    proc = {"version": 1, "source_data": [{"file": NAME, "columns": ["Command", "Latency [ms]", "Blocks"]}], "steps": ["Count."], "output": {"columns": ["Command", "count", "percent"]}}
    r = {"id": "x", "name": "share"}
    plain = PR.coder_context(r, proc, None, paths={NAME: p["comma"]})["FILES"][0]
    assert "written_as" not in plain and "not_read" not in plain and [c["position"] for c in plain["COLUMNS"]] == [0, 2, 4]
    assert [c.get("number_style", {}).get("style") for c in plain["COLUMNS"]] == [None, "decimal comma", "ambiguous"]
    for form in OTHERS:
        got = PR.coder_context(r, proc, None, paths={NAME: p[form]})["FILES"][0]
        assert got["COLUMNS"] == plain["COLUMNS"] and got["header_cells"] == plain["header_cells"] and got["rows_scanned_for_samples"] == N, form
        w = got["written_as"]
        assert w["separator"]["value"] == ";" and w["header"]["line"] == 2 and w["encoding"]["codec"] == ("utf-8-sig" if form == "semicolon" else "utf-16-le")
        # the stand-in Coder's code for this procedure opens the file as it is written, and counts what the plain file's code counts
        code = PR.standin_share_code({"source_data": [{"file": NAME, "columns": ["Command"]}], "output": {"columns": ["Command", "count", "percent"]}, "steps": []},
                                     PR.forms_of({"source_data": [{"file": NAME}]}, {NAME: p[form]}))
        assert PR.check_code(code) == []
        assert _run(code, p[form], tmp_path / ("out_%s.csv" % form)) == _run(PR.standin_share_code(
            {"source_data": [{"file": NAME, "columns": ["Command"]}], "output": {"columns": ["Command", "count", "percent"]}, "steps": []}, {}), p["comma"], tmp_path / "out_plain.csv")
    # the instruction says how such a file is opened, and that a column that could not be told is not read as a number
    for words in ("written_as.encoding.codec", "written_as.separator.value", "written_as.header.line", '"ambiguous" or "mixed"', "must NOT be read as a number", '"\\ufeff"'):
        assert words in PR.CODER_INSTRUCTION, words


def _run(code, path, out_csv):
    ns = {}
    exec(compile(code, "standin", "exec"), ns)
    res = ns["run"]({NAME: path}, str(out_csv))
    with open(str(out_csv), newline="", encoding="utf-8") as fh:
        return res, list(csv.reader(fh))


# ------------------------------------------------------------------------------------------- 2. the data research of Family 4
def _block(m, column, shift=0):
    """One column's measured block with the line numbers moved back by `shift` (the lines above the header of that file)."""
    b = json.loads(json.dumps(m["columns"][column].block(m["rows"], m["basis"])))       # a copy: the column's own lists are not touched
    for x in b["nothing"]:
        x["first_lines"] = [n - shift for n in x["first_lines"]]
    for x in b["sample_rows"]:
        x["line"] -= shift
    return b


def test_the_data_research_counts_the_same_in_every_form_and_reads_a_decimal_comma_as_a_number(tmp_path):
    from agentic import f4_research as RS
    p = three(tmp_path)
    plain = RS.measure(p["comma"], HEADER)
    assert plain["rows"] == N and plain["basis"] == "exact: all %d rows" % N and plain["header"] == HEADER and plain["file_written_as"] is None
    lat, blocks, queue = _block(plain, "Latency [ms]"), _block(plain, "Blocks"), _block(plain, "Queue")
    # the decimal-comma column is counted as numbers, with its real smallest and largest value
    assert lat["numbers"] == N and lat["not_numbers"] == 0 and lat["written_as"] == {"decimal comma": N} and lat["read_as_numbers"] is True
    assert lat["range"] == [min(latencies()), max(latencies())] and lat["number_style"]["style"] == "decimal comma" and lat["number_style"]["decimal_sign"] == ","
    assert lat["sample_rows"][0] == {"line": 2, "value": next(rows_of())[2]}
    # the column that cannot be told ("1,024" is 1.024 or 1024): no value is counted as a number, no range is given, and it is said
    assert blocks["numbers"] == 0 and blocks["not_numbers"] == N and blocks["range"] is None and blocks["read_as_numbers"] is False
    assert blocks["number_style"]["style"] == "ambiguous" and blocks["written_as"] == {"text": N} and blocks["values_not_read_as_numbers_for_that"] == N
    assert "number_style" not in queue and queue["numbers"] == N and queue["range"] == [1.0, 4.0]
    record = {"files": [{"file": NAME, "touched": [dict(b, file=NAME) for b in (lat, blocks, queue)]}], "links": [], "words": []}
    sur = RS.surprises_of(record)
    assert any("Latency [ms]: the numbers are written with a decimal comma" in s for s in sur), sur
    assert any("Blocks" in s and "not read as a number" in s and "decimal sign" in s for s in sur), sur
    hid = RS.hidden_decisions(record["files"][0]["touched"], [], [], "", {"steps": [], "output": {}})
    assert [h["kind"] for h in hid if "Blocks" in h["decision"]] == ["numbers that cannot be read for sure"]
    assert RS.count_rows(p["comma"]) == N
    for form in OTHERS:
        m = RS.measure(p[form], HEADER)
        assert (m["rows"], m["basis"], m["header"], m["absent"]) == (plain["rows"], plain["basis"], plain["header"], plain["absent"]), form
        assert m["file_written_as"]["separator"]["value"] == ";" and m["file_written_as"]["header"]["line"] == 2
        for c in HEADER:
            assert _block(m, c, shift=1) == _block(plain, c), (form, c)
        assert m["columns"]["Latency [ms]"].block(m["rows"], m["basis"])["sample_rows"][0]["line"] == 3      # the file's own line: title, header, first record
        assert RS.count_rows(p[form]) == N                                                               # the title line and the header are no rows


class _Runner:
    def ask(self, run, step, instruction, context, shape, key, standin):
        return standin(), "stand-in", None


class _Ctx:
    run = {"id": 1}

    class engine:               # noqa: N801 - a stand-in for the engine: only its runner is used
        runner = _Runner()

    def progress(self, *_a, **_k):
        pass


def _record(path, monkeypatch):
    from agentic import f4_research as RS
    monkeypatch.setattr(RS, "admin_items", lambda ctx, r, proc: [])
    proc = {"version": 1, "source_data": [{"file": NAME, "columns": ["Command", "Latency [ms]", "Blocks"]}], "steps": ["Count the rows of each Command."],
            "output": {"columns": ["Command", "count"], "order": "count, largest first; then Command"}}
    r = {"id": "x", "name": "share", "section": "analytics", "level": "other", "description": "count by Command"}
    rec = RS.build(_Ctx(), r, proc, {"paths": {NAME: path}, "dicts": {}, "on_tree": False, "headers": {}})
    return rec, RS.brief_for_agents(rec)


def test_the_research_record_and_its_files_for_the_coder_carry_the_files_form(tmp_path, monkeypatch):
    p = three(tmp_path)
    plain, plain_brief = _record(p["comma"], monkeypatch)
    assert "file_written_as" not in plain["files"][0] and "HOW_THE_FILE_IS_WRITTEN" not in plain_brief["FILES"][0]
    for form in OTHERS:
        rec, brief = _record(p[form], monkeypatch)
        f = rec["files"][0]
        assert f["rows"] == N and f["basis"] == plain["files"][0]["basis"] and f["header_cells"] == 5
        assert f["file_written_as"]["separator"]["name"] == "semicolon" and f["file_written_as"]["header"]["lines_before"] == [TITLE]
        # a column's own "written_as" is still the kinds of value it holds (every consumer of that key reads what it read before)
        assert [b["written_as"] for b in f["touched"]] == [b["written_as"] for b in plain["files"][0]["touched"]] == [{"text": N}, {"decimal comma": N}, {"text": N}]
        assert [(h["kind"], h["decision"]) for h in rec["hidden"]] == [(h["kind"], h["decision"]) for h in plain["hidden"]]
        assert [s.replace("line 3", "line 2") for s in rec["surprises"]] == plain["surprises"]
        how = brief["FILES"][0]["HOW_THE_FILE_IS_WRITTEN"]
        assert how["separator"]["value"] == ";" and how["header"]["line"] == 2 and how["encoding"]["codec"] == ("utf-8-sig" if form == "semicolon" else "utf-16-le")
        assert brief["FILES"][0]["rows"] == N


# ------------------------------------------------------------------------------------------- 3. the terminal agent, the start page
class _Store:
    def one(self, *_a, **_k):
        return None

    def all(self, *_a, **_k):
        return []


class _Engine:
    store = _Store()

    def __init__(self, root):
        self.runner = type("R", (), {"sandbox_root": root})()


def _analysis(tmp_path, form, pid):
    from agentic import investigate as IV
    folder = os.path.dirname(write(str(tmp_path / ("folder_" + form)), form))
    not_a_table(folder)
    box, files = IV.prepare(_Engine(str(tmp_path / "boxes")), {"id": pid, "name": form, "folder": folder})
    with open(os.path.join(box, "ANALYSIS.md"), encoding="utf-8") as fh:
        return fh.read(), files


def test_the_terminal_agents_table_of_files_says_how_each_file_is_written(tmp_path, monkeypatch):
    from agentic import family1, investigate as IV
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path / "knowledge"))
    text, files = _analysis(tmp_path, "comma", 1)
    row = next(ln for ln in text.splitlines() if ln.startswith("| `%s`" % NAME))
    assert "| File | Size | Columns | What it is | How it is written | Dictionary |" in text
    assert "| 5 |" in row and "| %s |" % IV.PLAIN_FORM in row and "### Files that are not written in the plain form" not in text
    assert [f["name"] for f in files] == [NAME]
    # the file that is no table is listed with its reason, in both analyses
    assert "### Files that were not read as a table" in text and "Not read as a table: notes.csv: notes.csv cannot be read as a table" in text
    for n, form in enumerate(OTHERS):
        text, files = _analysis(tmp_path, form, 2 + n)
        other = next(ln for ln in text.splitlines() if ln.startswith("| `%s`" % NAME))
        assert "| 5 |" in other and "cells separated by a semicolon, header on line 2 (1 line above it is not part of the table)" in other, other
        assert other.split("|")[3:5] == row.split("|")[3:5]                                # the same columns and the same kind of file as the plain one
        codec = "utf-8-sig" if form == "semicolon" else "utf-16-le"
        assert "### Files that are not written in the plain form" in text
        assert '- `%s`: open it with `open(path, newline="", encoding="%s", errors="replace")`, read and drop 1 line with `fh.readline()` (the header is line 2, the first record line 3)' % (NAME, codec) in text
        assert 'read it with `csv.reader(fh, delimiter=";")`' in text and "word for word: `%s`" % TITLE in text
        assert ("byte order mark" in text) == (form == "utf16")
        assert "Not read as a table: notes.csv" in text
    # a dictionary as the agent reads it keeps the file's form and each column's number style
    d = {"file": NAME, "columns": [{"column": "Latency [ms]", "number_style": {"style": "decimal comma", "how": "decimal comma: counted"}}, {"column": "Queue"}],
         "written_as": family1.inventory(str(tmp_path / "folder_semicolon"))[0]["written_as"]}
    dig = IV._digest(d)
    assert dig["written_as"]["separator"] == ";" and dig["written_as"]["header_line"] == 2 and dig["written_as"]["encoding_for_open"] == "utf-8-sig"
    assert dig["columns"][0]["number_style"] == "decimal comma: counted" and "number_style" not in dig["columns"][1]
    assert "written_as" not in IV._digest({"file": NAME, "columns": [{"column": "Queue"}]})
    from agentic import prompts
    assert "Open each file as the table of files in `ANALYSIS.md` says" in prompts.load("investigation")


def test_the_start_pages_tool_check_reads_the_header_in_the_files_own_form(tmp_path):
    from agentic import family1, source_tools as ST
    from api import agentic_api as A
    tool = next(t["key"] for t in ST.tools() if t["available"])
    folders = {form: os.path.dirname(write(str(tmp_path / form), form)) for form in ("comma",) + OTHERS}
    plain = A._tool_check(tool, family1.inventory(folders["comma"]))
    assert plain and plain["files"][0]["names"] == 5 and plain["files"][0]["looks"] is False
    for form in OTHERS:
        got = A._tool_check(tool, family1.inventory(folders[form]))
        assert got == plain, form                # judged by its five real column names, not by one cell that holds the whole line
    # a file whose header cannot be read is said to be not compared; nothing is guessed
    bad = A._tool_check(tool, [{"name": "notes.csv", "path": not_a_table(str(tmp_path / "bad")), "level": None}])
    assert bad["files"][0]["looks"] is None and "was not compared" in bad["files"][0]["sentence"]


# ------------------------------------------------------------------------------------------- 4. a file that is no table
def test_a_file_that_is_no_table_is_said_in_plain_words_by_every_reader(tmp_path, monkeypatch):
    from agentic import family1, family4, f4_recheck, procedures as PR, f4_research as RS
    import pytest
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path / "knowledge"))
    bad = not_a_table(str(tmp_path / "bad"))
    why = "notes.csv cannot be read as a table: every one of its first"
    info = PR.columns_info(bad, ["Command"])
    assert info["_error"].startswith(why) and info["Command"] == {"position": None, "samples": [], "rows_with_value": 0}
    for reader in (lambda: PR.sample_rows(bad), lambda: PR.sample_sources({"notes.csv": bad}, str(tmp_path / "box")), lambda: RS.measure(bad, ["Command"]), lambda: RS.count_rows(bad)):
        with pytest.raises(family1.L.BadFile) as e:
            reader()
        assert str(e.value).startswith(why)
    proc = {"version": 1, "source_data": [{"file": "notes.csv", "columns": ["Command"]}], "steps": ["Count."], "output": {"columns": ["Command", "count"], "order": "count, then Command"}}
    f = PR.coder_context({"id": "x", "name": "n"}, proc, None, paths={"notes.csv": bad})["FILES"][0]
    assert f["not_read"].startswith(why) and f["COLUMNS"][0]["position"] is None and "written_as" not in f
    assert PR.standin_share_code(dict(proc, output={"columns": ["Command", "count", "percent"]})) is not None       # the stand-in still writes its plain code
    monkeypatch.setattr(RS, "admin_items", lambda ctx, r, pr: [])
    rec = RS.build(_Ctx(), {"id": "x", "name": "n", "section": "analytics", "level": "other", "description": "count"}, proc, {"paths": {"notes.csv": bad}, "dicts": {}, "on_tree": False})
    assert rec["files"][0]["not_read"].startswith(why) and rec["files"][0]["note"].startswith("notes.csv was not read as a table, so nothing of it could be measured: " + why)
    assert rec["surprises"][0] == rec["files"][0]["note"] and RS.brief_for_agents(rec)["FILES"][0]["NOT_READ_AS_A_TABLE"].startswith(why)
    said = []
    assert family4._header(bad, said) is None and said[0].startswith(why)
    assert family4._header(str(tmp_path / "nowhere.csv"), said) is None and len(said) == 1
    assert f4_recheck.file_form(bad)["not_read_as_a_table"].startswith(why)


def test_family_4_reads_the_header_and_hands_the_recheck_the_form(tmp_path):
    from agentic import family4, f4_recheck
    p = three(tmp_path)
    assert family4._header(p["comma"]) == HEADER and f4_recheck.file_form(p["comma"]) == {}
    d = {"columns": [{"column": "Latency [ms]", "number_style": {"style": "decimal comma", "decimal_sign": ",", "thousands_sign": None, "how": "decimal comma: counted"}},
                     {"column": "Blocks", "number_style": {"style": "ambiguous", "how": "ambiguous: counted"}}, {"column": "Queue"}]}
    for form in OTHERS:
        assert family4._header(p[form]) == HEADER, form
        got = f4_recheck.file_form(p[form], d)
        assert got["written_as"]["separator"]["value"] == ";" and got["written_as"]["header"]["line"] == 2
        assert got["written_as"]["encoding"]["codec"] == ("utf-8-sig" if form == "semicolon" else "utf-16-le")
        assert [(x["column"], x["style"], x["read_as_a_number"]) for x in got["number_styles"]] == [("Latency [ms]", "decimal comma", True), ("Blocks", "ambiguous", False)]
    from agentic import prompts
    text = open(os.path.join(APP, "agentic", "prompts", "f4_recheck.md"), encoding="utf-8").read()
    assert "`written_as`" in text and "`number_styles`" in text
    assert "the header is on the line `FILES` gives" in prompts.load("f4_coder") and "a file of the same form" in open(os.path.join(APP, "agentic", "prompts", "f4_tester.md"), encoding="utf-8").read()


# ------------------------------------------------------------------------------------------- 5. the whole flow, with the stand-in
ITEM = "analytics/other/share_of_each_command"
ITEM2 = "errors/other/timed_out_commands"


def flow(root, form):
    """One whole flow with the stand-in on the recording written in `form` (what tests/flow_any_csv.py does, part 1) ->
    what it made, as plain data, to compare between the forms."""
    from agentic import admin_ask, core, family1, pipeline
    know = os.path.join(root, "knowledge")
    family1.knowledge_dir = lambda: know
    folder = os.path.dirname(write(os.path.join(root, "bench"), form, n=300))
    store = core.Store(os.path.join(root, "db", "agentic.sqlite"))
    runner = core.AgentRunner(os.path.join(root, "runs"), runtime="standin", web=False)
    eng = core.Engine(store, {"flow": pipeline}, runner, cfg={})
    pid = store.exec("INSERT INTO project (admin, name, folder, refs, created, updated) VALUES (?,?,?,?,?,?)", ("Sagar", "bench", folder, "[]", time.time(), time.time()))
    rid = eng.start(pid, "flow", "", {"started_by": "Sagar"})
    seen, out, t0 = [], {"form": form, "failed": None}, time.time()
    while time.time() - t0 < 240:
        run = store.one("SELECT * FROM run WHERE id=?", (rid,))
        failed = store.one("SELECT key, error FROM step WHERE run=? AND state='failed'", (rid,))
        if failed:
            out["failed"] = {"step": failed["key"], "error": failed["error"][-1500:]}
            break
        if run["state"] != "running":
            break
        rv = store.one("SELECT * FROM review WHERE run=? AND state='open' ORDER BY id LIMIT 1", (rid,))
        if not rv:
            time.sleep(0.2)
            continue
        key = store.one("SELECT key FROM step WHERE id=?", (rv["step"],))["key"]
        seen.append(key)
        edits = None
        if key == admin_ask.GATE:
            edits = {"stage2": "skip"}
        elif key == "f3_plan":
            edits = {"selected": [], "new": [{"section": "analytics", "level": "other", "name": "share of each command", "description": "percentage by Command"},
                                             {"section": "errors", "level": "other", "name": "timed out commands", "description": "rows where Result is timeout"}]}
        try:
            eng.decide(rv["id"], "approve", "Sagar", "", edits)
        except Exception as e:      # noqa: BLE001 - said in the result
            out["failed"] = {"step": key, "error": "the decision was refused: %s" % e}
            break
    by = {s["key"]: s for s in store.all("SELECT * FROM step WHERE run=? ORDER BY idx", (rid,))}

    def of(key):
        try:
            return json.loads((by.get(key) or {}).get("output") or "{}") or {}
        except ValueError:
            return {}
    out["state"] = store.one("SELECT state FROM run WHERE id=?", (rid,))["state"]
    out["reviews"] = [k.split(":")[-1] if k.startswith("f3:") else k.split(":")[0] for k in seen]
    d = {}
    try:
        with open(of("manager:" + NAME).get("dictionary_file") or "", encoding="utf-8") as fh:
            d = json.load(fh)
    except (OSError, ValueError):
        pass
    out["dictionary"] = {"rows": d.get("rows"), "columns": [[c.get("column"), c.get("type"), c.get("rows_with_value"), c.get("distinct"), (c.get("number_style") or {}).get("style")]
                                                              for c in d.get("columns") or []],
                         "written_as": (d.get("written_as") or {}).get("text")}
    for item in (ITEM, ITEM2):
        f4 = [s for s in by.values() if s["family"] == "4" and item in s["key"]]
        rec = (of(next((s["key"] for s in f4 if s["key"].endswith(":research")), "")).get("record") or {})
        files = rec.get("files") or [{}]
        out[item] = {"family_4": [(s["key"].split(":")[-1], s["state"]) for s in f4],
                     "research": {"rows": files[0].get("rows"), "basis": files[0].get("basis"), "touched": [[b["column"], b["rows_with_a_value"], b["distinct_values"], b["most_frequent"]]
                                                                                                           for b in files[0].get("touched") or []],
                                  "file_written_as": (files[0].get("file_written_as") or {}).get("text")},
                     "result": {k: of("f3:%s:run" % item).get(k) for k in ("columns", "head", "rows")}}
    eo = of("f3:%s:errors" % ITEM2)
    out["errors"] = {"kind": eo.get("kind"), "total": eo.get("total"), "rows": [[x.get("row"), x.get("file"), x.get("cells")] for x in eo.get("other_errors") or []]}
    return out


def _flow_in_its_own_process(root, form):
    got = subprocess.run([sys.executable, os.path.abspath(__file__), "flow", str(root), form], capture_output=True, text=True, timeout=600)
    assert got.returncode == 0, got.stderr[-3000:]
    return json.loads(got.stdout.strip().splitlines()[-1])


import pytest  # noqa: E402


@pytest.fixture(scope="module")
def flows(tmp_path_factory):
    root = tmp_path_factory.mktemp("flows")
    return _flow_in_its_own_process(root / "plain", "comma"), _flow_in_its_own_process(root / "semi", "semicolon")


def test_a_whole_flow_on_the_semicolon_file_equals_the_flow_on_the_plain_file(flows):
    plain, semi = flows
    for got in (plain, semi):
        assert got["failed"] is None and got["state"] == "finished", got["failed"]
        assert got["reviews"] == ["manager", "f1_gate", "f3_plan", "write", "req", "code", "result", "write", "req", "code", "result", "errors_done"], got["reviews"]
    # Family 1's dictionary: the five columns, 300 rows, the decimal comma and the column that cannot be told, in both
    assert plain["dictionary"]["written_as"] is None and "semicolon" in semi["dictionary"]["written_as"] and "header on line 2" in semi["dictionary"]["written_as"]
    assert semi["dictionary"]["columns"] == plain["dictionary"]["columns"] and semi["dictionary"]["rows"] == plain["dictionary"]["rows"] == 300
    assert [c[0] for c in semi["dictionary"]["columns"]] == HEADER and [c[4] for c in semi["dictionary"]["columns"]] == [None, None, "decimal comma", None, "ambiguous"]
    # Family 4: research, requirements, code; the result counted from the file itself
    for item in (ITEM, ITEM2):
        assert semi[item]["family_4"] == plain[item]["family_4"] and [k for k, _s in semi[item]["family_4"]] == ["research", "req", "code"], semi[item]["family_4"]
        assert plain[item]["research"]["file_written_as"] is None and "semicolon" in semi[item]["research"]["file_written_as"]
        assert {k: v for k, v in semi[item]["research"].items() if k != "file_written_as"} == {k: v for k, v in plain[item]["research"].items() if k != "file_written_as"}
        assert semi[item]["research"]["rows"] == 300 and semi[item]["research"]["basis"] == "exact: all 300 rows"
        assert semi[item]["result"] == plain[item]["result"] and semi[item]["result"]["columns"], item
    share = semi[ITEM]["result"]
    assert share["columns"] == ["Command", "count", "percent"] and sum(int(r[1]) for r in share["head"]) == 300
    assert {r[0]: int(r[1]) for r in share["head"]} == {"Read": 150, "Write": 100, "Flush": 50}
    # the errors item: the rows whose Result is timeout, found by the code on the file itself, the same rows in both
    slow = [i for i in range(1, 301) if i % 20 == 1]
    assert semi[ITEM2]["result"]["rows"] == plain[ITEM2]["result"]["rows"] == len(slow)
    assert semi["errors"]["kind"] == plain["errors"]["kind"] and semi["errors"]["total"] == plain["errors"]["total"] == len(slow)
    assert [x[:2] for x in semi["errors"]["rows"]] == [x[:2] for x in plain["errors"]["rows"]] == [[i, NAME] for i in slow]
    assert all(x[2][3] == "timeout" for x in plain["errors"]["rows"])


# (2026-11-15) agentic/other_errors.py reads the source file in its own form through csv_dialect: this was a strict expected failure until then
def test_the_cells_of_each_error_of_the_semicolon_file_are_the_rows_own_cells(flows):
    plain, semi = flows
    assert semi["errors"]["rows"] == plain["errors"]["rows"]


if __name__ == "__main__":
    if len(sys.argv) == 4 and sys.argv[1] == "flow":
        print(json.dumps(flow(sys.argv[2], sys.argv[3]), ensure_ascii=False, default=str))
        sys.exit(0)
    sys.exit("usage: python3 tests/test_form_in_every_reader.py flow <an empty folder> semicolon|comma")
