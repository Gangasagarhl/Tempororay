"""The rule families of the NVMe command level (nvme_hier/command_error_rules.py; owner, 2026-11-15).

No server and no model. Every recording is built in a temporary folder with the application's own loader, tree builder and detector
(F2T_WORKERS=1). The flow test uses a throw-away root and the stand-in only.

    python3 -m pytest -q -p no:cacheprovider tests/test_command_error_rules.py
"""
import csv
import json
import os
import shutil
import sys
import tempfile
import time
import tracemalloc

import pytest

os.environ["F2T_WORKERS"] = "1"
HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for _p in (APP, os.path.join(APP, "app"), HERE):
    if _p not in sys.path:
        sys.path.insert(0, _p)
from nvme_hier import builder as B, columns as C, command_error_rules as CE, loader as L, nvme_command_errors as NE, rules as RL, tree_api as T   # noqa: E402

SAMPLES = os.path.join(APP, "samples", "clean_five_files")
S17 = os.path.join(SAMPLES, "S17_io_timeout_abort_reset")
CMD_CSV, NTX_CSV = os.path.join(S17, "nvme_command.csv"), os.path.join(S17, "NVME_Transactions.csv")
CHECKABLE = [f for f in CE.FAMILIES if f["checkable"]]


@pytest.fixture
def tmp():
    d = tempfile.mkdtemp(prefix="cmd_err_rules_")
    yield d
    shutil.rmtree(d, ignore_errors=True)


def recording(folder, files, name="hier.sqlite"):
    db = os.path.join(folder, name)
    L.load_upload(db, files)
    B.build(db)
    RL.apply(db)
    return db


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as fh:
        rows = list(csv.reader(fh))
    return rows[0], rows[1:]


def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)
    return path


def found(db, fid):
    tree = T.Tree(db)
    try:
        info = {}
        out = list(CE.find(fid, tree, info))
        return out, info
    finally:
        tree.close()


def rows_of(db, fid):
    out, info = found(db, fid)
    assert info["can_be_checked"], (fid, info["why_not"])
    return [x["row"] for x in out]


class Cmds:
    """The S17 command and transaction files, to change cells of chosen commands (a command's row r is line r + 1 of its file)."""
    def __init__(self):
        self.h, self.rows = read_csv(CMD_CSV)
        self.nh, self.nrows = read_csv(NTX_CSV)
        self.i = {n: self.h.index(n) for n in ("OPC", "SQID", "CID", "NSID", "SLBA", "NLB", "ST.SCT", "ST.SC", "PRP1", "NSZE", "FID", "Time Stamp")}
        self.ni = {n: self.nh.index(n) for n in ("Type", "SQID", "CID", "SCT", "SC", "DNR", "M", "CRD", "Time Stamp")}

    def get(self, row, col):
        return self.rows[row - 1][self.i[col]]

    def set(self, row, **cells):
        for k, v in cells.items():
            self.rows[row - 1][self.i[{"SCT": "ST.SCT", "SC": "ST.SC", "TS": "Time Stamp"}.get(k, k)]] = str(v)

    def nset(self, nrow, **cells):
        for k, v in cells.items():
            self.nrows[nrow - 1][self.ni[k]] = str(v)

    def ok_io(self, opc_text=None):
        """Rows of I/O commands that completed with success, in file order."""
        return [n + 1 for n, r in enumerate(self.rows) if r[self.i["SQID"]] not in ("", "0") and r[self.i["ST.SCT"]] == "0" and r[self.i["ST.SC"]] == "0"
                and (opc_text is None or opc_text in r[self.i["OPC"]])]

    def build(self, folder, ntx=True):
        files = {"nvme_command": write_csv(os.path.join(folder, "nvme_command.csv"), self.h, self.rows)}
        if ntx:
            files["nvme_transaction"] = write_csv(os.path.join(folder, "NVME_Transactions.csv"), self.nh, self.nrows)
        return recording(folder, files)


@pytest.fixture(scope="module")
def s17():
    d = tempfile.mkdtemp(prefix="cmd_err_s17_")
    db = recording(d, {"nvme_command": CMD_CSV, "nvme_transaction": NTX_CSV})
    tree = T.Tree(db)
    cqe = {}
    for c in tree.rows("nvme_command"):
        n = CE.completion_row(tree, c.row)
        if n is not None:
            cqe[c.row] = n.row
    tree.close()
    yield {"db": db, "cqe": cqe}
    shutil.rmtree(d, ignore_errors=True)


# ---------------------------------------------------------------------------------------------- the data
def test_every_family_has_every_text_field_and_every_sentence_its_source():
    assert len(CE.FAMILIES) == len(CE.BY_ID) and [g for g, _a in CE.GROUPS] == ["Status the drive returned", "Behaviour over time", "Rules of the protocol"]
    assert sum(1 for f in CE.FAMILIES if f["group"] == CE.STATUS) == 24                     # R1's 24 families
    for f in CE.FAMILIES:
        assert f["group"] in dict(CE.GROUPS) and f["name"] and f["what"] and f["fault"] and f["from_notes"], f["id"]
        assert f["why"] and f["how"] and f["needs"], f["id"]
        for part in ("why", "how", "exceptions", "reaction"):
            for sentence, source in f[part]:
                assert sentence.strip() and source.strip(), (f["id"], part, sentence)
        for n in f["needs"]:
            assert n["what"] and ("cannot be checked on this recording" in n["says"] or "not given on this recording" in n["says"] or CE.NOT_CHECKABLE in n["says"]), (f["id"], n)
        for b in f["belongs_with"]:
            assert b in CE.BY_ID, (f["id"], b)
        if f["checkable"]:
            assert f["columns"] and f["reaction"], f["id"]
            for c in f["columns"]:
                assert c["names"] and c["meaning"] and c["level"] in ("nvme_command", "nvme_transaction"), (f["id"], c)     # no column without its meaning
        else:
            assert f["not_checkable"].startswith(CE.NOT_CHECKABLE) or f["not_checkable"].startswith("not seeded yet"), f["id"]
    # the status columns are named in both spellings, and the bits at the level that carries them
    assert CE.C_SCT["names"] == ["ST.SCT", "SCT"] and CE.C_SC["names"] == ["ST.SC", "SC"] and CE.C_DNR["level"] == "nvme_transaction"
    # the timeout chain belongs together
    for fid in CE.CHAIN:
        assert set(CE.CHAIN) - {fid} <= set(CE.BY_ID[fid]["belongs_with"]), fid
    # each of the detector's 13 command rules has its family, or the reason it has none
    assert set(CE.DETECTOR_MAP) == {r for r in RL.BASIS if r.startswith("cmd.")} and len(CE.DETECTOR_MAP) == 13
    for rule, (fams, words) in CE.DETECTOR_MAP.items():
        assert words and (fams is None or all(x in CE.BY_ID for x in fams)), rule
    assert len(CE.NOT_SEEDED) == len(CE.FAMILIES) - len(CHECKABLE) and all(x["why"] for x in CE.NOT_SEEDED)


def test_no_family_names_a_status_outside_the_catalogue_without_saying_why():
    for f in CE.FAMILIES:
        said = {v for v, _s, _src in f["differs"]}
        for _q, sct, codes, _ops in f["check"].get("match") or []:
            for sc in codes:
                e = NE.lookup(sct, sc)
                if not e or e["kind"] != "error":
                    assert "%Xh/%02Xh" % (sct, sc) in said, (f["id"], sct, hex(sc), (e or {}).get("kind"))
    for e in CE.EXCEPTIONS:                                                                     # a status that is not a failure: listed with its reason
        c = NE.lookup(e["sct"], e["sc"])
        assert c and c["kind"] in ("success", "status") and e["why"] and e["source"], e
    not_failures = {(e["type"], e["code"]) for e in NE.catalogue() if e["kind"] in ("success", "status")}
    assert not_failures == {(e["sct"], e["sc"]) for e in CE.EXCEPTIONS}


def test_no_error_status_of_the_catalogue_is_outside_every_family():
    seen = set()
    for e in NE.catalogue():
        if e["kind"] != "error":
            continue
        for sc in range(e["code"], (e.get("code_to") or e["code"]) + 1):
            for admin in (True, False):
                fid = CE.family_of_status(admin, "Read" if not admin else "Get Log Page (admin)", e["type"], sc)
                assert fid in CE.BY_ID and CE.BY_ID[fid]["checkable"], (e["type"], hex(sc), admin, fid)
                seen.add(fid)
    assert len(seen) >= 24
    for e in CE.EXCEPTIONS:
        assert CE.family_of_status(e["queue"] == "admin", "Firmware Commit (admin)" if e["queue"] == "admin" else "Read", e["sct"], e["sc"]) is None
    assert CE.family_of_status(False, "Read", 5, 0x10) == "protocol_05" and CE.family_of_status(False, "Read", 0, 0x17) == "protocol_05"       # reserved
    assert CE.family_of_status(False, "Read", 7, 0xC0) == "status_24" and CE.family_of_status(False, "Read", 0, 0xC5) == "status_24"          # vendor
    # a status tied to one command
    assert CE.family_of_status(True, "Identify (admin)", 1, 0x2C) == "status_07" and CE.family_of_status(True, "Set Features (admin)", 1, 0x2C) != "status_07"
    assert CE.family_of_status(True, "Set Features (admin)", 1, 0x14) == "status_21" and CE.family_of_status(True, "Firmware Commit (admin)", 1, 0x14) == "status_22"


def test_cells_are_read_in_both_spellings_and_a_damaged_cell_is_said():
    assert CE.num("0x02 (Read)") == (2, True) and CE.num("81h") == (0x81, True) and CE.num(" 7 ") == (7, True) and CE.num("") == (None, True) and CE.num("zz") == (None, False)

    class Row(dict):
        row, number, time_ps = 5, 5, 10
    real = CE.command(Row({"OPC": "0x02 (Read)", "SQID": "3", "CID": "9", "ST": "0x0281", "SCT": "2", "SC": "0x81"}))
    sample = CE.command(Row({"OPC": "0x02 (Read)", "SQID": "3", "CID": "9", "ST.SCT": "2", "ST.SC": "129"}))
    assert (real["sct"], real["sc"]) == (sample["sct"], sample["sc"]) == (2, 0x81) and real["name"] == "Read" and not real["damaged"]
    bad = CE.command(Row({"OPC": "0x02 (Read)", "SQID": "3", "ST.SCT": "zz", "ST.SC": "1"}))
    assert bad["sct"] is None and bad["damaged"] == [("ST.SCT", "zz")]


# ---------------------------------------------------------------------------------------------- each family on its own case
def test_each_status_family_finds_exactly_its_case_and_not_the_nearest_one(tmp):
    cm = Cmds()
    io, want = cm.ok_io(), {}
    k = 0
    for f in CE.FAMILIES:
        for q, sct, codes, ops in f["check"].get("match") or []:
            if ops or q == "admin":
                continue
            want[f["id"]] = io[10 + k]
            cm.set(io[10 + k], SCT=sct, SC=codes[0])
            k += 1
            break
    # the admin families, and the statuses tied to one command
    cm.set(1, SCT=1, SC=0x2C)             # Identify: Invalid I/O Command Set
    cm.set(4, SCT=1, SC=0x14)             # Set Features: Overlapping Range
    cm.set(5, SCT=1, SC=0x01)             # Create I/O Completion Queue: Invalid Queue Identifier
    cm.set(2, SCT=1, SC=0x14)             # Identify with 14h: not a Set Features, so the maintenance family
    cm.set(3, SCT=0, SC=0x24)             # admin command media not ready
    want.update({"status_07": [want["status_07"], 1], "status_21": 4, "status_20": 5, "status_22": 2, "status_16": [want["status_16"], 3]})
    # the nearest cases that must NOT be flagged: success, and the statuses that are not failures
    cm.set(6, SCT=1, SC=0x0B)             # admin: firmware activation requires a reset
    cm.set(io[5], SCT=1, SC=0x9C)         # I/O: successful media verification read
    # reserved and vendor values, and a damaged cell
    cm.set(io[6], SCT=5, SC=0x01)
    cm.set(io[7], SCT=0, SC=0x17)
    cm.set(io[8], SCT=7, SC=0x01)
    cm.set(io[9], SCT="zz", SC=1)
    want["protocol_05"] = [io[6], io[7], io[9]]
    want["status_24"] = [want["status_24"], io[8]]
    want["status_13"] = [want["status_13"], 144]          # the sample's own Read that the host aborted
    db = cm.build(tmp)
    second = CE.sql_counts(db)
    for f in CE.FAMILIES:
        if f["group"] != CE.STATUS and f["id"] != "protocol_05":
            continue
        out, info = found(db, f["id"])
        exp = want.get(f["id"], [])
        exp = sorted(exp if isinstance(exp, list) else [exp])
        assert info["can_be_checked"] and sorted(x["row"] for x in out) == exp, (f["id"], [x["row"] for x in out], exp)
        assert exp, f["id"]                                                                 # every status family has its case in this recording
        for x in out:
            assert x["reason"] and x["fault"] and x["values"] and "status_" not in x["reason"] and "protocol_" not in x["reason"], x
        if f["id"] != "protocol_05":
            # the second count, made another way; the damaged cell (SCT 'zz' beside SC 1) is a row only the loader's columns take for 0h/01h
            assert second[f["id"]] == len(exp) + (1 if f["id"] == "status_07" else 0), (f["id"], second[f["id"]])
            assert any("completed with status" in x["reason"] and "do not retry = " in x["reason"] for x in out), out[0]["reason"]
    damaged = [x for x in found(db, "protocol_05")[0] if x["row"] == io[9]]
    assert "is not a number" in damaged[0]["reason"] and "'zz'" in damaged[0]["reason"]
    # as the code of an item: the summary says how many cells could not be read; the Tester's checks pass
    out_csv = os.path.join(tmp, "out.csv")
    tree = T.Tree(db)
    res = CE.run_on_tree(tree, out_csv, "protocol_05")
    tree.close()
    assert res["rows_written"] == 3 and res["damaged_cells"] == 1 and res["can_be_checked"]
    head, lines = read_csv(out_csv)
    assert head == [c for c, _m in CE.OUTPUT_COLUMNS] and sorted(int(x[head.index(CE.ROW_COLUMN)]) for x in lines) == sorted(want["protocol_05"])
    checks = CE.result_checks(out_csv, res)
    assert all(c["ok"] for c in checks), checks
    assert any("reference implementation" in c["check"] and c["detail"].startswith("the same 3 rows") for c in checks)


def test_the_real_exports_spelling_of_the_status_columns_finds_the_same_rows(tmp):
    real = (C.real_headers().get("nvme_command") or [None])[0]
    if real is None:
        pytest.skip("no real header of the NVMe command file is stored")
    cm = Cmds()
    io = cm.ok_io("Read")
    cm.set(io[3], SCT=2, SC=0x81)
    cm.set(io[4], SCT=0, SC=0x80)
    assert "SCT" in real["header"] and "ST.SCT" not in real["header"]
    src, dst = L.align_header("nvme_command", cm.h).positions, L.align_header("nvme_command", real["header"]).positions
    shared = [n for n in src if n in dst]
    rows = []
    for r in cm.rows:
        new = [""] * len(real["header"])
        for n in shared:
            new[dst[n]] = r[src[n]] if src[n] < len(r) else ""
        rows.append(new)
    db = recording(tmp, {"nvme_command": write_csv(os.path.join(tmp, "nvme_command.csv"), real["header"], rows)})
    assert rows_of(db, "status_01") == [io[3]] and rows_of(db, "status_09") == [io[4]]
    assert rows_of(db, "status_13") == [144]                                              # the sample's own aborted Read
    out, _info = found(db, "status_01")
    assert "the bits were not read: the NVMe transactions file is not loaded" in out[0]["reason"]


def test_the_families_on_the_bits_and_the_relations_between_rows(tmp, s17):
    cm, cqe = Cmds(), s17["cqe"]
    io = [r for r in cm.ok_io() if r in cqe]
    wr = [r for r in cm.ok_io("Write") if r in cqe]
    # 'do not retry' on a success (should be 0); on Command Interrupted (shall be 0); on Invalid Field (allowed: not flagged)
    a, b, c_ = io[20], io[21], io[22]
    cm.nset(cqe[a], DNR=1)
    cm.set(b, SCT=0, SC=0x21)
    cm.nset(cqe[b], SCT=0, SC=0x21, DNR=1)
    cm.set(c_, SCT=0, SC=0x02)
    cm.nset(cqe[c_], SCT=0, SC=0x02, DNR=1)
    # a retry delay with 'do not retry' (flagged) and without (not flagged)
    d, e = io[23], io[24]
    cm.set(d, SCT=0, SC=0x82)
    cm.nset(cqe[d], SCT=0, SC=0x82, DNR=1, CRD=2)
    cm.set(e, SCT=0, SC=0x82)
    cm.nset(cqe[e], SCT=0, SC=0x82, DNR=0, CRD=1)
    # a Write that failed with 'do not retry' and was sent again; one that failed without it and was sent again (not flagged)
    w1, w2, w3, w4 = wr[30], wr[31], wr[32], wr[33]
    cm.set(w1, SCT=2, SC=0x80, SLBA=777000, NLB=7)
    cm.nset(cqe[w1], SCT=2, SC=0x80, DNR=1)
    cm.set(w2, SLBA=777000, NLB=7, NSID=cm.get(w1, "NSID"))
    cm.set(w3, SCT=2, SC=0x80, SLBA=888000, NLB=7)
    cm.nset(cqe[w3], SCT=2, SC=0x80, DNR=0)
    cm.set(w4, SLBA=888000, NLB=7, NSID=cm.get(w3, "NSID"))
    # the size of namespace 1 on its Identify; one command past the end answered with success, one answered LBA Out of Range, one that ends exactly at the end
    cm.set(3, NSZE=4000000)
    p, q, r_ = io[40], io[41], io[42]
    cm.set(p, SLBA=3999999, NLB=7)
    cm.set(q, SLBA=3999999, NLB=7, SCT=0, SC=0x80)
    cm.set(r_, SLBA=3999992, NLB=7)
    # a first data pointer that is not aligned, and one that is
    u, v = io[43], io[44]
    cm.set(u, PRP1="0x000000001E4B3002")
    cm.set(v, PRP1="0x000000001E4B3004")
    # a command identifier FFFFh
    cm.set(io[45], CID=65535)
    db = cm.build(tmp)
    assert rows_of(db, "protocol_06") == [a, b]
    out, _i = found(db, "protocol_06")
    assert "should be 0 on a success" in out[0]["reason"] and "shall be 0 with Command Interrupted" in out[1]["reason"]
    assert rows_of(db, "protocol_07") == [d]
    assert rows_of(db, "behaviour_09") == [w2]
    out, _i = found(db, "behaviour_09")
    assert ("row %d had failed with status 2h/80h and 'do not retry' = 1" % w1) in out[0]["reason"]
    assert rows_of(db, "protocol_11") == [p, q]
    out, _i = found(db, "protocol_11")
    assert "the controller is at fault as well" in out[0]["reason"] and "as the specification expects" in out[1]["reason"] and "4,000,000 blocks" in out[0]["reason"]
    assert rows_of(db, "protocol_13") == [u]
    got = found(db, "protocol_01")[0]
    assert [x["row"] for x in got] == [io[45]] and "Advice only" in got[0]["reason"]
    assert rows_of(db, "status_02") == [w1, w3] and rows_of(db, "status_09") == [q]
    second = CE.sql_counts(db)
    assert second["protocol_06"] == 2 and second["protocol_07"] == 1


def test_an_admin_command_that_io_depends_on_failed(tmp):
    cm = Cmds()
    cm.set(5, SCT=1, SC=0x01)             # Create I/O Completion Queue refused
    cm.set(4, SCT=0, SC=0x02)             # Set Features, Number of Queues, refused
    cm.set(145, SCT=1, SC=0x03)           # an Abort refused: not a command I/O depends on
    db = cm.build(tmp)
    assert rows_of(db, "behaviour_14") == [4, 5] and rows_of(db, "status_20") == [5] and rows_of(db, "status_21") == [145]


def test_without_the_completion_rows_the_families_on_the_bits_say_cannot_be_checked(tmp):
    db = recording(tmp, {"nvme_command": CMD_CSV})
    for fid in ("protocol_06", "protocol_07", "behaviour_09", "protocol_01", "behaviour_02", "behaviour_05"):
        out, info = found(db, fid)
        assert out == [] and info["can_be_checked"] is False and info["why_not"].startswith("cannot be checked on this recording: "), (fid, info)
        assert "NVMe transactions file is not loaded" in info["why_not"], fid
    # the status families still run, and say that the bits were not read
    out, info = found(db, "status_13")
    assert [x["row"] for x in out] == [144] and info["can_be_checked"] and "the bits were not read" in out[0]["reason"]
    # as an item's code: an empty list with the sentence, and the Tester's checks pass
    tree = T.Tree(db)
    res = CE.run_on_tree(tree, os.path.join(tmp, "o.csv"), "protocol_06")
    tree.close()
    assert res["rows_written"] == 0 and res["can_be_checked"] is False and "cannot be checked on this recording" in res["words"]
    assert all(c["ok"] for c in CE.result_checks(os.path.join(tmp, "o.csv"), res))
    # a family that cannot be checked from the command export at all says so, and what would be needed
    out, info = found(db, "behaviour_11")
    assert out == [] and info["why_not"].startswith(CE.NOT_CHECKABLE) and "SQHD" in info["why_not"]


def test_the_timeout_chain_on_s17_is_reported_as_linked_findings(s17):
    db = s17["db"]
    never, i1 = found(db, "behaviour_01")
    aborts, _ = found(db, "behaviour_03")
    resets, _ = found(db, "behaviour_04")
    aborted, _ = found(db, "status_13")
    assert [x["row"] for x in never] == [155, 216, 295, 358, 443, 509] and [x["row"] for x in aborts] == [145, 216, 358, 501, 570]
    assert [x["row"] for x in resets] == [279, 427, 580] and [x["row"] for x in aborted] == [144]
    # one episode, one sentence, on every finding of it
    ep2 = {x["linked"] for x in never[:2]} | {x["linked"] for x in aborts[:2]} | {resets[0]["linked"], aborted[0]["linked"]}
    assert len(ep2) == 1
    words = ep2.pop()
    assert words.startswith("Episode 2 of the recording") and "2 commands never completed (rows 155, 216" in words and "2 Abort commands (rows 145, 216)" in words
    assert "1 command was completed as aborted (row 144)" in words and "set the controller up again at row 279" in words
    assert all(x["linked"] for x in never + aborts + resets + aborted) and len({x["linked"] for x in never + aborts + resets + aborted}) == 3
    assert "never completed" in never[0]["reason"] and "the host's limit is 30 s" in never[0]["reason"]
    assert "the Abort itself got no completion; it was sent while the command in row 155 had no completion" in aborts[1]["reason"]
    assert "Which command it names is not a column of the NVMe command export" in aborts[0]["reason"]
    assert "bit 0 of its completion is 0" in aborts[0]["reason"]
    # the commands that are meant to stay open, and the other samples: nothing is flagged
    for fid in ("behaviour_02", "behaviour_05", "behaviour_09", "behaviour_13", "behaviour_14", "protocol_01", "protocol_06", "protocol_07", "protocol_13"):
        assert rows_of(db, fid) == [], fid
    out, info = found(db, "protocol_11")
    assert out == [] and info["why_not"] == "cannot be checked on this recording: no Identify command of the recording carries the size of a namespace (column NSZE)"
    # every status row is in exactly one status family
    total = sum(len(found(db, f["id"])[0]) for f in CE.FAMILIES if f["group"] == CE.STATUS or f["id"] == "protocol_05")
    assert total == 1
    # the page's counts: the same numbers
    page = CE.counts_for_page(db)
    assert page["behaviour_01"]["found"] == 6 and page["behaviour_03"]["found"] == 5 and page["behaviour_04"]["found"] == 3 and page["status_13"]["found"] == 1
    assert page["behaviour_11"]["found"] is None and page["behaviour_11"]["words"].startswith(CE.NOT_CHECKABLE)


def test_an_asynchronous_event_request_that_stays_open_is_not_flagged(tmp):
    cm = Cmds()
    cm.set(3, OPC="0x0C (Asynchronous Event Request)", SCT="", SC="")
    cm.rows[2][cm.h.index("ST")] = ""
    db = cm.build(tmp)
    assert 3 not in rows_of(db, "behaviour_01") and rows_of(db, "behaviour_01") == [155, 216, 295, 358, 443, 509]


def test_a_coded_result_is_compared_with_the_reference_and_the_difference_is_said(tmp, s17):
    out_csv = os.path.join(tmp, "coded.csv")
    write_csv(out_csv, ["note", CE.ROW_COLUMN], [["a", 155], ["b", 216], ["c", 295], ["d", 358], ["e", 443], ["f", 7]])
    c = CE.compare_with_reference(out_csv, s17["db"], "behaviour_01")
    assert c["ok"] is False and "only the code found row 7" in c["detail"] and "only the reference implementation found row 509" in c["detail"]
    write_csv(out_csv, ["note", CE.ROW_COLUMN], [["a", r] for r in (155, 216, 295, 358, 443, 509)])
    assert CE.compare_with_reference(out_csv, s17["db"], "behaviour_01") == {"check": c["check"], "ok": True, "detail": "the same 6 rows"}
    write_csv(out_csv, ["note"], [["a"]])
    assert CE.compare_with_reference(out_csv, s17["db"], "behaviour_01")["ok"] is False


def test_200000_commands_are_streamed_with_bounded_memory(tmp):
    header = ["NVMe Cmd", "OPC", "SQID", "CQID", "CID", "NSID", "SLBA", "NLB", "ST", "ST.SCT", "ST.SC", "Time Delta", "Time Stamp"]
    path, n, bad = os.path.join(tmp, "nvme_command.csv"), 200000, []
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        for i in range(1, n + 1):
            sct, sc = (2, 0x81) if i % 1000 == 0 else (0, 0)
            if sct:
                bad.append(i)
            w.writerow([i, "0x02 (Read)", 1 + i % 4, 1 + i % 4, i % 1024, 1, 8 * i, 7, "", sct, sc, "10.000 us", "%04d.%012ds" % (i // 100000, (i % 100000) * 10000000)])
    t0 = time.time()
    db = recording(tmp, {"nvme_command": path})
    t_load = time.time() - t0
    out_csv = os.path.join(tmp, "o.csv")
    tree = T.Tree(db)
    t0 = time.time()
    res = CE.run_on_tree(tree, out_csv, "status_01")
    t_status = time.time() - t0
    tracemalloc.start()                              # the memory is measured on the second run (the measuring itself makes a run several times slower)
    t0 = time.time()
    res2 = CE.run_on_tree(tree, os.path.join(tmp, "o2.csv"), "behaviour_03")
    t_chain = time.time() - t0
    _cur, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    tree.close()
    print("\n200,000 commands: loaded and built in %.1f s; the status family streamed them in %.1f s (%.0f commands a second); the chain family, with the memory "
          "measured, in %.1f s; peak memory growth of that run %.1f MB" % (t_load, t_status, n / max(t_status, 1e-9), t_chain, peak / 1024 ** 2))
    assert res["rows_read"] == n and res["rows_written"] == len(bad) == 200 and res2["rows_read"] == n and res2["rows_written"] == 0
    head, lines = read_csv(out_csv)
    assert [int(x[head.index(CE.ROW_COLUMN)]) for x in lines] == bad
    assert peak < 64 * 1024 ** 2, "the pass held %.1f MB" % (peak / 1024 ** 2)
    assert CE.sql_counts(db)["status_01"] == 200


# ---------------------------------------------------------------------------------------------- the library items and the flow
@pytest.fixture
def library(tmp):
    from agentic import family1, family3, procedures as PR
    kept, hook = family1.knowledge_dir, PR.MODEL_CONNECTED
    family1.knowledge_dir = lambda: tmp
    # (joined 2026-11-15) the engine sets the hook when it is made, and it stays set after a test's engine is gone: these tests state their own case
    PR.MODEL_CONNECTED = None
    try:
        yield family3
    finally:
        family1.knowledge_dir = kept
        PR.MODEL_CONNECTED = hook


def test_one_item_per_family_is_seeded_not_chosen_and_never_written_over(library):
    from agentic import other_errors as OE, procedures as PR
    from nvme_hier import coded_findings as CF
    family3 = library
    assert CE.ROW_COLUMN == OE.ROW_COLUMN == CF.ROW_COLUMN
    family3.tree()
    # (2026-11-15) a new installation keeps "The command was aborted because the host asked" as a live item and starts the other 37 families in
    # Deleted items (tests/test_top_three_rules.py checks that): restored here through the application's own restore path, so every family's
    # item is checked below as before
    from test_command_rules_flow import restore_the_families
    restore_the_families()
    tree = family3.tree()
    errs = next(lv for s in tree if s["section"] == "errors" for lv in s["levels"] if lv["level"] == "nvme_command")
    mine = [i for i in errs["items"] if i["id"].startswith(CE.ITEM_PREFIX)]
    assert len(mine) == len(CHECKABLE) == len(CE.items()) and not any(i["default"] for i in mine) and all(i["code"] == "verified" for i in mine)
    assert family3.DEFAULT_CHOSEN == {("analytics", "nvme_command", "command_type_share"), ("analytics", "nvme_command", "read_pattern"),
                                      ("errors", "nvme_command", "cmd_timeout"), ("errors", "nvme_command", "cmd_read_failure")}
    assert family3.KEPT_ERROR_RULES == ("cmd.timeout", "cmd.read_failure")
    for f in CHECKABLE:
        r = family3.load_rule("errors", "nvme_command", CE.item_id(f["id"]))
        assert r["name"] == f["name"] and r["group"] == f["group"] and r["kind"] == CE.KIND and r["plan"] == {"family": f["id"]} and r["status"] == "draft"
        assert "WHAT: " in r["definition"] and " WHY: " in r["definition"] and " HOW: " in r["definition"] and r["columns"] and r["source"]
        proc = PR.procedure_of(r)
        assert PR.validate({k: proc[k] for k in ("source_data", "steps", "output", "open_questions")}) and PR.uses_tree(proc) and not proc["open_questions"]
        assert CE.ROW_COLUMN in proc["output"]["columns"] and CF.result_problem(proc["output"]["columns"], "nvme_command", r["name"]) == ""
        # (joined 2026-11-15) the reference text passes only as the application's own code; as a Coder's code it is refused, and the stand-in holds none
        assert PR.check_code(CE.code_for(f["id"]), tree=True, application=True) == [] and r["id"] not in PR.STANDIN_CODE
        assert PR.REFERENCE_REFUSAL in PR.check_code(CE.code_for(f["id"]), tree=True)
        app = PR.application_code(r)
        assert app and app["file"] == CE.THIS_FILE and PR.code_state(r)["verified"] is True
    # an item the admin edited keeps the admin's text; an item the admin deleted does not come back
    a, b = CE.item_id("status_01"), CE.item_id("status_02")
    r = family3.load_rule("errors", "nvme_command", a)
    r.update(name="The admin's own name", status="approved", version=1)
    family3.save_rule(r)
    family3.delete_item("errors", "nvme_command", b, "admin t", "not wanted")
    family3.seed()
    assert family3.load_rule("errors", "nvme_command", a)["name"] == "The admin's own name" and family3.load_rule("errors", "nvme_command", b) is None
    # a procedure the admin changed makes the item a rule of its own: the Coder writes its code like any other
    c = family3.load_rule("errors", "nvme_command", CE.item_id("status_03"))
    proc = PR.procedure_of(c)
    changed, _ = PR.store(json.loads(json.dumps(c)), dict(proc, steps=proc["steps"] + ["One more step of the admin's own."]), "admin t")
    assert PR.application_code(changed) is None and PR.code_state(changed)["verified"] is False


def test_with_a_model_connected_family_4_writes_the_code(library):
    from agentic import procedures as PR
    family3 = library
    family3.seed()
    from test_command_rules_flow import restore_the_families
    restore_the_families()              # (2026-11-15) a new installation starts "A command never completed" in Deleted items
    r = family3.load_rule("errors", "nvme_command", CE.item_id("behaviour_01"))
    kept = PR.MODEL_CONNECTED
    try:
        PR.MODEL_CONNECTED = None           # (joined 2026-11-15) the engine sets the hook when it is made: a test that ran before this one may have made one
        assert PR.application_code(r)                                                     # nothing says a model is connected: the reference implementation
        PR.MODEL_CONNECTED = lambda: True
        assert PR.model_writes_the_code(r) and PR.application_code(r) is None            # Family 4's three steps then run for it
        st = PR.code_state(r)
        assert st["kind"] == "python" and st["verified"] is False                         # no code is taken as verified: the Coder writes it, the admin approves it
        assert family3.errors_of_the_tree(r)                                              # and its rows are filed as errors of the tree
        assert not PR.model_writes_the_code(family3.load_rule("analytics", "nvme_command", "near_limit"))
        PR.MODEL_CONNECTED = lambda: (_ for _ in ()).throw(RuntimeError("not known"))
        assert PR.application_code(r)                                                     # not known: the safe case
    finally:
        PR.MODEL_CONNECTED = kept


@pytest.fixture(scope="module")
def flow():
    import fuzz_app as F
    import fuzz_deep as FD
    from agentic import core, family1, procedures as PR
    from api import config_api, hier_api
    from test_application_code_items import drive
    root = tempfile.mkdtemp(prefix="cmd_err_flow_%d_" % os.getpid())
    kept = (core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK)
    uploads = list(PR._UPLOADS)          # create_app points the procedures at the throw-away root's uploads: put back for the tests that follow
    calls = []
    try:
        app, _c, _k, _r = F.setup(root)
        core.Engine.kick = F.REAL_KICK or kept[0]
        c = app.test_client()
        c.get("/api/agents/state")
        # (2026-11-15) a new installation starts 37 of the families in Deleted items: restored here, so "every item" is every family as before
        from test_command_rules_flow import restore_the_families
        restore_the_families()
        runner = app.config["services"].agentic_engine.runner
        real = runner.ask
        runner.ask = lambda *a, **k: (calls.append(str(a[1] if len(a) > 1 else k.get("agent"))), real(*a, **k))[1]
        out = {}
        drive(c, FD, "S17 every item", S17, lambda keys: list(keys), out)
        yield {"out": out["S17 every item"], "calls": calls, "root": root}
    finally:
        core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK = kept
        PR._UPLOADS[:] = uploads
        shutil.rmtree(root, ignore_errors=True)


def test_a_whole_flow_with_every_item_chosen_finishes_without_a_model(flow):
    f = flow["out"]
    print("\nthe whole flow on S17 with every item of the plan chosen: %s in %.0f s, %d items" % (f["state"], f["seconds"], len(f["plan"])))
    assert f["state"] == "finished", (f["state"], [(s["key"], s["state"], (s.get("error") or "")[:300]) for s in f["view"]["steps"] if s["state"] not in ("done", "approved", "skipped")])
    mine = ["errors/nvme_command/" + CE.item_id(x["id"]) for x in CHECKABLE]
    assert set(mine) <= set(f["plan"])
    sentence = "this item runs code that is part of the application (nvme_hier/command_error_rules.py): there is nothing to research, to ask or to code"
    found_rows = {}
    for fam, item in zip(CHECKABLE, mine):
        st = {s["key"].rsplit(":", 1)[1]: s for s in f["view"]["steps"] if s["key"].startswith("f3:%s:" % item)}
        for sub in ("research", "req", "code"):
            assert st[sub]["state"] == "skipped" and (st[sub].get("note") or "").startswith(sentence), (item, sub, st[sub]["state"], st[sub].get("note"))
        assert "no model is connected to write the code from the rule's text" in st["code"]["note"]
        assert st["run"]["state"] == "done" and st["run"]["output"]["columns"] == [c for c, _m in CE.OUTPUT_COLUMNS], item
        test = st["test"]["output"]
        assert test["passed"] is True, (item, [c for c in test["checks"] if not c["ok"]])
        assert any("reference implementation" in c["check"] for c in test["checks"]), item
        assert st["result"]["state"] == "approved", (item, st["result"]["state"])
        found_rows[fam["id"]] = st["run"]["output"]["rows"]
    assert (found_rows["behaviour_01"], found_rows["behaviour_03"], found_rows["behaviour_04"], found_rows["status_13"]) == (6, 5, 3, 1)
    assert sum(found_rows.values()) == 15
    assert not [a for a in flow["calls"] if CE.ITEM_PREFIX in a]                           # no model, and no stand-in agent, was asked for these items
