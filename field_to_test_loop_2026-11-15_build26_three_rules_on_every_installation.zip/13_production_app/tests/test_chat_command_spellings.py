"""The code check of a model's proposed sequence (nvme_hier/chat.check_answer): the ways a model writes the fault's own vendor
command. Found 2026-11-15: the real model wrote "opcode 0x7F (nsid 1)" and the check called it a command outside the allowed set.

    python3 -m pytest -q -p no:cacheprovider tests/test_chat_command_spellings.py
"""
import os
import sys

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, APP)
from nvme_hier import chat as CH   # noqa: E402

WINDOW = {"rows": [{"rowid_file": 207, "opc": 0x7F, "command": "Opcode 0x7F"}, {"rowid_file": 206, "opc": 0x02, "command": "Read"}]}


def problems(command):
    return CH.check_answer({"scenario_name": "a vendor command refused", "proposed_sequence": [{"step": 1, "command": command}], "cited_rows": [207]}, WINDOW)[1]


def test_the_faults_own_vendor_command_is_accepted_in_the_spellings_a_model_uses():
    for c in ("opcode 0x7F", "Opcode 0x7f", "opcode_0x7F", "opcode_0x7F_raw", "opcode 0x7F (nsid 1)", "opcode 0x7F (NSID=1)", "Opcode 0x7F (namespace 1)", "Read (nsid 1)"):
        assert problems(c) == [], (c, problems(c))


def test_a_command_that_is_not_allowed_is_still_refused_whatever_stands_in_brackets():
    for c in ("Firmware Commit (nsid 1)", "Firmware Image Download", "opcode 0x7F (and then Firmware Commit)", "rm -rf (nsid 1)", "Namespace Management (namespace 1)"):
        assert len(problems(c)) == 1 and "outside the allowed set" in problems(c)[0], (c, problems(c))


def test_a_cited_row_outside_the_window_is_still_refused():
    ok, probs = CH.check_answer({"scenario_name": "x", "proposed_sequence": [{"step": 1, "command": "Read"}], "cited_rows": [999]}, WINDOW)
    assert ok is False and any("cited row 999" in p for p in probs)
