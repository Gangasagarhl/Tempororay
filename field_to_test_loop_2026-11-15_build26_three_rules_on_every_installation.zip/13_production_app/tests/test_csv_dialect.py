"""A CSV as real tools write it (2026-11-14): agentic/csv_dialect.py and its use in the Data Explorer's reading.

Every file is written by the test, in a temporary folder: a semicolon file with decimal commas, units in the header and
carriage-return line ends (the header is the one real Windows Performance Analyzer export quoted in
reference_library/windows_wpa/NOTES.md section 3; the rows are made up in the same style), tab and vertical bar, title
lines before the header, UTF-16 in three forms, a quoted cell that holds the separator and a line break, a column of
"1,234" values, two separators that tie, an empty file, a file of one line, files that are not tables, a 60 MB file read
in parts and on one core, a part that ends inside a quoted cell, a UTF-16 file asked to be read in parts, and the
project's samples (the same profile as the released code gives).

No server, no model. The worker processes of the reading in parts are started as the application starts them; this
process itself never calls the functions that lower a priority.
Run: python3 -m pytest -q -p no:cacheprovider tests/test_csv_dialect.py   (-s shows the measured time and memory)."""
import importlib.util
import json
import os
import sys
import time
import zipfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app")):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import csv_dialect as CD, family1, profile_parallel as PP      # noqa: E402
from nvme_hier import loader as L                                           # noqa: E402

SMALL = dict(workers=3, min_bytes=0, chunk_bytes=64 * 1024)      # a small file in many parts
WPA_HEADER = ("IO Type;Priority;Process (Name);Init Time (s);Complete Time (s);IO Time (µs);Disk Service Time (µs);Size (B);Min Offset;"
              "Max Offset;QD/I - Queue Depth at Init Time;QD/C - Queue Depth at Complete Time;Disk;Count")
S08 = os.path.join(APP, "samples", "clean_five_files", "S08_interrupt_before_completion")
RELEASED_ZIP = os.path.join(os.path.dirname(APP), "field_to_test_loop_code_only.zip")


def regional(x, digits):
    """A number as a laptop with a decimal comma writes it: 1795.9 -> 1.795,900."""
    return "{:,.{d}f}".format(x, d=digits).replace(",", " ").replace(".", ",").replace(" ", ".")


def wpa_rows(n):
    for i in range(n):
        init = 1.0799438 + i * 0.0123457
        took = 87.2 + (i * 37 % 1500) * 1.1
        yield [("Read", "Write", "Flush")[i % 3], ("Normal", "Very Low")[i % 7 == 0], ("System", "svchost.exe", "MsMpEng.exe")[i % 3],
               regional(init, 9), regional(init + took / 1e6, 9), regional(took, 3), regional(took * 0.7, 3), str(512 * (1 + i % 8)),
               "0x%016X" % (i * 4096), "0x%016X" % (i * 4096 + 511), str(i % 3), str(i % 2), "1", "1"]


def write_wpa(path, n=5000, sep=";", end="\r\n", encoding="utf-8", before=()):
    text = "".join(ln + end for ln in before) + WPA_HEADER.replace(";", sep) + end + "".join(sep.join(r) + end for r in wpa_rows(n))
    with open(path, "wb") as fh:
        fh.write(text.encode(encoding))
    return path


def difference(a, b, skip=("seconds",)):
    """Where two profiles differ first, in words; "" when they are the same (the keys in `skip` aside)."""
    for k in sorted(set(a) | set(b)):
        if k not in skip and k != "columns" and a.get(k) != b.get(k):
            return "key %r: %r / %r" % (k, a.get(k), b.get(k))
    ca, cb = a.get("columns") or [], b.get("columns") or []
    if len(ca) != len(cb):
        return "%d columns / %d columns" % (len(ca), len(cb))
    for x, y in zip(ca, cb):
        for k in sorted(set(x) | set(y)):
            if x.get(k) != y.get(k):
                return "column %r, key %r: %r / %r" % (x.get("column"), k, str(x.get(k))[:200], str(y.get(k))[:200])
    return ""


def both(path, level=None, parallel=True, **how):
    """The file through the one-core reading and the reading in parts: the same profile. -> (the profile, what the call in parts did)."""
    a = family1.full_profile(path, level)
    b = PP.full_profile_parallel(path, level, **dict(SMALL, **how))
    did = dict(PP.LAST)
    assert difference(a, b) == "", did
    assert difference(a, PP.assemble(**PP.sequential_state(path, level))) == ""
    if parallel is not None:
        assert bool(did.get("parallel")) == parallel, did
    return a, did


def col(prof, name):
    return next(c for c in prof["columns"] if c["column"] == name)


# ---------------------------------------------------------------------------------------------- the forms real tools write
def test_semicolon_decimal_commas_units_and_carriage_returns(tmp_path):
    path = write_wpa(str(tmp_path / "Disk_Usage_Counts_by_IO_Type_Priority.csv"))
    d = CD.detect(path)
    assert d["refused"] is None and d["separator"] == ";" and d["separator_decided"] and d["header_line"] == 1 and d["codec"] == "utf-8-sig"
    assert "semicolon gives 14 cells" in d["separator_how"] and "comma gives" in d["separator_how"]         # every candidate with its count
    prof, did = both(path)
    assert prof["rows"] == 5000 and prof["columns_in_file"] == 14
    assert [c["column"] for c in prof["columns"]] == WPA_HEADER.split(";")         # the header text exactly, the units with it
    assert col(prof, "IO Time (µs)")["header_cell"] == "IO Time (µs)"
    w = prof["written_as"]
    assert w["separator"] == {"value": ";", "name": "semicolon", "decided": True, "how": d["separator_how"]}
    assert w["header"]["line"] == 1 and w["header"]["lines_before"] == [] and w["encoding"]["value"] == "UTF-8"
    took = col(prof, "IO Time (µs)")
    assert took["rows_with_value"] == 5000 and took["distinct"] == 1500
    ns = took["number_style"]
    assert ns["style"] == "decimal comma" and ns["decimal_sign"] == "," and ns["thousands_sign"] == "."
    assert abs(ns["min"] - 87.2) < 1e-9 and abs(ns["max"] - (87.2 + 1499 * 1.1)) < 1e-6 and ns["min_as_written"] == "87,200"
    assert ns["counts"]["values_with_a_decimal_comma"] > 0 and ns["counts"]["values_with_one_comma_and_three_digits_after"] > 0
    assert "decimal comma" in ns["how"] and "thousands" in ns["how"]
    init = col(prof, "Init Time (s)")["number_style"]
    assert init["style"] == "decimal comma" and init["thousands_sign"] is None and abs(init["min"] - 1.0799438) < 1e-9
    size = col(prof, "Size (B)")
    assert size["type"] == "integer" and (size["min"], size["max"]) == (512, 4096) and "number_style" not in size
    assert col(prof, "Min Offset")["type"] == "hex" and "number_style" not in col(prof, "Min Offset")
    assert col(prof, "IO Type")["top_values"][0]["count"] == 1667
    inv = family1.inventory(str(tmp_path))
    assert len(inv) == 1 and inv[0]["columns"] == 14 and inv[0]["written_as"]["separator"]["name"] == "semicolon"


@pytest.mark.parametrize("sep,name", [("\t", "tab"), ("|", "vertical bar")])
def test_tab_and_vertical_bar(tmp_path, sep, name):
    path = write_wpa(str(tmp_path / "table.csv"), n=3000, sep=sep, end="\n")
    d = CD.detect(path)
    assert d["separator"] == sep and d["separator_name"] == name and d["separator_decided"] and d["header_line"] == 1
    prof, _did = both(path)
    assert prof["rows"] == 3000 and prof["columns_in_file"] == 14 and prof["written_as"]["separator"]["name"] == name
    assert col(prof, "IO Time (µs)")["number_style"]["style"] == "decimal comma"


def test_three_title_lines_before_the_header(tmp_path):
    before = ["Disk report of the bench laptop", "Exported 2026-11-14 10:02; profile DiskIO", ""]
    path = write_wpa(str(tmp_path / "titled.csv"), n=4000, before=before)
    d = CD.detect(path)
    assert d["header_line"] == 4 and d["lines_before"] == before and d["lines_before_count"] == 3 and d["separator"] == ";"
    assert "line 4" in d["header_how"] and "kept as lines before the header" in d["header_how"]
    prof, _did = both(path)
    assert prof["rows"] == 4000 and [c["column"] for c in prof["columns"]] == WPA_HEADER.split(";")
    assert prof["written_as"]["header"]["line"] == 4 and prof["written_as"]["header"]["lines_before"] == before       # shown, never thrown away
    first = col(prof, "IO Type")["top_values"][0]["rows"][0]
    assert family1.where(path, [first]).endswith("line %d" % (first + 4))        # row 1 of the data is line 5 of this file
    # the same table without the title lines: the same columns and counts
    plain = family1.full_profile(write_wpa(str(tmp_path / "plain.csv"), n=4000), None)
    assert difference(prof, plain, skip=("seconds", "path", "written_as")) == ""
    # with a comma file too, and a quotation mark in a title line
    path = str(tmp_path / "comma_titled.csv")
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write('Report of the 5" drive\nsecond title line\nthird\nid,name,value\n' + "".join("%d,n%d,%d\n" % (i, i % 5, i % 9) for i in range(300)))
    d = CD.detect(path)
    assert d["separator"] == "," and d["header_line"] == 4 and d["lines_before"][0] == 'Report of the 5" drive' and not d["as_before"]
    prof = family1.full_profile(path, None)
    assert prof["rows"] == 300 and [c["column"] for c in prof["columns"]] == ["id", "name", "value"]


@pytest.mark.parametrize("encoding,mark,codec", [("utf-16-le", b"\xff\xfe", "utf-16-le"), ("utf-16-be", b"\xfe\xff", "utf-16-be"), ("utf-16-le", b"", "utf-16-le")])
def test_utf16(tmp_path, encoding, mark, codec):
    twin = family1.full_profile(write_wpa(str(tmp_path / "utf8.csv"), n=3000), None)
    path = str(tmp_path / "utf16.csv")
    write_wpa(path, n=3000, encoding=encoding)
    if mark:
        with open(path, "rb") as fh:
            body = fh.read()
        with open(path, "wb") as fh:
            fh.write(mark + body)
    d = CD.detect(path)
    assert d["codec"] == codec and d["bom_bytes"] == len(mark) and d["separator"] == ";" and d["refused"] is None
    assert ("byte order mark" in d["encoding_how"]) if mark else ("zero as second byte" in d["encoding_how"])
    prof, did = both(path, parallel=False)              # a part must be cut on a character boundary: such a file is read on one core
    assert "UTF-16" in did["why"] and "byte by byte" in did["why"]
    assert prof["written_as"]["encoding"]["value"].startswith("UTF-16")
    assert prof["columns"][0]["column"] == "IO Type"    # the byte order mark is not part of the first header cell
    assert difference(prof, twin, skip=("seconds", "path", "written_as")) == ""        # the same table as its UTF-8 twin


def test_quoted_cell_with_the_separator_and_a_line_break(tmp_path):
    path = str(tmp_path / "quoted.csv")
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write("id;note;value\r\n")
        for i in range(4000):
            fh.write('%d;"first; second\r\nline two of %d";%s\r\n' % (i, i % 7, regional(i / 8.0, 3)))
    d = CD.detect(path)
    assert d["separator"] == ";" and d["header_line"] == 1
    prof, _did = both(path, parallel=None)
    assert prof["rows"] == 4000 and prof["columns_in_file"] == 3
    assert col(prof, "note")["distinct"] == 7 and col(prof, "note")["top_values"][0]["value"].startswith("first; second\r\nline two of")


def test_a_part_boundary_inside_a_quoted_cell_is_read_on_one_core(tmp_path):
    path = str(tmp_path / "cut_in_cell.csv")
    with open(path, "wb") as fh:
        fh.write(b"id;name;value\n")
        for i in range(8000):
            fh.write(b"%d;name %d;%d\n" % (i, i % 40, i % 9))
        fh.write(b'8000;5" disk;1\n8001;"a cell of many lines\n')            # by the count of quotes the cell looks closed where it is open
        for i in range(5000):
            fh.write(b"line %d of the cell; with a semicolon\n" % i)
        fh.write(b'the end of the cell";2\n')
        for i in range(8002, 12000):
            fh.write(b"%d;name %d;%d\n" % (i, i % 40, i % 9))
    prof, did = both(path, parallel=False)
    assert "quoted cell" in did["why"] and prof["rows"] == 12000 and prof["written_as"]["separator"]["name"] == "semicolon"


def test_a_part_boundary_inside_a_utf16_character_cannot_happen(tmp_path):
    """Parts of 1,001 bytes would end between the two bytes of a character: a UTF-16 file is never cut, with the reason stated."""
    path = write_wpa(str(tmp_path / "wide.csv"), n=4000, encoding="utf-16-le")
    with open(path, "rb") as fh:
        body = fh.read()
    with open(path, "wb") as fh:
        fh.write(b"\xff\xfe" + body)
    prof, did = both(path, parallel=False, chunk_bytes=1001)
    assert "UTF-16" in did["why"] and prof["rows"] == 4000 and col(prof, "IO Time (µs)")["number_style"]["style"] == "decimal comma"
    assert all("\x00" not in c["column"] and "�" not in c["column"] for c in prof["columns"])


# ---------------------------------------------------------------------------------------------- numbers that do not decide
def test_a_column_of_1_234_values_is_ambiguous(tmp_path):
    path = str(tmp_path / "counts.csv")
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write("id;amount;price;big;both\n")
        for i in range(500):
            fh.write("%d;%d,%03d;%d,%02d;%s;%s\n" % (i, 1 + i % 9, i % 1000, i % 50, i % 100, "{:,}".format(1000000 + i), ("1,5", "2.5")[i % 2]))
    prof, _did = both(path, parallel=None)
    ns = col(prof, "amount")["number_style"]
    assert ns["style"] == "ambiguous" and ns["decimal_sign"] is None and ns["thousands_sign"] is None and "min" not in ns and "max" not in ns
    assert "ambiguous" in ns["how"] and "1,000" in ns["how"] and ns["counts"]["values_with_one_comma_and_three_digits_after"] == 500
    assert col(prof, "amount")["type"] == "text" and "min" not in col(prof, "amount")       # never silently read as 1.234 or as 1234
    price = col(prof, "price")["number_style"]
    assert price["style"] == "decimal comma" and price["max"] == 49.99
    big = col(prof, "big")["number_style"]                                                  # 1,000,499: the comma stands between thousands
    assert big["style"] == "decimal point" and big["thousands_sign"] == "," and (big["min"], big["max"]) == (1000000.0, 1000499.0)
    mixed = col(prof, "both")["number_style"]
    assert mixed["style"] == "mixed" and "could not tell" in mixed["how"] and "min" not in mixed
    # the function alone
    assert CD.number_style({"1,234": 3, "22,100": 1})["style"] == "ambiguous"
    assert CD.number_style({"1.234": 3})["style"] == "ambiguous"
    assert CD.number_style({"1,234": 3, "0,5": 1})["style"] == "decimal comma"
    assert CD.number_style({"1.360,300": 1, "87,200": 5})["min"] == 87.2
    assert CD.number_style({"20,726,984.943082": 1, "12": 2})["max"] == 20726984.943082
    assert CD.number_style({"0.5": 1, "12.25": 4, "7": 1}) is None          # plain decimal points: read as they stand, nothing to tell
    assert CD.number_style({"12": 1, "7": 1}) is None and CD.number_style({"Read": 5, "1,5": 1}) is None


def test_two_separators_that_tie(tmp_path):
    path = str(tmp_path / "tie.csv")
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write("a;b,c\n" + "".join("%d;%d,%d\n" % (i, i + 1, i + 2) for i in range(40)))
    d = CD.detect(path)
    assert d["refused"] is None and not d["separator_decided"] and d["separator"] == "," and not d["as_before"]
    assert d["separator_how"].startswith("could not tell: comma and semicolon fit equally well") and "the comma is used" in d["separator_how"]
    prof = family1.full_profile(path, None)
    assert [c["column"] for c in prof["columns"]] == ["a;b", "c"] and prof["rows"] == 40
    assert prof["written_as"]["separator"]["decided"] is False and "could not be told" in prof["written_as"]["text"]


# ---------------------------------------------------------------------------------------------- the smallest files, and files that are no table
def test_an_empty_file_and_a_file_of_one_line(tmp_path):
    empty = str(tmp_path / "empty.csv")
    open(empty, "wb").close()
    d = CD.detect(empty)
    assert d["refused"] is None and "the file is empty (0 bytes)" in d["separator_how"]
    prof = family1.full_profile(empty, None)
    assert prof["rows"] == 0 and prof["columns_in_file"] == 0 and prof["columns"] == []
    one = str(tmp_path / "one.csv")
    with open(one, "w", encoding="utf-8", newline="") as fh:
        fh.write("time;value;unit\n")
    d = CD.detect(one)
    assert d["separator"] == ";" and d["separator_decided"] and "one line" in d["separator_how"]
    prof = family1.full_profile(one, None)
    assert prof["rows"] == 0 and [c["column"] for c in prof["columns"]] == ["time", "value", "unit"]
    plain = str(tmp_path / "plain_one.csv")
    with open(plain, "w", encoding="utf-8", newline="") as fh:
        fh.write("time,value,unit\n")
    assert CD.detect(plain)["as_before"] and "written_as" not in family1.full_profile(plain, None)
    names = [f["name"] for f in family1.inventory(str(tmp_path))]
    assert names == ["empty.csv", "one.csv", "plain_one.csv"] and family1.refused_files(str(tmp_path)) == []


def test_files_that_are_no_table_are_refused_and_the_others_go_on(tmp_path):
    with open(str(tmp_path / "picture.csv"), "wb") as fh:           # binary content under a .csv name
        fh.write(b"\x89PNG\r\n\x1a\n" + bytes(range(256)) * 64 + os.urandom(8192))
    with open(str(tmp_path / "noise.csv"), "wb") as fh:             # no zero byte, and no text either
        fh.write(bytes([1, 2, 3, 4, 5, 6, 7, 8, 65, 66, 14, 15, 16, 10]) * 500)
    with open(str(tmp_path / "words.csv"), "w", encoding="utf-8") as fh:        # one cell on every line
        fh.write("".join("line %d of a log without any separator\n" % i for i in range(200)))
    with open(str(tmp_path / "ragged.csv"), "w", encoding="utf-8") as fh:       # the lines do not agree on a number of cells
        fh.write("".join(",".join("c%d" % k for k in range(1 + (i * 5) % 11)) + "\n" for i in range(300)))
    with open(str(tmp_path / "good.csv"), "w", encoding="utf-8") as fh:
        fh.write("Command,Queue,Latency_us\n" + "".join("Read,%d,%d\n" % (i % 4, 80 + i) for i in range(100)))
    refused = {r["name"]: r["why"] for r in family1.refused_files(str(tmp_path))}
    assert sorted(refused) == ["noise.csv", "picture.csv", "ragged.csv", "words.csv"]
    assert "zero bytes" in refused["picture.csv"] and "not a text file" in refused["picture.csv"]
    assert "are control characters" in refused["noise.csv"] and "not a text file" in refused["noise.csv"]
    assert "every one of its first 200 lines is one cell only" in refused["words.csv"]
    assert "more than 50% of its first lines have another number of cells" in refused["ragged.csv"]
    assert all(why.startswith(name + " cannot be read as a table: ") and why.endswith(".") for name, why in refused.items())
    assert [f["name"] for f in family1.inventory(str(tmp_path))] == ["good.csv"]         # the other file of the folder goes on
    assert family1.full_profile(str(tmp_path / "good.csv"), None)["rows"] == 100
    for name in refused:                                                                # asked directly, the same sentence on both readings
        for read in (family1.full_profile, lambda p, lv: PP.full_profile_parallel(p, lv, **SMALL), lambda p, lv: PP.sequential_state(p, lv)):
            with pytest.raises(L.BadFile) as e:
                read(str(tmp_path / name), None)
            assert str(e.value) == refused[name]
    # the director's step (the list of the folder's files Family 1 starts from) carries each refused file with its sentence
    said = []
    ctx = type("Ctx", (), {"step": {"key": "director"}, "project": {"folder": str(tmp_path), "refs": "[]"}, "progress": lambda self, text: said.append(text)})()
    out = family1.run_step(ctx).output
    assert [f["name"] for f in out["files"]] == ["good.csv"]
    assert [r["line"] for r in out["refused"]] == ["Not read as a table: %s: %s" % (n, refused[n]) for n in sorted(refused)]
    assert out["refused_text"].count("\n") == 3 and len(said) == 1 and said[0].endswith("And 1 more file not read as a table: each is listed with its reason under Details.")


def test_what_the_models_and_the_column_search_are_given_is_the_stored_record(tmp_path):
    """The record of this module as the readers after it use it: the Data Explorer's model gets the column's number style in the
    words of number_style(), the Data Grounder's model gets the record's own sentence, and the search for a column that holds
    some values reads the file with the separator, the encoding and the header line that detect() decided."""
    from agentic import column_match as CM
    path = write_wpa(str(tmp_path / "disk.csv"), n=600, encoding="utf-16", before=["Disk report", "second line"])
    d = CD.detect(path)
    assert (d["separator_name"], d["header_line"], d["codec"].startswith("utf-16")) == ("semicolon", 3, True)
    prof = family1.full_profile(path, None)
    col = next(c for c in prof["columns"] if c["column"] == "IO Time (µs)")
    assert family1._slim(col)["number_style"] == col["number_style"]["how"][:family1.FORM_STYLE_CHARS]
    assert family1._written_words(prof["written_as"]) == {"text": CD.record(d)["text"], "lines_before_the_header": ["Disk report", "second line"]}
    sig = {"file": "disk.csv", "path": path, "column": "IO Type", "position": 0}
    cands = [{"sig": sig}, {"sig": dict(sig, column="Process (Name)", position=2)}, {"sig": dict(sig, column="Gone", position=40)}]
    CM.exact_counts(cands, {"values": ["flush", "system"]})
    assert cands[0]["exact"] == {"rows_holding": 200, "found": ["flush"], "lines": [6, 9, 12, 15, 18], "rows_read": 600, "capped": False}
    assert cands[1]["exact"]["rows_holding"] == 200 and cands[1]["exact"]["found"] == ["system"] and cands[1]["exact"]["lines"][0] == 4
    assert cands[2]["exact"] == {"problem": "the header of disk.csv has no column Gone now"}


def test_a_file_written_as_before_is_decided_and_not_marked(tmp_path):
    path = str(tmp_path / "bench_log.csv")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("Command,Queue,Latency_us,Result\n" + "".join("Read,%d,%d,ok\n" % (i % 4, 80 + i) for i in range(200)))
    d = CD.detect(path)
    assert d["as_before"] and d["separator_decided"] and "comma gives 4 cells on 201 of the 201 lines from line 1 on" in d["separator_how"]
    prof = family1.full_profile(path, None)
    assert "written_as" not in prof and not any("number_style" in c for c in prof["columns"])
    assert "written_as" not in family1.inventory(str(tmp_path))[0]
    with open(path, "wb") as fh:                                    # a byte order mark and Latin-1 bytes: read as before
        fh.write(b"\xef\xbb\xbfname,size\n" + b"caf\xe9,1\n" * 50)
    d = CD.detect(path)
    assert d["as_before"] and "not UTF-8" in d["encoding_how"] and family1.full_profile(path, None)["columns"][0]["column"] == "name"


# ---------------------------------------------------------------------------------------------- what reaches the dictionary
class _Ctx:
    """The little of a step's context the Manager's code uses: where the Explorer's memory is, and a folder to write into."""

    def __init__(self, box, memory_file):
        self.box, self.memory_file = box, memory_file
        self.input, self.project, self.run = {}, {"admin": "Sagar"}, {"id": 1}
        self.engine = self
        self.runner = self

    def sandbox(self, _run, name):
        d = os.path.join(self.box, name)
        os.makedirs(d, exist_ok=True)
        return d

    def output_of(self, key):
        return {"memory_file": self.memory_file} if key.startswith("explore:") else {}


def _dictionary(tmp_path, path):
    f = next(x for x in family1.inventory(os.path.dirname(path)) if x["path"] == path)
    memory = dict(family1.full_profile(path, f["level"]), summary="a table", agent="Data Explorer")
    for c in memory["columns"]:
        c["observed"] = ""
    mem = str(tmp_path / ("memory_%s.json" % f["name"]))
    with open(mem, "w", encoding="utf-8") as fh:
        json.dump(memory, fh)
    family1._manager(_Ctx(str(tmp_path / "boxes"), mem), f)
    with open(str(tmp_path / "boxes" / ("manager_" + f["name"]) / "dictionary.json"), encoding="utf-8") as fh:
        return json.load(fh)


def test_the_dictionary_says_how_the_file_is_written(tmp_path):
    folder = tmp_path / "folder"
    folder.mkdir()
    d = _dictionary(tmp_path, write_wpa(str(folder / "disk.csv"), n=600, before=["Disk report"]))
    w = d["written_as"]
    assert w["separator"]["name"] == "semicolon" and w["separator"]["how"] and w["encoding"]["how"] and w["header"]["how"]
    assert w["header"]["line"] == 2 and w["header"]["lines_before"] == ["Disk report"] and "header on line 2" in w["text"]
    rows = {r["column"]: r for r in d["columns"]}
    assert list(rows) == WPA_HEADER.split(";") and d["rows"] == 600               # the header text exactly, the unit in it
    assert rows["IO Time (µs)"]["number_style"]["style"] == "decimal comma" and rows["IO Time (µs)"]["number_style"]["min"] == 87.2
    assert rows["IO Type"]["where"].split(",")[0].endswith("disk.csv line 5")     # "Flush" first stands in row 3 of the data: line 5 of the file (a title line, the header, two rows)
    assert "number_style" not in rows["Size (B)"]
    plain = str(folder / "plain.csv")
    with open(plain, "w", encoding="utf-8") as fh:
        fh.write("Command,Queue,Latency_us\n" + "".join("Read,%d,%d\n" % (i % 4, 80 + i) for i in range(100)))
    d = _dictionary(tmp_path, plain)
    assert "written_as" not in d and not any("number_style" in r for r in d["columns"]) and d["columns"][0]["where"].split(",")[0].endswith("plain.csv line 2")


# ---------------------------------------------------------------------------------------------- the samples: nothing changes
def _released_family1():
    """family1.py of the released zip, loaded beside the present modules (its reading functions use nothing that changed)."""
    if not os.path.exists(RELEASED_ZIP):
        pytest.skip("the released zip is not here: %s" % RELEASED_ZIP)
    with zipfile.ZipFile(RELEASED_ZIP) as z:
        src = z.read("13_production_app/agentic/family1.py").decode("utf-8")
    spec = importlib.util.spec_from_loader("agentic._family1_released", loader=None, origin=RELEASED_ZIP)
    mod = importlib.util.module_from_spec(spec)
    mod.__file__ = os.path.join(APP, "agentic", "family1.py")
    mod.__package__ = "agentic"
    exec(compile(src, "family1.py (released)", "exec"), mod.__dict__)
    return mod


def test_the_samples_keep_their_profile_byte_for_byte():
    old = _released_family1()
    was, now = old.inventory(S08), family1.inventory(S08)
    assert json.dumps(was, sort_keys=True) == json.dumps(now, sort_keys=True) and len(now) == 5
    for f in now:
        d = CD.detect(f["path"])
        assert d["as_before"] and d["separator_decided"], (f["name"], d)
        a, b = old.full_profile(f["path"], f["level"]), family1.full_profile(f["path"], f["level"])
        a.pop("seconds"), b.pop("seconds")
        assert json.dumps(a, indent=1) == json.dumps(b, indent=1), f["name"]            # the same text, key order included
        assert old.where(f["path"], [1, 7]) == family1.where(f["path"], [1, 7])
        assert old.blank_header_positions(f["path"]) == family1.blank_header_positions(f["path"])
    f = next(x for x in now if x["name"] == "nvme_command.csv")
    c = PP.full_profile_parallel(f["path"], f["level"], **SMALL)
    a = old.full_profile(f["path"], f["level"])
    a.pop("seconds"), c.pop("seconds")
    assert json.dumps(a, indent=1) == json.dumps(c, indent=1)


# ---------------------------------------------------------------------------------------------- 60 MB in parts and on one core
def _rss():
    try:
        import psutil
        return psutil.Process().memory_info().rss
    except Exception:       # noqa: BLE001 - no psutil here: the memory is not measured, the comparison still runs
        return None


def test_sixty_megabytes_in_parts_equal_one_core(tmp_path):
    path = str(tmp_path / "sixty.csv")
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write("Report of a long run\r\n" + WPA_HEADER + "\r\n")
        block = "".join(";".join(r) + "\r\n" for r in wpa_rows(20000))
        while fh.tell() < 60 * 1024 * 1024:
            fh.write(block)
    mb = os.path.getsize(path) / 1024.0 ** 2
    rss0 = _rss()
    t = time.time()
    a = family1.full_profile(path, None)
    one = time.time() - t
    rss1 = _rss()
    t = time.time()
    b = PP.full_profile_parallel(path, None, workers=4, min_bytes=0)         # the part size the application takes by itself
    many = time.time() - t
    rss2 = _rss()
    did = dict(PP.LAST)
    assert difference(a, b) == "" and did["parallel"], did
    assert a["rows"] % 20000 == 0 and a["rows"] >= 500000 and a["written_as"]["header"]["line"] == 2
    assert col(a, "IO Time (µs)")["number_style"]["style"] == "decimal comma"
    grown = "not measured (no psutil)" if rss0 is None else "one core +%.1f MB, in parts +%.1f MB in this process" % (
        (rss1 - rss0) / 1024.0 ** 2, (rss2 - rss1) / 1024.0 ** 2)
    try:                    # the largest worker process, where the system says it (not on Windows)
        import resource
        grown += "; the largest worker process held %.0f MB at its peak" % (resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss / 1024.0)
    except Exception:       # noqa: BLE001
        pass
    line = "TIME  %.0f MB, %s rows, semicolon: one core %.1f s; %d workers %.1f s (%d parts); memory growth: %s" % (
        mb, "{:,}".format(a["rows"]), one, did["workers"], many, did["parts"], grown)
    print("\n" + line, flush=True)
    with open(str(tmp_path / "measured.txt"), "w", encoding="utf-8") as fh:
        fh.write(line + "\n")
    if rss0 is not None:
        assert rss2 - rss0 < 400 * 1024 * 1024, line        # bounded: far below the size of a recording, whatever the file's size
