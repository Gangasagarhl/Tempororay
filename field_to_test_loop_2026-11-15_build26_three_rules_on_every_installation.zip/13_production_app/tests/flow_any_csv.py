"""A whole flow, offline, with the stand-in (no model): a folder of one CSV that is not an analyzer export; no tree.
Usage: python3 tests/flow_any_csv.py [a temporary folder]   (no server; its own store, knowledge folder and engine)
Then the finished flow is opened again at the rules (nothing may be computed again), and at the data with one new CSV
(only the new file may be read)."""
import json, os, random, sys, time
APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (APP, os.path.join(APP, "app")):
    sys.path.insert(0, p)
ITEM = "analytics/other/share_of_each_command"
ITEM2 = "errors/other/timed_out_commands"         # (2026-11-14) a rule of the section that finds defects, on the same file: its rows become errors
BAD = []


def check(what, ok, detail=""):
    print("%s  %s%s" % ("PASS" if ok else "FAIL", what, ("  | %s" % (detail,)) if detail != "" else ""))
    if not ok:
        BAD.append(what)


def main():
    root = sys.argv[1]
    from agentic import admin_ask, core, family1, family3, pipeline, procedures as PR
    know = os.path.join(root, "knowledge")
    family1.knowledge_dir = lambda: know
    folder = os.path.join(root, "bench")
    os.makedirs(folder, exist_ok=True)
    random.seed(7)
    with open(os.path.join(folder, "bench_log.csv"), "w", encoding="utf-8") as fh:
        fh.write("Command,Queue,Latency_us,Result\n")
        for i in range(300):
            fh.write("%s,%d,%d,%s\n" % (random.choice(["Read"] * 6 + ["Write"] * 3 + ["Flush"]), random.randint(1, 4), random.randint(80, 9000), "ok" if i % 50 else "timeout"))
    store = core.Store(os.path.join(root, "db", "agentic.sqlite"))
    runner = core.AgentRunner(os.path.join(root, "runs"), runtime="standin", web=False)
    eng = core.Engine(store, {"flow": pipeline}, runner, cfg={})
    pid = store.exec("INSERT INTO project (admin, name, folder, refs, created, updated) VALUES (?,?,?,?,?,?)", ("Sagar", "bench", folder, "[]", time.time(), time.time()))
    rid = eng.start(pid, "flow", "", {"started_by": "Sagar"})

    def steps():
        return store.all("SELECT * FROM step WHERE run=? ORDER BY idx", (rid,))

    def drive(decider, limit=240):
        """Decide every review as decider(key, review) -> (decision, edits, comment) says, until the flow finishes."""
        seen, t0 = [], time.time()
        while time.time() - t0 < limit:
            run = store.one("SELECT * FROM run WHERE id=?", (rid,))
            failed = store.one("SELECT key, error FROM step WHERE run=? AND state='failed'", (rid,))
            if failed:
                print("FAILED STEP", failed["key"], "\n", failed["error"][:1500])
                BAD.append("a step failed: " + failed["key"])
                return seen
            if run["state"] != "running":
                return seen
            rv = store.one("SELECT * FROM review WHERE run=? AND state='open' ORDER BY id LIMIT 1", (rid,))
            if not rv:
                time.sleep(0.2)
                continue
            key = store.one("SELECT key FROM step WHERE id=?", (rv["step"],))["key"]
            seen.append(key)
            dec, edits, comment = decider(key, rv)
            try:
                eng.decide(rv["id"], dec, "Sagar", comment, edits)
            except Exception as e:      # noqa: BLE001
                print("   DECIDE REFUSED at %s: %s" % (key, e))
                BAD.append("refused at " + key)
                return seen
        BAD.append("the flow did not finish in time")
        return seen

    # ---- 1. the first flow
    def first(key, rv):
        if key == admin_ask.GATE:
            d = json.loads(rv["data"])
            check("the fixed strategy is not offered for a folder without analyzer exports", d["stage2"]["fixed_possible"] is False, d["stage2"]["fixed_problem"][:70])
            return "approve", {"stage2": "skip"}, ""
        if key == "f3_plan":
            d = json.loads(rv["data"])
            sel = [i["key"] for i in d["items"] if i["selected"]]
            check("no item that cannot run here is ticked for the admin", sel == [], sel)
            check("every item of the library is said to be blocked, with its reason", all(i["blocked"] for i in d["items"]), [(i["name"], i["blocked"][:40]) for i in d["items"] if not i["blocked"]])
            return "approve", {"selected": [], "new": [{"section": "analytics", "level": "other", "name": "share of each command", "description": "percentage by Command"},
                                                       {"section": "errors", "level": "other", "name": "timed out commands", "description": "rows where Result is timeout"}]}, ""
        return "approve", None, ""
    seen = drive(first)
    run = store.one("SELECT * FROM run WHERE id=?", (rid,))
    check("the flow finished without a tree", run["state"] == "finished", run["summary"])
    check("the reviews came in order: dictionary, the step after Family 1, the plan, the procedure, Family 4's requirements, Family 4's code, the result",
          [k.split(":")[-1] if k.startswith("f3:") else k.split(":")[0] for k in seen] == ["manager", admin_ask.GATE, "f3_plan", "write", "req", "code", "result",
                                                                                           "write", "req", "code", "result", "errors_done"], seen)
    by0 = {s["key"]: s for s in steps()}
    f4 = [s for s in steps() if s["family"] == "4" and ITEM in s["key"]]
    check("Family 4 researches the data first, then the requirements, then the code (the research needs no decision)",
          [s["key"].split(":")[-1] for s in f4] == ["research", "req", "code"] and f4[0]["needs_review"] == 0, [(s["key"].split(":")[-1], s["state"]) for s in f4])
    rec = (json.loads(f4[0]["output"] or "{}").get("record") or {})
    check("the data research read the file once, whole, and counted the column the rule reads",
          bool(rec) and rec["files"][0]["file"] == "bench_log.csv" and rec["files"][0]["rows"] == 300 and rec["files"][0]["basis"] == "exact: all 300 rows"
          and [b["column"] for b in rec["files"][0]["touched"]] == ["Command"], (rec.get("files") or [{}])[0].get("basis"))
    check("the item's coding steps belong to Family 4", len(f4) >= 2 and all(s["state"] in ("done", "approved", "skipped") for s in f4), [(s["key"].split(":")[-1], s["state"]) for s in f4])
    by = {s["key"]: s for s in steps()}
    out = json.loads(by["f3:%s:run" % ITEM]["output"])
    check("the result is counted from the file itself (300 rows)", out["columns"] == ["Command", "count", "percent"] and sum(int(r[1]) for r in out["head"]) == 300, out["head"])
    check("the result names no upload (no tree)", out.get("upload_id") is None)
    rep = json.loads(by["report"]["output"]).get("files") or {}
    check("the report was written", bool(rep.get("html")) and os.path.exists(rep["html"]))
    check("Family 2 was skipped by the admin's word", all(s["state"] == "skipped" and s["note"] == admin_ask.F2_SKIP_NOTE for s in steps() if s["family"] == "2"))
    # ---- 1b. (2026-11-14) the rule of the errors section on the same file: its rows are errors of the analysis, with their own kind
    from agentic import other_errors as OE
    eo = json.loads(by["f3:%s:errors" % ITEM2]["output"] or "{}")
    slow = [i for i in range(1, 301) if (i - 1) % 50 == 0]          # the generator above writes "timeout" on every 50th row, the first one included
    check("the errors rule on the other file lists the rows it found as errors of their own kind (not as errors of the tree)",
          eo.get("kind") == OE.KIND and eo.get("errors") == [] and eo.get("total") == len(slow) and [x["row"] for x in eo.get("other_errors") or []] == slow
          and all(x["file"] == "bench_log.csv" and x["cells"][3] == "timeout" for x in eo["other_errors"]), (eo.get("total"), eo.get("refused")))
    check("the analytics item on the same file listed no error", "f3:%s:errors" % ITEM not in by and [x["item"] for x in OE.listings(eo.get("store") or "")] == [ITEM2])
    done = json.loads(by["errors_done"]["output"] or "{}")
    check("the errors of the tree are counted apart: none here, and the other file's errors beside them", done.get("errors") == 0 and done.get("patterns") == 0
          and done.get("other_errors") == len(slow) and done.get("other_patterns") == 1, done)
    one = (eo.get("other_errors") or [{}])[2]
    win = OE.window(eo["store"], one["error"], 3, 2)
    check("one error opened: its row and the rows around it, read from the file", [x["row"] for x in win["rows"]] == list(range(one["row"] - 3, one["row"] + 3))
          and win["rows"][3]["cells"] == one["cells"], [x["row"] for x in win["rows"]])
    d1 = OE.dictionary_of(folder, "bench_log.csv")
    iso = OE.isolate(eo["store"], one["error"], OE.column_meanings(d1, win["header"]), "rows where Result is timeout", "Sagar", 3, 2)
    check("the error isolated with the stand-in, clearly marked, and kept with who asked", iso["standin"] and iso["marked"].startswith("STAND-IN") and iso["answer"]["cited_rows"] == [one["row"]]
          and [(x["asked_by"], x["standin"]) for x in OE.isolations(eo["store"], one["error"])] == [("Sagar", True)], iso.get("producer"))
    rj = json.load(open(json.loads(by["report"]["output"])["files"]["json"], encoding="utf-8"))
    check("the report names the other file's errors apart", [(x["rule"], x["total"]) for x in rj.get("other_errors") or []] == [("timed out commands", len(slow))] and rj.get("errors") == [])
    stamp = {s["key"]: (s["started"], s["finished"], s["attempts"]) for s in steps()}

    # ---- 2. opened again at the rules: nothing is computed again
    pipeline.reopen(eng, rid, "rules", "Sagar")

    def again_rules(key, rv):
        if key == "f3_plan":
            check("the plan says the analysis was opened again", "This analysis was opened again" in rv["body"])
            return "approve", {"selected": [ITEM]}, ""
        BAD.append("an unexpected review after opening at the rules: " + key)
        return "approve", None, ""
    seen = drive(again_rules)
    by = {s["key"]: s for s in steps()}
    check("opened at the rules: only the plan asked again", seen == ["f3_plan"], seen)
    check("the item was kept, not computed again", "not computed again" in (json.loads(by["f3_plan"]["output"]).get("kept") or {}).get(ITEM, ""), json.loads(by["f3_plan"]["output"]).get("kept"))
    same = [k for k in stamp if k.startswith("f3:") and stamp[k] != (by[k]["started"], by[k]["finished"], by[k]["attempts"])]
    check("no step of the item ran again", same == [] and len(by) == len(stamp), same)
    check("the flow finished again and the report was written again", store.one("SELECT state FROM run WHERE id=?", (rid,))["state"] == "finished" and by["report"]["attempts"] == stamp["report"][2] + 1)

    # ---- 3. a new CSV arrives; opened again at the data: only the new file is read
    with open(os.path.join(folder, "thermal.csv"), "w", encoding="utf-8") as fh:
        fh.write("Sensor,Celsius\n" + "".join("%s,%d\n" % (random.choice(["nand", "controller"]), random.randint(30, 80)) for _ in range(120)))
    stamp = {s["key"]: (s["started"], s["finished"], s["attempts"]) for s in steps()}
    pipeline.reopen(eng, rid, "data", "Sagar")
    state = {"gates": 0}

    def again_data(key, rv):
        if key == admin_ask.GATE:
            state["gates"] += 1
            d = json.loads(rv["data"])
            if state["gates"] == 1:
                check("the step after Family 1 names the new file", d["new"] == ["thermal.csv"], d["new"])
                return "change", {"read_new": True}, "new CSV files were added to the folder"
            check("after the reading no file is new", d["new"] == [], d["new"])
            return "approve", {"stage2": "skip"}, ""
        if key == "f3_plan":
            return "approve", {"selected": [ITEM]}, ""
        return "approve", None, ""
    seen = drive(again_data)
    by = {s["key"]: s for s in steps()}
    check("opened at the data: the step, the new file's dictionary, the step again, the plan", seen == [admin_ask.GATE, "manager:thermal.csv", admin_ask.GATE, "f3_plan"], seen)
    old_files = [k for k in stamp if k.endswith(":bench_log.csv") and stamp[k] != (by[k]["started"], by[k]["finished"], by[k]["attempts"])]
    check("the file read before was not read again", old_files == [], old_files)
    check("the new file got its three agents", all(by.get("%s:thermal.csv" % a, {}).get("state") in ("done", "approved") for a in ("explore", "ground", "manager")))
    check("the item was kept again (its file did not change)", ITEM in (json.loads(by["f3_plan"]["output"]).get("kept") or {}))
    check("the flow finished", store.one("SELECT state FROM run WHERE id=?", (rid,))["state"] == "finished")
    chats = store.all("SELECT COUNT(*) AS n FROM review WHERE run=?", (rid,))[0]["n"]
    check("every card of every round is still with the flow", chats >= 9, chats)
    print("\n%d checks failed%s" % (len(BAD), (": " + "; ".join(BAD)) if BAD else ""))
    return 1 if BAD else 0


if __name__ == "__main__":
    import shutil
    import tempfile
    own = len(sys.argv) < 2             # no folder given: one of its own, removed afterwards
    if own:
        sys.argv.append(tempfile.mkdtemp(prefix="f2t_any_csv_"))
    try:
        rc = main()
    finally:
        if own:
            shutil.rmtree(sys.argv[1], ignore_errors=True)
    sys.exit(rc)
