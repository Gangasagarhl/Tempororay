"""The first question of the start page: which tool exported the recording (owner, 2026-11-12: "at the starting page ask
whether the analysis is going on for Windows ADK or Teledyne LeCroy or PCMark 10 ... there might not be need of building the
hierarchy by combining many different CSVs together, only it is needed for LeCroy Teledyne").

1. the list: the tools of the reference library in its order; only a ready one can be chosen, the others say why not.
2. the analysis keeps the chosen tool (project.source_tool), shows its name, and a step reads it as ctx.project["source_tool"];
   without the field nothing is stored; an unknown tool or one that is not ready is refused in plain words.
3. a database made by an earlier build gets the new column when the application starts, and keeps its rows.
4. the hierarchy: built unless the library says the chosen tool's export is one table; nothing changes for Teledyne LeCroy.
5. the answer for a tool that is not listed or not known (2026-11-14): accepted, stored under a reserved value that no
   library tool can take, named in plain words, no hierarchy with the reason; garbage is refused in plain words.
6. does a file look like the chosen tool: the reference library's own counting, one plain sentence per file.
No server and no model: Flask's test client on a database of its own."""
import json
import os
import sqlite3
import sys
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
for p in (APP_DIR, os.path.join(APP_DIR, "app")):
    if p not in sys.path:
        sys.path.insert(0, p)
from agentic import core, pipeline, source_tools as ST   # noqa: E402

LECROY, LECROY_NAME = "teledyne_lecroy_pcie", "Teledyne LeCroy PCIe Protocol Analysis"
WPA_NAME = "Windows Performance Analyzer (Windows Assessment and Deployment Kit)"
NOT_YET = ("not available yet: only the notes on its export are in the application. Until its column list is in the application, "
           "choose \"Another tool, or I do not know\" for its files")
CAN = "The answers that can be chosen: " + LECROY_NAME + ", \"Another tool, or I do not know\""
ANOTHER = "another_tool"


class QuietEngine(core.Engine):
    def kick(self, rid):            # runs are recorded, their steps are not executed
        pass


@pytest.fixture
def api(tmp_path, monkeypatch):
    from flask import Flask
    from api import agentic_api as A
    store = core.Store(str(tmp_path / "db" / "agentic.sqlite"))
    eng = QuietEngine(store, {"flow": pipeline}, runner=None)
    monkeypatch.setattr(A, "engine", lambda: eng)
    # what a folder must hold is not what is tested here: every folder passes as one with a packet-level file
    monkeypatch.setattr(A.family1, "inventory", lambda folder: [{"name": "packets.csv", "level": "packets", "bytes": 1}])
    monkeypatch.setattr(A.family1, "folder_problem", lambda found: None)
    app = Flask(__name__)
    app.config["services"] = types.SimpleNamespace(cfg={}, root=str(tmp_path))
    app.register_blueprint(A.bp)
    folder = tmp_path / "recording"
    folder.mkdir()
    yield app.test_client(), eng, str(folder)


def new(c, folder, name="analysis one", **more):
    return c.post("/api/agents/projects", json=dict({"admin": "Sagar", "name": name, "folder": folder}, **more))


def in_a_step(eng, pid):
    """The project as a step of a run sees it (ctx.project)."""
    return core.StepContext(eng, {"id": 0, "project": pid, "params": "{}"}, {"id": 0, "input": "{}"}).project


def own_library(tmp_path, tools):
    """A reference library of this test's own: every tool with "columns" gets a column list of one column."""
    root = tmp_path / "library"
    root.mkdir()
    for t in tools:
        if t.get("columns"):
            (root / t["key"]).mkdir()
            (root / t["columns"]).write_text(json.dumps({"entries": [{"name": "Time", "kind": "column", "meaning": "when the row happened"}], "sources": {}}))
    (root / "index.json").write_text(json.dumps({"tools": tools}))
    return str(root)


# ---------------------------------------------------------------------------------------------- 1. the list
def test_the_question_lists_the_library_tools_in_order_and_only_a_ready_one_can_be_chosen(api):
    c, _eng, _folder = api
    j = c.get("/api/agents/source_tools").get_json()
    assert j["question"] == "Which tool exported the recording you want to analyse?"
    assert [t["name"] for t in j["tools"]] == [LECROY_NAME, WPA_NAME, "PCMark 10 (UL Benchmarks)"]
    assert [t["available"] for t in j["tools"]] == [True, False, False]
    assert [t["sentence"] for t in j["tools"]] == ["", NOT_YET, NOT_YET]
    assert all(t["exports"] for t in j["tools"])
    # the hierarchy, in plain words under each tool
    assert [t["hierarchy"] for t in j["tools"]] == [True, False, False]
    assert j["tools"][0]["hierarchy_words"] == "its five exports of one recording are joined into one hierarchy"
    assert j["tools"][1]["hierarchy_words"] == j["tools"][2]["hierarchy_words"] == "one table per export: no hierarchy is built"
    # the list is the library's: nothing here is a list of the program's own
    index = json.load(open(os.path.join(APP_DIR, "reference_library", "index.json"), encoding="utf-8"))
    assert [t["key"] for t in j["tools"]] == [t["key"] for t in index["tools"]]
    # one more answer, after the list: a tool that is not listed, or not known. It is not one of the library's tools
    a = j["another"]
    assert a["key"] == ANOTHER == ST.ANOTHER and a["available"] is True and ANOTHER not in [t["key"] for t in index["tools"]]
    assert a["name"] == "Another tool, or I do not know (the agents learn the columns from the files themselves)"
    assert a["sentence"] == (
        "The three data agents read every CSV file of the folder and propose what each column means; each meaning says where it "
        "comes from, or says that it has no source to check. The application's reference document of a tool is used only for a file whose own "
        "column names match that tool's column list (at least 5 names and at least 30 in 100 of them); for every other file "
        "none is used. The files are not joined into one hierarchy by the fixed strategy: it joins only the exports of "
        "Teledyne LeCroy PCIe Protocol Analysis. Rules can be written on each file.")
    assert "choose the last answer" in j["why"] and "Nothing is chosen for you." in j["why"] and len(j["why"]) > 40


def test_why_a_tool_cannot_be_chosen_is_worded_from_the_library_status(tmp_path):
    root = own_library(tmp_path, [
        {"key": "ready_tool", "name": "Ready Tool", "exports": "one table", "columns": "ready_tool/columns.json", "status": "ready", "hierarchy": False},
        {"key": "notes_tool", "name": "Notes Tool", "status": "notes only: no column list yet"},
        {"key": "draft_tool", "name": "Draft Tool", "columns": "draft_tool/columns.json", "status": "draft: its column list is being checked"},
        {"key": "lost_tool", "name": "Lost Tool", "status": "ready"},                      # says ready, has no column list
        {"key": "bare_tool", "name": "Bare Tool"}])
    got = {t["key"]: t for t in ST.tools(root)}
    assert list(got) == ["ready_tool", "notes_tool", "draft_tool", "lost_tool", "bare_tool"]
    assert got["ready_tool"]["available"] and got["ready_tool"]["sentence"] == ""
    assert got["notes_tool"]["sentence"] == NOT_YET
    assert got["draft_tool"]["sentence"] == "not available yet: draft: its column list is being checked"
    assert got["lost_tool"]["sentence"] == "not available: its column list could not be read in this copy of the application"
    assert got["bare_tool"]["sentence"] == "not available yet: the reference library has no column list for it"
    assert [t["available"] for t in got.values()] == [True, False, False, False, False]
    # the hierarchy fact: the library's own words when it gives them, plain words otherwise, nothing when it says nothing
    assert got["ready_tool"]["hierarchy"] is False and got["ready_tool"]["hierarchy_words"] == "one table per export: no hierarchy is built"
    assert got["notes_tool"]["hierarchy"] is None and got["notes_tool"]["hierarchy_words"] == ""
    assert ST.check("ready_tool", root) == ("ready_tool", None)
    assert ST.check("lost_tool", root)[0] is None and "Lost Tool is not available" in ST.check("lost_tool", root)[1]


# ---------------------------------------------------------------------------------------------- 2. kept with the analysis
def test_a_new_analysis_keeps_the_chosen_tool_and_shows_its_name(api):
    c, eng, folder = api
    r = new(c, folder, source_tool=LECROY)
    assert r.status_code == 200, r.get_json()
    p = r.get_json()
    assert p["source_tool"] == LECROY and p["source_tool_name"] == LECROY_NAME
    assert eng.store.one("SELECT source_tool FROM project WHERE id=?", (p["id"],))["source_tool"] == LECROY
    assert in_a_step(eng, p["id"]).get("source_tool") == LECROY                 # what family1.exported_by reads
    listed = c.get("/api/agents/state").get_json()["projects"]
    assert [(x["source_tool"], x["source_tool_name"]) for x in listed] == [(LECROY, LECROY_NAME)]
    assert c.get("/api/agents/projects/%d" % p["id"]).get_json()["source_tool_name"] == LECROY_NAME


@pytest.mark.parametrize("more", [{}, {"source_tool": None}, {"source_tool": ""}])
def test_without_the_field_the_tool_is_recognised_from_the_files(api, more):
    # (changed 2026-11-15: the start page no longer asks; the files decide) without the field the tool recognised from the
    # files is stored. This fixture's stand-in file has no header to read, so no tool is recognised: "another_tool"
    c, eng, folder = api
    r = new(c, folder, **more)
    assert r.status_code == 200, r.get_json()
    p = r.get_json()
    assert p["source_tool"] == ANOTHER and p["source_tool_name"] == "another tool, or one that is not known"
    assert p["recognised"]["tool"] == ANOTHER and p["recognised"]["sentence"].startswith("Recognised from the files: no tool")
    assert in_a_step(eng, p["id"]).get("source_tool") == ANOTHER
    assert pipeline.needs_hierarchy(in_a_step(eng, p["id"])) is False


@pytest.mark.parametrize("value, words", [
    ("no_such_tool", "\"no_such_tool\" is not a tool the application knows"),
    ("windows_wpa", WPA_NAME + " is " + NOT_YET),
    ("pcmark10", "PCMark 10 (UL Benchmarks) is " + NOT_YET),
    (" Teledyne LeCroy ", "is not a tool the application knows"),
    (7, "must be given as text"), (["teledyne_lecroy_pcie"], "must be given as text"), ({"key": LECROY}, "must be given as text"), (True, "must be given as text")])
def test_an_unknown_tool_and_a_tool_that_is_not_ready_are_refused_in_plain_words(api, value, words):
    c, eng, folder = api
    r = new(c, folder, source_tool=value)
    assert r.status_code == 400
    err = r.get_json()["error"]
    assert words in err and err.endswith(CAN)
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 0             # nothing was made


def test_a_refused_tool_is_refused_before_the_folder_is_looked_at(api):
    c, _eng, _folder = api
    r = c.post("/api/agents/projects", json={"admin": "Sagar", "name": "x", "folder": "/no/such/folder", "source_tool": "windows_wpa"})
    assert r.status_code == 400 and NOT_YET in r.get_json()["error"]


def test_opening_the_same_analysis_again_keeps_or_takes_the_tool(api):
    c, eng, folder = api
    first = new(c, folder).get_json()
    assert first["source_tool"] == ANOTHER                                        # (2026-11-15) recognised from the files: none
    again = new(c, folder, source_tool=LECROY).get_json()                         # an older page sends an answer: taken as before
    assert again["reused"] is True and again["id"] == first["id"] and again["source_tool"] == LECROY
    third = new(c, folder).get_json()                                             # an older page sends nothing: what was said stays
    assert third["reused"] is True and third["source_tool"] == LECROY and third["source_tool_name"] == LECROY_NAME
    assert new(c, folder, source_tool="pcmark10").status_code == 400
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 1


def test_the_tool_can_be_set_and_removed_later_and_a_refused_one_changes_nothing(api):
    c, eng, folder = api
    pid = new(c, folder).get_json()["id"]
    url = "/api/agents/projects/%d" % pid
    r = c.put(url, json={"name": "another name", "source_tool": "windows_wpa"})
    assert r.status_code == 400 and NOT_YET in r.get_json()["error"]
    assert eng.store.one("SELECT name, source_tool FROM project WHERE id=?", (pid,)) == {"name": "analysis one", "source_tool": ANOTHER}
    assert c.put(url, json={"source_tool": LECROY}).get_json()["source_tool_name"] == LECROY_NAME
    assert c.put(url, json={"notes": "a note"}).get_json()["source_tool"] == LECROY     # another field leaves it alone
    assert c.put(url, json={"source_tool": None}).get_json()["source_tool"] is None


# ---------------------------------------------------------------------------------------------- 3. an earlier database
def test_a_database_of_an_earlier_build_gets_the_column_and_keeps_its_rows(tmp_path):
    path = str(tmp_path / "agentic.sqlite")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE project (id INTEGER PRIMARY KEY, admin TEXT, name TEXT, folder TEXT, refs TEXT, rea TEXT, "
                "upload_id TEXT, notes TEXT, created REAL, updated REAL)")
    con.execute("INSERT INTO project (admin, name, folder, refs, created, updated) VALUES ('Sagar', 'made before', '/data/rec', '[]', 1, 1)")
    con.commit()
    con.close()
    store = core.Store(path)
    row = store.one("SELECT * FROM project")
    assert "source_tool" in row and row["source_tool"] is None and row["name"] == "made before" and row["folder"] == "/data/rec"
    store.exec("UPDATE project SET source_tool=? WHERE id=?", (LECROY, row["id"]))
    again = core.Store(path)                                                     # the next start: nothing to add, nothing lost
    assert again.one("SELECT source_tool FROM project")["source_tool"] == LECROY
    con = sqlite3.connect(path)
    assert [r[1] for r in con.execute("PRAGMA table_info(project)")].count("source_tool") == 1
    con.close()


def test_a_new_database_has_the_column(tmp_path):
    store = core.Store(str(tmp_path / "new.sqlite"))
    con = store.con()
    assert "source_tool" in [r[1] for r in con.execute("PRAGMA table_info(project)")]
    con.close()


# ---------------------------------------------------------------------------------------------- 4. the hierarchy
def test_the_hierarchy_is_built_unless_the_library_says_the_tool_exports_one_table(tmp_path):
    # the shipped library: nothing changes for Teledyne LeCroy, nor for an analysis that was not asked
    for project in (None, {}, {"source_tool": None}, {"source_tool": ""}, {"source_tool": LECROY}, {"source_tool": "a tool the library dropped"}):
        assert pipeline.needs_hierarchy(project) is True
        assert ST.no_hierarchy_reason(project) == ""
    assert ST.needs_hierarchy({"source_tool": "pcmark10"}) is False
    assert ST.no_hierarchy_reason({"source_tool": "pcmark10"}) == "not needed for PCMark 10 (UL Benchmarks): its export is one table"
    # a library of this test's own: a ready tool whose export is one table, one whose exports are joined, one that says nothing
    root = own_library(tmp_path, [
        {"key": "one_table", "name": "One Table Tool", "columns": "one_table/columns.json", "status": "ready", "hierarchy": False},
        {"key": "joined", "name": "Joined Tool", "columns": "joined/columns.json", "status": "ready", "hierarchy": True},
        {"key": "silent", "name": "Silent Tool", "columns": "silent/columns.json", "status": "ready"},
        {"key": "odd", "name": "Odd Tool", "columns": "odd/columns.json", "status": "ready", "hierarchy": "no"}])
    assert ST.needs_hierarchy({"source_tool": "one_table"}, root) is False
    assert ST.no_hierarchy_reason({"source_tool": "one_table"}, root) == "not needed for One Table Tool: its export is one table"
    for key in ("joined", "silent", "odd"):                  # only a plain false switches the hierarchy off
        assert ST.needs_hierarchy({"source_tool": key}, root) is True and ST.no_hierarchy_reason({"source_tool": key}, root) == ""


# ---------------------------------------------------------------------------------------------- 5. another tool, or not known
def test_another_tool_is_accepted_stored_named_in_plain_words_and_asks_for_no_hierarchy(api):
    c, eng, folder = api
    r = new(c, folder, source_tool=ANOTHER)
    assert r.status_code == 200, r.get_json()
    p = r.get_json()
    assert p["source_tool"] == ANOTHER and p["source_tool_name"] == "another tool, or one that is not known"
    assert eng.store.one("SELECT source_tool FROM project WHERE id=?", (p["id"],))["source_tool"] == ANOTHER
    seen = in_a_step(eng, p["id"])                                               # what every later step reads
    assert seen.get("source_tool") == ANOTHER
    assert pipeline.needs_hierarchy(seen) is False and ST.needs_hierarchy(seen) is False
    assert ST.no_hierarchy_reason(seen) == (    # (changed 2026-11-15: the question is gone, the files decide)
        "not done for this analysis: its files were not recognised as exports of Teledyne LeCroy PCIe Protocol Analysis (or, for an "
        "analysis made before 15 November 2026, the answer on the start page was \"Another tool, or I do not know\"), and the "
        "fixed joining strategy joins only those exports. Start the same name on the same folder again from the start page: the "
        "files are looked at again and the tool is recognised from them")
    listed = c.get("/api/agents/state").get_json()["projects"]
    assert [(x["source_tool"], x["source_tool_name"]) for x in listed] == [(ANOTHER, "another tool, or one that is not known")]
    assert ANOTHER not in ST.name_of(ANOTHER) and "_" not in ST.name_of(ANOTHER)       # a screen never shows the stored value
    # the answer can be changed later, both ways, and the same analysis opened again takes it
    url = "/api/agents/projects/%d" % p["id"]
    assert c.put(url, json={"source_tool": LECROY}).get_json()["source_tool_name"] == LECROY_NAME
    assert c.put(url, json={"source_tool": ANOTHER}).get_json()["source_tool"] == ANOTHER
    again = new(c, folder, source_tool=LECROY).get_json()
    assert again["reused"] is True and again["source_tool"] == LECROY
    assert new(c, folder, source_tool=ANOTHER).get_json()["source_tool"] == ANOTHER


def test_the_reserved_value_can_never_be_a_library_tool(tmp_path):
    index = json.load(open(os.path.join(APP_DIR, "reference_library", "index.json"), encoding="utf-8"))
    assert ANOTHER not in [t["key"] for t in index["tools"]]
    # a library that lists a tool under the reserved value: the entry is not listed, and the value keeps its one meaning
    root = own_library(tmp_path, [
        {"key": ANOTHER, "name": "A Tool That Took The Reserved Value", "columns": ANOTHER + "/columns.json", "status": "ready", "hierarchy": True},
        {"key": "joined", "name": "Joined Tool", "columns": "joined/columns.json", "status": "ready", "hierarchy": True}])
    assert [t["key"] for t in ST.tools(root)] == ["joined"]
    assert ST.check(ANOTHER, root) == (ANOTHER, None)
    assert ST.name_of(ANOTHER, root) == "another tool, or one that is not known"
    assert ST.needs_hierarchy({"source_tool": ANOTHER}, root) is False
    assert "joins only the exports of Joined Tool." in ST.another(root)["sentence"]
    assert ST.folder_check(ANOTHER, [{"name": "a.csv", "columns": ["Time"]}], root) is None      # nothing is compared for it


@pytest.mark.parametrize("value, words", [
    (7, "must be given as text"), (0.5, "must be given as text"), ([ANOTHER], "must be given as text"), ({"key": ANOTHER}, "must be given as text"),
    ("x" * 5000, "is not a tool the application knows"),
    ("another_tool\x00", "\"another_tool?\" is not a tool the application knows"),
    ("\x00", "is not a tool the application knows"),
    ("Another_Tool", "\"Another_Tool\" is not a tool the application knows"),
    ("ANOTHER_TOOL", "\"ANOTHER_TOOL\" is not a tool the application knows"),
    ("another tool", "\"another tool\" is not a tool the application knows"),
    ("Another tool, or I do not know", "is not a tool the application knows")])
def test_garbage_for_the_tool_is_refused_in_plain_words(api, value, words):
    c, eng, folder = api
    r = new(c, folder, source_tool=value)
    assert r.status_code == 400
    err = r.get_json()["error"]
    assert words in err and err.endswith(CAN) and len(err) < 400 and "\x00" not in err and "Traceback" not in err
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 0
    pid = new(c, folder).get_json()["id"]                                        # and nothing changes in an analysis that exists
    assert c.put("/api/agents/projects/%d" % pid, json={"source_tool": value}).status_code == 400
    assert eng.store.one("SELECT source_tool FROM project WHERE id=?", (pid,))["source_tool"] == ANOTHER     # as recognised (2026-11-15)


def test_a_row_of_an_older_database_with_no_tool_behaves_as_before(tmp_path):
    path = str(tmp_path / "agentic.sqlite")
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE project (id INTEGER PRIMARY KEY, admin TEXT, name TEXT, folder TEXT, refs TEXT, rea TEXT, "
                "upload_id TEXT, notes TEXT, created REAL, updated REAL)")
    con.execute("INSERT INTO project (admin, name, folder, refs, created, updated) VALUES ('Sagar', 'made before', '/data/rec', '[]', 1, 1)")
    con.commit()
    con.close()
    row = core.Store(path).one("SELECT * FROM project")
    assert row["source_tool"] is None
    assert ST.name_of(row["source_tool"]) == "" and ST.needs_hierarchy(row) is True and ST.no_hierarchy_reason(row) == ""
    assert pipeline.needs_hierarchy(row) is True and ST.check(row["source_tool"]) == (None, None)
    assert ST.folder_check(row["source_tool"], [{"name": "a.csv", "columns": ["Time"]}]) is None


# ---------------------------------------------------------------------------------------------- 6. does a file look like the tool
def real_headers():
    with open(os.path.join(APP_DIR, "data", "lecroy_real_headers.json"), encoding="utf-8") as fh:
        return {name: list(recs[0]["columns"].values()) for name, recs in json.load(fh)["files"].items()}


def test_a_file_looks_like_the_tool_by_the_librarys_own_counting_and_limits():
    from agentic import column_knowledge as CK
    lib = CK.library()
    for name, cols in real_headers().items():                                   # the five real exports look like it
        got = ST.looks_like(LECROY, cols)
        assert got["looks"] is True and lib.recognise(cols)[0] == LECROY, name
        assert (got["names"], got["found"]) == (lib.names_found(LECROY, cols)["names"], lib.names_found(LECROY, cols)["found"])
    one = sorted(real_headers().items())[0][1]
    known = [n for n in dict.fromkeys(one) if lib.names_found(LECROY, [n])["found"]][:CK.RECOGNISE_LEAST + 1]
    assert len(known) == CK.RECOGNISE_LEAST + 1
    made_up = ["Feld %03d" % i for i in range(40)]
    # the same two limits as the recognition without a choice: at least 5 names, and at least 30 in 100 of them
    for cols in (made_up, made_up + known[:1], made_up + known[:4], made_up[:2] + known[:4], made_up + known, made_up[:11] + known[:5],
                 made_up[:12] + known[:5], known[:5], []):
        assert ST.looks_like(LECROY, cols)["looks"] is (lib.recognise(cols)[0] == LECROY), cols
    assert ST.looks_like(LECROY, made_up + known[:1])["looks"] is False            # one name in common is not that tool's export
    assert ST.looks_like(LECROY, made_up[:11] + known[:5])["looks"] is True and ST.looks_like(LECROY, made_up[:12] + known[:5])["looks"] is False
    for key in (None, "", ANOTHER, "windows_wpa", "no_such_tool"):              # nothing to compare with
        assert ST.looks_like(key, known) is None


def test_the_folder_check_says_one_plain_sentence_per_file():
    heads = real_headers()
    one = sorted(heads.items())[0][1]
    known = [n for n in dict.fromkeys(one) if ST.looks_like(LECROY, [n])["found"]][:3]
    made_up = ["Feld %03d" % i for i in range(20)]
    got = ST.folder_check(LECROY, [{"name": "packets.csv", "columns": one}, {"name": "bench.csv", "columns": made_up},
                                   {"name": "mixed.csv", "columns": made_up + known}, {"name": "locked.csv", "columns": None}])
    assert got["tool_name"] == LECROY_NAME and got["doubt"] == ["bench.csv", "mixed.csv"] and (got["least"], got["in_100"]) == (5, 30)
    by = {f["name"]: f for f in got["files"]}
    assert [by[n]["looks"] for n in ("packets.csv", "bench.csv", "mixed.csv", "locked.csv")] == [True, False, False, None]
    assert by["packets.csv"]["sentence"].startswith("packets.csv looks like an export of " + LECROY_NAME + ": ")
    assert by["bench.csv"]["sentence"] == ("bench.csv does not look like an export of %s: none of its 20 column names is in that tool's "
                                           "column list. The agents will not read it as that tool's export." % LECROY_NAME)
    assert by["mixed.csv"]["sentence"] == (
        "mixed.csv does not look like an export of %s: only 3 of its 23 column names are in that tool's column list (an export of "
        "that tool is recognised from at least 5 names and at least 30 in 100 of them). If you start with this answer all the same, "
        "the agents read this file as a file of an unknown tool: no meaning is taken from that tool's reference document for it."
        % LECROY_NAME)      # (changed 2026-11-15: family1.exported_by takes a chosen tool only for a file that passes the two limits)
    assert by["locked.csv"]["sentence"] == "locked.csv was not compared: its first line could not be read."
    assert got["sentence"] == (
        "2 of the 4 CSV files in this folder do not look like an export of %s (bench.csv, mixed.csv). If the recording comes from "
        "another tool, choose \"Another tool, or I do not know\". If it does come from %s, tick the box under the first question to "
        "start with it all the same." % (LECROY_NAME, LECROY_NAME))
    assert LECROY not in json.dumps(got)                                         # no key of a tool in what a screen shows
    fine = ST.folder_check(LECROY, [{"name": n, "columns": cols} for n, cols in heads.items()])
    assert fine["doubt"] == [] and fine["sentence"] == "" and all(f["looks"] for f in fine["files"])
    for key in (None, "", ANOTHER, "windows_wpa", "no_such_tool"):
        assert ST.folder_check(key, [{"name": "a.csv", "columns": made_up}]) is None


# ---------------------------------------------------------------------------------------------- 7. a chosen tool is taken only for a file that looks like it
def _known_names(n):
    """n different column names of the real exports that are in the Teledyne LeCroy column list (by the library's own counting)."""
    names = [x for cols in real_headers().values() for x in cols]
    known = [x for x in dict.fromkeys(names) if x and ST.looks_like(LECROY, [x])["found"]]
    assert len(known) >= n, "the real headers hold only %d names of the column list" % len(known)
    return known[:n]


@pytest.mark.parametrize("known, made_up, taken", [(1, 2, False), (4, 0, False), (5, 0, True), (1, 40, False), (4, 4, False), (5, 11, True), (5, 12, False),
                                                    (29, 71, False), (30, 70, True), (0, 20, False)],
                         ids=["1 name of 3", "4 names of 4", "5 names of 5", "1 name of 41", "4 names of 8", "5 names of 16", "5 names of 17",
                              "29 in 100", "30 in 100", "no name of 20"])
def test_a_chosen_tool_is_taken_for_a_file_only_within_the_two_limits_of_the_recognition_without_a_choice(known, made_up, taken):
    from agentic import column_knowledge as CK, family1
    assert (CK.RECOGNISE_LEAST, CK.RECOGNISE_SHARE) == (5, 0.3)
    names = _known_names(known) + ["Feld %03d" % i for i in range(made_up)]
    cols = [{"column": n} for n in names]
    got = family1.exported_by(cols, LECROY)
    alone = family1.exported_by(cols)                               # the same file without any choice
    assert ST.looks_like(LECROY, names)["looks"] is taken and (alone["tool"] == LECROY) is taken      # one definition of the limits
    words = family1.exported_sentence(got)
    total = known + made_up
    many = "%d column name%s" % (total, "" if total == 1 else "s")
    if taken:
        assert (got["tool"], got["how"], got["found"], got["names"]) == (LECROY, "chosen", known, total)
        assert words == "An export of **%s**, the tool recognised for this analysis from its files: %d of its %s are in that tool's reference document." % (
            LECROY_NAME, known, many)
        return
    assert (got["tool"], got["name"], got["how"], got["found"], got["chosen_name"], got["chosen_found"]) == (None, "", "chosen, not matching", 0, LECROY_NAME, known)
    assert family1._prompt_words(got) == family1._prompt_words(alone) and family1._prompt_words(got)[0] == "whose exporting tool is not known"
    counted = "only %d of its %s %s" % (known, many, "is" if known == 1 else "are") if known else "none of its %s is" % many
    assert words == ("**%s** is the tool kept with this analysis (recognised from its other files, or stated when it was started), but this file's column names do not match that tool's: %s in that tool's "
                     "reference document (a file is read as that tool's export from at least 5 names and at least 30 in 100 of them). The file is read "
                     "as a file of an unknown tool: no meaning is taken from that reference document." % (LECROY_NAME, counted))
    assert LECROY not in words                                      # no key of a tool in what a screen shows


def test_the_admins_own_word_can_override_the_limits_once_something_stores_it():
    """exported_by(..., confirmed=True) is the override the start page's box stands for. Nothing stores the tick yet, so no step
    passes it: this pins what it does when a caller passes it, and that a flow of today does not."""
    import inspect
    from agentic import family1
    few = [{"column": n} for n in _known_names(2) + ["Feld %03d" % i for i in range(20)]]
    got = family1.exported_by(few, LECROY, confirmed=True)
    assert (got["tool"], got["how"], got["found"], got["names"]) == (LECROY, "chosen, confirmed by the admin", 2, 22)
    assert family1.exported_sentence(got) == (
        "Read as an export of **%s**, the tool kept with this analysis, because the admin confirmed it: only 2 of its "
        "22 column names are in that tool's reference document." % LECROY_NAME)
    none = [{"column": "Feld %03d" % i} for i in range(20)]         # not one name of that tool: no word makes it that tool's export
    assert family1.exported_by(none, LECROY, confirmed=True)["how"] == "chosen, not matching"
    for word in ("yes", 1, None, False):                            # only the plain True counts
        assert family1.exported_by(few, LECROY, confirmed=word)["how"] == "chosen, not matching"
    assert family1.exported_by(few, None, confirmed=True)["how"] == "unknown" and family1.exported_by(few, ANOTHER, confirmed=True)["how"] == "unknown"
    assert "confirmed" not in inspect.getsource(family1._explore) and "confirmed" not in inspect.getsource(family1._declared_tool)


def test_under_another_tool_the_header_alone_decides_as_the_start_page_says():
    """Pinned: with "Another tool, or I do not know" stored, a file whose own column names match a tool's list (at least 5 names
    and at least 30 in 100 of them) gets that tool's reference document, and every other file gets none: the sentence the
    start page shows under that answer."""
    from agentic import family1
    assert ("The application's reference document of a tool is used only for a file whose own column names match that tool's column list "
            "(at least 5 names and at least 30 in 100 of them); for every other file none is used.") in ST.another()["sentence"]
    for name, header in real_headers().items():
        cols = [{"column": n} for n in header]
        got = family1.exported_by(cols, ANOTHER)
        assert got == family1.exported_by(cols) and (got["tool"], got["how"]) == (LECROY, "recognised"), name
        assert family1.exported_sentence(got).startswith("Recognised as an export of **%s**: " % LECROY_NAME)
    for names in (["Feld %03d" % i for i in range(20)], _known_names(4) + ["Feld %03d" % i for i in range(4)], _known_names(29) + ["Feld %03d" % i for i in range(71)]):
        cols = [{"column": n} for n in names]
        got = family1.exported_by(cols, ANOTHER)
        assert got == family1.exported_by(cols) and (got["tool"], got["how"]) == (None, "unknown") and "chosen_name" not in got
        assert family1.exported_sentence(got).startswith("The tool that exported this file was not recognised")
    ctx = type("Ctx", (), {"project": {"source_tool": ANOTHER}})()
    assert family1._declared_tool(ctx) == ANOTHER                   # the stored value reaches exported_by as it is, and is no tool there


def test_a_library_entry_under_the_reserved_key_is_skipped_by_the_library_itself(tmp_path):
    from agentic import column_knowledge as CK
    assert CK.RESERVED_KEY == ST.ANOTHER == ANOTHER
    root = own_library(tmp_path, [
        {"key": ANOTHER, "name": "A Tool That Took The Reserved Value", "columns": ANOTHER + "/columns.json", "document": ANOTHER, "status": "ready", "hierarchy": True},
        {"key": ANOTHER, "name": "The Same Key Once More", "notes": "notes.md"},
        {"key": "joined", "name": "Joined Tool", "columns": "joined/columns.json", "status": "ready"}])
    index = os.path.join(root, "index.json")                        # ... and entries that are no tool at all
    with open(index, encoding="utf-8") as fh:
        tools = json.load(fh)["tools"]
    with open(index, "w", encoding="utf-8") as fh:
        json.dump({"tools": tools + [{"key": None, "name": "No key"}, {"key": 7, "name": "A number"}, {"key": [ANOTHER], "name": "A list"}, {"key": ""},
                                     "another_tool", None, 7]}, fh)
    lib = CK.Library(root)
    assert list(lib.tools) == ["joined"] and [t["key"] for t in lib.listed] == ["joined"] and lib.problems == []
    assert lib.recognise(["Time"] * 6)[0] in (None, "joined") and lib.names_found(ANOTHER, ["Time"])["found"] == 0
    assert lib.describe(ANOTHER) is None and lib.lookup(ANOTHER, None, "Time")[0] is None
    assert ST.looks_like(ANOTHER, ["Time"], root) is None and [t["key"] for t in ST.tools(root)] == ["joined"]
    with open(os.path.join(APP_DIR, "reference_library", "README.md"), encoding="utf-8") as fh:
        assert "The key `another_tool` is reserved" in fh.read()
