"""Lab evidence and timing on the procedural graph, and the error page's search that starts from the graph and writes back
(2026-11-15; nvme_hier/graph_learning.py, nvme_hier/replay_search.py, the search block of app/api/isolate_api.py, app/api/dg_api.py).

    F2T_WORKERS=1 python3 -m pytest -q -p no:cacheprovider -s tests/test_graph_learning.py

No model is trained anywhere: counts, stored values and a search. Everything runs in temporary folders on the SIMULATED drive with a
hidden trigger (replay_search.HiddenTriggerBench), where a trigger stays the same between two searches unless the test moves it: the
four-arm measurement below says what the mechanism does there, and nothing about a real drive. The numbers it prints (-s) are the
measured ones; the acceptance lines were written before the measurement and are not tuned to it.
"""
import json
import os
import random
import shutil
import sqlite3
import statistics
import subprocess
import sys
import tempfile
import zipfile

import pytest

os.environ.setdefault("F2T_WORKERS", "1")
HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
sys.path.insert(0, HERE)

from nvme_hier import defect_graph as DG      # noqa: E402
from nvme_hier import graph_learning as GL    # noqa: E402
from nvme_hier import replay_search as RS     # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
OLD_ZIP = os.path.join(os.path.dirname(APP), "field_to_test_loop_code_only.zip")
UID = "up-s17"
MODEL, FW = "Drive model A", "FW 1.0"
ARMS_N = 30                 # hidden triggers per arm
MAJORITY = 20               # acceptance, written before measuring: same-kind history needs fewer runs in at least 20 of 30 (two thirds)
NO_HARM_RUNS = 2 * RS.EVAL_RUNS   # acceptance: stale or wrong history costs at most the two graph candidates' runs (2 x 2) at the median
NO_HARM_LOST = 3            # acceptance: with stale or wrong history at most 3 of 30 more searches end without a reproduction


def _steps(sid):
    return [{"command": "Write", "position": "above", "gap_us": 10, "source_row": 5, "opc": 1}, {"command": "Read", "position": "fault", "gap_us": 10, "source_row": 9 + sid, "opc": 2}]


@pytest.fixture()
def graph(tmp_path):
    g = DG.DefectGraph(str(tmp_path / "hier_knowledge.sqlite"))
    did, _ = g.add_defect("read never completed", "cmd.timeout", "nvme_command", "what", "t", term_key="k1")
    cid, _ = g.add_cause(did, "device", "the controller stalls", "t")
    return {"g": g, "did": did, "cid": cid}


@pytest.fixture(scope="module")
def s17():
    if not os.path.isdir(S17):
        pytest.skip("the sample recording samples/clean_five_files/S17_io_timeout_abort_reset is not on this machine")
    import fuzz_app as F
    import test_replay_search as TRS
    from agentic import core, family1, procedures as PR
    from api import config_api, hier_api
    # (2026-11-15) F.setup below points the application's modules at this throw-away application (the engine's start, the knowledge folder,
    # the settings file, the key file, the uploads folder, the question whether a model is connected): all of it is put back in the finally,
    # so that a test file that runs after this one does not look for the application's recordings in a folder that is gone
    kept = (core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK)
    uploads, connected = list(PR._UPLOADS), PR.MODEL_CONNECTED
    root = tempfile.mkdtemp(prefix="graph_learning_%d_" % os.getpid())
    try:
        app, c, _k, _r = F.setup(root)
        d = os.path.join(root, "uploads", UID)
        os.makedirs(d)
        TRS._tree(os.path.join(d, "hier.sqlite"))
        with open(os.path.join(d, "meta.json"), "w", encoding="utf-8") as fh:
            json.dump({"upload_id": UID, "created": 0, "operator": "t", "device": "D", "trace_name": UID, "recording_date": "", "notes": "", "files": {}, "status": "loaded",
                       "thresholds": {}, "file_stats": {}}, fh)
        con = sqlite3.connect(os.path.join(d, "hier.sqlite"))
        fid = con.execute("SELECT id FROM finding WHERE level='nvme_command' AND rule='cmd.timeout' ORDER BY id LIMIT 1").fetchone()[0]
        con.close()
        iso = c.post("/api/isolate/%s/%d/isolate" % (UID, fid), json={"anyway": True, "standin": True, "name": "t", "n": 15, "m": 2}).get_json()
        from api import isolate_api as IA
        with app.test_request_context():
            s = app.config["services"]
            ctx = IA._load(s, UID, fid)
            p, seed, usual = IA._search_pool(s, UID, fid, [dict(x) for x in iso["sequence"]], 15, ctx["f"]["cmd_rowid"])
            limit_us, _t, _s = IA._cmd_limit(ctx)
            oracle = IA.TP.oracle_of(ctx["f"], limit_us)
            recorded = ctx["f"]["value_ps"] / 10 ** 6
        yield {"app": app, "c": c, "root": root, "fid": fid, "seq": iso["sequence"], "base": "/api/isolate/%s/%d/" % (UID, fid), "dir": d,
               "pool": p, "seed": seed, "usual": usual, "oracle": oracle, "recorded": recorded}
    finally:
        core.Engine.kick, family1.knowledge_dir, config_api.save_config, hier_api.ENV_FILE, F.REAL_KICK = kept
        PR._UPLOADS[:], PR.MODEL_CONNECTED = uploads, connected
        shutil.rmtree(root, ignore_errors=True)


def _search(pl, trigger, seed=0, budget=RS.BUDGET_DEFAULT, first=None, do_stress=False):
    bench = RS.HiddenTriggerBench(pl["oracle"], trigger, pl["recorded"], pl["usual"], seed=seed)
    return RS.search(pl["pool"], pl["seed"], bench, budget=budget, recorded_time_us=pl["recorded"], rng_seed=seed, do_stress=do_stress, first=first)


def _runs_to(res):
    """Lab runs to the first confirmed reproduction (searching + confirming); a search that did not reproduce counts as budget + 1."""
    return (res["budget"]["search"] + res["budget"]["confirm"]) if res["found"] else res["budget"]["asked"] + 1


# ---------------------------------------------------------------------------------------------- 1 the lab ledger is apart from the judgements
def test_lab_rows_never_change_a_verdict_count_or_the_order_by_judgements_and_are_only_added(graph):
    g, cid = graph["g"], graph["cid"]
    sids = [g.add_solution(cid, _steps(i), ["line %d" % i], "", "admin:t", "t")[0] for i in range(4)]
    for sid, sigs in zip(sids, (["correct", "correct"], ["wrong"], [], ["correct", "wrong_with_edits"])):
        for i, sg in enumerate(sigs):
            g.verdict(sid, sg, "admin%d" % i)
    before = [(x["id"], x["rank"], x["correct"], x["judged"], x["edits"], x["lower_bound"], x["judged_words"]) for x in g.solutions(cid)]
    verdict_rows = sqlite3.connect(g.path).execute("SELECT COUNT(*), GROUP_CONCAT(signal) FROM dg_verdict").fetchone()
    # the solution judged wrong gets a perfect lab record, the best judged one a terrible one: the order must not move
    first = g.add_lab(sids[1], "simulated", "search", 50, 50, "t", model=MODEL, firmware=FW, fault_time_us=30000.0,
                      timing=[{"name": "the gap before the failing command", "key": "gap:fault", "value": 40, "unit": "microseconds"}])
    g.add_lab(sids[0], "simulated", "search", 50, 0, "t")
    g.add_lab(sids[0], "real", "validation_suite", 5, 1, "t")
    g.add_lab(sids[2], "simulated", "two_way_check", 4, 4, "t")
    after = [(x["id"], x["rank"], x["correct"], x["judged"], x["edits"], x["lower_bound"], x["judged_words"]) for x in g.solutions(cid)]
    assert after == before, "a lab row changed a judgement count or the order by judgements"
    assert sqlite3.connect(g.path).execute("SELECT COUNT(*), GROUP_CONCAT(signal) FROM dg_verdict").fetchone() == verdict_rows
    by = {x["id"]: x for x in g.solutions(cid)}
    assert by[sids[1]]["lab"]["simulated"]["words"] == "lab runs: the failure came back in 50 of 50 on the simulated drive"
    assert by[sids[0]]["lab"]["lines"] == ["lab runs: the failure came back in 0 of 50 on the simulated drive", "lab runs: the failure came back in 1 of 5 on the real drive"]
    assert by[sids[2]]["lab"]["simulated"] is None and "not counted" in by[sids[2]]["lab"]["not_counted"], "the two-way check is shown, never counted"
    assert by[sids[3]]["lab"]["lines"] == ["lab runs: none yet"]
    # rows are only added: the first row is still there, unchanged, after the others
    rows = g.lab_rows(solution_id=sids[1])
    assert len(rows) == 1 and rows[0]["id"] == first and rows[0]["runs"] == 50 and rows[0]["timing"][0]["unit"] == "microseconds" and rows[0]["by"] == "t"
    src = open(os.path.join(APP, "nvme_hier", "graph_learning.py"), encoding="utf-8").read()
    for table in ("dg_lab", "dg_timing", "dg_seq_timing"):
        assert "UPDATE %s" % table not in src and "DELETE FROM %s" % table not in src, "%s must only gain rows" % table
    assert "dg_verdict" not in src.split("class LabLedger")[1], "the lab ledger's code must not touch the verdict table"


def test_a_failed_lab_run_counts_against_the_solution_never_against_the_cause(graph):
    g, did, cid = graph["g"], graph["did"], graph["cid"]
    sid = g.add_solution(cid, _steps(0), ["x"], "", "admin:t", "t")[0]
    g.record_occurrence(did, cid, "u1", 1, MODEL, FW, {}, "t")
    chosen = g.view(did)["causes"][0]["chosen_words"]
    g.add_lab(sid, "simulated", "search", 10, 0, "t")
    v = g.view(did)
    assert v["causes"][0]["chosen_words"] == chosen and v["causes"][0]["solutions"][0]["lab"]["simulated"]["reproduced"] == 0


def test_a_database_of_the_previous_version_opens_and_gains_the_new_tables(tmp_path):
    p = str(tmp_path / "old.sqlite")
    con = sqlite3.connect(p)
    con.executescript(DG.SCHEMA.replace(GL.SCHEMA, ""))
    con.execute("INSERT INTO dg_defect (key, name) VALUES ('k', 'n')")
    con.commit()
    assert not con.execute("SELECT name FROM sqlite_master WHERE name='dg_lab'").fetchone()
    con.close()
    g = DG.DefectGraph(p)
    names = {r[0] for r in sqlite3.connect(p).execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"dg_lab", "dg_timing", "dg_seq_timing"} <= names and g.defects()[0]["name"] == "n"


# ---------------------------------------------------------------------------------------------- 2 timing as data, mapped by the key
def _shifted(pool, shift=1000, leave_out=()):
    """The same recording with other row numbers (every row number moved by `shift`), optionally without some commands."""
    def mv(s):
        return dict(s, source_row=s["source_row"] + shift)
    above = [mv(pool.by_row[r]) for r in pool.rows if r not in leave_out]
    times = {r + shift: t for r, t in pool.times.items()}
    return RS.Pool(above, mv(pool.fault), times, {r + shift for r in pool.fused})


def test_a_stored_solutions_timing_goes_onto_another_recording_by_the_key_and_a_step_without_counterpart_is_said_and_dropped(s17, graph):
    pool, g = s17["pool"], graph["g"]
    rows = pool.rows[2:9]
    cand = pool.candidate(rows, {rows[0]: 77, pool.frow: 33}, 1)
    timing = GL.timing_of_steps(pool, pool.steps_of(cand), 1)
    assert all("/" in s["key"] and s["key"].split("/")[0] in ("io", "admin") for s in timing["steps"][:-1]) and timing["steps"][-1]["key"] == "fault"
    assert not any(str(r) in s["key"].split("/-")[0] for s in timing["steps"] for r in rows if r > 99), "the key must not carry a row number of the recording"
    sid = g.add_solution(graph["cid"], pool.steps_of(cand), [], "", "t", "t")[0]
    g.set_seq_timing(sid, timing, "t")
    stored = g.seq_timing(sid)
    assert stored["stored"] and stored["steps"][0]["gap_searched_us"] == 77 and stored["steps"][0]["gap_recorded_us"] == pool.recorded_gap[rows[0]]
    other = _shifted(pool)
    c2, said, dropped = GL.apply_timing(other, stored)
    assert dropped == 0 and said == [] and c2["rows"] == [r + 1000 for r in rows] and c2["gaps"][rows[0] + 1000] == 77 and c2["gaps"][other.frow] == 33
    assert [RS.fingerprint(other.by_row[r]) for r in c2["rows"]] == [RS.fingerprint(pool.by_row[r]) for r in rows], "the same commands, found by the key"
    # a recording in which one kind of command of the stored sequence does not occur: its steps are said and dropped, the rest still maps
    kind = (bool(pool.by_row[rows[0]].get("admin")), pool.by_row[rows[0]].get("opc"))
    gone = [r for r in pool.rows if (bool(pool.by_row[r].get("admin")), pool.by_row[r].get("opc")) == kind]
    c3, said3, dropped3 = GL.apply_timing(_shifted(pool, 500, leave_out=gone), stored)
    n_kind = sum(1 for r in rows if r in gone)
    assert dropped3 == n_kind >= 1 and len(c3["rows"]) == len(rows) - n_kind
    assert all("has no counterpart in this recording: dropped" in x for x in said3[:dropped3]), said3
    # a solution stored before timing was kept still gives keys (counted within its own steps), and says so
    old = g.add_solution(graph["cid"], pool.steps_of(cand), [], "", "t", "t")[0]
    assert g.seq_timing(old)["stored"] is False and "before timing was kept" in g.seq_timing(old)["key_basis"]


# ---------------------------------------------------------------------------------------------- 3 brackets
def test_brackets_follow_the_yes_and_no_runs_and_say_what_they_do_with_contradictory_runs():
    obs = [{"value": 40, "runs": 10, "reproduced": 9}, {"value": 20, "runs": 3, "reproduced": 3}, {"value": 90, "runs": 2, "reproduced": 0}, {"value": 160, "runs": 2, "reproduced": 0}]
    b = GL.bracket(obs, "gap:fault")
    assert (b["came_back_at"], b["came_back_runs"], b["stayed_away_at"], b["stayed_away_runs"], b["best"], b["contradicted_runs"]) == (40, [9, 10], 90, [0, 2], 40, 0)
    assert GL.bracket_words(b, "the gap before the failing command") == ("the gap before the failing command: the failure still came back at 40 microseconds (in 9 of 10 runs); "
                                                                         "it no longer came back at 90 microseconds (0 of 2 runs)")
    # more runs at 90 with the failure: the came-back end moves up to 90, the stayed-away end to the next value above it
    b2 = GL.bracket(obs + [{"value": 90, "runs": 10, "reproduced": 8}], "gap:fault")
    assert (b2["came_back_at"], b2["stayed_away_at"]) == (90, 160)
    # contradictory: no failure in 2 runs at 30, although it came back at 40 and at 20. The range does not move; the runs are counted and said.
    b3 = GL.bracket(obs + [{"value": 30, "runs": 2, "reproduced": 0}], "gap:fault")
    assert (b3["came_back_at"], b3["stayed_away_at"], b3["contradicted_runs"]) == (40, 90, 2) and "do not move the range" in GL.bracket_words(b3, "x")
    # one run without the failure is not enough for "stayed away"; a share under one half is unclear and moves nothing
    b4 = GL.bracket([{"value": 40, "runs": 10, "reproduced": 9}, {"value": 60, "runs": 1, "reproduced": 0}, {"value": 50, "runs": 10, "reproduced": 2}], "gap:fault")
    assert (b4["came_back_at"], b4["stayed_away_at"]) == (40, None)
    # only "no" runs: no came-back end, no best value
    b5 = GL.bracket([{"value": 90, "runs": 4, "reproduced": 0}], "gap:fault")
    assert (b5["came_back_at"], b5["best"], b5["stayed_away_at"]) == (None, None, 90)
    # the queue depth is stressful upwards: the smallest depth at which it came back, the largest below it at which it did not
    q = GL.bracket([{"value": 2, "runs": 10, "reproduced": 9}, {"value": 3, "runs": 3, "reproduced": 3}, {"value": 1, "runs": 4, "reproduced": 0}], "queue_depth")
    assert (q["came_back_at"], q["stayed_away_at"], q["unit"]) == (2, 1, "commands")


def test_the_brackets_of_a_search_use_only_controlled_no_runs(s17):
    pool = s17["pool"]
    fr, rows = pool.frow, pool.rows[:4]
    res = {"candidates": [
        {"rows": rows + [fr], "gaps_us": [5, 5, 5, 5, 40], "queue_depth": 1, "runs": 10, "reproduced": 9},
        {"rows": rows + [fr], "gaps_us": [5, 5, 5, 5, 80], "queue_depth": 1, "runs": 2, "reproduced": 0},      # differs in the gap before the failing command only
        {"rows": rows[:2] + [fr], "gaps_us": [5, 5, 640], "queue_depth": 1, "runs": 2, "reproduced": 0}]}        # other commands: says nothing about a gap
    obs = {(o["key"], o["value"]): (o["reproduced"], o["runs"]) for o in GL.observations(res, pool)}
    assert obs[("gap:fault", 40)] == (9, 10) and obs[("gap:fault", 80)] == (0, 2) and ("gap:fault", 640) not in obs and obs[("queue_depth", 1)] == (9, 10)


# ---------------------------------------------------------------------------------------------- 4 firmware and model inheritance
def test_a_new_firmware_starts_from_the_same_model_and_a_new_model_from_the_defect_and_the_words_say_which(graph):
    g, did, cid = graph["g"], graph["did"], graph["cid"]
    assert g.timing_brackets(did, cid, "simulated", MODEL, FW) is None
    g.add_timing(did, cid, [{"key": "gap:fault", "unit": "microseconds", "value": 40, "runs": 10, "reproduced": 9}], "simulated", "t", model=MODEL, firmware=FW)
    g.add_timing(did, cid, [{"key": "gap:fault", "unit": "microseconds", "value": 7, "runs": 10, "reproduced": 10}], "simulated", "t", model="Drive model B", firmware="B1")
    same = g.timing_brackets(did, cid, "simulated", MODEL, FW)
    assert same["level"] == "same_firmware" and same["level_words"] == "from this drive model and this firmware" and same["values"][0]["best"] == 40
    newfw = g.timing_brackets(did, cid, "simulated", MODEL, "FW 2.0")
    assert newfw["level"] == "earlier_firmware" and newfw["level_words"] == "from an earlier firmware of the same drive model: used only as a starting point"
    assert newfw["values"][0]["best"] == 40, "a new firmware starts from what the same model holds (not from the other model)"
    newmodel = g.timing_brackets(did, cid, "simulated", "Drive model C", "C9")
    assert newmodel["level"] == "other_model" and "other drive models" in newmodel["level_words"] and newmodel["values"][0]["came_back_at"] == 40
    assert g.timing_brackets(did, cid, "real", MODEL, FW) is None, "simulated-drive evidence is never the start of a real-drive search"
    # the old rows are still there, unchanged (nothing is decayed), and the cause's rows win over the defect's
    assert sqlite3.connect(g.path).execute("SELECT COUNT(*), SUM(runs) FROM dg_timing").fetchone() == (2, 20)
    assert same["cause_used"] and g.timing_brackets(did, None, "simulated", MODEL, FW)["cause_used"] is False
    # the draw of the leading solution: lab runs of another firmware count as at most STALE_CAP_RUNS runs
    lead, draws = GL.lead_draw([{"id": 1, "k": 50, "n": 50, "level": "earlier_firmware"}, {"id": 2, "k": 0, "n": 0, "level": "same_firmware"}], random.Random(1))
    d1 = next(d for d in draws if d["id"] == 1)
    assert abs((d1["alpha"] + d1["beta"]) - (GL.STALE_CAP_RUNS + GL.PRIOR_RUNS)) < 1e-6 and lead["id"] in (1, 2)
    wins = sum(1 for i in range(400) if GL.lead_draw([{"id": 1, "k": 9, "n": 10, "level": "same_firmware"}, {"id": 2, "k": 1, "n": 10, "level": "same_firmware"}], random.Random(i))[0]["id"] == 1)
    assert wins > 360, "the solution whose failure came back in 9 of 10 lab runs leads far more often than the one with 1 of 10 (%d of 400)" % wins


# ---------------------------------------------------------------------------------------------- 5 the search with an empty graph, and its gaps
OLD_DRIVER = r'''
import json, sys
sys.path.insert(0, sys.argv[1])
from nvme_hier import replay_search as RS
d = json.load(open(sys.argv[2], encoding="utf-8"))
pool = RS.Pool(d["above"], d["fault"], {int(k): tuple(v) for k, v in d["times"].items()}, set(d["fused"]))
seed = pool.candidate(d["seed"]["rows"], {int(k): v for k, v in d["seed"]["gaps"].items()}, d["seed"]["queue_depth"])
out = []
for i, tr in enumerate(d["triggers"]):
    bench = RS.HiddenTriggerBench(d["oracle"], tr, d["recorded"], d["usual"], seed=i)
    out.append(RS.search(pool, seed, bench, budget=200, recorded_time_us=d["recorded"], rng_seed=i))
json.dump(out, open(sys.argv[3], "w", encoding="utf-8"))
'''


def test_with_an_empty_graph_the_search_is_exactly_the_released_one_for_the_same_seed(s17, graph, tmp_path):
    pool = s17["pool"]
    assert GL.plan(graph["g"], pool, s17["seed"], graph["did"], graph["cid"], "simulated", MODEL, FW, 3) is None, "an empty graph gives no plan"
    if not os.path.exists(OLD_ZIP):
        pytest.skip("the released code (field_to_test_loop_code_only.zip) is not on this machine")
    old = str(tmp_path / "old")
    with zipfile.ZipFile(OLD_ZIP) as z:
        z.extractall(old, [n for n in z.namelist() if n.startswith("13_production_app/nvme_hier/")])
    data = {"above": [pool.by_row[r] for r in pool.rows], "fault": pool.fault, "times": pool.times, "fused": sorted(pool.fused), "seed": s17["seed"],
            "triggers": [RS.random_trigger(pool, random.Random(700 + i)) for i in range(4)], "oracle": s17["oracle"], "recorded": s17["recorded"], "usual": s17["usual"]}
    with open(str(tmp_path / "in.json"), "w", encoding="utf-8") as fh:
        json.dump(data, fh)
    with open(str(tmp_path / "driver.py"), "w", encoding="utf-8") as fh:
        fh.write(OLD_DRIVER)
    got = {}
    for name, app_dir in (("released", os.path.join(old, "13_production_app")), ("now", APP)):
        out = str(tmp_path / (name + ".json"))
        p = subprocess.run([sys.executable, str(tmp_path / "driver.py"), app_dir, str(tmp_path / "in.json"), out], capture_output=True, text=True, timeout=600,
                           env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1"), cwd=str(tmp_path))
        assert p.returncode == 0, (name, p.stderr[-1500:])
        with open(out, encoding="utf-8") as fh:
            got[name] = json.load(fh)
    assert got["now"] == got["released"], "without anything from the graph the search must be the released search, run for run"
    assert any(r["found"] for r in got["now"]) and all("started_from" not in r for r in got["now"])


def test_the_search_is_given_the_gaps_as_recorded_not_the_flattened_ones(s17):
    pool, seed = s17["pool"], s17["seed"]
    con = sqlite3.connect(os.path.join(s17["dir"], "hier.sqlite"))
    from nvme_hier import loader as _L
    TBL = _L.TABLE["nvme_command"]
    t = dict(con.execute("SELECT rowid_file, t_ps FROM %s WHERE rowid_file IN (%s)" % (TBL, ",".join("?" * (len(seed["rows"]) + 1))), seed["rows"] + [pool.frow]).fetchall())
    con.close()
    order = sorted(seed["rows"]) + [pool.frow]
    checked = 0
    for a, b in zip(order, order[1:]):
        if t.get(a) is not None and t.get(b) is not None and t[b] > t[a]:
            want = max(1, min(RS.MAX_GAP_US, (t[b] - t[a]) // 10 ** 6))
            assert seed["gaps"][b] == want == pool.recorded_gap[b], "row %d: the search starts from %d microseconds, the recording says %d" % (b, seed["gaps"][b], want)
            checked += 1
    assert checked >= 1 and "measured ones of the recording" in pool.gap_basis
    sent = {x["source_row"]: x["gap_us"] for x in s17["seq"] if x.get("position") != "below"}
    flat = [r for r in order[1:] if sent.get(r) == 10 and seed["gaps"][r] != 10]
    print("\nrecorded gaps reaching the search: %d of the first sequence's %d gaps were flattened to 10 microseconds on the page and are now the measured ones: %s"
          % (len(flat), len(order) - 1, [(r, seed["gaps"][r]) for r in flat][:6]))
    assert [x["gap_us"] for x in s17["seq"]] == [x["gap_us"] for x in s17["seq"]] and all(x["gap_us"] == sent[x["source_row"]] for x in s17["seq"] if x.get("position") != "below"), \
        "the sequence the page holds (and the test written without the search) is not changed"


# ---------------------------------------------------------------------------------------------- 6 the route: starts from the graph, writes back, stores only on the press
def test_the_search_starts_from_the_graph_writes_back_and_stores_a_solution_only_when_the_admin_presses(s17):
    c, fid, base, pool = s17["c"], s17["fid"], s17["base"], s17["pool"]
    gpath = os.path.join(s17["root"], "db", "hier_knowledge.sqlite")

    def n_rows(table):
        con = sqlite3.connect(gpath)
        try:
            return con.execute("SELECT COUNT(*) FROM %s" % table).fetchone()[0]
        finally:
            con.close()
    did = c.post("/api/dg/defects", json={"name": "read timeout for the route test", "rule": "cmd.timeout", "level": "nvme_command", "what": "w", "admin": "t"}).get_json()["id"]
    cid = c.post("/api/dg/causes", json={"defect_id": did, "side": "device", "header": "the controller stalls (route test)", "admin": "t"}).get_json()["id"]
    r = c.post("/api/dg/occurrences", json={"defect_id": did, "cause_id": cid, "upload_id": UID, "finding_id": fid, "admin": "t", "device": MODEL, "firmware": FW, "isolation": {}})
    assert r.status_code == 200, r.get_data(as_text=True)
    tseed = next(i for i in range(900, 990) if _search(s17, RS.random_trigger(pool, random.Random(i)), seed=i)["found"])
    body = {"sequence": s17["seq"], "budget": 200, "bench": "simulated", "pool_n": 15, "name": "t", "trigger_seed": tseed}
    sols0, verdicts0 = n_rows("dg_solution"), n_rows("dg_verdict")
    # nothing can be stored before a search has finished
    assert c.post(base + "search/store", json={"name": "t", "which": "best"}).status_code == 400
    r1 = c.post(base + "search", json=body).get_json()["result"]
    assert r1["found"] and "started_from" not in r1 and "as it does without the graph" in r1["graph_start"]["words"], r1["graph_start"]["words"]
    assert n_rows("dg_solution") == sols0 and n_rows("dg_verdict") == verdicts0, "a search stores no solution and no judgement by itself"
    assert n_rows("dg_timing") > 0 and any("count(s) at a value" in w for w in r1["graph_start"]["written"])
    # the press: needs the admin's name
    assert c.post(base + "search/store", json={"which": "best"}).status_code == 400
    st = c.post(base + "search/store", json={"name": "Asha", "which": "best"})
    assert st.status_code == 200, st.get_data(as_text=True)
    made = st.get_json()
    sid = made["stored"]["solution_id"]
    assert n_rows("dg_solution") == sols0 + 1 and n_rows("dg_verdict") == verdicts0 and made["solution"]["judged"] == 0 and made["solution"]["created_by"] == "Asha"
    assert made["solution"]["lab"]["simulated"]["runs"] == r1["best"]["runs"] and "it is not judged" in made["words"]
    assert c.post(base + "search/store", json={"name": "Asha", "which": "best"}).status_code == 400, "the same sequence is not stored twice"
    # the next search of the same kind of defect starts from that solution, unchanged, and says so
    r2 = c.post(base + "search", json=body).get_json()["result"]
    gs, first = r2["graph_start"], r2["started_from"][0]
    print("\nthe sentence of the search: %s" % gs["words"])
    assert gs["words"].startswith("Started from what the graph holds for this kind of defect and cause: solution %d, which came back in %d of %d runs on the simulated drive"
                                  % (sid, r1["best"]["reproduced"], r1["best"]["runs"])), gs["words"]
    assert "the gap before the failing command started at" in gs["words"] and "chosen here, to be measured" in gs["formula"]
    assert first["role"] == "stored_solution" and first["solution_id"] == sid and first["dropped"] == 0 and r2["candidates"][0]["how"].startswith("from the graph: stored solution")
    assert [x["source_row"] for x in first["steps"]] == [x["source_row"] for x in r1["best"]["steps"]] and [x["gap_us"] for x in first["steps"]] == [x["gap_us"] for x in r1["best"]["steps"]]
    assert r2["found"] and _runs_to(r2) <= RS.CONFIRM_RUNS < _runs_to(r1) + 1, (_runs_to(r1), _runs_to(r2))
    assert RS.invented(pool, r2) == [] and all(x["source_row"] in set(pool.rows) | {pool.frow} for f in r2["started_from"] for x in f["steps"])
    lab = c.get("/api/dg/solutions/%d/lab" % sid).get_json()
    assert len(lab["rows"]) == 2 and lab["rows"][1]["source"] == "search" and lab["rows"][1]["model"] == "D" and lab["rows"][1]["by"] == "t" and lab["judged_words"] == "not yet judged"
    assert lab["lab"]["simulated"]["runs"] == r1["best"]["runs"] + first["runs"] and n_rows("dg_verdict") == verdicts0
    # the drive's model and firmware texts are the recording's own (its device text "D"; this sample names no firmware)
    br = c.get("/api/dg/defects/%d/timing?cause_id=%d&bench=simulated&model=D&firmware=%s" % (did, cid, lab["rows"][1]["firmware"] or "")).get_json()
    assert br["brackets"]["level"] == "same_firmware" and br["brackets"]["values"][0]["key"] == "gap:fault" and br["brackets"]["values"][0]["came_back_at"] is not None
    # a second version of the stored solution, again only on the press
    if r2.get("most_stressful"):
        rv = c.post(base + "search/store", json={"name": "Asha", "which": "stressed", "revision_of": sid}).get_json()
        assert rv["stored"]["new"] is False and rv["solution"]["version"] == 2 and n_rows("dg_solution") == sols0 + 1


def test_hostile_input_on_every_new_route_is_refused_with_a_plain_sentence(s17):
    c, base = s17["c"], s17["base"]
    did = c.post("/api/dg/defects", json={"name": "defect for the hostile test", "rule": "r", "level": "nvme_command", "what": "w", "admin": "t"}).get_json()["id"]
    cid = c.post("/api/dg/causes", json={"defect_id": did, "side": "device", "header": "cause for the hostile test", "admin": "t"}).get_json()["id"]
    sid = c.post("/api/dg/solutions", json={"cause_id": cid, "error_seq": _steps(0), "optimized": ["x"], "admin": "t"}).get_json()["id"]
    ok = {"admin": "t", "bench": "simulated", "source": "validation_suite", "runs": 4, "reproduced": 2}
    assert c.post("/api/dg/solutions/%d/lab" % sid, json=ok).status_code == 200
    bad = [[1, 2], "text", dict(ok, runs="many"), dict(ok, runs=-1), dict(ok, runs=0), dict(ok, runs=True), dict(ok, runs=10 ** 30), dict(ok, reproduced=5), dict(ok, reproduced=None),
           dict(ok, bench="the moon"), dict(ok, bench=["simulated"]), dict(ok, source="a rumour"), dict(ok, admin=""), dict(ok, admin={"a": 1}), dict(ok, timing="fast"),
           dict(ok, timing=[{"name": "x"}]), dict(ok, timing=[{"name": "x", "unit": "microseconds", "value": "soon"}]), dict(ok, timing=[1]), dict(ok, fault_time_us="late"),
           dict(ok, fault_time_us=float("1e99")), dict(ok, revision_id=10 ** 9), dict(ok, revision_id="x"), dict(ok, model=["m"]), dict(ok, finding_id="x"), dict(ok, note={"a": 1})]
    for b in bad:
        r = c.post("/api/dg/solutions/%d/lab" % sid, json=b)
        assert r.status_code == 400 and len(r.get_json()["error"]) > 15 and "Traceback" not in r.get_json()["error"], (b, r.status_code, r.get_data(as_text=True)[:200])
    assert len(c.get("/api/dg/solutions/%d/lab" % sid).get_json()["rows"]) == 1, "a refused request adds no row"
    for url in ("/api/dg/solutions/abc/lab", "/api/dg/solutions/%d/lab" % 10 ** 30, "/api/dg/solutions/-1/lab", "/api/dg/defects/abc/lab", "/api/dg/defects/abc/timing",
                "/api/dg/defects/%d/timing?bench=moon" % did, "/api/dg/defects/%d/timing?cause_id=x" % did, "/api/dg/defects/%d/timing?model=%s" % (did, "m" * 300)):
        r = c.get(url)
        assert r.status_code == 400 and len(r.get_json()["error"]) > 15, (url, r.status_code, r.get_data(as_text=True)[:200])
    assert c.post("/api/dg/solutions/abc/lab", json=ok).status_code == 400
    assert c.get("/api/dg/solutions/987654/lab").status_code == 404 and c.get("/api/dg/defects/987654/timing").status_code == 404
    for b in ([1], "x", {}, {"name": ""}, {"name": 5, "which": "best"}, {"name": "t"}, {"name": "t", "which": "everything"}, {"name": "t", "which": "best", "revision_of": "x"},
              {"name": "t", "which": "best", "revision_of": True}, {"name": "x" * 500, "which": "best"}):
        r = c.post(base.replace("/%d/" % s17["fid"], "/%d/" % (s17["fid"] + 0)) + "search/store", json=b)
        assert r.status_code == 400 and len(r.get_json()["error"]) > 15, (b, r.status_code, r.get_data(as_text=True)[:200])


# ---------------------------------------------------------------------------------------------- 7 the four arms, measured
def _moved(tr, pool, rnd):
    """The same trigger after a change of the drive (stale history): the largest gap before the failing command is a quarter of what
    it was, and one of the needed commands is another one."""
    t = dict(tr, needed=[list(x) for x in tr["needed"]], gap_max_us=max(RS.MIN_GAP_US, int(tr["gap_max_us"]) // 4))
    have = {tuple(x) for x in t["needed"]} | ({tuple(t["blocker"])} if t.get("blocker") else set())
    spare = [fp for fp in dict.fromkeys(RS.fingerprint(pool.by_row[r]) for r in pool.rows if RS.is_sent(pool.by_row[r])) if fp not in have and fp != RS.fingerprint(pool.fault)]
    if spare:
        t["needed"][rnd.randrange(len(t["needed"]))] = list(rnd.choice(spare))
    return t


def _history(tmp, pl, trigger, i):
    """A graph that holds one earlier search of this trigger: its counts at a value and, when it found the failure, its sequence stored
    as a solution (the admin's press, made here by the test)."""
    g = DG.DefectGraph(os.path.join(tmp, "g%d.sqlite" % i))
    did, _ = g.add_defect("d", "cmd.timeout", "nvme_command", "w", "t", term_key="k")
    cid, _ = g.add_cause(did, "device", "c", "t")
    res = _search(pl, trigger, seed=5000 + i, do_stress=True)
    GL.write_back(g, pl["pool"], res, None, did, cid, "t", MODEL, FW)
    if res["found"]:
        part = res["best"]
        g.store_searched(cid, part["steps"], GL.timing_of_steps(pl["pool"], part["steps"], part["queue_depth"]), "t", "simulated", part["runs"], part["reproduced"], model=MODEL, firmware=FW)
    return g, did, cid, res["found"]


def _with(pl, g, did, cid, trigger, seed):
    plan = GL.plan(g, pl["pool"], pl["seed"], did, cid, "simulated", MODEL, FW, seed)
    res = _search(pl, trigger, seed=seed, first=plan["first"] if plan else None)
    assert RS.invented(pl["pool"], res) == []
    ok = set(pl["pool"].rows) | {pl["pool"].frow}
    assert all(r in ok for c in res["candidates"] for r in c["rows"]), "every command of every candidate is a command of the recording"
    return _runs_to(res)


def test_four_arms_no_history_same_kind_stale_and_wrong_history_measured_on_the_simulated_drive(s17, tmp_path):
    pl, pool = s17, s17["pool"]
    triggers = [RS.random_trigger(pool, random.Random(300 + i)) for i in range(ARMS_N)]
    moved = [_moved(tr, pool, random.Random(400 + i)) for i, tr in enumerate(triggers)]
    hist = [_history(str(tmp_path), pl, tr, i) for i, tr in enumerate(triggers)]
    lost = RS.BUDGET_DEFAULT + 1
    arms = {"same kind of defect and firmware": [], "stale (the trigger moved)": [], "wrong (from another trigger)": []}
    base_same, base_moved = [], []
    for i, tr in enumerate(triggers):
        g, did, cid, _found = hist[i]
        base_same.append(_runs_to(_search(pl, tr, seed=1000 + i)))
        base_moved.append(_runs_to(_search(pl, moved[i], seed=1000 + i)))
        arms["same kind of defect and firmware"].append(_with(pl, g, did, cid, tr, 1000 + i))
        arms["stale (the trigger moved)"].append(_with(pl, g, did, cid, moved[i], 1000 + i))
        gw, dw, cw, _f = hist[(i + 7) % ARMS_N]
        arms["wrong (from another trigger)"].append(_with(pl, gw, dw, cw, tr, 1000 + i))
    print("\nFour arms on the SIMULATED drive with a hidden trigger, %d triggers each, budget %d lab runs; measured: lab runs to the first confirmed reproduction "
          "(%d of %d), a search without one counts as %d. Earlier searches that found the failure and so stored a solution: %d of %d."
          % (ARMS_N, RS.BUDGET_DEFAULT, RS.CONFIRM_NEED, RS.CONFIRM_RUNS, lost, sum(1 for h in hist if h[3]), ARMS_N))
    out = {}
    for name, got in arms.items():
        base = base_moved if name.startswith("stale") else base_same
        diff = [a - b for a, b in zip(got, base)]
        out[name] = {"better": sum(1 for d in diff if d < 0), "equal": sum(1 for d in diff if d == 0), "worse": sum(1 for d in diff if d > 0), "median": statistics.median(got),
                     "median_none": statistics.median(base), "median_diff": statistics.median(diff), "lost": sum(1 for x in got if x == lost), "lost_none": sum(1 for x in base if x == lost),
                     "worst": max(diff)}
        o = out[name]
        print("  history %-34s better %2d  equal %2d  worse %2d | median runs %6.1f against %6.1f with no history | median difference %+.1f | worst %+d | not reproduced %d against %d"
              % (name + ":", o["better"], o["equal"], o["worse"], o["median"], o["median_none"], o["median_diff"], o["worst"], o["lost"], o["lost_none"]))
    same = out["same kind of defect and firmware"]
    assert same["better"] >= MAJORITY, "same-kind history did not need fewer runs in a clear majority: %r" % same
    for name in ("stale (the trigger moved)", "wrong (from another trigger)"):
        o = out[name]
        assert o["median_diff"] <= NO_HARM_RUNS, "the no-harm check failed for %s history (median): %r" % (name, o)
        assert o["lost"] <= o["lost_none"] + NO_HARM_LOST, "the no-harm check failed for %s history (searches without a reproduction): %r" % (name, o)
