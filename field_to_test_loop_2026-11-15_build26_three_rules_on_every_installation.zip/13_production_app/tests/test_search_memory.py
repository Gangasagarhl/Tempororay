"""The memory of reproduction searches (stage2/search_memory.py) and the reward from the detector's findings.

Run:  python -m pytest -q -p no:cacheprovider tests/test_search_memory.py
Everything runs on the simulated bench and in temporary folders; nothing of the application's own data is touched.
The measured numbers of test (b) are printed with  -s  and written into the assertion messages.
"""
import hashlib
import json
import os
import statistics
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "stage2"))

import search_memory as sm                                    # noqa: E402
from kgdb import KGDB                                         # noqa: E402
from llm_adapter import family_template_scenario              # noqa: E402
from optimizer import OPERATORS, Optimizer                    # noqa: E402
from oracle import SyntheticDeviceOracle                      # noqa: E402
from ppo_optimizer import PPOOptimizer                        # noqa: E402

BUDGET = 300                                                  # lab runs allowed per search (the shipped stage2.opt_budget)
KINDS = [("C-07", "P02"), ("T-42", "P19"), ("L-03", "P08"), ("N-11", "P12"), ("D-21", "P23")]   # kind of defect, family
SEEDS = 12
PLAIN = {"commands": [{"op": "write"}, {"op": "read"}],
         "timing": {"inter_cmd_us": 50, "burst_len": 16, "idle_gap_ms": 0, "qd": 8, "bs_kb": 4}, "power_state": "none"}
OLD_KEYS = ("status", "best_scenario", "repro_k", "repro_n", "repro_rate_lower95", "trials", "simulated_time_s",
            "operator_stats", "archive_cells", "best_reward", "llm_proposals_used")
# measured on the code BEFORE this change (stage2/optimizer.py from field_to_test_loop_code_only.zip), same inputs as
# _fingerprint below: status, lab runs, first 16 characters of the SHA-256 of [every trial, the result record]
BEFORE = {"C-07|0": ["budget_exhausted", 300, "e6c19c01aed00759"], "C-07|3": ["confirmed", 290, "f8aa578688b36a46"],
          "T-42|0": ["confirmed", 62, "bb0a51adc7728154"], "T-42|3": ["confirmed", 287, "f144ac67472ca749"],
          "L-03|0": ["budget_exhausted", 300, "47149713d0a568f8"], "L-03|3": ["confirmed", 209, "f3daa6763801184d"]}
BEFORE_FAMILY = {"C-07": "P02", "T-42": "P19", "L-03": "P08"}


def _fingerprint(opt, r):
    old = {k: r[k] for k in OLD_KEYS}
    return [r["status"], r["trials"], hashlib.sha256(json.dumps([opt.trials, old], sort_keys=True).encode()).hexdigest()[:16]]


def _search(sig, family, seed, memory=None, budget=BUDGET, seed_sc=None, cls=Optimizer):
    oracle = SyntheticDeviceOracle(sig, 0, seed=seed, family=family)
    opt = cls(oracle, seed_sc or family_template_scenario(family), budget=budget, rng_seed=seed, memory=memory)
    return opt, opt.search()


def _runs_to_confirmed(r):
    """Lab runs until the search returned its first confirmed reproduction; a search that did not confirm within the
    budget counts as one more than the budget."""
    return r["trials"] if r["status"] == "confirmed" else BUDGET + 1


# ------------------------------------------------------------------ (a) stored in the knowledge base, survives a restart
def test_a_state_is_in_the_knowledge_base_and_survives_close_and_open():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "knowledge.sqlite")
        db = KGDB(path)
        opt, r = _search("T-42", "P19", 0, memory=sm.recall(db, "T-42"))
        assert r["search_memory"]["used"] is False and "without history" in r["search_memory"]["words"]
        stress = opt.stress_ascent(r["best_scenario"], max_trials=9)
        eid = sm.remember(db, "T-42", r, family="P19", stress=stress)
        db.commit()
        kinds = [k for (k,) in db.con.execute("SELECT kind FROM event")]
        assert kinds == ["search_learned"]                      # one event, no side file
        assert sorted(os.listdir(d))[0] == "knowledge.sqlite" and all(f.startswith("knowledge.sqlite") for f in os.listdir(d))
        db.con.close()

        db2 = KGDB(path)                                        # closed and opened again
        mem = sm.recall(db2, "T-42")
        assert mem["searches"] == 1 and mem["ignored"] == []
        assert mem["counts_found_by_operator"] == {o: [float(a), float(b)] for o, (a, b) in r["learned"]["operators"].items()}
        assert mem["seed"] == r["best_scenario"] and mem["seed_event"] == eid
        assert mem["seed_repro_k"] == r["repro_k"] and mem["seed_repro_n"] == r["repro_n"]
        assert mem["seed_reward"] == r["best_reward"]
        assert mem["stress"]["scenario"]["timing"] == stress["scenario"]["timing"]
        # the table is computed from the events: a rebuild gives the same memory, an undone event is gone
        db2.rebuild()
        assert sm.recall(db2, "T-42")["counts_found_by_operator"] == mem["counts_found_by_operator"]
        db2.undo(eid)
        assert sm.recall(db2, "T-42")["searches"] == 0
        db2.con.close()


def test_a2_the_next_search_says_what_it_reused():
    db = KGDB()
    for seed in range(3):
        opt, r = _search("T-42", "P19", seed, memory=sm.recall(db, "T-42"))
        sm.remember(db, "T-42", r, family="P19")
    opt, r = _search("T-42", "P19", 50, memory=sm.recall(db, "T-42"))
    rep = r["search_memory"]
    assert rep["used"] and rep["earlier_searches"] == 3
    assert rep["words"].startswith("Started from what 3 earlier searches of this kind of defect learned.")
    assert rep["seed_from_memory"] and rep["seed_result"] in ("reproduced", "not_reproduced")
    assert "commands " in rep["seed_from_memory_words"] and "microseconds" in rep["seed_from_memory_words"]
    assert rep["weight_carried_lab_runs"] <= sm.CARRY_LIMIT_RUNS + 1e-6
    assert rep["counts_carried"] and all(set(c) >= {"operator", "improved_count", "did_not_improve_count"} for c in rep["counts_carried"])
    assert "from_earlier_searches" in [t["tag"] for t in opt.trials]
    # what is stored is what THIS search counted, never the counts it started from (no double counting)
    counted = sum(a + b for a, b in r["learned"]["operators"].values())
    steps = sum(1 for t in opt.trials if t["tag"] in OPERATORS)
    assert abs(counted - steps) < 1e-6


# ------------------------------------------------------------------ (b) the measured claim
def measure(kinds=KINDS, seeds=SEEDS):
    """For every kind of defect and random seed: a first search without history, then a second search of the same
    kind (another random stream, another bench seed) that starts from what the first learned, and as a control the same
    second search without history. Returns rows (kind, seed, first, second, control) in lab runs to the first
    confirmed reproduction."""
    rows = []
    for sig, family in kinds:
        for seed in range(seeds):
            db = KGDB()
            _, r1 = _search(sig, family, seed, memory=sm.recall(db, sig))
            sm.remember(db, sig, r1, family=family)
            _, r2 = _search(sig, family, seed + 1000, memory=sm.recall(db, sig))
            _, r3 = _search(sig, family, seed + 1000)
            rows.append((sig, seed, _runs_to_confirmed(r1), _runs_to_confirmed(r2), _runs_to_confirmed(r3)))
    return rows


def summary(rows):
    first, second, control = [r[2] for r in rows], [r[3] for r in rows], [r[4] for r in rows]
    return {"pairs": len(rows),
            "second_better_than_first": sum(1 for a, b in zip(first, second) if b < a),
            "second_equal_to_first": sum(1 for a, b in zip(first, second) if b == a),
            "second_worse_than_first": sum(1 for a, b in zip(first, second) if b > a),
            "second_better_than_control": sum(1 for c, b in zip(control, second) if b < c),
            "second_equal_to_control": sum(1 for c, b in zip(control, second) if b == c),
            "second_worse_than_control": sum(1 for c, b in zip(control, second) if b > c),
            "median_first_lab_runs": statistics.median(first), "median_second_lab_runs": statistics.median(second),
            "median_control_lab_runs": statistics.median(control),
            "first_not_confirmed": sum(1 for a in first if a > BUDGET),
            "second_not_confirmed": sum(1 for b in second if b > BUDGET),
            "control_not_confirmed": sum(1 for c in control if c > BUDGET)}


def test_b_second_search_of_the_same_kind_needs_fewer_lab_runs():
    rows = measure()
    s = summary(rows)
    print("\nmeasured, %d kinds of defect x %d random seeds, budget %d lab runs: %s" % (len(KINDS), SEEDS, BUDGET, json.dumps(s)))
    for sig, _ in KINDS:
        print("  %s: %s" % (sig, json.dumps(summary([r for r in rows if r[0] == sig]))))
    assert s["pairs"] == len(KINDS) * SEEDS and SEEDS >= 10
    assert s["median_second_lab_runs"] < s["median_first_lab_runs"], s
    assert s["second_better_than_first"] > s["second_worse_than_first"], s
    assert s["second_better_than_control"] > s["second_worse_than_control"], s     # same random stream, with and without history
    for sig, _ in KINDS:                                       # and in no kind of defect is the second search worse
        k = summary([r for r in rows if r[0] == sig])
        assert k["median_second_lab_runs"] <= k["median_first_lab_runs"], (sig, k)
        assert k["second_better_than_first"] > k["second_worse_than_first"], (sig, k)


# ------------------------------------------------------------------ (c) the cap
def _hostile(db, sig, operator="swap_cmds", count=100000):
    ops = {o: [0, 0] for o in OPERATORS}
    ops[operator] = [count, 0]                                  # "this operator always improved the result": false
    db.apply_event(sm.EVENT_KIND, {"sig": sig, "operators": ops, "best": None, "status": "budget_exhausted", "trials": count})


def test_c_a_hostile_history_cannot_lock_the_search_in():
    confirmed_plain = confirmed_hostile = 0
    for seed in range(10):
        db = KGDB()
        _hostile(db, "T-42")
        mem = sm.recall(db, "T-42")
        assert mem["searches"] == 1 and mem["scaled_down"] and mem["counts_found"] == 100000
        carried = sum(a + b for a, b in mem["operator_prior"].values())
        assert carried <= sm.CARRY_LIMIT_RUNS + 1e-6            # 100000 counts weigh no more than 14 lab runs
        opt, r = _search("T-42", "P19", seed, memory=mem)
        assert opt.op_start["swap_cmds"] == [1.0 + sm.CARRY_LIMIT_RUNS, 1.0]
        used = sum(1 for t in opt.trials if t["tag"] == "swap_cmds")
        steps = sum(1 for t in opt.trials if t["tag"] in OPERATORS)
        assert steps == 0 or used < steps, "the search used nothing but the useless operator"
        confirmed_hostile += int(r["status"] == "confirmed")
        confirmed_plain += int(_search("T-42", "P19", seed)[1]["status"] == "confirmed")
    print("\nhostile history: confirmed in %d of 10 searches; without history: %d of 10" % (confirmed_hostile, confirmed_plain))
    assert confirmed_plain >= 5, "the comparison needs a kind of defect the plain search can find"
    assert confirmed_hostile >= confirmed_plain - 1, (confirmed_hostile, confirmed_plain)


# ------------------------------------------------------------------ (d) switched off = exactly as before
def test_d_switched_off_the_search_is_exactly_as_before():
    for key, want in BEFORE.items():
        sig, seed = key.split("|")
        oracle = SyntheticDeviceOracle(sig, 0, seed=int(seed), family=BEFORE_FAMILY[sig])
        opt = Optimizer(oracle, json.loads(json.dumps(PLAIN)), budget=BUDGET, rng_seed=int(seed))
        r = opt.search()
        assert _fingerprint(opt, r) == want, key
        assert r["search_memory"] is None


def test_d2_the_setting_switches_the_memory_off_in_the_flow():
    from stage2_v3 import Stage2V3
    db = KGDB()
    for seed in range(2):                                       # a history exists ...
        _, r = _search("T-42", "P19", seed, memory=sm.recall(db, "T-42"))
        sm.remember(db, "T-42", r, family="P19")
    events_before = db.con.execute("SELECT COUNT(*) FROM event").fetchone()[0]
    off = Stage2V3(db, search_memory=False)
    oracle = SyntheticDeviceOracle("T-42", 0, seed=0, family="P19")
    opt = off._optimizer(oracle, json.loads(json.dumps(PLAIN)), BUDGET, 0, None, [], None, sig="T-42")
    r = opt.search()
    assert _fingerprint(opt, r) == BEFORE["T-42|0"]             # ... and switched off it is not used
    assert off._remember("T-42", "P19", r) is None              # and nothing is stored
    assert db.con.execute("SELECT COUNT(*) FROM event").fetchone()[0] == events_before
    words = Stage2V3._search_stats(r)["started_from"]["words"]
    assert "switched off" in words and "stage2.search_memory" in words

    on = Stage2V3(db, search_memory=True)
    oracle = SyntheticDeviceOracle("T-42", 0, seed=0, family="P19")
    opt = on._optimizer(oracle, json.loads(json.dumps(PLAIN)), BUDGET, 0, None, [], None, sig="T-42")
    r = opt.search()
    stats = Stage2V3._search_stats(r)
    assert stats["started_from"]["used"] and stats["started_from"]["earlier_searches"] == 2
    assert "Started from what 2 earlier searches of this kind of defect learned." in stats["started_from"]["words"]
    assert on._remember("T-42", "P19", r, best_scenario=r["best_scenario"]) is not None
    assert sm.recall(db, "T-42")["searches"] == 3


def test_d3_the_setting_is_read_from_the_configuration_file():
    with open(os.path.join(os.path.dirname(HERE), "config", "app_config.json"), encoding="utf-8") as f:
        assert json.load(f)["stage2"]["search_memory"] is True      # the shipped value: on
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "app_config.json")
        for text, want in (('{"stage2": {"search_memory": false}}', False), ('{"stage2": {"search_memory": true}}', True),
                           ('{"stage2": {"search_memory": "off"}}', False), ('{"stage2": {}}', True), ('{}', True),
                           ('not a configuration', True), ('[1]', True)):
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
            assert sm.setting_from_config(path) is want, text
        assert sm.setting_from_config(os.path.join(d, "missing.json")) is True
    from stage2_v3 import Stage2V3
    assert Stage2V3(KGDB()).search_memory is sm.setting_from_config()     # the caller did not say: the file decides


# ------------------------------------------------------------------ (e) another kind of defect
def test_e_another_kind_of_defect_does_not_get_this_history():
    db = KGDB()
    _, r = _search("T-42", "P19", 0, memory=sm.recall(db, "T-42"))
    sm.remember(db, "T-42", r, family="P19")
    other = sm.recall(db, "C-07")
    assert other["searches"] == 0 and other["seed"] is None and other["counts_found"] == 0
    assert all(ab == [0.0, 0.0] for ab in other["operator_prior"].values())
    oracle = SyntheticDeviceOracle("C-07", 0, seed=3, family="P02")
    opt = Optimizer(oracle, json.loads(json.dumps(PLAIN)), budget=BUDGET, rng_seed=3, memory=other)
    r2 = opt.search()
    assert _fingerprint(opt, r2) == BEFORE["C-07|3"]            # exactly the search without any history
    assert r2["search_memory"]["used"] is False
    # a record filed under one kind but naming another inside is not used either
    db.con.execute("INSERT INTO search_memory(event_id,sig,payload) VALUES(?,?,?)",
                   (9001, "C-07", json.dumps(sm.record_of("T-42", r))))
    again = sm.recall(db, "C-07")
    assert again["searches"] == 0 and "another kind of defect" in again["ignored"][0]


# ------------------------------------------------------------------ (f) damaged records
def test_f_a_damaged_record_is_ignored_with_a_plain_message():
    db = KGDB()
    _, r = _search("T-42", "P19", 0, memory=sm.recall(db, "T-42"))
    good = sm.remember(db, "T-42", r, family="P19")
    db.apply_event(sm.EVENT_KIND, {"sig": "T-42", "operators": "not counts"})
    bad_counts = sm.record_of("T-42", r)
    bad_counts["operators"]["mut_qd"] = ["many", None]
    db.apply_event(sm.EVENT_KIND, bad_counts)
    denied = sm.record_of("T-42", r)
    denied["best"]["scenario"]["commands"] = [{"op": "format"}]     # a command the search must never run
    db.apply_event(sm.EVENT_KIND, denied)
    bad_timing = sm.record_of("T-42", r)
    bad_timing["best"]["scenario"]["timing"]["qd"] = "deep"
    db.apply_event(sm.EVENT_KIND, bad_timing)
    db.con.execute("INSERT INTO search_memory(event_id,sig,payload) VALUES(?,?,?)", (9002, "T-42", "{\"sig\": \"T-42\", \"oper"))
    db.con.execute("INSERT INTO search_memory(event_id,sig,payload) VALUES(?,?,?)", (9003, "T-42", "[1, 2, 3]"))
    db.apply_event(sm.EVENT_KIND, {"operators": {}})                # no kind of defect at all: not even filed
    db.apply_event(sm.EVENT_KIND, "nonsense")
    mem = sm.recall(db, "T-42")
    assert mem["searches"] == 1 and mem["seed_event"] == good
    assert len(mem["ignored"]) == 6
    for msg in mem["ignored"]:
        assert msg.startswith("A stored search record (event number ") and "could not be used and was left out" in msg
        assert "Traceback" not in msg and "Error" not in msg
    assert any("command the search must never run" in m for m in mem["ignored"])
    assert any("its text is damaged" in m for m in mem["ignored"])
    opt, r2 = _search("T-42", "P19", 7, memory=mem)                 # the search runs, and says what was left out
    assert r2["search_memory"]["earlier_searches"] == 1 and len(r2["search_memory"]["ignored_records"]) == 6
    assert "left out" in r2["search_memory"]["words"]
    db.rebuild()                                                    # the damaged events do not break a rebuild

    class NoTable:                                                  # a knowledge base that cannot answer at all
        def search_memory_rows(self, sig, limit):
            raise RuntimeError("no such table")
    mem = sm.recall(NoTable(), "T-42")
    assert mem["searches"] == 0 and "could not be read" in mem["ignored"][0]
    _, r3 = _search("T-42", "P19", 0, memory=mem)
    assert r3["search_memory"]["used"] is False and "could not be read" in r3["search_memory"]["words"]

    # every damaged record and nothing else: the search is the plain one
    db2 = KGDB()
    db2.apply_event(sm.EVENT_KIND, {"sig": "T-42", "operators": "not counts"})
    oracle = SyntheticDeviceOracle("T-42", 0, seed=0, family="P19")
    opt = Optimizer(oracle, json.loads(json.dumps(PLAIN)), budget=BUDGET, rng_seed=0, memory=sm.recall(db2, "T-42"))
    assert _fingerprint(opt, opt.search()) == BEFORE["T-42|0"]


# ------------------------------------------------------------------ (g) the reward from the detector's findings
TARGET = {"sig": "C-07", "expected": ["C-07", "C-09"], "rule": "completion later than the host limit",
          "timing": {"latency_us": 43000}}


def _finding(card="C-07", verdict="CONFIRMED", score=0.8, rule="another rule", latency=None):
    f = {"card_id": card, "verdict": verdict, "closeness": score, "rule": rule, "pkt": 10, "incident": "i1", "rank": 1}
    if latency is not None:
        f["timing"] = {"latency_us": latency}
    return f


def test_g_reward_from_findings():
    # reproduced: the same error type found again and confirmed
    got = sm.stage_from_findings([_finding()], TARGET)
    assert (got["stage"], got["closeness"], got["reproduced"]) == (3, 0.8, True)
    assert "same error type was found again and confirmed" in got["basis"]
    # ... by the same first rule as the recorded failure: the top stage
    got = sm.stage_from_findings([_finding(rule=TARGET["rule"], latency=43000)], TARGET)
    assert (got["stage"], got["closeness"], got["reproduced"]) == (4, 1.0, True)
    # close: measured 41 000 microseconds against the recorded 43 000 microseconds
    close = sm.stage_from_findings([_finding(latency=41000)], TARGET)
    assert close["stage"] == 3 and close["closeness"] == round(41000 / 43000, 4)
    # far: 4 300 microseconds against 43 000 microseconds (a tenth), and far on the other side too
    far = sm.stage_from_findings([_finding(latency=4300)], TARGET)
    assert far["stage"] == 3 and far["closeness"] == 0.1 and far["closeness"] < close["closeness"]
    assert sm.stage_from_findings([_finding(latency=430000)], TARGET)["closeness"] == 0.1
    # a suspicion only: not reproduced
    got = sm.stage_from_findings([_finding(verdict="SUSPECT", latency=41000)], TARGET)
    assert (got["stage"], got["reproduced"]) == (2, False) and got["closeness"] == round(41000 / 43000, 4)
    # a member of the expected group counts as the same failure
    assert sm.stage_from_findings([_finding(card="C-09")], TARGET)["stage"] == 3
    # wrong error type: same family -> stage 1 with 0.5; another family -> nothing
    got = sm.stage_from_findings([_finding(card="C-31")], TARGET)
    assert (got["stage"], got["closeness"], got["reproduced"]) == (1, 0.5, False)
    got = sm.stage_from_findings([_finding(card="T-42", latency=43000)], TARGET)
    assert (got["stage"], got["closeness"], got["reproduced"]) == (0, 0.0, False)
    # no findings
    for nothing in ([], None):
        got = sm.stage_from_findings(nothing, TARGET)
        assert (got["stage"], got["closeness"], got["reproduced"]) == (0, 0.0, False)
        assert "found nothing" in got["basis"]
    # the best finding of a run counts; a detector score outside 0 to 1 is limited; odd findings do not crash
    got = sm.stage_from_findings(["junk", {"card_id": None}, _finding(card="C-31"), _finding(verdict="SUSPECT", score=7.0),
                                  _finding(score="x")], TARGET)
    assert (got["stage"], got["closeness"]) == (3, 0.0)
    assert sm.stage_from_findings([_finding(verdict="SUSPECT", score=7.0)], TARGET)["closeness"] == 1.0


def test_g2_the_search_uses_findings_when_the_record_has_no_simulator_value():
    sim = SyntheticDeviceOracle("C-07", 0, seed=0, family="P02")
    rec = sim.run(PLAIN)
    assert sm.complete_run_record(rec, TARGET) is rec               # what the simulated bench returns is not changed

    class FindingsBench:
        """A bench as a real drive gives it: the detector's findings and the bench time, no stage and no closeness."""
        def __init__(self):
            self.calls = 0

        def run(self, sc):
            self.calls += 1
            qd = sc["timing"]["qd"]
            if qd >= 32:
                found = [_finding(latency=43000 * min(1.0, qd / 64.0))]
            elif qd >= 16:
                found = [_finding(verdict="SUSPECT", latency=20000)]
            else:
                found = []
            return {"findings": found, "cost_s": 3.0, "trace": "capture.csv"}

    bench = FindingsBench()
    opt = Optimizer(bench, json.loads(json.dumps(PLAIN)), budget=200, rng_seed=1, target=TARGET)
    r = opt.search()
    assert r["status"] == "confirmed" and r["best_scenario"]["timing"]["qd"] >= 32
    assert opt.trials[0]["stage"] == 0 and opt.trials[0]["reward"] == 0.0        # seed: queue depth 8, nothing found
    for t in opt.trials:
        assert t["reward"] == round(t["stage"] + t["closeness"], 3)
    assert opt.still_fails(r["best_scenario"]) is True
    filled = opt.run_bench(r["best_scenario"])
    assert filled["reward_from"] == "findings" and filled["reproduced"] and "same error type" in filled["reward_basis"]
    # "isolated" (the findings of the expected error types) is read when "findings" is missing
    got = sm.complete_run_record({"isolated": [_finding()], "cost_s": 1.0}, TARGET)
    assert (got["stage"], got["reproduced"]) == (3, True)
    # neither a stage nor findings: a plain message, not a guess
    try:
        sm.complete_run_record({"cost_s": 1.0}, TARGET)
        raise AssertionError("expected a ValueError")
    except ValueError as e:
        assert "neither a stage nor the detector's findings" in str(e)


def test_g3_a_bench_that_returns_findings_only_works_in_the_flow_wrapper():
    class Real:
        sig, expected, calls = "C-07", {"C-07", "C-09"}, 0

        def run(self, sc):
            self.calls += 1
            return {"trace": "capture.csv", "cost_s": 4.0,
                    "isolated": [_finding(latency=40000)] if sc["timing"]["qd"] >= 32 else []}

    real = Real()
    bench = sm.BenchWithStage(real, TARGET)
    low = bench.run(PLAIN)
    assert (low["stage"], low["closeness"], low["reproduced"], low["reward_from"]) == (0, 0.0, False, "findings")
    high = bench.run(dict(PLAIN, timing=dict(PLAIN["timing"], qd=64)))
    assert high["reproduced"] and high["stage"] == 3 and high["closeness"] == round(40000 / 43000, 4)
    assert bench.calls == 2 and bench.expected == {"C-07", "C-09"} and bench.sig == "C-07"   # the bench's own values stay reachable
    sim = SyntheticDeviceOracle("C-07", 0, seed=0, family="P02")
    twin = SyntheticDeviceOracle("C-07", 0, seed=0, family="P02")
    wrapped = sm.BenchWithStage(sim, TARGET)
    for _ in range(5):                                           # the simulated bench's records are not changed
        assert wrapped.run(PLAIN) == twin.run(PLAIN)


# ------------------------------------------------------------------ the whole flow: search, store, search again
def test_i_the_flow_stores_what_a_search_learned_and_the_next_search_starts_from_it():
    from stage1_adapter import Incident
    from stage2_v3 import SimAdmin, Stage2V3

    class NoBench:                                               # no lab check here (closed_loop=False): the search runs on the device model
        def __init__(self, sig, expected):
            self.sig, self.expected, self.calls, self.seconds = sig, set(expected), 0, 0.0

    def incident(i):
        return Incident(id="INC-%04d" % i, card="T-42", candidates=[], verdict="CONFIRMED", layer="config", pattern="P19",
                        origin="host", task="t", first_abnormal={"pkt": 37395, "rule": "CFG.D0_EARLY", "detail": "x"},
                        packets=(1, 2), evidence_packets=[], rows=[{"range": [1, 3], "rows": ["Packet=1 | TLP Type=CfgWr0 | x"]}],
                        explanation={}, nvme_commands=[], tokens=[], firmware="FW-A", raw={})

    with tempfile.TemporaryDirectory() as d:
        db = KGDB()
        s2 = Stage2V3(db, suite_dir=os.path.join(d, "suite"), opt_budget=BUDGET, closed_loop=False, use_llm=False,
                      search_memory=True, bench_factory=lambda sig, family, expected, fixed, decoy, seed: NoBench(sig, expected))
        s2._detectability["T-42"] = {"detectable": False, "engine_candidates": []}    # no capture is generated in this test
        first = s2.handle(incident(1), SimAdmin())
        assert first["status"] == "confirmed" and first["search"]["started_from"]["used"] is False
        kinds = [k for (k,) in db.con.execute("SELECT kind FROM event")]
        assert kinds.count("search_learned") >= 1
        mem = sm.recall(db, "T-42")
        assert mem["seed"] == first["best"]                      # the shortened procedure is what is stored
        assert first["stress"] is None or mem["stress"]["scenario"] == first["stress"]["scenario"]
        # the same kind of defect is searched again on another random stream (the action "restart_failed")
        ctx = s2.present(incident(2))
        second = s2.execute(incident(2), ctx, {"action": "restart_failed", "sig": "T-42", "requester": "admin",
                                              "approver": "second_admin", "attempt": 1})
        started = second["search"]["started_from"]
        assert second["status"] == "confirmed" and started["used"] and started["earlier_searches"] >= 1
        assert started["words"].startswith("Started from what ")
        assert second["trials"] < first["trials"], (first["trials"], second["trials"])
        print("\nflow: first search %d lab runs, second search of the same kind %d lab runs" % (first["trials"], second["trials"]))
        # improvements shown on the screen are those of this search only, not the counts it started from
        assert sum(o["improvements"] for o in second["search"]["operators_that_helped"]) <= second["trials"]

        # a search that finds nothing is retried once inside the same request. Both attempts start from the same
        # history (here: none), so the first request for a kind of defect runs exactly as it did without the memory;
        # what both attempts learned is stored for the next request.
        db3 = KGDB()
        s3 = Stage2V3(db3, suite_dir=os.path.join(d, "suite3"), opt_budget=12, closed_loop=False, use_llm=False, stress_trials=0,
                      search_memory=True, bench_factory=lambda sig, family, expected, fixed, decoy, seed: NoBench(sig, expected))
        s3._detectability["T-42"] = {"detectable": False, "engine_candidates": []}
        out = s3.handle(incident(3), SimAdmin())
        learned = [json.loads(p) for (p,) in db3.con.execute("SELECT payload FROM event WHERE kind='search_learned' ORDER BY id")]
        assert out["status"] == "budget_exhausted" and len(learned) == 2
        assert [x["started_from_earlier_searches"] for x in learned] == [0, 0]
        assert sm.recall(db3, "T-42")["searches"] == 2
        assert all(x["trials"] <= 12 for x in learned)              # each record holds its own lab runs, not the sum
        assert out["trials"] == sum(x["trials"] for x in learned)

        # switched off, the flow stores nothing and says so
        db4 = KGDB()
        s4 = Stage2V3(db4, suite_dir=os.path.join(d, "suite4"), opt_budget=12, closed_loop=False, use_llm=False, stress_trials=0,
                      search_memory=False, bench_factory=lambda sig, family, expected, fixed, decoy, seed: NoBench(sig, expected))
        s4._detectability["T-42"] = {"detectable": False, "engine_candidates": []}
        out4 = s4.handle(incident(4), SimAdmin())
        assert db4.con.execute("SELECT COUNT(*) FROM event WHERE kind='search_learned'").fetchone()[0] == 0
        assert "switched off" in out4["search"]["started_from"]["words"]


# ------------------------------------------------------------------ the other search (stage2.optimizer = ppo)
def test_h_the_policy_gradient_search_uses_the_same_memory():
    db = KGDB()
    _, r1 = _search("T-42", "P19", 0, memory=sm.recall(db, "T-42"), cls=PPOOptimizer)
    assert r1["policy"] == "ppo" and r1["search_memory"]["used"] is False
    sm.remember(db, "T-42", r1, family="P19", optimizer="ppo")
    opt, r2 = _search("T-42", "P19", 1000, memory=sm.recall(db, "T-42"), cls=PPOOptimizer)
    assert r2["search_memory"]["used"] and r2["search_memory"]["earlier_searches"] == 1
    assert "from_earlier_searches" in [t["tag"] for t in opt.trials]
    # without memory the policy starts with every weight at zero, as before
    plain = PPOOptimizer(SyntheticDeviceOracle("T-42", 0, seed=0, family="P19"), family_template_scenario("P19"), budget=60, rng_seed=0)
    assert all(w == 0.0 for row in plain.theta for w in row)


if __name__ == "__main__":
    rows = measure()
    print(json.dumps(summary(rows), indent=1))
    for sig, _ in KINDS:
        print(sig, json.dumps(summary([r for r in rows if r[0] == sig])))
