"""The hierarchy of the rules library (owner, 2026-11-15): Section -> Kind of recording -> Level -> items.

  - agentic/rule_hierarchy.py: the default hierarchy, the labels under "Errors" and under "Data analytics", the place of
    the existing items (their keys unchanged), kinds and levels the admin adds, edits and deletes, with the refusals;
  - app/api/rules_hierarchy_api.py: the routes, hostile input answered with 400 and a plain sentence;
  - an item of a level the admin added: a valid key, shown under its level, written and run on that level's file by the
    stand-in flow (no model);
  - a library folder of the previous version (no kinds file): opens with the default hierarchy, nothing written;
  - app/static/js/agents.js: the three layers, the four places to add, the place line, the reason under every field,
    nothing pre-selected, no raw key on the screen, no top-level name declared twice, node --check; the page's own
    drawing functions run by node against the real answers of the routes, with and without the hierarchy routes;
  - groups of items inside a level (the rule families seeded under Errors > NVMe errors > NVMe command level errors, by
    the real seed() in a throw-away library): the groups in the seeding module's order with its own meanings, the counts,
    the place of an item with its group, the field "group" never taken for a level the admin added (and the other way
    round), the search over one level, the question of the add form, and the older names of the sections gone from
    what the screens show.

No browser and no model. Every test has its own throw-away application and knowledge folder under pytest's temporary
folder; nothing is written into the application's own folders. A page file written beside the original can be checked
before it is renamed into place: RULE_HIER_JS=<that file>.
"""
import copy
import json
import os
import re
import shutil
import subprocess
import sys
import time

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import admin_ask, core, family1, family3, pipeline  # noqa: E402
from agentic import rule_hierarchy as RH  # noqa: E402

NODE = "/home/raghavendra/.nvm/versions/node/v22.23.2/bin/node"
JS = os.environ.get("RULE_HIER_JS") or os.path.join(APP, "app", "static", "js", "agents.js")
FIVE = {"analytics/nvme_command/command_type_share": ["Data analytics", "NVMe and PCIe recording (Teledyne LeCroy five-file export)", "NVMe command level"],
        "analytics/nvme_command/read_pattern": ["Data analytics", "NVMe and PCIe recording (Teledyne LeCroy five-file export)", "NVMe command level"],
        "analytics/nvme_command/near_limit": ["Data analytics", "NVMe and PCIe recording (Teledyne LeCroy five-file export)", "NVMe command level"],
        "errors/nvme_command/cmd_timeout": ["Errors", "NVMe errors", "NVMe command level errors"],
        "errors/nvme_command/cmd_read_failure": ["Errors", "NVMe errors", "NVMe command level errors"]}
HOSTILE_NAMES = [("", "give"), ("   ", "give"), ("x" * 5000, "under 60 characters"), ("ab\x00cd", "NUL"), ("../../etc/passwd", "path"), ("a/b", "path"),
                 ("c:\\windows", "path"), (None, "must be text"), (17, "must be text"), (["a"], "must be text"), ({"a": 1}, "must be text")]


# ------------------------------------------------------------------------------------------------ the throw-away library and application
@pytest.fixture()
def lib(tmp_path, monkeypatch):
    """A knowledge folder of the test's own, seeded as a new installation is."""
    know = str(tmp_path / "knowledge")
    os.makedirs(know)
    monkeypatch.setattr(family1, "knowledge_dir", lambda: know)
    family3._SECTIONS_SEEN[0] = None
    family3.tree()                    # the seed of a new installation
    # (2026-11-15) a new installation starts "Commands that completed but came close to the limit" in Deleted items (Data analytics reads
    # one CSV file, and it needs the NVMe transaction file too): restored here, so the cards of an item whose code is the application's are
    # still checked on it
    family3.restore_item("analytics", "nvme_command", "near_limit", "Sagar")
    # (2026-11-15) the owner kept only the top 3 NVMe command errors: a new installation keeps one rule family as a live item and starts the
    # other 37 in Deleted items (tests/test_top_three_rules.py checks that). Restored here the same way, so the groups of the level are
    # still checked with their 24, 8 and 6 items
    for x in family3.deleted_items():
        if x["by"] == family3.INSTALL_TOP_THREE_BY:
            family3.restore_item(x["section"], x["level"], x["id"], "Sagar")
    family3.tree()
    yield know
    family3._SECTIONS_SEEN[0] = None


class World:
    def __init__(self, root, know, mp):
        from api import config_api, hier_api
        self.root, self.know = str(root), know
        mp.setattr(config_api, "save_config", lambda c: None)
        mp.setattr(hier_api, "ENV_FILE", os.path.join(self.root, "env"))       # a test never reaches the real key file
        kick = getattr(sys.modules.get("fuzz_app"), "REAL_KICK", None)          # another test file of the session may have switched the engine's start off
        if kick is not None:
            mp.setattr(core.Engine, "kick", kick)
        with open(os.path.join(APP, "config", "app_config.json"), encoding="utf-8") as fh:
            cfg = copy.deepcopy(json.load(fh))
        cfg["_path"] = os.path.join(self.root, "app_config.json")
        cfg["llm"].update(base_url="http://127.0.0.1:9", api_key_env="RULE_HIERARCHY_NO_SUCH_KEY", backend="http")
        cfg["agentic"].update(runtime="standin", web=False)
        from server import create_app
        self.app = create_app(cfg, self.root)
        from api import rules_hierarchy_api
        if "rules_hierarchy" not in self.app.blueprints:           # the coordinator registers it in app/server.py; until then the test does
            self.app.register_blueprint(rules_hierarchy_api.bp)
        self.app.config["PROPAGATE_EXCEPTIONS"] = False
        self.app.logger.disabled = True
        self.c = self.app.test_client()

    def engine(self):
        with self.app.app_context():
            from api.agentic_api import engine
            return engine()

    def hier(self):
        r = self.c.get("/api/agents/rule-hierarchy")
        assert r.status_code == 200, r.get_data(as_text=True)[:300]
        return r.get_json()

    def add_kind(self, label="Bench logs", about="CSV logs our bench tool writes"):
        r = self.c.post("/api/agents/rule-hierarchy/kinds", json={"label": label, "about": about, "admin": "Sagar"})
        assert r.status_code == 200, r.get_json()
        return r.get_json()["kind"]

    def add_level(self, kid, label="Bench rows", file="bench_*.csv", about="one command the bench sent"):
        r = self.c.post("/api/agents/rule-hierarchy/kinds/%s/levels" % kid, json={"label": label, "file": file, "about": about, "admin": "Sagar"})
        assert r.status_code == 200, r.get_json()
        return r.get_json()["level"]


@pytest.fixture()
def world(tmp_path, lib, monkeypatch):
    from agentic import procedures
    uploads = procedures._UPLOADS[0]            # create_app points the uploads folder at the throw-away application: put back for the tests that follow
    try:
        yield World(tmp_path / "app", lib, monkeypatch)
    finally:
        procedures.use_uploads_folder(uploads)


def listing(folder):
    out = {}
    for d, _dirs, files in os.walk(folder):
        for f in files:
            p = os.path.join(d, f)
            out[os.path.relpath(p, folder)] = (os.path.getsize(p), os.path.getmtime(p))
    return out


def levels_of(section, kind_id):
    return next(k for k in section["kinds"] if k["kind"] == kind_id)["levels"]


def refused(r, word):
    """A refusal: 400, one plain sentence that says why, and nothing of the machinery in it."""
    body = r.get_json()
    assert r.status_code == 400, (r.status_code, body)
    assert isinstance(body, dict) and isinstance(body.get("error"), str) and word.lower() in body["error"].lower(), body
    assert len(body["error"]) < 400 and "Traceback" not in body["error"] and "\x00" not in body["error"], body["error"][:200]


# ------------------------------------------------------------------------------------------------ 1. the default hierarchy
def test_the_default_hierarchy_has_three_layers_in_the_owners_order(lib):
    h = RH.hierarchy()
    assert [s["name"] for s in h["sections"]] == ["Data analytics", "Errors"]
    assert [s["section"] for s in h["sections"]] == ["analytics", "errors"]            # the stored ids are the old ones
    assert [k["id"] for k in h["kinds"]] == ["lecroy_nvme_pcie", "other_csv"]
    assert [l["id"] for l in h["kinds"][0]["levels"]] == ["nvme_command", "nvme_transaction", "split", "link", "packets"]
    assert [l["id"] for l in h["kinds"][1]["levels"]] == ["other"]
    ana, err = h["sections"]
    assert [k["label"] for k in ana["kinds"]] == ["NVMe and PCIe recording (Teledyne LeCroy five-file export)", "Other CSV files (any tool)"]
    assert [l["label"] for l in levels_of(ana, "lecroy_nvme_pcie")] == ["NVMe command level", "NVMe transaction level", "Split transaction level",
                                                                      "Link transaction level", "PCIe packet level"]
    assert [l["label"] for l in levels_of(ana, "other_csv")] == ["Other CSV files"]
    assert err["kinds"][0]["label"] == "NVMe errors"
    assert [l["label"] for l in levels_of(err, "lecroy_nvme_pcie")] == ["NVMe command level errors", "NVMe transaction level errors", "Split transaction level errors",
                                                                      "Link transaction level errors", "PCIe packet level errors"]
    assert [l["label"] for l in levels_of(err, "other_csv")] == ["Errors in other CSV files"]
    assert err["defects"] is True and ana["defects"] is False and all(s["builtin"] for s in h["sections"]) and all(k["builtin"] for k in h["kinds"])
    # every stored level belongs to exactly one built-in kind, so the kind never needs to be in an item's key
    assert sorted(l["id"] for k in h["kinds"] for l in k["levels"]) == sorted(family3.LEVELS)
    assert family3.SECTIONS["errors"] == "Section 2 · Errors" and "errors" in family3.SECTION_INFO


def test_the_existing_items_are_at_their_place_and_their_keys_are_unchanged(lib):
    h = RH.hierarchy()
    found = {}
    for s in h["sections"]:
        for k in s["kinds"]:
            for l in k["levels"]:
                for it in RH.items_of(l):                                   # the ones in no group, then group by group
                    found[it["key"]] = (it["place"], l["level"], it)
    for key, place in FIVE.items():
        assert key in found, (key, sorted(found))
        got, level, it = found[key]
        assert got[:3] == place and got[3] == it["name"] and len(got) == 4 and it["in_group"] is None      # in no group: directly under the level
        sec, lvl, rid = pipeline.split_item(key)[:3] if hasattr(pipeline, "split_item") else key.split("/")
        assert (sec, lvl, rid) == tuple(key.split("/")) and lvl == level
        r = family3.load_rule(sec, lvl, rid)
        assert r and r["id"] == rid and "group" not in r                     # the stored item is not touched
        assert os.path.exists(os.path.join(lib, "rules", sec, lvl, rid + ".json"))
        assert RH.place_of(sec, lvl, rid) == got
    assert RH.place_of("errors", "nvme_command", "cmd_timeout") == ["Errors", "NVMe errors", "NVMe command level errors", "NVMe command timeout"]
    assert RH.place_of("errors", "nvme_command", "no_such_item") is None
    # the tree the older routes give is the same list of items: the hierarchy only groups it
    assert sorted(found) == sorted("%s/%s/%s" % (s["section"], l["level"], i["id"]) for s in family3.tree() for l in s["levels"] for i in l["items"])


def test_a_library_of_the_previous_version_opens_without_anything_written(world, lib):
    rules = os.path.join(lib, "rules")
    assert not os.path.exists(os.path.join(rules, "kinds.json"))
    with open(os.path.join(rules, "sections.json"), "w", encoding="utf-8") as fh:        # as the previous version wrote an admin's section
        json.dump([{"id": "timing_checks", "label": "Timing checks", "about": "", "defects": True, "builtin": False, "created_by": "Sagar", "created": 1.0}], fh)
    family3._SECTIONS_SEEN[0] = None
    before = listing(rules)
    h1 = RH.hierarchy()
    h2 = world.hier()
    RH.place_of("analytics", "nvme_command", "read_pattern")
    RH.files_of_level({"level": "other", "group": "g_gone"}, [{"file": "a.csv"}])
    assert listing(rules) == before and not os.path.exists(os.path.join(rules, "kinds.json"))
    assert [s["name"] for s in h1["sections"]] == ["Data analytics", "Errors", "Timing checks"] == [s["name"] for s in h2["sections"]]
    assert [k["id"] for k in h1["kinds"]] == ["lecroy_nvme_pcie", "other_csv"]
    assert h1["sections"][2]["kinds"][0]["label"] == "NVMe errors" and h1["sections"][2]["builtin"] is False       # a section that finds defects reads like Errors
    kind = world.add_kind()                                                   # the admin adds something: only now is the file made
    assert os.path.exists(os.path.join(rules, "kinds.json")) and kind["builtin"] is False
    after = listing(rules)
    assert set(after) - set(before) == {"kinds.json"} and all(after[k] == before[k] for k in before)
    # a damaged kinds file reads as none, and the library still opens
    with open(os.path.join(rules, "kinds.json"), "w", encoding="utf-8") as fh:
        fh.write("{ this is not json")
    assert [k["id"] for k in RH.hierarchy()["kinds"]] == ["lecroy_nvme_pcie", "other_csv"]
    with open(os.path.join(rules, "kinds.json"), "w", encoding="utf-8") as fh:
        json.dump({"kinds": "x", "levels": [7, {"id": 3}, None]}, fh)
    assert [k["id"] for k in world.hier()["kinds"]] == ["lecroy_nvme_pcie", "other_csv"]


# ------------------------------------------------------------------------------------------------ 2. kinds of recording
def test_a_kind_of_recording_is_added_edited_and_deleted(world):
    c = world.c
    kind = world.add_kind("Bench logs", "CSV logs our bench tool writes")
    assert kind["label"] == "Bench logs" and kind["about"] == "CSV logs our bench tool writes" and kind["levels"] == [] and kind["builtin"] is False
    h = world.hier()
    assert [k["label"] for k in h["kinds"]] == ["NVMe and PCIe recording (Teledyne LeCroy five-file export)", "Other CSV files (any tool)", "Bench logs"]
    assert all([k["label"] for k in s["kinds"]][-1] == "Bench logs" for s in h["sections"])          # under every section, after the built-in kinds
    refused(c.post("/api/agents/rule-hierarchy/kinds", json={"label": "bench  LOGS", "admin": "Sagar"}), "exists already")
    refused(c.post("/api/agents/rule-hierarchy/kinds", json={"label": "NVMe errors", "admin": "Sagar"}), "exists already")
    refused(c.post("/api/agents/rule-hierarchy/kinds", json={"label": "Other CSV files (any tool)", "admin": "Sagar"}), "exists already")
    r = c.put("/api/agents/rule-hierarchy/kinds/%s" % kind["id"], json={"label": "Bench tool logs", "about": "changed", "admin": "Sagar"})
    assert r.status_code == 200 and r.get_json()["kind"]["label"] == "Bench tool logs" and r.get_json()["kind"]["id"] == kind["id"]
    assert c.put("/api/agents/rule-hierarchy/kinds/%s" % kind["id"], json={"label": "Bench tool logs", "about": "same name again", "admin": "Sagar"}).status_code == 200
    refused(c.put("/api/agents/rule-hierarchy/kinds/%s" % kind["id"], json={"label": "Other CSV files (any tool)", "admin": "Sagar"}), "exists already")
    refused(c.put("/api/agents/rule-hierarchy/kinds/lecroy_nvme_pcie", json={"label": "Mine", "admin": "Sagar"}), "part of the application")
    refused(c.delete("/api/agents/rule-hierarchy/kinds/other_csv", json={"admin": "Sagar"}), "part of the application")
    assert c.put("/api/agents/rule-hierarchy/kinds/no_such_kind", json={"label": "Mine", "admin": "Sagar"}).status_code == 404
    assert c.delete("/api/agents/rule-hierarchy/kinds/no_such_kind", json={"admin": "Sagar"}).status_code == 404
    level = world.add_level(kind["id"])
    refused(c.delete("/api/agents/rule-hierarchy/kinds/%s" % kind["id"], json={"admin": "Sagar"}), "still holds 1 level")
    assert c.delete("/api/agents/rule-hierarchy/levels/%s" % level["id"], json={"admin": "Sagar"}).status_code == 200
    r = c.delete("/api/agents/rule-hierarchy/kinds/%s" % kind["id"], json={"admin": "Sagar"})
    assert r.status_code == 200 and r.get_json()["deleted"] == "Bench tool logs"
    assert [k["id"] for k in world.hier()["kinds"]] == ["lecroy_nvme_pcie", "other_csv"]


@pytest.mark.parametrize("name,word", HOSTILE_NAMES)
def test_a_hostile_name_is_refused_in_a_plain_sentence(world, name, word):
    c = world.c
    kind = world.add_kind("Good kind")
    level = world.add_level(kind["id"], "Good level")
    before = json.dumps(world.hier(), sort_keys=True)
    refused(c.post("/api/agents/rule-hierarchy/kinds", json={"label": name, "about": "x", "admin": "Sagar"}), word)
    refused(c.put("/api/agents/rule-hierarchy/kinds/%s" % kind["id"], json={"label": name, "about": "x", "admin": "Sagar"}), word)
    refused(c.post("/api/agents/rule-hierarchy/kinds/%s/levels" % kind["id"], json={"label": name, "file": "a.csv", "admin": "Sagar"}), word)
    refused(c.put("/api/agents/rule-hierarchy/levels/%s" % level["id"], json={"label": name, "file": "a.csv", "admin": "Sagar"}), word)
    assert json.dumps(world.hier(), sort_keys=True) == before                # a refusal changes nothing


def test_other_hostile_requests_are_refused_and_change_nothing(world):
    c = world.c
    kind = world.add_kind("Good kind")
    level = world.add_level(kind["id"], "Good level")
    before = json.dumps(world.hier(), sort_keys=True)
    for file, word in [("", "which file"), (None, "must be text"), (5, "must be text"), ("../secret.csv", "not a path"), ("/etc/passwd", "not a path"),
                       ("c:\\x.csv", "not a path"), ("a\x00.csv", "NUL"), ("x" * 5000, "under 120 characters"), ("a\nb.csv", "file name cannot have"), ("<b>.csv", "file name cannot have")]:
        refused(c.post("/api/agents/rule-hierarchy/kinds/%s/levels" % kind["id"], json={"label": "L", "file": file, "admin": "Sagar"}), word)
        refused(c.put("/api/agents/rule-hierarchy/levels/%s" % level["id"], json={"label": "L", "file": file, "admin": "Sagar"}), word)
    refused(c.post("/api/agents/rule-hierarchy/kinds", json={"label": "Fine", "about": "y" * 5000, "admin": "Sagar"}), "under 400 characters")
    refused(c.post("/api/agents/rule-hierarchy/kinds", json={"label": "Fine", "about": ["a"], "admin": "Sagar"}), "must be text")
    refused(c.post("/api/agents/rule-hierarchy/kinds", json={"label": "Fine", "about": "a\x00b", "admin": "Sagar"}), "NUL")
    refused(c.post("/api/agents/rule-hierarchy/kinds", json={"label": "Fine", "admin": {"x": 1}}), "admin")
    refused(c.post("/api/agents/rule-hierarchy/kinds", json={"label": "Fine", "admin": "s" * 5000}), "admin")
    # a body that is not an object, or not JSON at all: refused in a sentence (by the application's own guard, or as a request without a name), never an error of the server
    for raw in (b"[1, 2]", b"\"text\"", b"{ not json", b"", b"\xff\xfe\x00"):
        r = c.post("/api/agents/rule-hierarchy/kinds", data=raw, content_type="application/json")
        assert r.status_code == 400 and isinstance((r.get_json() or {}).get("error"), str) and "Traceback" not in r.get_json()["error"], (raw, r.status_code)
    for path in ("/api/agents/rule-hierarchy/kinds/%s/levels" % ("x" * 3000), "/api/agents/rule-hierarchy/kinds/..%2F..%2Fetc/levels", "/api/agents/rule-hierarchy/kinds/a%00b/levels"):
        r = c.post(path, json={"label": "L", "file": "a.csv", "admin": "Sagar"})
        assert r.status_code in (400, 404) and "error" in (r.get_json() or {}), (path[:60], r.status_code)
    refused(c.post("/api/agents/rule-hierarchy/kinds/lecroy_nvme_pcie/levels", json={"label": "My level", "file": "a.csv", "admin": "Sagar"}), "five levels")
    for body, word in [({"section": "nope", "level": "other", "name": "n"}, "which section"), ({"section": "analytics", "level": "nope", "name": "n"}, "which level"),
                       ({"section": "analytics", "level": ["other"], "name": "n"}, "which level"), ({"section": {"a": 1}, "level": "other", "name": "n"}, "which section"),
                       ({"section": "analytics", "level": "other", "name": ""}, "give"), ({"section": "analytics", "level": "other", "name": "n" * 5000}, "under 120"),
                       ({"section": "analytics", "level": "other", "name": "a\x00b"}, "NUL"), ({"section": "analytics", "level": "other", "name": "n", "description": 7}, "must be text"),
                       ({"section": "analytics", "level": "other", "name": "n", "description": "d" * 50000}, "under 20000")]:
        refused(c.post("/api/agents/rule-hierarchy/items", json=dict(body, admin="Sagar")), word)
    r = c.post("/api/agents/rule-hierarchy/items", json={"section": "analytics", "level": "other", "name": "n", "project": "abc", "admin": "Sagar"})
    assert r.status_code == 400 and "whole number" in r.get_json()["error"]
    assert json.dumps(world.hier(), sort_keys=True) == before
    assert not os.path.exists(os.path.join(world.know, "rules", "analytics", "other")) or not os.listdir(os.path.join(world.know, "rules", "analytics", "other"))


# ------------------------------------------------------------------------------------------------ 3. levels
def test_a_level_is_added_edited_and_deleted(world):
    c = world.c
    kind = world.add_kind("Bench logs")
    level = world.add_level(kind["id"], "Bench rows", "bench_*.csv", "one command the bench sent")
    assert level["label"] == "Bench rows" and level["file"] == "bench_*.csv" and level["level"] == "other" and level["group"] == level["id"] and level["builtin"] is False
    assert level["id"] not in family3.LEVELS and re.match(r"^[a-z0-9_]+$", level["id"])
    h = world.hier()
    for s in h["sections"]:                                     # the same level under every section, shown by the name the admin gave
        got = levels_of(s, kind["id"])
        assert [(l["label"], l["file"], l["items"]) for l in got] == [("Bench rows", "bench_*.csv", [])]
    refused(c.post("/api/agents/rule-hierarchy/kinds/%s/levels" % kind["id"], json={"label": "bench ROWS", "file": "b.csv", "admin": "Sagar"}), "already")
    refused(c.post("/api/agents/rule-hierarchy/kinds/other_csv/levels", json={"label": "Errors in other CSV files", "file": "b.csv", "admin": "Sagar"}), "already")
    assert c.post("/api/agents/rule-hierarchy/kinds/no_such/levels", json={"label": "L", "file": "b.csv", "admin": "Sagar"}).status_code == 404
    second = world.add_level("other_csv", "Bench rows", "x.csv")              # the same name under another kind is another level
    assert second["id"] != level["id"]
    r = c.put("/api/agents/rule-hierarchy/levels/%s" % level["id"], json={"label": "Bench commands", "file": "bench_log.csv", "about": "", "admin": "Sagar"})
    assert r.status_code == 200 and (r.get_json()["level"]["label"], r.get_json()["level"]["file"], r.get_json()["level"]["id"]) == ("Bench commands", "bench_log.csv", level["id"])
    refused(c.put("/api/agents/rule-hierarchy/levels/nvme_command", json={"label": "Mine", "file": "a.csv", "admin": "Sagar"}), "part of the application")
    refused(c.delete("/api/agents/rule-hierarchy/levels/other", json={"admin": "Sagar"}), "part of the application")
    assert c.put("/api/agents/rule-hierarchy/levels/g_no_such", json={"label": "Mine", "file": "a.csv", "admin": "Sagar"}).status_code == 404
    assert c.delete("/api/agents/rule-hierarchy/levels/g_no_such", json={"admin": "Sagar"}).status_code == 404
    assert c.delete("/api/agents/rule-hierarchy/levels/%s" % second["id"], json={"admin": "Sagar"}).status_code == 200
    assert c.delete("/api/agents/rule-hierarchy/levels/%s" % level["id"], json={"admin": "Sagar"}).status_code == 200
    assert levels_of(world.hier()["sections"][0], kind["id"]) == []
    with open(os.path.join(world.know, "rules", "kinds.json"), encoding="utf-8") as fh:
        stored = json.load(fh)
    assert [k["label"] for k in stored["kinds"]] == ["Bench logs"] and stored["levels"] == []


def test_an_item_of_an_admins_level_keeps_a_valid_key_and_shows_under_its_level(world):
    c = world.c
    kind = world.add_kind("Bench logs")
    level = world.add_level(kind["id"], "Bench rows", "bench_*.csv")
    r = c.post("/api/agents/rule-hierarchy/items", json={"section": "analytics", "level": level["id"], "name": "Share of each command", "description": "percentage by Command", "admin": "Sagar"})
    assert r.status_code == 200, r.get_json()
    key, rule = r.get_json()["key"], r.get_json()["rule"]
    assert key == "analytics/other/share_of_each_command" and rule["level"] == "other" and rule["group"] == level["id"]
    assert pipeline.split_item(key)[:3] == ("analytics", "other", "share_of_each_command")
    assert os.path.exists(os.path.join(world.know, "rules", "analytics", "other", "share_of_each_command.json"))
    assert c.get("/api/agents/rules/analytics/other/share_of_each_command").status_code == 200      # the older routes know it by the same key
    ana = world.hier()["sections"][0]
    mine = levels_of(ana, kind["id"])[0]
    assert [(i["key"], i["place"]) for i in mine["items"]] == [(key, ["Data analytics", "Bench logs", "Bench rows", "Share of each command"])]
    assert levels_of(ana, "other_csv")[0]["items"] == []                       # not also under the plain "Other CSV files"
    assert [i["id"] for l in next(s for s in family3.tree() if s["section"] == "analytics")["levels"] if l["level"] == "other" for i in l["items"]] == ["share_of_each_command"]
    # a plain "Other CSV files" item, and one at a built-in level, through the same route
    r2 = c.post("/api/agents/rule-hierarchy/items", json={"section": "errors", "level": "other", "name": "Timed out rows", "admin": "Sagar"})
    r3 = c.post("/api/agents/rule-hierarchy/items", json={"section": "errors", "level": "nvme_transaction", "name": "Late completion", "admin": "Sagar"})
    assert r2.get_json()["key"] == "errors/other/timed_out_rows" and "group" not in r2.get_json()["rule"]
    assert r3.get_json()["key"] == "errors/nvme_transaction/late_completion"
    err = world.hier()["sections"][1]
    assert [i["place"] for i in levels_of(err, "other_csv")[0]["items"]] == [["Errors", "Errors in other CSV files (any tool)", "Errors in other CSV files", "Timed out rows"]]
    assert [i["place"][:3] for i in levels_of(err, "lecroy_nvme_pcie")[1]["items"]] == [["Errors", "NVMe errors", "NVMe transaction level errors"]]
    # a level that still holds an item cannot be deleted, and says why; after the item is deleted (and can be restored) it can
    refused(c.delete("/api/agents/rule-hierarchy/levels/%s" % level["id"], json={"admin": "Sagar"}), "still holds 1 item")
    refused(c.delete("/api/agents/rule-hierarchy/kinds/%s" % kind["id"], json={"admin": "Sagar"}), "still holds 1 level")
    assert next(l for k in world.hier()["kinds"] for l in k["levels"] if l["id"] == level["id"])["holds"] == 1
    assert c.delete("/api/agents/rules/%s" % key, json={"admin": "Sagar", "why": "test"}).status_code == 200
    assert c.delete("/api/agents/rule-hierarchy/levels/%s" % level["id"], json={"admin": "Sagar"}).status_code == 200
    # restored after its level is gone: it is not lost, it shows under the plain "Other CSV files"
    assert c.post("/api/agents/rules/%s/restore" % key, json={"admin": "Sagar"}).status_code == 200
    assert [i["key"] for i in levels_of(world.hier()["sections"][0], "other_csv")[0]["items"]] == [key]


def test_an_admins_section_is_edited_and_deleted_only_when_empty(world):
    c = world.c
    r = c.post("/api/agents/rules/sections", json={"label": "Timing checks", "about": "how long things take", "defects": True, "admin": "Sagar"})
    sid = r.get_json()["section"]["id"]
    r = c.put("/api/agents/rule-hierarchy/sections/%s" % sid, json={"label": "Timing rules", "about": "changed", "admin": "Sagar"})
    assert r.status_code == 200 and r.get_json()["section"]["label"] == "Timing rules" and r.get_json()["section"]["defects"] is True
    assert [s["name"] for s in world.hier()["sections"]] == ["Data analytics", "Errors", "Timing rules"]
    refused(c.put("/api/agents/rule-hierarchy/sections/%s" % sid, json={"label": "errors", "admin": "Sagar"}), "exists already")
    refused(c.put("/api/agents/rule-hierarchy/sections/%s" % sid, json={"label": "x" * 5000, "admin": "Sagar"}), "under 60")
    refused(c.put("/api/agents/rule-hierarchy/sections/errors", json={"label": "Mine", "admin": "Sagar"}), "part of the application")
    refused(c.delete("/api/agents/rule-hierarchy/sections/analytics", json={"admin": "Sagar"}), "part of the application")
    assert c.delete("/api/agents/rule-hierarchy/sections/no_such", json={"admin": "Sagar"}).status_code == 404
    key = c.post("/api/agents/rule-hierarchy/items", json={"section": sid, "level": "nvme_command", "name": "Slow admin command", "admin": "Sagar"}).get_json()["key"]
    refused(c.delete("/api/agents/rule-hierarchy/sections/%s" % sid, json={"admin": "Sagar"}), "still holds 1 item")
    assert c.delete("/api/agents/rules/%s" % key, json={"admin": "Sagar"}).status_code == 200
    refused(c.delete("/api/agents/rule-hierarchy/sections/%s" % sid, json={"admin": "Sagar"}), "can still be restored")
    assert c.post("/api/agents/rules/%s/restore" % key, json={"admin": "Sagar"}).status_code == 200
    assert [s["name"] for s in world.hier()["sections"]] == ["Data analytics", "Errors", "Timing rules"]
    r = c.post("/api/agents/rules/sections", json={"label": "Empty one", "about": "", "defects": False, "admin": "Sagar"})
    assert c.delete("/api/agents/rule-hierarchy/sections/%s" % r.get_json()["section"]["id"], json={"admin": "Sagar"}).status_code == 200
    assert [s["name"] for s in world.hier()["sections"]] == ["Data analytics", "Errors", "Timing rules"]


# ------------------------------------------------------------------------------------------------ 4. the rule of an admin's level runs on its file
def test_the_rule_of_an_admins_level_is_offered_coded_and_run_on_the_levels_file(world, tmp_path):
    """The stand-in flow (no model) on a folder with two CSV files that both have a column Command. The item belongs to a
    level whose file is bench_*.csv: its procedure is written on bench_log.csv (300 rows), not on the other file, which the
    stand-in would otherwise take first; the Coder's code is run and counts the 300 rows."""
    import random
    folder = str(tmp_path / "bench")
    os.makedirs(folder)
    with open(os.path.join(folder, "a_first.csv"), "w", encoding="utf-8", newline="") as fh:
        fh.write("Command,Note\n" + "".join("Trim,%d\n" % i for i in range(12)))
    random.seed(7)
    with open(os.path.join(folder, "bench_log.csv"), "w", encoding="utf-8", newline="") as fh:
        fh.write("Command,Queue,Latency_us,Result\n")
        for i in range(300):
            fh.write("%s,%d,%d,%s\n" % (random.choice(["Read"] * 6 + ["Write"] * 3 + ["Flush"]), random.randint(1, 4), random.randint(80, 9000), "ok" if i % 50 else "timeout"))
    kind = world.add_kind("Bench logs")
    level = world.add_level(kind["id"], "Bench rows", "bench_*.csv")
    key = world.c.post("/api/agents/rule-hierarchy/items", json={"section": "analytics", "level": level["id"], "name": "Share of each command",
                                                                 "description": "percentage by Command", "admin": "Sagar"}).get_json()["key"]
    files = [{"file": "a_first.csv", "level": "x", "columns": []}, {"file": "bench_log.csv", "level": "x", "columns": []}]
    assert [f["file"] for f in RH.files_of_level(family3.load_rule(*key.split("/")), files)] == ["bench_log.csv"]
    assert RH.files_of_level({"level": "other"}, files) == files and RH.files_of_level({"level": "nvme_command", "group": level["id"]}, files) == files
    eng = world.engine()
    store = eng.store
    pid = store.exec("INSERT INTO project (admin, name, folder, refs, created, updated) VALUES (?,?,?,?,?,?)", ("Sagar", "bench", folder, "[]", time.time(), time.time()))
    rid = eng.start(pid, "flow", "", {"started_by": "Sagar"})
    seen, plan, t0 = [], None, time.time()
    while time.time() - t0 < 240:
        run = store.one("SELECT * FROM run WHERE id=?", (rid,))
        failed = store.one("SELECT key, error FROM step WHERE run=? AND state='failed'", (rid,))
        assert not failed, (failed["key"], failed["error"][-1500:])
        if run["state"] != "running":
            break
        rv = store.one("SELECT * FROM review WHERE run=? AND state='open' ORDER BY id LIMIT 1", (rid,))
        if not rv:
            time.sleep(0.1)
            continue
        step = store.one("SELECT key FROM step WHERE id=?", (rv["step"],))["key"]
        seen.append(step)
        edits = None
        if step == admin_ask.GATE:
            edits = {"stage2": "skip"}
        elif step == "f3_plan":
            plan = json.loads(rv["data"])
            edits = {"selected": [key]}
        eng.decide(rv["id"], "approve", "Sagar", "", edits)
    else:
        raise AssertionError("the flow did not finish in time: %s" % seen)
    assert store.one("SELECT state FROM run WHERE id=?", (rid,))["state"] == "finished", seen
    offered = next(i for i in plan["items"] if i["key"] == key)                 # the plan offers it, and says nothing stops it here
    assert not offered.get("blocked") and offered["level"] == "other" and offered["section"] == "analytics"
    steps = {s["key"]: s for s in store.all("SELECT * FROM step WHERE run=? ORDER BY idx", (rid,))}
    assert {"f3:%s:%s" % (key, k) for k in ("write", "run", "result")} <= set(steps), sorted(steps)
    assert [s.split(":")[-1] for s in seen if s.startswith("f3:")] == ["write", "req", "code", "result"], seen
    proc = family3.load_rule(*key.split("/"))
    from agentic import procedures as PR
    assert [x["file"] for x in PR.procedure_of(proc)["source_data"]] == ["bench_log.csv"]
    assert PR.code_state(proc)["verified"] and proc["group"] == level["id"]
    out = json.loads(steps["f3:%s:run" % key]["output"])
    assert out["columns"] == ["Command", "count", "percent"] and sum(int(r[1]) for r in out["head"]) == 300 and {r[0] for r in out["head"]} == {"Read", "Write", "Flush"}
    assert [i["key"] for i in levels_of(world.hier()["sections"][0], kind["id"])[0]["items"]] == [key]       # still at its place after the run


# ------------------------------------------------------------------------------------------------ 5. the page script
def script():
    with open(JS, encoding="utf-8") as fh:
        return fh.read()


def piece(text, name):
    m = re.search(r"^(?:async )?function %s\(.*?^}\n" % re.escape(name), text, re.M | re.S)
    if m:
        return m.group(0)
    m = re.search(r"^const %s = .*?;\n" % re.escape(name), text, re.M | re.S)
    assert m, "the page script has no top-level %s" % name
    return m.group(0)


def words(html):
    """What a person reads: the text between the tags, without attributes."""
    return re.sub(r"\s+", " ", re.sub(r"<[^>]*>", " ", html)).replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")


def test_the_page_script_is_a_sound_classic_script(tmp_path):
    text = script()
    with open(os.path.join(APP, "app", "static", "agents.html"), encoding="utf-8") as fh:
        page = fh.read()
    assert '<script src="/static/js/agents.js"></script>' in page                # a classic script, not a module: checked as .cjs
    names = re.findall(r"^(?:async )?function ([A-Za-z0-9_$]+)\(", text, re.M) + re.findall(r"^(?:const|let|var) ([A-Za-z0-9_$]+)\b", text, re.M)
    twice = sorted({n for n in names if names.count(n) > 1})
    assert not twice, "declared twice at the top level: %s" % twice
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    cjs = str(tmp_path / "agents_check.cjs")
    shutil.copyfile(JS, cjs)
    p = subprocess.run([NODE, "--check", cjs], capture_output=True, text=True, encoding="utf-8", timeout=60)
    assert p.returncode == 0, p.stderr[-2000:]


def test_the_page_script_names_the_layers_and_a_place_to_add_at_every_level():
    text = script()
    # the built-in kinds and the two names of every level are the same words in the page and in the module
    for k in RH.BUILTIN_KINDS:
        assert ('id: "%s"' % k["id"]) in text and ('label: "%s"' % k["label"]) in text and ('errors_label: "%s"' % k["errors_label"]) in text
        assert ("levels: [%s]" % ", ".join('"%s"' % l for l in k["levels"])) in text
    for level, (plain, errs) in RH.LEVEL_WORDS.items():
        assert ('%s: ["%s", "%s"]' % (level, plain, errs)) in text
    tree, inner, form, page3, item = piece(text, "rhTree"), piece(text, "rbInner"), piece(text, "rhFormCard"), piece(text, "rulesPage"), piece(text, "rhItemForm")
    # (owner, 2026-11-15) one tree: page 3, the plan card and the library all draw it through rbInner -> rhTree
    assert "rhTree(id, st, H, can)" in inner and "rbInner(id)" in page3 and 'mode: "run"' in page3 and "rhRunRow(id, st, s, l, i, where)" in inner + tree
    assert "rb-side" not in inner and "rhP3Form" not in text and "rhGroupBlock" not in text          # the side list and page 3's own list are gone
    for label in ('"Add a section"', '"Add a kind of recording"', '"Add a level"', '"Add a group"', '"Add an item to this group"', "`Add an item to ${esc(l.label)}`", "it is shown under every section"):
        assert label in tree, label
    for title in ("Add a section", "Add a kind of recording", "Add a level to ${esc(kname)}", "Add a group to", "Edit the section", "Edit the kind of recording", "Edit the level", "Delete the ${noun}"):
        assert title in form, title
    assert "Add an item to the group" in item and "rhGroupQuestion(l," in item and "rhCrumb(" in item
    # every node is a real disclosure: a button with aria-expanded; no hover opens anything
    assert 'class="rh-tog" data-act="rh-node"' in tree and 'aria-expanded="${o}"' in tree and "mouseover" not in tree + inner and ":hover" not in tree
    assert 'act === "rh-node"' in piece(text, "rhAct") and 'act === "rh-use"' in piece(text, "rhAct")
    # kinds, levels and groups are added only when the hierarchy routes answer; an older server is not asked for them
    assert "can = !!st.hier" in inner and tree.count("can ?") + tree.count("!can") + tree.count("&& can") + tree.count("can &&") >= 5
    assert "rhNewServer(secs.sections) ?" in piece(text, "rbLoad") and "rhNewServer(tree) ?" in piece(text, "rhEnsure") and '.catch(() => null)' in piece(text, "rhEnsure")
    # nothing pre-selected, nothing pre-filled: no radio or box arrives ticked, an add form has no value
    for body in (form, tree, inner, item, piece(text, "rhGroupQuestion"), piece(text, "rhRunRow")):
        assert not re.search(r"\schecked[\s>]", re.sub(r"\$\{[^}]*\}", "", body)) and " selected" not in body
    assert 'const val = v => f.edit ? ` value="${esc(v || "")}"` : "";' in form
    assert "Error roots" not in tree + inner + form + page3 + item
    assert "rhFind(l, q)" in tree and "Find an item in this level" in tree


def run_node(tmp_path, scenario, data, real=()):
    """The page's own functions, run by node on a stand-in page. real: functions and constants the stand-in page replaces (the icons, the
    badge, the card of an item) that this run takes from the page script instead, with what they call."""
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    text = script()
    names = ["RB", "rbState", "rbKey", "RH_KINDS", "RH_LEVEL_WORDS", "RH_FIXED_KIND", "RH_FIXED_WORDS", "RH_STYLE", "RH_FIND_FROM", "RHP", "rhSecName", "rhNewServer", "rhBuild", "rhCrumb", "rhPlace",
             "rhFind", "rhCount", "rhAddGroup", "rhGroupQuestion", "rhOldWords", "RH_READ", "rhFacts", "RH_NONE", "rbAddItem",
             "rhEnsure", "rbTreeFromReview", "rbItemRow", "rbDelAsk", "rbInner", "rhFormCard", "rulesPage", "planSummary",
             # the one tree (2026-11-15): page 3, the plan card and the library
             "rhNodeOf", "rhMany", "rhKeysOf", "rhPathOf", "rhAutoOpen", "rhOpenTo", "rhAdminGroup", "rhTree", "rhItemForm", "rhTreeOfChosen", "rhRunCard",
             "RHI", "RH_IN_STATES", "rhNoRoute", "rhRunItems", "rhInRun", "rhRunRow", "rhUse", "rhAct", "rhSave",
             "rbSentence", "rbFileName", "rbFolderWords", "rbFileWords"] + list(real)
    stand_in = r"""
const DATA = JSON.parse(require("fs").readFileSync(process.argv[2], "utf8"));
const els = {};
const document = { getElementById: id => els[id] || null, querySelector: () => null };
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const IC = { chev: "", trash: "", plus: "", left: "" };
const DONE = ["done", "approved", "skipped"];
const S = { admin: "Sagar", project: 1, state: null };
const nf = n => String(n);
const when = () => "a day";
const asked = [], sent = [];
async function api(method, url, body) {
  const k = method + " " + url; asked.push(k); if (body) sent.push([k, body]); if (!(k in DATA.answers)) throw new Error("this address does not answer");
  const a = DATA.answers[k];
  if (a && a.__status) { const er = new Error(a.error); er.status = a.__status; er.data = a; throw er; }      // as the page's api() throws on an HTTP error
  return a;
}
let redrawn = 0;
function rbRedraw() { redrawn += 1; }
// every node of a tree opened, as a person who clicked each row would have it
function openAll(st) {
  for (const s of rhBuild(st.tree, st.hier)) { st.nopen[rhNodeOf.sec(s)] = true;
    for (const k of s.kinds) { st.nopen[rhNodeOf.kind(s, k)] = true;
      for (const l of k.levels) { st.nopen[rhNodeOf.lvl(s, l)] = true; l.groups.forEach(g => { st.nopen[rhNodeOf.grp(s, l, g)] = true; }); } } }
}
const toasts = [];
function toast(t) { toasts.push(t); }
function nav() {}
function openSettings() {}
function rbClearForm() {}
async function rbLoad() {}
let drawn = 0;
function render() { drawn += 1; }
function route() { return ["p", "1", "rules"]; }
function rbMeta() { return ""; }
function rbUi() { return {}; }
function rbDetail() { return "<p>the item's own card</p>"; }
function rbJob() { return ""; }
const fileHref = p => "/file?" + encodeURIComponent(p);
function stepRow(s) { return "<div>" + esc(s.title) + "</div>"; }
function track() { return ""; }
function errorLists() { return []; }
function errCounts() { return null; }
"""
    d = tmp_path / "page"
    os.makedirs(str(d), exist_ok=True)
    (d / "data.json").write_text(json.dumps(data), encoding="utf-8")
    for n in real:                                             # the stand-in's own line for it goes: the page's is used
        stand_in = re.sub(r"^(?:const|function) %s\b.*\n" % re.escape(n), "", stand_in, flags=re.M)
    names = list(dict.fromkeys(names))
    body = stand_in + "\n".join(piece(text, n) for n in names) + "\n(async () => {\n" + scenario + "\n})().catch(e => { console.log('FAILED ' + e.stack); });\n"
    (d / "run.cjs").write_text(body, encoding="utf-8")
    p = subprocess.run([NODE, str(d / "run.cjs"), str(d / "data.json")], capture_output=True, text=True, encoding="utf-8", timeout=60)
    line = next((ln for ln in p.stdout.splitlines() if ln.startswith("RESULT ")), None)
    assert line, (p.stdout[-2500:], p.stderr[-2500:])
    return json.loads(line[7:])


def labels_with_reasons(html):
    """Every field label of a drawn form, with the reason directly under it (None when the next element is something else)."""
    out = []
    for m in re.finditer(r'<label class="f">(.*?)</label>\s*(<div class="why">(.*?)</div>)?', html, re.S):
        out.append((words(m.group(1)).strip(), words(m.group(3)).strip() if m.group(2) else None))
    return out


KEY_ON_SCREEN = re.compile(r"\b[a-z0-9_]+/[a-z0-9_]+/[a-z0-9_.]+\b")


NODE_ROW = re.compile(r'<button type="button" class="rh-tog" data-act="rh-node" data-rb="[^"]*" data-node="([^"]*)" aria-expanded="(true|false)"[^>]*>\s*'
                      r'<span class="rh-chev"[^>]*>.*?</span><span class="rh-txt"><span class="rh-name">(.*?)</span>(?:<span class="rh-about">(.*?)</span>)?</span>'
                      r'<span class="rh-cnt">(.*?)</span></button>', re.S)


def tree_rows(html):
    """The rows of the tree as drawn, in order: the node, open or closed, its name, its line under the name, its counts."""
    import html as H
    return [{"node": H.unescape(m.group(1)), "open": m.group(2) == "true", "name": words(m.group(3)).strip(), "about": words(m.group(4) or "").strip(),
             "count": words(m.group(5)).strip()} for m in NODE_ROW.finditer(html)]


def in_order(text, labels):
    at = -1
    for label in labels:
        nxt = text.find(label, at + 1)
        assert nxt > at, (label, text[max(0, at - 100):at + 600])
        at = nxt


def screen_rules(html):
    """What every drawn screen must hold to: no raw key, a reason of more than 40 characters under every field, nothing chosen or filled in."""
    assert not KEY_ON_SCREEN.search(words(html)), KEY_ON_SCREEN.search(words(html)).group(0)
    assert all(why and len(why) > 40 for _l, why in labels_with_reasons(html)), labels_with_reasons(html)
    assert len(re.findall(r'<label class="f">', html)) == len(re.findall(r'<label class="f">.*?</label>\s*<div class="why">', html, re.S))
    assert not re.search(r"<input(?![^>]*data-plan=)[^>]*\schecked", html)          # the plan card's ticks are the plan's choice, kept as they are
    assert not re.search(r'<input type="text"[^>]*\svalue="[^"]', re.sub(r'<input type="text" class="rb-q"[^>]*>', "", html))


def test_the_library_tree_from_an_older_servers_answers(world, tmp_path):
    """The running (older) server gives sections, levels and items only, and names the section "Error roots": the tree applies the built-in
    kinds itself, shows "Errors", starts closed, and offers no form for kinds, levels and groups (and asks for none)."""
    tree = world.c.get("/api/agents/rules").get_json()
    for s in tree:                                          # as the older server answers
        if s["section"] == "errors":
            s["name"], s["label"] = "Error roots", "Section 2 · Error roots"
    secs = world.c.get("/api/agents/rules/sections").get_json()
    for s in secs["sections"]:
        if s["id"] == "errors":
            s["label"], s["title"] = "Error roots", "Section 2 · Error roots"
    out = run_node(tmp_path, r"""
      const st = rbState("lib"); st.mode = "lib"; st.tree = DATA.tree; st.hier = null;
      const closed = rbInner("lib");
      openAll(st); const all = rbInner("lib");
      st.nopen = {}; st.open = "errors/nvme_command/cmd_timeout";
      const item = rbInner("lib");
      st.open = null; st.form = { what: "section", edit: false, del: false, sec: null, kind: null, lvl: null, defects: null, key: "k" };
      const form = rbInner("lib");
      console.log("RESULT " + JSON.stringify({ closed, all, item, form, newServer: [rhNewServer(DATA.tree), rhNewServer(DATA.secs.sections)] }));
    """, {"tree": tree, "secs": secs, "answers": {}})
    keep_for_the_browser("library_older.html", out["all"])
    assert out["newServer"] == [False, False]
    n = {s["section"]: sum(len(l["items"]) for l in s["levels"]) for s in tree}
    rows = tree_rows(out["closed"])
    assert [(r["name"], r["open"], r["about"], r["count"]) for r in rows] == [
        ("Data analytics", False, "results only", "2 kinds of recording, %d items" % n["analytics"]),
        ("Errors", False, "every error an item finds goes on to stage 1 and stage 2", "2 kinds of recording, %d items" % n["errors"])]
    assert out["closed"].count('class="rb-item ') == 0 and "Add a section" in words(out["closed"])         # nothing opens by itself in the library
    order = ["Data analytics", "NVMe and PCIe recording (Teledyne LeCroy five-file export)", "NVMe command level", "NVMe transaction level", "Split transaction level", "Link transaction level",
             "PCIe packet level", "Other CSV files (any tool)", "Other CSV files", "Errors", "NVMe errors", "NVMe command level errors", "NVMe transaction level errors",
             "Split transaction level errors", "Link transaction level errors", "PCIe packet level errors", "Errors in other CSV files (any tool)", "Errors in other CSV files", "Add a section"]
    in_order(" ".join(r["name"] for r in tree_rows(out["all"])) + " Add a section", order)
    assert "Error roots" not in out["all"] and "Add a kind of recording" not in out["all"] and "Add a level" not in out["all"] and "Add a group" not in out["all"]
    assert len(tree_rows(out["all"])) == 2 + 2 * (2 + 6) and all(r["open"] for r in tree_rows(out["all"]))
    assert "Add an item to NVMe command level" in words(out["all"]) and "Add an item to NVMe command level errors" in words(out["all"])
    assert out["all"].count('class="rb-item ') == n["analytics"] + n["errors"]          # every item of every level
    # an item opened from a link: only the way to it opens, and its card names its place
    opened = [r["node"] for r in tree_rows(out["item"]) if r["open"]]
    assert opened == ["s:errors", "k:errors/lecroy_nvme_pcie", "l:errors/nvme_command"], opened
    assert "Errors › NVMe errors › NVMe command level errors › NVMe command timeout" in words(out["item"])
    for html in (out["closed"], out["all"], out["item"], out["form"]):
        screen_rules(html)
    assert [l for l, _w in labels_with_reasons(out["form"])][:3] == ["Name", "What it is for", "What happens to its items"]
    assert "It appears at the end of the list of sections, on page 3 and in the Rules library" in words(out["form"]) and out["form"].count('type="radio"') == 2
    # the form of a new section sits where the section will appear: after the last section
    assert words(out["form"]).index("Errors") < words(out["form"]).index("A section is the top layer")


def test_the_tree_draws_an_admins_section_kind_and_level_with_their_add_rows_and_forms(world, tmp_path):
    c = world.c
    kind = world.add_kind("Bench logs")
    level = world.add_level(kind["id"], "Bench rows", "bench_*.csv")
    key = c.post("/api/agents/rule-hierarchy/items", json={"section": "analytics", "level": level["id"], "name": "Share of each command", "description": "percentage by Command",
                                                           "admin": "Sagar"}).get_json()["key"]
    sid = c.post("/api/agents/rules/sections", json={"label": "Timing checks", "about": "how long things take", "defects": True, "admin": "Sagar"}).get_json()["section"]["id"]
    tree, hier = c.get("/api/agents/rules").get_json(), world.hier()
    out = run_node(tmp_path, r"""
      const st = rbState(7); st.mode = "plan"; st.tree = DATA.tree; st.hier = DATA.hier; st.ticks = {}; st.ticks[DATA.key] = true;
      const first = rbInner(7);
      st.open = DATA.key; const open = rbInner(7); st.open = null;
      openAll(st); const all = rbInner(7);
      const forms = {}, places = {};
      for (const [name, f] of Object.entries({
        section: { what: "section" }, kind: { what: "kind", sec: "analytics" }, level: { what: "level", sec: "analytics", kind: DATA.kind },
        editSection: { what: "section", edit: true, sec: DATA.sid }, editKind: { what: "kind", edit: true, sec: "errors", kind: DATA.kind },
        editLevel: { what: "level", edit: true, sec: "analytics", kind: DATA.kind, lvl: DATA.level },
        delLevel: { what: "level", del: true, sec: "analytics", kind: DATA.kind, lvl: DATA.level }, delKind: { what: "kind", del: true, sec: "analytics", kind: DATA.kind },
        delSection: { what: "section", del: true, sec: DATA.sid } })) {
        st.form = Object.assign({ edit: false, del: false, sec: null, kind: null, lvl: null, gname: null, defects: null, key: name }, f);
        forms[name] = rhFormCard(7, st, rhBuild(st.tree, st.hier));
        places[name] = rbInner(7);                         // the whole tree with the form at its place
      }
      console.log("RESULT " + JSON.stringify({ first, open, all, forms, places, newServer: rhNewServer(DATA.tree) }));
    """, {"tree": tree, "hier": hier, "key": key, "kind": kind["id"], "level": level["id"], "sid": sid, "answers": {}})
    assert out["newServer"] is True
    # the way to the ticked item opens by itself, and nothing else
    rows = tree_rows(out["first"])
    assert [r["node"] for r in rows if r["open"]] == ["s:analytics", "k:analytics/%s" % kind["id"], "l:analytics/%s" % level["id"]]
    got = {r["name"]: r for r in rows}
    assert got["Bench logs"]["count"] == "1 level, 1 item, 1 chosen" and got["Bench rows"]["count"] == "1 item, 1 chosen" and got["Bench rows"]["about"] == "reads bench_*.csv · one command the bench sent"
    assert got["Timing checks"]["count"] == "3 kinds of recording, 0 items" and not got["Timing checks"]["open"]
    assert "Share of each command" in words(out["first"]) and "Add an item to Bench rows" in words(out["first"])
    assert "Data analytics › Bench logs › Bench rows › Share of each command" in words(out["open"])
    # every level has its place to add: a section at the end, a kind in each section, a level in each kind (never in the five-file kind), a group in each analyzer level
    a = words(out["all"])
    assert a.count("Add a section") == 1 and a.count("Add a kind of recording") == 3 and a.count("it is shown under every section") == 3
    assert a.count("Add a level") == 6 and a.count(RH.BUILTIN_KINDS[0]["label"]) == 1 and a.count("The five levels of this kind are the five files the analyzer exports") == 3
    assert a.count("Add a group") == 3 * 5 and a.count("Add an item to ") == 3 * 7 + 3 and a.count("Add an item to this group") == 3
    assert a.count("built in") == 2 + 2 * 3 + 6 * 3 + 3        # the 2 built-in sections; in each of the 3 sections the 2 built-in kinds and their 6 levels; the 3 stated groups
    tools = re.findall(r'<span class="rh-tools">(.*?)</span></div>', out["all"], re.S)
    assert sum("Edit" in t and "Delete" in t for t in tools) == 1 + 3 + 3          # the admin's section, kind (in 3 sections), level (in 3 sections)
    f, p = out["forms"], out["places"]
    assert [l for l, _w in labels_with_reasons(f["kind"])] == ["Name", "Which files it covers"]
    assert [l for l, _w in labels_with_reasons(f["level"])] == ["Name", "The file it reads", "What one row of it is"]
    for name in ("section", "kind", "level", "editSection", "editKind", "editLevel"):
        got = labels_with_reasons(f[name])
        assert got and all(why and len(why) > 40 for _l, why in got), (name, got)
        assert not re.search(r"<input[^>]*\schecked", f[name]), name
        if not name.startswith("edit"):
            assert ' value="' not in re.sub(r'type="radio"[^>]*', "", f[name]), name            # an add form arrives empty
        assert p[name].count('class="rb-panel') == 1 or p[name].count("rh-form") == 1, name          # drawn once, at its place
    # each form sits where the new thing appears: the kind inside its section after the kinds, the level inside its kind after the levels
    pk = words(p["kind"])
    assert pk.index("Other CSV files (any tool)") < pk.index("A kind of recording is one tool's set of files") < pk.index("Errors")
    pl = words(p["level"])
    assert pl.index("Bench rows") < pl.index("A level is one file of a kind of recording") < pl.index("Errors")
    assert words(p["editSection"]).index("Timing checks") < words(p["editSection"]).index("Edit the section")
    assert "A kind of recording is one tool's set of files" in words(f["kind"]) and "It appears as a heading under every section" in words(f["kind"])
    assert "A level is one file of a kind of recording" in words(f["level"]) and "It appears under “Bench logs” in every section" in words(f["level"])
    assert "every section › Bench logs › your new level" in words(f["level"])
    assert 'value="Bench logs"' in f["editKind"] and 'value="bench_*.csv"' in f["editLevel"] and 'value="Timing checks"' in f["editSection"]
    assert "is not changed here" in words(f["editSection"]) and 'type="radio"' not in f["editSection"]
    assert "still holds 1 item" in words(f["delLevel"]) and "Delete it" not in words(f["delLevel"])
    assert "still holds 1 level" in words(f["delKind"]) and "Delete it" not in words(f["delKind"])
    assert "It holds nothing" in words(f["delSection"]) and "Delete it" in words(f["delSection"])
    for html in [out["first"], out["open"], out["all"]] + list(f.values()):
        assert not KEY_ON_SCREEN.search(words(html).replace("bench_*.csv", "")), KEY_ON_SCREEN.search(words(html)).group(0)
        assert level["id"] not in words(html) and kind["id"] not in words(html).replace("Bench logs", "")


# ------------------------------------------------------------------------------------------------ 5b. page 3 of an analysis, as the owner has it
def owner_run(world):
    """Page 3 of an analysis like the owner's: two items of Data analytics and two of Errors in it, the plan approved."""
    c = world.c
    tree, hier = c.get("/api/agents/rules").get_json(), world.hier()
    mine = {"analytics/nvme_command/command_type_share": ("Command type percentages", {"run": {"rows": 10}, "test": {"checks": 4, "passed": True}}, "done"),
            "analytics/nvme_command/read_pattern": ("Read vs RndRead vs sequential read", {"run": {"rows": 3}, "test": {"checks": 4, "passed": False}}, "done"),
            "errors/nvme_command/cmd_timeout": ("NVMe command timeout", {"run": {"rows": 7}}, "needs_review"),
            "errors/nvme_command/cmd_read_failure": ("Read failed (the most common NVMe failure)", {}, "waiting")}
    ss = [{"key": "f3_plan", "title": "the rules to use on this data", "state": "approved"}]
    for k, (name, outs, last) in mine.items():
        ss += [{"key": "f3:%s:%s" % (k, step), "title": "%s · %s" % (name, step), "state": "done" if step != "result" else last, "output": outs.get(step, {})} for step in ("write", "run", "test", "result")]
    every = [(s["section"], l["level"], i["id"]) for s in tree for l in s["levels"] for i in l["items"]]
    # the sentences pipeline.items_of_analysis gives; the last item of the analytics command level cannot be used in this analysis
    blocked = [k for k in ("%s/%s/%s" % e for e in every) if k.startswith("analytics/nvme_command/") and k not in mine][-1]
    words = lambda k: ("It is in this analysis: its steps are on page 3." if k in mine else BLOCKED_WORDS if k == blocked else OUT_WORDS)      # noqa: E731
    items = {"items": [{"section": a, "level": b, "id": i, "state": "in the analysis" if "%s/%s/%s" % (a, b, i) in mine else "not in the analysis", "words": words("%s/%s/%s" % (a, b, i))}
                       for a, b, i in every], "can_add": True, "why_not": ""}
    return tree, hier, mine, ss, items


OUT_WORDS = "It is not in this analysis: “Use it in this analysis” adds it."
BLOCKED_WORDS = "It is not in this analysis, and it cannot be used here: it reads the tree, and this analysis has none."


PAGE3_SCENARIO = r"""
  const x = { ss: DATA.ss }, v = { run: { id: 7, project: 1 } };
  const before = rulesPage(x, v);                       // the library has not answered yet: the items of the analysis under the built-in names
  await new Promise(r => setTimeout(r, 30));
  const after = rulesPage(x, v);
  const st = rbState("run7");
  st.nopen["k:errors/other_csv"] = true; const oneDown = rulesPage(x, v); delete st.nopen["k:errors/other_csv"];
  st.nopen["g:errors/nvme_command/" + DATA.groups[0]] = true; const groupOpen = rulesPage(x, v);
  openAll(st); const everything = rulesPage(x, v);
  st.nopen = {};
  // the admin closes the open section Errors, then opens it again
  await rhAct("rh-node", { dataset: { rb: "run7", node: "s:errors" }, getAttribute: () => "true" }); const closedErrors = rulesPage(x, v);
  await rhAct("rh-node", { dataset: { rb: "run7", node: "s:errors" }, getAttribute: () => "false" }); const reopened = rulesPage(x, v);
  // "Use it in this analysis"
  st.nopen["g:errors/nvme_command/" + DATA.groups[1]] = true;          // the admin opened the group of the item
  const b = { dataset: { rb: "run7", key: DATA.use }, disabled: false, textContent: "" };
  sent.length = 0; const drawnBefore = drawn;
  await rhAct("rh-use", b);
  const used = { sent: sent.slice(), page: rulesPage(x, v), drawn: drawn - drawnBefore, asked: asked.filter(a => a.includes("/runs/7/items")).length };
  // an add form opened at a level of page 3: at its place, nothing chosen
  await rhAct("rh-form", { dataset: { rb: "run7", what: "item", sec: "errors", kind: "lecroy_nvme_pcie", lvl: "nvme_command", level: "nvme_command", alvl: "", gname: "" } });
  const addForm = rulesPage(x, v);
  await rhAct("rh-cancel", { dataset: { rb: "run7" } });
  // the plan card is open again (the analysis reopened at page 3): the items are chosen there, so no button here
  const x8 = { ss: DATA.ss.map(s => s.key === "f3_plan" ? Object.assign({}, s, { state: "needs_review" }) : s) }, v8 = { run: { id: 8, project: 1 } };
  rulesPage(x8, v8); await new Promise(r => setTimeout(r, 30));
  const planOpen = rulesPage(x8, v8);
  console.log("RESULT " + JSON.stringify({ before, after, oneDown, groupOpen, everything, closedErrors, reopened, used, addForm, planOpen, said: (rbState("run7").said || {})[DATA.use] || null }));
"""


def test_page_three_is_one_tree_with_every_item_and_its_state_in_the_analysis(world, tmp_path):
    from nvme_hier import command_error_rules as CE
    tree, hier, mine, ss, items = owner_run(world)
    lvl = command_level(hier)
    groups = [g["name"] for g in lvl["groups"]]
    use = lvl["groups"][1]["items"][0]["key"]                         # an item of the second group, not in the analysis
    how = "Added to this analysis: the flow writes its rule, codes it and runs it on this recording; its result appears at its row."
    answers = {"GET /api/agents/rules": tree, "GET /api/agents/rule-hierarchy": hier, "GET /api/agents/runs/7/items": items, "GET /api/agents/runs/8/items": items,
               "POST /api/agents/runs/7/items": {"how": how}}
    out = run_node(tmp_path, PAGE3_SCENARIO, {"ss": ss, "answers": answers, "groups": groups, "use": use})
    for name in ("after", "everything", "groupOpen", "addForm", "planOpen"):
        keep_for_the_browser("page3_%s.html" % name, out[name])
    keep_for_the_browser("page3_data.json", {"ss": ss, "answers": answers})
    n_ana = sum(len(l["items"]) for s in tree if s["section"] == "analytics" for l in s["levels"])
    n_err = sum(len(l["items"]) for s in tree if s["section"] == "errors" for l in s["levels"])
    ana_cmd = [i for s in tree if s["section"] == "analytics" for l in s["levels"] if l["level"] == "nvme_command" for i in l["items"]]
    # ---- the tree, closed but for the way to the four items of the analysis
    rows = tree_rows(out["after"])
    lecroy, other = RH.BUILTIN_KINDS[0]["label"], RH.BUILTIN_KINDS[1]["label"]
    assert [(r["name"], r["open"]) for r in rows] == (
        [("Data analytics", True), (lecroy, True), ("NVMe command level", True), ("NVMe transaction level", False), ("Split transaction level", False),
         ("Link transaction level", False), ("PCIe packet level", False), (other, False),
         ("Errors", True), ("NVMe errors", True), ("NVMe command level errors", True)] + [(g, False) for g in groups] +
        [("NVMe transaction level errors", False), ("Split transaction level errors", False), ("Link transaction level errors", False), ("PCIe packet level errors", False),
         ("Errors in other CSV files (any tool)", False)])
    count = {r["name"]: r["count"] for r in rows}
    assert count["Data analytics"] == "2 kinds of recording, %d items, 2 in this analysis" % n_ana
    assert count["Errors"] == "2 kinds of recording, %d items, 2 in this analysis" % n_err
    assert count["NVMe command level"] == "%d items, 2 in this analysis" % len(ana_cmd)
    assert count["NVMe command level errors"] == "3 groups, %d items, 2 in this analysis" % lvl["count"] == "3 groups, 40 items, 2 in this analysis"
    assert [count[g] for g in groups] == ["%d items" % len(g["items"]) for g in lvl["groups"]] == ["24 items", "8 items", "6 items"]
    assert count["NVMe transaction level"] == "0 items" and count[other] == "1 level, 0 items"
    # ---- what each item says: the four of the analysis as page 3 showed them; every other item of the open levels, with its button
    a = words(out["after"])
    in_order(a, ["Data analytics", "results only", lecroy, "NVMe command level", "Command type percentages", "in the analysis · 10 rows · tester: all checks passed", "done",
                 "Read vs RndRead vs sequential read", "in the analysis · 3 rows · tester: NOT all checks passed", "Add a group", "Add an item to NVMe command level",
                 "Errors", "every error an item finds goes on to stage 1 and stage 2", "NVMe errors", "NVMe command level errors", "Find an item in this level",
                 "Listed directly under this level, in no group", "NVMe command timeout", "in the analysis · 7 rows", "needs your decision",
                 "Read failed (the most common NVMe failure)", "waiting", groups[0], groups[1], groups[2], "Add a group", "Add an item to NVMe command level errors", "Add a section"])
    assert out["after"].count('class="group"') == 4 and out["after"].count('class="rh-irow') == len(ana_cmd) + 2
    assert out["after"].count('data-act="rh-use"') == len(ana_cmd) - 3 and a.count(OUT_WORDS) == len(ana_cmd) - 3 and a.count(BLOCKED_WORDS) == 1      # the server's sentence, no button where it cannot run
    assert a.count("Add a kind of recording") == 2 and a.count("The five levels of this kind are the five files the analyzer exports") == 2 and "Add a level" not in a
    # ---- before the library answered: the four items under the built-in names, nothing lost
    b4 = tree_rows(out["before"])
    assert [r["name"] for r in b4 if r["open"]] == ["Data analytics", lecroy, "NVMe command level", "Errors", "NVMe errors", "NVMe command level errors"]
    assert out["before"].count('class="group"') == 4 and "Use it in this analysis" not in out["before"]
    # ---- opening one node shows only the next level down, closed
    new = [r for r in tree_rows(out["oneDown"]) if r["node"] not in {x["node"] for x in rows}]
    assert [(r["name"], r["open"], r["count"]) for r in new] == [("Errors in other CSV files", False, "0 items")]
    assert out["oneDown"].count('class="rh-irow') == out["after"].count('class="rh-irow')
    g0 = tree_rows(out["groupOpen"])
    assert next(r for r in g0 if r["name"] == groups[0])["open"] and len(g0) == len(rows)
    assert out["groupOpen"].count('class="rh-irow') == len(ana_cmd) + 2 + 24 and words(out["groupOpen"]).count("Add an item to this group") == 1
    assert lvl["groups"][0]["more"] in words(out["groupOpen"]) and lvl["groups"][0]["more"] not in a
    # ---- every node opened: all 40 items of NVMe command level errors, each with its state; every item of the library is listed
    e = out["everything"]
    err_block = e.split('data-node="l:errors/nvme_command"')[1].split('data-node="l:errors/nvme_transaction"')[0]
    assert err_block.count('class="rh-irow') == 40 and err_block.count('data-act="rh-use"') == 38 and err_block.count('class="group"') == 2
    for it in RH.items_of(lvl):
        assert it["name"] in words(err_block), it["name"]
    assert e.count('class="rh-irow') == n_ana + n_err and e.count('data-act="rh-use"') == n_ana + n_err - 5
    assert words(e).count("Add an item to this group") == 3 and words(e).count("Add a level") == 2 * 1
    # ---- closing a node closes everything under it; opening it again shows the next level, as it was
    ce = tree_rows(out["closedErrors"])
    assert [r["name"] for r in ce if r["name"] in ("Errors", "NVMe errors")] == ["Errors"] and not next(r for r in ce if r["name"] == "Errors")["open"]
    assert "NVMe command timeout" not in words(out["closedErrors"]) and tree_rows(out["reopened"]) == rows
    # ---- "Use it in this analysis": the body the route needs, the server's sentence at the row, then the page drawn again
    sec, lv, rid = use.split("/")
    assert out["used"]["sent"] == [["POST /api/agents/runs/7/items", {"section": sec, "level": lv, "id": rid, "admin": "Sagar"}]]
    assert out["said"] == {"ok": True, "text": how} and out["used"]["drawn"] == 1 and out["used"]["asked"] >= 2
    shown = words(out["used"]["page"])
    assert how in shown and shown.index(lvl["groups"][1]["items"][0]["name"]) < shown.index(how) < shown.index(lvl["groups"][1]["items"][1]["name"])      # at that item's row
    # ---- the add form of page 3: at its level, after the groups, nothing chosen
    f = out["addForm"]
    assert words(f).index(groups[2]) < words(f).index("Add an item to NVMe command level errors") < words(f).index("Errors › NVMe errors › NVMe command level errors › your new item")
    assert [l for l, _w in labels_with_reasons(f.split('data-form="item"')[1])] == ["Group", "Name", "In your words"]
    assert "“Use it in this analysis” at its row then adds it to this analysis" in words(f)
    # ---- the plan card open again: the items are chosen there
    pw = words(out["planOpen"])
    assert "Use it in this analysis" not in out["planOpen"] and "The plan card above is open: the items are chosen there, with its ticks." in pw
    assert pw.count("not in the analysis: the plan card above chooses the items") == len(ana_cmd) - 2
    for html in (out["before"], out["after"], out["oneDown"], out["groupOpen"], out["everything"], out["used"]["page"], out["addForm"], out["planOpen"]):
        screen_rules(html)
        assert "Section 1" not in html and "Section 2" not in html and "Error roots" not in html


def test_page_three_on_a_server_without_the_new_routes(world, tmp_path):
    """The server running now has no route for what an analysis holds: the tree still draws, the items not in the analysis say they can be
    added after a restart, and no button is offered. A button pressed on a page drawn before (or a group added) gets the same sentence."""
    tree, hier, mine, ss, _items = owner_run(world)
    missing = {"__status": 404, "error": "The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again."}
    answers = {"GET /api/agents/rules": tree, "GET /api/agents/rule-hierarchy": hier, "GET /api/agents/runs/7/items": missing, "POST /api/agents/runs/7/items": missing,
               "POST /api/agents/rule-hierarchy/levels/nvme_command/groups": missing}
    use = next("analytics/nvme_command/" + i["id"] for s in tree if s["section"] == "analytics" for l in s["levels"] if l["level"] == "nvme_command" for i in l["items"]
               if "analytics/nvme_command/" + i["id"] not in mine)
    out = run_node(tmp_path, r"""
      const x = { ss: DATA.ss }, v = { run: { id: 7, project: 1 } };
      rulesPage(x, v); await new Promise(r => setTimeout(r, 30));
      const page = rulesPage(x, v);
      const b = { dataset: { rb: "run7", key: DATA.use }, disabled: false, textContent: "" };
      await rhAct("rh-use", b);
      const after = rulesPage(x, v);
      await rhAct("rh-form", { dataset: { rb: "run7", what: "group", sec: "errors", kind: "lecroy_nvme_pcie", lvl: "nvme_command" } });
      Object.assign(els, { agnrun7: { value: "Timing of the queues" }, agarun7: { value: "" }, rhmrun7: { innerHTML: "" } });
      await rhSave("run7", false);
      console.log("RESULT " + JSON.stringify({ page, after, said: rbState("run7").said[DATA.use], group: els.rhmrun7.innerHTML, form: rbState("run7").form, ri: RHI[7] }));
    """, {"ss": ss, "answers": answers, "use": use})
    keep_for_the_browser("page3_no_route.html", out["page"])
    ana_cmd = [i for s in tree if s["section"] == "analytics" for l in s["levels"] if l["level"] == "nvme_command" for i in l["items"]]
    p = words(out["page"])
    assert out["ri"]["missing"] is True and 'data-act="rh-use"' not in out["page"]
    assert p.count("not in the analysis · can be added after the application is restarted") == len(ana_cmd) - 2
    assert out["page"].count('class="group"') == 4 and len(tree_rows(out["page"])) == 2 + 2 * 7 + 3
    assert out["said"]["ok"] is False and "can be added after the application is restarted" in out["said"]["text"] and out["said"]["text"] in words(out["after"])
    assert "a group can be added after the application is restarted" in words(out["group"]) and out["form"] is not None          # the form stays open, with the sentence
    screen_rules(out["page"])


# ------------------------------------------------------------------------------------------------ 6. groups of items inside a level, in the tree
def command_level(h, section="errors"):
    sec = next(s for s in h["sections"] if s["section"] == section)
    return levels_of(sec, "lecroy_nvme_pcie")[0]


def test_the_seeded_rule_families_are_listed_in_their_groups_in_the_seeding_modules_order(lib):
    """The real seed() in a throw-away library: the rule families under Errors > NVMe errors > NVMe command level errors."""
    from nvme_hier import command_error_rules as CE
    seeded = CE.items()
    assert seeded and {(i["section"], i["level"]) for i in seeded} == set(RH.GROUP_SOURCES) == {("errors", "nvme_command")}      # the place the table names is the place the module seeds
    h = RH.hierarchy()
    lvl = command_level(h)
    assert lvl["label"] == "NVMe command level errors"
    # the groups: the module's names, in the module's order, each with the module's own text and nothing else
    assert [g["name"] for g in lvl["groups"]] == [n for n, _a in CE.GROUPS] and all(g["stated"] for g in lvl["groups"])
    for g, (_n, text) in zip(lvl["groups"], CE.GROUPS):
        assert g["about"] and text.startswith(g["about"]) and (g["about"] + " " + g["more"]).strip() == " ".join(text.split())
        assert g["about"].count(". ") == 0 and g["about"].endswith(".")                    # one sentence
    # the items of a group are the module's items of that group, in the order the level's list has them
    listed = [i["id"] for s in family3.tree() if s["section"] == "errors" for l in s["levels"] if l["level"] == "nvme_command" for i in l["items"]]
    for g in lvl["groups"]:
        want = {i["id"] for i in seeded if i["group"] == g["name"]}
        assert want and [i["id"] for i in g["items"]] == [x for x in listed if x in want]
        for it in g["items"]:
            assert it["in_group"] == g["name"] and it["group"] is None and it["key"] == "errors/nvme_command/" + it["id"]
            assert it["place"] == ["Errors", "NVMe errors", "NVMe command level errors", g["name"], it["name"]]
            assert it["about"] == next(i["description"] for i in seeded if i["id"] == it["id"]) and it["default"] is False       # never chosen in advance
    # the two items chosen by default are in no group: directly under the level
    assert sorted(i["id"] for i in lvl["items"]) == ["cmd_read_failure", "cmd_timeout"] and all(i["default"] and i["in_group"] is None for i in lvl["items"])
    assert lvl["count"] == 2 + len(seeded) == len(RH.items_of(lvl)) == len(listed)
    assert [i["id"] for i in RH.items_of(lvl)] == [i["id"] for i in lvl["items"]] + [i["id"] for g in lvl["groups"] for i in g["items"]]
    assert next(l for k in h["kinds"] for l in k["levels"] if l["id"] == "nvme_command")["holds"] >= lvl["count"]
    # the place of an item names its group; one in no group has four parts as before
    one = lvl["groups"][0]["items"][0]
    assert RH.place_of("errors", "nvme_command", one["id"]) == ["Errors", "NVMe errors", "NVMe command level errors", CE.GROUPS[0][0], one["name"]]
    assert RH.place_of("errors", "nvme_command", "cmd_timeout") == ["Errors", "NVMe errors", "NVMe command level errors", "NVMe command timeout"]
    # no other level has groups; the same level under Data analytics has none (no module states any for it)
    for s in h["sections"]:
        for k in s["kinds"]:
            for l in k["levels"]:
                assert (l["groups"] != []) == ((s["section"], l["level"]) == ("errors", "nvme_command")), (s["section"], l["id"])
                assert l["count"] == len(l["items"]) + sum(len(g["items"]) for g in l["groups"])
    assert json.dumps(RH.hierarchy(), sort_keys=True) == json.dumps(h, sort_keys=True)                # the same order every time
    assert RH.groups_of_level("errors", "nvme_command") == [n for n, _a in CE.GROUPS] and RH.groups_of_level("analytics", "nvme_command") == []
    assert RH.groups_of_level("errors", "other") == [] and RH.groups_of_level("no_such", "nvme_command") == []


def test_a_group_no_module_states_is_shown_by_its_name_alone_after_the_stated_ones(lib, monkeypatch):
    for name, grp in (("Zebra check", "Later group"), ("Alpha check", "an earlier group"), ("Beta check", "Later  group")):
        r = family3.add_item("errors", "nvme_transaction", name, "", "Sagar")
        r["group"] = grp
        family3.save_rule(r)
    lvl = levels_of(RH.hierarchy()["sections"][1], "lecroy_nvme_pcie")[1]
    assert [(g["name"], g["about"], g["more"], g["stated"], [i["name"] for i in g["items"]]) for g in lvl["groups"]] == [
        ("an earlier group", "", "", False, ["Alpha check"]), ("Later group", "", "", False, ["Beta check", "Zebra check"])]      # by name; spaces in a name do not make two groups
    assert lvl["items"] == [] and RH.groups_of_level("errors", "nvme_transaction") == ["an earlier group", "Later group"]
    # a module that cannot be read: the groups of its level are still shown, by their names alone
    monkeypatch.setitem(RH.GROUP_SOURCES, ("errors", "nvme_command"), ("nvme_hier.no_such_module", "GROUPS"))
    cmd = command_level(RH.hierarchy())
    assert len(cmd["groups"]) == 3 and all(g["about"] == "" and not g["stated"] for g in cmd["groups"]) and cmd["count"] == len(RH.items_of(cmd))
    assert [g["name"] for g in cmd["groups"]] == sorted(g["name"] for g in cmd["groups"])


def test_a_group_inside_a_level_is_never_taken_for_a_level_the_admin_added(world):
    """The stored field "group" has two uses, told apart by the item's stored level alone: at "other" it is the id of a level
    the admin added, at one of the analyzer's five levels it is the name of a group inside that level."""
    from nvme_hier import command_error_rules as CE
    c, status = world.c, CE.GROUPS[0][0]
    kind = world.add_kind("Bench logs")
    level = world.add_level(kind["id"], "Bench rows", "bench_*.csv")
    twin = world.add_level(kind["id"], status, "status_*.csv")                 # an admin's level with the very name of a seeded group
    assert twin["id"].startswith("g_") and twin["id"] != status
    # 1. an item of an analyzer level whose stored field is, letter for letter, the id of the admin's level: it stays in its own level
    r = family3.add_item("errors", "nvme_command", "Crafted item", "", "Sagar")
    r["group"] = level["id"]
    family3.save_rule(r)
    assert RH.group_of(r) is None and RH.item_group_of(r) == level["id"]
    files = [{"file": "bench_log.csv"}, {"file": "a.csv"}]
    assert RH.files_of_level(r, files) == files                                 # its rule is not written on the admin's level's file
    # 2. an "other" item whose stored field is the name of a group: it is in no group, and in no admin's level
    o = family3.add_item("errors", "other", "Other crafted", "", "Sagar")
    o["group"] = status
    family3.save_rule(o)
    assert RH.item_group_of(o) is None and RH.group_of(o) is None
    # 3. an item of the admin's level, added through the route
    mine = c.post("/api/agents/rule-hierarchy/items", json={"section": "errors", "level": level["id"], "name": "Bench timeout", "admin": "Sagar"}).get_json()["rule"]
    assert RH.group_of(mine) == level["id"] and RH.item_group_of(mine) is None
    h = world.hier()
    err = h["sections"][1]
    bench, twin_lvl = levels_of(err, kind["id"])
    assert [i["key"] for i in bench["items"]] == ["errors/other/bench_timeout"] and bench["groups"] == [] and bench["items"][0]["in_group"] is None
    assert bench["items"][0]["place"] == ["Errors", "Bench logs", "Bench rows", "Bench timeout"]
    assert twin_lvl["items"] == [] and twin_lvl["groups"] == [] and twin_lvl["count"] == 0          # the seeded items of the group "Status ..." did not move to the level of that name
    cmd = command_level(h)
    by_name = {g["name"]: g for g in cmd["groups"]}
    assert len(by_name[status]["items"]) == sum(1 for i in CE.items() if i["group"] == status)
    assert [i["name"] for i in by_name[level["id"]]["items"]] == ["Crafted item"] and by_name[level["id"]]["stated"] is False      # listed inside its own level
    plain = levels_of(err, "other_csv")[0]
    assert [i["name"] for i in plain["items"]] == ["Other crafted"] and plain["groups"] == [] and plain["items"][0]["in_group"] is None
    holds = {l["id"]: l["holds"] for k in h["kinds"] for l in k["levels"]}
    assert holds[level["id"]] == 1 and holds[twin["id"]] == 0
    assert c.delete("/api/agents/rule-hierarchy/levels/%s" % twin["id"], json={"admin": "Sagar"}).status_code == 200       # it holds nothing
    refused(c.delete("/api/agents/rule-hierarchy/levels/%s" % level["id"], json={"admin": "Sagar"}), "still holds 1 item")  # the one "other" item, not the crafted one
    # 4. the route writes the field the same way: a group only at an analyzer level that has it
    post = lambda body: c.post("/api/agents/rule-hierarchy/items", json=dict(body, admin="Sagar"))      # noqa: E731
    before = json.dumps(world.hier(), sort_keys=True)
    refused(post({"section": "errors", "level": "other", "name": "n", "group": status}), "has no groups")
    refused(post({"section": "errors", "level": level["id"], "name": "n", "group": status}), "has no groups")
    refused(post({"section": "analytics", "level": "nvme_command", "name": "n", "group": status}), "has no groups")
    refused(post({"section": "errors", "level": "nvme_command", "name": "n", "group": "No such group"}), "is not a group of")
    refused(post({"section": "errors", "level": "nvme_command", "name": "n", "group": "g" * 5000}), "is not a group of")
    refused(post({"section": "errors", "level": "nvme_command", "name": "n", "group": 7}), "must be text")
    refused(post({"section": "errors", "level": "nvme_command", "name": "n", "group": ["a"]}), "must be text")
    refused(post({"section": "errors", "level": "nvme_command", "name": "n", "group": "a\x00b"}), "NUL")
    assert json.dumps(world.hier(), sort_keys=True) == before
    r1 = post({"section": "errors", "level": "nvme_command", "name": "Slow write", "description": "a write slower than usual", "group": "  status the  DRIVE returned "})
    assert r1.status_code == 200 and r1.get_json()["key"] == "errors/nvme_command/slow_write" and r1.get_json()["rule"]["group"] == status      # stored by the group's own name
    for none in ("", None, "   "):
        r2 = post({"section": "errors", "level": "nvme_command", "name": "Loose one", "group": none})
        assert r2.status_code == 200 and "group" not in r2.get_json()["rule"]
    r3 = post({"section": "errors", "level": "nvme_command", "name": "No word about a group"})
    assert r3.status_code == 200 and "group" not in r3.get_json()["rule"]
    cmd = command_level(world.hier())
    assert "Slow write" in [i["name"] for i in next(g for g in cmd["groups"] if g["name"] == status)["items"]]
    assert RH.place_of("errors", "nvme_command", "slow_write") == ["Errors", "NVMe errors", "NVMe command level errors", status, "Slow write"]
    assert {"Loose one", "No word about a group"} <= {i["name"] for i in cmd["items"]}
    assert c.get("/api/agents/rules/errors/nvme_command/slow_write").status_code == 200           # the older routes know it by the same key


GROUP_SCENARIO = r"""
  const ERR = "errors/nvme_command";
  const plan = rbState(7); plan.mode = "plan"; plan.tree = DATA.tree; plan.hier = DATA.hier; plan.ticks = {};
  DATA.tree.forEach(s => s.levels.forEach(l => l.items.forEach(i => { plan.ticks[rbKey(s.section, l.level, i.id)] = !!i.default; })));
  plan.ticks[DATA.one] = true;                                    // the admin's plan holds one item of a group
  const first = rbInner(7);
  const lvl = plan.H.find(s => s.section === "errors").kinds[0].levels[0];
  const find = {}; for (const q of DATA.queries) find[q] = rhFind(lvl, q).map(i => i.id);
  // a tick taken off later does not close the way that was open
  plan.ticks[DATA.one] = false; const unticked = rbInner(7); plan.ticks[DATA.one] = true;
  // the field that finds an item, inside the open level; a word typed in another level does not filter this one
  plan.lq = "  Abort "; plan.lqAt = "l:errors/nvme_command"; const found = rbInner(7);
  plan.lqAt = "l:analytics/nvme_command"; const elsewhere = rbInner(7); plan.lq = ""; plan.lqAt = null;
  // an item of a group opened from a link; then the group above it is closed: the item closes with it
  plan.open = DATA.two; const item = rbInner(7);
  await rhAct("rh-node", { dataset: { rb: "7", node: "g:errors/nvme_command/" + DATA.groups[2] }, getAttribute: () => "true" });
  const closedItem = { open: plan.open, html: rbInner(7) };
  // Add an item to the level: the form at its place, the group asked, nothing chosen
  const atLevel = { dataset: { rb: "7", what: "item", sec: "errors", kind: "lecroy_nvme_pcie", lvl: "nvme_command", level: "nvme_command", alvl: "", gname: "" } };
  await rhAct("rh-form", atLevel); const levelForm = rbInner(7);
  Object.assign(els, { ain7: { value: "My new error" }, aid7: { value: "what it is" }, aim7: { innerHTML: "" } });
  await rbAddItem(7);
  const refusedAdd = { said: els.aim7.innerHTML, sent: sent.length };
  plan.addg = { at: ERR, none: false, name: DATA.groups[1] };
  const chose = rbInner(7);
  await rbAddItem(7);
  const sentGroup = sent.slice(), afterGroup = plan.addg, formAfter = plan.form, openAfter = Object.assign({}, plan.nopen);
  sent.length = 0; await rhAct("rh-form", atLevel); plan.addg = { at: ERR, none: true, name: "" };
  const choseNone = rbInner(7);
  await rbAddItem(7);
  const sentNone = sent.slice();
  // Add an item to this group: no question, the group named in the place line
  sent.length = 0; await rhAct("rh-form", { dataset: Object.assign({}, atLevel.dataset, { gname: DATA.groups[2] }) });
  const groupForm = rbInner(7);
  await rbAddItem(7);
  const sentInGroup = sent.slice();
  // Add a group
  const addGroup = { dataset: { rb: "7", what: "group", sec: "errors", kind: "lecroy_nvme_pcie", lvl: "nvme_command" } };
  await rhAct("rh-form", addGroup); const groupAdd = rbInner(7);
  Object.assign(els, { agn7: { value: "" }, aga7: { value: "" }, rhm7: { innerHTML: "" } });
  sent.length = 0; await rhSave(7, false); const groupNoName = { said: els.rhm7.innerHTML, sent: sent.length };
  els.agn7.value = "Timing of the queues"; els.aga7.value = "the checks on how long a queue waited";
  await rhSave(7, false); const groupSent = sent.slice(), groupOpened = Object.assign({}, plan.nopen), groupFormAfter = plan.form;
  // a group the admin added: Delete on its row; deleted only when empty
  plan.hier = DATA.hierAdmin; plan.nopen = {}; openAll(plan);
  const withAdminGroup = rbInner(7);
  await rhAct("rh-del", { dataset: { rb: "7", what: "group", sec: "errors", kind: "lecroy_nvme_pcie", lvl: "nvme_command", gname: "Timing of the queues", gid: "grp_timing" } });
  const delForm = rbInner(7);
  sent.length = 0; await rhSave(7, true); const delSent = sent.slice();
  // the library: the same tree, counted without "chosen"
  const lib = rbState("lib"); lib.mode = "lib"; lib.tree = DATA.tree; lib.hier = DATA.hier;
  const library = rbInner("lib");
  lib.nopen["s:errors"] = true; lib.nopen["k:errors/lecroy_nvme_pcie"] = true; lib.nopen["l:errors/nvme_command"] = true;
  const libLevel = rbInner("lib");
  // an older server: no groups are known, the level is one list
  const old = rbState("old"); old.mode = "lib"; old.tree = DATA.tree; old.hier = null; openAll(old);
  const older = rbInner("old");
  console.log("RESULT " + JSON.stringify({ first, unticked, find, found, elsewhere, item, closedItem, levelForm, refusedAdd, chose, sentGroup, afterGroup, formAfter, openAfter, choseNone, sentNone,
    groupForm, sentInGroup, groupAdd, groupNoName, groupSent, groupOpened, groupFormAfter, withAdminGroup, delForm, delSent, library, libLevel, older,
    place: rhPlace(plan, DATA.one), looseNames: lvl.loose.map(i => i.id), groupNames: lvl.groups.map(g => [g.name, g.items.length]) }));
"""


def test_a_level_with_groups_is_a_node_with_group_nodes_a_search_and_its_add_rows(world, tmp_path):
    from nvme_hier import command_error_rules as CE
    c = world.c
    tree, hier = c.get("/api/agents/rules").get_json(), world.hier()
    lvl = command_level(hier)
    groups = [g["name"] for g in lvl["groups"]]
    sizes = {g["name"]: len(g["items"]) for g in lvl["groups"]}
    assert groups == [n for n, _a in CE.GROUPS] and lvl["count"] == 2 + len(CE.items())
    one, two = lvl["groups"][0]["items"][3], lvl["groups"][2]["items"][0]
    every = RH.items_of(lvl)
    text_of = lambda i: "\n".join([i["name"], i["about"], i["in_group"] or ""]).lower()      # noqa: E731
    names = " ".join(i["name"] for i in every).lower() + " " + " ".join(groups).lower()
    meaning_word = next(w for i in every for w in re.findall(r"[a-z]{7,}", i["about"].lower()) if w not in names)
    queries = ["abort", "protocol", meaning_word, "status drive", "   ", "no such thing at all", "ABORT", "timeout"]
    hier_admin = copy.deepcopy(hier)
    command_level(hier_admin)["groups"].append({"name": "Timing of the queues", "about": "the checks on how long a queue waited", "more": "", "stated": False, "added": True, "id": "grp_timing", "items": []})
    answers = {"POST /api/agents/rule-hierarchy/items": {"rule": {"id": "my_new_error"}}, "POST /api/agents/rules": {"rule": {"id": "my_new_error"}},
               "POST /api/agents/rule-hierarchy/levels/nvme_command/groups": {"group": {"name": "Timing of the queues"}},
               "DELETE /api/agents/rule-hierarchy/levels/nvme_command/groups/grp_timing": {"deleted": "Timing of the queues"}}
    out = run_node(tmp_path, GROUP_SCENARIO, {"tree": tree, "hier": hier, "hierAdmin": hier_admin, "one": one["key"], "two": two["key"], "groups": groups, "queries": queries, "answers": answers})
    keep_for_the_browser("plan_card.html", out["first"])
    keep_for_the_browser("library.html", out["libLevel"])
    keep_for_the_browser("plan_card_all.html", out["withAdminGroup"])
    rows = lambda html: html.count('class="rb-item ')                    # noqa: E731
    # ---- the plan card: the way to the ticked items is open (the level, and the one group that holds a ticked item); the other groups are closed
    first, t = out["first"], tree_rows(out["first"])
    assert out["looseNames"] == [i["id"] for i in lvl["items"]] and out["groupNames"] == [[g, sizes[g]] for g in groups]
    opened = [r["node"] for r in t if r["open"]]
    assert "l:errors/nvme_command" in opened and "g:errors/nvme_command/%s" % groups[0] in opened
    assert not any(r["open"] for r in t if r["node"] in ("g:errors/nvme_command/%s" % groups[1], "g:errors/nvme_command/%s" % groups[2]))
    got = {r["name"]: r for r in t}
    for g in lvl["groups"]:
        assert got[g["name"]]["about"] == g["about"] and got[g["name"]]["count"] == "%d items%s" % (sizes[g["name"]], ", 1 chosen" if g["name"] == groups[0] else "")
    assert got["NVMe command level errors"]["count"] == "3 groups, %d items, 3 chosen" % lvl["count"]
    errblk = first.split('data-node="l:errors/nvme_command"')[1].split('data-node="l:errors/nvme_transaction"')[0]
    assert rows(errblk) == 2 + sizes[groups[0]] and lvl["groups"][0]["more"] in words(errblk)
    assert [r["name"] for r in t if r["node"].startswith("g:errors/nvme_command/")] == groups
    assert "Listed directly under this level, in no group 2 items, 2 chosen" in words(first)
    assert out["place"] == ["Errors", "NVMe errors", "NVMe command level errors", groups[0], one["name"]]
    assert [(r["node"], r["open"]) for r in tree_rows(out["unticked"])] == [(r["node"], r["open"]) for r in t]      # a tick taken off does not close what was open
    assert [l for l, _w in labels_with_reasons(errblk)] == ["Find an item in this level"]
    # ---- the search over the level: the page's own function against the same rule written here (every typed word in the name, the meaning or the group)
    order = [x["id"] for s in tree if s["section"] == "errors" for l in s["levels"] if l["level"] == "nvme_command" for x in l["items"]]
    for q in queries:
        typed = q.lower().split()
        want = [i["id"] for i in sorted(every, key=lambda i: order.index(i["id"])) if all(w in text_of(i) for w in typed)]
        assert out["find"][q] == want, (q, out["find"][q][:5], want[:5])
    assert len(out["find"]["   "]) == lvl["count"] and out["find"]["no such thing at all"] == [] and out["find"]["ABORT"] == out["find"]["abort"]
    assert set(out["find"]["protocol"]) >= {i["id"] for i in lvl["groups"][2]["items"]} and "cmd_timeout" in out["find"]["timeout"] and 1 < len(out["find"]["abort"]) < lvl["count"]
    n = len(out["find"]["abort"])
    found = out["found"].split('data-node="l:errors/nvme_command"')[1].split('data-node="l:errors/nvme_transaction"')[0]
    assert "%d of the %d items of this level match “Abort”" % (n, lvl["count"]) in words(found) and rows(found) == n and 'data-node="g:' not in found
    blk = lambda html: html.split('data-node="l:errors/nvme_command"')[1].split('data-node="l:errors/nvme_transaction"')[0]      # noqa: E731
    assert 'value="  Abort "' in out["found"] and rows(blk(out["elsewhere"])) == rows(errblk)
    # ---- closing the group above the open item closes the item too
    assert "Errors › NVMe errors › NVMe command level errors › %s › %s" % (groups[2], two["name"]) in words(out["item"])
    assert out["closedItem"]["open"] is None and two["name"] not in words(out["closedItem"]["html"])
    # ---- Add an item to the level: at its place (after the groups), the group asked with nothing chosen
    lf = out["levelForm"]
    form = lf.split('data-form="item"')[1]
    assert words(lf).index(groups[2]) < words(lf).index("Add an item to NVMe command level errors") and "Errors › NVMe errors › NVMe command level errors › your new item" in words(form)
    radios = re.findall(r'<input type="radio"[^>]*>', form)
    assert len(radios) == 4 and not any(re.search(r"\schecked", r) for r in radios)
    assert [l for l, _w in labels_with_reasons(form)] == ["Group", "Name", "In your words"]
    assert "choose the group it is listed in, or “No group”: one of the 4" in words(out["refusedAdd"]["said"]) and out["refusedAdd"]["sent"] == 0
    assert [bool(re.search(r"\schecked", r)) for r in re.findall(r'<input type="radio"[^>]*>', out["chose"])] == [False, True, False, False]
    assert "Errors › NVMe errors › NVMe command level errors › %s › your new item" % groups[1] in words(out["chose"])
    assert out["sentGroup"] == [["POST /api/agents/rule-hierarchy/items", {"section": "errors", "level": "nvme_command", "group": groups[1], "name": "My new error", "description": "what it is", "admin": "Sagar"}]]
    assert out["afterGroup"] is None and out["formAfter"] is None and out["openAfter"].get("g:errors/nvme_command/%s" % groups[1]) is True      # the group that received it is open
    assert [bool(re.search(r"\schecked", r)) for r in re.findall(r'<input type="radio"[^>]*>', out["choseNone"])] == [False, False, False, True]
    assert out["sentNone"] == [["POST /api/agents/rules", {"section": "errors", "level": "nvme_command", "name": "My new error", "description": "what it is", "admin": "Sagar"}]]
    # ---- Add an item to this group
    gf = out["groupForm"].split('data-form="item"')[1]
    assert 'type="radio"' not in gf and "Add an item to the group “%s”" % groups[2] in words(out["groupForm"]) and "Errors › NVMe errors › NVMe command level errors › %s › your new item" % groups[2] in words(gf)
    assert [l for l, _w in labels_with_reasons(gf)] == ["Name", "In your words"]
    assert out["sentInGroup"] == [["POST /api/agents/rule-hierarchy/items", {"section": "errors", "level": "nvme_command", "group": groups[2], "name": "My new error", "description": "what it is", "admin": "Sagar"}]]
    # ---- Add a group: at its place in the level, two fields with their reasons, the route's body, the new group open
    ga = out["groupAdd"]
    assert words(ga).index(groups[2]) < words(ga).index("Add a group to NVMe command level errors") < words(ga).index("Add an item to NVMe command level errors")
    assert [l for l, _w in labels_with_reasons(ga.split('data-form="group"')[1])] == ["Name", "What it holds"] and "Errors › NVMe errors › NVMe command level errors › your new group" in words(ga)
    assert "give the group a name" in out["groupNoName"]["said"] and out["groupNoName"]["sent"] == 0
    assert out["groupSent"] == [["POST /api/agents/rule-hierarchy/levels/nvme_command/groups", {"name": "Timing of the queues", "about": "the checks on how long a queue waited", "admin": "Sagar", "section": "errors"}]]
    assert out["groupOpened"].get("g:errors/nvme_command/Timing of the queues") is True and out["groupFormAfter"] is None
    # ---- a group the admin added: listed after the stated ones, with Delete; the stated ones say they are built in
    wa = tree_rows(out["withAdminGroup"])
    assert [r["name"] for r in wa if r["node"].startswith("g:errors/nvme_command/")] == groups + ["Timing of the queues"]
    assert "Delete" in out["withAdminGroup"].split('data-node="g:errors/nvme_command/Timing of the queues"')[1].split("</div>")[0]
    assert "It holds nothing" in words(out["delForm"]) and "Delete the group “Timing of the queues”?" in words(out["delForm"])
    assert out["delSent"] == [["DELETE /api/agents/rule-hierarchy/levels/nvme_command/groups/grp_timing", {"admin": "Sagar"}]]
    assert 'data-gid="grp_timing"' in out["withAdminGroup"]
    # ---- the library: the same tree, closed; its counts without "chosen"
    assert all(not r["open"] for r in tree_rows(out["library"])) and rows(out["library"]) == 0
    ll = tree_rows(out["libLevel"])
    assert [(r["name"], r["count"]) for r in ll if r["node"].startswith("g:")] == [(g, "%d items" % sizes[g]) for g in groups] and rows(out["libLevel"]) == 2
    assert not re.search(r"\d chosen", words(out["libLevel"])) and "in this analysis" not in words(out["libLevel"]).replace("whether it is in this analysis", "")
    # ---- an older server: one list, found by name, and no question about a group, no group to add
    older = out["older"].split('data-node="l:errors/nvme_command"')[1].split('data-node="l:errors/nvme_transaction"')[0]
    assert rows(older) == lvl["count"] and 'data-node="g:' not in older and 'type="radio"' not in older and "Find an item in this level" in words(older) and "Add a group" not in words(older)
    for html in (out["first"], out["item"], out["levelForm"], out["groupForm"], out["groupAdd"], out["withAdminGroup"], out["delForm"], out["library"], out["libLevel"], out["older"]):
        screen_rules(html)


def test_the_tree_never_scrolls_sideways_on_a_phone():
    """What can be said without a browser (the pages were looked at in one at 400 px): the rules view is one column; every row of the tree
    wraps, its texts can shrink and break, the indentation shrinks on a narrow window and the counts go under the name; nothing of the tree
    is held wider than a phone."""
    with open(os.path.join(APP, "app", "static", os.environ.get("RULE_HIER_HTML") or "agents.html"), encoding="utf-8") as fh:
        page = fh.read()
    rules = css_rules(re.search(r"<style>(.*?)</style>", page, re.S).group(1))
    has = lambda media, sel, *decls: any(md == media and s_ == sel and all(re.search(r"(^|[;\s])%s\s*(;|$)" % re.escape(d_), body.strip()) for d_ in decls) for md, s_, body in rules)      # noqa: E731
    assert has("", ".rb", "grid-template-columns: minmax(0, 1fr)")
    assert has("", ".rh-row", "flex-wrap: wrap", "min-width: 0") and has("", ".rh-tog", "min-width: 0", "grid-template-columns: auto minmax(0, 1fr) auto")
    assert has("", ".rh-name", "overflow-wrap: anywhere") and has("", ".rh-about", "overflow-wrap: anywhere") and has("", ".rh-iname", "overflow-wrap: anywhere")
    assert has("", ".rh-irow", "flex-wrap: wrap", "min-width: 0") and has("", ".rh-kids", "min-width: 0") and has("", ".rh-wrap", "min-width: 0")
    narrow = "@media (max-width: 520px)"
    assert has(narrow, ".rh-kids", "margin-left: 5px", "padding-left: 7px") and has(narrow, ".rh-tog", "grid-template-columns: auto minmax(0, 1fr)") and has(narrow, ".rh-cnt", "grid-column: 2")
    for md, sel, body in rules:
        if sel.startswith((".rh-", ".rb ")) or sel == ".rb":
            for prop, px in re.findall(r"(?<![-\w])(min-width|width|max-width)\s*:\s*(\d+)px", body):
                assert int(px) <= 560 and (prop != "min-width" or int(px) <= 40), (md, sel, prop, px)
            assert "nowrap" not in body or sel == ".rh-built", (md, sel)


# ------------------------------------------------------------------------------------------------ 6b. the card and the badge of one item
# (2026-11-15, found by looking at the pages) An opened rule family of the NVMe command level said "No verified code ... Press Code it" under
# a badge "needs code", its source data was printed with the stored level keys ("nvme_command: OPC"), and the rule file was shown with the
# whole path of the installation. The page's own functions are run here on the real answers of the routes, in both cases of the model.
CARD_REAL = ["IC", "rbUi", "rbCodeCase", "rbFamilies", "rbTakeCode", "rbMeta", "rbFindItem", "REC_FILE", "LEVEL_LABELS", "rbSources", "rbLibraryCode", "rbDetail"]
CARD_SCENARIO = r"""
  const out = {};
  for (const [name, c] of Object.entries(DATA.cases)) {
    const st = rbState("card-" + name); st.mode = "lib"; st.tree = JSON.parse(JSON.stringify(c.tree)); st.hier = DATA.hier; st.up = c.up || null; st.rulesFolder = DATA.rulesFolder;
    const [sec, lvl] = c.key.split("/"); st.sel = { sec, lvl, grp: null };
    const it = rbFindItem(st, c.key);
    const fromList = rbMeta(st, c.key, it), caseFromList = rbCodeCase(it);       // what the list alone says, before the item is opened
    st.ex[c.key] = c.explain; rbTakeCode(it, c.explain); st.open = c.key;
    out[name] = { fromList, caseFromList, opened: rbMeta(st, c.key, it), caseOpened: rbCodeCase(it, c.explain.code), card: rbDetail("card-" + name, c.key), page: rbInner("card-" + name) };
    st.delAsk = c.key; out[name].del = rbDelAsk("card-" + name, st, c.key, it); st.delAsk = null;
  }
  const gone = rbState("gone"); gone.mode = "lib"; gone.tree = DATA.cases[Object.keys(DATA.cases)[0]].tree; gone.hier = DATA.hier; gone.view = "deleted";
  gone.deleted = [{ key: "errors/nvme_command/x", section: "errors", level: "nvme_command", name: "An item", file: DATA.rulesFolder + "/_deleted/errors/nvme_command/x.json", at: 1, by: "Sagar", why: "" }];
  gone.rulesFolder = DATA.rulesFolder;
  out.deletedList = rbInner("gone");
  const st2 = rbState("src");
  out.sources = { none: rbSources(DATA.srcOpen.map(s => Object.assign({}, s, { path: null })), null), open: rbSources(DATA.srcOpen, "the-open-recording"), missing: rbSources(DATA.srcMissing, "the-open-recording") };
  console.log("RESULT " + JSON.stringify(out));
"""
RAW_LEVEL_KEY = re.compile(r"\b(nvme_command|nvme_transaction|packets|split|link)\s*:|\b(nvme_command|nvme_transaction)\b(?!\.csv)")


def card_cases(world, monkeypatch):
    """The real answers of the routes for the kinds of item, without a model and with one said to be connected."""
    from agentic import procedures as PR
    from nvme_hier import command_error_rules as CE
    c = world.c
    world.engine()                                          # the engine is made first: making it sets the question "is a model connected" for its own runner
    fam = "errors/nvme_command/%s" % CE.items()[0]["id"]
    mine = c.post("/api/agents/rules", json={"section": "errors", "level": "nvme_command", "name": "My own check", "description": "a write that took too long", "admin": "Sagar"}).get_json()
    own = "errors/nvme_command/%s" % mine["rule"]["id"]
    get = lambda key: c.get("/api/agents/rules/%s/explain" % key).get_json()      # noqa: E731
    cases = {}
    monkeypatch.setattr(PR, "MODEL_CONNECTED", lambda: False)
    tree = c.get("/api/agents/rules").get_json()
    cases["family_no_model"] = {"key": fam, "tree": tree, "explain": get(fam)}
    cases["near_limit"] = {"key": "analytics/nvme_command/near_limit", "tree": tree, "explain": get("analytics/nvme_command/near_limit")}
    cases["detector"] = {"key": "errors/nvme_command/cmd_timeout", "tree": tree, "explain": get("errors/nvme_command/cmd_timeout")}
    cases["admins_new"] = {"key": own, "tree": tree, "explain": get(own)}
    cases["admins_seeded"] = {"key": "analytics/nvme_command/command_type_share", "tree": tree, "explain": get("analytics/nvme_command/command_type_share")}
    monkeypatch.setattr(PR, "MODEL_CONNECTED", lambda: True)
    tree_m = c.get("/api/agents/rules").get_json()
    cases["family_model"] = {"key": fam, "tree": tree_m, "explain": get(fam)}
    cases["near_limit_model"] = {"key": "analytics/nvme_command/near_limit", "tree": tree_m, "explain": get("analytics/nvme_command/near_limit")}
    monkeypatch.setattr(PR, "MODEL_CONNECTED", lambda: False)
    return cases, fam, own


def reads(html):
    """What a person reads, joined as the browser joins it: a mark inside a sentence (bold, a file's name, a link, an icon) leaves no gap,
    a new block does."""
    return words(re.sub(r"<svg\b.*?</svg>", "", re.sub(r"</?(?:b|code|a|i|em|strong)\b[^>]*>", "", html), flags=re.S))


def keep_for_the_browser(name, value):
    """RULE_HIER_KEEP=<folder>: what the page drew is also written there, to be opened in a browser and looked at."""
    folder = os.environ.get("RULE_HIER_KEEP")
    if folder:
        os.makedirs(folder, exist_ok=True)
        with open(os.path.join(folder, name), "w", encoding="utf-8") as fh:
            fh.write(value if isinstance(value, str) else json.dumps(value))


def test_the_card_and_the_badge_say_whose_code_an_item_runs(world, lib, tmp_path, monkeypatch):
    from agentic import procedures as PR
    cases, fam, own = card_cases(world, monkeypatch)
    hier = world.hier()
    rules_folder = os.path.join(lib, "rules")
    # what the server says in the two cases: the list gives "verified" without a model and "needs code" with one, for the same seeded item
    listed = lambda case: next(i for s_ in cases[case]["tree"] for l in s_["levels"] for i in l["items"] if "%s/%s/%s" % (s_["section"], l["level"], i["id"]) == cases[case]["key"])      # noqa: E731
    assert (listed("family_no_model")["kind"], listed("family_no_model")["code"]) == ("command_error", "verified")
    assert (listed("family_model")["kind"], listed("family_model")["code"]) == ("command_error", "needs code")
    assert cases["family_no_model"]["explain"]["code"]["application"] == PR.APPLICATION_KINDS["command_error"] and "application" not in cases["family_model"]["explain"]["code"]
    assert (listed("near_limit")["kind"], listed("near_limit")["code"], listed("near_limit_model")["code"]) == ("near_limit", "verified", "verified")
    src_open = [{"file": "nvme_command.csv", "path": "/data/recordings/S17 timeout/S17_commands.csv", "columns": ["OPC", "SQID"]},
                {"file": "NVME_Transactions.csv", "path": "/data/recordings/S17 timeout/NVME_Transactions.csv", "columns": ["Type"]},
                {"file": "the tree", "path": "/srv/app/uploads/up-20261115-075240-ab12/hier.sqlite", "columns": ["nvme_command: OPC", "nvme_transaction: Type", "link: Link Tra Error", "packets: PSN", "split: Tag"]},
                {"file": "bench_log.csv", "path": "/data/recordings/S17 timeout/bench_log.csv", "columns": ["Volts"]}]
    src_missing = [{"file": "split.csv", "path": None, "columns": ["Tag"]}, {"file": "the tree", "path": None, "columns": ["nvme_command: OPC"]}]
    out = run_node(tmp_path, CARD_SCENARIO, {"cases": cases, "hier": hier, "rulesFolder": rules_folder, "srcOpen": src_open, "srcMissing": src_missing, "answers": {}}, real=CARD_REAL)
    keep_for_the_browser("cards.json", out)
    w = {k: reads(v["card"]) for k, v in out.items() if isinstance(v, dict) and "card" in v}
    badge = lambda k, which="opened": words(out[k][which]).strip()      # noqa: E731

    # ---- a rule family of the NVMe command level, no model connected: it runs the application's reference implementation
    f = out["family_no_model"]
    assert (f["caseOpened"], badge("family_no_model")) == ("application", "application's code")
    assert "needs code" not in f["fromList"] + f["opened"] and "needs code" not in w["family_no_model"]
    assert "✔ This rule runs the application's reference implementation of its rule family (the file nvme_hier/command_error_rules.py), because no model is connected." in w["family_no_model"]
    assert "No Coder wrote it and nobody approved it here, so there is nothing to code." in w["family_no_model"]
    assert "With a model connected, Family 4 writes the code from the rule's text in the flow, and the Tester compares its result with this reference implementation on the whole recording." in w["family_no_model"]
    assert "Press Code it" not in w["family_no_model"] and "No verified code" not in w["family_no_model"] and 'data-act="rb-code"' not in f["card"]      # Code it is not offered at all
    assert "approved by" not in w["family_no_model"]                            # nobody approved it: the card does not say "approved by the application"
    assert "The application's code ▾" in w["family_no_model"] and re.search(r'data-act="rb-run"[^>]*title="open an analysis first"', f["card"])
    # ---- the same item with a model connected: Family 4 writes its code in the flow; nothing "needs" the admin
    m = out["family_model"]
    assert (m["caseFromList"], m["caseOpened"], badge("family_model", "fromList"), badge("family_model")) == ("family4", "family4", "Family 4 writes the code", "Family 4 writes the code")
    assert "needs code" not in m["fromList"] + m["opened"] and "needs code" not in w["family_model"] and "No verified code" not in w["family_model"] and "Press Code it" not in w["family_model"]
    assert "A model is connected, so Family 4 writes this rule's code from the rule's text." in w["family_model"]
    assert "It does that in the flow, when the rule is chosen on page 3 of an analysis. Code it starts the same work here, for the open analysis." in w["family_model"]
    assert "No code is written and approved for procedure version 1 yet." in w["family_model"]
    assert "Without a model, this rule runs the application's reference implementation of its rule family." in w["family_model"]
    code_button = re.search(r'<button class="([^"]*)" data-act="rb-code"[^>]*>', m["card"])
    assert code_button and "primary" not in code_button.group(1) and "rb-warnw" not in m["card"]         # offered, not as the one way forward and not as a warning
    assert "reference implementation" not in badge("family_model") and "application's code" not in m["opened"]
    # ---- the other item whose code is part of the application, in both cases of the model
    for k in ("near_limit", "near_limit_model"):
        n = out[k]
        assert (n["caseFromList"], n["caseOpened"], badge(k, "fromList"), badge(k)) == ("application", "application", "application's code", "application's code")
        assert "✔ This item runs code that is part of the application (the file nvme_hier/near_limit.py)." in w[k]
        assert "That code is tested with the application, as the detector's code is. No Coder wrote it and nobody approved it here, so there is nothing to code." in w[k]
        assert "needs code" not in w[k] and "Press Code it" not in w[k] and 'data-act="rb-code"' not in n["card"] and "reference implementation" not in w[k]
    # ---- the detector's item keeps its own wording
    d = out["detector"]
    assert d["caseOpened"] == "detector" and badge("detector") == "0 found"
    assert "✔ Verified code: the detector, nvme_hier/rules.py, lines " in w["detector"] and "It is part of the application and tested with it." in w["detector"]
    assert "The steps below are written from the detector's code." in w["detector"] and "the detector's code, a file of the application" in w["detector"]
    # ---- an admin's own item: no procedure yet, and one with a procedure and no code (there "needs code" and "Code it" are true)
    a = out["admins_new"]
    assert (a["caseOpened"], badge("admins_new")) == ("none", "no procedure") and "No procedure yet." in w["admins_new"] and "The procedure comes first." in w["admins_new"]
    s_ = out["admins_seeded"]
    assert (s_["caseOpened"], badge("admins_seeded")) == ("needs code", "needs code") and "No verified code for procedure version 1. Press Code it." in w["admins_seeded"]
    assert re.search(r'<button class="[^"]*primary[^"]*" data-act="rb-code"', s_["card"])

    # ---- the source data: every file by its plain name, the columns per file, no stored level key
    assert "The tree: the files of the recording joined in stage 2. The columns used, by the file they come from: NVMe command file: OPC, SQID, ST.SCT, ST.SC NVMe transaction file: Type, DNR, M, CRD" in w["family_no_model"]
    assert "No analysis is open, so no recording's file is named here. The rule reads: NVMe command file (nvme_command.csv): OPC, SQID, NLB, ST.SCT, ST.SC, Time Stamp NVMe transaction file (NVME_Transactions.csv): Type, SCT, SC, Time Stamp" in w["detector"]
    assert "Split transaction file (split.csv) Link transaction file (link.csv): Explicit ACK, Link Tra Error" in w["detector"]
    so = reads(out["sources"]["open"])
    assert "/data/recordings/S17 timeout/ the recording's folder: 3 files of it are read NVMe command file (S17_commands.csv): OPC, SQID NVMe transaction file (NVME_Transactions.csv): Type bench_log.csv: Volts" in so
    assert so.count("/data/recordings/S17 timeout/") == 1 and "up-20261115" not in so and "hier.sqlite" not in so and "/srv/app" not in so      # the tree is not shown as a folder
    assert "NVMe command file: OPC NVMe transaction file: Type Link transaction file: Link Tra Error PCIe packet file: PSN Split transaction file: Tag" in so
    sm = reads(out["sources"]["missing"])
    assert "Not in the open recording: Split transaction file (split.csv): Tag" in sm and "No tree is built for the open recording." in sm and "NVMe command file: OPC" in sm
    assert "No analysis is open" in words(out["sources"]["none"]) and "No tree is built" not in words(out["sources"]["none"])
    for k, html in list(out["sources"].items()) + [(k, v["card"]) for k, v in out.items() if isinstance(v, dict) and "card" in v]:
        seen = words(re.sub(r"<(textarea|pre)\b.*?</\1>", "", html, flags=re.S))      # the lines of code shown as code are the code's own text
        hit = RAW_LEVEL_KEY.search(seen)
        assert not hit, (k, seen[max(0, hit.start() - 60):hit.end() + 40])

    # ---- where the rule is kept: the place line, the file's name and the folder inside the installation; never the path of the installation
    place = words(out["family_no_model"]["page"])
    from nvme_hier import command_error_rules as CE
    first = CE.items()[0]
    assert "Errors › NVMe errors › NVMe command level errors › %s › %s" % (first["group"], first["name"]) in place
    assert "The rule file of this item is %s.json. It is kept in the folder knowledge/rules of this installation, under its section and its level. Edit rule/procedure changes it." % fam.split("/")[2] in w["family_no_model"]
    above = os.path.dirname(lib)                              # the folders above the installation's knowledge folder: never on the card
    for k, v in out.items():
        for part in ([v] if isinstance(v, str) else [x for x in v.values() if isinstance(x, str)]):
            assert above not in part and "/home/" not in part and APP not in part, (k, part[max(0, part.find(above) - 80):part.find(above) + 80])
    assert "its rule file moves to the folder knowledge/rules/_deleted of this installation" in reads(out["family_no_model"]["del"])
    assert "Their rule files are kept in the folder knowledge/rules/_deleted of this installation; Restore puts one back where it was, as it was." in reads(out["deletedList"])
    assert ".application." not in w["family_no_model"]           # the copy of the application's code for the code runner is not named before it is written
    # since 2026-11-15 the list itself carries the file of the application's code an item runs (family3.tree, field "application"): the row
    # says "application's code" before any card is opened, never "needs code"; every row of the group says the same
    assert (f["caseFromList"], badge("family_no_model", "fromList")) == ("application", "application's code")
    in_group = sum(1 for i in CE.items() if i["group"] == first["group"])
    assert in_group > 5 and out["family_no_model"]["page"].count(">application's code</span>") == in_group and "verified code</span>" not in out["family_no_model"]["page"]
    assert out["family_model"]["page"].count(">Family 4 writes the code</span>") == in_group and "application's code" not in out["family_model"]["page"]
    assert "needs code" not in out["family_no_model"]["page"] + out["family_model"]["page"]
    for k in ("family_no_model", "family_model", "near_limit", "detector", "admins_new", "admins_seeded"):      # the item's stored key is not on its card
        seen, key = words(re.sub(r"<(textarea|pre)\b.*?</\1>", "", out[k]["card"], flags=re.S)), cases[k]["key"]
        assert key not in seen and key.rsplit("/", 1)[0] not in seen, (k, key)


def test_the_list_alone_never_says_needs_code_for_an_item_of_the_application(tmp_path):
    """The badge of a row before its card is opened, for every pair the list can give: a rule family that the list calls "verified" runs
    the reference implementation or code Family 4 wrote and the admin approved, and only the card can tell (or a list that says
    "application"), so the row says "verified code" until then and never "needs code"."""
    rows = [{"kind": k, "code": c, "application": a} for k in ("command_error", "near_limit", "python", "detection_rule", "distribution", None)
            for c in ("verified", "needs code", "none", "detector") for a in (None, "", "nvme_hier/x.py")]
    out = run_node(tmp_path, r"""
      const st = rbState("b"); st.up = null; st.counts = {};
      console.log("RESULT " + JSON.stringify(DATA.rows.map(r => { const it = Object.assign({}, r); if (it.application === null) delete it.application; return [rbCodeCase(it), rbMeta(st, "a/b/c", it)]; })));
    """, {"rows": rows, "answers": {}}, real=["rbCodeCase", "rbFamilies", "rbMeta"])
    for r, (case, badge) in zip(rows, out):
        text = words(badge).strip()
        if r["code"] == "detector":
            assert (case, text) == ("detector", "0 found"), r
        elif r["application"] or (r["application"] is None and r["kind"] == "near_limit"):
            assert (case, text) == {"verified": ("application", "application's code"), "needs code": ("refused", "cannot run as stated"), "none": ("none", "no procedure")}[r["code"]], r
        elif r["kind"] == "command_error" and r["code"] == "needs code":
            assert (case, text) == ("family4", "Family 4 writes the code"), r
        else:
            assert (case, text) == {"verified": ("verified", "verified code"), "needs code": ("needs code", "needs code"), "none": ("none", "no procedure")}[r["code"]], r
        if r["kind"] == "command_error" or (r["kind"] == "near_limit" and r["application"] != ""):       # "" = a card said the code is not the application's
            assert "needs code" not in text, r


def test_an_item_of_the_application_whose_plan_cannot_be_used_says_why_and_offers_no_code_it(tmp_path):
    """The share of "close to the limit" stated as something that is not a share: the server gives no verified code with its reason. The
    card shows the reason and sends the admin to Edit rule/procedure; Code it is not on the card."""
    tree = [{"section": "analytics", "label": "Data analytics", "name": "Data analytics", "about": "", "defects": False, "builtin": True, "number": 1,
             "levels": [{"level": "nvme_command", "label": "NVMe commands", "items": [{"id": "near_limit", "name": "Close to the limit", "status": "approved", "version": 1, "kind": "near_limit", "code": "needs code"}]}]}]
    explain = {"key": "analytics/nvme_command/near_limit", "name": "Close to the limit", "procedure": {"steps": ["One step."], "output": {"columns": ["a"], "order": ""}}, "procedure_info": {"version": 1},
               "sources": [], "rule_file": "/srv/app/knowledge/rules/analytics/nvme_command/near_limit.json", "rules_folder": "/srv/app/knowledge/rules", "code_file": None, "library_code": None, "last_result": None,
               "code": {"kind": "python", "application": "nvme_hier/near_limit.py", "procedure_version": 1, "verified": False, "refused": "The share must be above 0 and below 100 per cent; 250 was stated",
                        "why": "the item's plan cannot be used: The share must be above 0 and below 100 per cent; 250 was stated"}}
    out = run_node(tmp_path, r"""
      const st = rbState("r"); st.mode = "lib"; st.tree = DATA.tree; const key = DATA.explain.key, it = rbFindItem(st, key);
      const before = rbMeta(st, key, it); st.ex[key] = DATA.explain; rbTakeCode(it, DATA.explain);
      console.log("RESULT " + JSON.stringify({ before, after: rbMeta(st, key, it), card: rbDetail("r", key) }));
    """, {"tree": tree, "explain": explain, "answers": {}}, real=CARD_REAL)
    shown = reads(out["card"])
    assert words(out["before"]).strip() == words(out["after"]).strip() == "cannot run as stated"
    assert "This item cannot run as it is stated. The share must be above 0 and below 100 per cent; 250 was stated. It runs code that is part of the application (the file nvme_hier/near_limit.py), so there is nothing to code: use Edit rule/procedure, state it again, then run it again." in shown
    assert 'data-act="rb-code"' not in out["card"] and "Press Code it" not in shown and "needs code" not in shown and "/srv/app" not in out["card"]
    assert "The rule file of this item is near_limit.json. It is kept in the folder knowledge/rules of this installation" in shown


# ------------------------------------------------------------------------------------------------ 6c. the top bar on a narrow window
def css_rules(css):
    """{selector: declarations} of a style sheet, and the same inside each media block: [(media or "", selector, declarations)]."""
    css = re.sub(r"/\*.*?\*/", "", css, flags=re.S)
    out, i, media = [], 0, ""
    for m in re.finditer(r"(@media[^{]*)\{((?:[^{}]*\{[^{}]*\})*)\s*\}|([^{}@]+)\{([^{}]*)\}", css):
        if m.group(1):
            for r in re.finditer(r"([^{}]+)\{([^{}]*)\}", m.group(2)):
                out += [(" ".join(m.group(1).split()), sel.strip(), r.group(2)) for sel in r.group(1).split(",")]
        else:
            out += [("", sel.strip(), m.group(4)) for sel in m.group(3).split(",")]
    return out


def test_the_top_bar_wraps_and_nothing_in_it_is_held_wider_than_a_narrow_window():
    """What can be said without a browser (the measuring was done in one: 0 px of sideways scroll from 320 to 1600 px, with the decision
    that waits, what works now and both side buttons shown). The flow page's bar: its parts are direct children of one row that wraps up
    to 820 px, the texts in it can shrink (min-width: 0) or go to a row of their own, and no part has a fixed width above 66 px.
    The row at the top of the other pages (the shared style sheet): it wraps, and its chooser is not held at 280 px on a narrow window."""
    with open(os.path.join(APP, "app", "static", os.environ.get("RULE_HIER_HTML") or "agents.html"), encoding="utf-8") as fh:
        page = fh.read()
    bar = re.search(r'<header class="top"><div class="in">(.*?)</div></header>', page, re.S).group(1)
    kids = re.findall(r'^  <(\w+) class="([^"]*)"(?: id="([^"]*)")?', bar, re.M)
    assert [(k[1].split()[0], k[2]) for k in kids] == [("brand", ""), ("crumb", "crumb"), ("sp", ""), ("working", "working"), ("needs", "needs"), ("iconbtn", "inv-btn"), ("iconbtn", "side-btn"),
                                                       ("iconbtn", ""), ("iconbtn", ""), ("iconbtn", "open-settings"), ("avatar", "avatar")]
    assert bar.count('<span class="lbl">') == 5                                   # every button's name is a part of its own, so it can be left out on a narrow window
    rules = css_rules(re.search(r"<style>(.*?)</style>", page, re.S).group(1))
    has = lambda media, sel, *decls: any(md == media and s_ == sel and all(re.search(r"(^|[;\s])%s\s*(;|$)" % re.escape(d_), body.strip()) for d_ in decls) for md, s_, body in rules)      # noqa: E731
    narrow = "@media (max-width: 820px)"
    assert has(narrow, ".top .in", "flex-wrap: wrap")                              # the row wraps
    assert has(narrow, ".top .in::after", "flex: 0 0 100%", "order: 9") and has(narrow, ".top .working", "order: 10") and has(narrow, ".top .needs", "order: 10")      # the two status texts start a row of their own
    assert has(narrow, ".top .crumb", "flex: 1 1 0") and has("", ".crumb", "min-width: 0", "overflow: hidden") and has("", ".crumb > *", "min-width: 0")
    assert has(narrow, ".top .working", "min-width: 0") and has(narrow, ".top .needs", "min-width: 0") and has(narrow, ".top .working", "max-width: 100%") and has("", ".needs", "max-width: 100%", "white-space: nowrap")
    assert has("@media (max-width: 1160px)", ".iconbtn .lbl", "display: none") and has("@media (max-width: 700px)", ".brand > span:last-child", "display: none")
    assert has("@media (max-width: 520px)", ".top .crumb > *", "display: none") and has("@media (max-width: 520px)", ".top .crumb > a.home", "display: block")
    gutter = r"max\(16px, env\(safe-area-inset-(right|left), 0px\)\)"
    for sel in (".top .in", ".page"):                                             # a side gutter of at least 16 px, for the bar and for the page under it
        body = next(b for md, s_, b in rules if md == "" and s_ == sel)
        assert len(re.findall(gutter, body)) == 2, (sel, body)
    for md, sel, body in rules:                                                   # nothing of the bar is held wide
        if sel.startswith((".top", ".crumb", ".brand", ".iconbtn", ".needs", ".avatar")):
            for prop, px in re.findall(r"(?<![-\w])(min-width|width):\s*(\d+)px", body):
                assert int(px) <= 66, (md, sel, prop, px)
            assert "nowrap" not in body or sel in (".crumb > *", ".crumb b", ".needs", ".top .working"), (md, sel)      # a text that does not wrap must be one that can shrink or move down
    assert has("", ".tbl", "overflow-x: auto") and any(s_ == "pre.out" and "overflow-x: auto" in b for _m, s_, b in rules)      # tables and code blocks scroll inside their own box
    # ---- the row at the top of the other pages (/hier, /packets, /isolate, the error outside the tree): the shared style sheet
    with open(os.path.join(APP, "app", "static", os.environ.get("RULE_HIER_CSS") or "app.css"), encoding="utf-8") as fh:
        shared = css_rules(fh.read())
    has2 = lambda media, sel, *decls: any(md == media and s_ == sel and all(d_ in body for d_ in decls) for md, s_, body in shared)      # noqa: E731
    assert has2("", ".topbar", "flex-wrap: wrap") and has2("", ".topbar .ctx", "flex-wrap: wrap")
    assert has2("", ".topbar > *", "min-width: 0", "max-width: 100%") and has2("", ".topbar .ctx > *", "min-width: 0", "max-width: 100%")
    small = "@media (max-width: 720px)"
    assert has2(small, ".topbar .ctx label.inline select", "min-width: 0", "max-width: 100%") and has2(small, ".topbar .ctx label.inline", "flex-wrap: wrap")
    static = os.path.join(APP, "app", "static")
    for f in sorted(os.listdir(static)):                                          # every page that has such a row takes it from the shared style sheet
        if f.endswith(".html"):
            with open(os.path.join(static, f), encoding="utf-8") as fh:
                text = fh.read()
            if '<div class="topbar">' in text:
                assert '<link rel="stylesheet" href="/static/app.css">' in text, f
                own = re.search(r"<style>(.*?)</style>", text, re.S)
                assert not own or not re.search(r"\.topbar[^{]*\{[^}]*min-width:\s*[1-9]\d\dpx", own.group(1)), f


# ------------------------------------------------------------------------------------------------ 7. the older names of the sections
def test_the_older_names_of_the_sections_are_gone_from_what_the_screens_show_and_the_models_read():
    """"Error roots" is "Errors" since 2026-11-15, and the sections are not numbered on the screens of the hierarchy. The
    stored id stays "errors"."""
    old = re.compile(r"Error roots|\bSection [12]\b(?!\.\d)")            # "Section 1.4" of a specification is not a section of the library
    text = script()
    # the page script: the only lines that still hold the old name are the two that turn it into today's name
    left = [ln.strip()[:40] for ln in text.splitlines() if old.search(ln)]
    assert left == ["const rhSecName = s => { const n = s.nam", "const rhOldWords = t => String(t || \"\")."], left
    stages = re.search(r"^const STAGES = \[.*?^\];", text, re.M | re.S).group(0)
    assert "the section Data analytics" in stages and "the section Errors" in stages
    static = os.path.join(APP, "app", "static")
    for d, _dirs, files in os.walk(static):
        for f in files:
            if f.endswith((".html", ".js", ".css")) and os.path.join(d, f) != os.path.join(static, "js", "agents.js"):
                with open(os.path.join(d, f), encoding="utf-8") as fh:
                    assert not old.search(fh.read()), f
    with open(os.path.join(APP, "docs", "HOW_THE_APP_WORKS.html"), encoding="utf-8") as fh:        # the guide the application serves
        assert not old.search(fh.read())
    prompts = os.path.join(APP, "agentic", "prompts")
    for f in sorted(os.listdir(prompts)):
        if f.endswith(".md"):
            with open(os.path.join(prompts, f), encoding="utf-8") as fh:
                assert not old.search(fh.read()), f
    # the title of the plan step, and the sentences on how the rules work (shown, and given to the agents that answer about the rules)
    from api import agentic_api
    assert not old.search(" ".join(agentic_api.RULES_HOW)) and "in the section Errors" in " ".join(agentic_api.RULES_HOW)
    with open(os.path.join(APP, "agentic", "pipeline.py"), encoding="utf-8") as fh:
        title = re.search(r'"key": "f3_plan", "title": "([^"]*)"', fh.read()).group(1)
    assert not old.search(title) and "the rules to use on this data" in title
    # the names the hierarchy gives, and what did not change: the stored ids
    assert [b["label"] for b in family3.BUILTIN_SECTIONS] == ["Data analytics", "Errors"] and [b["id"] for b in family3.BUILTIN_SECTIONS] == ["analytics", "errors"]
    assert not old.search(json.dumps([RH.BUILTIN_KINDS, RH.LEVEL_WORDS]))


def test_the_deleted_list_shows_the_installations_reason_with_todays_name(tmp_path):
    out = run_node(tmp_path, r"""
      console.log("RESULT " + JSON.stringify({ a: rhOldWords("Error roots keeps only the NVMe command timeout and the read failure; restore this rule to use it"),
        b: rhOldWords("my own reason about Error roots"), c: rhOldWords(null), n: rhSecName({ section: "errors", label: "Section 2 · Error roots" }) }));
    """, {"answers": {}})
    assert out == {"a": "The section Errors keeps only the NVMe command timeout and the read failure; restore this rule to use it", "b": "my own reason about Error roots", "c": "", "n": "Errors"}
