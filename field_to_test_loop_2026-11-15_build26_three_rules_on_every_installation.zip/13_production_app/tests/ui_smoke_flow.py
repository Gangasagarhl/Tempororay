"""The whole flow clicked through in headless Chrome (port 9333), the way the admin uses the pages, with the stand-in.

    python3 tests/ui_smoke_flow.py

Home: your name, the folder ("Check" lists the five files), "Start the flow". Then the project's four pages
(1 Understand the data, 2 One tree, 3 Rules, defects, test cases, 4 Report): every decision is made with the page's
own buttons - the dictionaries, the strategy, the build, the tests, Family 3's rule picker (one tree of the rules:
rows opened one level down, one item unticked), the rules, the result, stage 1 (the "Correct" signal card), stage 2
("Verified: write the test file") - until the flow finishes on the Report page. Checks that each page shows only its
own stage (no rules list before page 3), the links (tree, isolation tab, exports, report), page 3's tree (every item of
a level with its state, "Use it in this analysis" offered but not pressed), the rules library, and that no script
error or failed request happened. Screenshots (light and dark) go to runs/ui_smoke_hier/flow_*.png.
The admin's own knowledge and isolation memory are set aside and put back (as in tests/test_flow.py).
"""
import json
import re
import os
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import test_flow as TF   # noqa: E402  (set aside / put back, the API helper)
from ui_smoke_hier import Chrome   # noqa: E402
from ui_smoke_agents import port_busy, FIVE_LEVELS, PLACE, REASONS, open_node, tree_row, tree_rows, tree_kids, tree_open_by_itself   # noqa: E402

BASE = TF.BASE
# page 3's level "NVMe command level errors" as drawn: its row's counts, its item rows (in the analysis: the item's card; otherwise its
# state and, where it can be used, "Use it in this analysis"), and how many rows under it are still closed
LEVEL_ROWS = """(() => { const b = document.querySelector('.rb.rh-run [data-act=rh-node][data-node="l:errors/nvme_command"]'); if (!b) return null;
  const box = b.closest('.rh-node').querySelector(':scope > .rh-kids'); if (!box) return null;
  const rows = [...box.querySelectorAll('.rh-irow')], out = rows.filter(r => !r.classList.contains('rh-in'));
  return { count: b.querySelector('.rh-cnt').innerText, rows: rows.length, inRun: rows.length - out.length,
           states: out.map(r => ((r.querySelector('.rh-state') || {}).innerText || '').trim()),
           use: out.filter(r => r.querySelector('[data-act=rh-use]')).map(r => r.querySelector('[data-act=rh-use]').innerText.trim()),
           useIn: rows.filter(r => r.classList.contains('rh-in') && r.querySelector('[data-act=rh-use]')).length,
           closed: box.querySelectorAll('[data-act=rh-node][aria-expanded=false]').length }; })()"""
ADMIN = "flow-ui-test"
R = {"pass": 0, "fail": 0}
SHOTS = []


def check(name, ok, detail=""):
    R["pass" if ok else "fail"] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:240]) if detail != "" else ""), flush=True)
    return ok


def shot(c, name):
    c.shot("flow_" + name)
    SHOTS.append(name)


def text(c, sel="#main"):
    return c.js("(document.querySelector(%s) || {innerText: ''}).innerText" % json.dumps(sel)) or ""


def main():
    if port_busy(9333):
        sys.exit("port 9333 is busy (another headless Chrome)")
    s0 = TF.api("GET", "/api/agents/settings")
    TF.MADE["settings"] = {k: s0.get(k) for k in ("runtime", "model", "slices")}
    TF.set_aside()
    TF.api("PUT", "/api/agents/settings", {"runtime": "standin", "slices": 5})
    c = Chrome()
    wait_for = lambda e: any(c.js(e) or time.sleep(0.3) for _ in range(40))      # noqa: E731
    t0 = time.time()
    try:
        c.goto(BASE + "/#/")
        time.sleep(2)
        check("home: the flow's four stages are named, and nothing else is shown yet", "Understand the data" in text(c) and "Report" in text(c) and
              (c.js("document.querySelectorAll('.rb, nav#nav').length") or 0) == 0)
        # (owner, 2026-11-15: "Keep only one field") the REA folder is given once, in the REA agent card; the new analysis only says which one it keeps
        check("home has one field for the REA findings, in the REA agent card, and the new analysis says which findings it keeps; it asks for no earlier tree",
              c.js("!document.getElementById('np-rea') && !!document.getElementById('np-rea-line') && document.getElementById('np-rea-line').innerText.startsWith('REA findings:') && !!document.getElementById('rea-card') && !!document.getElementById('rea-folder') && !document.getElementById('np-up')"))
        check("the REA agent offers nothing to ask before a folder was read, and Read stays off until a folder is checked",
              c.js("!document.getElementById('rea-q') && document.querySelector('#rea-box button[data-act=rea-read]').disabled"))
        c.js("document.getElementById('adm').value = %s" % json.dumps(ADMIN))
        c.js("document.getElementById('np-folder').value = %s; document.getElementById('np-check').click()" % json.dumps(TF.FOLDER))
        time.sleep(1.5)
        n = c.js("document.querySelectorAll('#np-inv .file').length") or 0
        check("'Check' shows the five files with their levels", n == 5 and "All five levels are there" in text(c, "#np-inv"), n)
        c.js("document.getElementById('np-name').value = 'flow ui test'")
        # (owner, 2026-11-15) the tool is not asked: "Check" says what was recognised from the files, and Start the flow is on
        check("the tool is not asked: 'Check' says it was recognised from the files, and 'Start the flow' is on",
              not c.js("!!document.getElementById('st-q')") and
              "Recognised from the files: an export of Teledyne LeCroy PCIe Protocol Analysis" in text(c, "#np-inv") and
              c.js("document.getElementById('np-make').disabled") is False, text(c, "#np-inv")[-300:])
        shot(c, "1_home")
        c.js("document.getElementById('np-make').click()")
        time.sleep(3)
        proj = next((p for p in TF.api("GET", "/api/agents/state")["projects"] if p["name"] == "flow ui test"), None)
        check("'Start the flow' creates the analysis and opens its page", proj is not None and "#/p/" in (c.js("location.hash") or ""))
        if not proj:
            return
        check("the analysis keeps the tool recognised from the files, and its page says it by name", proj.get("source_tool_name") == "Teledyne LeCroy PCIe Protocol Analysis" and
              "recognised from the files: an export of Teledyne LeCroy PCIe Protocol Analysis" in text(c, ".phead"), proj.get("source_tool_name"))
        TF.MADE["projects"].append(proj["id"])
        check("your name is kept and shown as initials", (c.js("document.getElementById('avatar').innerText") or "") == "F")
        check("the page shows the four stages as a stepper", (c.js("document.querySelectorAll('.stepper .stg').length") or 0) == 4)
        rid = next((r["id"] for r in TF.api("GET", "/api/agents/runs?project=%d" % proj["id"]) if r["kind"] == "flow"), None)
        clicks, seen, last, broken = [], set(), 0, []
        while time.time() - t0 < 1800:
            v = TF.view(rid)
            if time.time() - last > 30:
                TF.progress_line(v, "flow in the browser")
                last = time.time()
            if v["run"]["state"] != "running" or any(s["state"] == "failed" for s in v["steps"]):
                break
            if not any(r["state"] == "open" for r in v["reviews"]):
                time.sleep(2)
                continue
            time.sleep(1)
            c.js("location.hash = '#/p/%d'" % proj["id"])
            time.sleep(1.8)
            if "Something went wrong" in text(c):
                broken.append(text(c)[:200])
            title = c.js("(document.querySelector('.decide h3') || {}).innerText") or ""
            if not title:
                time.sleep(2)
                continue
            cur = c.js("(document.querySelector('.stg.cur .t') || {}).innerText") or ""
            if title.startswith("Data dictionary") and "dict" not in seen:
                seen.add("dict")
                check("a new decision rings the chime and the tab title shows how many wait", (c.js("window.__chimes") or 0) >= 1 and (c.js("document.title") or "").startswith("("),
                      (c.js("window.__chimes"), c.js("document.title")))
                check("page 1 opens by itself on the first decision, with nothing of the later stages", cur.startswith("1") and (c.js("document.querySelectorAll('.rb-item').length") or 0) == 0, cur)
                shot(c, "2_page1_decision")
            if title.startswith("The joining strategy") and "strat" not in seen:
                seen.add("strat")
                check("the page moves to 2 · One tree for the strategy, and page 1 shows done", cur.startswith("2") and "done" in (c.js("document.querySelector('.stg').innerText") or ""), cur)
                shot(c, "3_page2_strategy")
            if title.startswith("The rules to use") or title.startswith("What to look for"):
                check("page 3 opens for the rule picker", cur.startswith("3"), cur)
                # the rules (owner, 2026-11-15): one tree, Section > Kind of recording > Level > (Group >) items, every row a button that
                # opens one level down; only the way to the items ticked when the card was drawn opens by itself; evidence under an item
                wait_for("!!document.querySelector('.rb .rh-add[data-what=kind]')")       # the library's hierarchy has arrived
                ob = tree_open_by_itself(c, ".rb", "input[data-plan]:checked") or {}
                check("the rule picker draws the rules as one tree, and only the way to the ticked items is open by itself (no side list)",
                      len(ob.get("open") or []) >= 3 and ob.get("open") == ob.get("want") and (c.js("document.querySelectorAll('.rb .rb-side, .rb .rb-sec, .rb .rb-lvl').length") or 0) == 0, ob)
                for sec in ("analytics", "errors"):
                    open_node(c, ".rb", "s:" + sec)
                    open_node(c, ".rb", "k:%s/lecroy_nvme_pcie" % sec)
                lv = {sec: [x["name"] for x in tree_kids(c, ".rb", "k:%s/lecroy_nvme_pcie" % sec) or []] for sec in ("analytics", "errors")}
                check("the tree lists the sections, each with the five levels in the order of the analyzer's files", lv == FIVE_LEVELS, lv)
                shut = c.js("(document.querySelector('.rb [data-act=rh-node][data-node^=\"k:\"][aria-expanded=false]') || {dataset: {}}).dataset.node") or ""
                before = {x["node"] for x in tree_rows(c, ".rb")}
                down = []
                if shut:
                    open_node(c, ".rb", shut)
                    down = tree_kids(c, ".rb", shut) or []
                check("a click on a closed row opens only the next level down, its rows closed", down and all(not x["open"] for x in down)
                      and {x["node"] for x in tree_rows(c, ".rb")} == before | {x["node"] for x in down}, (shut, down))
                if shut:
                    c.js("(b => b && b.click())(%s)" % tree_row(".rb", shut))         # closed again, as it was
                    time.sleep(0.4)
                open_node(c, ".rb", "l:errors/nvme_command")
                where = c.js("(b => b ? [...b.closest('.rh-node').querySelectorAll('.rb-item')].map(p => p.dataset.sec + '/' + p.dataset.lvl) : [])(%s)"
                             % tree_row(".rb", "l:errors/nvme_command")) or []
                check("the level 'NVMe command level errors' lists only its own items", where and set(where) == {"errors/nvme_command"}, set(where))
                c.js("[...document.querySelectorAll('.rb .rb-item[data-sec=errors][data-lvl=nvme_command] .rb-open')].find(b => b.innerText.toLowerCase().includes('timeout')).click()")
                wait_for("document.querySelector('.rb-detail .rb-d')")
                d = (text(c, ".rb-detail") or "").lower()
                check("an opened item shows its source data (full paths), its procedure step by step, its code and the four buttons",
                      all(w in d for w in ("source data", "rules or procedure", "verified code", "nvme_transactions.csv", "edit rule/procedure", "run", "export csv")), d[:200])
                for n in ("s:analytics", "k:analytics/lecroy_nvme_pcie", "l:analytics/nvme_command"):
                    open_node(c, ".rb", n)
                was = text(c, "[id^=sum]")
                c.js("document.querySelector('.rb-item[data-key$=\"/read_pattern\"] .rb-tick').click()")
                time.sleep(0.4)
                summ = text(c, "[id^=sum]")
                check("unticking an item updates the count", int(summ.split()[0]) == int(was.split()[0]) - 1, (was, summ))
                shot(c, "4_page3_picker")
            if title.startswith("Result:") and "timeout" in title.lower() and "res" not in seen:
                seen.add("res")
                check("an errors pattern's result asks for no choice of one error (2026-11-11)", not c.js("!!document.querySelector('.decide select[id^=df]')"))
            if title.startswith("The errors: stage 1 and stage 2") and "errs" not in seen:
                # (owner, 2026-11-11) the errors go to the errors page; each error to its own page; page 3 shows only where they stand
                seen.add("errs")
                check("page 3 shows the pattern's errors and where they stand, with the errors page", re.search(r"\d[\d,]* errors?\b.{0,12}stage 1 done", text(c) or "") is not None
                      and c.js("!!document.querySelector('a[href*=\"/errors\"]')"))
                c.js("location.hash = '#/p/%d/errors'" % proj["id"])
                time.sleep(3)
                check("the errors page lists the errors, each with 'Isolate this error'", (c.js("document.querySelectorAll('section.card table tr').length") or 0) >= 2
                      and "Isolate this error" in (text(c) or ""))
                # (2026-11-15) a five-file recording has no CSV file outside the tree: the errors page shows no section for such errors, and no section without a row
                check("the errors page has no section for CSV files outside the tree when the flow has none, and no errors section with an empty table",
                      not c.js("!!document.getElementById('sec-other-csv')") and
                      c.js("[...document.querySelectorAll('section.card[id^=sec-] table')].every(t => t.querySelectorAll('tr').length >= 2)") is True)
                shot(c, "5_errors_page")
                href = c.js("(document.querySelector('section.card table a.btn') || {}).href") or ""
                c.goto(href)
                time.sleep(4)
                h2 = c.js("[...document.querySelectorAll('h2')].map(x => x.innerText)") or []
                # (2026-11-15) two parts were added: the optional search between parts 5 and 6, and part 7 (hand over to the validation
                # suite). The owner's six numbered parts must still stand in their order, and the optional part must say that it is one.
                numbered = [x.split(" · ")[0] for x in h2 if x.split(" · ")[0].isdigit()]
                check("the error page has its six parts in the owner's order", numbered[:6] == ["1", "2", "3", "4", "5", "6"] and "Isolation of the defect" in h2[2], h2)
                check("the parts added on 2026-11-14 are named as what they are: the search is optional and stands before the test, the hand-over is part 7",
                      any(x.startswith("Optional") and "Search" in x for x in h2) and numbered[6:7] == ["7"]
                      and [i for i, x in enumerate(h2) if x.startswith("Optional")][:1] < [i for i, x in enumerate(h2) if x.startswith("6")][:1], h2)
                check("the commands around the error are a tree with expand", (c.js("document.querySelectorAll('#win button.exp').length") or 0) >= 1)
                c.js("document.getElementById('btn-isolate').click()")
                ok = any(c.js("!!document.getElementById('btn-name')") or time.sleep(1) for _ in range(180))
                check("'Isolate the defect' shows its progress and gives the dictionary's name of the defect", ok and "as the dictionary names it" in (text(c, "#iso-out") or "").lower(),
                      (ok, (text(c, "#iso-out") or "")[:160]))
                shot(c, "6_error_page_isolation")
                c.goto(BASE + "/#/p/%d/rules" % proj["id"])
                time.sleep(3)
            if title.startswith("REA findings"):
                check("the flow never asks for the REA findings (the REA agent is on the start page)", False, cur)
            btn = (".decide .choice[data-sig=correct]" if c.js("!!document.querySelector('.decide .choice[data-sig=correct]')") else
                   ".decide button[data-norea]" if c.js("!!document.querySelector('.decide button[data-norea]')") else
                   ".decide .actions .btn.primary[data-dec=approve]")     # the card's own Approve (the join rules' hidden "Save as version" buttons are primary too)
            label = (c.js("(document.querySelector(%s + ' b') || document.querySelector(%s)).innerText" % (json.dumps(btn), json.dumps(btn))) or "").strip().split("\n")[0]
            c.js("document.querySelectorAll('.decide input[data-jr]').forEach(x => { if (!x.checked) x.click(); })")     # the admin ticks each rule for combining the files
            c.js("document.querySelector(%s).click()" % json.dumps(btn))
            clicks.append((title[:50], label))
            print("      [%4.0f s] clicked '%s' on '%s'" % (time.time() - t0, label, title[:60]), flush=True)
            time.sleep(2.5)
        v = TF.view(rid)
        check("the flow finished, decided entirely through the page's buttons", v["run"]["state"] == "finished" and not any(s["state"] == "failed" for s in v["steps"]),
              (v["run"]["state"], [s["title"] for s in v["steps"] if s["state"] == "failed"][:1]))
        labels = {lab for _t, lab in clicks}
        check("the plan and the end of the errors were decided with their own buttons", {"Run the chosen rules", "Done: write the report"} <= labels, sorted(labels))
        check("the item unticked in the page did not run", not any("read_pattern" in s["key"] for s in v["steps"]))
        up = TF.api("GET", "/api/agents/projects/%d" % proj["id"]).get("upload_id")
        if up:
            TF.MADE["uploads"].add(up)
        tc = next((s for s in v["steps"] if s["key"].endswith(":testcase")), {})
        if (tc.get("output") or {}).get("path"):
            TF.MADE.setdefault("tests", []).append(tc["output"]["path"])
        c.js("location.hash = '#/p/%d'" % proj["id"])
        time.sleep(2.5)
        cur = c.js("(document.querySelector('.stg.cur .t') || {}).innerText") or ""
        steps_done = c.js("[...document.querySelectorAll('.stg')].every(s => s.classList.contains('done'))")
        check("when the flow is finished the page opens on 4 · Report, and every stage shows done", cur.startswith("4") and steps_done, cur)
        tiles = text(c, ".tiles")
        check("the report page sums it up: dictionaries, windows, rules, errors found, isolated, stage 2, test files",
              all(x in tiles for x in ("data dictionaries", "rules run", "errors found", "isolated (stage 1 done)", "stage 2 done", "test files")), tiles[:160])
        href = c.js("([...document.querySelectorAll('a')].find(a => a.innerText.includes('Open the flow report')) || {}).href") or ""
        try:
            page = urllib.request.urlopen(href).read() if href else b""
            check("the flow report opens, with where each error stands", b"Family 3" in page and b"The errors: stage 1, stage 2" in page)
        except Exception as e:      # noqa: BLE001
            check("the flow report opens", False, e)
        shot(c, "7_page4_report")
        check("the analysis page says who started the flow", "started by " + ADMIN in (c.js("document.querySelector('.phead .meta').innerText") or ""))
        c.js("[...document.querySelectorAll('[data-act=start-flow]')].find(b => b.innerText.includes('Run the flow again')).click()")
        time.sleep(1)
        check("'Run the flow again' first asks who is starting it (filled in with the last name used)",
              (c.js("document.querySelector('#modal h2').innerText") or "") == "Who is starting this flow?" and c.js("document.getElementById('st-name').value") == ADMIN)
        c.js("document.querySelector('#modal [data-act=close]').click()")
        time.sleep(0.5)
        c.js("document.querySelector('.stg[data-stage=rules]').click()")
        time.sleep(2)
        c.js("document.querySelectorAll('details.group').forEach(d => d.open = true)")
        time.sleep(0.5)
        links = c.js("[...document.querySelectorAll('#main a')].map(a => a.innerText)") or []
        check("page 3 links the errors page and the exports, and shows the test files", any("errors page" in x for x in links) and any("export" in x.lower() for x in links) and "test file" in text(c), links[:8])
        shot(c, "8_page3_done")
        # (owner, 2026-11-15) page 3 draws the rules as the library's tree: only the way to the items of this analysis is open by itself; a level
        # lists every item with its state in this analysis, and an item not in it offers "Use it in this analysis". The button is NOT pressed:
        # on this finished analysis it would open the analysis again, and the rest of this walk reads the flow as it finished.
        wait_for("!!document.querySelector('.rb.rh-run .rh-add[data-what=kind]')")      # the library's hierarchy has arrived (its places to add are drawn)
        ob = tree_open_by_itself(c, ".rb.rh-run", ".rh-irow.rh-in") or {}
        check("page 3 draws the rules as one tree, and only the way to the items of this analysis is open by itself",
              len(ob.get("open") or []) >= 3 and ob.get("open") == ob.get("want"), ob)
        for n in ("s:errors", "k:errors/lecroy_nvme_pcie", "l:errors/nvme_command"):
            open_node(c, ".rb.rh-run", n)
        c.js("(() => { for (let i = 0; i < 60; i++) { const b = document.querySelector('.rb.rh-run [data-act=rh-node][data-node^=\"g:errors/nvme_command/\"][aria-expanded=false]');"
             " if (!b) break; b.click(); } })()")          # every group of the level opened
        wait_for("!!document.querySelector('.rb.rh-run [data-act=rh-use]')")      # what this analysis holds has arrived from the server
        lv = c.js(LEVEL_ROWS) or {}
        m = re.search(r"([\d,]+) items?, ([\d,]+) in this analysis", lv.get("count") or "")
        check("page 3 lists every item of NVMe command level errors, each with its state in this analysis",
              m is not None and lv["rows"] == int(m.group(1).replace(",", "")) >= 2 and lv["inRun"] == int(m.group(2).replace(",", "")) >= 1
              and all(lv["states"]) and lv["closed"] == 0, {k: lv.get(k) for k in ("count", "rows", "inRun", "closed")})
        check("'Use it in this analysis' is offered at an item that is not in the analysis, and never at one that is",
              len(lv.get("use") or []) >= 1 and all(u == "Use it in this analysis" for u in lv["use"]) and lv.get("useIn") == 0, (lv.get("use") or [])[:2])
        add = '.rb.rh-run .rh-add[data-what=item][data-sec=errors][data-lvl=nvme_command][data-gname=""]'
        c.js("(b => b && b.click())(document.querySelector(%s))" % json.dumps(add))
        time.sleep(0.4)
        got = c.js(REASONS % json.dumps(".rb.rh-run .rh-form label.f")) or []
        check("page 3's 'Add an item to NVMe command level errors' opens its form in place: a why-line under every field, nothing typed or chosen",
              len(got) == 3 and all(got) and c.js(PLACE % json.dumps(".rb.rh-run .rh-form")) == "l:errors/nvme_command"
              and c.js("[...document.querySelectorAll('.rb.rh-run .rh-form input[type=text], .rb.rh-run .rh-form textarea')].every(x => !x.value) "
                       "&& !document.querySelector('.rb.rh-run .rh-form input:checked')") is True, got)
        c.js("(b => b && b.click())(document.querySelector('.rb.rh-run .rh-form [data-act=rh-cancel]'))")
        time.sleep(0.3)
        c.js("document.querySelector('.stg[data-stage=tree]').click()")
        time.sleep(2)
        check("page 2 shows the tree's tests as figures and opens the tree", "random windows" in text(c, ".tiles") and any("Open the tree" in x for x in (c.js("[...document.querySelectorAll('#main a')].map(a => a.innerText)") or [])))
        c.js("location.hash = '#/library'")
        time.sleep(2)
        wait_for("document.querySelectorAll('.rb-lib [data-act=rh-node]').length >= 2")
        lib0 = tree_rows(c, ".rb-lib")
        check("the rules library opens as one tree: every row closed, no item listed before a level is opened",
              len(lib0) >= 2 and not any(x["open"] for x in lib0) and (c.js("document.querySelectorAll('.rb-lib .rb-item').length") or 0) == 0, lib0[:3])
        for n in ("s:errors", "k:errors/lecroy_nvme_pcie", "l:errors/nvme_command"):
            open_node(c, ".rb-lib", n)
        check("the rules library opens from page 3 (and only lists, then shows one rule at a time)", (c.js("document.querySelectorAll('.rb-lib .rb-item').length") or 0) >= 2)
        c.js("document.querySelector('.rb-lib .rb-open').click()")
        time.sleep(2)
        check("one item shows its source data, its procedure and its code", all(w in text(c).lower() for w in ("source data", "rules or procedure", "code")))
        shot(c, "9_library")
        c.js("location.hash = '#/history'")
        time.sleep(1.5)
        check("History lists the flow", "The flow" in text(c))
        c.js("document.getElementById('open-settings').click()")
        time.sleep(1)
        check("Settings open as a dialog with the places the agents can run: opencode in a terminal first, and with API calls off only the stand-in beside it", (c.js("document.querySelectorAll('#set-rt button').length") or 0) == (4 if c.js("!!document.getElementById('set-url')") else 2)
              and c.js("document.querySelector('#set-rt button').dataset.rt") == "opencode" and c.js("!!document.getElementById('set-oc-model')"))
        # (2026-11-15) the three switches of the settings file, each with its why-line; the value shown is the file's, and nothing is chosen for the admin
        sw = c.js("[...document.querySelectorAll('#modal select')].filter(s => ['set-memory', 'set-round', 'set-recheck'].includes(s.id)).map(s => ({id: s.id, now: s.dataset.now, value: s.value, label: ((document.querySelector('#modal label.f[for=' + s.id + ']') || {}).innerText || ''), why: (((document.querySelector('#modal label.f[for=' + s.id + ']') || {}).nextElementSibling || {}).className === 'why' ? document.querySelector('#modal label.f[for=' + s.id + ']').nextElementSibling.textContent.length : 0)}))") or []
        check("Settings show the switches of the settings file, each with a why-line under its label and the value the file holds", len(sw) in (2, 3) and
              all(x["label"] and x["why"] > 40 and x["value"] == x["now"] for x in sw), sw)
        c.js("document.querySelector('#modal [data-act=close]').click()")
        c.send("Emulation.setEmulatedMedia", features=[{"name": "prefers-color-scheme", "value": "dark"}])
        c.js("location.hash = '#/p/%d/rules'" % proj["id"])
        time.sleep(2)
        shot(c, "10_page3_dark")
        c.js("location.hash = '#/'")
        time.sleep(2)
        shot(c, "11_home_dark")
        print("screenshots: runs/ui_smoke_hier/flow_*.png (%d)" % len(SHOTS))
        check("no script error and no failed request in the whole walk", not c.errors, c.errors[:3])
        check("the page never showed 'Something went wrong' (an error the page caught itself)", not broken, broken[:2])
    finally:
        c.close()
        TF.put_back()
    print("%d checks, %d failed, %.0f s" % (R["pass"] + R["fail"], R["fail"], time.time() - t0))
    sys.exit(1 if R["fail"] else 0)


if __name__ == "__main__":
    main()
