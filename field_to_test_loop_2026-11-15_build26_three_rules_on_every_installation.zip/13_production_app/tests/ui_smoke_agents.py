"""Browser check of the flow pages (the front page /, also at /agents) in headless Chrome (port 9333). Read-only.

    python3 tests/ui_smoke_agents.py

Home shows only what starts an analysis (your name, the folder, Start) and the four stages by name; there is no
permanent sidebar and no rules list at the start. The top bar opens History, the guide and Settings (a dialog). The
rules library (Family 3) is one tree (2026-11-15): Section > Kind of recording > Level > (Group >) items, every row a
button that opens only the next level down, a search, one rule shown at a time; every "Add ..." row (section, kind of
recording, level, group, item) opens its form in place, a why-line under every field and nothing chosen. No script
error and no failed request.
(tests/ui_smoke_flow.py clicks through a whole flow.)
"""
import json
import os
import socket
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ui_smoke_hier import Chrome   # noqa: E402


def port_busy(port):
    with socket.socket() as sk:
        return sk.connect_ex(("127.0.0.1", port)) == 0


BASE = "http://127.0.0.1:8077"
R = {"pass": 0, "fail": 0}


def check(name, ok, detail=""):
    R["pass" if ok else "fail"] += 1
    print("%s  %s%s" % ("PASS" if ok else "FAIL", name, ("  | " + str(detail)[:200]) if detail != "" else ""), flush=True)


# ---- the rules tree (owner, 2026-11-15): page 3, the plan card and the Rules library draw one tree, Section > Kind of recording > Level >
# (Group >) items. Every row is a button [data-act=rh-node][data-node="s:<section>" | "k:<section>/<kind>" | "l:<section>/<level>" |
# "g:<section>/<level>/<group>"] with aria-expanded; a click opens or closes it. (Also used by tests/ui_smoke_flow.py.)
FIVE_IDS = ["nvme_command", "nvme_transaction", "split", "link", "packets"]
FIVE_LEVELS = {"analytics": ["NVMe command level", "NVMe transaction level", "Split transaction level", "Link transaction level", "PCIe packet level"],
               "errors": ["NVMe command level errors", "NVMe transaction level errors", "Split transaction level errors", "Link transaction level errors", "PCIe packet level errors"]}
# where an element sits in the tree: the row whose node holds it, "after the tree" (the form of a new section), or "elsewhere"
PLACE = ("(x => { if (!x) return null; const n = x.closest('.rh-node'); return n ? n.querySelector(':scope > .rh-row > [data-act=rh-node]').dataset.node"
         " : x.previousElementSibling && x.previousElementSibling.classList.contains('rh-tree') ? 'after the tree' : 'elsewhere'; })(document.querySelector(%s))")
# every field label the selector finds: true when a why-line of more than 40 characters stands directly under it
REASONS = "[...document.querySelectorAll(%s)].map(l => { const w = l.nextElementSibling; return !!w && w.classList.contains('why') && w.innerText.trim().length > 40; })"


def tree_row(scope, n):
    return "document.querySelector(%s)" % json.dumps('%s [data-act=rh-node][data-node="%s"]' % (scope, n))


def open_node(c, scope, n):
    """Opens a row of the tree when it is closed (a click on an open row would close it). -> False when there is no such row."""
    ok = c.js("(b => { if (b && b.getAttribute('aria-expanded') !== 'true') b.click(); return !!b; })(%s)" % tree_row(scope, n))
    time.sleep(0.4)
    return ok


ROW_JS = "({node: %s.dataset.node, open: %s.getAttribute('aria-expanded') === 'true', name: (%s.querySelector('.rh-name') || {}).innerText || ''})"


def tree_rows(c, scope):
    """Every row of the tree as drawn, in order: [{node, open, name}]."""
    return c.js("[...document.querySelectorAll(%s)].map(b => %s)" % (json.dumps(scope + " [data-act=rh-node]"), ROW_JS % ("b", "b", "b"))) or []


def tree_kids(c, scope, n):
    """The rows directly under one row, in order ([] while it is closed; None when there is no such row)."""
    return c.js("(b => b ? [...b.closest('.rh-node').querySelectorAll(':scope > .rh-kids > .rh-node > .rh-row > [data-act=rh-node]')].map(x => %s) : null)(%s)"
                % (ROW_JS % ("x", "x", "x"), tree_row(scope, n)))


def tree_open_by_itself(c, scope, rows):
    """The rows open now, and the rows above the elements `rows` finds (the items whose way opens by itself): {open, want}, both sorted."""
    return c.js("(() => { const rb = document.querySelector(%s); if (!rb) return null; const want = new Set();"
                " rb.querySelectorAll(%s).forEach(r => { let n = r.closest('.rh-node'); while (n) { want.add(n.querySelector(':scope > .rh-row > [data-act=rh-node]').dataset.node); n = n.parentElement.closest('.rh-node'); } });"
                " return {open: [...rb.querySelectorAll('[data-act=rh-node][aria-expanded=true]')].map(b => b.dataset.node).sort(), want: [...want].sort()}; })()"
                % (json.dumps(scope), json.dumps(rows)))


def main():
    if port_busy(9333):
        sys.exit("port 9333 is busy (another headless Chrome)")
    c = Chrome()
    txt = lambda: c.js("document.getElementById('main').innerText") or ""     # noqa: E731
    try:
        c.goto(BASE + "/#/")
        time.sleep(2.5)
        check("the front page is the flow", (c.js("document.title") or "").endswith("Field-to-Test flow"))
        t = txt()
        check("home names the four stages in order", all(x in t for x in ("1 · Understand the data", "2 · One tree", "3 · Rules, defects, test cases", "4 · Report")), t[:200])
        check("home asks only for what starts an analysis: the folder, a name, Start", all(c.js("!!document.getElementById('%s')" % i) for i in ("np-folder", "np-check", "np-name", "np-make")))
        check("the other options are folded under 'More options'", c.js("!document.querySelector('details.more[data-id=np-more]').open") is True)
        n_fields = c.js("document.querySelectorAll('#main label.f').length") or 0
        n_why = c.js("[...document.querySelectorAll('#main label.f')].filter(l => (l.nextElementSibling || {}).className === 'why' && l.nextElementSibling.textContent.length > 40).length") or 0
        check("every field says why it exists (a 'why' line under each label)", n_fields >= 3 and n_why == n_fields, (n_why, n_fields))
        check("the name of the analysis is marked required and unique", "required · unique" in (c.js("document.querySelector('label[for=np-name]').innerText") or ""))
        # (owner, 2026-11-15) the question "which tool exported the recording" is gone: the tool is recognised from the files
        check("the start card does not ask which tool exported the recording, and Start the flow is on",
              not c.js("!!document.getElementById('st-q')") and "Which tool exported the recording" not in (c.js("document.getElementById('main').innerText") or "") and
              c.js("document.getElementById('np-make').disabled") is False)
        check("no key of a tool is on the page", not c.js("/teledyne_lecroy_pcie|windows_wpa|pcmark10|another_tool/.test(document.getElementById('main').innerText)"))
        check("tools with notes only are not shown on the start page", not c.js("/Windows Performance Analyzer|PCMark 10/.test(document.getElementById('main').innerText)"))
        c.js("document.getElementById('adm').value = 'ui-check'; document.getElementById('np-folder').value = '/tmp'; document.getElementById('np-make').click()")
        time.sleep(0.8)
        check("Start without a name is stopped with the reason, nothing is created", "give the analysis a name" in (c.js("document.getElementById('np-msg').innerText") or ""))
        c.js("document.getElementById('np-name').value = 'a brand new name'; document.getElementById('np-name').dispatchEvent(new Event('input', {bubbles: true}))")
        time.sleep(0.4)
        check("while typing, the page says whether the name opens an existing analysis or makes a new one", "new analysis" in (c.js("document.getElementById('np-name-hint').innerText") or "").lower())
        c.js("localStorage.setItem('agents.admin', 'someone before')")
        c.goto(BASE + "/?reload=1#/")          # a real reload: the page reads the saved name again
        time.sleep(2.5)
        check("the starter's name is asked every time, even after a name was saved here (filled in, can be changed)",
              c.js("document.getElementById('adm') && document.getElementById('adm').value") == "someone before" and "change it if someone else is starting" in (c.js("document.querySelector('label[for=adm]').nextElementSibling.textContent") or ""))
        c.js("localStorage.removeItem('agents.admin')")
        check("no permanent sidebar and no rules list at the start", (c.js("document.querySelectorAll('nav#nav, .rb').length") or 0) == 0)
        top = c.js("document.querySelector('.top').innerText") or ""
        check("the top bar offers History, Guide and Settings", all(x in top for x in ("History", "Guide", "Settings")), top)
        c.js("document.getElementById('open-settings').click()")
        time.sleep(1)
        check("Settings open as a dialog: your name and where the agents run", c.js("document.getElementById('modal').classList.contains('on')") and (c.js("document.querySelectorAll('#set-rt button').length") or 0) in (2, 4))
        # (2026-11-15) three switches of the settings file: each with its why-line, showing the value the file holds, and nothing is sent before Save
        sw = c.js("[...document.querySelectorAll('#modal select')].filter(s => ['set-memory', 'set-round', 'set-recheck'].includes(s.id)).map(s => ({id: s.id, now: s.dataset.now, value: s.value, label: ((document.querySelector('#modal label.f[for=' + s.id + ']') || {}).innerText || ''), why: (((document.querySelector('#modal label.f[for=' + s.id + ']') || {}).nextElementSibling || {}).className === 'why' ? document.querySelector('#modal label.f[for=' + s.id + ']').nextElementSibling.textContent.length : 0)}))") or []
        check("Settings show the switches of the settings file (the search memory of stage 2, the rule for a packet number that comes round, and the recheck of Family 4's code when "
              "the file has it), each with a why-line of more than 40 characters under its label", len(sw) in (2, 3) and [x["id"] for x in sw][:2] == ["set-memory", "set-round"]
              and all(x["label"] and x["why"] > 40 for x in sw), sw)
        check("each switch shows the value of the settings file, or 'not set' with nothing chosen", all(x["value"] == x["now"] for x in sw) and
              all(x["now"] in (("always", "ask", "never", "") if x["id"] == "set-recheck" else ("true", "false", "")) for x in sw), sw)
        c.js("document.querySelector('#modal [data-act=close]').click()")
        time.sleep(0.3)
        check("the dialog closes", not c.js("document.getElementById('modal').classList.contains('on')"))
        c.js("location.hash = '#/history'")
        time.sleep(1.5)
        check("History opens", "Every run" in txt())
        c.js("location.hash = '#/library'")
        for _ in range(30):        # the library draws when its list has arrived
            time.sleep(0.3)
            if (c.js("document.querySelectorAll('.rb-lib [data-act=rh-node]').length") or 0) >= 2:
                break
        # (owner, 2026-11-15) one tree: Section > Kind of recording > Level > (Group >) items. Nothing opens by itself in the library;
        # a click on a row opens only the next level down
        r0 = tree_rows(c, ".rb-lib")
        check("the rules library is one tree: the sections as rows that open, all closed, no item listed yet, and a search; the side list is gone",
              len(r0) >= 2 and [x["name"] for x in r0][:2] == ["Data analytics", "Errors"] and all(x["node"].startswith("s:") and not x["open"] for x in r0)
              and (c.js("document.querySelectorAll('.rb-lib .rb-item, .rb-lib .rb-side, .rb-lib .rb-lvl, .rb-lib .rb-sec').length") or 0) == 0
              and c.js("!!document.getElementById('lib-q')"), r0[:4])
        open_node(c, ".rb-lib", "s:errors")
        k1 = tree_kids(c, ".rb-lib", "s:errors") or []
        check("opening a section shows only the next level down: its kinds of recording, closed, and no level or item",
              [x["name"] for x in k1][:2] == ["NVMe errors", "Errors in other CSV files (any tool)"] and all(x["node"].startswith("k:errors/") and not x["open"] for x in k1)
              and {x["node"] for x in tree_rows(c, ".rb-lib")} == {x["node"] for x in r0} | {x["node"] for x in k1}
              and (c.js("document.querySelectorAll('.rb-lib .rb-item').length") or 0) == 0, k1)
        open_node(c, ".rb-lib", "k:errors/lecroy_nvme_pcie")
        k2 = tree_kids(c, ".rb-lib", "k:errors/lecroy_nvme_pcie") or []
        check("the kind 'NVMe errors' opens to its five levels, in the order of the analyzer's five files, each closed, and no item yet",
              [(x["node"], x["name"], x["open"]) for x in k2] == [("l:errors/" + i, n, False) for i, n in zip(FIVE_IDS, FIVE_LEVELS["errors"])]
              and (c.js("document.querySelectorAll('.rb-lib .rb-item').length") or 0) == 0, k2)
        for n in ("s:analytics", "k:analytics/lecroy_nvme_pcie", "l:analytics/nvme_command"):
            open_node(c, ".rb-lib", n)
        n1 = c.js("document.querySelectorAll('.rb-lib .rb-item[data-sec=analytics][data-lvl=nvme_command]').length") or 0
        open_node(c, ".rb-lib", "l:errors/nvme_command")
        n2 = c.js("document.querySelectorAll('.rb-lib .rb-item[data-sec=errors][data-lvl=nvme_command]').length") or 0
        g2 = tree_kids(c, ".rb-lib", "l:errors/nvme_command") or []
        check("a level of Data analytics lists the analytics items, the same level of Errors the detector's errors, with its groups as closed rows",
              n1 >= 2 and n2 >= 2 and len(g2) >= 1 and all(x["node"].startswith("g:errors/nvme_command/") and not x["open"] for x in g2), (n1, n2, g2[:3]))
        c.js("[...document.querySelectorAll('.rb-lib .rb-item[data-sec=errors][data-lvl=nvme_command] .rb-open')].find(x => x.innerText.toLowerCase().includes('timeout')).click()")
        for _ in range(30):
            time.sleep(0.3)
            if c.js("!!document.querySelector('.rb-lib .rb-detail .rb-d')"):
                break
        t = txt().lower()
        check("one error shows its source data, its procedure, the detector's verified code and Edit rule/procedure",
              "timeout" in t and "source data" in t and "rules or procedure" in t and "verified code" in t and "edit rule/procedure" in t)
        c.js("document.getElementById('lib-q').value = 'read'; document.getElementById('lib-q').dispatchEvent(new Event('input', {bubbles: true}))")
        time.sleep(1.2)
        names = c.js("[...document.querySelectorAll('.rb-lib .rb-item .rb-nm')].map(x => x.innerText)") or []
        check("the search narrows the list across sections", names and all("read" in x.lower() for x in names), names[:3])
        c.js("document.getElementById('lib-q').value = ''; document.getElementById('lib-q').dispatchEvent(new Event('input', {bubbles: true}))")
        time.sleep(0.8)
        # ---- the hierarchy (2026-11-15): Section > Kind of recording > Level > items, a place to add at every layer, the place line, a reason under every field
        for n in ("k:analytics/other_csv", "k:errors/other_csv"):          # the kinds where a level is added
            open_node(c, ".rb-lib", n)
        side = c.js("[...document.querySelectorAll('.rb-lib .rh-tog .rh-name, .rb-lib .rh-add')].map(x => x.innerText.trim()).join('\\n')") or ""
        order =["Data analytics", "NVMe and PCIe recording (Teledyne LeCroy five-file export)", "NVMe command level", "PCIe packet level", "Other CSV files (any tool)",
                 "Errors", "NVMe errors", "NVMe command level errors", "NVMe transaction level errors", "Add a section"]
        at, in_order = -1, True
        for label in order:
            nxt = side.find(label, at + 1)
            in_order, at = in_order and nxt > at, max(nxt, at)
        check("the tree shows three layers in order: section, kind of recording, level, with 'Errors' and 'NVMe errors'", in_order and "Error roots" not in side, side[:300])
        check("a kind of recording and a level have their place to add (the hierarchy routes answer)",
              (c.js("document.querySelectorAll('.rb-lib [data-act=rh-form][data-what=kind]').length") or 0) >= 2
              and (c.js("document.querySelectorAll('.rb-lib [data-act=rh-form][data-what=level]').length") or 0) >= 2)
        # the item opened above stays open while other rows open; it is opened again only if it was closed
        c.js("(i => { if (i && !i.classList.contains('open')) i.querySelector('.rb-open').click(); })([...document.querySelectorAll('.rb-lib .rb-item[data-sec=errors][data-lvl=nvme_command]')]"
             ".find(x => x.querySelector('.rb-open').innerText.toLowerCase().includes('timeout')))")
        time.sleep(1.0)
        crumb = c.js("(document.querySelector('.rb-lib .rb-detail .rh-crumb') || {}).innerText") or ""
        check("an open item shows its place: section > kind of recording > level > item", crumb.replace("\n", " ").split(" › ")[:3] == ["Errors", "NVMe errors", "NVMe command level errors"], crumb)
        add_item = '.rb-lib .rh-add[data-what=item][data-sec=errors][data-lvl=nvme_command][data-gname=""]'
        check("'Add an item' sits inside its level and names it", "Add an item to NVMe command level errors" in (c.js("(document.querySelector(%s) || {}).innerText" % json.dumps(add_item)) or "")
              and c.js(PLACE % json.dumps(add_item)) == "l:errors/nvme_command", c.js(PLACE % json.dumps(add_item)))
        # every "Add ..." row opens its form in place (a click on the row; the form replaces the row), one form at a time; Cancel closes it.
        # A group of the level is opened first, for the row that adds an item to a group.
        grp = c.js("(document.querySelector('.rb-lib [data-act=rh-node][data-node^=\"g:errors/nvme_command/\"]') || {dataset: {}}).dataset.node") or ""
        open_node(c, ".rb-lib", grp)
        ids = {}
        for what, row, labels, place in (("a section", ".rb-lib .rh-add[data-what=section]", 3, "after the tree"),
                                         ("a kind of recording", ".rb-lib .rh-add[data-what=kind][data-sec=errors]", 2, "s:errors"),
                                         ("a level", ".rb-lib .rh-add[data-what=level][data-sec=errors][data-kind=other_csv]", 3, "k:errors/other_csv"),
                                         ("a group", ".rb-lib .rh-add[data-what=group][data-sec=errors][data-lvl=nvme_command]", 2, "l:errors/nvme_command"),
                                         # three fields here since 2026-11-15: this level lists its items in groups, so the form also asks the group
                                         ("an item", add_item, 3, "l:errors/nvme_command"),
                                         ("an item to a group", '.rb-lib .rh-add[data-what=item][data-sec=errors][data-lvl=nvme_command]:not([data-gname=""])', 2, grp)):
            c.js("document.querySelector(%s).click()" % json.dumps(row))
            time.sleep(0.4)
            got = c.js(REASONS % json.dumps(".rb-lib .rh-form label.f")) or []
            check("the form 'Add %s' says under every field why it is asked" % what, len(got) == labels and all(got), got)
            check("the form 'Add %s' arrives empty: nothing typed for the admin, nothing ticked" % what,
                  c.js("[...document.querySelectorAll('.rb-lib .rh-form input[type=text], .rb-lib .rh-form textarea')].every(x => !x.value) "
                       "&& !document.querySelector('.rb-lib .rh-form input:checked')"))
            at = c.js(PLACE % json.dumps(".rb-lib .rh-form"))
            check("the form 'Add %s' opens in place, where the new one will appear, and alone" % what,
                  at == place and (c.js("document.querySelectorAll('.rb-lib .rh-form').length") or 0) == 1 and not c.js("!!document.querySelector(%s)" % json.dumps(row)), at)
            for i in ("asnlib", "asalib", "ainlib", "aidlib"):
                ids[i] = ids.get(i) or c.js("!!document.getElementById('%s')" % i)
            c.js("document.querySelector('.rb-lib .rh-form [data-act=rh-cancel]').click()")
            time.sleep(0.3)
        n_fields = c.js("document.querySelectorAll('.rb-lib label.f').length") or 0
        n_why = c.js(("(%s).filter(Boolean).length" % REASONS) % json.dumps(".rb-lib label.f")) or 0
        check("every field left in the tree (the finder of a level with groups) says why it exists", n_fields >= 1 and n_why == n_fields, (n_why, n_fields))
        shown = c.js("document.querySelector('.rb-lib').innerText") or ""
        check("no stored key is shown on the screen", "errors/nvme_command" not in shown and "analytics/nvme_command" not in shown and "lecroy_nvme_pcie" not in shown)
        check("'Add a section' and 'Add an item' sit in the browser, with a name and the words", all(ids.get(i) for i in ("asnlib", "asalib", "ainlib", "aidlib")), ids)
        print("screenshot:", c.shot("agents_page"))
        check("no script error and no failed request", not c.errors, c.errors[:3])
    finally:
        c.close()
    print("%d checks, %d failed" % (R["pass"] + R["fail"], R["fail"]))
    sys.exit(1 if R["fail"] else 0)


if __name__ == "__main__":
    main()
