"""Hand-over of approved tests to a validation suite (statement S8, item B7; 2026-11-14): the package, its refusals, the README's own command
run on the simulated drive, the results read back, hostile result files, and the routes. Everything lives in temporary folders; the
application's own folders are never touched and no real drive is ever used (NVME_BACKEND=sim only).

    python3 -m pytest -q -p no:cacheprovider tests/test_handover.py
"""
import hashlib
import io
import json
import os
import shlex
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import types
import zipfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))

from nvme_hier import handover as HO      # noqa: E402
from nvme_hier import testplan as TP      # noqa: E402


# ---------------------------------------------------------------------------------------------- a throw-away application root
def _plan(upload, fid, version, slba):
    """A small plan the way the main flow builds it (nvme_hier/testplan.build_plan): a Write, then the Read that failed in the field."""
    finding = {"id": fid, "rule": "cmd.read_failure", "level": "nvme_command", "detail": {"SCT": 2, "SC": 0x81},
               "observed_outcome": "Read of 8 blocks at block %d ended with status type 2 code 81h (Unrecovered Read Error)" % slba}
    steps = [{"step": 1, "command": "Write", "opc": 0x01, "admin": False, "queue": 1, "parameters": {"nsid": 1, "slba": slba, "nlb": 7}, "gap_us": 10, "position": "above", "source_row": 11, "why": []},
             {"step": 2, "command": "Read", "opc": 0x02, "admin": False, "queue": 1, "parameters": {"nsid": 1, "slba": slba, "nlb": 7}, "gap_us": 10, "position": "fault", "source_row": 12, "why": []}]
    return TP.build_plan(finding, steps, "v1|dev:TEST DRIVE|err:cmd.read_failure", "Read fails with an unrecovered read error", upload, version, "Test drive", None,
                         30 * 10 ** 6, [], [], "Tester", "%s_f%d" % (upload, fid))


def _approve(path, who="Asha", two_sided=True, uid="up-test-1", fid=3):
    """The approval record exactly as app/api/isolate_api.py approve_testcase writes it."""
    with open(path, "rb") as fh:
        sha = hashlib.sha256(fh.read()).hexdigest()
    rec = {"approved_by": who, "at": time.time(), "sha256": sha, "status": "approved", "comment": "checked on the bench notes", "upload_id": uid, "finding": fid, "two_sided": two_sided}
    with open(path + ".approved.json", "w", encoding="utf-8") as fh:
        json.dump(rec, fh, indent=1)
    return rec


def _packet_test(root, test_id, vhash):
    d = os.path.join(root, "suite", test_id)
    os.makedirs(d)
    with open(os.path.join(d, "manifest.json"), "w", encoding="utf-8") as fh:
        json.dump({"test_id": test_id, "incident_id": "INC-0007", "card": "C-16", "pattern": "P04", "source_solution": vhash, "capture": {"tool": "analyzer export (113-column CSV)"},
                   "signature": {"detail": "completion timeout after a reset during a write burst"},
                   "closed_loop_at_generation": {"known_bad_hits": 2, "known_bad_n": 6, "fixed_hits": 0, "fixed_n": 3, "passed": True}}, fh)
    with open(os.path.join(d, "conftest.py"), "w", encoding="utf-8") as fh:
        fh.write('import os\nSTAGE2 = os.environ.get("STAGE2_DIR")\n')
    with open(os.path.join(d, "test_%s.py" % test_id.replace("-", "_")), "w", encoding="utf-8") as fh:
        fh.write('"""Closed-loop regression test of the earlier workflow (a stand-in for this check)."""\n\n\ndef test_nothing():\n    assert True\n')
    return d


@pytest.fixture(scope="module")
def world():
    """A temporary application root: suite/hier with two approved tests, one unapproved, one changed after approval; the earlier workflow's
    folder with one test of an approved procedure and one of a procedure that is not approved; an upload record with file names."""
    root = tempfile.mkdtemp(prefix="handover_%d_" % os.getpid())
    try:
        hier = os.path.join(root, "suite", "hier")
        os.makedirs(os.path.join(root, "uploads", "up-test-1"))
        with open(os.path.join(root, "uploads", "up-test-1", "meta.json"), "w", encoding="utf-8") as fh:
            json.dump({"upload_id": "up-test-1", "device": "Test drive", "files": {"nvme_command": "/somewhere/else/commands.csv", "packets": "C:\\captures\\packets.csv"}}, fh)
        plans, paths = {}, {}
        for name, fid, ver, slba in (("a", 3, 1, 1000), ("b", 4, 2, 5000), ("unapproved", 5, 1, 9000), ("changed", 6, 1, 13000)):
            plans[name] = _plan("up-test-1", fid, ver, slba)
            paths[name] = TP.write(plans[name], hier, "up-test-1_f%d_v%d.py" % (fid, ver))
        two = TP.two_sided(paths["a"], plans["a"])
        assert two["ok"], two
        recs = {"a": _approve(paths["a"], two_sided={"ok": two["ok"], "words": two["words"], "runs": two["runs"]}, fid=3),
                "b": _approve(paths["b"], who="Ravi", two_sided=True, fid=4), "changed": _approve(paths["changed"], fid=6)}
        with open(paths["changed"], "a", encoding="utf-8") as fh:
            fh.write("\n# one line added after the approval\n")
        os.makedirs(os.path.join(root, "db"))
        con = sqlite3.connect(os.path.join(root, "db", "knowledge.sqlite"))
        con.executescript("CREATE TABLE event (id INTEGER PRIMARY KEY, ts REAL, kind TEXT, actor TEXT, payload TEXT, undone INTEGER DEFAULT 0);"
                          "CREATE TABLE solution (vhash TEXT PRIMARY KEY, sig TEXT, cause TEXT, scenario TEXT, context_hash TEXT, producer TEXT, status TEXT, repro_lower95 REAL,"
                          " created_event INTEGER, approved_by TEXT, supersedes TEXT);")
        con.execute("INSERT INTO solution (vhash, status, approved_by) VALUES ('aaaa111122223333', 'admin-approved', 'second admin Meera')")
        con.execute("INSERT INTO solution (vhash, status, approved_by) VALUES ('bbbb111122223333', 'validated-by-execution', NULL)")
        con.execute("INSERT INTO event (ts, kind, actor, payload) VALUES (?, 'solution_approve', 'second admin Meera', ?)", (1793001471.0, json.dumps({"vhash": "aaaa111122223333"})))
        con.commit()
        con.close()
        _packet_test(root, "T-C-16-aaaa1111", "aaaa111122223333")
        _packet_test(root, "T-C-16-bbbb1111", "bbbb111122223333")
        yield types.SimpleNamespace(root=root, hier=hier, plans=plans, paths=paths, recs=recs, A="up-test-1_f3_v1.py", B="up-test-1_f4_v2.py", U="up-test-1_f5_v1.py", C="up-test-1_f6_v1.py")
    finally:
        shutil.rmtree(root, ignore_errors=True)


def _snapshot(folder):
    out = {}
    for d, _dirs, files in os.walk(folder):
        for f in files:
            if "__pycache__" in d:
                continue
            p = os.path.join(d, f)
            with open(p, "rb") as fh:
                out[os.path.relpath(p, folder)] = hashlib.sha256(fh.read()).hexdigest()
    return out


def _unzip(data, where):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert z.testzip() is None
        for n in z.namelist():
            assert not n.startswith("/") and ".." not in n, n
        z.extractall(where)
        return z.namelist()


# ---------------------------------------------------------------------------------------------- the listing
def test_the_list_shows_every_test_with_its_approval_state_and_chooses_nothing(world):
    r = HO.list_tests(world.root)
    by = {t["name"]: t for t in r["tests"]}
    assert set(by) == {world.A, world.B, world.U, world.C, "T-C-16-aaaa1111", "T-C-16-bbbb1111"}, sorted(by)
    assert by[world.A]["approval"]["state"] == "approved" and by[world.A]["approval"]["can_hand_over"] and by[world.A]["approval"]["approved_by"] == "Asha"
    assert by[world.U]["approval"]["state"] == "not approved" and not by[world.U]["approval"]["can_hand_over"] and "has not been approved" in by[world.U]["approval"]["why_not"]
    assert by[world.C]["approval"]["state"] == "changed after approval" and "changed after Asha approved it" in by[world.C]["approval"]["why_not"]
    assert by["T-C-16-aaaa1111"]["approval"]["state"] == "approved" and by["T-C-16-aaaa1111"]["approval"]["approved_by"] == "second admin Meera"
    assert "no fingerprint" in by["T-C-16-aaaa1111"]["approval"]["approval_kind"] and "cannot be detected" in by["T-C-16-aaaa1111"]["approval"]["caution"]
    assert by["T-C-16-bbbb1111"]["approval"]["state"] == "not approved" and "validated-by-execution" in by["T-C-16-bbbb1111"]["approval"]["why_not"]
    assert r["counts"] == {"tests": 6, "can_be_handed_over": 3}
    assert not any("selected" in t or "chosen" in t for t in r["tests"]) and "Nothing is chosen in advance" in r["note"]
    assert "f2t_nvme.py" not in by


# ---------------------------------------------------------------------------------------------- the package
def test_a_package_of_two_approved_tests_holds_the_files_unchanged_and_a_matching_manifest(world, tmp_path):
    before = _snapshot(os.path.join(world.root, "suite"))
    made = HO.build_package(world.root, [world.A, world.B], "Kiran")
    assert _snapshot(os.path.join(world.root, "suite")) == before, "building a package must not write into the test folder"
    names = _unzip(made["zip"], str(tmp_path))
    assert set(names) == {"README.txt", "manifest.json", "manifest.txt", "results_template.csv", "pytest.ini", "conftest.py",
                          "tests/" + world.A, "tests/" + world.B, "tests/f2t_nvme.py"}, names
    for n, src in ((world.A, world.paths["a"]), (world.B, world.paths["b"]), ("f2t_nvme.py", os.path.join(world.hier, "f2t_nvme.py"))):
        with open(os.path.join(str(tmp_path), "tests", n), "rb") as f1, open(src, "rb") as f2:
            assert f1.read() == f2.read(), n
    with open(os.path.join(str(tmp_path), "manifest.json"), encoding="utf-8") as fh:
        man = json.load(fh)
    assert man == json.loads(json.dumps(made["manifest"])) and man["built_by"] == "Kiran" and man["package"] == made["package_id"]
    a, b = man["tests"]
    assert (a["name"], b["name"]) == (world.A, world.B)
    with open(world.paths["a"], "rb") as fh:
        sha = hashlib.sha256(fh.read()).hexdigest()
    assert a["fingerprint_sha256"] == sha == world.recs["a"]["sha256"] and a["fingerprint_matches_the_approval"] is True
    assert a["approved_by"] == "Asha" and b["approved_by"] == "Ravi" and a["approved_at"].endswith("UTC") and a["approval_comment"] == "checked on the bench notes"
    assert "Unrecovered Read Error" in a["defect"] and "block 1000" in a["defect"] and a["scenario"] == "Read fails with an unrecovered read error"
    assert a["recording"]["upload"] == "up-test-1" and {f["file"] for f in a["recording"]["files"]} == {"commands.csv", "packets.csv"}
    assert "somewhere" not in json.dumps(a["recording"]) and "captures" not in json.dumps(a["recording"]), "file names only, never the folders"
    # what it needs: read from the file's own 'How to run' lines, not retyped here
    with open(world.paths["a"], encoding="utf-8") as fh:
        text = fh.read()
    how = text.split("How to run\n", 1)[1].split('"""', 1)[0]
    assert [x.strip() for x in how.strip().splitlines()] == a["needs_to_run"]["how_to_run"]
    env = {v["name"] for v in a["needs_to_run"]["environment_variables"]}
    assert {"NVME_NS", "NVME_ALLOW", "NVME_DESTRUCTIVE", "NVME_CONFIRM", "EXPECT", "NVME_MEASURE", "NVME_BACKEND"} <= env, env
    assert all(("%s=" % v["name"]) in text for v in a["needs_to_run"]["environment_variables"])
    assert a["run_history"]["only_simulated_drive"] is True and "Only ever run on a simulated drive" in a["run_history"]["words"]
    assert a["two_way_result_at_approval"]["recorded"] and a["two_way_result_at_approval"]["passed"] is True and "faulty drive, expecting 'fault': wanted pass, got pass" in a["two_way_result_at_approval"]["words"]
    assert b["two_way_result_at_approval"]["passed"] is True and "recorded at approval as passed" in b["two_way_result_at_approval"]["words"]
    assert a["replay_library"]["same_as_named"] is True and a["replay_library"]["fingerprint_sha256"].startswith(world.plans["a"]["library"])
    with open(os.path.join(str(tmp_path), "manifest.txt"), encoding="utf-8") as fh:
        txt = fh.read()
    for part in (world.A, world.B, "Approved by Asha", "Approved by Ravi", sha, "Only ever run on a simulated drive", "NVME_ALLOW", "Upload up-test-1"):
        assert part in txt, part
    with open(os.path.join(str(tmp_path), "README.txt"), encoding="utf-8") as fh:
        readme = fh.read()
    for part in ("NVME_NS=/dev/ng0n1 NVME_ALLOW=allow.txt NVME_DESTRUCTIVE=1 NVME_CONFIRM=ERASE-<serial> python3 -m pytest -q --junit-xml=result.xml tests",
                 "NVME_BACKEND=sim python3 -m pytest -q --junit-xml=result.xml tests", "allow-list", "erase confirmation", "set by a person", "SIMULATED drive", "Not decided yet"):
        assert part in readme, part
    with open(os.path.join(str(tmp_path), "results_template.csv"), encoding="utf-8", newline="") as fh:
        rows = fh.read().strip().split("\r\n")
    assert len(rows) == 3 and rows[1].startswith('"%s","tests/%s","tests.%s",""' % (world.A, world.A, world.A[:-3])) and rows[1].endswith(',""')
    assert [p["package_id"] for p in HO.packages(world.root)["packages"]][0] == made["package_id"]


def test_the_library_note_says_so_when_the_library_beside_the_test_is_a_later_one(world):
    d = HO.describe(world.root, world.A)
    assert d["library"]["same_as_named"] is True
    lines = HO.header_of("'''T\n\nHow to run\n    A_VAR=1 python3 x\n'''\nPLAN = {'library': 'deadbeefdeadbeef'}\n")
    assert HO.block_of(lines, "How to run") == ["A_VAR=1 python3 x"]
    assert HO.plan_of("PLAN = __import__('os').system('true')\n") == {}, "a test file is read as data, never run"


def test_a_test_changed_after_its_approval_is_refused(world):
    with pytest.raises(HO.HandoverError) as e:
        HO.build_package(world.root, [world.A, world.C], "Kiran")
    assert "was changed after Asha approved it" in str(e.value) and "approved again" in str(e.value) and "No package was built" in str(e.value)


def test_an_unapproved_test_is_refused(world):
    with pytest.raises(HO.HandoverError) as e:
        HO.build_package(world.root, [world.U], "Kiran")
    assert "has not been approved" in str(e.value)
    with pytest.raises(HO.HandoverError) as e:
        HO.build_package(world.root, ["T-C-16-bbbb1111"], "Kiran")
    assert "not 'admin-approved'" in str(e.value)


@pytest.mark.parametrize("selection", [None, [], "", "all", "*", ["all"], ["*"], {"all": True}, 7])
def test_nothing_selected_is_a_plain_refusal_never_all(world, selection):
    n = len(HO.packages(world.root)["packages"])
    with pytest.raises(HO.HandoverError) as e:
        HO.build_package(world.root, selection, "Kiran")
    assert any(x in str(e.value) for x in ("Nothing was selected", "must be a list of test names", "There is no test named")), str(e.value)
    assert len(HO.packages(world.root)["packages"]) == n


def test_who_builds_the_package_must_be_said(world):
    for who in (None, "", "   ", 5, ["x"]):
        with pytest.raises(HO.HandoverError, match="Say who you are"):
            HO.build_package(world.root, [world.A], who)


def test_a_path_a_dotdot_a_nul_and_a_link_out_of_the_folder_are_refused(world, tmp_path):
    bad = [world.paths["a"], "hier/" + world.A, "..\\" + world.A, "../hier/" + world.A, "..", "a..py", world.A + "\x00", "\x00", "C:" + world.A, "f2t_nvme.py", "conftest.py",
           world.A + ".approved.json", "", "x" * 300, 5, None, ["x"], {"name": world.A}]
    for b in bad:
        with pytest.raises(HO.HandoverError) as e:
            HO.build_package(world.root, [b], "Kiran")
        assert str(e.value) and "Traceback" not in str(e.value), b
    # a link in the test folder that points out of it, with an approval record that matches the file it points to
    outside = tmp_path / "outside_f9_v1.py"
    shutil.copyfile(world.paths["a"], str(outside))
    link = os.path.join(world.hier, "up-test-1_f9_v1.py")
    try:
        os.symlink(str(outside), link)
    except (OSError, NotImplementedError, AttributeError):
        pytest.skip("this system does not let the test make a link")
    try:
        _approve(link, fid=9)
        with pytest.raises(HO.HandoverError, match="is a link to another place"):
            HO.build_package(world.root, ["up-test-1_f9_v1.py"], "Kiran")
        assert "up-test-1_f9_v1.py" in [p["name"] for p in HO.list_tests(world.root)["not_listed"]]
        folder = tmp_path / "T-C-16-cccc1111"
        shutil.copytree(os.path.join(world.root, "suite", "T-C-16-aaaa1111"), str(folder))
        os.symlink(str(folder), os.path.join(world.root, "suite", "T-C-16-cccc1111"))
        with pytest.raises(HO.HandoverError, match="is a link to another place"):
            HO.build_package(world.root, ["T-C-16-cccc1111"], "Kiran")
    finally:
        for p in (link, link + ".approved.json", os.path.join(world.root, "suite", "T-C-16-cccc1111")):
            if os.path.lexists(p):
                os.remove(p)


def test_a_test_of_the_earlier_workflow_goes_in_with_what_its_approval_really_is(world, tmp_path):
    made = HO.build_package(world.root, ["T-C-16-aaaa1111", world.A], "Kiran")
    names = _unzip(made["zip"], str(tmp_path))
    assert {"packet_workflow/T-C-16-aaaa1111/test_T_C_16_aaaa1111.py", "packet_workflow/T-C-16-aaaa1111/manifest.json", "packet_workflow/T-C-16-aaaa1111/conftest.py"} <= set(names)
    e = made["manifest"]["tests"][0]
    assert e["workflow"] == "earlier packet workflow" and e["approved_by"] == "second admin Meera" and e["approved_at"] == "2026-10-26 07:57:51 UTC"
    assert e["fingerprint_matches_the_approval"] is None and "cannot be detected" in e["approval_caution"] and "procedure" in e["approval_is"]
    assert e["defect"] == "completion timeout after a reset during a write burst" and "INC-0007" in e["recording"]["words"]
    assert [v["name"] for v in e["needs_to_run"]["environment_variables"]] == ["STAGE2_DIR"]
    assert "in 2 of 6 runs with the faulty firmware and in 0 of 3 runs with the fixed firmware" in e["two_way_result_at_approval"]["words"] and e["run_history"]["only_simulated_drive"] is True
    with open(os.path.join(str(tmp_path), "README.txt"), encoding="utf-8") as fh:
        readme = fh.read()
    assert "STAGE2_DIR=<the application's stage2 folder> python3 -m pytest -q --junit-xml=result_packet.xml packet_workflow" in readme and "not self-contained" in readme


# ---------------------------------------------------------------------------------------------- the README's own command, then the results back
def _readme_command(readme, start):
    line = next(x.strip() for x in readme.splitlines() if x.strip().startswith(start))
    words = shlex.split(line)
    env = dict(w.split("=", 1) for w in words if "=" in w and not w.startswith("-"))
    args = [w for w in words if w not in ["%s=%s" % kv for kv in env.items()]]
    assert args[0] == "python3"
    return env, [sys.executable] + args[1:]


def _run(folder, env, args, **more):
    e = {k: v for k, v in os.environ.items() if not k.startswith("NVME_") and k != "EXPECT"}
    e.update(env, PYTHONDONTWRITEBYTECODE="1", **more)
    assert e.get("NVME_BACKEND") in ("sim", None) and "NVME_NS" not in e, "these tests never run on a real drive: the simulated drive, or no drive named at all"
    p = subprocess.run(args + ["-p", "no:cacheprovider"], capture_output=True, text=True, timeout=300, cwd=folder, env=e)
    return p.returncode, p.stdout + p.stderr


def test_the_readme_command_runs_on_the_simulated_drive_and_the_results_come_back(world, tmp_path):
    made = HO.build_package(world.root, [world.A, world.B], "Kiran")
    folder = str(tmp_path / "unpacked")
    _unzip(made["zip"], folder)
    with open(os.path.join(folder, "README.txt"), encoding="utf-8") as fh:
        readme = fh.read()
    env, args = _readme_command(readme, "NVME_BACKEND=sim python3 -m pytest")
    assert env == {"NVME_BACKEND": "sim"} and args[1:] == ["-m", "pytest", "-q", "--junit-xml=result.xml", "tests"]

    # 1. exactly as the README says: a correct simulated drive, so the recorded fault does not appear and both tests report 'failed'
    rc, out = _run(folder, env, args)
    assert os.path.exists(os.path.join(folder, "result.xml")), out
    assert rc == 1 and "2 failed" in out, out
    with open(os.path.join(folder, "result.xml"), "rb") as fh:
        xml1 = fh.read()
    assert made["package_id"].encode() in xml1
    r = HO.read_results(world.root, xml1, "Divya")
    assert r["counts"] == {"passed": 0, "failed": 2, "skipped": 0} and r["packages"] == [made["package_id"]], r
    assert {x["test"] for x in r["recorded"]} == {world.A, world.B} and all(x["drive_kind"] == "simulated" and x["brought_in_by"] == "Divya" and x["reason"] for x in r["recorded"])

    # 2. the same command with a simulated drive that has test A's fault: A passes, B still fails
    cfg = str(tmp_path / "sim.json")
    with open(cfg, "w", encoding="utf-8") as fh:
        json.dump({"lba_bytes": 512, "nsze": 1 << 20, "drb": 1, "thinp": True, "dae": True, "nsid": 1, "faults": [TP.sim_fault(world.plans["a"])]}, fh)
    rc, out = _run(folder, env, args, NVME_SIM=cfg, NVME_REPEAT="2")
    assert rc == 1 and "1 failed, 1 passed" in out, out
    with open(os.path.join(folder, "result.xml"), "rb") as fh:
        xml2 = fh.read()
    r = HO.read_results(world.root, xml2, "Divya")
    got = {x["test"]: x for x in r["recorded"]}
    assert got[world.A]["outcome"] == "passed" and got[world.A]["reason"] == "" and got[world.B]["outcome"] == "failed" and got[world.A]["expect"] == "fault", got

    # 3. no drive given at all: both are skipped with the reason (a skip is never a pass)
    rc, out = _run(folder, {}, args)
    assert rc == 0 and "2 skipped" in out, out
    with open(os.path.join(folder, "result.xml"), "rb") as fh:
        xml3 = fh.read()
    r = HO.read_results(world.root, xml3, "Divya")
    assert r["counts"] == {"passed": 0, "failed": 0, "skipped": 2} and all("no drive given" in x["reason"] for x in r["recorded"]), r

    # what came back, newest first (only this package's results are looked at: the tests of this file run in any order and share the folder)
    back = {t["test"]: [x for x in t["results"] if x["package_id"] == made["package_id"]] for t in HO.results(world.root)["tests"]}
    assert [x["outcome"] for x in back[world.A]] == ["skipped", "passed", "failed"], back[world.A]
    assert back[world.A][0]["brought_in_at"].endswith("UTC") and back[world.A][0]["run_at"] and back[world.A][0]["brought_in_by"] == "Divya"
    assert [x["outcome"] for x in HO.results(world.root, world.B)["tests"][0]["results"] if x["package_id"] == made["package_id"]] == ["skipped", "failed", "failed"]
    # still only simulated: the listing says so from the records
    assert HO.describe(world.root, world.A)["run_history"]["only_simulated_drive"] is True
    # the same file twice is not recorded twice
    with pytest.raises(HO.HandoverError, match="already brought in"):
        HO.read_results(world.root, xml3, "Divya")
    # the tests in the package are still the approved files
    with open(os.path.join(folder, "tests", world.A), "rb") as fh:
        assert hashlib.sha256(fh.read()).hexdigest() == world.recs["a"]["sha256"]


def _junit(cases, package=None, stamp="2026-11-14T10:00:00"):
    props = ('<properties><property name="handover_package" value="%s"/></properties>' % package) if package else ""
    return ('<?xml version="1.0" encoding="utf-8"?><testsuites><testsuite name="pytest" tests="%d" timestamp="%s">%s%s</testsuite></testsuites>' % (
        len(cases), stamp, props, "".join('<testcase classname="%s" name="%s" time="0.1">%s</testcase>' % c for c in cases))).encode("utf-8")


def test_a_real_drive_result_changes_what_the_listing_says(world):
    made = HO.build_package(world.root, [world.B], "Kiran")
    xml = ('<?xml version="1.0" encoding="utf-8"?><testsuite name="suite of the team" timestamp="2026-11-15T09:00:00"><properties>'
           '<property name="test_id" value="up-test-1_f4"/><property name="test_version" value="2"/><property name="backend" value="real"/>'
           '<property name="drive_model" value="Model X"/><property name="expect" value="fixed"/></properties>'
           '<testcase classname="regression.imported.%s" name="test_defect_reproduces_or_stays_fixed"/></testsuite>' % world.B[:-3]).encode("utf-8")
    r = HO.read_results(world.root, xml, "Divya")          # no package number in the file and another folder: found by the test's name
    assert r["recorded"][0]["test"] == world.B and r["recorded"][0]["drive_kind"] == "real" and r["recorded"][0]["package_id"] == made["package_id"]
    h = HO.describe(world.root, world.B)["run_history"]
    assert h["only_simulated_drive"] is False and "A result from a real drive was brought into this application" in h["words"]
    assert HO.describe(world.root, world.A)["run_history"]["only_simulated_drive"] is True


def test_results_that_do_not_belong_are_refused(world):
    made = HO.build_package(world.root, [world.A], "Kiran")
    n = sum(t["count"] for t in HO.results(world.root)["tests"])
    stem = world.A[:-3]
    cases = [
        (_junit([("tests.some_other_test", "test_x", "")]), "in no package|not in any package"),
        (_junit([("tests." + stem, "test_x", ""), ("tests.unknown", "test_y", "")], made["package_id"]), "Nothing was recorded"),
        (_junit([("tests." + world.B[:-3], "test_x", "")], made["package_id"]), "not in the package"),
        (_junit([("tests." + stem, "test_x", "")], "handover-19990101-000000-ffffff"), "did not build"),
        (_junit([]), "holds no test case"),
        (b"", "is empty"),
        (b"PK\x03\x04 this is a zip, not XML", "cannot be read as XML"),
        (b'{"tests": 2}', "cannot be read as XML"),
        (b"<html><body>hello</body></html>", "not a JUnit result file"),
        (b"<testsuite><testcase classname='tests.%s' name='t'>" % stem.encode(), "cannot be read as XML"),
        (b"<a>" * 100 + b"</a>" * 100, "not a JUnit result file"),
        (b"<testsuite>" + b"<x>" * 200 + b"</x>" * 200 + b"</testsuite>", "nested too deeply"),
    ]
    for data, want in cases:
        with pytest.raises(HO.HandoverError) as e:
            HO.read_results(world.root, data, "Divya")
        import re
        assert re.search(want, str(e.value)), (want, str(e.value))
    with pytest.raises(HO.HandoverError, match="Say who you are"):
        HO.read_results(world.root, _junit([("tests." + stem, "test_x", "")], made["package_id"]), "")
    assert sum(t["count"] for t in HO.results(world.root)["tests"]) == n, "a refused file records nothing"


def test_a_hostile_result_file_is_refused(world, tmp_path):
    made = HO.build_package(world.root, [world.A], "Kiran")
    stem = world.A[:-3]
    case = '<testsuite><testcase classname="tests.%s" name="t"><failure message="&lol9;">x</failure></testcase></testsuite>' % stem
    bomb = '<?xml version="1.0"?><!DOCTYPE lolz [<!ENTITY lol "lol">' + "".join(
        '<!ENTITY lol%d "%s">' % (i, ("&lol%s;" % ("" if i == 1 else i - 1)) * 10) for i in range(1, 10)) + "]>" + case
    secret = tmp_path / "secret.txt"
    secret.write_text("TOP-SECRET-LINE", encoding="utf-8")
    external = '<?xml version="1.0"?><!DOCTYPE t [<!ENTITY lol9 SYSTEM "%s">]>%s' % (secret.as_uri(), case)
    parameter = '<?xml version="1.0"?><!DOCTYPE t [<!ENTITY %% p SYSTEM "%s"> %%p;]>%s' % (secret.as_uri(), case.replace("&lol9;", "m"))
    plain_doctype = '<?xml version="1.0"?><!DOCTYPE testsuite>' + case.replace("&lol9;", "m")
    n = sum(t["count"] for t in HO.results(world.root)["tests"])
    t0 = time.time()
    for text in (bomb, external, parameter, plain_doctype):
        for data in (text.encode("utf-8"), text.replace('<?xml version="1.0"?>', '<?xml version="1.0" encoding="utf-16"?>').encode("utf-16")):
            with pytest.raises(HO.HandoverError) as e:
                HO.read_results(world.root, data, "Divya")
            assert "declares a document type or an entity" in str(e.value) and "TOP-SECRET" not in str(e.value), str(e.value)
    with pytest.raises(HO.HandoverError, match="larger than 5 megabytes"):
        HO.read_results(world.root, _junit([("tests." + stem, "t", "")], made["package_id"]) + b" " * (50 * 1024 * 1024), "Divya")
    many = _junit([("tests." + stem, "t%d" % i, "") for i in range(1)], made["package_id"]).replace(b"</testsuite>", b"<a/>" * 250000 + b"</testsuite>")
    with pytest.raises(HO.HandoverError, match="too many entries"):
        HO.read_results(world.root, many, "Divya")
    assert time.time() - t0 < 20, "a hostile file must be refused quickly"
    assert sum(t["count"] for t in HO.results(world.root)["tests"]) == n
    assert "TOP-SECRET" not in json.dumps(HO.results(world.root))


# ---------------------------------------------------------------------------------------------- the routes
@pytest.fixture(scope="module")
def client(world):
    from flask import Flask
    from api import handover_api
    app = Flask("handover_test")
    app.config["services"] = types.SimpleNamespace(root=world.root)
    app.config["PROPAGATE_EXCEPTIONS"] = False
    app.register_blueprint(handover_api.bp)          # the coordinator registers it in app/server.py; here on a throw-away application
    return app.test_client()


def test_the_routes_list_build_take_results_and_show_them(world, client):
    r = client.get("/api/handover/tests")
    assert r.status_code == 200 and r.get_json()["counts"]["tests"] == 6
    z = client.post("/api/handover/package", json={"tests": [world.A, world.B], "name": "Kiran"})
    assert z.status_code == 200 and z.mimetype == "application/zip" and z.headers["X-Handover-Package"].startswith("handover-")
    assert ("%s.zip" % z.headers["X-Handover-Package"]) in z.headers["Content-Disposition"] and hashlib.sha256(z.data).hexdigest() == z.headers["X-Handover-Sha256"]
    with zipfile.ZipFile(io.BytesIO(z.data)) as zf:
        assert "tests/" + world.A in zf.namelist() and json.loads(zf.read("manifest.json"))["package"] == z.headers["X-Handover-Package"]
    assert client.get("/api/handover/packages").get_json()["packages"][0]["package_id"] == z.headers["X-Handover-Package"]
    xml = _junit([("tests." + world.A[:-3], "test_defect_reproduces_or_stays_fixed", '<skipped message="no drive given">x</skipped>'),
                  ("tests." + world.B[:-3], "test_defect_reproduces_or_stays_fixed", '<failure message="the fault did not appear">long text</failure>')], z.headers["X-Handover-Package"], "2026-11-14T11:11:11")
    r = client.post("/api/handover/results", data={"file": (io.BytesIO(xml), "result.xml"), "name": "Divya"}, content_type="multipart/form-data")
    assert r.status_code == 200 and r.get_json()["counts"] == {"passed": 0, "failed": 1, "skipped": 1}, r.get_json()
    r = client.post("/api/handover/results?name=Divya", data=xml.replace(b"11:11:11", b"12:12:12"), content_type="application/xml")
    assert r.status_code == 200, r.get_json()
    got = client.get("/api/handover/results?test=" + world.A).get_json()["tests"]
    assert len(got) == 1 and got[0]["latest"]["outcome"] == "skipped" and got[0]["latest"]["reason"] == "no drive given" and got[0]["latest"]["brought_in_by"] == "Divya"
    assert got[0]["latest"]["run_at"] == "2026-11-14T12:12:12"
    assert any(t["test"] == world.B for t in client.get("/api/handover/results").get_json()["tests"])


def test_every_route_answers_400_with_a_plain_sentence_on_wrong_input(world, client):
    def refused(r):
        assert r.status_code == 400, (r.status_code, r.data[:200])
        j = r.get_json()
        assert isinstance(j, dict) and isinstance(j.get("error"), str) and len(j["error"]) > 20 and "Traceback" not in j["error"], j
        return j["error"]

    P = "/api/handover/package"
    refused(client.post(P))
    refused(client.post(P, data="not json", content_type="application/json"))
    refused(client.post(P, data=b"\xff\xfe\x00", content_type="application/octet-stream"))
    for body in ([], [world.A], "all", 5, None, True):
        refused(client.post(P, json=body))
    for tests in (None, [], "all", "*", ["all"], [None], [5], [[world.A]], [{"a": 1}], ["../hier/" + world.A], [world.paths["a"]], [world.A + "\x00"], ["..", world.A], {"x": 1}, 10 ** 30,
                  [world.U], [world.C], ["T-C-16-bbbb1111"], ["nothing_like_this.py"], [world.A] * 501 + ["x.py"] * 600):
        refused(client.post(P, json={"tests": tests, "name": "Kiran"}))
    assert "Nothing was selected" in refused(client.post(P, json={"tests": [], "name": "Kiran"}))
    assert "was changed after" in refused(client.post(P, json={"tests": [world.C], "name": "Kiran"}))
    for name in (None, "", "  ", 5, ["Kiran"], {"n": 1}, "x" * 500, "a\x00b"):
        refused(client.post(P, json={"tests": [world.A], "name": name}))

    R = "/api/handover/results"
    ok = _junit([("tests." + world.A[:-3], "t", "")])
    refused(client.post(R))
    refused(client.post(R + "?name=Divya"))
    refused(client.post(R, data=ok, content_type="application/xml"))                                  # nobody named
    refused(client.post(R + "?name=Divya", data=b"\x00\x01\x02garbage", content_type="application/xml"))
    refused(client.post(R + "?name=Divya", data=b'{"a": 1}', content_type="application/json"))
    refused(client.post(R + "?name=Divya", data=_junit([("tests.unknown_test", "t", "")]), content_type="application/xml"))
    refused(client.post(R, data={"name": "Divya"}, content_type="multipart/form-data"))               # no file
    refused(client.post(R, data={"file": (io.BytesIO(b"<html/>"), "x.xml"), "name": "Divya"}, content_type="multipart/form-data"))
    refused(client.post(R, data={"file": (io.BytesIO(ok), "x.xml")}, content_type="multipart/form-data"))
    bomb = b'<?xml version="1.0"?><!DOCTYPE l [<!ENTITY a "aaaaaaaaaa"><!ENTITY b "&a;&a;&a;&a;&a;&a;&a;&a;&a;&a;">]><testsuite><testcase classname="x" name="&b;"/></testsuite>'
    assert "document type or an entity" in refused(client.post(R + "?name=Divya", data=bomb, content_type="application/xml"))
    big = b"<testsuite>" + b" " * (50 * 1024 * 1024) + b"</testsuite>"
    assert "larger than 5 megabytes" in refused(client.post(R + "?name=Divya", data=big, content_type="application/xml"))
    assert "larger than 5 megabytes" in refused(client.post(R, data={"file": (io.BytesIO(big), "x.xml"), "name": "Divya"}, content_type="multipart/form-data"))
    for t in ("../x", "a/b.py", "..", "x" * 300, "no such thing"):
        refused(client.get(R + "?test=" + t))
    assert client.get(R + "?test=" + world.U).status_code == 200                                      # a real test with no result yet: an empty answer, not an error
    for path in ("/api/handover/tests", "/api/handover/packages", R):
        assert client.get(path).status_code == 200
