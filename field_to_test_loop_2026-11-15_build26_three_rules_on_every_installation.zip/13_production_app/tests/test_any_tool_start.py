"""The start page for a recording of ANY tool (owner, 2026-11-14: "whichever the file format it is, I don't know what are the
columns ... that's why there is no deterministic code present; that's why there are research agents and coding agents").

1. "Another tool, or I do not know": a folder of one CSV with disguised column names starts through the start route, reaches
   Family 1 with the stand-in (no model), and the fixed joining strategy is never tried: not offered, refused when asked for,
   Family 2 skipped. The same answer on the application's own five-file sample: the fixed strategy is not offered either,
   with the reason in plain words; with Teledyne LeCroy chosen it is offered as before.
2. Teledyne LeCroy chosen for a file that does not look like its export: the start route says so per file and stores
   nothing, until the admin says it once more; the five-file sample is taken at once.
3. The page script (changed 2026-11-15): the question is gone, nothing is chosen in advance, the why-lines are there, and
   the two scripts have no name declared twice.
No server and no model: Flask's test client, a database, a knowledge folder and a runs folder of the test's own."""
import json
import os
import re
import shutil
import subprocess
import sys
import time
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
for p in (APP_DIR, os.path.join(APP_DIR, "app")):
    if p not in sys.path:
        sys.path.insert(0, p)
from agentic import admin_ask, core, pipeline, source_tools as ST   # noqa: E402

LECROY, LECROY_NAME = "teledyne_lecroy_pcie", "Teledyne LeCroy PCIe Protocol Analysis"
ANOTHER = "another_tool"
SAMPLE = os.path.join(APP_DIR, "samples", "clean_five_files", "S08_interrupt_before_completion")
NODE = "/home/raghavendra/.nvm/versions/node/v22.23.2/bin/node"
JS = os.path.join(APP_DIR, "app", "static", "js")
DISGUISED = ["Zeitstempel_ns", "Kanal", "Befehlsart", "Dauer_us", "Ergebnis", "Blockadresse"]


@pytest.fixture
def live(tmp_path, monkeypatch):
    """The start route on an engine that really runs the flow, with the stand-in in place of a model."""
    from flask import Flask
    from api import agentic_api as A
    from agentic import family1
    monkeypatch.setattr(family1, "knowledge_dir", lambda: str(tmp_path / "knowledge"))
    kick = getattr(sys.modules.get("fuzz_app"), "REAL_KICK", None)      # another test of the same session may have switched the engine off
    if kick is not None:
        monkeypatch.setattr(core.Engine, "kick", kick)
    store = core.Store(str(tmp_path / "db" / "agentic.sqlite"))
    runner = core.AgentRunner(str(tmp_path / "runs"), runtime="standin", web=False)
    eng = core.Engine(store, {"flow": pipeline}, runner, cfg={})
    monkeypatch.setattr(A, "engine", lambda: eng)
    app = Flask(__name__)
    app.config["services"] = types.SimpleNamespace(cfg={}, root=str(tmp_path))
    app.register_blueprint(A.bp)
    yield app.test_client(), eng, tmp_path
    for r in store.all("SELECT id FROM run WHERE state='running'"):
        try:
            eng.stop(r["id"], "Sagar", "the test is over")
        except Exception:               # noqa: BLE001
            pass


def disguised_folder(tmp_path, header=None, name="bench_log.csv"):
    folder = tmp_path / "recording"
    folder.mkdir(exist_ok=True)
    cols = header or DISGUISED
    with open(str(folder / name), "w", encoding="utf-8") as fh:
        fh.write(",".join(cols) + "\n")
        for i in range(200):
            fh.write(",".join(["%d" % (1000 + 37 * i), "%d" % (i % 4), ("Lesen", "Schreiben", "Leeren")[i % 3], "%d" % (90 + (i * 53) % 4000),
                               "ok" if i % 40 else "Zeitlimit", "%d" % (i * 8)] + ["%d" % (i % 7)] * (len(cols) - 6)) + "\n")
    return str(folder)


def new(c, folder, name="bench of the drive", **more):
    return c.post("/api/agents/projects", json=dict({"admin": "Sagar", "name": name, "folder": folder}, **more))


def next_review(eng, rid, limit=150):
    """The next open review of the flow -> (its step's key, the review); the test fails when a step fails or none comes."""
    t0 = time.time()
    while time.time() - t0 < limit:
        failed = eng.store.one("SELECT key, error FROM step WHERE run=? AND state='failed'", (rid,))
        assert not failed, "a step failed: %s\n%s" % (failed["key"], (failed["error"] or "")[:1500])
        rv = eng.store.one("SELECT * FROM review WHERE run=? AND state='open' ORDER BY id LIMIT 1", (rid,))
        if rv:
            return eng.store.one("SELECT key FROM step WHERE id=?", (rv["step"],))["key"], rv
        assert eng.store.one("SELECT state FROM run WHERE id=?", (rid,))["state"] == "running", "the flow ended before its next review"
        time.sleep(0.1)
    raise AssertionError("no review came in %d seconds" % limit)


def found_in(value, key):
    """Every value stored under `key` anywhere in a JSON value."""
    out = []
    if isinstance(value, dict):
        for k, v in value.items():
            if k == key:
                out.append(v)
            out += found_in(v, key)
    elif isinstance(value, list):
        for v in value:
            out += found_in(v, key)
    return out


# ---------------------------------------------------------------------------------------------- 1. another tool, or not known
def test_another_tool_reaches_family_1_and_the_fixed_joining_strategy_is_never_tried(live):
    c, eng, tmp_path = live
    folder = disguised_folder(tmp_path)
    assert ST.looks_like(LECROY, DISGUISED)["found"] == 0                        # the names are in no tool's list
    # nothing is compared for this answer: there is no column list to compare with
    assert c.get("/api/agents/source_tools", query_string={"folder": folder, "tool": ANOTHER}).get_json()["check"] is None
    r = new(c, folder, source_tool=ANOTHER)
    assert r.status_code == 200, r.get_json()
    p = r.get_json()
    assert p["source_tool"] == ANOTHER and p["source_tool_name"] == "another tool, or one that is not known" and p["tool_check"] is None
    r = c.post("/api/agents/projects/%d/flow" % p["id"], json={"admin": "Sagar"})
    assert r.status_code == 200, r.get_json()
    rid = eng.store.one("SELECT id FROM run WHERE project=?", (p["id"],))["id"]

    # Family 1: the three data agents read the file, and the Manager asks for the review of its dictionary
    key, rv = next_review(eng, rid)
    assert key == "manager:bench_log.csv", key
    steps = {s["key"]: s for s in eng.store.all("SELECT * FROM step WHERE run=?", (rid,))}
    assert all(steps["%s:bench_log.csv" % a]["state"] in ("done", "approved", "needs_review") for a in ("explore", "ground", "manager")), \
        [(k, s["state"]) for k, s in steps.items() if s["family"] == "1"]
    tools = [t for s in steps.values() if s["family"] == "1" for t in found_in(core.jload(s["output"], {}), "exported_by") if isinstance(t, dict)]
    assert tools and all(t.get("tool") is None and t.get("how") == "unknown" for t in tools), tools      # no tool's reference was used
    assert "was not recognised" in rv["body"] and LECROY_NAME not in rv["body"]
    eng.decide(rv["id"], "approve", "Sagar", "", None)

    # the step after Family 1: the fixed joining strategy is not offered, and asking for it is refused
    key, rv = next_review(eng, rid)
    assert key == admin_ask.GATE, key
    s2 = json.loads(rv["data"])["stage2"]
    assert s2["fixed_possible"] is False and s2["fixed_problem"]
    with pytest.raises(Exception) as refused:
        eng.decide(rv["id"], "approve", "Sagar", "", {"stage2": "fixed"})
    assert "the fixed joining strategy cannot build these files into a tree" in str(refused.value)
    assert eng.store.one("SELECT state FROM review WHERE id=?", (rv["id"],))["state"] == "open"
    eng.decide(rv["id"], "approve", "Sagar", "", {"stage2": "skip"})
    f2 = eng.store.all("SELECT key, state, note, started, attempts FROM step WHERE run=? AND family='2'", (rid,))
    assert f2 and all(s["state"] == "skipped" and s["note"] == admin_ask.F2_SKIP_NOTE and not s["started"] and not s["attempts"] for s in f2), f2

    # and the flow goes on to the rules, which are written on the files as they are
    key, rv = next_review(eng, rid)
    assert key == "f3_plan", key
    assert not eng.store.one("SELECT COUNT(*) AS n FROM step WHERE run=? AND family='2' AND state!='skipped'", (rid,))["n"]


def test_another_tool_on_the_five_file_sample_is_not_joined_and_says_why(live):
    c, eng, _tmp = live
    if not os.path.isdir(SAMPLE):
        pytest.skip("the five-file sample is not in this copy of the application")
    r = new(c, SAMPLE, source_tool=ANOTHER)
    assert r.status_code == 200, r.get_json()
    pid = r.get_json()["id"]
    project = eng.store.one("SELECT * FROM project WHERE id=?", (pid,))
    facts = admin_ask.stage2_facts(eng, {"id": 0}, project)
    assert facts["fixed_possible"] is False
    assert facts["fixed_problem"] == ST.no_hierarchy_reason(project) and "\"Another tool, or I do not know\"" in facts["fixed_problem"]
    assert "cannot build these files: not done for this analysis" in "\n".join(admin_ask.stage2_lines(facts))
    # the same files with Teledyne LeCroy chosen: looked at per file by the start route, taken at once, and joined as before
    r = new(c, SAMPLE, source_tool=LECROY)
    assert r.status_code == 200, r.get_json()
    again = r.get_json()
    assert again["reused"] is True and again["id"] == pid and again["source_tool"] == LECROY
    project = eng.store.one("SELECT * FROM project WHERE id=?", (pid,))
    assert admin_ask.stage2_facts(eng, {"id": 0}, project)["fixed_possible"] is True
    check = c.get("/api/agents/source_tools", query_string={"folder": SAMPLE, "tool": LECROY}).get_json()["check"]
    assert len(check["files"]) == 5 and check["doubt"] == [] and check["sentence"] == "" and all(f["looks"] is True for f in check["files"])
    r = new(c, SAMPLE, name="the sample, a second analysis", source_tool=LECROY)
    assert r.status_code == 200 and r.get_json()["tool_check"]["doubt"] == []


# ---------------------------------------------------------------------------------------------- 2. the wrong tool is seen at the start
def test_teledyne_lecroy_for_a_file_that_does_not_look_like_it_is_said_before_anything_is_stored(live):
    c, eng, tmp_path = live
    folder = disguised_folder(tmp_path)
    said = ("bench_log.csv does not look like an export of %s: none of its 6 column names is in that tool's column list. "
            "The agents will not read it as that tool's export." % LECROY_NAME)
    # before the start: the page asks for the folder and the answer the admin is about to give
    check = c.get("/api/agents/source_tools", query_string={"folder": folder, "tool": LECROY}).get_json()["check"]
    assert check["doubt"] == ["bench_log.csv"] and check["files"][0]["sentence"] == said and check["files"][0]["looks"] is False
    # the start itself
    for more in ({}, {"source_tool_confirmed": False}, {"source_tool_confirmed": "yes"}, {"source_tool_confirmed": 1}):
        r = new(c, folder, source_tool=LECROY, **more)
        assert r.status_code == 409, r.get_json()
        j = r.get_json()
        assert j["error"] == ("1 of the 1 CSV file in this folder does not look like an export of %s (bench_log.csv). If the recording "
                              "comes from another tool, choose \"Another tool, or I do not know\". If it does come from %s, tick the box "
                              "under the first question to start with it all the same." % (LECROY_NAME, LECROY_NAME))
        assert j["tool_check"]["files"][0]["sentence"] == said and LECROY not in j["error"]
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 0
    # the admin says once more that it is this tool: the analysis is made with it, and the answer shows what was said
    r = new(c, folder, source_tool=LECROY, source_tool_confirmed=True)
    assert r.status_code == 200, r.get_json()
    p = r.get_json()
    assert p["source_tool"] == LECROY and p["tool_check"]["doubt"] == ["bench_log.csv"]
    assert new(c, folder, source_tool=LECROY).get_json()["reused"] is True       # opened again with the stored answer: not asked again


def test_a_few_names_in_common_do_not_make_a_file_that_tools_export(live):
    c, eng, tmp_path = live
    with open(os.path.join(APP_DIR, "data", "lecroy_real_headers.json"), encoding="utf-8") as fh:
        real = list(sorted(json.load(fh)["files"].items())[0][1][0]["columns"].values())
    known = [n for n in dict.fromkeys(real) if "," not in n and "\"" not in n and ST.looks_like(LECROY, [n])["found"]][:3]
    assert len(known) == 3
    folder = disguised_folder(tmp_path, DISGUISED + ["Feld %02d" % i for i in range(14)] + known)
    r = new(c, folder, source_tool=LECROY)
    assert r.status_code == 409
    words = r.get_json()["tool_check"]["files"][0]["sentence"]
    assert words.startswith("bench_log.csv does not look like an export of %s: only 3 of its 23 column names are in that tool's column list" % LECROY_NAME)
    # (changed 2026-11-15) the sentence says what the agents then do: 3 names of 23 are below the two limits, so the file is not
    # read as that tool's export, whatever is ticked
    assert words.endswith("If you start with this answer all the same, the agents read this file as a file of an unknown tool: no meaning is "
                          "taken from that tool's reference document for it.")
    from agentic import family1
    got = family1.exported_by([{"column": n} for n in DISGUISED + ["Feld %02d" % i for i in range(14)] + known], LECROY)
    assert (got["tool"], got["how"], got["chosen_found"], got["names"]) == (None, "chosen, not matching", 3, 23)
    assert "only 3 of its 23 column names are in that tool's reference document" in family1.exported_sentence(got)
    # under "another tool" the same folder starts at once; opening it again with Teledyne LeCroy is said in the same way and changes nothing
    r = new(c, folder, source_tool=ANOTHER)
    assert r.status_code == 200 and r.get_json()["tool_check"] is None
    pid = r.get_json()["id"]
    assert new(c, folder, source_tool=LECROY).status_code == 409
    assert eng.store.one("SELECT source_tool FROM project WHERE id=?", (pid,))["source_tool"] == ANOTHER
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 1


def test_a_notes_only_tool_is_refused_with_the_sentence_that_points_to_another_tool(live):
    c, eng, tmp_path = live
    folder = disguised_folder(tmp_path)
    for key, name in (("windows_wpa", "Windows Performance Analyzer (Windows Assessment and Deployment Kit)"), ("pcmark10", "PCMark 10 (UL Benchmarks)")):
        r = new(c, folder, source_tool=key)
        assert r.status_code == 400
        assert r.get_json()["error"] == (
            "%s is not available yet: only the notes on its export are in the application. Until its column list is in the application, "
            "choose \"Another tool, or I do not know\" for its files. The answers that can be chosen: %s, \"Another tool, or I do not know\""
            % (name, LECROY_NAME))
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 0
    shown = {t["key"]: t for t in c.get("/api/agents/source_tools").get_json()["tools"]}
    assert all(shown[k]["available"] is False and "choose \"Another tool, or I do not know\" for its files" in shown[k]["sentence"] for k in ("windows_wpa", "pcmark10"))
    assert new(c, folder, source_tool=ANOTHER).status_code == 200               # and that answer works for such a file


@pytest.mark.parametrize("value", [7, ["another_tool"], "x" * 5000, "another_tool\x00", "Another_Tool", "ANOTHER_TOOL"])
def test_garbage_is_refused_by_the_start_route_and_by_the_check_before_it(live, value):
    c, eng, tmp_path = live
    folder = disguised_folder(tmp_path)
    r = new(c, folder, source_tool=value)
    assert r.status_code == 400
    err = r.get_json()["error"]
    assert ("must be given as text" in err or "is not a tool the application knows" in err) and "\x00" not in err and len(err) < 400
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 0
    if isinstance(value, str):                                                   # the question before the start compares nothing for it
        r = c.get("/api/agents/source_tools", query_string={"folder": folder, "tool": value})
        assert r.status_code == 200 and r.get_json()["check"] is None and len(r.get_json()["tools"]) == 3


def test_the_start_route_refuses_a_request_that_is_not_an_object(live):
    c, _eng, _tmp = live
    r = c.post("/api/agents/projects", json=["another_tool"])
    assert r.status_code == 400 and "must be one object" in r.get_json()["error"]


# ---------------------------------------------------------------------------------------------- 3. the page script
def script(name):
    with open(os.path.join(JS, name), encoding="utf-8") as fh:
        return fh.read()


def test_the_page_no_longer_asks_and_nothing_is_chosen_in_advance():
    # (changed 2026-11-15, owner: "are these things really needed? ... Otherwise it is no need") the question is gone from the
    # start page: the tool is recognised from the files. source_tool.js only shows the line kept with each analysis
    s = script("source_tool.js")
    for gone in ("st-q", "st-opt", "st-any", "radio", "/api/agents/source_tools", "Which tool exported", "window.api", "checked"):
        assert gone not in s, gone
    assert "recognised from the files: an export of" in s and "recognised from the files: no tool the application has a column list for" in s
    page = script("agents.js")
    assert "Which tool exported the recording you want to analyse?" not in page and "name=\"st-tool\"" not in page
    assert not re.search(r"<input[^>`]*\schecked[\s>]", s + page[page.index("<h2>New analysis</h2>"):page.index("<h2>Your analyses</h2>")])
    # what the server gives for the page: the plain texts
    a = ST.another()
    assert a["name"].startswith("Another tool, or I do not know") and "_" not in a["name"] + a["sentence"] + a["short"]


def test_the_why_lines_are_there():
    # every field label of the start form has a why-line of more than 40 characters directly under it
    page = script("agents.js")
    at = page.index("<h2>New analysis</h2>")
    page = page[at:page.index("</section>", at)]
    labels = re.findall(r"<label class=\"f\"", page)
    with_why = re.findall(r"<label class=\"f\"[^>]*>(?:(?!</label>).)*</label>\s*<div class=\"why\">((?:(?!</div>).)*)</div>", page, flags=re.S)
    assert len(labels) >= 3 and len(with_why) == len(labels), (len(with_why), len(labels))
    assert all(len(re.sub(r"<[^>]+>|\$\{[^}]*\}", "", w)) > 40 for w in with_why)
    assert "recognised from each file's own column names" in page
    assert "class=\"f\"" not in script("source_tool.js")                     # the line about the tool adds no field label


@pytest.mark.parametrize("name", ["source_tool.js", "agents.js"])
def test_the_script_has_no_name_declared_twice(tmp_path, name):
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    copy = str(tmp_path / (name[:-3] + ".mjs"))                                  # as a module: a name declared twice is an error
    shutil.copyfile(os.path.join(JS, name), copy)
    r = subprocess.run([NODE, "--check", copy], capture_output=True, text=True, timeout=120)
    assert r.returncode == 0, r.stderr[-1500:]
