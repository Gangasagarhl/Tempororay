"""The three NVMe command errors the owner kept (2026-11-15): NVMe command timeout, Read failed, and the command aborted because the
host asked. Two faults an independent check found on a recording with planted cases, kept fixed here:

  A. "never completed" was decided from an empty status cell in the command's row alone, although the tree held the command's
     completion entry: the timeout rule then listed a completed command as "never completed".
  B. a status written the way the NVMe specification writes hexadecimal values ("81h", "1Bh") was read as decimal (81 = 51h),
     so an Unrecovered Read Error (2h/81h) was named "an error status (2h/51h)".

And what a NEW installation (a knowledge folder of the test's own, seeded by the real seed()) offers under Errors > NVMe errors > NVMe
command level errors: exactly the three, the two detector items chosen by default and the rule family not; the other 37 rule families in
Deleted items with the owner's reason and the installation as who deleted them; a restart (seed again) changes nothing; an installation
of the earlier version (the families live) and one where the admin deleted them are left as they are; a restored family stays restored
and runs as before on S17. Nothing is written into the application's own folders.
"""
import json
import os
import shutil
import sqlite3
import sys

import pytest

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (APP, os.path.join(APP, "app")):
    if p not in sys.path:
        sys.path.insert(0, p)
os.environ.setdefault("F2T_WORKERS", "1")

from nvme_hier import builder as B, command_error_rules as CE, loader as L, parse as P, rules as RL, tree_api as T   # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}


def test_a_value_written_with_h_is_read_as_hexadecimal():
    assert [P.int_value(x) for x in ("81h", "1Bh", "07h", "0x81", "129", "81", " 7 ", "12 us")] == [129, 27, 7, 129, 129, 81, 7, 12]
    assert P.int_value("") is None and P.int_value(None) is None
    assert P.int_value("81h", hex_default=True) == 129


def _tree(tmp_path):
    if not os.path.isdir(S17):
        pytest.skip("the sample S17 is not on this machine")
    db = str(tmp_path / "hier.sqlite")
    L.load_upload(db, {k: os.path.join(S17, v) for k, v in NAMES.items() if os.path.exists(os.path.join(S17, v))})
    B.build(db)
    return db


def _findings(db, rule):
    con = sqlite3.connect(db)
    try:
        return {r: json.loads(d or "{}") for r, d in con.execute("SELECT rowid, detail FROM finding WHERE rule = ? ORDER BY rowid", (rule,))}
    finally:
        con.close()


def test_the_three_rules_on_s17_find_exactly_the_rows_an_independent_reading_finds(tmp_path):
    db = _tree(tmp_path)
    RL.apply(db)
    t = _findings(db, "cmd.timeout")
    assert {r: d.get("kind") for r, d in t.items()} == {144: "aborted by the host", 155: "never completed", 216: "never completed",
                                                         295: "never completed", 358: "never completed", 443: "never completed", 509: "never completed"}
    assert _findings(db, "cmd.read_failure") == {}
    tree = T.Tree(db)
    try:
        assert [x["row"] for x in CE.find("status_13", tree, {})] == [144]
    finally:
        tree.close()


def test_a_completed_command_with_an_empty_status_cell_is_not_never_completed(tmp_path):
    db = _tree(tmp_path)
    con = sqlite3.connect(db)
    # row 55 of S17 is a command the tree has a completion entry for; its status cells are emptied, as an export may leave them
    has_end = con.execute("SELECT COUNT(*) FROM ntx WHERE parent_level = 'nvme_command' AND parent = 55 AND type LIKE '%Completion Queue Entry%'").fetchone()[0]
    assert has_end >= 1
    con.execute("UPDATE cmd SET sct = NULL, sc = NULL WHERE rowid_file = 55")
    con.commit()
    con.close()
    RL.apply(db)
    t = _findings(db, "cmd.timeout")
    assert 55 not in t or t[55].get("kind") != "never completed", t.get(55)
    assert {155, 216, 295, 358, 443, 509} <= {r for r, d in t.items() if d.get("kind") == "never completed"}


def test_an_unrecovered_read_error_written_81h_keeps_its_meaning(tmp_path):
    if not os.path.isdir(S17):
        pytest.skip("the sample S17 is not on this machine")
    src = tmp_path / "s17"
    shutil.copytree(S17, src)
    path = src / "nvme_command.csv"
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    import csv
    import io
    rows = list(csv.reader(io.StringIO("".join(lines))))
    head = rows[0]
    sct_i = next(i for i, h in enumerate(head) if h in ("ST.SCT", "SCT"))
    sc_i = next(i for i, h in enumerate(head) if h in ("ST.SC", "SC"))
    opc_i = next(i for i, h in enumerate(head) if h == "OPC")
    sq_i = next(i for i, h in enumerate(head) if h == "SQID")
    # the first Read on an I/O queue that completed with success: its status becomes 2h/81h, written the specification's way
    k = next(i for i, r in enumerate(rows[1:], 1) if len(r) > max(sct_i, sc_i, opc_i, sq_i) and r[sq_i] not in ("", "0")
             and P.int_value(r[opc_i], hex_default=True) == 2 and r[sct_i] in ("0", "0h") and r[sc_i] in ("0", "0h", "00h"))
    rows[k][sct_i], rows[k][sc_i] = "2h", "81h"
    out = io.StringIO()
    csv.writer(out, lineterminator="\n").writerows(rows)
    path.write_text(out.getvalue(), encoding="utf-8")
    db = str(tmp_path / "hier.sqlite")
    L.load_upload(db, {kk: str(src / v) for kk, v in NAMES.items() if (src / v).exists()})
    B.build(db)
    con = sqlite3.connect(db)
    assert con.execute("SELECT sct, sc FROM cmd WHERE rowid_file = ?", (k,)).fetchone() == (2, 0x81)
    con.close()
    RL.apply(db)
    rf = _findings(db, "cmd.read_failure")
    assert k in rf and (rf[k].get("SCT"), rf[k].get("SC")) == (2, 0x81), rf


# ============================================================================================== what a new installation offers
from agentic import family1, family3, procedures as PR      # noqa: E402

KEPT_FAMILY = CE.item_id("status_13")
# the three the owner kept, by the names the screens show: (name, chosen by default)
THREE = {"cmd_timeout": ("NVMe command timeout", True), "cmd_read_failure": ("Read failed (the most common NVMe failure)", True),
         KEPT_FAMILY: ("The command was aborted because the host asked", False)}
WHY = ("The owner kept only the top 3 NVMe command errors (NVMe command timeout, Read failed, and The command was aborted because the host asked); "
       "Restore brings this rule back.")


@pytest.fixture()
def lib(tmp_path, monkeypatch):
    """A knowledge folder of the test's own, empty: what a new installation (the code zip unpacked with no knowledge folder) starts from."""
    know = str(tmp_path / "knowledge")
    os.makedirs(know)
    monkeypatch.setattr(family1, "knowledge_dir", lambda: know)
    monkeypatch.setattr(PR, "MODEL_CONNECTED", lambda: False)          # no model: a rule family runs the application's reference implementation
    family3._SECTIONS_SEEN[0] = None
    yield know
    family3._SECTIONS_SEEN[0] = None


def _level(tree=None):
    tree = tree if tree is not None else family3.tree()
    sec = next(s for s in tree if s["section"] == "errors")
    return {i["id"]: i for i in next(lv for lv in sec["levels"] if lv["level"] == "nvme_command")["items"]}


def _families_deleted():
    return {x["id"]: x for x in family3.deleted_items() if (x["section"], x["level"]) == ("errors", "nvme_command") and x["id"].startswith(CE.ITEM_PREFIX)}


def _snapshot(know):
    """Every file of the knowledge folder with its bytes: what a restart may not change."""
    out = {}
    for d, _dirs, files in os.walk(know):
        for f in files:
            p = os.path.join(d, f)
            with open(p, "rb") as fh:
                out[os.path.relpath(p, know)] = fh.read()
    return out


def test_the_37_other_families_are_what_the_application_can_run_but_the_owner_did_not_keep():
    ids = [it["id"] for it in CE.items()]
    assert len(CE.FAMILIES) == 52 and len(ids) == 38 and KEPT_FAMILY in ids          # the 52 families stay in the module as data, 38 can be run
    assert family3.KEPT_FAMILY_ITEMS == (KEPT_FAMILY,) and family3.TOP_THREE_DELETED_WHY == WHY
    assert family3.INSTALL_TOP_THREE_BY in family3.INSTALLATION_BY and family3.INSTALL_TOP_THREE_BY.startswith("at installation")
    assert {rid for sec, lvl, rid in family3.DEFAULT_CHOSEN if (sec, lvl) == ("errors", "nvme_command")} == {"cmd_timeout", "cmd_read_failure"}
    assert len(CE.families_for_page()["families"]) == 52                                   # the /nvme-rules page still lists all 52


def test_a_new_installation_offers_exactly_the_three_two_chosen_by_default(lib):
    level = _level()
    assert set(level) == set(THREE), sorted(level)
    for rid, (name, chosen) in THREE.items():
        assert (level[rid]["name"], level[rid]["default"]) == (name, chosen), (rid, level[rid])
        assert level[rid]["status"] == "draft"
    assert level[KEPT_FAMILY]["kind"] == CE.KIND and level[KEPT_FAMILY]["group"] == CE.BY_ID["status_13"]["group"]
    assert level[KEPT_FAMILY]["application"] == CE.THIS_FILE                       # it runs the application's own code, as every family does
    # the files of the level are the three, nothing more
    d = os.path.join(lib, "rules", "errors", "nvme_command")
    assert sorted(f for f in os.listdir(d) if f.endswith(".json")) == sorted("%s.json" % k for k in THREE)


def test_a_new_installation_starts_the_other_37_families_in_deleted_items_with_the_owners_reason(lib):
    family3.tree()
    gone = _families_deleted()
    want = {it["id"] for it in CE.items()} - {KEPT_FAMILY}
    assert len(want) == 37 and set(gone) == want, sorted(set(gone) ^ want)
    by_id = {it["id"]: it for it in CE.items()}
    for rid, e in gone.items():
        assert e["why"] == WHY and e["by"] == family3.INSTALL_TOP_THREE_BY and e["by"] in family3.INSTALLATION_BY, e
        assert (e["name"], e["kind"], e["detector"]) == (by_id[rid]["name"], CE.KIND, False), e
        assert os.path.exists(e["file"]) and e["file"].startswith(os.path.join(lib, "rules", "_deleted", "errors", "nvme_command") + os.sep)
        saved = json.load(open(e["file"], encoding="utf-8"))
        assert saved["plan"] == {"family": rid[len(CE.ITEM_PREFIX):]} and saved["status"] == "draft" and saved["version"] == 0, saved
        assert family3.load_rule("errors", "nvme_command", rid) is None
    # the other things a new installation starts without are where they were: the detector's other rules, and the near-limit item
    others = [x for x in family3.deleted_items() if not x["id"].startswith(CE.ITEM_PREFIX)]
    assert {x["by"] for x in others} == {family3.INSTALL_DELETED_BY, family3.INSTALL_ONE_FILE_BY}
    assert not [x for x in others if x["why"] == WHY]


def test_a_restart_seeds_again_and_changes_nothing(lib):
    family3.tree()
    before, reg = _snapshot(lib), family3._register()
    for _ in range(2):
        family3._SECTIONS_SEEN[0] = None
        family3.seed()
        level = _level()
    assert _snapshot(lib) == before and family3._register() == reg
    assert set(level) == set(THREE) and len(_families_deleted()) == 37


def test_an_installation_of_the_earlier_version_keeps_its_families_live(lib, monkeypatch):
    # the earlier seed wrote every family as a live item: made here by the real seed with every family kept
    monkeypatch.setattr(family3, "KEPT_FAMILY_ITEMS", tuple(it["id"] for it in CE.items()))
    level = _level()
    assert len([k for k in level if k.startswith(CE.ITEM_PREFIX)]) == 38 and _families_deleted() == {}
    monkeypatch.setattr(family3, "KEPT_FAMILY_ITEMS", (KEPT_FAMILY,))
    before, reg = _snapshot(lib), family3._register()
    family3._SECTIONS_SEEN[0] = None
    level = _level()                                  # the new code starts on that installation: nothing moves
    assert len([k for k in level if k.startswith(CE.ITEM_PREFIX)]) == 38 and _families_deleted() == {}
    assert _snapshot(lib) == before and family3._register() == reg


def test_the_families_the_admin_deleted_stay_deleted_with_the_admins_own_reason(lib, monkeypatch):
    # this machine's case: the earlier installation had the families live, the owner moved 37 to Deleted items with Delete
    monkeypatch.setattr(family3, "KEPT_FAMILY_ITEMS", tuple(it["id"] for it in CE.items()))
    family3.tree()
    monkeypatch.setattr(family3, "KEPT_FAMILY_ITEMS", (KEPT_FAMILY,))
    for it in CE.items():
        if it["id"] != KEPT_FAMILY:
            family3.delete_item("errors", "nvme_command", it["id"], "Sagar", "only the top three")
    before, reg = _snapshot(lib), family3._register()
    family3._SECTIONS_SEEN[0] = None
    level = _level()
    assert set(level) == set(THREE) and _snapshot(lib) == before and family3._register() == reg
    gone = _families_deleted()
    assert len(gone) == 37 and {(e["by"], e["why"]) for e in gone.values()} == {("Sagar", "only the top three")}
    # the family the owner kept, deleted too, stays deleted at the next start (a seed never brings back what the admin deleted)
    family3.delete_item("errors", "nvme_command", KEPT_FAMILY, "Sagar", "")
    family3._SECTIONS_SEEN[0] = None
    assert KEPT_FAMILY not in _level() and KEPT_FAMILY in _families_deleted()


def _run_item(rid, db, box):
    """The run step of the flow for a rule family without a model (agentic/family3.py _run): the application's own code text written where
    the code runner takes it, its verified state, then run on the tree in a process of its own -> the rows it found."""
    r = family3.load_rule("errors", "nvme_command", rid)
    assert PR.application_code(r)["file"] == CE.THIS_FILE
    PR.application_code_file(r)
    st = PR.code_state(r)
    assert st["verified"] is True and st["application"] == CE.THIS_FILE, st
    assert [s["file"] for s in PR.procedure_of(r)["source_data"]] == [PR.TREE]
    out = os.path.join(box, "%s.csv" % rid)
    res = PR.run_code(st["path"], {PR.TREE: db}, out, os.path.join(box, rid), application=True)
    assert res.get("ok") and res["summary"]["can_be_checked"] is True, res
    import csv
    with open(out, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    return [int(x[CE.ROW_COLUMN]) for x in rows]


def test_a_restored_family_stays_restored_and_runs_as_before(lib, tmp_path):
    family3.tree()
    never = CE.item_id("behaviour_01")
    assert never in _families_deleted() and never not in _level()
    got = family3.restore_item("errors", "nvme_command", never, "Sagar")              # the application's own restore path (the route calls it)
    assert got["name"] == "A command never completed" and got["kind"] == CE.KIND
    assert never not in _families_deleted() and len(_families_deleted()) == 36
    before = _snapshot(lib)
    for _ in range(2):                                 # restarts: the restored item stays restored, as it is
        family3._SECTIONS_SEEN[0] = None
        level = _level()
    assert never in level and level[never]["default"] is False and _snapshot(lib) == before
    assert never not in _families_deleted() and len(_families_deleted()) == 36
    # it runs as before on S17, and so does the family a new installation keeps
    db = _tree(tmp_path)
    RL.apply(db)                                       # the detector's rules, run when a recording is loaded ("never completed" reads them)
    box = str(tmp_path / "box")
    assert _run_item(never, db, box) == [155, 216, 295, 358, 443, 509]
    assert _run_item(KEPT_FAMILY, db, box) == [144]
    # a second one restored: the others stay where they are
    family3.restore_item("errors", "nvme_command", CE.item_id("status_01"), "Sagar")
    family3._SECTIONS_SEEN[0] = None
    assert set(_level()) == set(THREE) | {never, CE.item_id("status_01")} and len(_families_deleted()) == 35
