"""The start page without the question "Which tool exported the recording?" (owner, 2026-11-15: "are these things really
needed? ... if it is looking at the column names ... if that is going to help, then it's good ... Otherwise it is no need" and
"when it is loaded, let's say there are some ETL files or other unknown files in the folder, the status must say there is no
CSV ... why only fixing yourself to CSV?").

1. The tool is recognised from the files and stored: the five Teledyne LeCroy exports -> that tool, the fixed joining strategy
   is offered after Family 1 and the flow goes as before with the stand-in; one disguised CSV -> "another_tool", no tree.
2. Every file of the folder is listed by "Check": CSV tables with what was recognised, CSV files that are no table, other
   files grouped by their ending with count and size, subfolders as not read. Family 1 still reads only the CSV tables.
3. A folder without a CSV table: said plainly, and the start route refuses with the same sentence.
4. A request that still sends source_tool (older pages, other tests) works as before; an analysis made before keeps or
   upgrades its value; hostile folder values are refused in plain words.
5. The page script: the question is gone, the new lines and the terminal agent's button are there, why-lines, nothing
   pre-selected, no name declared twice.
No server and no model: Flask's test client on a database, knowledge folder and runs folder of the test's own."""
import json
import os
import re
import shutil
import subprocess
import sys

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
for p in (APP_DIR, os.path.join(APP_DIR, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)
from agentic import admin_ask, family1, source_tools as ST   # noqa: E402
from test_any_tool_start import DISGUISED, SAMPLE, disguised_folder, live, new, next_review   # noqa: E402,F401 - live is a fixture

LECROY, LECROY_NAME = "teledyne_lecroy_pcie", "Teledyne LeCroy PCIe Protocol Analysis"
ANOTHER = "another_tool"
NODE = "/home/raghavendra/.nvm/versions/node/v22.23.2/bin/node"
JS = os.path.join(APP_DIR, "app", "static", "js")
NO_TABLE = "No CSV table in this folder: the agent families read tables. This folder holds: "


def inv(c, folder):
    return c.get("/api/agents/inventory", query_string={"folder": folder})


def sized(path, n):
    """A file of n bytes; nothing in it is meant to be read."""
    with open(path, "wb") as fh:
        fh.write(b"\0" * n)


def need_sample():
    if not os.path.isdir(SAMPLE):
        pytest.skip("the five-file sample is not in this copy of the application")


# ---------------------------------------------------------------------------------------------- 1. recognised and stored
def test_the_five_lecroy_exports_are_recognised_stored_and_the_flow_goes_as_before(live):
    c, eng, _tmp = live
    need_sample()
    j = inv(c, SAMPLE).get_json()
    assert j["no_table"] is None and j["also"] is None and j["others"]["groups"] == [] and j["refused"] == []
    assert j["recognised"]["tool"] == LECROY
    assert j["recognised"]["sentence"] == ("Recognised from the files: an export of %s (5 of the 5 CSV tables match that tool's column list)."
                                           % LECROY_NAME)
    for f in j["files"]:
        assert re.fullmatch(r"%s looks like an export of %s: \d+ of its \d+ column names are in that tool's column list\."
                            % (re.escape(f["name"]), re.escape(LECROY_NAME)), f["recognised"]), f["recognised"]
    r = new(c, SAMPLE)                                                            # no tool sent: the page no longer asks
    assert r.status_code == 200, r.get_json()
    p = r.get_json()
    assert p["source_tool"] == LECROY and p["source_tool_name"] == LECROY_NAME and p["tool_check"] is None
    assert p["recognised"]["tool"] == LECROY
    project = eng.store.one("SELECT * FROM project WHERE id=?", (p["id"],))
    assert ST.needs_hierarchy(project) is True and ST.no_hierarchy_reason(project) == ""
    # the whole flow with the stand-in: Family 1 reads the five files, and after it the fixed joining strategy is offered
    r = c.post("/api/agents/projects/%d/flow" % p["id"], json={"admin": "Sagar"})
    assert r.status_code == 200, r.get_json()
    rid = eng.store.one("SELECT id FROM run WHERE project=?", (p["id"],))["id"]
    managers = 0
    while True:
        key, rv = next_review(eng, rid, limit=400)
        if key == admin_ask.GATE:
            break
        assert key.startswith("manager:"), key
        managers += 1
        eng.decide(rv["id"], "approve", "Sagar", "", None)
    assert managers == 5
    s2 = json.loads(rv["data"])["stage2"]
    assert s2["fixed_possible"] is True and not s2["fixed_problem"]


def test_a_disguised_csv_is_stored_as_another_tool_and_no_tree_is_offered(live):
    c, eng, tmp_path = live
    folder = disguised_folder(tmp_path)
    j = inv(c, folder).get_json()
    assert j["recognised"]["tool"] == ANOTHER and j["recognised"]["sentence"].startswith("Recognised from the files: no tool the application has a column list for")
    assert j["files"][0]["recognised"] == ("bench_log.csv is a CSV file of a tool the application has no column list for: the agents "
                                           "learn its columns from the file.")
    p = new(c, folder).get_json()
    assert p["source_tool"] == ANOTHER and p["source_tool_name"] == "another tool, or one that is not known"
    project = eng.store.one("SELECT * FROM project WHERE id=?", (p["id"],))
    assert ST.needs_hierarchy(project) is False
    assert admin_ask.stage2_facts(eng, {"id": 0}, project)["fixed_possible"] is False


# ---------------------------------------------------------------------------------------------- 2. every file of the folder
def test_csv_with_other_files_lists_every_group_and_family_1_reads_only_the_csv(live):
    c, eng, tmp_path = live
    folder = disguised_folder(tmp_path)
    for i in range(3):
        sized(os.path.join(folder, "trace_%d.etl" % i), 2_000_000)
    sized(os.path.join(folder, "Setup.XML"), 1500)
    sized(os.path.join(folder, "notes.txt"), 12)
    sized(os.path.join(folder, "LICENSE"), 3)
    os.mkdir(os.path.join(folder, "older captures"))
    sized(os.path.join(folder, "older captures", "inside.csv"), 10)
    j = inv(c, folder).get_json()
    lines = [g["line"] for g in j["others"]["groups"]]
    assert lines == ["3 files ending .etl, 6.0 MB", "1 file without an ending, 3 bytes", "1 file ending .txt, 12 bytes",
                     "1 file ending .xml, 1.5 kB"], lines
    assert j["others"]["folders"] == ["older captures"]
    assert j["others"]["folders_line"] == "Subfolders are not read: only the files directly in this folder are. Subfolders: older captures."
    assert j["no_table"] is None
    assert j["also"] == "This folder also holds files that are not tables: %s." % "; ".join(lines)
    assert "terminal agent can look at these files" in j["others"]["why"] and "turn them into a CSV file itself" in j["others"]["why"]
    assert [f["name"] for f in j["files"]] == ["bench_log.csv"]
    assert [f["name"] for f in family1.inventory(folder)] == ["bench_log.csv"]   # the scan stays "*.csv", nothing below is read
    p = new(c, folder).get_json()
    c.post("/api/agents/projects/%d/flow" % p["id"], json={"admin": "Sagar"})
    rid = eng.store.one("SELECT id FROM run WHERE project=?", (p["id"],))["id"]
    key, _rv = next_review(eng, rid)
    assert key == "manager:bench_log.csv"
    f1 = [s["key"] for s in eng.store.all("SELECT key FROM step WHERE run=? AND family='1'", (rid,))]
    per_file = [k for k in f1 if ":" in k]                                        # one sub-family per file read
    assert per_file and all(k.endswith(":bench_log.csv") for k in per_file), f1


# ---------------------------------------------------------------------------------------------- 3. no CSV table
def test_a_folder_without_a_csv_table_is_said_plainly_and_cannot_start(live):
    c, eng, tmp_path = live
    folder = tmp_path / "etl_only"
    folder.mkdir()
    for i in range(12):
        sized(str(folder / ("boot_%02d.etl" % i)), 250_000_000 if i == 0 else 100)
    sized(str(folder / "a.xml"), 600_000)
    sized(str(folder / "b.xml"), 500_000)
    with open(str(folder / "broken.csv"), "wb") as fh:                          # named .csv, but not text
        fh.write(bytes(range(256)) * 50)
    (folder / "sub").mkdir()
    j = inv(c, str(folder)).get_json()
    want = NO_TABLE + "12 files ending .etl, 250.0 MB; 2 files ending .xml, 1.1 MB; 1 CSV file that cannot be read as a table; 1 subfolder (not read)."
    assert j["no_table"] == want and j["files"] == [] and j["recognised"] is None and j["also"] is None
    assert [r["name"] for r in j["refused"]] == ["broken.csv"] and j["refused"][0]["line"].startswith("Not read as a table: broken.csv: ")
    r = new(c, str(folder))
    assert r.status_code == 400 and r.get_json()["error"] == want and r.get_json()["no_table"] is True
    r = new(c, str(folder), source_tool=LECROY)                                   # an older page that sends the tool: the same
    assert r.status_code == 400 and r.get_json()["error"] == want
    empty = tmp_path / "empty"
    empty.mkdir()
    assert inv(c, str(empty)).get_json()["no_table"] == NO_TABLE + "nothing: it is empty."
    assert new(c, str(empty)).get_json()["error"] == NO_TABLE + "nothing: it is empty."
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 0


# ---------------------------------------------------------------------------------------------- 4. older requests and values
def test_a_request_that_still_sends_the_tool_works_as_before(live):
    c, eng, tmp_path = live
    need_sample()
    r = new(c, SAMPLE, source_tool=ANOTHER)                                       # the old answer is still accepted and kept
    assert r.status_code == 200 and r.get_json()["source_tool"] == ANOTHER and r.get_json()["recognised"] is None
    r = new(c, SAMPLE, name="second", source_tool=LECROY)
    assert r.status_code == 200 and r.get_json()["source_tool"] == LECROY and r.get_json()["tool_check"]["doubt"] == []
    folder = disguised_folder(tmp_path)
    assert new(c, folder, source_tool=LECROY).status_code == 409                  # the wrong tool is still said before anything is stored
    assert new(c, folder, source_tool="pcmark10").status_code == 400


def test_an_analysis_made_before_keeps_a_ready_tool_and_leaves_another_tool_when_the_files_say_so(live):
    c, eng, tmp_path = live
    need_sample()
    pid = new(c, SAMPLE, source_tool=ANOTHER).get_json()["id"]                    # made with the former question's answer
    again = new(c, SAMPLE).get_json()                                             # opened again from the new page: the files decide
    assert again["reused"] is True and again["id"] == pid and again["source_tool"] == LECROY
    assert new(c, SAMPLE).get_json()["source_tool"] == LECROY                     # a ready tool kept earlier stays
    folder = disguised_folder(tmp_path)
    pid2 = new(c, folder, name="bench", source_tool=LECROY, source_tool_confirmed=True).get_json()["id"]
    assert new(c, folder, name="bench").get_json()["source_tool"] == LECROY       # the admin's earlier word is not overwritten
    assert pid2 != pid


@pytest.mark.parametrize("value", ["", "/no/such/folder", "x" * 5000, "/tmp\x00/x", "../../../../etc/passwd"])
def test_hostile_folder_values_are_refused_in_plain_words(live, value):
    c, eng, _tmp = live
    r = inv(c, value)
    assert r.status_code == 400 and r.get_json()["error"].startswith("not a folder") and "Traceback" not in r.get_json()["error"]
    r = new(c, value)
    assert r.status_code == 400 and r.get_json()["error"].startswith("the input folder does not exist")
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 0


@pytest.mark.parametrize("value", [7, ["/tmp"], {"a": 1}])
def test_a_folder_that_is_not_text_is_refused(live, value):
    c, eng, _tmp = live
    r = new(c, value)
    assert r.status_code == 400 and "Traceback" not in json.dumps(r.get_json())
    assert eng.store.one("SELECT COUNT(*) AS n FROM project")["n"] == 0


def test_the_other_files_are_listed_by_size_without_being_opened(tmp_path, monkeypatch):
    sized(str(tmp_path / "huge.etl"), 10)
    import builtins
    real = builtins.open

    def no_open(path, *a, **k):
        if str(path).endswith(".etl"):
            raise AssertionError("a file that is not a table was opened: %s" % path)
        return real(path, *a, **k)
    monkeypatch.setattr(builtins, "open", no_open)
    got = family1.other_files(str(tmp_path))
    assert got == {"groups": [{"ending": ".etl", "count": 1, "bytes": 10, "names": ["huge.etl"]}], "folders": []}
    assert family1.other_files(str(tmp_path / "missing")) == {"groups": [], "folders": []}


# ---------------------------------------------------------------------------------------------- 5. the page script
def script(name):
    with open(os.path.join(JS, name), encoding="utf-8") as fh:
        return fh.read()


def test_the_page_script_has_no_question_and_the_new_lines_and_button():
    page, st = script("agents.js"), script("source_tool.js")
    assert "Which tool exported the recording you want to analyse?" not in page + st
    assert "/api/agents/source_tools" not in page + st and "st-q" not in page + st
    # the folder check: what was recognised, the other files, no table, the terminal agent's button
    assert "r.recognised && r.recognised.sentence" in page and 'id="np-recognised"' in page
    assert 'id="np-no-table"' in page and "r.no_table" in page and "r.also" in page and "o.folders_line" in page
    assert "Ask the terminal agent about the files of this folder" in page
    assert 'typeof window.F2TTerminal.openFolder === "function"' in page
    assert "window.F2TTerminal.openFolder(b.dataset.folder" in page              # only on the admin's click
    assert page.count("F2TTerminal.openFolder(") == 1
    # Start the flow stays off for a folder without a table, with the reason
    assert "mk.disabled = !!why" in page and "Start the flow is off: " in page
    # the analysis's page: one plain line about the tool
    assert "recognised from the files: an export of" in st
    # nothing chosen or filled in for the admin by the new code
    new_code = page[page.index("let NP_NO_TABLE"):page.index("async function makeProject()")]
    assert not re.search(r"\.checked\s*=|\schecked[\s>]|\.value\s*=", new_code)


def test_every_field_label_of_the_start_form_has_its_why_line():
    page = script("agents.js")
    at = page.index("<h2>New analysis</h2>")
    page = page[at:page.index("</section>", at)]
    labels = re.findall(r"<label class=\"f\"", page)
    with_why = re.findall(r"<label class=\"f\"[^>]*>(?:(?!</label>).)*</label>\s*<div class=\"why\">((?:(?!</div>).)*)</div>", page, flags=re.S)
    assert len(labels) >= 3 and len(with_why) == len(labels)
    assert all(len(re.sub(r"<[^>]+>|\$\{[^}]*\}", "", w)) > 40 for w in with_why)


def test_how_the_page_loads_the_scripts():
    with open(os.path.join(APP_DIR, "app", "static", "agents.html"), encoding="utf-8") as fh:
        html = fh.read()
    for name in ("agents.js", "source_tool.js", "terminal_agent.js"):
        tag = re.search(r"<script[^>]*src=\"/static/js/%s\"[^>]*>" % re.escape(name), html)
        assert tag and "module" not in tag.group(0), name                        # classic scripts: one shared top level
    assert html.index("/static/js/agents.js") < html.index("/static/js/source_tool.js")


@pytest.mark.parametrize("name", ["agents.js", "source_tool.js"])
@pytest.mark.parametrize("ending", [".cjs", ".mjs"])
def test_the_script_parses_and_declares_no_name_twice(tmp_path, name, ending):
    if not os.path.exists(NODE):
        pytest.skip("node is not on this computer")
    copy = str(tmp_path / (name[:-3] + ending))
    shutil.copyfile(os.path.join(JS, name), copy)
    r = subprocess.run([NODE, "--check", copy], capture_output=True, text=True, timeout=120)
    assert r.returncode == 0, r.stderr[-1500:]


def test_no_top_level_name_of_the_new_code_is_declared_by_another_page_script():
    names = ("NP_NO_TABLE", "npNoTable", "npCanAskTerminal")
    for fn in os.listdir(JS):
        if fn.endswith(".js") and fn != "agents.js":
            s = script(fn)
            assert not any(re.search(r"\b(?:let|const|var|function)\s+%s\b" % n, s) for n in names), fn
