"""The data research of Family 4 says nothing the data does not show (owner, 2026-11-14: "It should not hallucinate at
all"), at the place where the record is made (agentic/f4_research.py), not only where Family 4 takes it.

The case is the experiment's own (research note E, the real model on the CSV of an unknown tool): the same header, the same
rule text and procedure, the same counts in the columns the rule reads (608 commands, 6 that never completed, 1 aborted).
The experiment's CSV itself was not kept with its evidence, so the file is rebuilt here from those counts.

What must hold:
  1. on the experiment's case: no false surprise, no false conflict, exactly the one real surprise (the 6 empty completion
     times, with its count), and Family 4's own filter (ground_research) finds nothing left to drop;
  2. a word in quotation marks that is the name of a column, in any of five spellings, is a column name;
  3. a phrase that lists alternatives, in any of four forms, is looked for value by value;
  4. a real conflict is still reported, with both counts;
  5. a decision of the Data researcher that names a column the file does not have, or that the counts contradict, is
     recorded as not supported by the data, with the reason, and is no question;
  6. a file of 200,000 rows is read once, row by row, in bounded memory.
No server and no model: the Data researcher's answers are written here."""
import csv
import json
import os
import sys
import time
import tracemalloc

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import family1, family3, family4, f4_research as RS  # noqa: E402
import test_family4 as T  # noqa: E402
import test_f4_research as F  # noqa: E402

FILE = "cmd_trace_export.csv"
HEADER = ["Idx", "T Submit [ns]", "Dev", "QID", "Tag", "Op", "Code", "NS", "LBA Start", "Blocks", "Xfer [B]", "Buf Addr", "Result", "T Done [ns]", "Svc Time [us]"]
PENDING_ROWS = (155, 216, 295, 400, 500, 600)           # the 6 commands that never completed; the first three are at lines 156, 217, 296 as in the run
ABORTED_ROW = 301
# the words of the real run (run_dump.json of the experiment): the admin's sentence and the Rule writer's procedure
WORDS = "List every command that never got a completion, with its QID (the queue) and its Tag."
PROC = {"source_data": [{"file": FILE, "columns": ["QID", "Tag", "Result", "T Done [ns]", "Idx"]}],
        "steps": ["No tree exists and none is needed. The item uses only the file cmd_trace_export.csv, where each row is one traced command, so no two files are joined.",
                  "Open cmd_trace_export.csv and read the header row. Then read every data row in file order. There should be 608 rows, numbered by Idx from 1 to 608. "
                  "No hash map is kept. Each row is judged on its own.",
                  "For each row, read the cell 'Result' as text and remove spaces at the start and end. Do not change letter case. The row counts as 'never got a completion' "
                  "only if this text is exactly PENDING. FILES says PENDING marks commands that are still pending, and 'T Done [ns]' is empty for them.",
                  "Read the cell 'T Done [ns]' only to check consistency. It counts as empty if it has no characters after trimming spaces. Do not use it to decide which rows "
                  "are listed. Count the rows where Result is PENDING but 'T Done [ns]' is not empty. Count the rows where 'T Done [ns]' is empty but Result is not PENDING. "
                  "Report both counts to the admin next to the result, and do not list those rows.",
                  "Rows with Result OK or ABORTED_BY_REQ are not listed, because they carry a completion outcome.",
                  "For each listed row, read 'QID' as a decimal whole number (for example 0, 1, 2, 3, 4). Read 'Tag' as a decimal whole number. Neither is changed or reformatted.",
                  "Write one output line per listed row with QID and Tag. If the same QID and Tag pair occurs on several listed rows, write one line for each row and do not "
                  "merge them, because Tag is reused over time.",
                  "Sort the lines by QID ascending as a number, then by Tag ascending as a number. Break any remaining tie by Idx ascending as a number. Idx is used only for "
                  "sorting and is not output.",
                  "If no row is listed, output only the header line with the two column names."],
        "output": {"columns": ["QID", "Tag"], "order": "QID ascending (numeric), then Tag ascending (numeric), then Idx ascending for ties"}}
EMPTY_DONE = "cmd_trace_export.csv column T Done [ns]: an empty cell in 6 of the 608 rows (first at line 156, 217, 296) (exact: all 608 rows)."
FALSE_OF_THE_RUN = ("“Result”", "“never got a completion”", "“T Done [ns]”", "“QID”", "“Tag”", "“ok or aborted_by_req”")


def rows_of(n=608, pending=PENDING_ROWS, aborted=(ABORTED_ROW,)):
    """The rows of the disguised file, one at a time: the same columns and the same counts as the experiment's."""
    for i in range(1, n + 1):
        sub = 400000000.0 + i * 12500.25
        state = "PENDING" if i in pending else "ABORTED_BY_REQ" if i in aborted else "OK"
        done = "" if state == "PENDING" else "%.3f" % (sub + 80000.5)
        yield [str(i), "%.3f" % sub, "002:00:0", str(i % 5), str(i % 64), "Read" if i % 3 else "Write", "0x02" if i % 3 else "0x01", "1", str(i * 8), "8", "4096",
               "0x%08X" % (0x10000000 + i * 4096), state, done, "" if state == "PENDING" else "80.000"]


def write_file(path, n=608, **kw):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(HEADER)
        for row in rows_of(n, **kw):
            w.writerow(row)
    return path


def the_run(tmp_path, monkeypatch, words=WORDS, proc=PROC, research=None, settle_hidden=True):
    """The experiment's case as an analysis: the disguised file, Family 1's dictionary of it, the rule and its procedure."""
    lab = T.Lab(tmp_path, monkeypatch, proc=proc)
    write_file(os.path.join(lab.folder, FILE))
    f = next(x for x in family1.inventory(lab.folder) if x["name"] == FILE)
    d = os.path.join(lab.know, "dictionaries", f["format_key"])
    os.makedirs(d, exist_ok=True)
    cols = [{"column": c, "type": "text", "rows_with_value": 608, "distinct": 1, "meaning": "", "keywords": []} for c in HEADER]
    with open(os.path.join(d, "cmd_trace_export.current.json"), "w", encoding="utf-8") as fh:
        json.dump({"path": f["path"], "level": None, "version": 1, "approved_at": 100.0, "approved_by": "Sagar", "rows": 608, "columns": cols}, fh)
    r = lab.rule()
    r["description"] = words
    family3.save_rule(r)
    lab.req = lambda ctx, n: {"requirements": ["Read cmd_trace_export.csv row by row.", "List the rows whose Result is exactly PENDING, with QID and Tag."],
                              "data_needed": [], "definitions": [], "questions": [], "answers": []}
    if research:
        lab.research = research
    lab.settle_hidden = settle_hidden
    lab.start()
    lab.work()
    return lab


class Col:
    """A measured column as find_words reads it: its values with their counts."""
    overflow = False

    def __init__(self, values):
        self.values = values


RESULT = {FILE: {"Result": Col({"OK": 601, "PENDING": 6, "ABORTED_BY_REQ": 1})}}


def words_of(text, phrases=True):
    lits = RS.literals_of(text)
    return lits, {w["text"]: w for w in RS.find_words(lits, RS.phrases_of(text) if phrases else [], RESULT, {}, {FILE: HEADER})}


def said_of(lits, words):
    """What the record would say of these words: its surprises, its conflicts and its ledger lines."""
    ws = list(words.values())
    con = RS.conflicts_of(ws, [], lits, [])
    sur = RS.surprises_of({"files": [], "links": [], "words": ws})
    return sur, con, {x["what"]: x for x in RS.ledger_of([], ws, [], [], [], lits, con)}


# ------------------------------------------------------------------------------------------- 1. the experiment's own case
def test_the_real_runs_case_gives_the_one_real_surprise_and_no_false_line(tmp_path, monkeypatch):
    lab = the_run(tmp_path, monkeypatch)
    rec = lab.out("research")["record"]
    assert rec["files"][0]["rows"] == 608 and rec["files"][0]["basis"] == "exact: all 608 rows"
    assert rec["surprises"] == [EMPTY_DONE]                                  # the report's one real surprise, with its count
    assert rec["conflicts"] == [] and rec["not_supported"] == []
    said = json.dumps([rec["surprises"], rec["conflicts"], rec["hidden"]], ensure_ascii=False)
    assert not any(w in said for w in FALSE_OF_THE_RUN) and "in no column" not in said and "no count" not in said
    words = {w["text"]: w for w in rec["words"]}
    for name in ("Result", "T Done [ns]", "QID", "Tag"):                     # the Rule writer's quoted column names
        assert words[name]["column_name"] == {"file": FILE, "column": name} and words[name]["found"] == [] and words[name]["nearest"] == []
    assert "ok or aborted_by_req" not in words                               # a list of two values, looked for value by value
    assert [(words[t]["found"][0]["spelling"], words[t]["found"][0]["rows"], words[t]["one_of"]) for t in ("ok", "aborted_by_req")] == [
        ("OK", 601, "ok or aborted_by_req"), ("ABORTED_BY_REQ", 1, "ok or aborted_by_req")]
    assert words["pending"]["found"][0]["rows"] == 6 and words["pending"]["found"][0]["column"] == "Result"
    never = words["never got a completion"]                                  # the admin's phrase: nothing like it is stored
    assert never["found"] == [] and never["nearest"] == [] and "column_name" not in never
    led = {x["what"]: x for x in rec["ledger"]}
    line = led["the rule's word “never got a completion”"]
    assert line["state"] == RS.TO_DECIDE and line["source"].startswith("not found in the data") and "nothing like it in the data" in line["detail"]
    assert led["the rule's word “Result”"]["state"] == RS.ESTABLISHED and "is the name of a column of cmd_trace_export.csv" in led["the rule's word “Result”"]["source"]
    assert led["the rule's word “ok”"]["state"] == RS.ESTABLISHED and "holds “OK” in 601 rows" in led["the rule's word “ok”"]["source"]
    # the one open decision is the program's, from its count
    assert [(h["kind"], h["by"]) for h in rec["hidden"]] == [("empty values", "the program")] and "6 of the 608 rows hold nothing there" in rec["hidden"][0]["because"]
    # nothing reaches the admin as a question about a word, and the card shows no such line
    rv = lab.review()
    assert not [q for q in rv["data"]["questions"] if q.get("kind") == "conflict"] and "is in no column of the files it reads" not in rv["body"]
    assert "Conflicts between what was said and what was measured" not in rv["body"] and "an empty cell in 6 of the 608 rows" in rv["body"]


def test_family_4s_own_filter_finds_nothing_left_to_drop_on_the_real_runs_case(tmp_path, monkeypatch):
    """ground_research (agentic/family4.py) ran on this record inside the step; run on what build() makes, it drops nothing."""
    lab = the_run(tmp_path, monkeypatch)
    step = lab.step("research")
    made = []
    monkeypatch.setattr(family4, "ground_research", lambda record, facts=None, log=None: made.append(json.loads(json.dumps(record))) or record)
    lab2 = the_run(tmp_path / "again", monkeypatch)
    raw = made[0]                                                            # the record as f4_research.build made it, before any filter
    assert raw["surprises"] == [EMPTY_DONE] and raw["conflicts"] == [] and len(raw["hidden"]) == 1
    monkeypatch.undo()
    said = []
    after = family4.ground_research(json.loads(json.dumps(raw)), {"headers": {FILE: HEADER}}, said.append)
    assert after["not_supported"] == [] and said == []                       # nothing dropped, nothing said to the log
    assert after["surprises"] == raw["surprises"] and after["conflicts"] == raw["conflicts"] and after["hidden"] == raw["hidden"]
    assert [x for x in after["ledger"]] == raw["ledger"]                     # also the ledger lines of the column names were right already
    assert step and lab2.out("research")["record"]["surprises"] == [EMPTY_DONE]


# ------------------------------------------------------------------------------------------- 2. quoted column names
def test_a_quoted_column_name_in_five_spellings_is_a_column_name():
    spellings = {"T Done [ns]": "T Done [ns]",          # letter for letter
                 "t done [NS]": "T Done [ns]",          # another case
                 "  T  Done [ns] ": "T Done [ns]",      # spaces around and inside
                 "T Done": "T Done [ns]",               # the unit in brackets left out
                 "t_done_ns": "T Done [ns]"}            # other marks
    for said, column in spellings.items():
        assert RS.column_named(said, {FILE: HEADER}) == (FILE, column), said
        assert RS.column_named(said, HEADER) == ("", column), said             # a plain list of names is taken too
    assert RS.column_named("T Done [us]", {FILE: HEADER}) is None and RS.column_named("Done", {FILE: HEADER}) is None and RS.column_named("", HEADER) is None
    assert RS.column_named("never got a completion", {FILE: HEADER}) is None
    for said, column in list(spellings.items()) + [("result", "Result"), ("QID", "QID"), ("Svc Time [us]", "Svc Time [us]")]:
        lits, words = words_of('Read "%s" of each row.' % said, phrases=False)
        (w,) = words.values()                                                 # the rule's words keep one spelling of a quoted text, spaces made single
        assert w["column_name"] == {"file": FILE, "column": column} and not w["found"] and not w["nearest"] and not w["part_of"], said
        sur, con, led = said_of(lits, words)
        assert sur == [] and con == [], said
        assert all(x["state"] == RS.ESTABLISHED and x["source"] == "“%s” is the name of a column of cmd_trace_export.csv (its header, read by the program), not a value to look for" % column
                   for x in led.values()), said
    text = 'Read "T Done [ns]", "T Done", "t_done_ns", "result", "QID" and "Svc Time [us]" of each row.'
    lits, words = words_of(text, phrases=False)
    assert [w["column_name"]["column"] for w in words.values()] == ["T Done [ns]", "T Done [ns]", "T Done [ns]", "Result", "QID", "Svc Time [us]"]
    sur, con, led = said_of(lits, words)
    assert sur == [] and con == []
    assert all(x["state"] == RS.ESTABLISHED and "is the name of a column of cmd_trace_export.csv (its header, read by the program)" in x["source"] for x in led.values())
    # a quoted word that is a column's name AND a stored value is the stored value, as before
    lits, words = words_of('Keep the rows that say "pending".', phrases=False)
    held = RS.find_words(lits, [], RESULT, {}, {FILE: HEADER + ["Pending"]})[0]
    assert held["found"][0]["rows"] == 6 and "column_name" not in held


# ------------------------------------------------------------------------------------------- 3. lists of alternatives
def test_a_list_of_alternatives_in_four_forms_is_looked_for_value_by_value():
    assert RS.alternatives_of("OK or ABORTED_BY_REQ") == ["OK", "ABORTED_BY_REQ"] and RS.alternatives_of("OK, ABORTED_BY_REQ and PENDING") == ["OK", "ABORTED_BY_REQ", "PENDING"]
    assert RS.alternatives_of("OK / PENDING") == ["OK", "PENDING"] and RS.alternatives_of("OK/PENDING") == ["OK", "PENDING"] and RS.alternatives_of("timed out") == []
    forms = {'Rows whose Result is "OK or ABORTED_BY_REQ" are left out.': {"OK": 601, "ABORTED_BY_REQ": 1},
             'Rows whose Result is "OK, ABORTED_BY_REQ and PENDING" are counted.': {"OK": 601, "ABORTED_BY_REQ": 1, "PENDING": 6},
             'Rows whose Result is "OK / PENDING" are counted.': {"OK": 601, "PENDING": 6},
             'Rows whose Result is "OK/PENDING" are counted.': {"OK": 601, "PENDING": 6}}
    for text, want in forms.items():
        for marks in (True, False):                                          # in quotation marks, and as plain words of the rule
            t = text if marks else text.replace('"', "")
            lits, words = words_of(t)
            got = {w["found"][0]["spelling"]: w["found"][0]["rows"] for w in words.values() if w["found"]}
            assert got == want, (t, got)
            sur, con, led = said_of(lits, words)
            assert sur == [] and con == [], (t, sur, con)
            assert all(x["state"] == RS.ESTABLISHED for x in led.values()), (t, led)
    # no phrase is made across a comma: "OK, ABORTED_BY_REQ" is not the value "ok aborted_by_req" (its nearest spelling made a false conflict)
    assert "ok aborted_by_req" not in RS.phrases_of("Result OK, ABORTED_BY_REQ and PENDING") and "ok or aborted_by_req" in RS.phrases_of("Result OK or ABORTED_BY_REQ")
    # one value of a list that the data spells another way is a real finding, about that value alone, with both counts
    lits, words = words_of('Rows whose Result is "OK or ABORTED_BY_REQUEST" are left out.', phrases=False)
    assert words["OK"]["found"][0]["rows"] == 601 and words["ABORTED_BY_REQUEST"]["nearest"] == [{"file": FILE, "column": "Result", "spelling": "ABORTED_BY_REQ", "rows": 1}]
    sur, con, led = said_of(lits, words)
    assert sur == ["The rule's word “ABORTED_BY_REQUEST” is in no column of the files it reads; nearest: “ABORTED_BY_REQ” in cmd_trace_export.csv column Result (1 row)."]
    assert len(con) == 1 and con[0]["counts"] == [{"what": "“ABORTED_BY_REQUEST” as the rule writes it", "rows": 0},
                                                  {"what": "“ABORTED_BY_REQ” in cmd_trace_export.csv column Result", "rows": 1}]
    # words outside quotation marks that only happen to stand around "and" are no list: the value is found on its own, as before
    lits, words = words_of("Keep the rows whose Result is PENDING and whose Tag is 3.")
    assert list(words) == ["pending"] and words["pending"]["found"][0]["rows"] == 6 and "one_of" not in words["pending"]
    # in quotation marks, a list with one value the data does not hold: the held one is found, the other is not found in the data
    lits, words = words_of('Rows whose Result is "OK or RETRIED" are left out.', phrases=False)
    assert words["OK"]["found"][0]["rows"] == 601 and words["RETRIED"]["found"] == [] and words["RETRIED"]["nearest"] == [] and words["RETRIED"]["one_of"] == "OK or RETRIED"
    sur, con, led = said_of(lits, words)
    assert sur == [] and con == [] and led["the rule's word “RETRIED”"]["state"] == RS.TO_DECIDE and led["the rule's word “RETRIED”"]["source"].startswith("not found in the data")
    # a quoted text with a separator that is one stored value stays one value
    one = {FILE: {"Op": Col({"Create I/O SQ": 4, "Read": 9})}}
    (w,) = RS.find_words(RS.literals_of('Count the "Create I/O SQ" commands.'), [], one, {}, {FILE: HEADER})
    assert w["text"] == "Create I/O SQ" and w["found"][0]["rows"] == 4 and "one_of" not in w
    # a list of which the data holds no value is not taken apart: it is one word, not found in the data
    (w,) = RS.find_words(RS.literals_of('Mark the "red or blue" ones.'), [], RESULT, {}, {FILE: HEADER})
    assert w["text"] == "red or blue" and not w["found"] and not w["nearest"]
    assert RS.surprises_of({"files": [], "links": [], "words": [w]}) == [] and RS.conflicts_of([w], [], [], []) == []


# ------------------------------------------------------------------------------------------- 4. a real conflict
def test_a_real_conflict_is_still_reported_with_both_counts(tmp_path, monkeypatch):
    # the rule's spelling against the data's, through the whole step (the bench of test_f4_research: "timed out" in the rule, "timeout" in 4 rows)
    lab = F.bench(tmp_path, monkeypatch)
    lab.work()
    rec = F.record_of(lab)
    word = next(c for c in rec["conflicts"] if "“timed out”" in c["what"])
    assert word["counts"] == [{"what": "“timed out” as the rule writes it", "rows": 0}, {"what": "“timeout” in bench.csv column Result", "rows": 4}]
    assert word["measured_fact"] == "bench.csv column Result holds “timeout” (4 rows)" and word["b"]["says"] == word["measured_fact"] and "timeout" in word["question"]
    assert "The rule's word “timed out” is in no column of the files it reads; nearest: “timeout” in bench.csv column Result (4 rows)." in rec["surprises"]
    # (2026-11-15) a third conflict, settled by the measured count: the dictionary says "integer" and the one value "1,200" is not
    # read as a number for sure (the comma can be a decimal sign or a thousands sign)
    assert any("43 ms" in c["what"] for c in rec["conflicts"]) and len(rec["conflicts"]) == 3
    assert [c["kind"] for c in rec["conflicts"] if c["settled"]] == ["the dictionary against the measured content"]
    # two columns of one file against what Family 1's dictionary says of them: the measured content stands, both counts named
    p = tmp_path / "two.csv"
    p.write_text("Sent,Received\n" + "".join("%d,%s\n" % (i, i if i % 4 else "lost") for i in range(1, 41)), encoding="utf-8")
    m = RS.measure(str(p), ["Sent", "Received"])
    blocks = [dict(m["columns"][c].block(m["rows"], m["basis"], declared="integer"), file="two.csv") for c in ("Sent", "Received")]
    (c,) = RS.conflicts_of([], blocks, [], [])
    assert c["kind"] == "the dictionary against the measured content" and c["settled"] is True and "two.csv column Received" in c["what"]
    assert c["counts"] == [{"what": "values of two.csv column Received that are numbers", "rows": 30}, {"what": "values of two.csv column Received that are not numbers", "rows": 10}]
    assert "10 values are not numbers" in c["b"]["says"] and "exact: all 40 rows" in c["b"]["source"]


# ------------------------------------------------------------------------------------------- 5. the Data researcher's decisions
def test_a_decision_about_a_column_the_file_does_not_have_and_one_the_counts_contradict_are_not_questions(tmp_path, monkeypatch):
    answer = {"matters": [], "doubts": [], "hidden_decisions": [
        {"column": "Status", "kind": "empty values", "decision": "what happens to a command whose Status cell is empty"},           # the file has no column Status
        {"column": "Result", "kind": "empty values", "decision": "what happens to a command whose Result cell is empty"},           # no Result cell is empty: 608 of 608 hold a value
        {"column": "Result", "kind": "other", "decision": "is a command whose Result is TIMED_OUT listed too"},                     # no row holds TIMED_OUT
        {"column": "", "kind": "other", "decision": "what happens to commands sent during a reset"},                                # names no column
        {"column": "Op", "kind": "other", "decision": "is a Flush command listed like the others"},                                 # a column the rule does not read
        {"column": "Result", "kind": "other", "decision": "is a command whose Result is ABORTED_BY_REQ listed too"}]}               # 1 row holds it: supported
    lab = the_run(tmp_path, monkeypatch, research=lambda ctx, n: answer, settle_hidden=False)
    rec = lab.out("research")["record"]
    mine = [h for h in rec["hidden"] if h["by"] != "the program"]
    assert [h["decision"] for h in mine] == ["is a command whose Result is ABORTED_BY_REQ listed too"]
    assert mine[0]["column"] == "Result" and mine[0]["file"] == FILE and mine[0]["id"] == "H2"
    assert mine[0]["measured_fact"] == "cmd_trace_export.csv column Result holds “ABORTED_BY_REQ” in 1 row (exact: all 608 rows)"
    assert mine[0]["because"] == "measured by the program: " + mine[0]["measured_fact"] and "no count" not in json.dumps(rec["hidden"])
    aside = {x["what"]: x for x in rec["researchers"][FILE]["not_supported"]}
    assert len(aside) == 5 and all(x["why"].startswith("not supported by the data: ") and x["kind"] == "open decision raised by the Data researcher" for x in aside.values())
    assert aside["what happens to a command whose Status cell is empty"]["why"] == (
        "not supported by the data: it names the column “Status”, and the header of cmd_trace_export.csv has no column of that name")
    assert aside["what happens to a command whose Result cell is empty"]["why"] == (
        "not supported by the data: cmd_trace_export.csv column Result holds a value in 608 of its 608 rows: no cell there is empty or a spelling of nothing (exact: all 608 rows)")
    assert "names none of the values the column holds" in aside["is a command whose Result is TIMED_OUT listed too"]["why"]
    assert "it names no column of cmd_trace_export.csv" in aside["what happens to commands sent during a reset"]["why"]
    assert "is not among the columns the rule reads" in aside["is a Flush command listed like the others"]["why"]
    assert rec["researchers"][FILE]["dropped"] == ["Status"]
    # none of the five is offered: not on the card, not as a question, not to the Requirements agent
    rv = lab.review()
    shown = rv["body"] + json.dumps(rv["data"]["questions"], ensure_ascii=False) + json.dumps(lab.of("requirements")[0]["HIDDEN_DECISIONS"], ensure_ascii=False)
    for what in aside:
        assert what not in shown, what
    asked = [q["question"] for q in rv["data"]["questions"] if q.get("kind") == "hidden"]
    assert len(asked) == 2 and any("ABORTED_BY_REQ listed too" in q for q in asked)
    assert "holds “ABORTED_BY_REQ” in 1 row" in rv["body"]


def test_the_fact_of_a_decision_is_looked_up_in_the_column_it_names_and_never_taken_from_the_model():
    m_rows = "exact: all 608 rows"
    block = {"file": FILE, "column": "T Done [ns]", "in_the_file": True, "rows": 608, "rows_with_a_value": 602, "basis": m_rows, "unit": "ns", "unit_from": "from its name",
             "nothing": [{"spelling": "an empty cell", "rows": 6, "first_lines": [156, 217, 296]}], "numbers": 602, "range": [1.0, 9.0], "distinct_values": 602,
             "distinct_is_exact": True, "most_frequent": []}
    ask = lambda kind, decision="what then": {"column": "T Done [ns]", "file": FILE, "kind": kind, "decision": decision}
    assert RS.decision_fact(ask("empty values"), block) == ("cmd_trace_export.csv column T Done [ns]: an empty cell in 6 rows (exact: all 608 rows)", "")
    assert RS.decision_fact(ask("units"), block) == ("cmd_trace_export.csv column T Done [ns] holds its values in ns (from its name)", "")
    assert RS.decision_fact(ask("equality at a limit"), block)[0] == "cmd_trace_export.csv column T Done [ns] holds 602 numbers, from 1 to 9 ns (exact: all 608 rows)"
    fact, why = RS.decision_fact(ask("ties"), block)                          # every value is there once: no two lines can be equal in it
    assert fact == "" and "no value of cmd_trace_export.csv column T Done [ns] is held by two rows" in why
    assert RS.decision_fact(ask("other", "the model says 40 rows hold N/A"), block)[0] == ""          # a number the model gives is no fact
    assert RS.decision_fact({"column": "", "file": FILE, "kind": "other", "decision": "x"}, None) == ("", "it names no column of cmd_trace_export.csv, so no count can show it")
    assert RS.decision_fact(ask("empty values"), None)[0] == ""


# ------------------------------------------------------------------------------------------- 6. one pass, bounded memory
def test_a_file_of_200000_rows_is_read_once_in_bounded_memory(tmp_path, monkeypatch):
    n, pending = 200000, set(range(1000, 200001, 1000))                      # 200 commands that never completed
    path = write_file(str(tmp_path / FILE), n, pending=pending, aborted=set(range(500, 200001, 20000)))
    size = os.path.getsize(path)
    # (2026-11-15) the pass reads through csv_dialect (the file's own encoding, separator and header line), no longer through
    # nvme_hier.loader.read_csv, which reads the plain form only: a reading by either one is counted
    opened, real, real_rows = [], family1.L.read_csv, RS.CD.Rows

    def counted(fh, p, *a, **kw):
        opened.append(p)
        return real(fh, p, *a, **kw)

    class CountedRows(real_rows):
        def __init__(self, fh, p, *a, **kw):
            opened.append(p)
            real_rows.__init__(self, fh, p, *a, **kw)
    monkeypatch.setattr(family1.L, "read_csv", counted)
    monkeypatch.setattr(RS.CD, "Rows", CountedRows)
    tracemalloc.start()
    t0 = time.time()
    m = RS.measure(path, ["QID", "Tag", "Result", "T Done [ns]", "Idx"])
    lits = RS.literals_of(WORDS, " ".join(PROC["steps"]))
    words = RS.find_words(lits, RS.phrases_of(WORDS, " ".join(PROC["steps"])), {FILE: m["columns"]}, {}, {FILE: [c for c in m["header"] if c]})
    blocks = [dict(m["columns"][c].block(m["rows"], m["basis"]), file=FILE) for c in ("QID", "Tag", "Result", "T Done [ns]", "Idx")]
    record = {"files": [{"file": FILE, "touched": blocks}], "links": [], "words": words}
    sur, con = RS.surprises_of(record), RS.conflicts_of(words, blocks, lits, [])
    seconds = time.time() - t0
    _now, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    print("\n200,000 rows (%.1f MB): one pass, %.1f s with the memory trace on, peak %.1f MB of Python memory" % (size / 1e6, seconds, peak / 1e6))
    assert opened == [path]                                                  # the file was opened and read once
    assert m["rows"] == n and m["basis"] == "exact: all 200,000 rows" and m["header"] == HEADER
    assert sur == ["cmd_trace_export.csv column T Done [ns]: an empty cell in 200 of the 200,000 rows (first at line 1001, 2001, 3001) (exact: all 200,000 rows)."]
    assert con == []
    held = {w["text"]: w["found"][0]["rows"] for w in words if w["found"]}
    assert held == {"ok": n - 200 - 10, "aborted_by_req": 10, "pending": 200}
    idx = next(b for b in blocks if b["column"] == "Idx")
    assert idx["distinct_values"] == RS.DISTINCT_CAP and idx["distinct_is_exact"] is False       # what is kept of a column has a fixed limit, and the record says so
    assert peak < 48 * 1024 * 1024 and peak < 2 * size + 16 * 1024 * 1024, peak                  # bounded: far below a second copy of the rows as Python objects
