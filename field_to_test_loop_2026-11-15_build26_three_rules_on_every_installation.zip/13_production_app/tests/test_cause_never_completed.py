"""The cause of a command that never completed (2026-11-14): the evidence card looks at what happened AFTER the command's last step
(the host's Abort for it, the controller reset, who stopped first, whether the drive answered other commands), joined by identity, and
fixed rules decide the cause from that (nvme_hier/evidence.py _after, _never_completed).

    python3 -m pytest -q -p no:cacheprovider tests/test_cause_never_completed.py

The tree of the S17 sample (samples/clean_five_files/S17_io_timeout_abort_reset) is built once in a temporary folder; every hand-made
recording is a copy of that tree with rows removed or one cell changed (the card reads only the tree). Nothing of the application's own
folders is touched. What the S17 rows show (worked out from the data, see the report build_cause_rules.md):

    Read  row 144 (queue 1, id 29): Abort row 145 names it 60 µs after its doorbell; it completed with status 0/07h
    Write row 155 (queue 3, id 26): Abort row 216 names it after 30.000 s (never answered); reset (row 3153) after 60.000 s
    Write row 295 (queue 3, id 2):  Abort row 358 names it after 30.000 s (never answered); reset (row 4377) after 60.000 s
    Write row 443 (queue 3, id 4):  Abort row 501 names it after 30.000 s (answered);       reset (row 5822) after 60.003 s
    Write row 509 (queue 3, id 24): Abort row 570 names it after 30.000 s (answered);       reset (row 5822) after 30.001 s; 443 stopped first
    Abort rows 216 and 358: fetched, never answered, 30.000 s old (limit 60 s) when the reset for "their" Write came
During every one of these waits the drive answered 59 to 132 other commands, on the same queue too.
"""
import inspect
import json
import os
import shutil
import sqlite3
import sys
import tempfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
for p in (APP_DIR, os.path.join(APP_DIR, "app")):
    if p not in sys.path:
        sys.path.insert(0, p)
from nvme_hier import evidence as EV, terms as TM   # noqa: E402

S17 = os.path.join(APP_DIR, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
pytestmark = pytest.mark.skipif(not all(os.path.exists(os.path.join(S17, v)) for v in NAMES.values()),
                                reason="the S17 sample folder (samples/clean_five_files/S17_io_timeout_abort_reset) is not on this machine")
S = 10 ** 12
EXPECTED = {144: "host_abort_by_tool_or_test", 155: "device_internal_delay", 295: "device_internal_delay", 443: "device_internal_delay",
            509: "device_internal_delay", 216: "host_reset_or_driver_recovery", 358: "host_reset_or_driver_recovery"}
ABORT_OF = {155: 216, 295: 358, 443: 501, 509: 570}
RESET_OF = {155: 3153, 295: 4377, 443: 5822, 509: 5822, 216: 3153, 358: 4377}


@pytest.fixture(scope="module")
def tree():
    """The S17 tree, built once the way the application builds it (the files, the joins, the rules), in a temporary folder."""
    from nvme_hier import builder as B, loader as L, rules as RL
    base = os.environ.get("F2T_TEST_TMP") or None
    if base:
        os.makedirs(base, exist_ok=True)
    d = tempfile.mkdtemp(prefix="cause_never_", dir=base)
    db = os.path.join(d, "hier.sqlite")
    L.load_upload(db, {k: os.path.join(S17, v) for k, v in NAMES.items()})
    B.build(db)
    RL.apply(db)
    yield db
    shutil.rmtree(d, ignore_errors=True)


@pytest.fixture
def copy(tree, tmp_path):
    """A hand-made recording: a copy of the tree to remove rows from. -> a function giving a new copy's connection."""
    made = []

    def make():
        p = str(tmp_path / ("copy%d.sqlite" % len(made)))
        src, dst = sqlite3.connect(tree), sqlite3.connect(p)
        src.backup(dst)
        src.close()
        dst.row_factory = sqlite3.Row
        made.append(dst)
        return dst
    yield make
    for c in made:
        c.close()


def finding(con, row):
    """The detector's own timeout finding of a command row, the way the page hands it to the card."""
    con.row_factory = sqlite3.Row
    f = con.execute("SELECT * FROM finding WHERE rule='cmd.timeout' AND cmd_rowid=?", (row,)).fetchone()
    assert f is not None, "no cmd.timeout finding for command row %s" % row
    f = dict(f)
    f["detail"] = json.loads(f["detail"])
    return f


def decided(con, row, f=None):
    c = EV.card(con, f or finding(con, row))
    key, words = EV.decide_cause(c)
    assert key in TM.CAUSES, key
    json.dumps(c)                                   # the card is plain data
    return c, key, words


def abort_packet(con, abort_row):
    """The packet that carries the Abort's own 64-byte entry (the read completion under its Submission Queue Entry)."""
    r = con.execute("SELECT p.rowid_file, p.raw FROM ntx n JOIN spl s ON s.parent_level='nvme_transaction' AND s.parent=n.rowid_file "
                    "JOIN lnk l ON l.parent_level='split' AND l.parent=s.rowid_file JOIN pkt p ON p.parent_level='link' AND p.parent=l.rowid_file "
                    "WHERE n.parent_level='nvme_command' AND n.parent=? AND n.type LIKE '%Submission Queue Entry' AND p.tlp_type LIKE 'Cpl%'", (abort_row,)).fetchone()
    assert r is not None
    return r[0], json.loads(r[1])


def set_data(con, pkt_row, raw, cell):
    raw = dict(raw)
    raw["DATA"] = cell
    con.execute("UPDATE pkt SET raw=? WHERE rowid_file=?", (json.dumps(raw), pkt_row))
    con.commit()


def remove_resets_after(con, t_ps):
    con.execute("DELETE FROM ntx WHERE type='Controller Register (CC)' AND t_ps>?", (t_ps,))
    con.commit()


def stop_command(con, row):
    """Make a completed command one that never completed: no status, no time, and its completion entry, interrupt and head doorbell gone."""
    con.execute("UPDATE cmd SET st=NULL, sct=NULL, sc=NULL, dur_ps=NULL WHERE rowid_file=?", (row,))
    con.execute("DELETE FROM ntx WHERE parent_level='nvme_command' AND parent=? AND (type LIKE '%Completion Queue Entry' OR type LIKE 'MSI-X%' OR type LIKE 'Completion Queue Head%')", (row,))
    con.commit()
    return {"rule": "cmd.timeout", "level": "nvme_command", "rowid": row, "cmd_rowid": row,
            "detail": {"kind": "never completed", "host_limit_ps": 30 * S, "median_ps": 17657750.0,
                       "cycle": {"reached": ["submitted", "fetched", "data"], "completed": False, "stopped_after": "data", "nak": 0, "unacked": 0}}}


# ----------------------------------------------------------------------------------------------------------------------- the S17 sample
def test_the_seven_timeout_errors_of_s17_get_the_causes_their_rows_justify(tree):
    con = sqlite3.connect(tree)
    rows = [r[0] for r in con.execute("SELECT cmd_rowid FROM finding WHERE rule='cmd.timeout' ORDER BY id")]
    assert sorted(rows) == sorted(EXPECTED), rows
    for row in rows:
        c, key, words = decided(con, row)
        assert key == EXPECTED[row], (row, key, words)
        if row == 144:
            assert c["after"] is None and c["abort"]["row"] == 145         # it completed: the rules for completed commands, unchanged
            continue
        a = c["after"]
        assert a["wait_end"] == "controller reset" and a["reset"]["row"] == RESET_OF[row] and a["aborts_unreadable"] == [] and a["others"]["answered"] > 0
        if row in ABORT_OF:                                              # a Write: its own Abort by the Abort's parameters, 30.000 s after its doorbell
            assert a["abort"]["row"] == ABORT_OF[row] and a["abort"]["names"] == [c["command"]["queue"], c["command"]["id"]]
            assert a["abort"]["after_doorbell_ps"] == 30000050000000 and c["abort"] == {"row": ABORT_OF[row], "after_doorbell_ps": 30000050000000}
            assert "Abort for this command 30.000 s after it was submitted (NVMe command row %d" % ABORT_OF[row] in words
            assert "answered %d other command(s)" % a["others"]["answered"] in words and a["others"]["answered_same_queue"] > 0
        else:                                                            # an Abort that was never answered: it names the Write that stopped first
            assert a["abort"] is None and a["names"]["row"] == a["first_stopped"]["row"] == {216: 155, 358: 295}[row]
            assert "less than the host's limit for it (60.000 s)" in words and "This command is the host's Abort for that command" in words
    con.close()


def test_the_measured_numbers_of_the_first_stall(tree):
    con = sqlite3.connect(tree)
    c, key, words = decided(con, 155)
    a = c["after"]
    assert a["first_stopped"] is None and "It was the first command to stop" in words
    assert a["reset"]["after_doorbell_ps"] == 60000051895000 and a["reset"]["after_abort_ps"] == 30000001895000
    assert a["abort"]["answered"] is False and "the drive did not answer the Abort either" in words
    assert "The controller was reset 60.000 s after this command was submitted" in words and "NVMe transaction row 3153, 30.000 s after the Abort" in words
    assert a["others"] == {"sent": 120, "answered": 119, "answered_same_queue": 34, "answered_admin": 0, "queues_answered": 3, "rows": [156, 157, 158, 159, 160]}
    assert not any(e["rule"] in EV.LINK_RULES for e in c["link_events"])  # the link was clean during the whole wait
    c2, key2, words2 = decided(con, 509)                                 # the second Write of the last episode: Write 443 stopped first, but it reached its own limit
    assert c2["after"]["first_stopped"]["row"] == 443 and c2["after"]["reset"]["after_doorbell_ps"] == 30001477358750 and c2["after"]["abort"]["answered"] is True
    assert "It was not the first command to stop: Write, NVMe command row 443 (queue 3, identifier 4) was sent 30.002 s earlier" in words2
    f = EV.facts(c, TM.defect_term(finding(con, 155)), key)
    assert "the host's Abort came 30.000 s after the doorbell (row 216)" in f["when"] and "the controller was reset 60.000 s after the doorbell" in f["when"]
    con.close()


def test_the_card_and_the_cause_do_not_depend_on_a_window_or_on_the_connection(tree):
    """The card is made from the error's own command: card() takes no window, and two readers get the same card, hash and cause."""
    assert list(inspect.signature(EV.card).parameters) == ["con", "f"]
    one, two = sqlite3.connect(tree), sqlite3.connect("file:%s?mode=ro" % tree, uri=True)
    for row in EXPECTED:
        c1, k1, w1 = decided(one, row)
        c2, k2, w2 = decided(two, row)
        assert c1 == c2 and EV.card_hash(c1) == EV.card_hash(c2) and (k1, w1) == (k2, w2)
        assert EV.decide_cause(json.loads(json.dumps(c1))) == (k1, w1)   # the stored card decides the same
    one.close()
    two.close()


def test_the_same_cause_with_a_small_and_a_large_window_on_the_page():
    """Through the page's own call, with 2 rows above and 1 below and with 40 and 40 (on a throw-away copy of the S17 upload's tree)."""
    import test_regression_tests as R
    root = tempfile.mkdtemp(prefix="cause_window_%d_" % os.getpid())
    try:
        app, c = R._app_with_s17(root)                                   # skips when that tree is not on this machine
        lv = ["nvme_transaction", "split", "link", "packets"]
        for fid, want in ((13, "device_internal_delay"), (138, "host_reset_or_driver_recovery")):
            runs = [c.post("/api/isolate/up-s17/%d/isolate" % fid, json={"anyway": True, "standin": True, "name": "t", "isolation": True, "levels": lv, "n": n, "m": m}).get_json()["isolation"]
                    for n, m in ((2, 1), (40, 40))]
            assert runs[0]["cause_key"] == runs[1]["cause_key"] == want, [r["cause_key"] for r in runs]
            assert runs[0]["card_hash"] == runs[1]["card_hash"] and runs[0]["cause_header"] == runs[1]["cause_header"] and runs[0]["card"]["after"] == runs[1]["card"]["after"]
    finally:
        shutil.rmtree(root, ignore_errors=True)


# ------------------------------------------------------------------------------------------------- hand-made recordings (rows removed)
def test_no_abort_at_all(copy):
    con = copy()
    aborts = [r[0] for r in con.execute("SELECT rowid_file FROM cmd WHERE opc=8 AND sqid=0")]
    con.executemany("DELETE FROM ntx WHERE parent_level='nvme_command' AND parent=?", [(a,) for a in aborts])
    con.execute("DELETE FROM cmd WHERE opc=8 AND sqid=0")
    con.commit()
    c, key, words = decided(con, 155)
    assert c["after"]["abort"] is None and c["abort"] is None and c["after"]["aborts_for_others"] == 0 and c["after"]["reset"]["row"] == 3153
    assert key == "device_internal_delay" and "The host sent no Abort for this command." in words and "The controller was reset 60.000 s" in words


def test_no_reset(copy):
    con = copy()
    remove_resets_after(con, 595444109750)
    c, key, words = decided(con, 155)
    a = c["after"]
    assert a["reset"] is None and a["wait_end"] == "end of the recording" and a["abort"]["row"] == 216
    assert key == "device_internal_delay" and "No controller reset followed before the recording ended" in words
    c2, key2, words2 = decided(con, 216)             # the Abort: no reset ended it, it was never answered while the drive answered others
    assert c2["after"]["reset"] is None and key2 == "device_internal_delay" and "host_reset" not in key2


def test_an_abort_for_another_command_is_not_given_to_this_one(copy):
    con = copy()
    pkt, raw = abort_packet(con, 216)
    b = raw["DATA"].split()
    assert b[40:44] == ["03", "00", "1A", "00"]                           # it names queue 3, identifier 26: the Write of row 155
    b[42] = "1B"
    set_data(con, pkt, raw, " ".join(b))                                  # now it names identifier 27, although it is as near in time as before
    c, key, words = decided(con, 155)
    assert c["after"]["abort"] is None and c["abort"] is None and c["after"]["aborts_for_others"] == 1
    assert key == "device_internal_delay" and "No Abort named this command (1 Abort sent during the wait named another command)" in words
    c2, key2, words2 = decided(con, 216)
    assert c2["after"]["names"]["id"] == 27 and key2 == "host_reset_or_driver_recovery" and "This command is the host's Abort for that command" not in words2


def test_a_reset_before_the_command_was_sent_is_not_its_reset(copy):
    con = copy()
    remove_resets_after(con, 60607286210250)                             # Write row 295 was sent 11.790 ms after the reset of row 3153
    c, key, words = decided(con, 295)
    a = c["after"]
    assert a["reset"] is None and a["episode_from"]["row"] in (3153, 3159) and a["first_stopped"] is None      # Write 155 belongs to the time before that reset
    assert key == "device_internal_delay" and "No controller reset followed" in words and "since the previous controller reset" in words


def test_two_stalls_on_two_queues(copy):
    con = copy()
    late = con.execute("SELECT rowid_file, sqid FROM cmd WHERE sqid NOT IN (0, 3) AND sct IS NOT NULL AND t_ps>? AND t_ps<? ORDER BY t_ps LIMIT 1", (160 * S, 180 * S)).fetchone()
    early = con.execute("SELECT rowid_file, sqid FROM cmd WHERE sqid NOT IN (0, 3) AND sct IS NOT NULL AND t_ps>? AND t_ps<? ORDER BY t_ps LIMIT 1", (121 * S, 140 * S)).fetchone()
    assert late and early
    f_late, f_early = stop_command(con, late[0]), stop_command(con, early[0])
    # sent less than the host's 30 s before the reset, while Write 443 had stopped first: only outstanding when the driver reset the controller
    c, key, words = decided(con, late[0], f_late)
    assert key == "host_reset_or_driver_recovery" and c["after"]["first_stopped"]["row"] == 443 and c["after"]["abort"] is None
    assert "less than the host's limit for it (30.000 s)" in words and "The command that stopped first was Write, NVMe command row 443" in words
    # sent more than 30 s before the reset on another queue: a stall of its own (no Abort names it), and the drive answered others meanwhile
    c2, key2, words2 = decided(con, early[0], f_early)
    assert key2 == "device_internal_delay" and c2["after"]["first_stopped"]["row"] == 443 and c2["command"]["queue"] == early[1] != 3
    assert c2["after"]["abort"] is None and c2["after"]["aborts_for_others"] >= 1 and "No Abort named this command" in words2
    # the first stall keeps its cause and its own Abort
    c3, key3, _w = decided(con, 443)
    assert key3 == "device_internal_delay" and c3["after"]["abort"]["row"] == 501 and c3["after"]["first_stopped"] is None and c3["after"]["outstanding_others"] == 3


def test_a_drive_that_answers_nothing_during_the_wait_is_a_firmware_stall(copy):
    con = copy()
    con.execute("UPDATE cmd SET st=NULL, sct=NULL, sc=NULL, dur_ps=NULL WHERE t_ps>? AND t_ps<=? AND rowid_file!=155", (595444109750, 60595496004750))
    con.commit()
    c, key, words = decided(con, 155)
    assert c["after"]["others"]["answered"] == 0 and c["after"]["others"]["sent"] == 120
    assert key == "firmware_stall" and "answered no other command on any queue (120 were sent, none was answered)" in words and "30.000 s after it was submitted" in words


def test_a_reset_before_the_limit_with_nothing_else_outstanding_is_not_decided(copy):
    con = copy()
    late = con.execute("SELECT rowid_file FROM cmd WHERE sqid NOT IN (0, 3) AND sct IS NOT NULL AND t_ps>? AND t_ps<? ORDER BY t_ps LIMIT 1", (40 * S, 55 * S)).fetchone()
    f = stop_command(con, late[0])
    con.execute("DELETE FROM cmd WHERE rowid_file IN (155, 216)")        # nothing stopped before it
    con.commit()
    c, key, words = decided(con, late[0], f)
    assert key == "unknown_cause" and "before the host's limit for it (30.000 s), and no earlier command was outstanding" in words


# --------------------------------------------------------------------------------------------------------------------- damaged rows
@pytest.mark.parametrize("cell", ["08 00 0F 00 ?? 00", "64 B", "", None, "08 00 0F 00"])
def test_a_damaged_abort_row_gives_unknown_cause_with_a_reason(copy, cell):
    con = copy()
    pkt, raw = abort_packet(con, 216)
    if cell is None:
        con.execute("UPDATE pkt SET raw='{not json' WHERE rowid_file=?", (pkt,))
        con.commit()
    else:
        set_data(con, pkt, raw, cell)
    c, key, words = decided(con, 155)
    assert key == "unknown_cause" and c["after"]["abort"] is None and c["after"]["aborts_unreadable"][0]["row"] == 216
    assert "An Abort".lower() in words.lower() and "30.000 s after this command was submitted (NVMe command row 216)" in words
    assert "cannot be read" in words and "does not decide by nearness in time" in words
    assert decided(con, 295)[1] == "device_internal_delay"               # the other errors are not touched by it


def test_a_damaged_reset_row_and_a_tree_without_packets_do_not_crash(copy):
    con = copy()
    link = con.execute("SELECT rowid_file FROM lnk WHERE parent_level='nvme_transaction' AND parent=3153").fetchone()[0]
    p = con.execute("SELECT rowid_file, raw FROM pkt WHERE parent_level='link' AND parent=? AND tlp_type LIKE 'MWr%'", (link,)).fetchone()
    set_data(con, p[0], json.loads(p[1]), "zz 00 46 00")
    c, key, words = decided(con, 155)
    assert key == "unknown_cause" and "cannot tell whether the controller was reset" in words and c["after"]["register_writes_unreadable"][0]["row"] == 3153
    con2 = copy()
    con2.execute("DROP TABLE pkt")                                        # a recording loaded without its packets file
    con2.commit()
    c2, key2, words2 = decided(con2, 155)
    assert key2 == "unknown_cause" and c2["after"]["unreadable"] and "could not be read from the tree" in words2
    assert EV.decide_cause({"rule": "cmd.timeout", "completed": False})[0] == "unknown_cause"      # a card without the section: never a guess


def test_a_command_whose_own_identifier_cannot_be_read_and_more_aborts_than_are_examined(copy, monkeypatch):
    con = copy()
    con.execute("UPDATE cmd SET cid=NULL WHERE rowid_file=155")
    con.commit()
    c, key, words = decided(con, 155)
    assert key == "unknown_cause" and "own queue or identifier cannot be read" in words
    monkeypatch.setattr(EV, "LOOK", 0)                                    # nothing is examined: the answer is "cannot tell", never "no Abort" or "no reset"
    c2, key2, words2 = decided(con, 295)
    assert key2 == "unknown_cause" and c2["after"]["abort"] is None and "none of them names this command" in words2
