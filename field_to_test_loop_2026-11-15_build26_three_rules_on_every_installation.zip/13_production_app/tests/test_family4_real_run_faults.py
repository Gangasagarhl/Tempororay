"""Family 4 after the real-model run on an unknown CSV (2026-11-14, research note E): the three faults that run found, and the
optional link to the REA agent.

What must hold:
  1. the dead end: an answer of the admin that adds an output column leads to a changed procedure, shown before / after on
     the requirements card and stored when he approves, or to a plain question; no round of code starts while the
     requirements and the procedure contradict each other on the output columns; the same failing check twice for a cause
     no change of the code can repair stops the rounds with the reason;
  2. a surprise, a conflict and an open decision of the Data researcher are shown, and asked, only with the measured fact
     that supports them; what the data does not support is dropped into the record and never becomes a question;
  3. the Tester's final position on a finding is one of fixed words decided by code; a withdrawn finding does not block
     the approval, a kept one does;
  4. REA: with findings and the admin's tick the questions go to the REA agent and its quoted answers are in the ledger with
     file and lines; an answer without a quote is refused; without the tick, or without findings, nothing of REA is called;
  5. hostile answers at each new point end in a plain message, never in a crash.

No server and no model: the scripted model of tests/test_family4.py (its Lab)."""
import json
import os
import sys
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import family1, family3, family4, procedures as PR, rea_agent as RA  # noqa: E402
import test_family4 as T  # noqa: E402

GOOD3 = T.GOOD.replace('w.writerow(["City", "count"])', 'w.writerow(["City", "count", "Minutes"])').replace("w.writerow([v, k])", "w.writerow([v, k, 0])")
PROC3 = {"source_data": T.PROC["source_data"], "steps": T.PROC["steps"][:3] + ["Output one line per city: City, count, Minutes; the largest count first, then the city by name."],
         "output": {"columns": ["City", "count", "Minutes"], "order": "count, largest first; then City"}}
ASK = "Should the minutes be an output column too?"


@pytest.fixture
def lab(tmp_path, monkeypatch):
    return T.Lab(tmp_path, monkeypatch).start()


def answer_then(extra):
    """The Requirements agent asks once; after the admin's answer it returns what the test gives."""
    def req(ctx, n):
        if not ctx["ADMIN_SAID"]["answers"]:
            return T.req_answer(questions=[ASK])
        return dict(T.req_answer(), requirements=["Read visits.csv.", "Count the rows of each city.", "Write City, count, Minutes."], **extra)
    return req


def send(lab, text="yes: add Minutes as a third output column"):
    lab.decide("change", edits={"answers": {"0": text}})
    return lab.work()


# ---------------------------------------------------------------------------------------------- 1. the dead end
def test_an_answer_that_adds_an_output_column_changes_the_procedure_and_the_admin_confirms_it(lab):
    lab.req = answer_then({"output_columns": ["City", "count", "Minutes"], "procedure": PROC3, "procedure_changes": ["Minutes is a third output column"]})
    lab.coder = lambda ctx, n: {"notes": ["three columns"], "code": GOOD3}
    lab.tester = lambda ctx, n: {"cases": [], "remarks": [], "replies": [], "nothing_more": True}
    lab.work()
    assert lab.out("req")["procedure_change"] is None and lab.out("req")["output_conflict"] is None          # nothing said yet: nothing changes
    send(lab)
    out, rv = lab.out("req"), lab.review()
    assert out["output_conflict"] is None and out["procedure_change"]["after"]["output"]["columns"] == ["City", "count", "Minutes"]
    assert "**The procedure changed: before / after.**" in rv["body"] and "Before (version 1): output columns **City, count**" in rv["body"]
    assert "After (to be confirmed by you): output columns **City, count, Minutes**" in rv["body"] and "← changed" in rv["body"]
    assert "Approving these requirements confirms the changed procedure" in rv["body"] and rv["data"]["f4_procedure_change"]["changes"] == ["Minutes is a third output column"]
    assert lab.rule()["procedure"]["output"]["columns"] == ["City", "count"] and "coder" not in lab.calls     # nothing stored, nothing coded before he confirms
    lab.decide("approve")
    r = lab.rule()
    assert r["procedure"]["version"] == 2 and r["procedure"]["output"]["columns"] == ["City", "count", "Minutes"] and "confirmed" in r["procedure"]["note"]
    assert r["coding"]["requirements"]["procedure_sha"] == PR.sha(r["procedure"]) and r["coding"]["requirements"]["procedure_changed_from_version"] == 1
    lab.work()
    code = lab.out("code")
    assert lab.of("coder")[0]["PROCEDURE"]["output"]["columns"] == ["City", "count", "Minutes"]              # the first round already has the agreed columns
    assert code["rounds_used"] == 1 and code["clean"] and code["unrepairable"] is None
    assert all(c["ok"] for c in code["checks"] if c["check"].startswith("the output has the procedure's columns"))


def test_without_a_changed_procedure_the_contradiction_is_a_plain_question_and_no_code_round_starts(lab):
    lab.req = answer_then({"output_columns": ["City", "count", "Minutes"]})
    lab.work()
    send(lab)
    out, rv = lab.out("req"), lab.review()
    q = out["questions"][0]
    assert q["kind"] == "output_conflict" and "The requirements say the output columns are: City, count, Minutes" in q["question"] and "says: City, count. Which is meant?" in q["question"]
    assert out["output_conflict"]["procedure_says"] == ["City", "count"] and "do not agree on the output columns" in rv["body"] and rv["data"]["open"] >= 1
    for edits in (None, {"accept_open": True}):
        with pytest.raises(ValueError, match="no round of code starts"):
            lab.decide("approve", edits=edits)                                              # also the tick "go on with the open points" does not start the code
    assert lab.step("code")["state"] == "waiting" and "coder" not in lab.calls and lab.rule()["procedure"]["output"]["columns"] == ["City", "count"]


def test_the_contradiction_is_found_in_the_requirements_text_when_the_agent_gives_no_list(lab):
    lab.req = answer_then({})                                    # the real run's shape: "Write City, count, Minutes." and no list of columns
    lab.work()
    send(lab)
    out = lab.out("req")
    assert out["output_columns"] == ["City", "count", "Minutes"] and out["output_conflict"]["said_in"] == "requirement R3"
    with pytest.raises(ValueError, match="no round of code starts"):
        lab.decide("approve", edits={"accept_open": True})


def test_a_changed_procedure_is_not_taken_without_the_admins_words_or_when_it_names_what_the_data_lacks(lab):
    lab.req = lambda ctx, n: dict(T.req_answer(), procedure=PROC3, output_columns=["City", "count"])
    lab.work()
    out = lab.out("req")
    assert out["procedure_change"] is None and "although you said nothing" in out["procedure_note"] and "Note: the Requirements agent proposed" in lab.review()["body"]
    lab.decide("approve")
    assert lab.rule()["procedure"]["version"] == 1


def test_the_same_check_failing_twice_for_a_cause_no_code_can_repair_stops_the_rounds_with_the_reason(lab):
    lab.coder = lambda ctx, n: {"notes": ["three columns, as I read the requirements"], "code": GOOD3 + "# round %d\n" % n}
    lab.tester = lambda ctx, n: {"cases": [], "remarks": [], "replies": [], "nothing_more": True}
    st = lab.to_code_review(rounds=8)
    out, body = lab.out("code"), lab.review()["body"]
    assert st["state"] == "needs_review" and out["rounds_used"] == 2 and out["rounds_most"] == 8 and lab.calls.count("coder") == 2       # 2 of 8 rounds, not 8
    assert out["unrepairable"]["the_code_writes"] == ["City", "count", "Minutes"] and out["unrepairable"]["the_procedure_says"] == ["City", "count"]
    assert "the same check failed in two rounds for a cause no change of the code can repair" in out["stopped_because"]
    assert "**The rounds were stopped early: no change of the code can repair this.**" in body and "that is yours to say" in body and not out["clean"]
    assert lab.of("coder")[1]["WHAT_FAILED"][0]["what"].startswith("the output has the procedure's columns")       # the Coder was told in between


# ---------------------------------------------------------------------------------------------- 2. nothing without its measured fact
def real_run_record():
    """The words, surprises and conflict of the real run's record (research note E), with the measured block they came from."""
    f, no = "cmd_trace_export.csv", lambda t, q=True: {"text": t, "in_quotation_marks": q, "found": [], "nearest": [], "part_of": []}
    word = lambda t: "The rule's word “%s” is in no column of the files it reads; nothing like it was found (a value to look for, or a name the output writes)." % t
    names = ["Result", "never got a completion", "T Done [ns]", "QID", "Tag"]
    near = {"file": f, "column": "Result", "spelling": "ABORTED_BY_REQ", "rows": 1}
    block = {"file": f, "column": "Result", "in_the_file": True, "rows": 608, "rows_with_a_value": 608, "basis": "exact: all 608 rows", "nothing": [],
             "most_frequent": [{"value": "OK", "rows": 601}, {"value": "PENDING", "rows": 6}, {"value": "ABORTED_BY_REQ", "rows": 1}]}
    return {"files": [{"file": f, "columns": [{"column": c} for c in ("Idx", "QID", "Tag", "Result", "T Done [ns]")], "touched": [block]}],
            "words": [no(n) for n in names] + [dict(no("ok or aborted_by_req", False), nearest=[near])],
            "surprises": ["%s column T Done [ns]: an empty cell in 6 of the 608 rows (first at line 156, 217, 296) (exact: all 608 rows)." % f] + [word(n) for n in names]
            + ["The rule's word “ok or aborted_by_req” is in no column of the files it reads; nearest: “ABORTED_BY_REQ” in %s column Result (1 row)." % f],
            "conflicts": [{"kind": "the rule against the data", "what": "the rule says “ok or aborted_by_req”, and no column of the files it reads holds that value", "settled": False,
                           "a": {"says": "x", "source": "the rule's words (the admin)"}, "b": {"says": "y", "source": "the data, counted by the program"},
                           "question": "The rule says “ok or aborted_by_req”. Is that what is meant?"}],
            "hidden": [{"id": "H1", "kind": "empty values", "decision": "what the code does with an empty T Done [ns]", "because": "6 of the 608 rows hold nothing there", "by": "the program"}],
            "ledger": [{"what": "the rule's word “Result”", "kind": "word of the rule", "state": "to decide", "source": "in no column of the files the rule reads", "detail": "x"}],
            "researchers": {}}


def test_the_false_surprises_and_the_false_conflict_of_the_real_run_are_dropped_and_the_true_one_stays():
    said = []
    rec = family4.ground_research(real_run_record(), {"headers": {}}, said.append)
    assert rec["surprises"] == ["cmd_trace_export.csv column T Done [ns]: an empty cell in 6 of the 608 rows (first at line 156, 217, 296) (exact: all 608 rows)."]
    assert rec["surprise_facts"][0]["text"] == rec["surprises"][0] and rec["surprise_facts"][0]["measured_fact"]
    assert rec["conflicts"] == [] and len(rec["hidden"]) == 1                                # the conflict that became question 1 of the real run is gone
    why = {d["what"]: d["why"] for d in rec["not_supported"]}
    assert len(rec["not_supported"]) == 7 and [d["kind"] for d in rec["not_supported"]].count("conflict") == 1
    assert "is the name of a column of cmd_trace_export.csv" in next(v for k, v in why.items() if "“Result”" in k)
    assert "no count, value or row of the data supports it" in next(v for k, v in why.items() if "never got a completion" in k)
    both = next(v for k, v in why.items() if k.startswith("the rule says"))
    assert "names 2 values, and the data holds each of them" in both and "“OK” in cmd_trace_export.csv column Result (601 rows)" in both and "“ABORTED_BY_REQ”" in both
    assert rec["ledger"][0]["state"] == "established" and "name of a column" in rec["ledger"][0]["source"]
    assert said and "left out 7 statements the measured data does not support" in said[0]


def test_of_three_things_the_data_researcher_raises_only_the_one_the_data_supports_is_shown_and_asked(lab):
    lab.settle_hidden = False
    lab.research = lambda ctx, n: {"matters": [], "doubts": [], "hidden_decisions": [
        {"column": "City", "kind": "other", "decision": "is the city Goa counted like every other city, or apart"},
        {"column": "City", "kind": "empty values", "decision": "what happens to a visit whose city cell is empty"},        # no City cell is empty in this file
        {"column": "", "kind": "other", "decision": "what happens to visits made on a public holiday"}]}                    # nothing in the data shows it
    lab.work()
    rec, out, rv = lab.out("research")["record"], lab.out("req"), lab.review()
    mine = [h for h in rec["hidden"] if h.get("by") != "the program"]
    assert [h["decision"] for h in mine] == ["is the city Goa counted like every other city, or apart"]
    assert mine[0]["measured_fact"] == "visits.csv column City holds “Goa” in 2 rows (exact: all 6 rows)" and mine[0]["because"].startswith("measured by the program: ")
    gone = [d for d in rec["not_supported"] if d["kind"] == "open decision raised by the Data researcher"]
    assert sorted(d["what"] for d in gone) == ["what happens to a visit whose city cell is empty", "what happens to visits made on a public holiday"]
    asked = " ".join(q["question"] for q in out["questions"])
    assert "Goa counted like every other city" in asked and "city cell is empty" not in asked and "public holiday" not in asked
    assert "city cell is empty" not in rv["body"] and "public holiday" not in rv["body"] and "visits.csv column City holds “Goa” in 2 rows" in rv["body"]
    assert any("have a space at an end" in s for s in rec["surprises"]) and len(rec["surprise_facts"]) == len(rec["surprises"])     # the counted surprise stays, with its fact


# ---------------------------------------------------------------------------------------------- 3. the Tester's position, in fixed words
def test_the_testers_position_is_one_of_fixed_words_decided_by_code():
    assert family4.tester_position({"case": "x", "keep": False, "why": "my expectation was wrong"}) == ("withdrawn", "my expectation was wrong")
    assert family4.tester_position({"keep": True, "why": "step 3 is on my side"}) == ("kept", "step 3 is on my side")
    assert family4.tester_position({"keep": True, "why": "I withdraw it. The header came from the old list."})[0] == "not clear"      # the real run's card
    assert family4.tester_position({"keep": False, "why": "I keep it"})[0] == "not clear"
    assert family4.tester_position({"keep": "false", "why": "x"})[0] == "withdrawn" and family4.tester_position({"keep": "yes"})[0] == "kept"
    for bad in (None, "I withdraw it", 7, [], {}, {"keep": None}, {"keep": "perhaps"}, {"keep": 0}, {"keep": [False], "why": {"a": 1}}):
        assert family4.tester_position(bad)[0] == "not answered"
    assert set(family4.POSITION_MEANS) == {"kept", "withdrawn", "not answered", "not clear"}


CRASH = T.GOOD.replace("            n += 1\n", "            n += 1\n            _third = row[2]\n")       # stops on a line cut short after its first cell
CUT = "one record cut short after its first cell"


def test_a_finding_the_tester_withdrew_has_the_fixed_word_and_does_not_block_the_approval_also_on_the_programs_data_set(lab):
    lab.coder = lambda ctx, n: {"code": CRASH + "# %d\n" % n, "objections": [] if n == 0 else [{"case": CUT, "why": "the requirements say every line has its three cells"}]}
    lab.tester = lambda ctx, n: {"cases": [], "remarks": [], "replies": [{"case": o["case"], "keep": False, "why": "I withdraw it. The Coder is right."} for o in ctx.get("OBJECTIONS") or []]}
    lab.to_code_review()
    out, body = lab.out("code"), lab.review()["body"]
    case = next(c for c in out["cases"] if c["name"] == CUT)
    assert case["by"] == "the program" and case["status"] == "withdrawn" and case["tester_position"] == "withdrawn"       # before: "for the admin to judge", for ever
    assert out["set_aside"] == [] and out["failing"] == [] and out["withdrawn"] == [CUT] and out["clean"]
    assert "**Withdrawn (1): these findings do not stand against the code and need no decision of yours.**" in body
    assert "the Tester's position: **withdrawn**" in body and "keeps it" not in body and "For you to judge" not in body
    lab.decide("approve")                                                                   # no reason is asked for: nothing is open
    assert lab.rule()["code"]["verified_by"] == "Sagar"


def test_a_finding_the_tester_keeps_has_the_fixed_word_and_blocks_the_approval(lab):
    lab.coder = lambda ctx, n: {"code": T.GOOD, "objections": [] if n == 0 else [{"case": "two cities once each", "why": "each city is met once"}]}
    lab.tester = lambda ctx, n: {"cases": [T.WRONG_CLAIM] if n == 0 else [], "remarks": [],
                                 "replies": [{"case": o["case"], "keep": True, "why": "step 3 counts visitors"} for o in ctx.get("OBJECTIONS") or []]}
    lab.to_code_review()
    out, body = lab.out("code"), lab.review()["body"]
    assert out["set_aside"] == ["two cities once each"] and next(c for c in out["cases"] if c["name"] == "two cities once each")["tester_position"] == "kept"
    assert "the Tester's position: **kept** (the Tester keeps its finding: it stays open for you to judge). Its reason: step 3 counts visitors" in body
    with pytest.raises(ValueError, match="not settled"):
        lab.decide("approve")


def test_a_reply_that_says_both_is_not_clear_and_the_card_never_says_keeps_it_i_withdraw_it(lab):
    lab.coder = lambda ctx, n: {"code": T.GOOD, "objections": [] if n == 0 else [{"case": "two cities once each", "why": "each city is met once"}]}
    lab.tester = lambda ctx, n: {"cases": [T.WRONG_CLAIM] if n == 0 else [], "remarks": [],
                                 "replies": [{"case": o["case"], "keep": True, "why": "I withdraw it."} for o in ctx.get("OBJECTIONS") or []]}
    lab.to_code_review()
    body = lab.review()["body"]
    assert "the Tester's position: **not clear** (the Tester's answer says both: it stays open for you to judge). Its reason: I withdraw it." in body and "keeps it" not in body
    with pytest.raises(ValueError, match="not settled"):
        lab.decide("approve")


def test_a_data_set_carried_from_the_build_before_is_settled_again_by_code(lab):
    """The real run: four data sets set aside in the first build were carried into the clean second build and refused it."""
    lab.to_code_review()
    b = family4.Build.__new__(family4.Build)
    b.proc = PROC3
    b.cases = [{"name": "the header only, no record", "by": "the program", "status": family4.SET_ASIDE, "objection": "o", "tester_reply": "I withdraw it.", "expected_rows": None},
               {"name": "two columns", "by": "the Tester", "status": family4.SET_ASIDE, "expected_rows": [["Pune", 2]]},
               {"name": "three columns", "by": "the Tester", "status": "passed", "expected_rows": [["Pune", 2, 0]]}]
    b._settle_carried()
    assert "status" not in b.cases[0] and "objection" not in b.cases[0]                         # the program's own data set runs again on the new code
    assert b.cases[1]["status"] == "withdrawn" and b.cases[1]["tester_position"] == "withdrawn" and b.cases[1]["withdrawn_by"] == "the program"
    assert "do not have the 3 columns the output has now" in b.cases[1]["tester_reply"] and b.cases[2]["status"] == "passed"


# ---------------------------------------------------------------------------------------------- 4. the REA agent, only when asked
class Spy:
    def __init__(self, monkeypatch, answer=None):
        self.calls, self.answer = [], answer
        monkeypatch.setattr(RA, "ask_for_family4", self.ask4)
        for name in ("ask", "search", "is_read", "done", "join_hits", "status", "identity", "chat"):
            monkeypatch.setattr(RA, name, self.touch(name))

    def touch(self, name):
        def f(*a, **k):
            self.calls.append(name)
            raise AssertionError("the REA agent's %s was called" % name)
        return f

    def ask4(self, engine, project, questions, most=6):
        self.calls.append(("ask_for_family4", list(questions)))
        return self.answer(questions) if callable(self.answer) else self.answer


def with_findings(lab, tmp_path):
    folder = str(tmp_path / "rea_findings")
    os.makedirs(folder, exist_ok=True)
    lab.store.exec("UPDATE project SET rea=? WHERE id=?", (folder, lab.pid))
    return folder


def test_without_the_tick_nothing_of_rea_is_called_and_the_card_says_it_is_optional(lab, tmp_path, monkeypatch):
    spy = Spy(monkeypatch)
    folder = with_findings(lab, tmp_path)
    lab.to_code_review()
    assert spy.calls == []                                                                   # not the question, not the index, not even "is it read"
    rea = lab.out("req")["rea"]
    assert rea["given"] and rea["wanted"] is False and rea["answers"] == [] and rea["folder"] == folder
    body = next(r for r in lab.store.all("SELECT * FROM review WHERE run=? ORDER BY id", (lab.rid,)))["body"]
    assert "**The REA findings (optional, not used).**" in body and "has not looked at them" in body and "Ask the REA agent" in body
    assert all(x["kind"] != "REA" for x in lab.out("req")["ledger"]) and "REA_ANSWERS" not in lab.of("requirements")[0]


def test_without_findings_nothing_of_rea_is_called_with_or_without_the_tick(lab, monkeypatch):
    spy = Spy(monkeypatch)
    lab.req = lambda ctx, n: T.req_answer(questions=[ASK] if n == 0 else [])
    lab.work()
    assert lab.out("req")["rea"] is None and "REA" not in lab.review()["body"]
    lab.decide("change", edits={"use_rea": True})                                             # the tick alone is an answer the card takes
    lab.work()
    rea = lab.out("req")["rea"]
    assert spy.calls == [] and rea["wanted"] and rea["usable"] is False and "no REA findings are kept with this analysis" in rea["why"]
    assert "you asked for them, and they could not be used" in lab.review()["body"]


def test_with_findings_and_the_tick_the_questions_go_to_the_rea_agent_and_only_quoted_answers_enter_the_ledger(lab, tmp_path, monkeypatch):
    quoted = {"file": "nvme_layer.txt", "lines": "1-24", "quote": "SQID and CID identify a command"}
    spy = Spy(monkeypatch, lambda qs: {"available": True, "folder": "x", "answers": [
        {"question": qs[0], "found": True, "answer": "A command is known by its queue and its identifier.", "sources": [quoted], "producer": "a model (test)"},
        {"question": "another", "answer": "The analyzer surely merges repeated visits.", "sources": []}]})        # good words, no quote
    with_findings(lab, tmp_path)
    lab.req = lambda ctx, n: (T.req_answer(questions=[ASK]) if n == 0 else
                              dict(T.req_answer(), requirements=[{"text": "Read visits.csv.", "rests_on": ["REA2", 7, None]}, {"text": "Count the rows of each City.", "rests_on": ["REA1"]}, "Write City, count."]))
    lab.work()
    assert spy.calls == []                                                                   # off until the admin ticks it
    lab.decide("change", edits={"use_rea": True, "answers": {"0": "no"}})
    lab.work()
    assert [c[0] for c in spy.calls] == ["ask_for_family4"] and ASK in spy.calls[0][1]          # the question the research raised went to the REA agent
    out, body = lab.out("req"), lab.review()["body"]
    a, b = out["rea"]["answers"]
    assert a["id"] == "REA1" and a["found"] and a["sources"] == [quoted]
    assert b["found"] is False and b["answer"] == "not found in the findings" and "without words quoted" in b["why"] and "surely merges" not in json.dumps(out)
    line = next(x for x in out["ledger"] if x["kind"] == "REA" and x["state"] == "established")
    assert "nvme_layer.txt, lines 1-24: “SQID and CID identify a command”" in line["source"] and line["detail"].startswith("A command is known")
    assert next(x for x in out["ledger"] if x["kind"] == "REA" and x["state"] == "to decide")["source"] == "the REA agent: not found in the findings"
    r2 = out["requirement_rests_on"]["R2"]                                                    # all four kinds of evidence, each named with what it is
    assert [x["basis"] for x in r2] == ["the admin's words", "Family 1's answer", "a measured fact of the data research", "a REA answer"]
    assert r2[1]["what"].startswith("yes for ") and "visits.csv column City: 6 of the 6 rows hold a value" in r2[2]["what"] and "nvme_layer.txt, lines 1-24" in r2[3]["what"]
    assert [x["basis"] for x in out["requirement_rests_on"]["R1"]] == ["the admin's words"]      # REA2 has no quote: nothing rests on it
    assert "  - rests on: the admin's words: " in body and "Family 1's answer: yes for " in body
    assert next(x for x in out["ledger"] if x["what"] == "requirement R2")["source"].count("a REA answer: REA1") == 1
    assert "**REA1**" in body and "*(source: nvme_layer.txt, lines 1-24: “SQID and CID identify a command”)*" in body and "→ **not found in the findings**" in body
    seen = lab.of("requirements")[-1]["REA_ANSWERS"]
    assert seen[0]["quoted_from_the_findings"] == [quoted] and seen[1]["answer"] == "not found in the findings"
    lab.decide("approve")
    lab.work()
    code_body = lab.review()["body"]
    assert "**What each requirement rests on**" in code_body and "- **R2**: the admin's words: " in code_body and "a REA answer: REA1: nvme_layer.txt, lines 1-24" in code_body
    given = lab.of("coder")[0]["REQUIREMENTS"]["rea_answers_quoted_from_the_findings"]
    assert [x["id"] for x in given] == ["REA1"] and given[0]["quoted"] == [quoted]                # the Coder gets only the quoted answer, to cite


def test_the_rea_agents_function_for_family_4_refuses_an_answer_whose_quote_is_not_in_the_findings(tmp_path, monkeypatch):
    know = str(tmp_path / "knowledge")
    monkeypatch.setattr(family1, "knowledge_dir", lambda: know)
    monkeypatch.setattr(RA, "IDENTITY_KEPT_S", 0)
    folder = tmp_path / "findings"
    folder.mkdir()
    (folder / "nvme_layer.txt").write_text("nvme layer\ncommand_of(sqe) { key = (sqe.SQID << 16) | sqe.CID; }   // SQID and CID identify a command\n", encoding="utf-8")
    answers = [{"answer": "By queue and identifier.", "sources": [{"passage": 0, "quote": "SQID and CID identify a command"}], "search_more": []},
               {"answer": "It retries three times.", "sources": [{"passage": 0, "quote": "retry_count = 3"}], "search_more": []}]          # a made-up quote

    def ask(run_id, agent, instruction, context, shape, must_have, standin, **kw):
        return answers.pop(0), "a model (test)", None
    eng = types.SimpleNamespace(runner=types.SimpleNamespace(ask=ask))
    project = {"rea": str(folder)}
    assert RA.ask_for_family4(eng, project, ["x"])["available"] is False                          # not read yet: said, nothing asked
    assert RA.ask_for_family4(eng, {}, ["x"]) == {"available": False, "why": "no REA findings were given for this analysis", "answers": []}
    RA.read(str(folder))
    got = RA.ask_for_family4(eng, project, ["How does the analyzer identify an NVMe command (SQID, CID)?", "How often is a command retried (SQID)?", "", 5, None])
    one, two = got["answers"]
    assert one["found"] and one["sources"][0]["file"] == "nvme_layer.txt" and one["sources"][0]["lines"] and one["sources"][0]["quote"] == "SQID and CID identify a command"
    assert two == {"question": "How often is a command retried (SQID)?", "found": False, "answer": "not found in the findings", "sources": [],
                   "why": "the answer came without words quoted from the findings, so it is not used", "producer": "a model (test)"}
    assert [t["who"] for t in RA.chat(str(folder))] == ["Family 4", "REA agent", "Family 4", "REA agent"]
    for bad in (None, "text", 5, {"answer": 7, "sources": "x"}, {"answer": "a", "sources": [{"file": 1, "lines": None, "quote": []}, "s", None]}, {"answer": "a" * 100000, "sources": [{}]}):
        assert RA.checked_answer("q", bad)["found"] is False and RA.checked_answer("q", bad)["answer"] == "not found in the findings"


# ---------------------------------------------------------------------------------------------- 5. hostile answers
HOSTILE_REQ = [{"output_columns": "City"}, {"output_columns": [1, None, {}]}, {"output_columns": ["x" * 5000]}, {"output_columns": []}, {"output_columns": ["City"] * 500},
               {"procedure": "change it"}, {"procedure": []}, {"procedure": {"steps": 5}}, {"procedure": {"source_data": "x", "steps": ["a"], "output": 3}},
               {"procedure": dict(PROC3, steps=["x" * 200000])}, {"procedure_changes": {"a": 1}, "procedure": PROC3},
               {"procedure": dict(PROC3, source_data=[{"file": "visits.csv", "columns": ["City", "Shoe size"]}])},          # an invented column name
               {"procedure": dict(PROC3, source_data=[{"file": "other.csv", "columns": ["City"]}])},
               {"requirements": [{"text": "Read visits.csv.", "rests_on": "REA1"}, {"text": 5, "rests_on": [[1]]}, {"rests_on": ["REA9"]}, None, "Write City, count."]}]


@pytest.mark.parametrize("extra", HOSTILE_REQ, ids=lambda e: json.dumps(e)[:60])
def test_a_hostile_requirements_answer_ends_in_a_plain_card_never_in_a_crash(tmp_path, monkeypatch, extra):
    lab = T.Lab(tmp_path, monkeypatch).start()
    lab.req = lambda ctx, n: T.req_answer(questions=[ASK]) if n == 0 else dict(T.req_answer(), **extra)
    lab.work()
    st = send(lab, "leave the output as it is")
    out = lab.out("req")
    assert st["state"] == "needs_review" and out["procedure_change"] is None or out["procedure_change"]["after"]["output"]["columns"]
    assert isinstance(lab.review()["body"], str) and "Traceback" not in lab.review()["body"]
    if isinstance(extra.get("procedure"), (str, list)) or "steps" in str(extra.get("procedure"))[:12] or "Shoe size" in json.dumps(extra) or "other.csv" in json.dumps(extra):
        assert out["procedure_change"] is None
    if "Shoe size" in json.dumps(extra):
        assert "names visits.csv: Shoe size, which the data does not have" in out["procedure_note"]
    assert lab.rule()["procedure"]["version"] == 1                                              # nothing is stored without the admin's approval


def test_hostile_answers_of_the_researcher_the_tester_and_the_rea_agent_end_in_plain_words(lab, tmp_path, monkeypatch):
    spy = Spy(monkeypatch, {"available": True, "answers": [None, "x", {"answer": {"a": 1}, "sources": [5]}, {"question": 9, "answer": "y" * 50000, "sources": [{"file": "f", "lines": "1", "quote": ""}]}]})
    with_findings(lab, tmp_path)
    lab.settle_hidden = False
    lab.research = lambda ctx, n: {"matters": "x", "doubts": 5, "hidden_decisions": [None, 7, {"column": "City", "kind": ["x"], "decision": "d" * 9000}, {"column": "Nowhere", "decision": "q"},
                                                                                   {"column": 3, "kind": None, "decision": {"a": 1}}]}
    lab.req = lambda ctx, n: T.req_answer(questions=[ASK] if n == 0 else [])
    lab.coder = lambda ctx, n: {"code": T.GOOD, "objections": [] if n == 0 else [{"case": "two cities once each", "why": "each city is met once"}]}
    lab.tester = lambda ctx, n: {"cases": [T.WRONG_CLAIM] if n == 0 else [], "remarks": [], "replies": [{"case": o["case"], "keep": {"x": 1}, "why": ["a", "b"]} for o in ctx.get("OBJECTIONS") or []] + [None, 5]}
    lab.work()
    assert [h for h in lab.out("research")["record"]["hidden"] if h.get("by") != "the program"] == []        # none of them has a measured fact
    lab.decide("change", edits={"use_rea": True, "answers": {"0": "no"}})
    assert lab.work()["state"] == "needs_review"
    rea = lab.out("req")["rea"]
    assert rea["usable"] and [a["found"] for a in rea["answers"]] == [False] * 4 and "yyyy" not in lab.review()["body"]
    lab.decide("approve")
    assert lab.work()["state"] == "needs_review"
    case = next(c for c in lab.out("code")["cases"] if c["name"] == "two cities once each")
    assert case["tester_position"] == "not answered" and "the Tester's position: **not answered**" in lab.review()["body"]
    for bad in ({"use_rea": "yes"}, {"use_rea": 1}, {"use_rea": None}):                           # the tick is true or false, nothing else
        with pytest.raises(ValueError):
            family4.on_change(lab.eng, {"id": lab.rid}, dict(lab.step("req"), full_key="req"), {"edits": bad}, "Sagar", "")
    spy2 = Spy(monkeypatch, lambda qs: (_ for _ in ()).throw(OSError("the disk is gone")))
    ctx = types.SimpleNamespace(project={"rea": "/nowhere"}, input={"use_rea": True}, engine=lab.eng)
    got = family4.rea_for(ctx, None, [{"question": "q"}])
    assert spy2.calls and got["usable"] is False and "the REA agent could not be asked (the disk is gone)" in got["why"]


def test_the_prompt_documents_say_the_new_rules_and_keep_their_layout():
    from agentic import prompts
    for name, must in (("f4_requirements", ["`output_columns`", "`procedure_changes`", "`REA_ANSWERS`", "You do not change the procedure on your own reading"]),
                       ("f4_data_research", ["A decision for which it finds no such fact is dropped"]),
                       ("f4_tester", ["\"kept\" or \"withdrawn\""]), ("f4_coder", ["`# REA1`", "do not choose between them"])):
        text = prompts.load(name, questions_most=8, cases_per_round=5)
        for head in ("## Who you are", "## What you are given", "## What to do", "## What you do not do, and why", "## How to answer"):
            assert head in text or (name == "f4_coder" and head == "## How to answer"), (name, head)       # the Coder's document ends with the rules of the code, taken from procedures.py
        for m in must:
            assert m in text, (name, m)
    assert '"output_columns"' in family4.REQ_SHAPE and '"procedure"' in family4.REQ_SHAPE


# ---------------------------------------------------------------------------------------------- the guards behind the cards
def test_the_code_step_itself_refuses_to_start_a_round_in_contradiction(lab):
    """Whatever let the requirements through (an older card, a stored answer): the code step compares once more."""
    lab.work()
    s = lab.step("req")
    lab.store.exec("UPDATE step SET output=? WHERE id=?", (json.dumps(dict(json.loads(s["output"]), output_columns=["City", "count", "Minutes"])), s["id"]))
    lab.decide("approve")
    st = lab.work()
    assert st["state"] == "failed" and "coder" not in lab.calls
    assert "no round of code was started: the requirements say the output columns are City, count, Minutes, and the procedure (version 1) says City, count" in st["error"]


def test_a_column_name_in_quotation_marks_in_the_rule_is_no_surprise_on_the_card(tmp_path, monkeypatch):
    lab = T.Lab(tmp_path, monkeypatch)
    r = lab.rule()
    r["description"] = 'Count the visits per "City"; the column "Minutes" is not used.'
    family3.save_rule(r)
    lab.start().work()
    rec = lab.out("research")["record"]
    assert not any("“City”" in s or "“Minutes”" in s for s in rec["surprises"]) and "is in no column of the files it reads" not in lab.review()["body"]
    # (2026-11-15) the data research no longer makes a surprise of a quoted column name at all (agentic/f4_research.py find_words,
    # surprises_of), so nothing is left for Family 4 to drop; the ledger says what the word is: the name of a column
    assert rec["not_supported"] == []
    led = {x["what"]: x for x in rec["ledger"] if "“City”" in str(x.get("what")) or "“Minutes”" in str(x.get("what"))}
    assert sorted(x["source"] for x in led.values()) == ["“City” is the name of a column of visits.csv (its header, read by the program), not a value to look for",
                                                        "“Minutes” is the name of a column of visits.csv (its header, read by the program), not a value to look for"]
    assert all(x["state"] == "established" for x in led.values())
    assert not [q for q in lab.out("req")["questions"] if "City" in q["question"] and "no column" in q["question"].lower()]
