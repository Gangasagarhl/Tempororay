"""The search and the stress step on the page of one error (2026-11-14, real-environment item B2): nvme_hier/replay_search.py and the
routes /api/isolate/<upload>/<finding>/search. Everything runs on the simulated drive with a hidden trigger, in temporary folders.

    python3 -m pytest -q -p no:cacheprovider tests/test_replay_search.py

REPLAY_SEARCH_TREE=<a hier.sqlite built from the S17 sample> skips the 20 seconds of loading (a developer's shortcut, nothing else).
The numbers the comparison test prints (-s shows them) are the measured ones; nothing in this file is tuned to make a claim true.
"""
import json
import os
import random
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import zipfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))
sys.path.insert(0, HERE)

from nvme_hier import replay_search as RS   # noqa: E402

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
OLD_ZIP = os.path.join(os.path.dirname(APP), "field_to_test_loop_code_only.zip")
UID = "up-s17"


def _tree(path):
    """The S17 sample as a tree (loaded, joined, rules applied) at path."""
    from nvme_hier import builder as B, loader as L, rules as RL
    import fuzz_app as F
    cache = os.environ.get("REPLAY_SEARCH_TREE")
    if cache and os.path.exists(cache):
        shutil.copy(cache, path)
        return
    L.load_upload(path, {k: os.path.join(S17, n) for k, n in F.NAMES.items()})
    B.build(path)
    RL.apply(path)
    if cache:
        shutil.copy(path, cache)


@pytest.fixture(scope="module")
def s17():
    if not os.path.isdir(S17):
        pytest.skip("the sample recording samples/clean_five_files/S17_io_timeout_abort_reset is not on this machine")
    import fuzz_app as F
    root = tempfile.mkdtemp(prefix="replay_search_%d_" % os.getpid())
    try:
        app, c, _k, _r = F.setup(root)
        d = os.path.join(root, "uploads", UID)
        os.makedirs(d)
        _tree(os.path.join(d, "hier.sqlite"))
        with open(os.path.join(d, "meta.json"), "w", encoding="utf-8") as fh:
            json.dump({"upload_id": UID, "created": 0, "operator": "t", "device": "D", "trace_name": UID, "recording_date": "", "notes": "", "files": {}, "status": "loaded",
                       "thresholds": {}, "file_stats": {}}, fh)
        con = sqlite3.connect(os.path.join(d, "hier.sqlite"))
        fid = con.execute("SELECT id FROM finding WHERE level='nvme_command' AND rule='cmd.timeout' ORDER BY id LIMIT 1").fetchone()[0]
        con.close()
        iso = c.post("/api/isolate/%s/%d/isolate" % (UID, fid), json={"anyway": True, "standin": True, "name": "t", "n": 15, "m": 2}).get_json()
        yield {"app": app, "c": c, "root": root, "fid": fid, "seq": iso["sequence"], "base": "/api/isolate/%s/%d/" % (UID, fid), "dir": d}
    finally:
        shutil.rmtree(root, ignore_errors=True)


@pytest.fixture(scope="module")
def pool(s17):
    """The pool of the search exactly as the route builds it: 15 recorded commands before the failing one, and the first sequence."""
    from api import isolate_api as IA
    app = s17["app"]
    with app.test_request_context():
        s = app.config["services"]
        ctx = IA._load(s, UID, s17["fid"])
        p, seed, usual = IA._search_pool(s, UID, s17["fid"], [dict(x) for x in s17["seq"]], 15, ctx["f"]["cmd_rowid"])
        limit_us, _t, _s = IA._cmd_limit(ctx)
        oracle = IA.TP.oracle_of(ctx["f"], limit_us)
        recorded = ctx["f"]["value_ps"] / 10 ** 6
    return {"pool": p, "seed": seed, "usual": usual, "oracle": oracle, "recorded": recorded}


def _search(pl, trigger, seed=0, budget=RS.BUDGET_DEFAULT, **kw):
    bench = RS.HiddenTriggerBench(pl["oracle"], trigger, pl["recorded"], pl["usual"], seed=seed, slope=kw.pop("slope", True))
    return RS.search(pl["pool"], pl["seed"], bench, budget=budget, recorded_time_us=pl["recorded"], rng_seed=seed, **kw)


def _good(res):
    return bool(res["found"] and res["best"]["runs"] >= 10 and res["best"]["reproduced"] >= 8)


# ---------------------------------------------------------------------------------------------- the search finds the hidden trigger
def test_the_search_finds_the_hidden_trigger_and_a_random_choice_with_the_same_budget_does_worse(pool):
    p = pool["pool"]
    assert len(p.rows) >= 10 and p.io_queues > 1, "the S17 window has several queues and enough commands to choose from"
    found = {"search": 0, "random": 0}
    used = {"search": [], "random": []}
    for t in range(10):
        trigger = RS.random_trigger(p, random.Random(100 + t))
        for strategy in ("search", "random"):
            res = _search(pool, trigger, seed=t, strategy=strategy, do_stress=False)
            assert res["budget"]["used"] <= RS.BUDGET_DEFAULT, res["budget"]
            assert RS.invented(p, res) == []
            found[strategy] += 1 if _good(res) else 0
            used[strategy].append(res["budget"]["used"])
    print("\nMEASURED hidden-trigger drive, 10 random triggers, budget %d bench runs each: search found %d of 10 (mean %.0f runs used), random baseline found %d of 10 (mean %.0f runs used)"
          % (RS.BUDGET_DEFAULT, found["search"], sum(used["search"]) / 10, found["random"], sum(used["random"]) / 10))
    # the same without the simulated drive's hint (the failing command does not get slower near the trigger): measured and printed, not required
    blind = {"search": 0, "random": 0}
    for t in range(10):
        trigger = RS.random_trigger(p, random.Random(100 + t))
        for strategy in ("search", "random"):
            blind[strategy] += 1 if _good(_search(pool, trigger, seed=t, strategy=strategy, do_stress=False, slope=False)) else 0
    print("MEASURED the same with no hint in the measured time: search found %d of 10, random baseline found %d of 10" % (blind["search"], blind["random"]))
    assert found["search"] >= 8, found
    assert found["search"] - found["random"] >= 3, "the search is not clearly better than a random choice: %s" % found


def test_a_trigger_that_cannot_be_met_is_never_called_a_success(pool):
    trigger = RS.random_trigger(pool["pool"], random.Random(7), impossible=True)
    for strategy in ("search", "random"):
        res = _search(pool, trigger, seed=1, strategy=strategy)
        assert res["found"] is False and res["best"] is None and res["most_stressful"] is None and res["stress"] is None
        assert res["verdict"].startswith("not reproduced within the budget"), res["verdict"]
        assert sum(c["reproduced"] for c in res["candidates"]) == 0 and res["budget"]["used"] <= RS.BUDGET_DEFAULT


@pytest.mark.parametrize("threshold", [3, 20, 150])
def test_the_stress_step_stops_at_the_hidden_threshold_within_one_step(pool, threshold):
    p = pool["pool"]
    seed = p.candidate(pool["seed"]["rows"], dict(pool["seed"]["gaps"], **{}), 1)
    seed["gaps"][p.frow] = 400                                   # the gap before the failing command starts at 400 microseconds
    trigger = {"needed": [], "gap_min_us": threshold, "gap_max_us": 1000, "blocker": None, "queue_depth_min": 1, "miss_share": 0.0}
    bench = RS.HiddenTriggerBench(pool["oracle"], trigger, pool["recorded"], pool["usual"], seed=5)
    res = RS.search(p, seed, bench, budget=60, recorded_time_us=pool["recorded"], rng_seed=5)
    assert res["found"] and res["best"]["reproduced"] == 10
    gap = next(c for c in res["stress"]["conditions"] if c["value"].startswith("the gap before the failing command"))
    assert gap["to"] >= threshold > gap["to"] // 2, gap          # the last value that still fails is at most one halving above the hidden threshold
    assert gap["reproduced"] >= RS.STRESS_NEED and gap["runs"] == RS.STRESS_RUNS and "came back in" in gap["words"]
    lost = [x for x in res["stress"]["steps"] if x["value"] == gap["value"] and not x["kept"]]
    assert lost and lost[0]["to"] < threshold and lost[0]["reproduced"] < RS.STRESS_NEED
    assert res["most_stressful"]["steps"][-1]["gap_us"] == gap["to"] and res["budget"]["stress"] <= RS.STRESS_MAX_RUNS


# ---------------------------------------------------------------------------------------------- nothing invented, no illegal order
def test_every_command_of_every_candidate_is_a_command_of_the_recording(pool, s17):
    from api import isolate_api as IA
    p = pool["pool"]
    res = _search(pool, RS.random_trigger(p, random.Random(101)), seed=1)
    rows = set(p.rows) | {p.frow}
    assert len(res["candidates"]) > 20 and all(set(c["rows"]) <= rows and c["rows"][-1] == p.frow for c in res["candidates"])
    con = sqlite3.connect("file:%s?mode=ro" % os.path.join(s17["dir"], "hier.sqlite"), uri=True)
    con.row_factory = sqlite3.Row
    try:
        with s17["app"].test_request_context():
            for part in ("best", "most_stressful"):
                if res.get(part):
                    assert IA.evidence_check(con, res[part]["steps"]) == []
    finally:
        con.close()
    assert sum(c["runs"] for c in res["candidates"]) == res["budget"]["used"]          # every run is in the list: nothing is hidden


def _step(row, opc, slba, nlb=7, admin=False, fua=0, q=1):
    return {"command": "c%d" % row, "opc": opc, "admin": admin, "queue": 0 if admin else q, "parameters": {"nsid": 1, "slba": slba, "nlb": nlb, "fua": fua}, "gap_us": 20,
            "source_row": row, "position": "above", "why": []}


def test_an_illegal_reorder_is_never_produced():
    W, R = 0x01, 0x02
    assert RS.must_keep_order(_step(1, W, 100), _step(2, R, 104)) is not None             # a write before its read of the same blocks
    assert RS.must_keep_order(_step(1, R, 100), _step(2, W, 100)) is not None
    assert RS.must_keep_order(_step(1, W, 100), _step(2, W, 107)) is not None
    assert RS.must_keep_order(_step(1, R, 100), _step(2, R, 100)) is None                 # two reads are independent
    assert RS.must_keep_order(_step(1, W, 100), _step(2, R, 108)) is None                 # different blocks
    assert RS.must_keep_order(_step(1, 0x09, 0, admin=True), _step(2, R, 100)) is not None
    assert RS.must_keep_order(_step(1, 0x00, 0), _step(2, R, 100)) is not None            # a Flush
    assert RS.must_keep_order(_step(1, W, 500, fua=1), _step(2, R, 100)) is not None
    rnd = random.Random(3)
    above = [_step(1, 0x09, 0, admin=True)] + [_step(i, rnd.choice([W, R, R]), 100 + 8 * rnd.randint(0, 5)) for i in range(2, 14)]
    p = RS.Pool(above, dict(_step(14, R, 100), position="fault"), {i: (i * 10 ** 7, 3 * 10 ** 7) for i in range(1, 15)})
    cand, swapped = p.candidate([1, 2, 3]), 0
    for _ in range(4000):
        new = RS.mutate(p, cand, rnd.choice(RS.operators_for(p)), rnd)
        if new is None:
            continue
        assert p.legal(new["rows"]) and set(new["rows"]) <= set(p.rows) and len(set(new["rows"])) == len(new["rows"]), new
        assert 1 <= new["queue_depth"] <= p.max_queue_depth and all(g >= 1 for g in new["gaps"].values())
        for i, a in enumerate(new["rows"]):                      # the rule itself, pair by pair: nothing recorded later comes before what it depends on
            for b in new["rows"][i + 1:]:
                assert not (a > b and RS.must_keep_order(p.by_row[b], p.by_row[a]))
        swapped += 1 if new["rows"] != sorted(new["rows"]) else 0
        cand = new
    assert swapped > 50                                          # the order does change where it is free, so the check above is not empty
    for _ in range(300):
        c = RS.random_candidate(p, rnd)
        assert p.legal(c["rows"])


# ---------------------------------------------------------------------------------------------- the routes: job, progress, stop, result
def _wait(c, jid, seconds=120, until=None):
    seen, t0 = [], time.time()
    while time.time() - t0 < seconds:
        j = c.get("/api/isolate/jobs/" + jid).get_json()
        seen.append(j)
        if j["state"] != "running" or (until and until(j)):
            return j, seen
        time.sleep(0.02)
    raise AssertionError("the job did not end in %d seconds: %s" % (seconds, seen[-1]))


def test_the_job_shows_progress_and_stores_a_result_labelled_simulated(s17, monkeypatch):
    c, base = s17["c"], s17["base"]
    earlier = os.path.join(s17["dir"], "replay_search", "f%d.json" % s17["fid"])        # the tests may run in any order: start with nothing stored
    if os.path.exists(earlier):
        os.remove(earlier)
    assert c.get(base + "search").get_json()["result"] is None
    one = RS.HiddenTriggerBench._one
    monkeypatch.setattr(RS.HiddenTriggerBench, "_one", lambda self, steps, qd: (time.sleep(0.004), one(self, steps, qd))[1])
    r = c.post(base + "search?job=1", json={"sequence": s17["seq"], "budget": 200, "bench": "simulated", "name": "Tester", "trigger_seed": 101})
    assert r.status_code == 200, r.get_json()
    j, seen = _wait(c, r.get_json()["job"])
    assert j["state"] == "done", j
    pcts = [x["pct"] for x in seen]
    assert pcts == sorted(pcts) and len(set(pcts)) >= 5 and pcts[-1] == 100, pcts
    assert any("bench run" in (x["text"] or "") and "simulated drive" in x["text"] for x in seen)
    res = j["result"]["result"]
    assert j["result"]["stored"] and res["bench"] == {"kind": "simulated", "label": "simulated drive", "simulated": True} and res["label"] == "simulated drive"
    for k in ("seed", "budget", "best", "stress", "candidates", "verdict", "simulated_drive", "operators", "order_rule"):
        assert k in res, k
    assert res["budget"]["asked"] == 200 and res["budget"]["used"] == sum(x["runs"] for x in res["candidates"])
    if res["found"]:
        b = res["best"]
        assert b["runs"] >= 10 and b["reproduced"] >= 8 and 0 < b["lower_bound"] < b["reproduced"] / b["runs"] and "simulated drive" in b["steps"][0]["why"][0]
    assert "not on a real one" in res["simulated_drive"]["note"] and res["simulated_drive"]["hidden_trigger_words"]
    stored = c.get(base + "search").get_json()
    assert stored["result"]["verdict"] == res["verdict"] and stored["running"] is False and stored["defaults"]["budget"] == RS.BUDGET_DEFAULT


def test_a_stopped_job_leaves_no_half_written_result(s17, monkeypatch):
    c = s17["c"]
    fid = s17["fid"]
    base = s17["base"]
    before = c.get(base + "search").get_json()["result"]
    folder = os.path.join(s17["dir"], "replay_search")
    files_before = {n: os.path.getmtime(os.path.join(folder, n)) for n in os.listdir(folder)} if os.path.isdir(folder) else {}
    one = RS.HiddenTriggerBench._one
    monkeypatch.setattr(RS.HiddenTriggerBench, "_one", lambda self, steps, qd: (time.sleep(0.01), one(self, steps, qd))[1])
    monkeypatch.setattr(RS, "CONFIRM_NEED", 11)                   # cannot be met: the search runs its whole budget unless it is stopped
    r = c.post(base + "search?job=1", json={"sequence": s17["seq"], "budget": 5000, "bench": "simulated", "trigger_seed": 5})
    jid = r.get_json()["job"]
    _wait(c, jid, until=lambda j: j["pct"] >= 4)
    assert c.get(base + "search").get_json()["running"] is True
    again = c.post(base + "search?job=1", json={"sequence": s17["seq"], "budget": 50, "bench": "simulated"})
    assert again.status_code == 409 and "already running" in again.get_json()["error"]
    assert c.post(base + "search/stop").get_json()["stopping"] is True
    j, _seen = _wait(c, jid, seconds=30)
    assert j["state"] == "done" and j["result"]["stopped"] is True and j["result"]["stored"] is False and "nothing was stored" in j["result"]["note"]
    after = c.get(base + "search").get_json()
    assert after["result"] == before and after["running"] is False
    files_after = {n: os.path.getmtime(os.path.join(folder, n)) for n in os.listdir(folder)} if os.path.isdir(folder) else {}
    assert files_after == files_before, "a stopped search wrote or left a file: %s" % sorted(set(files_after) ^ set(files_before))
    assert c.post(base + "search/stop").get_json() == {"stopping": False, "note": "no search is running for this error"}
    assert fid


def test_the_real_bench_without_an_implementation_answers_in_plain_words(s17):
    c, base = s17["c"], s17["base"]
    before = c.get(base + "search").get_json()["result"]
    r = c.post(base + "search", json={"sequence": s17["seq"], "budget": 40, "bench": "real"})
    assert r.status_code == 409, r.get_json()
    msg = r.get_json()["error"]
    assert "Nothing was run on a device" in msg and "Traceback" not in msg and "NotImplementedError" not in msg, msg
    assert c.get(base + "search").get_json()["result"] == before
    r = c.post(base + "search?job=1", json={"sequence": s17["seq"], "budget": 40, "bench": "real"})
    j, _seen = _wait(c, r.get_json()["job"])
    assert j["state"] == "error" and "Nothing was run on a device" in j["error"]

    class NoRun:
        def run(self, scenario):
            raise NotImplementedError("x")
    with pytest.raises(RS.BenchNotReady, match="not connected yet"):
        RS.RealBench("sig", None, hook=NoRun()).run([{"command": "Read", "gap_us": 1}], 1, 1)


HOSTILE = [
    {"budget": "abc"}, {"budget": -5}, {"budget": 10 ** 30}, {"budget": 1.5}, {"budget": True}, {"budget": [200]}, {"budget": {"a": 1}}, {"budget": "9" * 60},
    {"budget": 0}, {"budget": "20\x00"}, {"bench": 5}, {"bench": "simulated\x00"}, {"bench": None}, {"bench": ["real"]}, {"sequence": "x"}, {"sequence": [1, 2]},
    {"sequence": []}, {"sequence": [{}]}, {"sequence": [{"position": "fault", "source_row": "144\x00"}]}, {"sequence": [{"position": "fault", "source_row": 10 ** 40}]},
    {"sequence": [{"position": "fault", "source_row": -1}]}, {"sequence": [{"position": "fault", "source_row": 1}]}, {"pool_n": -1}, {"pool_n": "x"},
    {"pool_n": 10 ** 9}, {"trigger_seed": -1}, {"trigger_seed": "\x00"}, {"sequence": [{"position": "fault"}] * 2001},
]


@pytest.mark.parametrize("change", HOSTILE, ids=[str(i) for i in range(len(HOSTILE))])
def test_hostile_input_on_the_search_route_is_refused_in_words(s17, change):
    c, base = s17["c"], s17["base"]
    for q in ("", "?job=1"):
        r = c.post(base + "search" + q, json=dict({"sequence": s17["seq"], "budget": 40, "bench": "simulated"}, **change))
        j = r.get_json()
        assert r.status_code == 400, (r.status_code, j)
        assert isinstance(j.get("error"), str) and len(j["error"]) > 20 and "Traceback" not in j["error"], j


def test_hostile_gaps_and_bodies_are_refused_in_words(s17):
    c, base = s17["c"], s17["base"]
    for gap in (-3, 0, "5", 10 ** 30, None, 2.5, True):
        seq = [dict(x, gap_us=gap) if x.get("position") == "fault" else x for x in s17["seq"]]
        r = c.post(base + "search", json={"sequence": seq, "budget": 40, "bench": "simulated"})
        assert r.status_code == 400 and "gap" in r.get_json()["error"], (gap, r.get_json())
    for raw in (b"[1, 2]", b"\"x\"", b"{", b"null", b"\x00"):
        r = c.post(base + "search", data=raw, content_type="application/json")
        assert r.status_code == 400 and isinstance(r.get_json().get("error"), str), (raw, r.status_code)
    for use in (7, "x\x00", ["best"], {"a": 1}, "BEST", True):
        r = c.post(base + "testcase", json={"sequence": s17["seq"], "standin": True, "use_search": use})
        assert r.status_code == 400 and "use_search" in r.get_json()["error"], (use, r.get_json())


# ---------------------------------------------------------------------------------------------- the test file: from the searched sequence, or unchanged
def test_the_test_can_be_written_from_the_searched_sequence_when_the_admin_chooses_so(s17):
    c, base = s17["c"], s17["base"]
    r = c.post(base + "search", json={"sequence": s17["seq"], "budget": 200, "bench": "simulated", "trigger_seed": 101, "name": "Tester"})
    assert r.status_code == 200, r.get_json()
    res = r.get_json()["result"]
    assert res["found"], res["verdict"]
    below = [x["source_row"] for x in s17["seq"] if x.get("position") == "below"]
    for which, part in (("best", res["best"]), ("stressed", res["most_stressful"])):
        if part is None:
            assert which == "stressed"
            r = c.post(base + "testcase", json={"sequence": s17["seq"], "standin": True, "use_search": which})
            assert r.status_code == 400 and "most stressful" in r.get_json()["error"]
            continue
        prop = c.post(base + "testcase", json={"sequence": s17["seq"], "name": "t", "standin": True, "use_search": which}).get_json()
        assert [x["source_row"] for x in prop["sequence"]] == part["rows"] + below
        made = c.post(base + "testcase", json={"sequence": prop["sequence"], "expected_outcomes": prop["expected_outcomes"], "verified": True, "name": "Tester"})
        m = made.get_json()
        assert made.status_code == 200, m
        plan = m["plan"]
        assert [x["source_row"] for x in plan["steps"]] == part["rows"] + below and [x["gap_us"] for x in plan["steps"]][:len(part["rows"])] == [x["gap_us"] for x in part["steps"]]
        assert "simulated drive" in plan["steps"][0]["why"][0] and "simulated drive" in m["text"] and m["two_sided"]["ok"], m["two_sided"]


DRIVER = r'''
import copy, json, os, shutil, sys, time
app_dir, root, tree, fid = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
sys.path.insert(0, app_dir); sys.path.insert(0, os.path.join(app_dir, "app"))
time.strftime = lambda *a, **k: "2026-11-14 00:00:00"        # the file carries the time it was generated: the same in both runs
def main():
    from agentic import core, family1
    from api import config_api, hier_api
    with open(os.path.join(app_dir, "config", "app_config.json"), encoding="utf-8") as fh:
        cfg = json.load(fh)
    cfg["_path"] = os.path.join(root, "app_config.json")
    cfg["llm"].update(base_url="http://127.0.0.1:9", api_key_env="FUZZ_NO_SUCH_KEY", backend="http")
    cfg["agentic"].update(runtime="standin", web=False)
    cfg.setdefault("server", {})["api_calls"] = True
    config_api.save_config = lambda c: None
    hier_api.ENV_FILE = os.path.join(root, "env")
    family1.knowledge_dir = lambda: os.path.join(root, "knowledge")
    core.Engine.kick = lambda self, rid: None
    for d in ("knowledge", "config", os.path.join("uploads", "up-s17")):
        os.makedirs(os.path.join(root, d), exist_ok=True)
    shutil.copy(os.path.join(app_dir, "config", "app_config.json"), os.path.join(root, "config", "app_config.json"))
    from server import create_app
    app = create_app(cfg, root)
    shutil.copy(tree, os.path.join(root, "uploads", "up-s17", "hier.sqlite"))
    with open(os.path.join(root, "uploads", "up-s17", "meta.json"), "w", encoding="utf-8") as fh:
        json.dump({"upload_id": "up-s17", "created": 0, "operator": "t", "device": "D", "trace_name": "up-s17", "recording_date": "", "notes": "", "files": {},
                   "status": "loaded", "thresholds": {}, "file_stats": {}}, fh)
    c = app.test_client()
    base = "/api/isolate/up-s17/%d/" % fid
    iso = c.post(base + "isolate", json={"anyway": True, "standin": True, "name": "t", "n": 15, "m": 2}).get_json()
    prop = c.post(base + "testcase", json={"sequence": iso["sequence"], "name": "t", "standin": True}).get_json()
    made = c.post(base + "testcase", json={"sequence": prop["sequence"], "expected_outcomes": prop["expected_outcomes"], "verified": True, "name": "Tester"})
    m = made.get_json()
    with open(m["path"], "rb") as fh:
        data = fh.read()
    with open(os.path.join(os.path.dirname(m["path"]), "f2t_nvme.py"), "rb") as fh:
        lib = fh.read()
    import hashlib
    with open(os.path.join(root, "out.json"), "w", encoding="utf-8") as fh:
        json.dump({"status": made.status_code, "name": m["name"], "file": data.decode("utf-8"), "library_sha256": hashlib.sha256(lib).hexdigest(), "two_sided": m["two_sided"]["ok"]}, fh)
if __name__ == "__main__":
    main()
'''


def test_without_the_search_the_written_test_file_is_byte_for_byte_what_the_earlier_code_wrote(s17, tmp_path):
    if not os.path.exists(OLD_ZIP):
        pytest.skip("the copy of the code before this change (field_to_test_loop_code_only.zip) is not on this machine")
    old = str(tmp_path / "old")
    with zipfile.ZipFile(OLD_ZIP) as z:
        z.extractall(old, [n for n in z.namelist() if n.startswith("13_production_app/") and not n.startswith(("13_production_app/tests/", "13_production_app/docs/"))])
    driver = str(tmp_path / "driver.py")
    with open(driver, "w", encoding="utf-8") as fh:
        fh.write(DRIVER)
    out = {}
    for name, app_dir in (("before", os.path.join(old, "13_production_app")), ("now", APP)):
        root = str(tmp_path / ("root_" + name))
        os.makedirs(root)
        env = {k: v for k, v in os.environ.items() if not k.startswith("NVME_")}
        env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1")
        p = subprocess.run([sys.executable, driver, app_dir, root, os.path.join(s17["dir"], "hier.sqlite"), str(s17["fid"])], capture_output=True, text=True, timeout=600, env=env, cwd=str(tmp_path))
        assert p.returncode == 0 and os.path.exists(os.path.join(root, "out.json")), "the %s code did not write the test: %s" % (name, (p.stderr or p.stdout)[-1500:])
        with open(os.path.join(root, "out.json"), encoding="utf-8") as fh:
            out[name] = json.load(fh)
    assert out["before"]["status"] == out["now"]["status"] == 200 and out["before"]["two_sided"] and out["now"]["two_sided"]
    assert out["before"]["name"] == out["now"]["name"]
    assert out["before"]["library_sha256"] == out["now"]["library_sha256"], "the replay library changed: its version text and every written test change with it"
    assert out["now"]["file"].encode("utf-8") == out["before"]["file"].encode("utf-8"), "the written test file differs from what the earlier code wrote"
    assert len(out["now"]["file"]) > 2000 and "PLAN = {" in out["now"]["file"]


# ---------------------------------------------------------------------------------------------- the page
def test_the_page_has_the_optional_part_between_the_solution_and_the_test_and_every_field_says_why():
    import re
    with open(os.path.join(APP, "app", "static", "isolate.html"), encoding="utf-8") as fh:
        page = fh.read()
    with open(os.path.join(APP, "app", "static", "js", "isolate.js"), encoding="utf-8") as fh:
        js = fh.read()
    assert page.index('id="s-solution"') < page.index('id="s-search"') < page.index('id="s-test"')
    assert "Search for the conditions that bring the failure back" in js and "Simulated drive." in js and 'name="sr-use"' in js
    assert "checked" not in "".join(re.findall(r'<input type="radio" name="sr-use"[^>]*>', js)) and '<option value="">choose one' in js      # nothing chosen in advance
    labels = re.findall(r'<label class="f"[^>]*>.*?</label>\s*(<div class="why">(.*?)</div>)?', js, flags=re.S)
    assert len(labels) >= 3 and all(why and len(text) > 40 for why, text in labels), labels
    assert "...searchChoice()" in js and "use_search" in js
    # the page script is a module: a name declared twice at the top level stops the whole page (node --check on a .js file does not see it)
    names = re.findall(r"^(?:async )?function ([A-Za-z_$][\w$]*)|^(?:const|let|class) ([A-Za-z_$][\w$]*)", js, flags=re.M)
    flat = [x or y for x, y in names]
    assert len(flat) > 30 and sorted(set(flat)) == sorted(flat), [n for n in set(flat) if flat.count(n) > 1]
