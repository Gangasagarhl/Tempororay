"""How a file is written reaches the three agents of Family 1, and the folder's refused files reach the director's card
(joined on 2026-11-15 from two builds: agentic/csv_dialect.py and the start page's "Another tool, or I do not know").

What is tested here:
  * a semicolon file with decimal commas and a title line: the text handed to the Data Explorer's model and to the Data
    Grounder's model holds the stored facts (encoding, separator, header line, the line above the header, each column's
    number style), in a block whose size is bounded; a file written as before gets the calls it always got;
  * 80 open columns that all have a number style are still two calls of 40, and 50 long lines above the header reach the
    model as 5 cut lines;
  * a Manager asked "which separator does this file use" answers from the stored record (stand-in, no model);
  * the director's step lists a refused file with its plain sentence while the other files of the folder go on;
  * the data dictionaries of the project's sample recording are, byte for byte, what they were before this join.

No real model: the scripted model server of tests/test_grounder_batches.py, the stand-in runner, and a knowledge folder of
each test's own (tests/test_grounder_known.py, _World). Nothing is written into the application's folders."""
import hashlib
import json
import os
import sys
import types

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
for p in (APP, os.path.join(APP, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

from agentic import core, csv_dialect as CD, family1      # noqa: E402
from test_csv_dialect import WPA_HEADER, _Ctx as _ManagerCtx, _dictionary, write_wpa      # noqa: E402
from test_grounder_known import _World      # noqa: E402

S08 = os.path.join(APP, "samples", "clean_five_files", "S08_interrupt_before_completion")
# the SHA-256 of samples_snapshot() taken on 2026-11-15 with the code as it was before the join (209,837 characters)
SAMPLES_BEFORE = "3bfbeeb924ba593ba1615f4ddc9cd962f548b8872f2e5e68c6b96810e75832c6"


def _folder(tmp_path, name="rec"):
    d = tmp_path / name
    d.mkdir()
    return str(d)


def _plain_file(folder, name="plain.csv", rows=300):
    path = os.path.join(folder, name)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("Command,Queue,Latency_us,Result\n" + "".join("%s,%d,%d,ok\n" % (("Read", "Write", "Flush")[i % 3], i % 4, 80 + i) for i in range(rows)))
    return path


# ---------------------------------------------------------------------------------------------- the two models' inputs
def test_a_semicolon_file_with_decimal_commas_and_a_title_line_reaches_both_models_with_its_form(tmp_path):
    folder = _folder(tmp_path)
    write_wpa(os.path.join(folder, "disk.csv"), n=600, before=["Disk report of drive D"])
    f = family1.inventory(folder)[0]
    assert f["written_as"]["separator"]["name"] == "semicolon"
    with _World("form_explore") as w:
        model, res, memory, ctx = w.explore(f)
        assert model.prompts, "the Data Explorer asked no model"
        limit = ctx.engine.runner.context_tokens() * ctx.engine.runner.CHARS_PER_TOKEN
        for prompt in model.prompts:                                # the text handed to the model, word for word
            assert "HOW THE FILE IS WRITTEN" in prompt and len(prompt) < limit
            facts = json.loads(prompt.split("CONTEXT:\n", 1)[1])["file_facts"]["written_as"]
            assert facts == {"text": "Written as UTF-8, cells separated by a semicolon, header on line 2 (1 line above it is not part of the table).",
                             "lines_before_the_header": ["Disk report of drive D"]}
        seen = {c["column"]: c for a in model.asked for c in a["columns"]}
        assert list(seen) == WPA_HEADER.split(";")                  # the header text exactly, the unit in it
        assert seen["IO Time (µs)"]["number_style"].startswith("decimal comma: of the ")
        assert "the point stands between thousands" in seen["IO Time (µs)"]["number_style"]
        assert "number_style" not in seen["Size (B)"] and "number_style" not in seen["IO Type"]
        assert all(len(c.get("number_style", "")) <= family1.FORM_STYLE_CHARS for c in seen.values())
        assert memory["written_as"]["header"]["line"] == 2 and res.output["rows"] == 600
        # the Data Grounder, on what the Data Explorer stored
        cols = memory["columns"]
        gmodel, gres, out, gctx = w.ground(cols, f, web=False, mem_more={"written_as": memory["written_as"]})
        assert gmodel.prompts, "the Data Grounder asked no model"
        for prompt in gmodel.prompts:
            assert "HOW THE FILE IS WRITTEN" in prompt and len(prompt) < limit
            context = json.loads(prompt.split("CONTEXT:\n", 1)[1])
            assert context["written_as"]["text"].startswith("Written as UTF-8, cells separated by a semicolon, header on line 2")
            assert context["written_as"]["lines_before_the_header"] == ["Disk report of drive D"]
        asked = {c["column"]: c for a in gmodel.asked for c in a["columns"] if "meaning_known" not in c}
        assert asked["IO Time (µs)"]["number_style"] == seen["IO Time (µs)"]["number_style"]
        assert asked["Init Time (s)"]["number_style"].startswith("decimal comma: ") and "number_style" not in asked["Size (B)"]
        # no meaning was written by code: every meaning in the Grounder's memory came from the scripted model's answer
        assert all((m.get("source") or {}).get("kind") in ("model", None) for m in out["columns"].values())
    # the size: the same step without the form facts (in a world of its own: nothing understood before), call by call
    bare = [{k: v for k, v in c.items() if k != "number_style"} for c in cols]
    with _World("form_bare") as w:
        bmodel, _r, _o, _c = w.ground(bare, f, web=False)
        assert len(bmodel.prompts) == len(gmodel.prompts) and not any("HOW THE FILE IS WRITTEN" in p or "written_as" in p for p in bmodel.prompts)
        styled = sum(1 for c in cols if c.get("number_style"))
        assert styled == 4
        most = len(family1.GROUND_FORM_NOTE) + 400 + styled * (family1.FORM_STYLE_CHARS + 40)
        for with_form, without in zip(sorted(gmodel.prompts, key=len), sorted(bmodel.prompts, key=len)):
            assert 0 < len(with_form) - len(without) <= most, (len(with_form), len(without), most)


def test_a_file_written_as_before_gets_the_calls_it_always_got(tmp_path):
    folder = _folder(tmp_path)
    _plain_file(folder)
    f = family1.inventory(folder)[0]
    assert "written_as" not in f
    with _World("form_plain") as w:
        model, _res, memory, _ctx = w.explore(f)
        gmodel, _g, _out, _c = w.ground(memory["columns"], f, web=False)
        for prompt in model.prompts + gmodel.prompts:
            assert "HOW THE FILE IS WRITTEN" not in prompt and "number_style" not in prompt and "written_as" not in prompt
        assert "written_as" not in memory and model.prompts and gmodel.prompts


def test_eighty_columns_with_a_number_style_are_two_calls_of_forty_and_fifty_long_lines_reach_the_model_as_five(tmp_path):
    how = "decimal comma: of the 2,000 different values counted, 1,990 can only be read with a decimal comma (such as 1.795,900); " + "x" * 600
    cols = [{"column": "Wert %03d" % i, "position": i, "header_cell": "Wert %03d" % i, "type": "text", "rows_with_value": 5000, "observed": "numbers",
             "top_values": [{"value": "1.795,%03d" % i, "count": 9}], "keywords": [],
             "number_style": {"style": "decimal comma", "decimal_sign": ",", "thousands_sign": ".", "how": how}} for i in range(80)]
    written = {"encoding": {"value": "UTF-16, little endian", "codec": "utf-16-le", "how": "the file starts with the bytes FF FE"},
               "separator": {"value": ";", "name": "semicolon", "decided": True, "how": "semicolon gives 80 cells on 200 of the 200 lines"},
               "header": {"line": 51, "lines_before": ["Zeile %02d " % i + "y" * 480 for i in range(50)], "lines_before_count": 50, "how": "the first line of the table"},
               "lines_looked_at": 251, "text": "Written as UTF-16, little endian, cells separated by a semicolon, header on line 51 (50 lines above it are not part of the table)."}
    f = {"name": "werte.csv", "level": None, "level_label": "not one of the five analyzer levels", "format_key": "fmtW"}
    with _World("form_forty") as w:
        model, res, _out, ctx = w.ground(cols, f, web=False, mem_more={"written_as": written}, per_second=1000, pause=0.02)
        assert [len(a["columns"]) for a in model.asked] == [40, 40] and family1.column_parts(cols) == [cols[:40], cols[40:]]
        limit = ctx.engine.runner.context_tokens() * ctx.engine.runner.CHARS_PER_TOKEN
        for prompt in model.prompts:
            context = json.loads(prompt.split("CONTEXT:\n", 1)[1])
            block = context["written_as"]
            assert len(block["lines_before_the_header"]) == family1.FORM_LINES == 5 and block["more_lines_before_the_header"] == 45
            assert all(len(x) == family1.FORM_LINE_CHARS for x in block["lines_before_the_header"])
            assert len(json.dumps(block)) < 1500                                    # the whole block, whatever the file holds above its header
            assert all(len(c["number_style"]) == family1.FORM_STYLE_CHARS and c["number_style"] == how[:260] for c in context["columns"])
            assert len(prompt) < 40 * 1200 and len(prompt) < limit


def test_the_facts_are_the_stored_ones_and_nothing_is_said_for_a_plain_file():
    assert family1._written_words(None) is None and family1._written_words({}) is None and family1._written_words("comma") is None
    assert family1._numbers_words({}) == "" and family1._numbers_words({"number_style": "decimal comma"}) == "" and family1._numbers_words(None) == ""
    c = {"column": "x", "type": "text", "rows_with_value": 3, "top_values": [], "number_style": {"style": "ambiguous", "how": "ambiguous: of the 3 different values counted"}}
    assert family1._slim(c)["number_style"] == "ambiguous: of the 3 different values counted"
    assert "number_style" not in family1._slim({"column": "x", "type": "text", "rows_with_value": 3, "top_values": []})
    assert family1._for_model(1, {"column": "x", "number_style": "ambiguous: ..."})["number_style"] == "ambiguous: ..."
    assert "number_style" not in family1._for_model(1, {"column": "x"})
    for note in (family1.EXPLORE_FORM_NOTE, family1.GROUND_FORM_NOTE):              # the notes ask for no meaning of any column
        assert "counted by" in note and "code" in note and len(note) < 900


# ---------------------------------------------------------------------------------------------- a Manager's answer
def _ask(tmp_path, dictionary_file, question):
    runner = core.AgentRunner(str(tmp_path / "runs"), runtime="standin", web=False)
    return family1.manager_ask(types.SimpleNamespace(runner=runner), {"run": 1}, {"output": json.dumps({"dictionary_file": dictionary_file})}, question, [])


def _dictionary_file(tmp_path, path):
    _dictionary(tmp_path, path)
    return str(tmp_path / "boxes" / ("manager_" + os.path.basename(path)) / "dictionary.json")


def test_a_manager_asked_which_separator_the_file_uses_answers_from_the_stored_record(tmp_path):
    folder = _folder(tmp_path)
    path = write_wpa(os.path.join(folder, "disk.csv"), n=600, before=["Disk report of drive D"])
    record = CD.record(CD.detect(path))
    dfile = _dictionary_file(tmp_path, path)
    answer, producer = _ask(tmp_path, dfile, "which separator does this file use")
    assert "stand-in" in producer and answer.startswith("I asked the Data Explorer.")
    assert "Written as UTF-8, cells separated by a semicolon, header on line 2 (1 line above it is not part of the table)." in answer
    assert "The separator: " + record["separator"]["how"].rstrip(".") in answer and path in answer
    assert "The encoding:" not in answer                              # only what was asked
    answer, _p = _ask(tmp_path, dfile, "On which line is the header, and what stands above it?")
    assert "The header: " + record["header"]["how"].rstrip(".") in answer and "Above the header: Disk report of drive D." in answer
    answer, _p = _ask(tmp_path, dfile, "Which columns are written with a decimal comma?")
    with open(dfile, encoding="utf-8") as fh:
        styles = {c["column"]: c["number_style"]["how"] for c in json.load(fh)["columns"] if c.get("number_style")}
    assert len(styles) == 4 and all("%s: %s" % (name, how.rstrip(".")[:200]) in answer for name, how in styles.items())
    # a column the question names says its number style too
    assert family1._lookup(path, json.load(open(json.load(open(dfile, encoding="utf-8"))["explorer_memory"], encoding="utf-8")),
                           "what does io time (µs) hold")[0]["number_style"] == styles["IO Time (µs)"][:family1.FORM_STYLE_CHARS]
    # a question that is not about the form is answered as before
    answer, _p = _ask(tmp_path, dfile, "how many rows hold Flush")
    assert "IO Type = Flush: 200 rows" in answer and "Written as" not in answer
    # a file written as before: nothing is stored about its form, and the answer says what it was read as
    dfile = _dictionary_file(tmp_path, _plain_file(folder))
    answer, _p = _ask(tmp_path, dfile, "which separator does this file use")
    assert ("Nothing else is stored about how this file is written: it was read as UTF-8 text with its cells separated by a comma and its "
            "header on line 1.") in answer
    assert family1._form_lookup({"columns": []}, "how many rows hold Read") is None


# ---------------------------------------------------------------------------------------------- the director's card
class _DirectorCtx:
    def __init__(self, folder):
        self.step, self.project, self.notes = {"key": "director"}, {"folder": folder, "refs": "[]"}, []

    def progress(self, text):
        self.notes.append(text)


def test_the_director_lists_a_refused_file_with_its_sentence_and_the_other_files_go_on(tmp_path):
    folder = _folder(tmp_path)
    write_wpa(os.path.join(folder, "disk.csv"), n=300)
    _plain_file(folder)
    with open(os.path.join(folder, "image.csv"), "wb") as fh:           # not text: zero bytes in it
        fh.write(b"\x00\x01\x02\x00" * 400)
    ctx = _DirectorCtx(folder)
    out = family1.run_step(ctx).output
    assert [f["name"] for f in out["files"]] == ["disk.csv", "plain.csv"]
    why = family1.refused_files(folder)[0]["why"]
    assert why.startswith("image.csv cannot be read as a table: ") and why.endswith(".")
    assert out["refused"] == [{"name": "image.csv", "path": os.path.join(folder, "image.csv"), "why": why, "line": "Not read as a table: image.csv: " + why}]
    assert out["refused_text"] == "Not read as a table: image.csv: " + why and ctx.notes == [out["refused_text"]]
    assert [s["key"] for s in family1.steps({}, {"folder": folder})] == ["director"] + ["%s:%s" % (k, n) for n in ("disk.csv", "plain.csv") for k in ("explore", "ground", "manager")]
    # five refused files: three on the step's own line, all of them in its output
    for i in range(4):
        with open(os.path.join(folder, "junk%d.csv" % i), "wb") as fh:
            fh.write(b"\x00\x01\x02\x00" * 400)
    ctx = _DirectorCtx(folder)
    out = family1.run_step(ctx).output
    assert len(out["refused"]) == 5 and len(out["files"]) == 2 and ctx.notes[0].count("Not read as a table: ") == family1.REFUSED_SHOWN == 3
    assert ctx.notes[0].endswith("And 2 more files not read as a table: each is listed with its reason under Details.")
    # a folder where every file is read: the output is as before, and nothing is said
    clean = _folder(tmp_path, "clean")
    _plain_file(clean)
    ctx = _DirectorCtx(clean)
    assert sorted(family1.run_step(ctx).output) == ["files", "references"] and ctx.notes == []
    # a folder with refused files only: the step stops and says which and why
    only = _folder(tmp_path, "only")
    with open(os.path.join(only, "image.csv"), "wb") as fh:
        fh.write(b"\x00\x01\x02\x00" * 400)
    with pytest.raises(RuntimeError) as e:
        family1.run_step(_DirectorCtx(only))
    assert str(e.value) == "no CSV file in the folder %s. Not read as a table: image.csv: %s" % (only, why)


# ---------------------------------------------------------------------------------------------- the samples: nothing changes
def samples_snapshot(tmp):
    """The data dictionary, the Manager's review text, the recognised tool and what the Data Explorer's model is shown, for the
    five files of the sample recording (no model: the profile and the Manager's code), as one text without times and folders."""
    out = {}
    for f in family1.inventory(S08):
        prof = family1.full_profile(f["path"], f["level"])
        prof.pop("seconds", None)
        tool = family1.exported_by(prof["columns"], None)
        memory = dict(prof, summary="a table", agent="Data Explorer", exported_by=tool)
        for c in memory["columns"]:
            c["observed"] = ""
        mem = os.path.join(tmp, "memory_%s.json" % f["name"])
        with open(mem, "w", encoding="utf-8") as fh:
            json.dump(memory, fh)
        res = family1._manager(_ManagerCtx(os.path.join(tmp, "boxes"), mem), f)
        with open(os.path.join(tmp, "boxes", "manager_" + f["name"], "dictionary.json"), encoding="utf-8") as fh:
            d = json.load(fh)
        for k in ("made", "explorer_memory", "grounder_memory"):
            d.pop(k, None)
        out[f["name"]] = {"dictionary": d, "body": res.review["body"], "exported_by": tool,
                          "explorer_sees": [family1._slim(c) for c in prof["columns"] if c["rows_with_value"]]}
    return json.dumps(out, sort_keys=True, ensure_ascii=False).replace(json.dumps(APP)[1:-1], "<app>")


def test_the_sample_recordings_dictionaries_are_byte_for_byte_what_they_were_before_the_join(tmp_path):
    if not os.path.isdir(S08):
        pytest.skip("the S08 sample recording is not on this machine (the code-only zip carries no samples)")
    text = samples_snapshot(str(tmp_path))
    assert len(text) == 209837 and hashlib.sha256(text.encode("utf-8")).hexdigest() == SAMPLES_BEFORE, (
        "the data dictionary of a sample file is not what it was on 2026-11-15: if that is wanted, take the new SHA-256 from samples_snapshot()")
    assert "written_as" not in text and "number_style" not in text and "chosen" not in text
