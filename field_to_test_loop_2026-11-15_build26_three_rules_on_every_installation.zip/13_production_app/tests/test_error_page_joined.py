"""The page of one error with the three parts of 2026-11-14 joined (coverage check of 2026-11-14, items B2, B6, B7 and the cause rules):
the isolation and the approval of a test keep the rows around the error in the knowledge base; an archive that fails never fails the
admin's action; the model that writes "why" and "how" sees the Abort and the reset of a command that never completed; the page shows
that section, the kept-rows sentence and the hand-over part, with nothing chosen in advance.

    python3 -m pytest -q -p no:cacheprovider tests/test_error_page_joined.py

Everything runs in temporary folders; the tree is built on one core from samples/clean_five_files/S17_io_timeout_abort_reset.
ERROR_PAGE_TREE=<a hier.sqlite built from that sample> skips the loading (a developer's shortcut, nothing else).
"""
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.dirname(HERE)
sys.path.insert(0, APP)
sys.path.insert(0, os.path.join(APP, "app"))

S17 = os.path.join(APP, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
PAGE = os.path.join(APP, "app", "static", "isolate.html")
SCRIPT = os.path.join(APP, "app", "static", "js", "isolate.js")
NODE = "/home/raghavendra/.nvm/versions/node/v22.23.2/bin/node"
UID = "up-s17"
KEPT = "The rows around this error are kept in the knowledge base ("
NOT_KEPT = "The rows around this error were not kept in the knowledge base"


def _read(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def _copy_db(src, dst):
    a = sqlite3.connect("file:%s?mode=ro" % src, uri=True)
    b = sqlite3.connect(dst)
    a.backup(b)
    a.close()
    b.close()


@pytest.fixture(scope="module")
def s17(tmp_path_factory):
    """The tree of the sample S17 (commands that never completed, the host's Aborts, controller resets), built once on one core."""
    cache = os.environ.get("ERROR_PAGE_TREE")
    if cache and os.path.isfile(cache):
        return cache
    if not os.path.isdir(S17) or not all(os.path.exists(os.path.join(S17, n)) for n in NAMES.values()):
        pytest.skip("the S17 sample recording is not on this machine (the code-only zip carries no samples)")
    from nvme_hier import builder as B, loader as L, rules as RL
    db = str(tmp_path_factory.mktemp("s17_tree") / "hier.sqlite")
    was = os.environ.get("F2T_WORKERS")
    os.environ["F2T_WORKERS"] = "1"          # a test must not compete with the owner's running work
    try:
        L.load_upload(db, {k: os.path.join(S17, n) for k, n in NAMES.items()})
        B.build(db)
        RL.apply(db)
    finally:
        if was is None:
            os.environ.pop("F2T_WORKERS", None)
        else:
            os.environ["F2T_WORKERS"] = was
    return db


def _error_of(db, command_row):
    """The number of the cmd.timeout error on one NVMe command row of the sample."""
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    try:
        r = con.execute("SELECT id FROM finding WHERE rule = 'cmd.timeout' AND cmd_rowid = ? ORDER BY id LIMIT 1", (command_row,)).fetchone()
    finally:
        con.close()
    assert r, "the sample has no cmd.timeout error on NVMe command row %d" % command_row
    return r[0]


def _upload(root, tree, uid):
    d = os.path.join(root, "uploads", uid)
    os.makedirs(d)
    _copy_db(tree, os.path.join(d, "hier.sqlite"))
    with open(os.path.join(d, "meta.json"), "w", encoding="utf-8") as fh:
        json.dump({"upload_id": uid, "created": 1, "operator": "t", "device": "", "trace_name": "S17 sample", "recording_date": "", "notes": "",
                   "files": {k: os.path.join(S17, n) for k, n in NAMES.items()}, "status": "loaded", "thresholds": {}, "file_stats": {}}, fh)
    return d


@pytest.fixture(scope="module")
def app_s17(s17):
    """A throw-away application (its own root, the model connection pointing nowhere) with the S17 tree as the upload up-s17.
    What it replaces in the application's modules is put back afterwards."""
    import copy
    from agentic import core, family1
    from api import config_api, hier_api
    root = tempfile.mkdtemp(prefix="error_page_joined_%d_" % os.getpid())
    was = (config_api.save_config, hier_api.ENV_FILE, family1.knowledge_dir, core.Engine.kick)
    try:
        with open(os.path.join(APP, "config", "app_config.json"), encoding="utf-8") as fh:
            cfg = copy.deepcopy(json.load(fh))
        cfg["_path"] = os.path.join(root, "app_config.json")
        cfg["llm"].update(base_url="http://127.0.0.1:9", api_key_env="FUZZ_NO_SUCH_KEY", backend="http")
        cfg["agentic"].update(runtime="standin", web=False)
        cfg.setdefault("server", {})["api_calls"] = True
        config_api.save_config = lambda c: None
        hier_api.ENV_FILE = os.path.join(root, "env")            # a test must never reach the real key file
        family1.knowledge_dir = lambda: os.path.join(root, "knowledge")
        core.Engine.kick = lambda self, rid: None
        for d in ("knowledge", "config", "uploads"):
            os.makedirs(os.path.join(root, d), exist_ok=True)
        shutil.copy(os.path.join(APP, "config", "app_config.json"), os.path.join(root, "config", "app_config.json"))
        from server import create_app
        app = create_app(cfg, root)
        _upload(root, s17, UID)
        yield app.test_client(), root
    finally:
        config_api.save_config, hier_api.ENV_FILE, family1.knowledge_dir, core.Engine.kick = was
        shutil.rmtree(root, ignore_errors=True)


def _isolate(c, uid, fid, **more):
    body = dict({"anyway": True, "standin": True, "isolation": True, "history": True, "name": "Sagar", "n": 5, "m": 3,
                 "levels": ["nvme_transaction", "split", "link", "packets"]}, **more)
    return c.post("/api/isolate/%s/%d/isolate" % (uid, fid), json=body)


def _written_test(c, uid, fid, sequence):
    """The test file of one error, written through the page's own two calls (no model: the code's own plan)."""
    base = "/api/isolate/%s/%d/" % (uid, fid)
    prop = c.post(base + "testcase", json={"sequence": sequence, "name": "Sagar", "standin": True})
    assert prop.status_code == 200, prop.get_json()
    prop = prop.get_json()
    made = c.post(base + "testcase", json={"sequence": prop["sequence"], "expected_outcomes": prop["expected_outcomes"], "verified": True, "name": "Sagar"})
    assert made.status_code == 200, made.get_json()
    return made.get_json()


# ---------------------------------------------------------------------------------------------- task 1: the two moments keep the rows
def test_isolating_and_approving_keep_the_rows_and_they_are_read_back_after_the_upload_is_removed(app_s17, s17):
    c, root = app_s17
    uid = "up-s17-gone"                      # an upload of its own: this test removes it
    _upload(root, s17, uid)
    fid = _error_of(s17, 155)                # a Write the drive never completed
    r = _isolate(c, uid, fid, queue="all")
    assert r.status_code == 200, r.get_json()
    iso = r.get_json()
    t = iso["trace"]
    assert t["archived"] and t["words"].startswith(KEPT + "the error's command with 5 commands above and 3 below; "), t["words"]
    assert t["record"]["archived_by"] == "Sagar" and t["record"]["reason"] == "the isolation of this error was kept"
    assert (t["record"]["n_above"], t["record"]["m_below"]) == (5, 3)                 # the admin's real window, not the default
    assert iso["isolation"]["card"]["after"]["abort"]["row"] == 216                   # the same answer carries the card's new section
    # asked again from the same evidence the isolation is the kept one, and nothing is copied twice
    again = _isolate(c, uid, fid).get_json()
    assert again["isolation"]["kept_at"] and again["trace"]["archived"] and "nothing was copied again" in again["trace"]["did"]
    # the test of this error is written and approved: the approval archives too
    made = _written_test(c, uid, fid, iso["sequence"])
    ap = c.post("/api/isolate/%s/%d/testcase/approve" % (uid, fid), json={"path": made["path"], "name": "Sagar", "two_sided": True})
    assert ap.status_code == 200, ap.get_json()
    ap = ap.get_json()
    assert ap["ok"] and ap["approved"]["status"] == "approved" and ap["trace"]["archived"] and ap["trace"]["words"].startswith(KEPT)
    log = sqlite3.connect(os.path.join(root, "db", "hier_knowledge.sqlite"))
    try:
        reasons = [x[0] for x in log.execute("SELECT reason FROM kb_trace_log WHERE upload_id = ? AND finding_id = ? ORDER BY id", (uid, fid))]
    finally:
        log.close()
    assert reasons[0] == "the isolation of this error was kept" and reasons[-1] == "the test of this error was approved", reasons
    # the rows come back from the knowledge base alone once the upload folder is gone
    before = c.get("/api/dg/trace?upload=%s&finding=%d" % (uid, fid)).get_json()
    assert before["levels"]["nvme_command"]["count"] == 9                             # 5 above, the error's command, 3 below
    shutil.rmtree(os.path.join(root, "uploads", uid))
    after = c.get("/api/dg/trace?upload=%s&finding=%d" % (uid, fid))
    assert after.status_code == 200 and after.get_json()["levels"] == before["levels"]
    rows = [x["row"] for x in after.get_json()["levels"]["nvme_command"]["rows"]]
    assert rows == list(range(150, 159)), rows
    assert all(after.get_json()["levels"][lv]["count"] > 0 for lv in ("nvme_transaction", "packets"))


def test_approving_alone_keeps_the_rows_of_an_error_that_was_never_isolated_with_the_isolation_part(app_s17, s17):
    c, root = app_s17
    fid = _error_of(s17, 443)
    plain = c.post("/api/isolate/%s/%d/isolate" % (UID, fid), json={"anyway": True, "standin": True, "name": "Sagar", "n": 4, "m": 2})
    assert plain.status_code == 200 and "trace" not in plain.get_json()               # no isolation asked for: nothing is kept, nothing is claimed
    assert c.get("/api/dg/trace?upload=%s&finding=%d&rows=0" % (UID, fid)).status_code == 404
    made = _written_test(c, UID, fid, plain.get_json()["sequence"])
    ap = c.post("/api/isolate/%s/%d/testcase/approve" % (UID, fid), json={"path": made["path"], "name": "Sagar"}).get_json()
    assert ap["ok"] and ap["trace"]["archived"] and ap["trace"]["record"]["reason"] == "the test of this error was approved"
    assert c.get("/api/dg/trace?upload=%s&finding=%d&rows=0" % (UID, fid)).status_code == 200
    # the hand-over part of the page: the listing holds this error's approved test under the name the page filters by ("<upload>_f<error>_"),
    # nothing but the admin's tick puts it into a package, and no result is shown before one is brought in
    mine = [t for t in c.get("/api/handover/tests").get_json()["tests"] if t["name"].startswith("%s_f%d_" % (UID, fid))]
    assert len(mine) == 1 and mine[0]["name"] == os.path.basename(made["path"])
    assert mine[0]["approval"]["state"] == "approved" and mine[0]["approval"]["can_hand_over"] and mine[0]["approval"]["approved_by"] == "Sagar"
    assert mine[0]["finding"] == fid and mine[0]["recording"]["upload"] == UID        # the second way the page recognises its own test
    assert mine[0]["run_history"]["only_simulated_drive"] is True and mine[0]["run_history"]["words"]
    assert c.post("/api/handover/package", json={"tests": [], "name": "Sagar"}).status_code == 400       # nothing ticked: no package
    assert c.post("/api/handover/package", json={"tests": [mine[0]["name"]], "name": ""}).status_code == 400    # no name: no package
    pk = c.post("/api/handover/package", json={"tests": [mine[0]["name"]], "name": "Sagar"})
    assert pk.status_code == 200 and pk.headers["X-Handover-Package"].startswith("handover-") and len(pk.headers["X-Handover-Sha256"]) == 64 and pk.data[:2] == b"PK"
    assert c.get("/api/handover/results?test=%s" % mine[0]["name"]).get_json()["tests"] == []


# ---------------------------------------------------------------------------------------------- an archive that fails never fails the action
@pytest.mark.parametrize("fault", ["raises", "is missing", "answers nonsense"])
def test_an_archive_that_fails_does_not_fail_the_isolation_or_the_approval(app_s17, s17, monkeypatch, fault):
    from api import dg_api
    c, root = app_s17
    fid = _error_of(s17, 295)

    def broken(*a, **k):
        raise RuntimeError("the disk of the knowledge base is full")
    if fault == "raises":
        monkeypatch.setattr(dg_api, "archive_trace", broken)
    elif fault == "is missing":
        monkeypatch.delattr(dg_api, "archive_trace")
    else:
        monkeypatch.setattr(dg_api, "archive_trace", lambda *a, **k: ["not", "an", "answer"])
    r = _isolate(c, UID, fid, rewrite=True)          # written again, so the isolation is kept anew under the broken archive
    assert r.status_code == 200, r.get_json()
    iso = r.get_json()
    assert iso["isolation"]["cause_key"] and iso["isolation"]["what"] and iso["sequence"]
    assert iso["trace"]["archived"] is False and iso["trace"]["words"].startswith(NOT_KEPT) and iso["trace"]["record"] is None
    if fault == "raises":
        assert "the disk of the knowledge base is full" in iso["trace"]["words"]
    kept = _isolate(c, UID, fid).get_json()          # the isolation itself was kept: asked again it is the stored one
    assert kept["isolation"]["kept_at"] and kept["isolation"]["why"] == iso["isolation"]["why"]
    made = _written_test(c, UID, fid, iso["sequence"])
    ap = c.post("/api/isolate/%s/%d/testcase/approve" % (UID, fid), json={"path": made["path"], "name": "Sagar"})
    assert ap.status_code == 200, ap.get_json()
    assert ap.get_json()["ok"] and ap.get_json()["trace"]["archived"] is False and ap.get_json()["trace"]["words"].startswith(NOT_KEPT)
    with open(made["path"] + ".approved.json", encoding="utf-8") as fh:
        assert json.load(fh)["approved_by"] == "Sagar"                                # the approval record is written all the same


# ---------------------------------------------------------------------------------------------- task 2: the model sees the Abort and the reset
def _card(db, command_row):
    from nvme_hier import evidence as EV, terms as TM
    from api.hier_api import _finding
    con = sqlite3.connect("file:%s?mode=ro" % db, uri=True)
    con.row_factory = sqlite3.Row
    try:
        f = _finding(con, _error_of(db, command_row))
        card = EV.card(con, f)
    finally:
        con.close()
    key, words = EV.decide_cause(card)
    return f, card, TM.cause_of(key), words, EV.facts(card, TM.defect_term(f), key)


def test_the_explain_prompt_of_a_command_that_never_completed_holds_the_abort_and_the_reset(s17):
    from nvme_hier import isolate as ISO
    f, card, cause, words, facts = _card(s17, 155)
    a = card["after"]
    assert a["abort"]["row"] == 216 and a["reset"]["row"] == 3153 and a["others"]["answered"] == 119 and a["others"]["answered_same_queue"] == 34
    prompt = ISO.explain_prompt(f, card, cause, words, facts, [])
    line = next(x for x in prompt.split("\n") if x.startswith('{"rule"'))
    seen = json.loads(line)["after"]
    assert seen["abort"]["row"] == 216 and seen["abort"]["names"] == [3, 26] and seen["abort"]["answered"] is False
    assert seen["abort"]["after_doorbell_ps"] == a["abort"]["after_doorbell_ps"] and 29.9e12 < seen["abort"]["after_doorbell_ps"] < 30.1e12
    assert seen["reset"]["row"] == 3153 and 59.9e12 < seen["reset"]["after_doorbell_ps"] < 60.1e12
    assert seen["first_stopped"] is None and seen["others"]["answered"] == 119 and seen["others"]["answered_same_queue"] == 34
    # the size: the card stays one line of the prompt (the bound on evidence lines still governs), and the section is small even when every
    # list in it is as long as the card's own caps allow (5 unreadable Aborts, 6 unreadable register writes, a long reason each)
    without = ISO.explain_prompt(f, dict(card, after=None), cause, words, facts, [])
    assert len(prompt.split("\n")) == len(without.split("\n")) and 0 < len(prompt) - len(without) < 2500, len(prompt) - len(without)
    worst = dict(card, after=dict(a, aborts_unreadable=[{"row": 10 ** 7 + k, "after_doorbell_ps": 10 ** 14, "why": "w" * 200} for k in range(5)],
                                  register_writes_unreadable=[{"row": 10 ** 7 + k, "at_ps": 10 ** 14, "capped": True} for k in range(6)]))
    assert len(ISO.explain_prompt(f, worst, cause, words, facts, [])) - len(without) < 6000
    many = ISO.explain_prompt(f, card, cause, words, facts, [{"level": "nvme_command", "rowid": k, "summary": "x"} for k in range(ISO.MAX_CONTEXT_LINES + 50)])
    assert "and 50 more rows not shown" in many and '"after": {' in many             # the evidence rows are still cut at the code's own bound
    # a completed command has no such section, and its prompt says so with a plain null
    f2, card2, cause2, words2, facts2 = _card(s17, 144)
    assert card2["after"] is None and '"after": null' in ISO.explain_prompt(f2, card2, cause2, words2, facts2, [])


def test_the_isolate_route_gives_that_prompt_to_the_model(app_s17, s17, monkeypatch):
    from api import isolate_api
    c, root = app_s17
    fid = _error_of(s17, 509)                # a Write that was only outstanding: the Write of row 443 stopped first
    seen = []

    def no_model(llm, prompt, schema, must_have):
        seen.append((must_have, prompt))
        return None, "stand-in"
    monkeypatch.setattr(isolate_api.ISO, "call_model", no_model)
    r = _isolate(c, UID, fid, rewrite=True)
    assert r.status_code == 200, r.get_json()
    why = [p for k, p in seen if k == "why"]
    assert len(why) == 1
    card = json.loads(next(x for x in why[0].split("\n") if x.startswith('{"rule"')))
    assert card["after"]["abort"]["row"] == 570 and card["after"]["reset"]["row"] == 5822 and card["after"]["first_stopped"]["row"] == 443
    assert card["after"] == json.loads(json.dumps(r.get_json()["isolation"]["card"]["after"]))


# ---------------------------------------------------------------------------------------------- tasks 3 to 6: the page files
def _top_names(js):
    return [a or b for a, b in re.findall(r"^(?:async\s+)?function\s+([A-Za-z_$][\w$]*)|^(?:const|let|var|class)\s+([A-Za-z_$][\w$]*)", js, flags=re.M)]


def test_the_page_files_hold_the_new_parts_and_nothing_is_chosen_in_advance(tmp_path):
    html, js = _read(PAGE), _read(SCRIPT)
    # the hand-over part sits after the test part and before the questions; its navigation button exists
    assert html.index('id="s-test"') < html.index('id="s-handover"') < html.index('id="s-ask"') and 'data-go="s-handover"' in html
    assert html.index('id="s-solution"') < html.index('id="s-search"') < html.index('id="s-test"')      # the search part was not disturbed
    assert 'id="handover-out"' in html and "Hand over to the validation suite" in html
    for text in ("Build the package for the validation suite", "Bring a result file in", "/api/handover/tests", "/api/handover/package", "/api/handover/results",
                 "What followed this command, which the drive never completed", "${afterHtml(c.after)}"):
        assert text in js, text
    # no second top-level function or constant of one name: the browser would refuse the whole module
    names = _top_names(js)
    assert sorted({n for n in names if names.count(n) > 1}) == [] and {"seqTable", "srSeqTable", "afterHtml", "showHandover", "showSearch", "traceLine", "windowSent"} <= set(names)
    if os.path.exists(NODE):                 # as a module (node --check on the .js name does not apply module rules)
        copy = str(tmp_path / "isolate_copy.mjs")
        shutil.copy(SCRIPT, copy)
        done = subprocess.run([NODE, "--check", copy], capture_output=True, text=True)
        assert done.returncode == 0, done.stderr
    # every field label has its why-line directly under it, longer than 40 characters
    labels = re.findall(r'<label class="f"[^>]*>.*?</label>\s*(<div class="why">(.*?)</div>)?', js + html, flags=re.S)
    assert len(labels) >= 6 and all(why and len(text) > 40 for why, text in labels), labels
    assert {"ho-name", "ho-file"} <= set(re.findall(r'<label class="f" for="([\w-]+)"', js))
    # nothing chosen in advance: no ticked box, no chosen option, no name typed for the admin, both buttons locked until the admin acts
    block = js[js.index("async function showHandover"):js.index("async function hoBuild")]
    picks = re.findall(r'<input type="checkbox" class="ho-pick"[^>]*>', block)
    assert len(picks) == 1 and "checked" not in picks[0].replace(":checked", "")
    assert not re.search(r'<input id="ho-name"[^>]*\svalue=', block) and not re.search(r"\bselected\b|\bchecked\b(?!\")", re.sub(r":checked", "", block))
    assert '<button class="primary" id="btn-ho-build" disabled>' in block and '<button id="btn-ho-bring" disabled>' in block
    assert '$("btn-ho-build").disabled = !(picked && nm)' in block                    # opened only by a tick and a name
    assert "tests.filter(hoMine)" in block and "${UID}_f${FID}_" in js                # this error's test files only
    assert "checked" not in "".join(re.findall(r'<input type="radio"[^>]*>', js))
    # the kept-rows sentence is shown with each action, and the window on the screen goes with the three knowledge-base calls
    for shown in ("traceLine(S.iso.trace)", "traceLine(o.trace)", "showSolutions(r.did, r.trace)", "come back`], r.trace)", "traceLine(r.trace)", "${traceLine(trace)}"):
        assert shown in js, shown
    assert js.count("traceLine(o.trace)") == 2 and js.count("...windowSent()") == 4   # two occurrence calls, the stored solution, the judgement
    for call in ('"/api/dg/occurrences"', '"/api/dg/solutions"', "/verdict`"):
        assert call in js
    sent = re.search(r"const windowSent = .*", js).group(0)
    assert 'queue: "all"' in sent and "S.shownWindow" in sent
    # the new section of the evidence card names every value it shows
    part = js[js.index("function afterHtml"):js.index("async function nameDefect")]
    for words in ("The host's Abort for this command", "Did the drive answer that Abort", "The controller reset", "First to stop, or only outstanding",
                  "Other commands the drive answered during the wait", "on this command's own queue", "Rows that could not be read", "what it means",
                  "seconds (s), milliseconds (ms), microseconds (µs) or nanoseconds (ns)"):
        assert words in part, words
    assert "opc" not in part and "dw0" not in part and "sqid" not in part            # no raw field name reaches the screen


def test_the_server_side_text_files_are_opened_as_utf8():
    for rel in ("app/api/isolate_api.py", "nvme_hier/isolate.py", "tests/test_error_page_joined.py"):
        src = _read(os.path.join(APP, rel))
        for m in re.finditer(r"\bopen\(([^()]*(?:\([^()]*\)[^()]*)*)\)", src):
            call = m.group(1)
            assert "encoding=" in call or '"rb"' in call or '"wb"' in call or "'rb'" in call, (rel, call)
