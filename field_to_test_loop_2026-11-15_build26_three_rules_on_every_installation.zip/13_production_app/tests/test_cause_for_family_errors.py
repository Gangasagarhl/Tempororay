"""The cause of an error does not depend on WHICH RULE found its command (2026-11-15).

    python3 -m pytest -q -p no:cacheprovider tests/test_cause_for_family_errors.py

The fault this file keeps away (seen in a browser on sample S17, command row 155): the same command is found twice, by the detector's
rule "NVMe command timeout" and by the rule family "A command never completed" of the NVMe command level. Worked through as the
detector's error the cause rules named a cause; worked through as the family's error the page said "none of the fixed rules applies to
this evidence". The evidence card took the steps of the command's cycle, the host's limit and the usual time only from the detail the
detector keeps with its timeout rule; a family's finding (nvme_hier/coded_findings.py) keeps none of them. Now the card reads what a
finding does not carry from the command's own rows in the tree (nvme_hier/evidence.py _read_from_tree), so:

  * every command of S17 that the detector and a family both find gets one cause, with the same words and the same evidence: the six
    commands that never completed, the two Aborts among them, the Read that completed as aborted;
  * the Aborts the drive answered and the set-ups of the controller after a reset, which only a family finds, say honestly that no fixed
    rule applies, with what the command's own rows show and what the rules would have needed; no cause is made up;
  * an admin's own rule, a version-2 key of a family, another rule of the detector and a finding whose detail is damaged all behave the
    same on the same command: the rule's name is not read for the cause;
  * what the wider reach must not get wrong: a command still open when the recording ended, an Asynchronous Event Request, an Abort that
    names another command or cannot be read, a status without a completion entry, a tree without its NVMe transactions, a tree in which
    the detector kept no times.

The tree of the S17 sample (samples/clean_five_files/S17_io_timeout_abort_reset) is built once in a temporary folder and every seeded
rule family is run on it and filed the way the flow files it; every hand-made recording is a copy of that tree. Nothing of the
application's own folders is touched.
"""
import csv
import json
import os
import shutil
import sqlite3
import sys
import tempfile

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
APP_DIR = os.path.dirname(HERE)
for p in (APP_DIR, os.path.join(APP_DIR, "app"), HERE):
    if p not in sys.path:
        sys.path.insert(0, p)
from nvme_hier import coded_findings as CF, command_error_rules as CE, evidence as EV, terms as TM, tree_api as T   # noqa: E402

S17 = os.path.join(APP_DIR, "samples", "clean_five_files", "S17_io_timeout_abort_reset")
NAMES = {"packets": "packets.csv", "link": "link.csv", "split": "split.csv", "nvme_transaction": "NVME_Transactions.csv", "nvme_command": "nvme_command.csv"}
pytestmark = pytest.mark.skipif(not all(os.path.exists(os.path.join(S17, v)) for v in NAMES.values()),
                                reason="the S17 sample folder (samples/clean_five_files/S17_io_timeout_abort_reset) is not on this machine")
S = 10 ** 12
# what the existing test of the detector's errors fixes for S17 (tests/test_cause_never_completed.py EXPECTED)
CAUSE = {144: "host_abort_by_tool_or_test", 155: "device_internal_delay", 295: "device_internal_delay", 443: "device_internal_delay",
         509: "device_internal_delay", 216: "host_reset_or_driver_recovery", 358: "host_reset_or_driver_recovery"}
NEVER, ABORTS, ABORTED = [155, 216, 295, 358, 443, 509], [145, 216, 358, 501, 570], [144]
ABORT_OF = {155: 216, 295: 358, 443: 501, 509: 570}
NAMED_BY = {145: (144, True), 501: (443, False), 570: (509, False)}      # an answered Abort: the command its parameters name, and whether that one completed
NOT_EVIDENCE = ("version", "rule", "kind", "error_row", "level", "read_from_tree")      # the parts of a card that name the finding, not what the command's rows show
NOTHING = "none of the fixed rules applies to this evidence: "
NEEDS = ("To name a cause the rules need one of these in the command's own rows: a link event or packets of the command that were refused or left unacknowledged, "
         "no completion of the command, an Abort of the host that names it, a completion entry without its interrupt or its head doorbell, a media error status, "
         "or an answer slower than usual for its command type and size.")
FAMILY = "admin.errors.nvme_command.cmd_family_%s.v1"


def origin_of(f):
    """Whose rule a family's finding says it is, as the flow decides it (agentic/family3.rule_origin for a seeded item)."""
    from agentic import family3
    return family3.rule_origin(CE.item(f), by_application=True)


def run_family(db, fid, out_csv, version=1):
    """One seeded family run on the tree by the application's reference implementation and filed as errors, the way the flow does it."""
    tree = T.Tree(db)
    try:
        r = CE.run_on_tree(tree, out_csv, fid)
    finally:
        tree.close()
    if not r["rows_written"]:
        return r, None
    return r, CF.file_findings(db, "errors", "nvme_command", CE.item_id(fid), version, CE.BY_ID[fid]["name"], out_csv, approved_by="t", origin=origin_of(CE.BY_ID[fid]))


@pytest.fixture(scope="module")
def tree():
    """The S17 tree, built the way the application builds it, with every seeded rule family run on it and its rows filed as errors."""
    from nvme_hier import builder as B, loader as L, rules as RL
    base = os.environ.get("F2T_TEST_TMP") or None
    if base:
        os.makedirs(base, exist_ok=True)
    d = tempfile.mkdtemp(prefix="cause_family_", dir=base)
    db = os.path.join(d, "hier.sqlite")
    L.load_upload(db, {k: os.path.join(S17, v) for k, v in NAMES.items()})
    B.build(db)
    RL.apply(db)
    filed = {}
    for f in CE.FAMILIES:
        if f["checkable"]:
            r, got = run_family(db, f["id"], os.path.join(d, "out_%s.csv" % f["id"]))
            filed[f["id"]] = got["total"] if got else 0
    yield {"db": db, "dir": d, "filed": filed}
    shutil.rmtree(d, ignore_errors=True)


@pytest.fixture
def con(tree):
    c = sqlite3.connect("file:%s?mode=ro" % tree["db"], uri=True)
    yield c
    c.close()


@pytest.fixture
def copy(tree, tmp_path):
    """A hand-made recording: a copy of the tree to change. -> a function giving (path, connection) of a new copy."""
    made = []

    def make():
        p = str(tmp_path / ("copy%d.sqlite" % len(made)))
        src, dst = sqlite3.connect(tree["db"]), sqlite3.connect(p)
        src.backup(dst)
        src.close()
        dst.row_factory = sqlite3.Row
        made.append(dst)
        return p, dst
    yield make
    for c in made:
        c.close()


def found(con, where, args=()):
    """Findings of the tree as the rows hold them (the detail as JSON text)."""
    con.row_factory = sqlite3.Row
    return [dict(r) for r in con.execute("SELECT * FROM finding WHERE %s ORDER BY rowid, id" % where, args)]


def of_family(con, fid, row=None):
    out = found(con, "rule=?" + ("" if row is None else " AND rowid=%d" % row), (FAMILY % fid,))
    return out if row is None else out[0]


def of_detector(con, row, rule="cmd.timeout"):
    return found(con, "rule=? AND cmd_rowid=?", (rule, row))[0]


def decided(con, f):
    """(card, cause keyword, words) of a finding, the way the page calls it; the same whether the detail arrives as text or as an object."""
    c = EV.card(con, f)
    key, words = EV.decide_cause(c)
    assert key in TM.CAUSES, key
    json.dumps(c)                                                        # the card is plain data
    if isinstance(f.get("detail"), str):
        try:
            as_object = dict(f, detail=json.loads(f["detail"]))
        except ValueError:
            as_object = None
        if as_object is not None:
            c2 = EV.card(con, as_object)
            assert c2 == c and EV.decide_cause(c2) == (key, words)
    assert EV.decide_cause(json.loads(json.dumps(c))) == (key, words)    # the stored card decides the same
    return c, key, words


def evidence(c):
    return {k: v for k, v in c.items() if k not in NOT_EVIDENCE}


def same_cause(con, f, g):
    """Two findings of one command: the same cause keyword, the same words (the rule that decided, with its measured numbers), the same
    evidence, the same basis of the keyword, and the same when / where / which / who stated by the code."""
    cf, kf, wf = decided(con, f)
    cg, kg, wg = decided(con, g)
    assert (kf, wf) == (kg, wg), (f["rule"], g["rule"], kf, kg, wf, wg)
    assert evidence(cf) == evidence(cg), [k for k in evidence(cf) if evidence(cf)[k] != evidence(cg).get(k)]
    assert TM.cause_of(kf) == TM.cause_of(kg) and TM.cause_of(kf)["evidence"] == TM.CAUSES[kf][2]
    term = {"name": "the same name"}
    assert EV.facts(cf, term, kf) == EV.facts(cg, term, kg)
    return cf, kf, wf


def stop_command(con, row):
    """Make a completed command one without a completion: no status, no time, and its completion entry, interrupt and head doorbell gone."""
    con.execute("UPDATE cmd SET st=NULL, sct=NULL, sc=NULL, dur_ps=NULL WHERE rowid_file=?", (row,))
    con.execute("DELETE FROM ntx WHERE parent_level='nvme_command' AND parent=? AND (type LIKE '%Completion Queue Entry' OR type LIKE 'MSI-X%' OR type LIKE 'Completion Queue Head%')", (row,))
    con.commit()


def last_io_command_stopped(con):
    """The last I/O command of the recording, made one without a completion, with no access to the controller configuration register
    after it: no Abort names it, no reset follows, and the recording ends less than a second after it was sent. -> its row."""
    row, t0 = con.execute("SELECT rowid_file, t_ps FROM cmd WHERE sqid!=0 AND sct=0 AND sc=0 ORDER BY t_ps DESC, rowid_file DESC LIMIT 1").fetchone()
    stop_command(con, row)
    con.execute("DELETE FROM ntx WHERE type=? AND t_ps>?", (EV.CC_TYPE, t0))
    con.commit()
    return row


def own(row, rule="admin.errors.nvme_command.my_rule.v1", detail=None):
    """A finding of an admin's own rule on one command row, as the tree would hold it."""
    return {"rule": rule, "level": "nvme_command", "rowid": row, "cmd_rowid": row, "detail": json.dumps(detail if detail is not None else {"kind": CF.kind_words("my_rule")})}


def healthy_read(con):
    """A Read on an I/O queue that completed with success and that no rule found."""
    return con.execute("SELECT rowid_file FROM cmd WHERE sqid!=0 AND opc=2 AND sct=0 AND sc=0 AND rowid_file NOT IN (SELECT rowid FROM finding WHERE level='nvme_command') "
                       "ORDER BY rowid_file LIMIT 1").fetchone()[0]


# ------------------------------------------------------------------------------------------------- what the sample holds, and the gap
def test_the_families_found_these_rows_of_s17_and_their_findings_keep_no_cycle(tree, con):
    assert len(CE.items()) == 38 and set(tree["filed"]) == {f["id"] for f in CE.FAMILIES if f["checkable"]}
    assert {k: v for k, v in tree["filed"].items() if v} == {"behaviour_01": 6, "behaviour_03": 5, "behaviour_04": 3, "status_13": 1}
    assert [f["rowid"] for f in of_family(con, "behaviour_01")] == NEVER and [f["rowid"] for f in of_family(con, "behaviour_03")] == ABORTS
    assert [f["rowid"] for f in of_family(con, "status_13")] == ABORTED
    d = json.loads(of_family(con, "behaviour_01", 155)["detail"])
    # the cause of the gap: nothing of what the cause rules read is in a family's finding
    assert d["admin_rule"]["origin"] == "application" and not ({"cycle", "host_limit_ps", "usual_bar_ps", "median_ps"} & set(d))
    assert {"cycle", "host_limit_ps", "usual_bar_ps", "median_ps"} <= set(json.loads(of_detector(con, 155)["detail"]))
    assert EV.CARD_VERSION == 3


def test_every_command_that_the_detector_and_a_family_both_find_gets_one_cause(con):
    pairs = []
    for f in found(con, "level='nvme_command' AND rule LIKE 'admin.errors.nvme_command.cmd_family_%'"):
        t = found(con, "rule='cmd.timeout' AND cmd_rowid=?", (f["rowid"],))
        if not t:
            continue
        c, key, words = same_cause(con, t[0], f)
        assert key == CAUSE[f["rowid"]], (f["rowid"], f["rule"], key, words)
        assert key != "unknown_cause" and not words.startswith("none of the fixed rules")
        card_f, card_t = EV.card(con, f), EV.card(con, t[0])
        assert card_f["read_from_tree"] == [EV.READ_CYCLE, EV.READ_TIMES] and "read_from_tree" not in card_t      # said where the family's card took them
        pairs.append((f["rowid"], f["rule"].split("cmd_family_")[1]))
    assert sorted(pairs) == [(144, "status_13.v1"), (155, "behaviour_01.v1"), (216, "behaviour_01.v1"), (216, "behaviour_03.v1"), (295, "behaviour_01.v1"),
                             (358, "behaviour_01.v1"), (358, "behaviour_03.v1"), (443, "behaviour_01.v1"), (509, "behaviour_01.v1")]


def test_the_six_commands_that_never_completed(con):
    for row in NEVER:
        c, key, words = decided(con, of_family(con, "behaviour_01", row))
        a = c["after"]
        assert c["completed"] is False and key == CAUSE[row] and a["wait_end"] == "controller reset" and a["others"]["answered"] > 0
        assert c["host_limit_ps"] == (60 if row in (216, 358) else 30) * S and c["nak"] == 0 and c["unacked"] == 0 and c["packets"] > 0
        if row in ABORT_OF:                                              # a Write: stopped after the data; its own Abort by the Abort's parameters
            assert c["reached"] == ["submitted", "fetched", "data"] and c["stopped_after"] == "data" and c["median_ps"] == 17657750 and c["usual_ps"] == 74465250
            assert a["abort"]["row"] == ABORT_OF[row] and a["abort"]["names"] == [c["command"]["queue"], c["command"]["id"]]
            assert "The host sent an Abort for this command 30.000 s after it was submitted (NVMe command row %d" % ABORT_OF[row] in words
        else:                                                            # an Abort that was never answered
            assert c["reached"] == ["submitted", "fetched"] and c["stopped_after"] == "entry fetched" and a["abort"] is None
            assert "less than the host's limit for it (60.000 s)" in words and "This command is the host's Abort for that command" in words
    words = decided(con, of_family(con, "behaviour_01", 155))[2]
    assert words.startswith("the drive took the command and stopped after the data, with all of its packets acknowledged; in the 60.000 s wait that followed "
                            "(until the controller reset) the drive answered 119 other command(s) on 3 queue(s), 34 of them on this command's queue 3")
    assert "The controller was reset 60.000 s after this command was submitted" in words and "It was the first command to stop" in words


def test_the_abort_commands(con):
    for row in ABORTS:
        f = of_family(con, "behaviour_03", row)
        c, key, words = decided(con, f)
        if row in (216, 358):                                            # never answered: the detector finds it too, and the cause is the same
            assert key == "host_reset_or_driver_recovery" and c["after"]["names"]["row"] == {216: 155, 358: 295}[row] and "names" not in c
            assert decided(con, of_detector(con, row))[1:] == (key, words)
            continue
        target, completed = NAMED_BY[row]                                # answered: only the family finds it, and no fixed rule covers it
        assert not found(con, "rule LIKE 'cmd.%' AND cmd_rowid=?", (row,))
        assert key == "unknown_cause" and words.startswith(NOTHING + "the command completed with success after ") and NEEDS in words
        assert c["completed"] is True and c["abort"] is None and c["after"] is None and c["names"]["row"] == target and c["names"]["completed"] is completed
        assert words.endswith("This command is the host's Abort; its own parameters name %s, NVMe command row %d (queue %s, identifier %s), which %s: why the host sent the "
                              "Abort is decided on the error of that command." % ("Read" if target == 144 else "Write", target, c["names"]["queue"], c["names"]["id"],
                                                                                 "completed" if completed else "never completed"))
        assert "its steps in the recording are doorbell, entry fetched, completion entry, interrupt, head doorbell, and the link acknowledged all" in words


def test_the_command_that_completed_as_aborted(con):
    f = of_family(con, "status_13", 144)
    c, key, words = same_cause(con, of_detector(con, 144), f)
    assert key == "host_abort_by_tool_or_test" and c["abort"] == {"row": 145, "after_doorbell_ps": 60000000} and "abort_unreadable" not in c
    assert words.startswith("the host sent the Abort 60.000 µs after the doorbell, sooner than this command type usually takes here (median 65.775 µs); "
                            "the host's driver limit is 30.000 s")
    # before the repair this error, and the detector's own "status error" of the same row, were given "the host aborted the command after its limit (-)"
    assert "after its limit" not in words and c["times_median"] == 6.41
    same_cause(con, of_detector(con, 144), of_detector(con, 144, "cmd.status_error"))


def test_the_set_ups_of_the_controller_after_a_reset_say_that_no_fixed_rule_applies(con):
    rows = of_family(con, "behaviour_04")
    assert len(rows) == 3
    for f in rows:
        opc, sqid, sct = con.execute("SELECT opc, sqid, sct FROM cmd WHERE rowid_file=?", (f["rowid"],)).fetchone()
        assert (opc, sqid, sct) == (9, 0, 0)                             # a Set Features on the admin queue that completed with success
        c, key, words = decided(con, f)
        assert key == "unknown_cause" and TM.cause_of(key)["name"] == "not decided from this recording"
        assert words.startswith(NOTHING + "the command completed with success after ") and words.endswith(NEEDS)
        assert "no link event happened while it was outstanding; no Abort sent while it was outstanding names it" in words
        assert c["completed"] is True and c["after"] is None and c["abort"] is None and "names" not in c


def test_the_other_rules_of_the_detector_on_the_same_commands(con):
    n = 0
    for row in CAUSE:
        for f in found(con, "rule LIKE 'cmd.%' AND rule!='cmd.timeout' AND cmd_rowid=?", (row,)):
            c, key, words = same_cause(con, of_detector(con, row), f)
            assert key == CAUSE[row]
            n += 1
    assert n >= 7                                                        # "never completed: no completion entry" of the six, the status error of row 144


def test_what_the_tree_gives_is_what_the_detector_kept(con):
    """The detector's own findings are not touched: nothing is read from the tree for them, and reading everything from the tree gives the
    same evidence (so the two sources cannot drift apart unnoticed)."""
    for row in CAUSE:
        f = of_detector(con, row)
        kept = EV.card(con, f)
        bare = EV.card(con, dict(f, detail=None))
        assert "read_from_tree" not in kept and bare["read_from_tree"] == [EV.READ_CYCLE, EV.READ_TIMES]
        assert evidence(kept) == evidence(bare) and EV.decide_cause(kept) == EV.decide_cause(bare)


def test_the_rules_name_is_not_read_for_the_cause(con):
    for row in (155, 216, 144, 501):
        base = of_family(con, "behaviour_03", row) if row == 501 else of_detector(con, row)
        card = EV.card(con, base)
        want = EV.decide_cause(card)
        for rule in ("", None, "anything at all", "cmd.timeout", "cmd.incomplete", FAMILY % "behaviour_01", "admin.errors.nvme_command.my_rule.v7"):
            assert EV.decide_cause(dict(card, rule=rule)) == want
            got = EV.card(con, dict(base, rule=rule, detail=None))
            assert EV.decide_cause(got) == want and evidence(got) == evidence(card)


# ------------------------------------------------------------------------------------- an admin's own rule, a version 2, a damaged detail
def test_an_admins_own_rule_on_the_same_rows_gets_the_same_cause(copy, tmp_path):
    """Decided and said: an admin's own rule is not a rule family, and it gets the cause too, because the cause is read from the command's
    rows. A healthy command it lists gets the honest sentence."""
    path, con = copy()
    ok = healthy_read(con)
    out = str(tmp_path / "mine.csv")
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow([CF.ROW_COLUMN])
        w.writerows([[155], [144], [ok]])
    got = CF.file_findings(path, "errors", "nvme_command", "my_rule", 1, "my rule", out)
    assert got["added"] == 3 and got["rule"] == "admin.errors.nvme_command.my_rule.v1"
    mine = {f["rowid"]: f for f in found(con, "rule=?", (got["rule"],))}
    assert json.loads(mine[155]["detail"])["admin_rule"]["origin"] == "admin" and CE.family_of_item({"id": "my_rule"}) is None
    for row in (155, 144):
        c, key, words = same_cause(con, of_detector(con, row), mine[row])
        assert key == CAUSE[row]
    c, key, words = decided(con, mine[ok])
    assert key == "unknown_cause" and words.startswith(NOTHING + "the command completed with success after ") and words.endswith(NEEDS)
    assert "it was not slower than usual for its command type and size here (the usual bar is " in words


def test_a_version_2_key_of_the_same_family(copy, tmp_path):
    path, con = copy()
    r, got = run_family(path, "behaviour_01", str(tmp_path / "v2.csv"), version=2)
    assert got["rule"] == "admin.errors.nvme_command.cmd_family_behaviour_01.v2" and got["total"] == 6 and got["removed"] == 6
    assert not found(con, "rule=?", (FAMILY % "behaviour_01",))
    for f in found(con, "rule=?", (got["rule"],)):
        c, key, words = same_cause(con, of_detector(con, f["rowid"]), f)
        assert key == CAUSE[f["rowid"]]


DAMAGED = ["{not json", "", None, "[1, 2]", "7", "null", '"text"',
           json.dumps({"cycle": "gone", "host_limit_ps": "soon", "median_ps": [], "usual_bar_ps": {}, "times_median": "x", "kind": 5}),
           json.dumps({"cycle": {"reached": "submitted", "completed": "no"}, "host_limit_ps": True}),
           json.dumps({"cycle": {"reached": ["submitted"], "completed": True, "nak": "many"}}),
           json.dumps({"cycle": {"reached": [1, 2], "completed": False}, "admin_rule": "not an object"}),
           json.dumps({"cycle": None, "admin_rule": {"origin": 3}})]


@pytest.mark.parametrize("detail", DAMAGED)
def test_a_finding_whose_detail_is_damaged_gets_the_cause_of_its_command(con, detail):
    for row in (155, 216, 144):
        f = dict(of_family(con, "behaviour_01" if row != 144 else "status_13", row), detail=detail)
        c, key, words = same_cause(con, of_detector(con, row), f)
        assert key == CAUSE[row]
    f = dict(of_family(con, "behaviour_03", 501), detail=detail)
    assert decided(con, f)[1:] == decided(con, of_family(con, "behaviour_03", 501))[1:]


def test_a_finding_without_a_command_says_so(con):
    for f in ({"rule": FAMILY % "behaviour_01", "level": "nvme_command", "rowid": 10 ** 9, "cmd_rowid": 10 ** 9, "detail": "{}"},
              {"rule": "admin.errors.link.my_rule.v1", "level": "link", "rowid": 5, "cmd_rowid": None, "detail": None}):
        c, key, words = decided(con, f)
        assert key == "unknown_cause" and c["command"] is None
        assert words == NOTHING + ("this error belongs to no NVMe command of the tree, and every fixed rule reads the rows of the error's own command. To name a cause the "
                                   "error's row would have to belong to a command through the tree's parent links")


# ------------------------------------------------------------------------------------- what the wider reach must not get wrong
def test_a_command_still_open_when_the_recording_ended_is_not_given_the_cause_of_a_stall(copy):
    path, con = copy()
    end = con.execute("SELECT MAX(t_ps) FROM cmd").fetchone()[0]
    row = last_io_command_stopped(con)
    for f in (own(row), dict(own(row), rule="cmd.incomplete"), dict(own(row), rule=FAMILY % "behaviour_01")):
        c, key, words = decided(con, f)
        a = c["after"]
        assert c["completed"] is False and a["abort"] is None and a["reset"] is None and a["wait_end"] == "end of the recording" and 0 < a["outstanding_ps"] < 30 * S
        assert a["outstanding_ps"] >= end - con.execute("SELECT t_ps FROM cmd WHERE rowid_file=?", (row,)).fetchone()[0]
        assert key == "unknown_cause" and "before the host's limit for it (30.000 s): it was still open when the recording ended" in words
        assert "To name a cause the recording would have to go on until the host's limit" in words
    # the same command with the limit already passed is judged as before: the guard is only about the end of the recording
    c2, key2, words2 = decided(con, own(155))
    assert key2 == "device_internal_delay"


def test_an_asynchronous_event_request_without_a_completion_is_not_a_fault(copy):
    path, con = copy()
    con.execute("UPDATE cmd SET opc=12 WHERE rowid_file=216")            # the Abort that was never answered becomes a command that waits by design
    con.commit()
    for f in (own(216), dict(own(216), rule="cmd.incomplete")):
        c, key, words = decided(con, f)
        assert c["completed"] is False and c["not_timed"] == {"name": "Asynchronous Event Request", "why": "it stays open until an event occurs"} and c["host_limit_ps"] is None
        assert key == "unknown_cause" and words.startswith("this command (Asynchronous Event Request, on the admin queue) is never judged for time by the fixed rules, "
                                                           "because it stays open until an event occurs: that the recording holds no completion for it is not a fault")


def test_an_abort_that_names_another_command_or_cannot_be_read_is_not_given_to_a_completed_command(copy):
    """Row 144 completed as aborted, and Abort row 145 was sent while it was outstanding. The Abort is this command's only when its own
    parameters name it (queue 1, identifier 29); never because it is near in time. The same for the detector's error and the family's."""
    import test_cause_never_completed as N
    path, con = copy()
    pkt, raw = N.abort_packet(con, 145)
    b = raw["DATA"].split()
    assert b[40:44] == ["01", "00", "1D", "00"]
    b[42] = "1E"
    N.set_data(con, pkt, raw, " ".join(b))                               # now it names identifier 30
    for f in (of_detector(con, 144), of_family(con, "status_13", 144)):
        c, key, words = decided(con, f)
        assert c["abort"] is None and "abort_unreadable" not in c and key != "host_abort_by_tool_or_test" and "Abort" not in words
    same_cause(con, of_detector(con, 144), of_family(con, "status_13", 144))
    N.set_data(con, pkt, raw, "64 B")                                    # now its parameters cannot be read
    for f in (of_detector(con, 144), of_family(con, "status_13", 144)):
        c, key, words = decided(con, f)
        assert c["abort"] is None and c["abort_unreadable"]["row"] == 145 and key == "unknown_cause"
        assert words == ("an Abort was sent 60.000 µs after this command's doorbell, while it was outstanding (NVMe command row 145), but the data bytes of the Abort's entry "
                         "cannot be read, so the code cannot tell whether it was for this command and does not decide by nearness in time")


def test_a_status_without_a_completion_entry_is_not_called_never_completed(copy):
    path, con = copy()
    row = healthy_read(con)
    con.execute("DELETE FROM ntx WHERE parent_level='nvme_command' AND parent=? AND type LIKE '%Completion Queue Entry'", (row,))
    con.commit()
    c, key, words = decided(con, own(row))
    assert c["completed"] is None and c["after"] is None and c["stopped_after"] is None and "completed" not in c["reached"]
    assert key == "unknown_cause" and words.startswith(NOTHING + "the command's own row carries a status, but no completion entry is joined under it in the tree, "
                                                       "so where its cycle ended cannot be read. To name a cause")


def test_a_tree_without_its_nvme_transactions_does_not_crash_and_says_what_it_cannot_read(copy):
    path, con = copy()
    con.execute("DROP TABLE ntx")
    con.commit()
    for row in (155, healthy_read(con)):
        c, key, words = decided(con, own(row))
        assert c["completed"] is None and c["stages"] == [] and key == "unknown_cause"
        assert words.startswith(NOTHING + "the NVMe transactions of this recording are not in the tree, so the steps of this command, and whether a completion entry was "
                                "written for it, cannot be read. To name a cause")
    c, key, words = decided(con, own(144))                               # an Abort was sent while it was outstanding, and what it names cannot be read here
    assert key == "unknown_cause" and c["abort_unreadable"]["row"] == 145 and "does not decide by nearness in time" in words


def test_a_tree_in_which_the_detector_kept_no_times(copy):
    """A tree the built-in checks never measured (no limits, no usual times): nothing is assumed in their place."""
    path, con = copy()
    con.execute("DELETE FROM meta WHERE k='rules'")
    con.commit()
    c, key, words = decided(con, of_family(con, "behaviour_01", 155))    # the Abort that names it and the reset are in the rows: decided as before
    assert c["host_limit_ps"] is None and c["median_ps"] is None and c["read_from_tree"] == [EV.READ_CYCLE] and key == "device_internal_delay"
    assert words == decided(con, of_detector(con, 155))[2]
    c, key, words = decided(con, of_family(con, "status_13", 144))       # the Abort names it, but it cannot be placed before or after a limit nobody kept
    assert c["abort"]["row"] == 145 and key == "unknown_cause" and "after its limit" not in words
    assert words.startswith("the host sent an Abort for this command 60.000 µs after the doorbell (NVMe command row 145), but the host's limit for this command is not known")
    stop = last_io_command_stopped(con)
    c, key, words = decided(con, own(stop))                              # no completion, no Abort, no reset, no limit: cannot tell
    assert c["after"]["abort"] is None and c["after"]["reset"] is None and c["host_limit_ps"] is None
    assert key == "unknown_cause" and "the host's limit for it is not known for this recording" in words and "To name a cause the rules need that limit" in words


def test_a_tree_without_packets_gives_the_family_what_it_gives_the_detector(copy):
    path, con = copy()
    con.execute("DROP TABLE pkt")
    con.commit()
    c, key, words = same_cause(con, of_detector(con, 155), of_family(con, "behaviour_01", 155))
    assert key == "unknown_cause" and "could not be read from the tree" in words


# ------------------------------------------------------------------------------------- every seeded family, on a constructed row
def test_every_status_family_gets_what_the_detectors_status_error_gets_and_says_so_when_nothing_applies(copy):
    """One healthy command is given each status of each status family in turn (the command's row only: its completion entry stays). The
    family's error and the detector's "status error" of that row get the same cause; a status no fixed rule reads gets the honest sentence."""
    path, con = copy()
    io = healthy_read(con)
    adm = con.execute("SELECT rowid_file FROM cmd WHERE sqid=0 AND opc=6 AND sct=0 AND sc=0 ORDER BY rowid_file LIMIT 1").fetchone()[0]
    seen, covered = 0, set()
    for f in CE.FAMILIES:
        for q, sct, codes, _ops in f["check"].get("match") or []:
            row = adm if q == "admin" else io
            for sc in codes:
                con.execute("UPDATE cmd SET sct=?, sc=? WHERE rowid_file=?", (sct, sc, row))
                fam = {"rule": FAMILY % f["id"], "level": "nvme_command", "rowid": row, "cmd_rowid": row, "detail": json.dumps({"kind": "matched the rule '%s'" % f["name"]})}
                det = dict(fam, rule="cmd.status_error", detail=json.dumps({"SCT": sct, "SC": sc}))
                c, key, words = same_cause(con, det, fam)
                seen += 1
                if key == "unknown_cause":
                    assert words.startswith(NOTHING + "the command completed with status %Xh/%02Xh (" % (sct, sc)) and words.endswith(NEEDS), (f["id"], sct, sc, words)
                else:
                    assert sct == 2 and key == "media_retry_or_read_error", (f["id"], sct, sc, key)      # the one fixed rule that reads a status: status code type 2h
                    covered.add(f["id"])
            con.execute("UPDATE cmd SET sct=0, sc=0 WHERE rowid_file=?", (row,))
    assert seen == 124 and covered == {"status_01", "status_02", "status_03", "status_04", "status_05", "status_06"}


def test_a_slow_command_gets_the_cause_of_a_slow_answer_whichever_rule_found_it(copy):
    """The families "much slower than usual" and "completed after the host's limit" find no row of S17, so one healthy command is given a
    longer time in its own row (its steps stay). The fixed rule reads the command's time against the usual bar the detector measured for
    its type and size; where no bar is measured (fewer than 20 completed commands of that kind) nothing applies, and that is said."""
    path, con = copy()
    io = healthy_read(con)
    adm = con.execute("SELECT rowid_file FROM cmd WHERE sqid=0 AND opc=6 AND sct=0 AND sc=0 ORDER BY rowid_file LIMIT 1").fetchone()[0]
    for took, fam in ((10 ** 9, "behaviour_05"), (31 * S, "behaviour_02")):
        con.execute("UPDATE cmd SET dur_ps=? WHERE rowid_file=?", (took, io))
        c, key, words = same_cause(con, dict(own(io), rule="cmd.latency_over_limit"), dict(own(io), rule=FAMILY % fam))
        assert key == "device_internal_delay" and c["usual_ps"] > 0 and c["host_limit_ps"] == 30 * S
        assert words.startswith("the drive answered after %s, longer than this command type's usual bar here (%s), with a clean link" % (EV.fmt(took), EV.fmt(c["usual_ps"])))
    con.execute("UPDATE cmd SET dur_ps=? WHERE rowid_file=?", (61 * S, adm))
    c, key, words = decided(con, dict(own(adm), rule=FAMILY % "behaviour_02"))
    assert c["usual_ps"] is None and c["host_limit_ps"] == 60 * S and key == "unknown_cause"
    assert words.startswith(NOTHING + "the command completed with success after 61.000 s") and words.endswith(NEEDS)
    assert "no usual time is measured in this recording for its command type and size" in words


# ------------------------------------------------------------------------------------- through the page's own call
def test_the_page_names_the_same_cause_for_the_familys_error_and_the_detectors(tree):
    import fuzz_app as F
    from agentic import core, family1
    from api import config_api, hier_api as H
    kept = (core.Engine.kick, family1.knowledge_dir, config_api.save_config, H.ENV_FILE)
    root = tempfile.mkdtemp(prefix="cause_family_page_%d_" % os.getpid(), dir=os.environ.get("F2T_TEST_TMP") or None)
    try:
        app, c, _k, _r = F.setup(root)
        d = os.path.join(H.uploads_dir(app.config["services"]), "up-s17-families")
        os.makedirs(d)
        src, dst = sqlite3.connect("file:%s?mode=ro" % tree["db"], uri=True), sqlite3.connect(os.path.join(d, "hier.sqlite"))
        src.backup(dst)
        ids = {(r[0], r[1]): r[2] for r in dst.execute("SELECT rule, rowid, id FROM finding WHERE level='nvme_command'")}
        src.close()
        dst.close()
        H.write_meta(d, {"upload_id": "up-s17-families", "created": 1.0, "operator": "t", "device": "D", "trace_name": "S17", "recording_date": "", "notes": "",
                         "files": {k: os.path.join(S17, v) for k, v in NAMES.items()}, "status": "loaded", "thresholds": {}, "file_stats": {}})
        lv = ["nvme_transaction", "split", "link", "packets"]

        def page(fid, n=2, m=1):
            r = c.post("/api/isolate/up-s17-families/%d/isolate" % fid, json={"anyway": True, "standin": True, "name": "t", "isolation": True, "levels": lv, "n": n, "m": m})
            assert r.status_code == 200, r.get_json()
            return r.get_json()["isolation"]
        for row, fam in ((155, "behaviour_01"), (216, "behaviour_03"), (144, "status_13")):
            det, own_ = page(ids[("cmd.timeout", row)]), page(ids[(FAMILY % fam, row)])
            assert det["cause_key"] == own_["cause_key"] == CAUSE[row] and det["cause_header"] == own_["cause_header"] and det["cause"] == own_["cause"]
            assert evidence(det["card"]) == evidence(own_["card"]) and det["who"] == own_["who"] and det["when"] == own_["when"] and det["which"] == own_["which"]
            assert own_["rule"] == FAMILY % fam and own_["decided_by"] == "the fixed rules of the evidence card (version 3) and the dictionary (version %d)" % TM.VERSION
            wide = page(ids[(FAMILY % fam, row)], 40, 40)                # the window does not change it
            assert wide["cause_key"] == own_["cause_key"] and wide["card_hash"] == own_["card_hash"] and wide["cause_header"] == own_["cause_header"]
        answered = page(ids[(FAMILY % "behaviour_03", 501)])
        assert answered["cause_key"] == "unknown_cause" and answered["cause"]["name"] == "not decided from this recording"
        assert answered["cause_header"].startswith(NOTHING) and "NVMe command row 443 (queue 3, identifier 4), which never completed" in answered["cause_header"]
    finally:
        core.Engine.kick, family1.knowledge_dir, config_api.save_config, H.ENV_FILE = kept
        shutil.rmtree(root, ignore_errors=True)
