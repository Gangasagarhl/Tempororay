"""What a reproduction search learned, kept per kind of defect, and given to the next search of the same kind.

No model is trained or fine-tuned here. The memory is counts and stored search state only:

  after a search   one event "search_learned" in the knowledge base (stage2/kgdb.py): how often each change operator
                   improved the result and how often it did not (the counts of THAT search only), the best procedure
                   found (commands, timing, power state) with its reward and its reproduction count, and the result
                   of the most-stressful-conditions step when there is one. The table `search_memory` is computed
                   from these events (undo and rebuild work as for every other table). No side file.
  before a search  recall(db, kind of defect): the counts of the earlier searches of the SAME kind are added up and
                   become the starting counts of the operator choice; the best stored procedure is run right after
                   the seed procedure.

The bound (CARRY_LIMIT_RUNS). The counts carried over are scaled down so that together they weigh at most
14 lab runs: one lab run for each of the 14 change operators. A search may spend hundreds of lab runs, and without a
bound a long history would fix the operator choice before the new search has measured anything (a changed firmware,
another device, or simply a history that was wrong). With the bound, about 14 new lab runs weigh as much as the whole
history, so new results overrule old ones early in the search. Only the latest HISTORY_SEARCHES searches are read.

A stored record that cannot be read (damaged text, counts that are not numbers, a procedure with a command that is not
allowed) is left out, and the reason is returned in plain words; it never stops a search.
"""
import json
import os

from oracle import OPS, POWER, TIMING_KEYS

EVENT_KIND = "search_learned"
SETTING = "stage2.search_memory"
CARRY_LIMIT_RUNS = 14.0          # total weight of the counts carried over, in lab runs (see the module text for why)
HISTORY_SEARCHES = 20            # only the latest searches of a kind of defect are read
# the same names the search uses (stage2/optimizer.py OPERATORS / DENY_OPS); kept here so that this module imports
# without the optimizer (the optimizer imports this module)
_OPERATORS = ("insert_cmd", "delete_cmd", "swap_cmds", "replace_cmd", "dup_cmd", "mut_qd", "mut_bs", "mut_inter_cmd",
              "mut_burst", "mut_idle", "mut_power", "crossover", "nudge_timing", "step_timing")
_DENIED = ("format", "sanitize", "fw_download", "fw_commit", "ns_delete")
_OPERATOR_WORDS = {"insert_cmd": "insert a command", "delete_cmd": "remove a command", "swap_cmds": "swap two commands",
                   "replace_cmd": "replace a command", "dup_cmd": "repeat a command", "mut_qd": "change the queue depth",
                   "mut_bs": "change the block size", "mut_inter_cmd": "change the spacing between commands",
                   "mut_burst": "change the burst length", "mut_idle": "change the idle gap",
                   "mut_power": "change the power state", "crossover": "combine two procedures",
                   "nudge_timing": "small step on one timing value",
                   "step_timing": "jump one timing value to a standard point"}
TIMING_WORDS = {"inter_cmd_us": ("spacing between commands", "microseconds"), "qd": ("queue depth", "commands at once"),
                "bs_kb": ("block size", "kilobytes"), "burst_len": ("burst length", "commands"),
                "idle_gap_ms": ("idle gap", "milliseconds")}


def setting_from_config(path=None):
    """The value of the setting stage2.search_memory in config/app_config.json (the shipped value: on). Used only when
    the caller of Stage2V3 does not say on or off itself. A file that is missing or cannot be read means on."""
    path = path or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config", "app_config.json")
    try:
        with open(path, encoding="utf-8") as f:
            value = (json.load(f).get("stage2") or {}).get("search_memory", True)
    except (OSError, ValueError, AttributeError):
        return True
    if isinstance(value, str):
        return value.strip().lower() not in ("off", "false", "no", "0", "")
    return bool(value)


# ---------------------------------------------------------------------------------------------- checking a record
def clean_scenario(sc):
    """A stored procedure, checked: returns the procedure in the search's own form, or raises ValueError with the
    reason in plain words."""
    if not isinstance(sc, dict):
        raise ValueError("the stored procedure is not a record")
    cmds = sc.get("commands")
    if not isinstance(cmds, list) or not 1 <= len(cmds) <= 12:
        raise ValueError("the stored procedure does not have between 1 and 12 commands")
    ops = []
    for c in cmds:
        op = c.get("op") if isinstance(c, dict) else c
        if op in _DENIED:
            raise ValueError("the stored procedure contains a command the search must never run (%s)" % op)
        if op not in OPS:
            raise ValueError("the stored procedure contains a command the search does not know")
        ops.append(op)
    timing_in = sc.get("timing")
    if not isinstance(timing_in, dict):
        raise ValueError("the stored procedure has no timing values")
    timing = {}
    for key, (lo, hi) in TIMING_KEYS.items():
        v = timing_in.get(key)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v:
            raise ValueError("the stored procedure has a timing value that is not a number (%s)" % TIMING_WORDS[key][0])
        timing[key] = int(min(hi, max(lo, v)))
    power = sc.get("power_state", "none")
    if power not in POWER:
        raise ValueError("the stored procedure names a power state the search does not know")
    return {"commands": [{"op": o} for o in ops], "timing": timing, "power_state": power}


def _count(v):
    if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v or v < 0 or v > 1e9:
        raise ValueError("its operator counts are not numbers of lab runs")
    return float(v)


def clean_record(pl):
    """One stored "search_learned" record, checked. Raises ValueError (plain words) when it cannot be used."""
    if not isinstance(pl, dict):
        raise ValueError("it is not a record")
    ops_in = pl.get("operators")
    if not isinstance(ops_in, dict):
        raise ValueError("its operator counts are missing")
    operators = {}
    for o in _OPERATORS:
        ab = ops_in.get(o, [0, 0])
        if not isinstance(ab, (list, tuple)) or len(ab) != 2:
            raise ValueError("its operator counts are not pairs of numbers")
        operators[o] = [_count(ab[0]), _count(ab[1])]
    best = pl.get("best")
    out_best = None
    if best is not None:
        if not isinstance(best, dict):
            raise ValueError("its best procedure is not a record")
        k, n = best.get("repro_k", 0), best.get("repro_n", 0)
        reward = best.get("reward", 0.0)
        for v in (k, n, reward):
            if isinstance(v, bool) or not isinstance(v, (int, float)) or v != v:
                raise ValueError("the reward or the reproduction count of its best procedure is not a number")
        out_best = {"scenario": clean_scenario(best.get("scenario")), "reward": float(reward), "repro_k": int(k),
                    "repro_n": int(n)}
    stress = pl.get("stress")
    out_stress = None
    if isinstance(stress, dict) and stress.get("scenario") is not None:
        out_stress = {"scenario": clean_scenario(stress["scenario"]), "pushed": dict(stress.get("pushed") or {}),
                      "stress": stress.get("stress"), "trials": stress.get("trials")}
    return {"operators": operators, "best": out_best, "stress": out_stress, "status": str(pl.get("status", "")),
            "trials": pl.get("trials")}


# ---------------------------------------------------------------------------------------------- after a search
def record_of(sig, result, family=None, best_scenario=None, stress=None, optimizer="bandit"):
    """The record of one finished search, from the result its search() returned (Optimizer.finish). `best_scenario`
    replaces the result's best procedure when the caller made it shorter afterwards (minimize); `stress` is the result
    of the most-stressful-conditions step, or None."""
    learned = result.get("learned") or {}
    sc = best_scenario if best_scenario is not None else result.get("best_scenario")
    best = None
    if sc:
        best = {"scenario": {"commands": [{"op": c["op"] if isinstance(c, dict) else c} for c in sc["commands"]],
                             "timing": dict(sc["timing"]), "power_state": sc.get("power_state", "none")},
                "reward": result.get("best_reward", 0.0), "repro_k": result.get("repro_k", 0),
                "repro_n": result.get("repro_n", 0)}
    rec = {"sig": sig, "family": family, "optimizer": optimizer, "status": result.get("status"),
           "trials": result.get("trials"),
           "operators": {o: list((learned.get("operators") or {}).get(o, [0, 0])) for o in _OPERATORS},
           "runs_to_first_reproduction": learned.get("runs_to_first_reproduction"), "best": best,
           "started_from_earlier_searches": int((result.get("search_memory") or {}).get("earlier_searches") or 0)}
    if stress and stress.get("scenario"):
        rec["stress"] = {"scenario": stress["scenario"], "pushed": stress.get("pushed") or {},
                         "stress": stress.get("stress"), "trials": stress.get("trials")}
    return rec


def remember(db, sig, result, family=None, best_scenario=None, stress=None, optimizer="bandit", actor="search"):
    """Save what a finished search learned as one event in the knowledge base. Returns the event number."""
    return db.apply_event(EVENT_KIND, record_of(sig, result, family, best_scenario, stress, optimizer), actor)


# ---------------------------------------------------------------------------------------------- before a search
def _seed_rank(best):
    """Which stored procedure is the best seed: one that reproduced beats one that did not, then the share of lab runs
    that showed the defect, then the reward."""
    k, n = best["repro_k"], best["repro_n"]
    return (1 if k > 0 else 0, (k / n) if n > 0 else 0.0, best["reward"])


def recall(db, sig, limit_runs=CARRY_LIMIT_RUNS):
    """What the earlier searches of this kind of defect learned, ready for Optimizer(memory=...).

    Returns a dict: searches (how many earlier searches were read), operator_prior {operator: [improved, did not
    improve]} already scaled to at most `limit_runs` lab runs in total, counts_found (the counts before scaling),
    seed (the best stored procedure or None) with seed_reward / seed_repro_k / seed_repro_n, stress (the latest
    stored most-stressful procedure or None), ignored (plain messages about records that were left out)."""
    ignored, records = [], []
    try:
        rows = db.search_memory_rows(sig, HISTORY_SEARCHES)
    except Exception as e:                                   # a knowledge base without the table, a locked file, ...
        rows = []
        ignored.append("The memory of earlier searches could not be read (%s); this search starts without history."
                       % type(e).__name__)
    for eid, payload in rows:
        try:
            pl = json.loads(payload) if isinstance(payload, str) else payload
            if isinstance(pl, dict) and pl.get("sig") != sig:
                raise ValueError("it belongs to another kind of defect")
            records.append((eid, clean_record(pl)))
        except (ValueError, TypeError, KeyError, AttributeError) as e:
            why = str(e) if isinstance(e, ValueError) and not isinstance(e, json.JSONDecodeError) else "its text is damaged"
            ignored.append("A stored search record (event number %s) could not be used and was left out: %s." % (eid, why))
    total = {o: [0.0, 0.0] for o in _OPERATORS}
    seed, seed_event, stress = None, None, None
    for eid, rec in records:
        for o in _OPERATORS:
            total[o][0] += rec["operators"][o][0]
            total[o][1] += rec["operators"][o][1]
        if rec["best"] and (seed is None or _seed_rank(rec["best"]) >= _seed_rank(seed)):
            seed, seed_event = rec["best"], eid
        if rec["stress"]:
            stress = rec["stress"]
    found = sum(a + b for a, b in total.values())
    limit_runs = max(0.0, float(limit_runs))
    factor = 1.0 if found <= limit_runs or found == 0 else limit_runs / found
    prior = {o: [round(a * factor, 4), round(b * factor, 4)] for o, (a, b) in total.items()}
    return {"sig": sig, "searches": len(records), "operator_prior": prior, "counts_found": round(found, 2),
            "counts_found_by_operator": {o: [round(a, 2), round(b, 2)] for o, (a, b) in total.items()},
            "weight_carried": round(found * factor, 2), "weight_limit": limit_runs, "scaled_down": factor < 1.0,
            "seed": seed["scenario"] if seed else None, "seed_event": seed_event,
            "seed_reward": seed["reward"] if seed else None, "seed_repro_k": seed["repro_k"] if seed else None,
            "seed_repro_n": seed["repro_n"] if seed else None, "stress": stress, "ignored": ignored}


# ---------------------------------------------------------------------------------------------- plain words
def scenario_words(sc):
    """A procedure in one line of plain words, every number with its unit."""
    t = sc["timing"]
    parts = ["%s %s %s" % (TIMING_WORDS[k][0], t[k], TIMING_WORDS[k][1]) for k in TIMING_WORDS if k in t]
    power = sc.get("power_state", "none")
    return "commands %s; %s; %s" % (", ".join(c["op"].replace("_", " ") for c in sc["commands"]), ", ".join(parts),
                                    "no power state change" if power == "none" else "power state %s" % power)


def report(memory, seed_result=None, switched_on=True):
    """What was reused, for the result record of the search and for the screen. `memory` is recall()'s answer (or None),
    `seed_result` what the stored procedure did when it was run again in this search."""
    if not switched_on:
        return {"used": False, "switched_on": False, "earlier_searches": 0, "ignored_records": [],
                "words": "The memory of earlier searches is switched off (setting %s), so this search started "
                         "without history and nothing it learned was stored." % SETTING}
    ignored = list((memory or {}).get("ignored") or [])
    if not memory or not memory.get("searches"):
        return {"used": False, "switched_on": True, "earlier_searches": 0, "ignored_records": ignored,
                "words": "No earlier search of this kind of defect is stored, so this search started without history."
                         + ((" " + " ".join(ignored)) if ignored else "")}
    n = memory["searches"]
    by_op = memory.get("counts_found_by_operator") or {}
    improved = sum(v[0] for v in by_op.values())
    not_improved = sum(v[1] for v in by_op.values())
    words = "Started from what %d earlier search%s of this kind of defect learned." % (n, "" if n == 1 else "es")
    if memory["counts_found"] > 0:
        words += (" Their %d counted changes to the procedure (%d improved the result, %d did not) set the starting "
                  "counts for the choice of the next change" % (round(memory["counts_found"]), round(improved), round(not_improved)))
        if memory["scaled_down"]:
            words += (", scaled down to the weight of %d lab runs, the limit that keeps old history from outweighing "
                      "new results." % round(memory["weight_limit"]))
        else:
            words += "."
    carried = []
    for o, (a, b) in sorted(memory["operator_prior"].items(), key=lambda kv: -(kv[1][0] + kv[1][1])):
        if a + b > 0:
            carried.append({"operator": _OPERATOR_WORDS.get(o, o), "improved_weight_lab_runs": a,
                            "did_not_improve_weight_lab_runs": b, "improved_count": by_op.get(o, [0, 0])[0],
                            "did_not_improve_count": by_op.get(o, [0, 0])[1]})
    out = {"used": True, "switched_on": True, "earlier_searches": n, "counts_found": memory["counts_found"],
           "counts_improved": improved, "counts_did_not_improve": not_improved,
           "weight_carried_lab_runs": memory["weight_carried"], "weight_limit_lab_runs": memory["weight_limit"],
           "scaled_down": memory["scaled_down"], "counts_carried": carried, "seed_from_memory": memory.get("seed"),
           "seed_from_memory_words": None, "seed_result": seed_result, "ignored_records": ignored}
    if memory.get("seed"):
        out["seed_from_memory_words"] = scenario_words(memory["seed"])
        k, n_runs = memory.get("seed_repro_k") or 0, memory.get("seed_repro_n") or 0
        words += (" The best procedure stored for this kind of defect (%s; earlier it showed the defect in %d of %d lab "
                  "runs) was run again right after the seed procedure" % (out["seed_from_memory_words"], k, n_runs))
        if seed_result == "reproduced":
            words += ", and it showed the defect again."
        elif seed_result == "not_reproduced":
            words += ", and it did not show the defect this time."
        elif seed_result == "not_run":
            words += ", but the lab runs allowed for this search were used up before its turn."
        else:
            words += "."
    if ignored:
        words += " " + " ".join(ignored)
    out["words"] = words
    return out


# ---------------------------------------------------------------------------------------------- reward from findings
def _ratio_closeness(measured, recorded):
    """How close two measured values are, 0 to 1: the smaller divided by the larger (1 = the same value)."""
    try:
        a, b = float(measured), float(recorded)
    except (TypeError, ValueError):
        return None
    if a != a or b != b or a < 0 or b < 0:
        return None
    if a == b:
        return 1.0
    return min(a, b) / max(a, b)


def timing_closeness(found_timing, recorded_timing):
    """Mean closeness over the timing values that both the finding and the recorded failure carry (for example the
    measured latency in microseconds), or None when they share no value."""
    if not isinstance(found_timing, dict) or not isinstance(recorded_timing, dict):
        return None
    vals = [c for c in (_ratio_closeness(found_timing.get(k), v) for k, v in recorded_timing.items()
                        if k in found_timing) if c is not None]
    return (sum(vals) / len(vals)) if vals else None


def stage_from_findings(findings, target):
    """stage, closeness and reproduced of one lab run from the detector's findings alone (no hidden answer).

    findings  what the detector found in the capture of this run: [{"card_id" (the error type), "verdict"
              ("CONFIRMED" | "SUSPECT"), "closeness" (detector score 0 to 1), "rule" (the first rule that fired),
              "timing" ({name: measured value}, optional)}]
    target    the recorded failure: {"sig": error type, "expected": error types that count as the same failure (the
              type and its ambiguity group; default: the type alone), "rule": first rule of the recorded failure
              (optional), "timing": {name: value measured in the recorded failure} (optional)}

    The rules are those of deploy/BENCH_INTEGRATION.md section 2.5:
      the same error type found again, CONFIRMED                          stage 3
      ... and with the same first rule as the recorded failure             stage 4
      the same error type found again, SUSPECT only                       stage 2
      only an error type of the same family (same letters before "-")     stage 1, closeness 0.5
      nothing of the kind                                                 stage 0, closeness 0.0
    closeness inside stages 2 to 4: how close the measured timing of the finding is to the recorded failure (smaller
    value divided by larger, mean over the shared timing values); when the finding or the recorded failure carries no
    timing, the detector's own score of the finding, limited to 0 to 1.
    Returns {"stage", "closeness", "reproduced" (stage >= 3), "basis" (plain words)}."""
    target = target or {}
    sig = target.get("sig")
    expected = set(target.get("expected") or ([sig] if sig else []))
    family = str(sig).split("-")[0] if sig else None
    best = (0, 0.0, "the detector found nothing of this kind in the capture of this lab run")
    for f in findings or []:
        if not isinstance(f, dict):
            continue
        card, verdict = f.get("card_id"), f.get("verdict")
        if card in expected and verdict in ("CONFIRMED", "SUSPECT"):
            close = timing_closeness(f.get("timing"), target.get("timing"))
            if close is None:
                try:
                    close = min(1.0, max(0.0, float(f.get("closeness", 0.0))))
                except (TypeError, ValueError):
                    close = 0.0
                how = "closeness is the detector's own score of the finding (no shared timing value to compare)"
            else:
                how = "closeness compares the measured timing of the finding with the recorded failure"
            if verdict == "CONFIRMED":
                same_rule = bool(target.get("rule")) and f.get("rule") == target.get("rule")
                cand = (4 if same_rule else 3, close, "the same error type was found again and confirmed%s; %s"
                        % (", by the same first rule as the recorded failure" if same_rule else "", how))
            else:
                cand = (2, close, "the same error type was found again, as a suspicion only; %s" % how)
        elif family and isinstance(card, str) and card.split("-")[0] == family and verdict in ("CONFIRMED", "SUSPECT"):
            cand = (1, 0.5, "only another error type of the same family was found")
        else:
            continue
        if cand[:2] > best[:2]:
            best = cand
    return {"stage": best[0], "closeness": round(best[1], 4), "reproduced": best[0] >= 3, "basis": best[2]}


def complete_run_record(res, target):
    """A lab run's record with stage / closeness / reproduced filled in. A record that already carries a stage (the
    simulated bench, or a hardware bench that computes it) is returned unchanged. A record that carries findings and
    no stage gets them from stage_from_findings. Findings are read from "findings" (everything the detector found) or,
    when that is missing, from "isolated" (the findings of the expected error types)."""
    if not isinstance(res, dict):
        raise ValueError("the bench returned no record for this lab run")
    if res.get("stage") is not None and res.get("closeness") is not None:
        if "reproduced" not in res:
            res = dict(res, reproduced=res["stage"] >= 3)
        return res
    findings = res.get("findings")
    if findings is None:
        findings = res.get("isolated")
    if findings is None:
        raise ValueError("the bench record of this lab run has neither a stage nor the detector's findings, so the "
                         "search cannot tell whether the defect appeared")
    got = stage_from_findings(findings, target)
    out = dict(res)
    out.update(stage=got["stage"], closeness=got["closeness"], reproduced=got["reproduced"],
               reward_from="findings", reward_basis=got["basis"])
    out.setdefault("cost_s", 0.0)
    return out


class BenchWithStage:
    """A bench whose lab-run records always carry stage / closeness / reproduced. A record that already has them (the
    simulated bench) passes through unchanged, the same object; a record with the detector's findings and no stage (a
    real drive: there is no hidden answer) gets them from stage_from_findings. Everything else of the bench (its
    counters, its detect(), its fault injection) is reached as before."""

    def __init__(self, bench, target):
        self._bench, self._target = bench, target

    def run(self, scenario):
        return complete_run_record(self._bench.run(scenario), self._target)

    def __getattr__(self, name):
        if name.startswith("__") or name in ("_bench", "_target"):
            raise AttributeError(name)
        return getattr(self._bench, name)
